; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [160 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [160 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [160 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [160 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.spill10 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill10, align 64
  %.spill11 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill11, align 64
  %.spill12 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill12, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %.spill14 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill14, align 64
  %.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill15, align 64
  %.spill16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill16, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %.spill18 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill18, align 64
  %.spill19 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill19, align 64
  %.spill20 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill20, align 64
  %.spill21 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill21, align 64
  %.spill22 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill22, align 64
  %.spill23 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill23, align 64
  %.spill24 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill24, align 64
  %.spill25 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill25, align 64
  %.spill26 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill26, align 64
  %.spill27 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill27, align 64
  %.spill28 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill28, align 1
  %tile_snapshot.spill29 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill29, align 64
  %.spill30 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill30, align 64
  %.spill31 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill31, align 64
  %.spill32 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill32, align 64
  %.spill33 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill33, align 64
  %.spill34 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill34, align 64
  %.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill35, align 64
  %.spill36 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill36, align 64
  %.spill37 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill37, align 64
  %tile_snapshot.spill38 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill38, align 64
  %.spill39 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill39, align 64
  %.spill40 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill40, align 64
  %.spill41 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill41, align 64
  %.spill42 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill42, align 64
  %.spill43 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill43, align 64
  %.spill44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill44, align 64
  %.spill45 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill45, align 64
  %.spill46 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill46, align 64
  %.spill47 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill47, align 64
  %tile_snapshot.spill48 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill48, align 64
  %.spill49 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill49, align 64
  %.spill50 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill50, align 64
  %.spill51 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill51, align 64
  %.spill52 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %.spill52, align 64
  %8 = getelementptr i8, ptr %argument_buffer, i64 0
  %9 = load ptr, ptr %8, align 16
  %10 = getelementptr i8, ptr %8, i64 8
  %11 = load i64, ptr %10, align 8
  %12 = insertvalue { ptr, i64 } poison, ptr %9, 0
  %13 = insertvalue { ptr, i64 } %12, i64 %11, 1
  %14 = getelementptr i8, ptr %argument_buffer, i64 16
  %15 = load ptr, ptr %14, align 16
  %16 = getelementptr i8, ptr %14, i64 8
  %17 = load i64, ptr %16, align 8
  %18 = insertvalue { ptr, i64 } poison, ptr %15, 0
  %19 = insertvalue { ptr, i64 } %18, i64 %17, 1
  %20 = getelementptr i8, ptr %argument_buffer, i64 32
  %21 = load ptr, ptr %20, align 16
  %22 = getelementptr i8, ptr %20, i64 8
  %23 = load i64, ptr %22, align 8
  %24 = insertvalue { ptr, i64 } poison, ptr %21, 0
  %25 = insertvalue { ptr, i64 } %24, i64 %23, 1
  %26 = getelementptr i8, ptr %argument_buffer, i64 48
  %27 = load ptr, ptr %26, align 16
  %28 = getelementptr i8, ptr %26, i64 8
  %29 = load i64, ptr %28, align 8
  %30 = insertvalue { ptr, i64 } poison, ptr %27, 0
  %31 = insertvalue { ptr, i64 } %30, i64 %29, 1
  %32 = load i32, ptr %launch_config, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 12
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 4
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 16
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 8
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 20
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 36
  %44 = load i32, ptr %43, align 4
  %.splatinsert53 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat54 = shufflevector <8 x i32> %.splatinsert53, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat54, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %46 = mul i32 %32, 32
  %.splatinsert55 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat56 = shufflevector <8 x i32> %.splatinsert55, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat56, %45
  %48 = mul i32 %36, 1
  %.splatinsert57 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat58 = shufflevector <8 x i32> %.splatinsert57, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat58, zeroinitializer
  %50 = mul i32 %40, 1
  %.splatinsert59 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat60 = shufflevector <8 x i32> %.splatinsert59, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat60, zeroinitializer
  %52 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %47, 0
  %53 = insertvalue [3 x <8 x i32>] %52, <8 x i32> %49, 1
  %54 = insertvalue [3 x <8 x i32>] %53, <8 x i32> %51, 2
  %.splatinsert61 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat62 = shufflevector <8 x i32> %.splatinsert61, <8 x i32> poison, <8 x i32> zeroinitializer
  %55 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat62
  %56 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  br i1 %56, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %57 = extractvalue [3 x <8 x i32>] %54, 0
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = sub <8 x i32> %57, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %61 = select <8 x i1> %55, <8 x i32> %60, <8 x i32> zeroinitializer
  %62 = select <8 x i1> %55, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %63 = lshr <8 x i32> %61, %62
  %64 = zext <8 x i32> %63 to <8 x i64>
  %65 = select <8 x i1> %55, <8 x i64> %64, <8 x i64> zeroinitializer
  %66 = select <8 x i1> %55, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %67 = sdiv <8 x i64> %65, %66
  %68 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %69 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %68, 0
  %71 = select <8 x i1> %55, <8 x ptr> %69, <8 x ptr> %70
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %68, 1
  %74 = select <8 x i1> %55, <8 x i64> %72, <8 x i64> %73
  %75 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %71, 0
  %76 = insertvalue { <8 x ptr>, <8 x i64> } %75, <8 x i64> %74, 1
  store { <8 x ptr>, <8 x i64> } %76, ptr %tile_snapshot.spill, align 64
  %77 = load <8 x i64>, ptr %.spill10, align 64
  %78 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %77
  store <8 x i64> %78, ptr %.spill10, align 64
  %79 = add <8 x i64> %67, zeroinitializer
  %80 = add <8 x i64> zeroinitializer, %79
  %81 = load <8 x i64>, ptr %.spill11, align 64
  %82 = select <8 x i1> %55, <8 x i64> %80, <8 x i64> %81
  store <8 x i64> %82, ptr %.spill11, align 64
  %83 = load <8 x i64>, ptr %.spill12, align 64
  %84 = select <8 x i1> %55, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %83
  store <8 x i64> %84, ptr %.spill12, align 64
  %85 = mul <8 x i64> %80, splat (i64 66)
  %86 = load <8 x i64>, ptr %.spill13, align 64
  %87 = select <8 x i1> %55, <8 x i64> %85, <8 x i64> %86
  store <8 x i64> %87, ptr %.spill13, align 64
  %88 = add <8 x i64> %85, <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>
  %89 = load <8 x i64>, ptr %.spill14, align 64
  %90 = select <8 x i1> %55, <8 x i64> %88, <8 x i64> %89
  store <8 x i64> %90, ptr %.spill14, align 64
  %91 = extractvalue { ptr, i64 } %13, 0
  %92 = extractelement <8 x i64> %88, i32 0
  %93 = sub i64 %92, 0
  %94 = mul i64 %93, 4
  %buffer.contiguous.address = getelementptr i8, ptr %91, i64 %94
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %55, <8 x float> zeroinitializer)
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %97 = add <8 x i64> %96, zeroinitializer
  %98 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %95, 0
  %99 = insertvalue { <8 x ptr>, <8 x i64> } %98, <8 x i64> %97, 1
  %100 = load { <8 x ptr>, <8 x i64> }, ptr %.spill15, align 64
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %99, 0
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %100, 0
  %103 = select <8 x i1> %55, <8 x ptr> %101, <8 x ptr> %102
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %99, 1
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %100, 1
  %106 = select <8 x i1> %55, <8 x i64> %104, <8 x i64> %105
  %107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %103, 0
  %108 = insertvalue { <8 x ptr>, <8 x i64> } %107, <8 x i64> %106, 1
  store { <8 x ptr>, <8 x i64> } %108, ptr %.spill15, align 64
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %99, 1
  %111 = extractelement <8 x ptr> %109, i32 0
  %112 = extractelement <8 x i64> %110, i32 0
  %113 = sub i64 %112, 0
  %114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %115 = select i1 %114, i64 %113, i64 0
  %private.contiguous.address = getelementptr i8, ptr %111, i64 %115
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %116 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %116, ptr %private.contiguous.address, align 4
  %117 = load <8 x i64>, ptr %.spill16, align 64
  %118 = select <8 x i1> %55, <8 x i64> <i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15>, <8 x i64> %117
  store <8 x i64> %118, ptr %.spill16, align 64
  %119 = load <8 x i64>, ptr %.spill17, align 64
  %120 = select <8 x i1> %55, <8 x i64> <i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15>, <8 x i64> %119
  store <8 x i64> %120, ptr %.spill17, align 64
  %121 = add <8 x i64> %85, <i64 8, i64 9, i64 10, i64 11, i64 12, i64 13, i64 14, i64 15>
  %122 = load <8 x i64>, ptr %.spill18, align 64
  %123 = select <8 x i1> %55, <8 x i64> %121, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill18, align 64
  %124 = extractvalue { ptr, i64 } %13, 0
  %125 = extractelement <8 x i64> %121, i32 0
  %126 = sub i64 %125, 0
  %127 = mul i64 %126, 4
  %buffer.contiguous.address63 = getelementptr i8, ptr %124, i64 %127
  %buffer.contiguous.load64 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address63, <8 x i1> %55, <8 x float> zeroinitializer)
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %129 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %130 = add <8 x i64> %129, splat (i64 32)
  %131 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %128, 0
  %132 = insertvalue { <8 x ptr>, <8 x i64> } %131, <8 x i64> %130, 1
  %133 = load { <8 x ptr>, <8 x i64> }, ptr %.spill19, align 64
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %132, 0
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %133, 0
  %136 = select <8 x i1> %55, <8 x ptr> %134, <8 x ptr> %135
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %138 = extractvalue { <8 x ptr>, <8 x i64> } %133, 1
  %139 = select <8 x i1> %55, <8 x i64> %137, <8 x i64> %138
  %140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %141 = insertvalue { <8 x ptr>, <8 x i64> } %140, <8 x i64> %139, 1
  store { <8 x ptr>, <8 x i64> } %141, ptr %.spill19, align 64
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %143 = extractvalue { <8 x ptr>, <8 x i64> } %132, 1
  %144 = extractelement <8 x ptr> %142, i32 0
  %145 = extractelement <8 x i64> %143, i32 0
  %146 = sub i64 %145, 0
  %147 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %148 = select i1 %147, i64 %146, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %144, i64 %148
  %private.contiguous.preserve66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %149 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load64, <8 x float> %private.contiguous.preserve66
  store <8 x float> %149, ptr %private.contiguous.address65, align 4
  %150 = load <8 x i64>, ptr %.spill20, align 64
  %151 = select <8 x i1> %55, <8 x i64> <i64 16, i64 17, i64 18, i64 19, i64 20, i64 21, i64 22, i64 23>, <8 x i64> %150
  store <8 x i64> %151, ptr %.spill20, align 64
  %152 = load <8 x i64>, ptr %.spill21, align 64
  %153 = select <8 x i1> %55, <8 x i64> <i64 16, i64 17, i64 18, i64 19, i64 20, i64 21, i64 22, i64 23>, <8 x i64> %152
  store <8 x i64> %153, ptr %.spill21, align 64
  %154 = add <8 x i64> %85, <i64 16, i64 17, i64 18, i64 19, i64 20, i64 21, i64 22, i64 23>
  %155 = load <8 x i64>, ptr %.spill22, align 64
  %156 = select <8 x i1> %55, <8 x i64> %154, <8 x i64> %155
  store <8 x i64> %156, ptr %.spill22, align 64
  %157 = extractvalue { ptr, i64 } %13, 0
  %158 = extractelement <8 x i64> %154, i32 0
  %159 = sub i64 %158, 0
  %160 = mul i64 %159, 4
  %buffer.contiguous.address67 = getelementptr i8, ptr %157, i64 %160
  %buffer.contiguous.load68 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address67, <8 x i1> %55, <8 x float> zeroinitializer)
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %163 = add <8 x i64> %162, splat (i64 64)
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = load { <8 x ptr>, <8 x i64> }, ptr %.spill23, align 64
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %166, 0
  %169 = select <8 x i1> %55, <8 x ptr> %167, <8 x ptr> %168
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %166, 1
  %172 = select <8 x i1> %55, <8 x i64> %170, <8 x i64> %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  store { <8 x ptr>, <8 x i64> } %174, ptr %.spill23, align 64
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %177 = extractelement <8 x ptr> %175, i32 0
  %178 = extractelement <8 x i64> %176, i32 0
  %179 = sub i64 %178, 0
  %180 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %181 = select i1 %180, i64 %179, i64 0
  %private.contiguous.address69 = getelementptr i8, ptr %177, i64 %181
  %private.contiguous.preserve70 = load <8 x float>, ptr %private.contiguous.address69, align 4
  %182 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load68, <8 x float> %private.contiguous.preserve70
  store <8 x float> %182, ptr %private.contiguous.address69, align 4
  %183 = load <8 x i64>, ptr %.spill24, align 64
  %184 = select <8 x i1> %55, <8 x i64> <i64 24, i64 25, i64 26, i64 27, i64 28, i64 29, i64 30, i64 31>, <8 x i64> %183
  store <8 x i64> %184, ptr %.spill24, align 64
  %185 = load <8 x i64>, ptr %.spill25, align 64
  %186 = select <8 x i1> %55, <8 x i64> <i64 24, i64 25, i64 26, i64 27, i64 28, i64 29, i64 30, i64 31>, <8 x i64> %185
  store <8 x i64> %186, ptr %.spill25, align 64
  %187 = add <8 x i64> %85, <i64 24, i64 25, i64 26, i64 27, i64 28, i64 29, i64 30, i64 31>
  %188 = load <8 x i64>, ptr %.spill26, align 64
  %189 = select <8 x i1> %55, <8 x i64> %187, <8 x i64> %188
  store <8 x i64> %189, ptr %.spill26, align 64
  %190 = extractvalue { ptr, i64 } %13, 0
  %191 = extractelement <8 x i64> %187, i32 0
  %192 = sub i64 %191, 0
  %193 = mul i64 %192, 4
  %buffer.contiguous.address71 = getelementptr i8, ptr %190, i64 %193
  %buffer.contiguous.load72 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address71, <8 x i1> %55, <8 x float> zeroinitializer)
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %195 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %196 = add <8 x i64> %195, splat (i64 96)
  %197 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %194, 0
  %198 = insertvalue { <8 x ptr>, <8 x i64> } %197, <8 x i64> %196, 1
  %199 = load { <8 x ptr>, <8 x i64> }, ptr %.spill27, align 64
  %200 = extractvalue { <8 x ptr>, <8 x i64> } %198, 0
  %201 = extractvalue { <8 x ptr>, <8 x i64> } %199, 0
  %202 = select <8 x i1> %55, <8 x ptr> %200, <8 x ptr> %201
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %198, 1
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %199, 1
  %205 = select <8 x i1> %55, <8 x i64> %203, <8 x i64> %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  store { <8 x ptr>, <8 x i64> } %207, ptr %.spill27, align 64
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %198, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address73 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.preserve74 = load <8 x float>, ptr %private.contiguous.address73, align 4
  %215 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load72, <8 x float> %private.contiguous.preserve74
  store <8 x float> %215, ptr %private.contiguous.address73, align 4
  %216 = load <8 x i1>, ptr %.spill28, align 1
  %217 = select <8 x i1> %55, <8 x i1> <i1 true, i1 false, i1 false, i1 false, i1 false, i1 false, i1 false, i1 false>, <8 x i1> %216
  store <8 x i1> %217, ptr %.spill28, align 1
  %218 = and <8 x i1> %55, <i1 true, i1 false, i1 false, i1 false, i1 false, i1 false, i1 false, i1 false>
  %219 = and <8 x i1> %55, <i1 false, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true, i1 true>
  %220 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %218)
  %221 = bitcast <8 x i1> %218 to i8
  %222 = call i8 @llvm.cttz.i8(i8 %221, i1 false)
  %223 = zext i8 %222 to i32
  %224 = select i1 %220, i32 %223, i32 0
  %225 = add <8 x i64> %85, <i64 32, i64 33, i64 34, i64 35, i64 36, i64 37, i64 38, i64 39>
  %226 = extractvalue { ptr, i64 } %13, 0
  %227 = select <8 x i1> %218, <8 x i64> %225, <8 x i64> zeroinitializer
  %228 = extractelement <8 x i64> %227, i32 %224
  %229 = zext i32 %224 to i64
  %230 = sub i64 %228, %229
  %231 = mul i64 %230, 4
  %buffer.contiguous.address75 = getelementptr i8, ptr %226, i64 %231
  %buffer.contiguous.load76 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address75, <8 x i1> %218, <8 x float> zeroinitializer)
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %233 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %234 = add <8 x i64> %233, splat (i64 128)
  %235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %232, 0
  %236 = insertvalue { <8 x ptr>, <8 x i64> } %235, <8 x i64> %234, 1
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %236, 1
  %239 = extractelement <8 x ptr> %237, i32 0
  %240 = extractelement <8 x i64> %238, i32 %224
  %241 = zext i32 %224 to i64
  %242 = mul i64 %241, 4
  %243 = sub i64 %240, %242
  %244 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %218)
  %245 = select i1 %244, i64 %243, i64 0
  %private.contiguous.address77 = getelementptr i8, ptr %239, i64 %245
  %private.contiguous.preserve78 = load <8 x float>, ptr %private.contiguous.address77, align 4
  %246 = select <8 x i1> %218, <8 x float> %buffer.contiguous.load76, <8 x float> %private.contiguous.preserve78
  store <8 x float> %246, ptr %private.contiguous.address77, align 4
  %247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %219)
  %248 = bitcast <8 x i1> %219 to i8
  %249 = call i8 @llvm.cttz.i8(i8 %248, i1 false)
  %250 = zext i8 %249 to i32
  %251 = select i1 %247, i32 %250, i32 0
  br label %direct.schedule.2

direct.schedule.2:                                ; preds = %direct.schedule.0
  %252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 0
  %255 = select <8 x i1> %55, <8 x ptr> %253, <8 x ptr> %254
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %258 = select <8 x i1> %55, <8 x i64> %256, <8 x i64> %257
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %255, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  store { <8 x ptr>, <8 x i64> } %260, ptr %tile_snapshot.spill29, align 64
  %.spill.load = load <8 x i64>, ptr %.spill10, align 64
  %261 = add <8 x i64> splat (i64 33), %.spill.load
  %.spill.load79 = load <8 x i64>, ptr %.spill13, align 64
  %262 = add <8 x i64> %.spill.load79, %261
  %263 = load <8 x i64>, ptr %.spill30, align 64
  %264 = select <8 x i1> %55, <8 x i64> %262, <8 x i64> %263
  store <8 x i64> %264, ptr %.spill30, align 64
  %265 = extractvalue { ptr, i64 } %13, 0
  %266 = extractelement <8 x i64> %262, i32 0
  %267 = sub i64 %266, 0
  %268 = mul i64 %267, 4
  %buffer.contiguous.address80 = getelementptr i8, ptr %265, i64 %268
  %buffer.contiguous.load81 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address80, <8 x i1> %55, <8 x float> zeroinitializer)
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %270 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %271 = add <8 x i64> %270, zeroinitializer
  %272 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %269, 0
  %273 = insertvalue { <8 x ptr>, <8 x i64> } %272, <8 x i64> %271, 1
  %274 = load { <8 x ptr>, <8 x i64> }, ptr %.spill31, align 64
  %275 = extractvalue { <8 x ptr>, <8 x i64> } %273, 0
  %276 = extractvalue { <8 x ptr>, <8 x i64> } %274, 0
  %277 = select <8 x i1> %55, <8 x ptr> %275, <8 x ptr> %276
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %273, 1
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %274, 1
  %280 = select <8 x i1> %55, <8 x i64> %278, <8 x i64> %279
  %281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %277, 0
  %282 = insertvalue { <8 x ptr>, <8 x i64> } %281, <8 x i64> %280, 1
  store { <8 x ptr>, <8 x i64> } %282, ptr %.spill31, align 64
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %273, 1
  %285 = extractelement <8 x ptr> %283, i32 0
  %286 = extractelement <8 x i64> %284, i32 0
  %287 = sub i64 %286, 0
  %288 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %289 = select i1 %288, i64 %287, i64 0
  %private.contiguous.address82 = getelementptr i8, ptr %285, i64 %289
  %private.contiguous.preserve83 = load <8 x float>, ptr %private.contiguous.address82, align 4
  %290 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load81, <8 x float> %private.contiguous.preserve83
  store <8 x float> %290, ptr %private.contiguous.address82, align 4
  %.spill.load84 = load <8 x i64>, ptr %.spill16, align 64
  %291 = add <8 x i64> splat (i64 33), %.spill.load84
  %.spill.load85 = load <8 x i64>, ptr %.spill13, align 64
  %292 = add <8 x i64> %.spill.load85, %291
  %293 = load <8 x i64>, ptr %.spill32, align 64
  %294 = select <8 x i1> %55, <8 x i64> %292, <8 x i64> %293
  store <8 x i64> %294, ptr %.spill32, align 64
  %295 = extractvalue { ptr, i64 } %13, 0
  %296 = extractelement <8 x i64> %292, i32 0
  %297 = sub i64 %296, 0
  %298 = mul i64 %297, 4
  %buffer.contiguous.address86 = getelementptr i8, ptr %295, i64 %298
  %buffer.contiguous.load87 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address86, <8 x i1> %55, <8 x float> zeroinitializer)
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %301 = add <8 x i64> %300, splat (i64 32)
  %302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %299, 0
  %303 = insertvalue { <8 x ptr>, <8 x i64> } %302, <8 x i64> %301, 1
  %304 = load { <8 x ptr>, <8 x i64> }, ptr %.spill33, align 64
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %303, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %304, 0
  %307 = select <8 x i1> %55, <8 x ptr> %305, <8 x ptr> %306
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %303, 1
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %304, 1
  %310 = select <8 x i1> %55, <8 x i64> %308, <8 x i64> %309
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %307, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  store { <8 x ptr>, <8 x i64> } %312, ptr %.spill33, align 64
  %313 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %303, 1
  %315 = extractelement <8 x ptr> %313, i32 0
  %316 = extractelement <8 x i64> %314, i32 0
  %317 = sub i64 %316, 0
  %318 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %319 = select i1 %318, i64 %317, i64 0
  %private.contiguous.address88 = getelementptr i8, ptr %315, i64 %319
  %private.contiguous.preserve89 = load <8 x float>, ptr %private.contiguous.address88, align 4
  %320 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load87, <8 x float> %private.contiguous.preserve89
  store <8 x float> %320, ptr %private.contiguous.address88, align 4
  %.spill.load90 = load <8 x i64>, ptr %.spill20, align 64
  %321 = add <8 x i64> splat (i64 33), %.spill.load90
  %.spill.load91 = load <8 x i64>, ptr %.spill13, align 64
  %322 = add <8 x i64> %.spill.load91, %321
  %323 = load <8 x i64>, ptr %.spill34, align 64
  %324 = select <8 x i1> %55, <8 x i64> %322, <8 x i64> %323
  store <8 x i64> %324, ptr %.spill34, align 64
  %325 = extractvalue { ptr, i64 } %13, 0
  %326 = extractelement <8 x i64> %322, i32 0
  %327 = sub i64 %326, 0
  %328 = mul i64 %327, 4
  %buffer.contiguous.address92 = getelementptr i8, ptr %325, i64 %328
  %buffer.contiguous.load93 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address92, <8 x i1> %55, <8 x float> zeroinitializer)
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %330 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %331 = add <8 x i64> %330, splat (i64 64)
  %332 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %329, 0
  %333 = insertvalue { <8 x ptr>, <8 x i64> } %332, <8 x i64> %331, 1
  %334 = load { <8 x ptr>, <8 x i64> }, ptr %.spill35, align 64
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %333, 0
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %334, 0
  %337 = select <8 x i1> %55, <8 x ptr> %335, <8 x ptr> %336
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %333, 1
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %334, 1
  %340 = select <8 x i1> %55, <8 x i64> %338, <8 x i64> %339
  %341 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %337, 0
  %342 = insertvalue { <8 x ptr>, <8 x i64> } %341, <8 x i64> %340, 1
  store { <8 x ptr>, <8 x i64> } %342, ptr %.spill35, align 64
  %343 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %344 = extractvalue { <8 x ptr>, <8 x i64> } %333, 1
  %345 = extractelement <8 x ptr> %343, i32 0
  %346 = extractelement <8 x i64> %344, i32 0
  %347 = sub i64 %346, 0
  %348 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %349 = select i1 %348, i64 %347, i64 0
  %private.contiguous.address94 = getelementptr i8, ptr %345, i64 %349
  %private.contiguous.preserve95 = load <8 x float>, ptr %private.contiguous.address94, align 4
  %350 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load93, <8 x float> %private.contiguous.preserve95
  store <8 x float> %350, ptr %private.contiguous.address94, align 4
  %.spill.load96 = load <8 x i64>, ptr %.spill24, align 64
  %351 = add <8 x i64> splat (i64 33), %.spill.load96
  %.spill.load97 = load <8 x i64>, ptr %.spill13, align 64
  %352 = add <8 x i64> %.spill.load97, %351
  %353 = load <8 x i64>, ptr %.spill36, align 64
  %354 = select <8 x i1> %55, <8 x i64> %352, <8 x i64> %353
  store <8 x i64> %354, ptr %.spill36, align 64
  %355 = extractvalue { ptr, i64 } %13, 0
  %356 = extractelement <8 x i64> %352, i32 0
  %357 = sub i64 %356, 0
  %358 = mul i64 %357, 4
  %buffer.contiguous.address98 = getelementptr i8, ptr %355, i64 %358
  %buffer.contiguous.load99 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address98, <8 x i1> %55, <8 x float> zeroinitializer)
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %361 = add <8 x i64> %360, splat (i64 96)
  %362 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %359, 0
  %363 = insertvalue { <8 x ptr>, <8 x i64> } %362, <8 x i64> %361, 1
  %364 = load { <8 x ptr>, <8 x i64> }, ptr %.spill37, align 64
  %365 = extractvalue { <8 x ptr>, <8 x i64> } %363, 0
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %364, 0
  %367 = select <8 x i1> %55, <8 x ptr> %365, <8 x ptr> %366
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %363, 1
  %369 = extractvalue { <8 x ptr>, <8 x i64> } %364, 1
  %370 = select <8 x i1> %55, <8 x i64> %368, <8 x i64> %369
  %371 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %367, 0
  %372 = insertvalue { <8 x ptr>, <8 x i64> } %371, <8 x i64> %370, 1
  store { <8 x ptr>, <8 x i64> } %372, ptr %.spill37, align 64
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %363, 1
  %375 = extractelement <8 x ptr> %373, i32 0
  %376 = extractelement <8 x i64> %374, i32 0
  %377 = sub i64 %376, 0
  %378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %379 = select i1 %378, i64 %377, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %375, i64 %379
  %private.contiguous.preserve101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %380 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load99, <8 x float> %private.contiguous.preserve101
  store <8 x float> %380, ptr %private.contiguous.address100, align 4
  %.spill.load102 = load <8 x i1>, ptr %.spill28, align 1
  %381 = and <8 x i1> %55, %.spill.load102
  %382 = xor <8 x i1> %.spill.load102, splat (i1 true)
  %383 = and <8 x i1> %55, %382
  %384 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %381)
  %385 = bitcast <8 x i1> %381 to i8
  %386 = call i8 @llvm.cttz.i8(i8 %385, i1 false)
  %387 = zext i8 %386 to i32
  %388 = select i1 %384, i32 %387, i32 0
  %.spill.load103 = load <8 x i64>, ptr %.spill, align 64
  %389 = add <8 x i64> splat (i64 32), %.spill.load103
  %390 = add <8 x i64> splat (i64 33), %389
  %.spill.load104 = load <8 x i64>, ptr %.spill13, align 64
  %391 = add <8 x i64> %.spill.load104, %390
  %392 = extractvalue { ptr, i64 } %13, 0
  %393 = select <8 x i1> %381, <8 x i64> %391, <8 x i64> zeroinitializer
  %394 = extractelement <8 x i64> %393, i32 %388
  %395 = zext i32 %388 to i64
  %396 = sub i64 %394, %395
  %397 = mul i64 %396, 4
  %buffer.contiguous.address105 = getelementptr i8, ptr %392, i64 %397
  %buffer.contiguous.load106 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address105, <8 x i1> %381, <8 x float> zeroinitializer)
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %400 = add <8 x i64> %399, splat (i64 128)
  %401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %398, 0
  %402 = insertvalue { <8 x ptr>, <8 x i64> } %401, <8 x i64> %400, 1
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %402, 1
  %405 = extractelement <8 x ptr> %403, i32 0
  %406 = extractelement <8 x i64> %404, i32 %388
  %407 = zext i32 %388 to i64
  %408 = mul i64 %407, 4
  %409 = sub i64 %406, %408
  %410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %381)
  %411 = select i1 %410, i64 %409, i64 0
  %private.contiguous.address107 = getelementptr i8, ptr %405, i64 %411
  %private.contiguous.preserve108 = load <8 x float>, ptr %private.contiguous.address107, align 4
  %412 = select <8 x i1> %381, <8 x float> %buffer.contiguous.load106, <8 x float> %private.contiguous.preserve108
  store <8 x float> %412, ptr %private.contiguous.address107, align 4
  %413 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %383)
  %414 = bitcast <8 x i1> %383 to i8
  %415 = call i8 @llvm.cttz.i8(i8 %414, i1 false)
  %416 = zext i8 %415 to i32
  %417 = select i1 %413, i32 %416, i32 0
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.2
  %418 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %419 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %418, 0
  %421 = select <8 x i1> %55, <8 x ptr> %419, <8 x ptr> %420
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %418, 1
  %424 = select <8 x i1> %55, <8 x i64> %422, <8 x i64> %423
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  store { <8 x ptr>, <8 x i64> } %426, ptr %tile_snapshot.spill38, align 64
  %.spill.load109 = load <8 x i64>, ptr %.spill11, align 64
  %427 = mul <8 x i64> %.spill.load109, splat (i64 33)
  %428 = load <8 x i64>, ptr %.spill39, align 64
  %429 = select <8 x i1> %55, <8 x i64> %427, <8 x i64> %428
  store <8 x i64> %429, ptr %.spill39, align 64
  %.spill.load110 = load <8 x i64>, ptr %.spill12, align 64
  %430 = add <8 x i64> %427, %.spill.load110
  %431 = load <8 x i64>, ptr %.spill40, align 64
  %432 = select <8 x i1> %55, <8 x i64> %430, <8 x i64> %431
  store <8 x i64> %432, ptr %.spill40, align 64
  %433 = extractvalue { ptr, i64 } %19, 0
  %434 = extractelement <8 x i64> %430, i32 0
  %435 = sub i64 %434, 0
  %436 = mul i64 %435, 4
  %buffer.contiguous.address111 = getelementptr i8, ptr %433, i64 %436
  %buffer.contiguous.load112 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address111, <8 x i1> %55, <8 x float> zeroinitializer)
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %438 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %439 = add <8 x i64> %438, zeroinitializer
  %440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %437, 0
  %441 = insertvalue { <8 x ptr>, <8 x i64> } %440, <8 x i64> %439, 1
  %442 = load { <8 x ptr>, <8 x i64> }, ptr %.spill41, align 64
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %441, 0
  %444 = extractvalue { <8 x ptr>, <8 x i64> } %442, 0
  %445 = select <8 x i1> %55, <8 x ptr> %443, <8 x ptr> %444
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %441, 1
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %442, 1
  %448 = select <8 x i1> %55, <8 x i64> %446, <8 x i64> %447
  %449 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %445, 0
  %450 = insertvalue { <8 x ptr>, <8 x i64> } %449, <8 x i64> %448, 1
  store { <8 x ptr>, <8 x i64> } %450, ptr %.spill41, align 64
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %441, 1
  %453 = extractelement <8 x ptr> %451, i32 0
  %454 = extractelement <8 x i64> %452, i32 0
  %455 = sub i64 %454, 0
  %456 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %457 = select i1 %456, i64 %455, i64 0
  %private.contiguous.address113 = getelementptr i8, ptr %453, i64 %457
  %private.contiguous.preserve114 = load <8 x float>, ptr %private.contiguous.address113, align 4
  %458 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load112, <8 x float> %private.contiguous.preserve114
  store <8 x float> %458, ptr %private.contiguous.address113, align 4
  %.spill.load115 = load <8 x i64>, ptr %.spill17, align 64
  %459 = add <8 x i64> %427, %.spill.load115
  %460 = load <8 x i64>, ptr %.spill42, align 64
  %461 = select <8 x i1> %55, <8 x i64> %459, <8 x i64> %460
  store <8 x i64> %461, ptr %.spill42, align 64
  %462 = extractvalue { ptr, i64 } %19, 0
  %463 = extractelement <8 x i64> %459, i32 0
  %464 = sub i64 %463, 0
  %465 = mul i64 %464, 4
  %buffer.contiguous.address116 = getelementptr i8, ptr %462, i64 %465
  %buffer.contiguous.load117 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address116, <8 x i1> %55, <8 x float> zeroinitializer)
  %466 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %468 = add <8 x i64> %467, splat (i64 32)
  %469 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %466, 0
  %470 = insertvalue { <8 x ptr>, <8 x i64> } %469, <8 x i64> %468, 1
  %471 = load { <8 x ptr>, <8 x i64> }, ptr %.spill43, align 64
  %472 = extractvalue { <8 x ptr>, <8 x i64> } %470, 0
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %471, 0
  %474 = select <8 x i1> %55, <8 x ptr> %472, <8 x ptr> %473
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %470, 1
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %471, 1
  %477 = select <8 x i1> %55, <8 x i64> %475, <8 x i64> %476
  %478 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %474, 0
  %479 = insertvalue { <8 x ptr>, <8 x i64> } %478, <8 x i64> %477, 1
  store { <8 x ptr>, <8 x i64> } %479, ptr %.spill43, align 64
  %480 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %470, 1
  %482 = extractelement <8 x ptr> %480, i32 0
  %483 = extractelement <8 x i64> %481, i32 0
  %484 = sub i64 %483, 0
  %485 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %486 = select i1 %485, i64 %484, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %482, i64 %486
  %private.contiguous.preserve119 = load <8 x float>, ptr %private.contiguous.address118, align 4
  %487 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load117, <8 x float> %private.contiguous.preserve119
  store <8 x float> %487, ptr %private.contiguous.address118, align 4
  %.spill.load120 = load <8 x i64>, ptr %.spill21, align 64
  %488 = add <8 x i64> %427, %.spill.load120
  %489 = load <8 x i64>, ptr %.spill44, align 64
  %490 = select <8 x i1> %55, <8 x i64> %488, <8 x i64> %489
  store <8 x i64> %490, ptr %.spill44, align 64
  %491 = extractvalue { ptr, i64 } %19, 0
  %492 = extractelement <8 x i64> %488, i32 0
  %493 = sub i64 %492, 0
  %494 = mul i64 %493, 4
  %buffer.contiguous.address121 = getelementptr i8, ptr %491, i64 %494
  %buffer.contiguous.load122 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address121, <8 x i1> %55, <8 x float> zeroinitializer)
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %496 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %497 = add <8 x i64> %496, splat (i64 64)
  %498 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %495, 0
  %499 = insertvalue { <8 x ptr>, <8 x i64> } %498, <8 x i64> %497, 1
  %500 = load { <8 x ptr>, <8 x i64> }, ptr %.spill45, align 64
  %501 = extractvalue { <8 x ptr>, <8 x i64> } %499, 0
  %502 = extractvalue { <8 x ptr>, <8 x i64> } %500, 0
  %503 = select <8 x i1> %55, <8 x ptr> %501, <8 x ptr> %502
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %499, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %500, 1
  %506 = select <8 x i1> %55, <8 x i64> %504, <8 x i64> %505
  %507 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %503, 0
  %508 = insertvalue { <8 x ptr>, <8 x i64> } %507, <8 x i64> %506, 1
  store { <8 x ptr>, <8 x i64> } %508, ptr %.spill45, align 64
  %509 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %499, 1
  %511 = extractelement <8 x ptr> %509, i32 0
  %512 = extractelement <8 x i64> %510, i32 0
  %513 = sub i64 %512, 0
  %514 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %515 = select i1 %514, i64 %513, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %511, i64 %515
  %private.contiguous.preserve124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %516 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load122, <8 x float> %private.contiguous.preserve124
  store <8 x float> %516, ptr %private.contiguous.address123, align 4
  %.spill.load125 = load <8 x i64>, ptr %.spill25, align 64
  %517 = add <8 x i64> %427, %.spill.load125
  %518 = load <8 x i64>, ptr %.spill46, align 64
  %519 = select <8 x i1> %55, <8 x i64> %517, <8 x i64> %518
  store <8 x i64> %519, ptr %.spill46, align 64
  %520 = extractvalue { ptr, i64 } %19, 0
  %521 = extractelement <8 x i64> %517, i32 0
  %522 = sub i64 %521, 0
  %523 = mul i64 %522, 4
  %buffer.contiguous.address126 = getelementptr i8, ptr %520, i64 %523
  %buffer.contiguous.load127 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address126, <8 x i1> %55, <8 x float> zeroinitializer)
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %526 = add <8 x i64> %525, splat (i64 96)
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %524, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = load { <8 x ptr>, <8 x i64> }, ptr %.spill47, align 64
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 0
  %531 = extractvalue { <8 x ptr>, <8 x i64> } %529, 0
  %532 = select <8 x i1> %55, <8 x ptr> %530, <8 x ptr> %531
  %533 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %529, 1
  %535 = select <8 x i1> %55, <8 x i64> %533, <8 x i64> %534
  %536 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %532, 0
  %537 = insertvalue { <8 x ptr>, <8 x i64> } %536, <8 x i64> %535, 1
  store { <8 x ptr>, <8 x i64> } %537, ptr %.spill47, align 64
  %538 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %539 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %540 = extractelement <8 x ptr> %538, i32 0
  %541 = extractelement <8 x i64> %539, i32 0
  %542 = sub i64 %541, 0
  %543 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %544 = select i1 %543, i64 %542, i64 0
  %private.contiguous.address128 = getelementptr i8, ptr %540, i64 %544
  %private.contiguous.preserve129 = load <8 x float>, ptr %private.contiguous.address128, align 4
  %545 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load127, <8 x float> %private.contiguous.preserve129
  store <8 x float> %545, ptr %private.contiguous.address128, align 4
  %.spill.load130 = load <8 x i1>, ptr %.spill28, align 1
  %546 = and <8 x i1> %55, %.spill.load130
  %547 = xor <8 x i1> %.spill.load130, splat (i1 true)
  %548 = and <8 x i1> %55, %547
  %549 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %546)
  %550 = bitcast <8 x i1> %546 to i8
  %551 = call i8 @llvm.cttz.i8(i8 %550, i1 false)
  %552 = zext i8 %551 to i32
  %553 = select i1 %549, i32 %552, i32 0
  %.spill.load131 = load <8 x i64>, ptr %.spill, align 64
  %554 = add <8 x i64> splat (i64 32), %.spill.load131
  %555 = add <8 x i64> zeroinitializer, %554
  %556 = add <8 x i64> %427, %555
  %557 = extractvalue { ptr, i64 } %19, 0
  %558 = select <8 x i1> %546, <8 x i64> %556, <8 x i64> zeroinitializer
  %559 = extractelement <8 x i64> %558, i32 %553
  %560 = zext i32 %553 to i64
  %561 = sub i64 %559, %560
  %562 = mul i64 %561, 4
  %buffer.contiguous.address132 = getelementptr i8, ptr %557, i64 %562
  %buffer.contiguous.load133 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address132, <8 x i1> %546, <8 x float> zeroinitializer)
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %565 = add <8 x i64> %564, splat (i64 128)
  %566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %563, 0
  %567 = insertvalue { <8 x ptr>, <8 x i64> } %566, <8 x i64> %565, 1
  %568 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %569 = extractvalue { <8 x ptr>, <8 x i64> } %567, 1
  %570 = extractelement <8 x ptr> %568, i32 0
  %571 = extractelement <8 x i64> %569, i32 %553
  %572 = zext i32 %553 to i64
  %573 = mul i64 %572, 4
  %574 = sub i64 %571, %573
  %575 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %546)
  %576 = select i1 %575, i64 %574, i64 0
  %private.contiguous.address134 = getelementptr i8, ptr %570, i64 %576
  %private.contiguous.preserve135 = load <8 x float>, ptr %private.contiguous.address134, align 4
  %577 = select <8 x i1> %546, <8 x float> %buffer.contiguous.load133, <8 x float> %private.contiguous.preserve135
  store <8 x float> %577, ptr %private.contiguous.address134, align 4
  %578 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %548)
  %579 = bitcast <8 x i1> %548 to i8
  %580 = call i8 @llvm.cttz.i8(i8 %579, i1 false)
  %581 = zext i8 %580 to i32
  %582 = select i1 %578, i32 %581, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.4
  %583 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill48, align 64
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %583, 0
  %586 = select <8 x i1> %55, <8 x ptr> %584, <8 x ptr> %585
  %587 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %583, 1
  %589 = select <8 x i1> %55, <8 x i64> %587, <8 x i64> %588
  %590 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %586, 0
  %591 = insertvalue { <8 x ptr>, <8 x i64> } %590, <8 x i64> %589, 1
  store { <8 x ptr>, <8 x i64> } %591, ptr %tile_snapshot.spill48, align 64
  %.spill.load136 = load <8 x i64>, ptr %.spill40, align 64
  %592 = extractvalue { ptr, i64 } %25, 0
  %593 = extractelement <8 x i64> %.spill.load136, i32 0
  %594 = sub i64 %593, 0
  %595 = mul i64 %594, 4
  %buffer.contiguous.address137 = getelementptr i8, ptr %592, i64 %595
  %buffer.contiguous.load138 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address137, <8 x i1> %55, <8 x float> zeroinitializer)
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %597 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %598 = add <8 x i64> %597, zeroinitializer
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %596, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = load { <8 x ptr>, <8 x i64> }, ptr %.spill49, align 64
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 0
  %603 = extractvalue { <8 x ptr>, <8 x i64> } %601, 0
  %604 = select <8 x i1> %55, <8 x ptr> %602, <8 x ptr> %603
  %605 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %606 = extractvalue { <8 x ptr>, <8 x i64> } %601, 1
  %607 = select <8 x i1> %55, <8 x i64> %605, <8 x i64> %606
  %608 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %604, 0
  %609 = insertvalue { <8 x ptr>, <8 x i64> } %608, <8 x i64> %607, 1
  store { <8 x ptr>, <8 x i64> } %609, ptr %.spill49, align 64
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %612 = extractelement <8 x ptr> %610, i32 0
  %613 = extractelement <8 x i64> %611, i32 0
  %614 = sub i64 %613, 0
  %615 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %616 = select i1 %615, i64 %614, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %612, i64 %616
  %private.contiguous.preserve140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %617 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load138, <8 x float> %private.contiguous.preserve140
  store <8 x float> %617, ptr %private.contiguous.address139, align 4
  %.spill.load141 = load <8 x i64>, ptr %.spill42, align 64
  %618 = extractvalue { ptr, i64 } %25, 0
  %619 = extractelement <8 x i64> %.spill.load141, i32 0
  %620 = sub i64 %619, 0
  %621 = mul i64 %620, 4
  %buffer.contiguous.address142 = getelementptr i8, ptr %618, i64 %621
  %buffer.contiguous.load143 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address142, <8 x i1> %55, <8 x float> zeroinitializer)
  %622 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %623 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %624 = add <8 x i64> %623, splat (i64 32)
  %625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %622, 0
  %626 = insertvalue { <8 x ptr>, <8 x i64> } %625, <8 x i64> %624, 1
  %627 = load { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 0
  %629 = extractvalue { <8 x ptr>, <8 x i64> } %627, 0
  %630 = select <8 x i1> %55, <8 x ptr> %628, <8 x ptr> %629
  %631 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %627, 1
  %633 = select <8 x i1> %55, <8 x i64> %631, <8 x i64> %632
  %634 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %630, 0
  %635 = insertvalue { <8 x ptr>, <8 x i64> } %634, <8 x i64> %633, 1
  store { <8 x ptr>, <8 x i64> } %635, ptr %.spill50, align 64
  %636 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %637 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %638 = extractelement <8 x ptr> %636, i32 0
  %639 = extractelement <8 x i64> %637, i32 0
  %640 = sub i64 %639, 0
  %641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %642 = select i1 %641, i64 %640, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %638, i64 %642
  %private.contiguous.preserve145 = load <8 x float>, ptr %private.contiguous.address144, align 4
  %643 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load143, <8 x float> %private.contiguous.preserve145
  store <8 x float> %643, ptr %private.contiguous.address144, align 4
  %.spill.load146 = load <8 x i64>, ptr %.spill44, align 64
  %644 = extractvalue { ptr, i64 } %25, 0
  %645 = extractelement <8 x i64> %.spill.load146, i32 0
  %646 = sub i64 %645, 0
  %647 = mul i64 %646, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %644, i64 %647
  %buffer.contiguous.load148 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address147, <8 x i1> %55, <8 x float> zeroinitializer)
  %648 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %650 = add <8 x i64> %649, splat (i64 64)
  %651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %648, 0
  %652 = insertvalue { <8 x ptr>, <8 x i64> } %651, <8 x i64> %650, 1
  %653 = load { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %654 = extractvalue { <8 x ptr>, <8 x i64> } %652, 0
  %655 = extractvalue { <8 x ptr>, <8 x i64> } %653, 0
  %656 = select <8 x i1> %55, <8 x ptr> %654, <8 x ptr> %655
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %652, 1
  %658 = extractvalue { <8 x ptr>, <8 x i64> } %653, 1
  %659 = select <8 x i1> %55, <8 x i64> %657, <8 x i64> %658
  %660 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %656, 0
  %661 = insertvalue { <8 x ptr>, <8 x i64> } %660, <8 x i64> %659, 1
  store { <8 x ptr>, <8 x i64> } %661, ptr %.spill51, align 64
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %652, 1
  %664 = extractelement <8 x ptr> %662, i32 0
  %665 = extractelement <8 x i64> %663, i32 0
  %666 = sub i64 %665, 0
  %667 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %668 = select i1 %667, i64 %666, i64 0
  %private.contiguous.address149 = getelementptr i8, ptr %664, i64 %668
  %private.contiguous.preserve150 = load <8 x float>, ptr %private.contiguous.address149, align 4
  %669 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load148, <8 x float> %private.contiguous.preserve150
  store <8 x float> %669, ptr %private.contiguous.address149, align 4
  %.spill.load151 = load <8 x i64>, ptr %.spill46, align 64
  %670 = extractvalue { ptr, i64 } %25, 0
  %671 = extractelement <8 x i64> %.spill.load151, i32 0
  %672 = sub i64 %671, 0
  %673 = mul i64 %672, 4
  %buffer.contiguous.address152 = getelementptr i8, ptr %670, i64 %673
  %buffer.contiguous.load153 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address152, <8 x i1> %55, <8 x float> zeroinitializer)
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %675 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %676 = add <8 x i64> %675, splat (i64 96)
  %677 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %674, 0
  %678 = insertvalue { <8 x ptr>, <8 x i64> } %677, <8 x i64> %676, 1
  %679 = load { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %678, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %679, 0
  %682 = select <8 x i1> %55, <8 x ptr> %680, <8 x ptr> %681
  %683 = extractvalue { <8 x ptr>, <8 x i64> } %678, 1
  %684 = extractvalue { <8 x ptr>, <8 x i64> } %679, 1
  %685 = select <8 x i1> %55, <8 x i64> %683, <8 x i64> %684
  %686 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %682, 0
  %687 = insertvalue { <8 x ptr>, <8 x i64> } %686, <8 x i64> %685, 1
  store { <8 x ptr>, <8 x i64> } %687, ptr %.spill52, align 64
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %689 = extractvalue { <8 x ptr>, <8 x i64> } %678, 1
  %690 = extractelement <8 x ptr> %688, i32 0
  %691 = extractelement <8 x i64> %689, i32 0
  %692 = sub i64 %691, 0
  %693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %694 = select i1 %693, i64 %692, i64 0
  %private.contiguous.address154 = getelementptr i8, ptr %690, i64 %694
  %private.contiguous.preserve155 = load <8 x float>, ptr %private.contiguous.address154, align 4
  %695 = select <8 x i1> %55, <8 x float> %buffer.contiguous.load153, <8 x float> %private.contiguous.preserve155
  store <8 x float> %695, ptr %private.contiguous.address154, align 4
  %.spill.load156 = load <8 x i1>, ptr %.spill28, align 1
  %696 = and <8 x i1> %55, %.spill.load156
  %697 = xor <8 x i1> %.spill.load156, splat (i1 true)
  %698 = and <8 x i1> %55, %697
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %696)
  %700 = bitcast <8 x i1> %696 to i8
  %701 = call i8 @llvm.cttz.i8(i8 %700, i1 false)
  %702 = zext i8 %701 to i32
  %703 = select i1 %699, i32 %702, i32 0
  %.spill.load157 = load <8 x i64>, ptr %.spill, align 64
  %704 = add <8 x i64> splat (i64 32), %.spill.load157
  %705 = add <8 x i64> zeroinitializer, %704
  %.spill.load158 = load <8 x i64>, ptr %.spill39, align 64
  %706 = add <8 x i64> %.spill.load158, %705
  %707 = extractvalue { ptr, i64 } %25, 0
  %708 = select <8 x i1> %696, <8 x i64> %706, <8 x i64> zeroinitializer
  %709 = extractelement <8 x i64> %708, i32 %703
  %710 = zext i32 %703 to i64
  %711 = sub i64 %709, %710
  %712 = mul i64 %711, 4
  %buffer.contiguous.address159 = getelementptr i8, ptr %707, i64 %712
  %buffer.contiguous.load160 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address159, <8 x i1> %696, <8 x float> zeroinitializer)
  %713 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %714 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %715 = add <8 x i64> %714, splat (i64 128)
  %716 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %713, 0
  %717 = insertvalue { <8 x ptr>, <8 x i64> } %716, <8 x i64> %715, 1
  %718 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %719 = extractvalue { <8 x ptr>, <8 x i64> } %717, 1
  %720 = extractelement <8 x ptr> %718, i32 0
  %721 = extractelement <8 x i64> %719, i32 %703
  %722 = zext i32 %703 to i64
  %723 = mul i64 %722, 4
  %724 = sub i64 %721, %723
  %725 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %696)
  %726 = select i1 %725, i64 %724, i64 0
  %private.contiguous.address161 = getelementptr i8, ptr %720, i64 %726
  %private.contiguous.preserve162 = load <8 x float>, ptr %private.contiguous.address161, align 4
  %727 = select <8 x i1> %696, <8 x float> %buffer.contiguous.load160, <8 x float> %private.contiguous.preserve162
  store <8 x float> %727, ptr %private.contiguous.address161, align 4
  %728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %698)
  %729 = bitcast <8 x i1> %698 to i8
  %730 = call i8 @llvm.cttz.i8(i8 %729, i1 false)
  %731 = zext i8 %730 to i32
  %732 = select i1 %728, i32 %731, i32 0
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.6
  %.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %.spill15, align 64
  %733 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %734 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load163, 1
  %735 = extractelement <8 x ptr> %733, i32 0
  %736 = extractelement <8 x i64> %734, i32 0
  %737 = sub i64 %736, 0
  %738 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %739 = select i1 %738, i64 %737, i64 0
  %private.contiguous.address164 = getelementptr i8, ptr %735, i64 %739
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address164, align 4
  %740 = select <8 x i1> %55, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %.spill.load165 = load { <8 x ptr>, <8 x i64> }, ptr %.spill41, align 64
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %742 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load165, 1
  %743 = extractelement <8 x ptr> %741, i32 0
  %744 = extractelement <8 x i64> %742, i32 0
  %745 = sub i64 %744, 0
  %746 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %747 = select i1 %746, i64 %745, i64 0
  %private.contiguous.address166 = getelementptr i8, ptr %743, i64 %747
  %private.contiguous.load167 = load <8 x float>, ptr %private.contiguous.address166, align 4
  %748 = select <8 x i1> %55, <8 x float> %private.contiguous.load167, <8 x float> zeroinitializer
  %749 = fmul <8 x float> %740, %748
  %.spill.load168 = load { <8 x ptr>, <8 x i64> }, ptr %.spill31, align 64
  %750 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %751 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load168, 1
  %752 = extractelement <8 x ptr> %750, i32 0
  %753 = extractelement <8 x i64> %751, i32 0
  %754 = sub i64 %753, 0
  %755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %756 = select i1 %755, i64 %754, i64 0
  %private.contiguous.address169 = getelementptr i8, ptr %752, i64 %756
  %private.contiguous.load170 = load <8 x float>, ptr %private.contiguous.address169, align 4
  %757 = select <8 x i1> %55, <8 x float> %private.contiguous.load170, <8 x float> zeroinitializer
  %.spill.load171 = load { <8 x ptr>, <8 x i64> }, ptr %.spill49, align 64
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load171, 1
  %760 = extractelement <8 x ptr> %758, i32 0
  %761 = extractelement <8 x i64> %759, i32 0
  %762 = sub i64 %761, 0
  %763 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %764 = select i1 %763, i64 %762, i64 0
  %private.contiguous.address172 = getelementptr i8, ptr %760, i64 %764
  %private.contiguous.load173 = load <8 x float>, ptr %private.contiguous.address172, align 4
  %765 = select <8 x i1> %55, <8 x float> %private.contiguous.load173, <8 x float> zeroinitializer
  %766 = fmul <8 x float> %757, %765
  %767 = fsub <8 x float> %749, %766
  %.spill.load174 = load <8 x i64>, ptr %.spill14, align 64
  %768 = extractvalue { ptr, i64 } %31, 0
  %769 = extractelement <8 x i64> %.spill.load174, i32 0
  %770 = sub i64 %769, 0
  %771 = mul i64 %770, 4
  %buffer.contiguous.address175 = getelementptr i8, ptr %768, i64 %771
  call void @llvm.masked.store.v8f32.p0(<8 x float> %767, ptr align 1 %buffer.contiguous.address175, <8 x i1> %55)
  %.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %.spill19, align 64
  %772 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %773 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load176, 1
  %774 = extractelement <8 x ptr> %772, i32 0
  %775 = extractelement <8 x i64> %773, i32 0
  %776 = sub i64 %775, 0
  %777 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %778 = select i1 %777, i64 %776, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %774, i64 %778
  %private.contiguous.load178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %779 = select <8 x i1> %55, <8 x float> %private.contiguous.load178, <8 x float> zeroinitializer
  %.spill.load179 = load { <8 x ptr>, <8 x i64> }, ptr %.spill43, align 64
  %780 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %781 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load179, 1
  %782 = extractelement <8 x ptr> %780, i32 0
  %783 = extractelement <8 x i64> %781, i32 0
  %784 = sub i64 %783, 0
  %785 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %786 = select i1 %785, i64 %784, i64 0
  %private.contiguous.address180 = getelementptr i8, ptr %782, i64 %786
  %private.contiguous.load181 = load <8 x float>, ptr %private.contiguous.address180, align 4
  %787 = select <8 x i1> %55, <8 x float> %private.contiguous.load181, <8 x float> zeroinitializer
  %788 = fmul <8 x float> %779, %787
  %.spill.load182 = load { <8 x ptr>, <8 x i64> }, ptr %.spill33, align 64
  %789 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %790 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load182, 1
  %791 = extractelement <8 x ptr> %789, i32 0
  %792 = extractelement <8 x i64> %790, i32 0
  %793 = sub i64 %792, 0
  %794 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %795 = select i1 %794, i64 %793, i64 0
  %private.contiguous.address183 = getelementptr i8, ptr %791, i64 %795
  %private.contiguous.load184 = load <8 x float>, ptr %private.contiguous.address183, align 4
  %796 = select <8 x i1> %55, <8 x float> %private.contiguous.load184, <8 x float> zeroinitializer
  %.spill.load185 = load { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %797 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %798 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load185, 1
  %799 = extractelement <8 x ptr> %797, i32 0
  %800 = extractelement <8 x i64> %798, i32 0
  %801 = sub i64 %800, 0
  %802 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %803 = select i1 %802, i64 %801, i64 0
  %private.contiguous.address186 = getelementptr i8, ptr %799, i64 %803
  %private.contiguous.load187 = load <8 x float>, ptr %private.contiguous.address186, align 4
  %804 = select <8 x i1> %55, <8 x float> %private.contiguous.load187, <8 x float> zeroinitializer
  %805 = fmul <8 x float> %796, %804
  %806 = fsub <8 x float> %788, %805
  %.spill.load188 = load <8 x i64>, ptr %.spill18, align 64
  %807 = extractvalue { ptr, i64 } %31, 0
  %808 = extractelement <8 x i64> %.spill.load188, i32 0
  %809 = sub i64 %808, 0
  %810 = mul i64 %809, 4
  %buffer.contiguous.address189 = getelementptr i8, ptr %807, i64 %810
  call void @llvm.masked.store.v8f32.p0(<8 x float> %806, ptr align 1 %buffer.contiguous.address189, <8 x i1> %55)
  %.spill.load190 = load { <8 x ptr>, <8 x i64> }, ptr %.spill23, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load190, 1
  %813 = extractelement <8 x ptr> %811, i32 0
  %814 = extractelement <8 x i64> %812, i32 0
  %815 = sub i64 %814, 0
  %816 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %817 = select i1 %816, i64 %815, i64 0
  %private.contiguous.address191 = getelementptr i8, ptr %813, i64 %817
  %private.contiguous.load192 = load <8 x float>, ptr %private.contiguous.address191, align 4
  %818 = select <8 x i1> %55, <8 x float> %private.contiguous.load192, <8 x float> zeroinitializer
  %.spill.load193 = load { <8 x ptr>, <8 x i64> }, ptr %.spill45, align 64
  %819 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %820 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load193, 1
  %821 = extractelement <8 x ptr> %819, i32 0
  %822 = extractelement <8 x i64> %820, i32 0
  %823 = sub i64 %822, 0
  %824 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %825 = select i1 %824, i64 %823, i64 0
  %private.contiguous.address194 = getelementptr i8, ptr %821, i64 %825
  %private.contiguous.load195 = load <8 x float>, ptr %private.contiguous.address194, align 4
  %826 = select <8 x i1> %55, <8 x float> %private.contiguous.load195, <8 x float> zeroinitializer
  %827 = fmul <8 x float> %818, %826
  %.spill.load196 = load { <8 x ptr>, <8 x i64> }, ptr %.spill35, align 64
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %829 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load196, 1
  %830 = extractelement <8 x ptr> %828, i32 0
  %831 = extractelement <8 x i64> %829, i32 0
  %832 = sub i64 %831, 0
  %833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %834 = select i1 %833, i64 %832, i64 0
  %private.contiguous.address197 = getelementptr i8, ptr %830, i64 %834
  %private.contiguous.load198 = load <8 x float>, ptr %private.contiguous.address197, align 4
  %835 = select <8 x i1> %55, <8 x float> %private.contiguous.load198, <8 x float> zeroinitializer
  %.spill.load199 = load { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %837 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load199, 1
  %838 = extractelement <8 x ptr> %836, i32 0
  %839 = extractelement <8 x i64> %837, i32 0
  %840 = sub i64 %839, 0
  %841 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %842 = select i1 %841, i64 %840, i64 0
  %private.contiguous.address200 = getelementptr i8, ptr %838, i64 %842
  %private.contiguous.load201 = load <8 x float>, ptr %private.contiguous.address200, align 4
  %843 = select <8 x i1> %55, <8 x float> %private.contiguous.load201, <8 x float> zeroinitializer
  %844 = fmul <8 x float> %835, %843
  %845 = fsub <8 x float> %827, %844
  %.spill.load202 = load <8 x i64>, ptr %.spill22, align 64
  %846 = extractvalue { ptr, i64 } %31, 0
  %847 = extractelement <8 x i64> %.spill.load202, i32 0
  %848 = sub i64 %847, 0
  %849 = mul i64 %848, 4
  %buffer.contiguous.address203 = getelementptr i8, ptr %846, i64 %849
  call void @llvm.masked.store.v8f32.p0(<8 x float> %845, ptr align 1 %buffer.contiguous.address203, <8 x i1> %55)
  %.spill.load204 = load { <8 x ptr>, <8 x i64> }, ptr %.spill27, align 64
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %851 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load204, 1
  %852 = extractelement <8 x ptr> %850, i32 0
  %853 = extractelement <8 x i64> %851, i32 0
  %854 = sub i64 %853, 0
  %855 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %856 = select i1 %855, i64 %854, i64 0
  %private.contiguous.address205 = getelementptr i8, ptr %852, i64 %856
  %private.contiguous.load206 = load <8 x float>, ptr %private.contiguous.address205, align 4
  %857 = select <8 x i1> %55, <8 x float> %private.contiguous.load206, <8 x float> zeroinitializer
  %.spill.load207 = load { <8 x ptr>, <8 x i64> }, ptr %.spill47, align 64
  %858 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load207, 1
  %860 = extractelement <8 x ptr> %858, i32 0
  %861 = extractelement <8 x i64> %859, i32 0
  %862 = sub i64 %861, 0
  %863 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %864 = select i1 %863, i64 %862, i64 0
  %private.contiguous.address208 = getelementptr i8, ptr %860, i64 %864
  %private.contiguous.load209 = load <8 x float>, ptr %private.contiguous.address208, align 4
  %865 = select <8 x i1> %55, <8 x float> %private.contiguous.load209, <8 x float> zeroinitializer
  %866 = fmul <8 x float> %857, %865
  %.spill.load210 = load { <8 x ptr>, <8 x i64> }, ptr %.spill37, align 64
  %867 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %868 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load210, 1
  %869 = extractelement <8 x ptr> %867, i32 0
  %870 = extractelement <8 x i64> %868, i32 0
  %871 = sub i64 %870, 0
  %872 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %873 = select i1 %872, i64 %871, i64 0
  %private.contiguous.address211 = getelementptr i8, ptr %869, i64 %873
  %private.contiguous.load212 = load <8 x float>, ptr %private.contiguous.address211, align 4
  %874 = select <8 x i1> %55, <8 x float> %private.contiguous.load212, <8 x float> zeroinitializer
  %.spill.load213 = load { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %875 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %876 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load213, 1
  %877 = extractelement <8 x ptr> %875, i32 0
  %878 = extractelement <8 x i64> %876, i32 0
  %879 = sub i64 %878, 0
  %880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %881 = select i1 %880, i64 %879, i64 0
  %private.contiguous.address214 = getelementptr i8, ptr %877, i64 %881
  %private.contiguous.load215 = load <8 x float>, ptr %private.contiguous.address214, align 4
  %882 = select <8 x i1> %55, <8 x float> %private.contiguous.load215, <8 x float> zeroinitializer
  %883 = fmul <8 x float> %874, %882
  %884 = fsub <8 x float> %866, %883
  %.spill.load216 = load <8 x i64>, ptr %.spill26, align 64
  %885 = extractvalue { ptr, i64 } %31, 0
  %886 = extractelement <8 x i64> %.spill.load216, i32 0
  %887 = sub i64 %886, 0
  %888 = mul i64 %887, 4
  %buffer.contiguous.address217 = getelementptr i8, ptr %885, i64 %888
  call void @llvm.masked.store.v8f32.p0(<8 x float> %884, ptr align 1 %buffer.contiguous.address217, <8 x i1> %55)
  %.spill.load218 = load <8 x i1>, ptr %.spill28, align 1
  %889 = and <8 x i1> %55, %.spill.load218
  %890 = xor <8 x i1> %.spill.load218, splat (i1 true)
  %891 = and <8 x i1> %55, %890
  %892 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %889)
  %893 = bitcast <8 x i1> %889 to i8
  %894 = call i8 @llvm.cttz.i8(i8 %893, i1 false)
  %895 = zext i8 %894 to i32
  %896 = select i1 %892, i32 %895, i32 0
  %.spill.load219 = load <8 x i64>, ptr %.spill, align 64
  %897 = add <8 x i64> splat (i64 32), %.spill.load219
  %898 = add <8 x i64> zeroinitializer, %897
  %.spill.load220 = load <8 x i64>, ptr %.spill13, align 64
  %899 = add <8 x i64> %.spill.load220, %898
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %901 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %902 = add <8 x i64> %901, splat (i64 128)
  %903 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %900, 0
  %904 = insertvalue { <8 x ptr>, <8 x i64> } %903, <8 x i64> %902, 1
  %905 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %906 = extractvalue { <8 x ptr>, <8 x i64> } %904, 1
  %907 = extractelement <8 x ptr> %905, i32 0
  %908 = extractelement <8 x i64> %906, i32 %896
  %909 = zext i32 %896 to i64
  %910 = mul i64 %909, 4
  %911 = sub i64 %908, %910
  %912 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %889)
  %913 = select i1 %912, i64 %911, i64 0
  %private.contiguous.address221 = getelementptr i8, ptr %907, i64 %913
  %private.contiguous.load222 = load <8 x float>, ptr %private.contiguous.address221, align 4
  %914 = select <8 x i1> %889, <8 x float> %private.contiguous.load222, <8 x float> zeroinitializer
  %tile_snapshot.spill.load223 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 0
  %916 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load223, 1
  %917 = add <8 x i64> %916, splat (i64 128)
  %918 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %915, 0
  %919 = insertvalue { <8 x ptr>, <8 x i64> } %918, <8 x i64> %917, 1
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %919, 1
  %922 = extractelement <8 x ptr> %920, i32 0
  %923 = extractelement <8 x i64> %921, i32 %896
  %924 = zext i32 %896 to i64
  %925 = mul i64 %924, 4
  %926 = sub i64 %923, %925
  %927 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %889)
  %928 = select i1 %927, i64 %926, i64 0
  %private.contiguous.address224 = getelementptr i8, ptr %922, i64 %928
  %private.contiguous.load225 = load <8 x float>, ptr %private.contiguous.address224, align 4
  %929 = select <8 x i1> %889, <8 x float> %private.contiguous.load225, <8 x float> zeroinitializer
  %930 = fmul <8 x float> %914, %929
  %tile_snapshot.spill.load226 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 0
  %932 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load226, 1
  %933 = add <8 x i64> %932, splat (i64 128)
  %934 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %931, 0
  %935 = insertvalue { <8 x ptr>, <8 x i64> } %934, <8 x i64> %933, 1
  %936 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %935, 1
  %938 = extractelement <8 x ptr> %936, i32 0
  %939 = extractelement <8 x i64> %937, i32 %896
  %940 = zext i32 %896 to i64
  %941 = mul i64 %940, 4
  %942 = sub i64 %939, %941
  %943 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %889)
  %944 = select i1 %943, i64 %942, i64 0
  %private.contiguous.address227 = getelementptr i8, ptr %938, i64 %944
  %private.contiguous.load228 = load <8 x float>, ptr %private.contiguous.address227, align 4
  %945 = select <8 x i1> %889, <8 x float> %private.contiguous.load228, <8 x float> zeroinitializer
  %tile_snapshot.spill.load229 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill48, align 64
  %946 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 0
  %947 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load229, 1
  %948 = add <8 x i64> %947, splat (i64 128)
  %949 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %946, 0
  %950 = insertvalue { <8 x ptr>, <8 x i64> } %949, <8 x i64> %948, 1
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %952 = extractvalue { <8 x ptr>, <8 x i64> } %950, 1
  %953 = extractelement <8 x ptr> %951, i32 0
  %954 = extractelement <8 x i64> %952, i32 %896
  %955 = zext i32 %896 to i64
  %956 = mul i64 %955, 4
  %957 = sub i64 %954, %956
  %958 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %889)
  %959 = select i1 %958, i64 %957, i64 0
  %private.contiguous.address230 = getelementptr i8, ptr %953, i64 %959
  %private.contiguous.load231 = load <8 x float>, ptr %private.contiguous.address230, align 4
  %960 = select <8 x i1> %889, <8 x float> %private.contiguous.load231, <8 x float> zeroinitializer
  %961 = fmul <8 x float> %945, %960
  %962 = fsub <8 x float> %930, %961
  %963 = extractvalue { ptr, i64 } %31, 0
  %964 = extractelement <8 x i64> %899, i32 %896
  %965 = zext i32 %896 to i64
  %966 = sub i64 %964, %965
  %967 = mul i64 %966, 4
  %buffer.contiguous.address232 = getelementptr i8, ptr %963, i64 %967
  call void @llvm.masked.store.v8f32.p0(<8 x float> %962, ptr align 1 %buffer.contiguous.address232, <8 x i1> %889)
  %968 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %891)
  %969 = bitcast <8 x i1> %891 to i8
  %970 = call i8 @llvm.cttz.i8(i8 %969, i1 false)
  %971 = zext i8 %970 to i32
  %972 = select i1 %968, i32 %971, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.spill.load233 = load { <8 x ptr>, <8 x i64> }, ptr %.spill15, align 64
  %973 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %974 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load233, 1
  %975 = extractelement <8 x ptr> %973, i32 0
  %976 = extractelement <8 x i64> %974, i32 0
  %977 = sub i64 %976, 0
  %978 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %979 = select i1 %978, i64 %977, i64 0
  %private.contiguous.address234 = getelementptr i8, ptr %975, i64 %979
  %private.contiguous.load235 = load <8 x float>, ptr %private.contiguous.address234, align 4
  %980 = select <8 x i1> %55, <8 x float> %private.contiguous.load235, <8 x float> zeroinitializer
  %.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %.spill49, align 64
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load236, 1
  %983 = extractelement <8 x ptr> %981, i32 0
  %984 = extractelement <8 x i64> %982, i32 0
  %985 = sub i64 %984, 0
  %986 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %987 = select i1 %986, i64 %985, i64 0
  %private.contiguous.address237 = getelementptr i8, ptr %983, i64 %987
  %private.contiguous.load238 = load <8 x float>, ptr %private.contiguous.address237, align 4
  %988 = select <8 x i1> %55, <8 x float> %private.contiguous.load238, <8 x float> zeroinitializer
  %989 = fmul <8 x float> %980, %988
  %.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %.spill31, align 64
  %990 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %991 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load239, 1
  %992 = extractelement <8 x ptr> %990, i32 0
  %993 = extractelement <8 x i64> %991, i32 0
  %994 = sub i64 %993, 0
  %995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %996 = select i1 %995, i64 %994, i64 0
  %private.contiguous.address240 = getelementptr i8, ptr %992, i64 %996
  %private.contiguous.load241 = load <8 x float>, ptr %private.contiguous.address240, align 4
  %997 = select <8 x i1> %55, <8 x float> %private.contiguous.load241, <8 x float> zeroinitializer
  %.spill.load242 = load { <8 x ptr>, <8 x i64> }, ptr %.spill41, align 64
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load242, 1
  %1000 = extractelement <8 x ptr> %998, i32 0
  %1001 = extractelement <8 x i64> %999, i32 0
  %1002 = sub i64 %1001, 0
  %1003 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1004 = select i1 %1003, i64 %1002, i64 0
  %private.contiguous.address243 = getelementptr i8, ptr %1000, i64 %1004
  %private.contiguous.load244 = load <8 x float>, ptr %private.contiguous.address243, align 4
  %1005 = select <8 x i1> %55, <8 x float> %private.contiguous.load244, <8 x float> zeroinitializer
  %1006 = fmul <8 x float> %997, %1005
  %1007 = fadd <8 x float> %989, %1006
  %.spill.load245 = load <8 x i64>, ptr %.spill30, align 64
  %1008 = extractvalue { ptr, i64 } %31, 0
  %1009 = extractelement <8 x i64> %.spill.load245, i32 0
  %1010 = sub i64 %1009, 0
  %1011 = mul i64 %1010, 4
  %buffer.contiguous.address246 = getelementptr i8, ptr %1008, i64 %1011
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1007, ptr align 1 %buffer.contiguous.address246, <8 x i1> %55)
  %.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %.spill19, align 64
  %1012 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1013 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load247, 1
  %1014 = extractelement <8 x ptr> %1012, i32 0
  %1015 = extractelement <8 x i64> %1013, i32 0
  %1016 = sub i64 %1015, 0
  %1017 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1018 = select i1 %1017, i64 %1016, i64 0
  %private.contiguous.address248 = getelementptr i8, ptr %1014, i64 %1018
  %private.contiguous.load249 = load <8 x float>, ptr %private.contiguous.address248, align 4
  %1019 = select <8 x i1> %55, <8 x float> %private.contiguous.load249, <8 x float> zeroinitializer
  %.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %.spill50, align 64
  %1020 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1021 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load250, 1
  %1022 = extractelement <8 x ptr> %1020, i32 0
  %1023 = extractelement <8 x i64> %1021, i32 0
  %1024 = sub i64 %1023, 0
  %1025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1026 = select i1 %1025, i64 %1024, i64 0
  %private.contiguous.address251 = getelementptr i8, ptr %1022, i64 %1026
  %private.contiguous.load252 = load <8 x float>, ptr %private.contiguous.address251, align 4
  %1027 = select <8 x i1> %55, <8 x float> %private.contiguous.load252, <8 x float> zeroinitializer
  %1028 = fmul <8 x float> %1019, %1027
  %.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %.spill33, align 64
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1030 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load253, 1
  %1031 = extractelement <8 x ptr> %1029, i32 0
  %1032 = extractelement <8 x i64> %1030, i32 0
  %1033 = sub i64 %1032, 0
  %1034 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1035 = select i1 %1034, i64 %1033, i64 0
  %private.contiguous.address254 = getelementptr i8, ptr %1031, i64 %1035
  %private.contiguous.load255 = load <8 x float>, ptr %private.contiguous.address254, align 4
  %1036 = select <8 x i1> %55, <8 x float> %private.contiguous.load255, <8 x float> zeroinitializer
  %.spill.load256 = load { <8 x ptr>, <8 x i64> }, ptr %.spill43, align 64
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load256, 1
  %1039 = extractelement <8 x ptr> %1037, i32 0
  %1040 = extractelement <8 x i64> %1038, i32 0
  %1041 = sub i64 %1040, 0
  %1042 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1043 = select i1 %1042, i64 %1041, i64 0
  %private.contiguous.address257 = getelementptr i8, ptr %1039, i64 %1043
  %private.contiguous.load258 = load <8 x float>, ptr %private.contiguous.address257, align 4
  %1044 = select <8 x i1> %55, <8 x float> %private.contiguous.load258, <8 x float> zeroinitializer
  %1045 = fmul <8 x float> %1036, %1044
  %1046 = fadd <8 x float> %1028, %1045
  %.spill.load259 = load <8 x i64>, ptr %.spill32, align 64
  %1047 = extractvalue { ptr, i64 } %31, 0
  %1048 = extractelement <8 x i64> %.spill.load259, i32 0
  %1049 = sub i64 %1048, 0
  %1050 = mul i64 %1049, 4
  %buffer.contiguous.address260 = getelementptr i8, ptr %1047, i64 %1050
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1046, ptr align 1 %buffer.contiguous.address260, <8 x i1> %55)
  %.spill.load261 = load { <8 x ptr>, <8 x i64> }, ptr %.spill23, align 64
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1052 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load261, 1
  %1053 = extractelement <8 x ptr> %1051, i32 0
  %1054 = extractelement <8 x i64> %1052, i32 0
  %1055 = sub i64 %1054, 0
  %1056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1057 = select i1 %1056, i64 %1055, i64 0
  %private.contiguous.address262 = getelementptr i8, ptr %1053, i64 %1057
  %private.contiguous.load263 = load <8 x float>, ptr %private.contiguous.address262, align 4
  %1058 = select <8 x i1> %55, <8 x float> %private.contiguous.load263, <8 x float> zeroinitializer
  %.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %.spill51, align 64
  %1059 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1060 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load264, 1
  %1061 = extractelement <8 x ptr> %1059, i32 0
  %1062 = extractelement <8 x i64> %1060, i32 0
  %1063 = sub i64 %1062, 0
  %1064 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1065 = select i1 %1064, i64 %1063, i64 0
  %private.contiguous.address265 = getelementptr i8, ptr %1061, i64 %1065
  %private.contiguous.load266 = load <8 x float>, ptr %private.contiguous.address265, align 4
  %1066 = select <8 x i1> %55, <8 x float> %private.contiguous.load266, <8 x float> zeroinitializer
  %1067 = fmul <8 x float> %1058, %1066
  %.spill.load267 = load { <8 x ptr>, <8 x i64> }, ptr %.spill35, align 64
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load267, 1
  %1070 = extractelement <8 x ptr> %1068, i32 0
  %1071 = extractelement <8 x i64> %1069, i32 0
  %1072 = sub i64 %1071, 0
  %1073 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1074 = select i1 %1073, i64 %1072, i64 0
  %private.contiguous.address268 = getelementptr i8, ptr %1070, i64 %1074
  %private.contiguous.load269 = load <8 x float>, ptr %private.contiguous.address268, align 4
  %1075 = select <8 x i1> %55, <8 x float> %private.contiguous.load269, <8 x float> zeroinitializer
  %.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %.spill45, align 64
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1077 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load270, 1
  %1078 = extractelement <8 x ptr> %1076, i32 0
  %1079 = extractelement <8 x i64> %1077, i32 0
  %1080 = sub i64 %1079, 0
  %1081 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1082 = select i1 %1081, i64 %1080, i64 0
  %private.contiguous.address271 = getelementptr i8, ptr %1078, i64 %1082
  %private.contiguous.load272 = load <8 x float>, ptr %private.contiguous.address271, align 4
  %1083 = select <8 x i1> %55, <8 x float> %private.contiguous.load272, <8 x float> zeroinitializer
  %1084 = fmul <8 x float> %1075, %1083
  %1085 = fadd <8 x float> %1067, %1084
  %.spill.load273 = load <8 x i64>, ptr %.spill34, align 64
  %1086 = extractvalue { ptr, i64 } %31, 0
  %1087 = extractelement <8 x i64> %.spill.load273, i32 0
  %1088 = sub i64 %1087, 0
  %1089 = mul i64 %1088, 4
  %buffer.contiguous.address274 = getelementptr i8, ptr %1086, i64 %1089
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1085, ptr align 1 %buffer.contiguous.address274, <8 x i1> %55)
  %.spill.load275 = load { <8 x ptr>, <8 x i64> }, ptr %.spill27, align 64
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1091 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load275, 1
  %1092 = extractelement <8 x ptr> %1090, i32 0
  %1093 = extractelement <8 x i64> %1091, i32 0
  %1094 = sub i64 %1093, 0
  %1095 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1096 = select i1 %1095, i64 %1094, i64 0
  %private.contiguous.address276 = getelementptr i8, ptr %1092, i64 %1096
  %private.contiguous.load277 = load <8 x float>, ptr %private.contiguous.address276, align 4
  %1097 = select <8 x i1> %55, <8 x float> %private.contiguous.load277, <8 x float> zeroinitializer
  %.spill.load278 = load { <8 x ptr>, <8 x i64> }, ptr %.spill52, align 64
  %1098 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1099 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load278, 1
  %1100 = extractelement <8 x ptr> %1098, i32 0
  %1101 = extractelement <8 x i64> %1099, i32 0
  %1102 = sub i64 %1101, 0
  %1103 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1104 = select i1 %1103, i64 %1102, i64 0
  %private.contiguous.address279 = getelementptr i8, ptr %1100, i64 %1104
  %private.contiguous.load280 = load <8 x float>, ptr %private.contiguous.address279, align 4
  %1105 = select <8 x i1> %55, <8 x float> %private.contiguous.load280, <8 x float> zeroinitializer
  %1106 = fmul <8 x float> %1097, %1105
  %.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %.spill37, align 64
  %1107 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1108 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load281, 1
  %1109 = extractelement <8 x ptr> %1107, i32 0
  %1110 = extractelement <8 x i64> %1108, i32 0
  %1111 = sub i64 %1110, 0
  %1112 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1113 = select i1 %1112, i64 %1111, i64 0
  %private.contiguous.address282 = getelementptr i8, ptr %1109, i64 %1113
  %private.contiguous.load283 = load <8 x float>, ptr %private.contiguous.address282, align 4
  %1114 = select <8 x i1> %55, <8 x float> %private.contiguous.load283, <8 x float> zeroinitializer
  %.spill.load284 = load { <8 x ptr>, <8 x i64> }, ptr %.spill47, align 64
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1116 = extractvalue { <8 x ptr>, <8 x i64> } %.spill.load284, 1
  %1117 = extractelement <8 x ptr> %1115, i32 0
  %1118 = extractelement <8 x i64> %1116, i32 0
  %1119 = sub i64 %1118, 0
  %1120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %55)
  %1121 = select i1 %1120, i64 %1119, i64 0
  %private.contiguous.address285 = getelementptr i8, ptr %1117, i64 %1121
  %private.contiguous.load286 = load <8 x float>, ptr %private.contiguous.address285, align 4
  %1122 = select <8 x i1> %55, <8 x float> %private.contiguous.load286, <8 x float> zeroinitializer
  %1123 = fmul <8 x float> %1114, %1122
  %1124 = fadd <8 x float> %1106, %1123
  %.spill.load287 = load <8 x i64>, ptr %.spill36, align 64
  %1125 = extractvalue { ptr, i64 } %31, 0
  %1126 = extractelement <8 x i64> %.spill.load287, i32 0
  %1127 = sub i64 %1126, 0
  %1128 = mul i64 %1127, 4
  %buffer.contiguous.address288 = getelementptr i8, ptr %1125, i64 %1128
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1124, ptr align 1 %buffer.contiguous.address288, <8 x i1> %55)
  %.spill.load289 = load <8 x i1>, ptr %.spill28, align 1
  %1129 = and <8 x i1> %55, %.spill.load289
  %1130 = xor <8 x i1> %.spill.load289, splat (i1 true)
  %1131 = and <8 x i1> %55, %1130
  %1132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1129)
  %1133 = bitcast <8 x i1> %1129 to i8
  %1134 = call i8 @llvm.cttz.i8(i8 %1133, i1 false)
  %1135 = zext i8 %1134 to i32
  %1136 = select i1 %1132, i32 %1135, i32 0
  %.spill.load290 = load <8 x i64>, ptr %.spill, align 64
  %1137 = add <8 x i64> splat (i64 32), %.spill.load290
  %1138 = add <8 x i64> splat (i64 33), %1137
  %.spill.load291 = load <8 x i64>, ptr %.spill13, align 64
  %1139 = add <8 x i64> %.spill.load291, %1138
  %tile_snapshot.spill.load292 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 0
  %1141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 1
  %1142 = add <8 x i64> %1141, splat (i64 128)
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1140, 0
  %1144 = insertvalue { <8 x ptr>, <8 x i64> } %1143, <8 x i64> %1142, 1
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %1146 = extractvalue { <8 x ptr>, <8 x i64> } %1144, 1
  %1147 = extractelement <8 x ptr> %1145, i32 0
  %1148 = extractelement <8 x i64> %1146, i32 %1136
  %1149 = zext i32 %1136 to i64
  %1150 = mul i64 %1149, 4
  %1151 = sub i64 %1148, %1150
  %1152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1129)
  %1153 = select i1 %1152, i64 %1151, i64 0
  %private.contiguous.address293 = getelementptr i8, ptr %1147, i64 %1153
  %private.contiguous.load294 = load <8 x float>, ptr %private.contiguous.address293, align 4
  %1154 = select <8 x i1> %1129, <8 x float> %private.contiguous.load294, <8 x float> zeroinitializer
  %tile_snapshot.spill.load295 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill48, align 64
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load295, 0
  %1156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load295, 1
  %1157 = add <8 x i64> %1156, splat (i64 128)
  %1158 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1155, 0
  %1159 = insertvalue { <8 x ptr>, <8 x i64> } %1158, <8 x i64> %1157, 1
  %1160 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1161 = extractvalue { <8 x ptr>, <8 x i64> } %1159, 1
  %1162 = extractelement <8 x ptr> %1160, i32 0
  %1163 = extractelement <8 x i64> %1161, i32 %1136
  %1164 = zext i32 %1136 to i64
  %1165 = mul i64 %1164, 4
  %1166 = sub i64 %1163, %1165
  %1167 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1129)
  %1168 = select i1 %1167, i64 %1166, i64 0
  %private.contiguous.address296 = getelementptr i8, ptr %1162, i64 %1168
  %private.contiguous.load297 = load <8 x float>, ptr %private.contiguous.address296, align 4
  %1169 = select <8 x i1> %1129, <8 x float> %private.contiguous.load297, <8 x float> zeroinitializer
  %1170 = fmul <8 x float> %1154, %1169
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill29, align 64
  %1171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %1173 = add <8 x i64> %1172, splat (i64 128)
  %1174 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1171, 0
  %1175 = insertvalue { <8 x ptr>, <8 x i64> } %1174, <8 x i64> %1173, 1
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %1175, 1
  %1178 = extractelement <8 x ptr> %1176, i32 0
  %1179 = extractelement <8 x i64> %1177, i32 %1136
  %1180 = zext i32 %1136 to i64
  %1181 = mul i64 %1180, 4
  %1182 = sub i64 %1179, %1181
  %1183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1129)
  %1184 = select i1 %1183, i64 %1182, i64 0
  %private.contiguous.address299 = getelementptr i8, ptr %1178, i64 %1184
  %private.contiguous.load300 = load <8 x float>, ptr %private.contiguous.address299, align 4
  %1185 = select <8 x i1> %1129, <8 x float> %private.contiguous.load300, <8 x float> zeroinitializer
  %tile_snapshot.spill.load301 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill38, align 64
  %1186 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load301, 0
  %1187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load301, 1
  %1188 = add <8 x i64> %1187, splat (i64 128)
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1186, 0
  %1190 = insertvalue { <8 x ptr>, <8 x i64> } %1189, <8 x i64> %1188, 1
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %1190, 1
  %1193 = extractelement <8 x ptr> %1191, i32 0
  %1194 = extractelement <8 x i64> %1192, i32 %1136
  %1195 = zext i32 %1136 to i64
  %1196 = mul i64 %1195, 4
  %1197 = sub i64 %1194, %1196
  %1198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1129)
  %1199 = select i1 %1198, i64 %1197, i64 0
  %private.contiguous.address302 = getelementptr i8, ptr %1193, i64 %1199
  %private.contiguous.load303 = load <8 x float>, ptr %private.contiguous.address302, align 4
  %1200 = select <8 x i1> %1129, <8 x float> %private.contiguous.load303, <8 x float> zeroinitializer
  %1201 = fmul <8 x float> %1185, %1200
  %1202 = fadd <8 x float> %1170, %1201
  %1203 = extractvalue { ptr, i64 } %31, 0
  %1204 = extractelement <8 x i64> %1139, i32 %1136
  %1205 = zext i32 %1136 to i64
  %1206 = sub i64 %1204, %1205
  %1207 = mul i64 %1206, 4
  %buffer.contiguous.address304 = getelementptr i8, ptr %1203, i64 %1207
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1202, ptr align 1 %buffer.contiguous.address304, <8 x i1> %1129)
  %1208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1131)
  %1209 = bitcast <8 x i1> %1131 to i8
  %1210 = call i8 @llvm.cttz.i8(i8 %1209, i1 false)
  %1211 = zext i8 %1210 to i32
  %1212 = select i1 %1208, i32 %1211, i32 0
  br label %direct.schedule.12

direct.schedule.12:                               ; preds = %direct.schedule.10
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #2

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_11:
	.quad	14                              ; 0xe
	.quad	15                              ; 0xf
lCPI0_12:
	.quad	10                              ; 0xa
	.quad	11                              ; 0xb
lCPI0_13:
	.quad	12                              ; 0xc
	.quad	13                              ; 0xd
lCPI0_14:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
lCPI0_15:
	.quad	32                              ; 0x20
	.quad	0                               ; 0x0
lCPI0_16:
	.quad	22                              ; 0x16
	.quad	23                              ; 0x17
lCPI0_17:
	.quad	18                              ; 0x12
	.quad	19                              ; 0x13
lCPI0_18:
	.quad	20                              ; 0x14
	.quad	21                              ; 0x15
lCPI0_19:
	.quad	16                              ; 0x10
	.quad	17                              ; 0x11
lCPI0_20:
	.quad	64                              ; 0x40
	.quad	0                               ; 0x0
lCPI0_21:
	.quad	30                              ; 0x1e
	.quad	31                              ; 0x1f
lCPI0_22:
	.quad	26                              ; 0x1a
	.quad	27                              ; 0x1b
lCPI0_23:
	.quad	28                              ; 0x1c
	.quad	29                              ; 0x1d
lCPI0_24:
	.quad	24                              ; 0x18
	.quad	25                              ; 0x19
lCPI0_25:
	.quad	96                              ; 0x60
	.quad	0                               ; 0x0
lCPI0_26:
	.quad	152                             ; 0x98
	.quad	156                             ; 0x9c
lCPI0_27:
	.quad	144                             ; 0x90
	.quad	148                             ; 0x94
lCPI0_28:
	.quad	136                             ; 0x88
	.quad	140                             ; 0x8c
lCPI0_29:
	.quad	128                             ; 0x80
	.quad	132                             ; 0x84
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_30:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v23, v0, v2
	cmhi.4s	v16, v0, v1
	uzp1.8h	v18, v16, v23
	umaxv.8h	h0, v18
	fmov	w8, s0
	tbz	w8, #0, LBB0_955
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #2080
	ldr	x11, [x0]
	ldr	x10, [x0, #16]
	ldr	x9, [x0, #32]
	ldr	x8, [x0, #48]
	sshll.2d	v0, v16, #0
	sshll.2d	v1, v23, #0
	sshll2.2d	v22, v16, #0
	sshll2.2d	v25, v23, #0
	ldr	w12, [x1]
	ldr	w13, [x1, #36]
	add	w12, w13, w12, lsl #5
Lloh4:
	adrp	x13, lCPI0_2@PAGE
Lloh5:
	ldr	q2, [x13, lCPI0_2@PAGEOFF]
	and.16b	v8, v25, v2
Lloh6:
	adrp	x13, lCPI0_3@PAGE
Lloh7:
	ldr	q2, [x13, lCPI0_3@PAGEOFF]
	and.16b	v9, v22, v2
Lloh8:
	adrp	x13, lCPI0_4@PAGE
Lloh9:
	ldr	q2, [x13, lCPI0_4@PAGEOFF]
	and.16b	v10, v1, v2
Lloh10:
	adrp	x13, lCPI0_5@PAGE
Lloh11:
	ldr	q1, [x13, lCPI0_5@PAGEOFF]
	and.16b	v6, v0, v1
	lsr	w12, w12, #3
	dup.4s	v0, w12
	and.16b	v1, v16, v0
	and.16b	v0, v23, v0
	ushll2.2d	v26, v0, #0
	ushll2.2d	v28, v1, #0
	ushll.2d	v31, v0, #0
	ushll.2d	v0, v1, #0
	subs	x12, x11, x8
	cset	w13, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w13, wzr, w13, ls
	subs	x12, x8, x11
	cset	w14, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w14, wzr, w14, ls
	subs	x12, x10, x8
	cset	w15, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w15, wzr, w15, ls
	subs	x12, x8, x10
	cset	w16, hs
	cmp	x12, #2243
	csel	w16, wzr, w16, ls
	subs	x12, x9, x8
	cset	w17, hs
	lsr	x12, x12, #3
	cmp	x12, #560
	csel	w12, wzr, w17, ls
	subs	x17, x8, x9
	cset	w0, hs
	cmp	x17, #2243
	csel	w17, wzr, w0, ls
	orr	w0, w12, w17
	adrp	x17, lCPI0_6@PAGE
	xtn.2s	v1, v0
	adrp	x12, lCPI0_30@PAGE
	cmp	w0, #1
	b.ne	LBB0_480
; %bb.2:                                ; %direct.activate
	orr	w13, w13, w14
	cbz	w13, LBB0_480
; %bb.3:                                ; %direct.activate
	orr	w13, w15, w16
	cbz	w13, LBB0_480
; %bb.4:                                ; %direct.true
	ldr	q0, [x17, lCPI0_6@PAGEOFF]
	and.16b	v0, v18, v0
	addv.8h	h19, v0
	fmov	w16, s19
	and	w13, w16, #0xff
	movi.2s	v7, #66
	mov.16b	v0, v6
	umlal.2d	v0, v1, v7
	fmov	x14, d0
	lsl	x14, x14, #2
	add	x15, x11, x14
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w16, #0, LBB0_12
; %bb.5:                                ; %cond.load
	ldr	s2, [x15]
	tbnz	w13, #1, LBB0_13
LBB0_6:                                 ; %else2
	tbz	w13, #2, LBB0_14
LBB0_7:                                 ; %cond.load4
	add	x16, x15, #8
	ld1.s	{ v2 }[2], [x16]
	tbnz	w13, #3, LBB0_15
LBB0_8:                                 ; %else8
	tbz	w13, #4, LBB0_16
LBB0_9:                                 ; %cond.load10
	add	x16, x15, #16
	ld1.s	{ v0 }[0], [x16]
	tbnz	w13, #5, LBB0_17
LBB0_10:                                ; %else14
	tbz	w13, #6, LBB0_18
LBB0_11:                                ; %cond.load16
	add	x16, x15, #24
	ld1.s	{ v0 }[2], [x16]
	umull.2d	v17, v1, v7
	tbnz	w13, #7, LBB0_19
	b	LBB0_20
LBB0_12:                                ; %else
	tbz	w13, #1, LBB0_6
LBB0_13:                                ; %cond.load1
	add	x16, x15, #4
	ld1.s	{ v2 }[1], [x16]
	tbnz	w13, #2, LBB0_7
LBB0_14:                                ; %else5
	tbz	w13, #3, LBB0_8
LBB0_15:                                ; %cond.load7
	add	x16, x15, #12
	ld1.s	{ v2 }[3], [x16]
	tbnz	w13, #4, LBB0_9
LBB0_16:                                ; %else11
	tbz	w13, #5, LBB0_10
LBB0_17:                                ; %cond.load13
	add	x16, x15, #20
	ld1.s	{ v0 }[1], [x16]
	tbnz	w13, #6, LBB0_11
LBB0_18:                                ; %else17
	umull.2d	v17, v1, v7
	tbz	w13, #7, LBB0_20
LBB0_19:                                ; %cond.load19
	add	x13, x15, #28
	ld1.s	{ v0 }[3], [x13]
LBB0_20:                                ; %else20
	fmov	w0, s19
	and	w16, w0, #0xff
	fmov	x13, d17
	lsl	x13, x13, #2
	add	x15, x13, #132
	add	x17, x11, x15
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w0, #0, LBB0_28
; %bb.21:                               ; %cond.load23
	ldr	s4, [x17]
	tbnz	w16, #1, LBB0_29
LBB0_22:                                ; %else27
	tbz	w16, #2, LBB0_30
LBB0_23:                                ; %cond.load29
	add	x0, x17, #8
	ld1.s	{ v4 }[2], [x0]
	tbnz	w16, #3, LBB0_31
LBB0_24:                                ; %else33
	tbz	w16, #4, LBB0_32
LBB0_25:                                ; %cond.load35
	add	x0, x17, #16
	ld1.s	{ v3 }[0], [x0]
	tbnz	w16, #5, LBB0_33
LBB0_26:                                ; %else39
	tbz	w16, #6, LBB0_34
LBB0_27:                                ; %cond.load41
	add	x0, x17, #24
	ld1.s	{ v3 }[2], [x0]
	tbnz	w16, #7, LBB0_35
	b	LBB0_36
LBB0_28:                                ; %else24
	tbz	w16, #1, LBB0_22
LBB0_29:                                ; %cond.load26
	add	x0, x17, #4
	ld1.s	{ v4 }[1], [x0]
	tbnz	w16, #2, LBB0_23
LBB0_30:                                ; %else30
	tbz	w16, #3, LBB0_24
LBB0_31:                                ; %cond.load32
	add	x0, x17, #12
	ld1.s	{ v4 }[3], [x0]
	tbnz	w16, #4, LBB0_25
LBB0_32:                                ; %else36
	tbz	w16, #5, LBB0_26
LBB0_33:                                ; %cond.load38
	add	x0, x17, #20
	ld1.s	{ v3 }[1], [x0]
	tbnz	w16, #6, LBB0_27
LBB0_34:                                ; %else42
	tbz	w16, #7, LBB0_36
LBB0_35:                                ; %cond.load44
	add	x16, x17, #28
	ld1.s	{ v3 }[3], [x16]
LBB0_36:                                ; %else45
	fmov	w1, s19
	and	w17, w1, #0xff
	movi.2s	v16, #33
	mov.16b	v5, v6
	umlal.2d	v5, v1, v16
	fmov	x16, d5
	lsl	x16, x16, #2
	add	x0, x10, x16
	movi.2d	v20, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbz	w1, #0, LBB0_52
; %bb.37:                               ; %cond.load48
	ldr	s20, [x0]
	tbnz	w17, #1, LBB0_53
LBB0_38:                                ; %else52
	tbz	w17, #2, LBB0_54
LBB0_39:                                ; %cond.load54
	add	x1, x0, #8
	ld1.s	{ v20 }[2], [x1]
	tbnz	w17, #3, LBB0_55
LBB0_40:                                ; %else58
	tbz	w17, #4, LBB0_56
LBB0_41:                                ; %cond.load60
	add	x1, x0, #16
	ld1.s	{ v5 }[0], [x1]
	tbnz	w17, #5, LBB0_57
LBB0_42:                                ; %else64
	tbz	w17, #6, LBB0_58
LBB0_43:                                ; %cond.load66
	add	x1, x0, #24
	ld1.s	{ v5 }[2], [x1]
	tbnz	w17, #7, LBB0_59
LBB0_44:                                ; %else70
	fmov	w0, s19
	and	w17, w0, #0xff
	add	x16, x9, x16
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w0, #0, LBB0_60
LBB0_45:                                ; %cond.load73
	ldr	s22, [x16]
	tbnz	w17, #1, LBB0_61
LBB0_46:                                ; %else77
	tbz	w17, #2, LBB0_62
LBB0_47:                                ; %cond.load79
	add	x0, x16, #8
	ld1.s	{ v22 }[2], [x0]
	tbnz	w17, #3, LBB0_63
LBB0_48:                                ; %else83
	tbz	w17, #4, LBB0_64
LBB0_49:                                ; %cond.load85
	add	x0, x16, #16
	ld1.s	{ v21 }[0], [x0]
	tbnz	w17, #5, LBB0_65
LBB0_50:                                ; %else89
	tbz	w17, #6, LBB0_66
LBB0_51:                                ; %cond.load91
	add	x0, x16, #24
	ld1.s	{ v21 }[2], [x0]
	tbnz	w17, #7, LBB0_67
	b	LBB0_68
LBB0_52:                                ; %else49
	tbz	w17, #1, LBB0_38
LBB0_53:                                ; %cond.load51
	add	x1, x0, #4
	ld1.s	{ v20 }[1], [x1]
	tbnz	w17, #2, LBB0_39
LBB0_54:                                ; %else55
	tbz	w17, #3, LBB0_40
LBB0_55:                                ; %cond.load57
	add	x1, x0, #12
	ld1.s	{ v20 }[3], [x1]
	tbnz	w17, #4, LBB0_41
LBB0_56:                                ; %else61
	tbz	w17, #5, LBB0_42
LBB0_57:                                ; %cond.load63
	add	x1, x0, #20
	ld1.s	{ v5 }[1], [x1]
	tbnz	w17, #6, LBB0_43
LBB0_58:                                ; %else67
	tbz	w17, #7, LBB0_44
LBB0_59:                                ; %cond.load69
	add	x17, x0, #28
	ld1.s	{ v5 }[3], [x17]
	fmov	w0, s19
	and	w17, w0, #0xff
	add	x16, x9, x16
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w0, #0, LBB0_45
LBB0_60:                                ; %else74
	tbz	w17, #1, LBB0_46
LBB0_61:                                ; %cond.load76
	add	x0, x16, #4
	ld1.s	{ v22 }[1], [x0]
	tbnz	w17, #2, LBB0_47
LBB0_62:                                ; %else80
	tbz	w17, #3, LBB0_48
LBB0_63:                                ; %cond.load82
	add	x0, x16, #12
	ld1.s	{ v22 }[3], [x0]
	tbnz	w17, #4, LBB0_49
LBB0_64:                                ; %else86
	tbz	w17, #5, LBB0_50
LBB0_65:                                ; %cond.load88
	add	x0, x16, #20
	ld1.s	{ v21 }[1], [x0]
	tbnz	w17, #6, LBB0_51
LBB0_66:                                ; %else92
	tbz	w17, #7, LBB0_68
LBB0_67:                                ; %cond.load94
	add	x16, x16, #28
	ld1.s	{ v21 }[3], [x16]
LBB0_68:                                ; %else95
	fmov	w17, s19
	and	w16, w17, #0xff
	fmul.4s	v23, v2, v20
	fmul.4s	v24, v4, v22
	fsub.4s	v23, v23, v24
	add	x14, x8, x14
	tbz	w17, #0, LBB0_76
; %bb.69:                               ; %cond.store
	str	s23, [x14]
	tbnz	w16, #1, LBB0_77
LBB0_70:                                ; %else100
	tbz	w16, #2, LBB0_78
LBB0_71:                                ; %cond.store101
	add	x17, x14, #8
	st1.s	{ v23 }[2], [x17]
	fmul.4s	v24, v0, v5
	fmul.4s	v25, v3, v21
	tbnz	w16, #3, LBB0_79
LBB0_72:                                ; %else104
	fsub.4s	v23, v24, v25
	tbz	w16, #4, LBB0_80
LBB0_73:                                ; %cond.store105
	str	s23, [x14, #16]
	tbnz	w16, #5, LBB0_81
LBB0_74:                                ; %else108
	tbz	w16, #6, LBB0_82
LBB0_75:                                ; %cond.store109
	add	x17, x14, #24
	st1.s	{ v23 }[2], [x17]
	tbnz	w16, #7, LBB0_83
	b	LBB0_84
LBB0_76:                                ; %else98
	tbz	w16, #1, LBB0_70
LBB0_77:                                ; %cond.store99
	add	x17, x14, #4
	st1.s	{ v23 }[1], [x17]
	tbnz	w16, #2, LBB0_71
LBB0_78:                                ; %else102
	fmul.4s	v24, v0, v5
	fmul.4s	v25, v3, v21
	tbz	w16, #3, LBB0_72
LBB0_79:                                ; %cond.store103
	add	x17, x14, #12
	st1.s	{ v23 }[3], [x17]
	fsub.4s	v23, v24, v25
	tbnz	w16, #4, LBB0_73
LBB0_80:                                ; %else106
	tbz	w16, #5, LBB0_74
LBB0_81:                                ; %cond.store107
	add	x17, x14, #20
	st1.s	{ v23 }[1], [x17]
	tbnz	w16, #6, LBB0_75
LBB0_82:                                ; %else110
	tbz	w16, #7, LBB0_84
LBB0_83:                                ; %cond.store111
	add	x14, x14, #28
	st1.s	{ v23 }[3], [x14]
LBB0_84:                                ; %else112
	fmov	w16, s19
	and	w14, w16, #0xff
	fmul.4s	v2, v2, v22
	fmul.4s	v4, v4, v20
	fadd.4s	v2, v4, v2
	add	x15, x8, x15
	tbz	w16, #0, LBB0_92
; %bb.85:                               ; %cond.store114
	str	s2, [x15]
	tbnz	w14, #1, LBB0_93
LBB0_86:                                ; %else117
	tbz	w14, #2, LBB0_94
LBB0_87:                                ; %cond.store118
	add	x16, x15, #8
	st1.s	{ v2 }[2], [x16]
	fmul.4s	v0, v0, v21
	fmul.4s	v3, v3, v5
	tbnz	w14, #3, LBB0_95
LBB0_88:                                ; %else121
	fadd.4s	v0, v3, v0
	tbz	w14, #4, LBB0_96
LBB0_89:                                ; %cond.store122
	str	s0, [x15, #16]
	tbnz	w14, #5, LBB0_97
LBB0_90:                                ; %else125
	tbz	w14, #6, LBB0_98
LBB0_91:                                ; %cond.store126
	add	x16, x15, #24
	st1.s	{ v0 }[2], [x16]
	tbnz	w14, #7, LBB0_99
	b	LBB0_100
LBB0_92:                                ; %else115
	tbz	w14, #1, LBB0_86
LBB0_93:                                ; %cond.store116
	add	x16, x15, #4
	st1.s	{ v2 }[1], [x16]
	tbnz	w14, #2, LBB0_87
LBB0_94:                                ; %else119
	fmul.4s	v0, v0, v21
	fmul.4s	v3, v3, v5
	tbz	w14, #3, LBB0_88
LBB0_95:                                ; %cond.store120
	add	x16, x15, #12
	st1.s	{ v2 }[3], [x16]
	fadd.4s	v0, v3, v0
	tbnz	w14, #4, LBB0_89
LBB0_96:                                ; %else123
	tbz	w14, #5, LBB0_90
LBB0_97:                                ; %cond.store124
	add	x16, x15, #20
	st1.s	{ v0 }[1], [x16]
	tbnz	w14, #6, LBB0_91
LBB0_98:                                ; %else127
	tbz	w14, #7, LBB0_100
LBB0_99:                                ; %cond.store128
	add	x14, x15, #28
	st1.s	{ v0 }[3], [x14]
LBB0_100:                               ; %else129
	fmov	w17, s19
	and	w15, w17, #0xff
	mov	w14, #8                         ; =0x8
	dup.2d	v0, x14
	orr.16b	v5, v6, v0
	add.2d	v0, v17, v5
	fmov	x14, d0
	lsl	x14, x14, #2
	add	x16, x11, x14
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w17, #0, LBB0_108
; %bb.101:                              ; %cond.load131
	ldr	s2, [x16]
	tbnz	w15, #1, LBB0_109
LBB0_102:                               ; %else135
	tbz	w15, #2, LBB0_110
LBB0_103:                               ; %cond.load137
	add	x17, x16, #8
	ld1.s	{ v2 }[2], [x17]
	tbnz	w15, #3, LBB0_111
LBB0_104:                               ; %else141
	tbz	w15, #4, LBB0_112
LBB0_105:                               ; %cond.load143
	add	x17, x16, #16
	ld1.s	{ v0 }[0], [x17]
	tbnz	w15, #5, LBB0_113
LBB0_106:                               ; %else147
	tbz	w15, #6, LBB0_114
LBB0_107:                               ; %cond.load149
	add	x17, x16, #24
	ld1.s	{ v0 }[2], [x17]
	tbnz	w15, #7, LBB0_115
	b	LBB0_116
LBB0_108:                               ; %else132
	tbz	w15, #1, LBB0_102
LBB0_109:                               ; %cond.load134
	add	x17, x16, #4
	ld1.s	{ v2 }[1], [x17]
	tbnz	w15, #2, LBB0_103
LBB0_110:                               ; %else138
	tbz	w15, #3, LBB0_104
LBB0_111:                               ; %cond.load140
	add	x17, x16, #12
	ld1.s	{ v2 }[3], [x17]
	tbnz	w15, #4, LBB0_105
LBB0_112:                               ; %else144
	tbz	w15, #5, LBB0_106
LBB0_113:                               ; %cond.load146
	add	x17, x16, #20
	ld1.s	{ v0 }[1], [x17]
	tbnz	w15, #6, LBB0_107
LBB0_114:                               ; %else150
	tbz	w15, #7, LBB0_116
LBB0_115:                               ; %cond.load152
	add	x15, x16, #28
	ld1.s	{ v0 }[3], [x15]
LBB0_116:                               ; %else153
	fmov	w0, s19
	and	w16, w0, #0xff
	add	x15, x13, #164
	add	x17, x11, x15
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w0, #0, LBB0_124
; %bb.117:                              ; %cond.load156
	ldr	s4, [x17]
	tbnz	w16, #1, LBB0_125
LBB0_118:                               ; %else160
	tbz	w16, #2, LBB0_126
LBB0_119:                               ; %cond.load162
	add	x0, x17, #8
	ld1.s	{ v4 }[2], [x0]
	tbnz	w16, #3, LBB0_127
LBB0_120:                               ; %else166
	tbz	w16, #4, LBB0_128
LBB0_121:                               ; %cond.load168
	add	x0, x17, #16
	ld1.s	{ v3 }[0], [x0]
	tbnz	w16, #5, LBB0_129
LBB0_122:                               ; %else172
	tbz	w16, #6, LBB0_130
LBB0_123:                               ; %cond.load174
	add	x0, x17, #24
	ld1.s	{ v3 }[2], [x0]
	umull.2d	v20, v1, v16
	tbnz	w16, #7, LBB0_131
	b	LBB0_132
LBB0_124:                               ; %else157
	tbz	w16, #1, LBB0_118
LBB0_125:                               ; %cond.load159
	add	x0, x17, #4
	ld1.s	{ v4 }[1], [x0]
	tbnz	w16, #2, LBB0_119
LBB0_126:                               ; %else163
	tbz	w16, #3, LBB0_120
LBB0_127:                               ; %cond.load165
	add	x0, x17, #12
	ld1.s	{ v4 }[3], [x0]
	tbnz	w16, #4, LBB0_121
LBB0_128:                               ; %else169
	tbz	w16, #5, LBB0_122
LBB0_129:                               ; %cond.load171
	add	x0, x17, #20
	ld1.s	{ v3 }[1], [x0]
	tbnz	w16, #6, LBB0_123
LBB0_130:                               ; %else175
	umull.2d	v20, v1, v16
	tbz	w16, #7, LBB0_132
LBB0_131:                               ; %cond.load177
	add	x16, x17, #28
	ld1.s	{ v3 }[3], [x16]
LBB0_132:                               ; %else178
	fmov	w1, s19
	and	w17, w1, #0xff
	add.2d	v1, v20, v5
	fmov	x16, d1
	lsl	x16, x16, #2
	add	x0, x10, x16
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w1, #0, LBB0_148
; %bb.133:                              ; %cond.load181
	ldr	s5, [x0]
	tbnz	w17, #1, LBB0_149
LBB0_134:                               ; %else185
	tbz	w17, #2, LBB0_150
LBB0_135:                               ; %cond.load187
	add	x1, x0, #8
	ld1.s	{ v5 }[2], [x1]
	tbnz	w17, #3, LBB0_151
LBB0_136:                               ; %else191
	tbz	w17, #4, LBB0_152
LBB0_137:                               ; %cond.load193
	add	x1, x0, #16
	ld1.s	{ v1 }[0], [x1]
	tbnz	w17, #5, LBB0_153
LBB0_138:                               ; %else197
	tbz	w17, #6, LBB0_154
LBB0_139:                               ; %cond.load199
	add	x1, x0, #24
	ld1.s	{ v1 }[2], [x1]
	tbnz	w17, #7, LBB0_155
LBB0_140:                               ; %else203
	fmov	w0, s19
	and	w17, w0, #0xff
	add	x16, x9, x16
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w0, #0, LBB0_156
LBB0_141:                               ; %cond.load206
	ldr	s22, [x16]
	tbnz	w17, #1, LBB0_157
LBB0_142:                               ; %else210
	tbz	w17, #2, LBB0_158
LBB0_143:                               ; %cond.load212
	add	x0, x16, #8
	ld1.s	{ v22 }[2], [x0]
	tbnz	w17, #3, LBB0_159
LBB0_144:                               ; %else216
	tbz	w17, #4, LBB0_160
LBB0_145:                               ; %cond.load218
	add	x0, x16, #16
	ld1.s	{ v21 }[0], [x0]
	tbnz	w17, #5, LBB0_161
LBB0_146:                               ; %else222
	tbz	w17, #6, LBB0_162
LBB0_147:                               ; %cond.load224
	add	x0, x16, #24
	ld1.s	{ v21 }[2], [x0]
	tbnz	w17, #7, LBB0_163
	b	LBB0_164
LBB0_148:                               ; %else182
	tbz	w17, #1, LBB0_134
LBB0_149:                               ; %cond.load184
	add	x1, x0, #4
	ld1.s	{ v5 }[1], [x1]
	tbnz	w17, #2, LBB0_135
LBB0_150:                               ; %else188
	tbz	w17, #3, LBB0_136
LBB0_151:                               ; %cond.load190
	add	x1, x0, #12
	ld1.s	{ v5 }[3], [x1]
	tbnz	w17, #4, LBB0_137
LBB0_152:                               ; %else194
	tbz	w17, #5, LBB0_138
LBB0_153:                               ; %cond.load196
	add	x1, x0, #20
	ld1.s	{ v1 }[1], [x1]
	tbnz	w17, #6, LBB0_139
LBB0_154:                               ; %else200
	tbz	w17, #7, LBB0_140
LBB0_155:                               ; %cond.load202
	add	x17, x0, #28
	ld1.s	{ v1 }[3], [x17]
	fmov	w0, s19
	and	w17, w0, #0xff
	add	x16, x9, x16
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w0, #0, LBB0_141
LBB0_156:                               ; %else207
	tbz	w17, #1, LBB0_142
LBB0_157:                               ; %cond.load209
	add	x0, x16, #4
	ld1.s	{ v22 }[1], [x0]
	tbnz	w17, #2, LBB0_143
LBB0_158:                               ; %else213
	tbz	w17, #3, LBB0_144
LBB0_159:                               ; %cond.load215
	add	x0, x16, #12
	ld1.s	{ v22 }[3], [x0]
	tbnz	w17, #4, LBB0_145
LBB0_160:                               ; %else219
	tbz	w17, #5, LBB0_146
LBB0_161:                               ; %cond.load221
	add	x0, x16, #20
	ld1.s	{ v21 }[1], [x0]
	tbnz	w17, #6, LBB0_147
LBB0_162:                               ; %else225
	tbz	w17, #7, LBB0_164
LBB0_163:                               ; %cond.load227
	add	x16, x16, #28
	ld1.s	{ v21 }[3], [x16]
LBB0_164:                               ; %else228
	fmov	w17, s19
	and	w16, w17, #0xff
	fmul.4s	v23, v2, v5
	fmul.4s	v24, v4, v22
	fsub.4s	v23, v23, v24
	add	x14, x8, x14
	tbz	w17, #0, LBB0_172
; %bb.165:                              ; %cond.store231
	str	s23, [x14]
	tbnz	w16, #1, LBB0_173
LBB0_166:                               ; %else234
	tbz	w16, #2, LBB0_174
LBB0_167:                               ; %cond.store235
	add	x17, x14, #8
	st1.s	{ v23 }[2], [x17]
	fmul.4s	v24, v0, v1
	fmul.4s	v25, v3, v21
	tbnz	w16, #3, LBB0_175
LBB0_168:                               ; %else238
	fsub.4s	v23, v24, v25
	tbz	w16, #4, LBB0_176
LBB0_169:                               ; %cond.store239
	str	s23, [x14, #16]
	tbnz	w16, #5, LBB0_177
LBB0_170:                               ; %else242
	tbz	w16, #6, LBB0_178
LBB0_171:                               ; %cond.store243
	add	x17, x14, #24
	st1.s	{ v23 }[2], [x17]
	tbnz	w16, #7, LBB0_179
	b	LBB0_180
LBB0_172:                               ; %else232
	tbz	w16, #1, LBB0_166
LBB0_173:                               ; %cond.store233
	add	x17, x14, #4
	st1.s	{ v23 }[1], [x17]
	tbnz	w16, #2, LBB0_167
LBB0_174:                               ; %else236
	fmul.4s	v24, v0, v1
	fmul.4s	v25, v3, v21
	tbz	w16, #3, LBB0_168
LBB0_175:                               ; %cond.store237
	add	x17, x14, #12
	st1.s	{ v23 }[3], [x17]
	fsub.4s	v23, v24, v25
	tbnz	w16, #4, LBB0_169
LBB0_176:                               ; %else240
	tbz	w16, #5, LBB0_170
LBB0_177:                               ; %cond.store241
	add	x17, x14, #20
	st1.s	{ v23 }[1], [x17]
	tbnz	w16, #6, LBB0_171
LBB0_178:                               ; %else244
	tbz	w16, #7, LBB0_180
LBB0_179:                               ; %cond.store245
	add	x14, x14, #28
	st1.s	{ v23 }[3], [x14]
LBB0_180:                               ; %else246
	fmov	w16, s19
	and	w14, w16, #0xff
	fmul.4s	v2, v2, v22
	fmul.4s	v4, v4, v5
	fadd.4s	v2, v4, v2
	add	x15, x8, x15
	tbz	w16, #0, LBB0_188
; %bb.181:                              ; %cond.store248
	str	s2, [x15]
	tbnz	w14, #1, LBB0_189
LBB0_182:                               ; %else251
	tbz	w14, #2, LBB0_190
LBB0_183:                               ; %cond.store252
	add	x16, x15, #8
	st1.s	{ v2 }[2], [x16]
	fmul.4s	v0, v0, v21
	fmul.4s	v1, v3, v1
	tbnz	w14, #3, LBB0_191
LBB0_184:                               ; %else255
	fadd.4s	v0, v1, v0
	tbz	w14, #4, LBB0_192
LBB0_185:                               ; %cond.store256
	str	s0, [x15, #16]
	tbnz	w14, #5, LBB0_193
LBB0_186:                               ; %else259
	tbz	w14, #6, LBB0_194
LBB0_187:                               ; %cond.store260
	add	x16, x15, #24
	st1.s	{ v0 }[2], [x16]
	tbnz	w14, #7, LBB0_195
	b	LBB0_196
LBB0_188:                               ; %else249
	tbz	w14, #1, LBB0_182
LBB0_189:                               ; %cond.store250
	add	x16, x15, #4
	st1.s	{ v2 }[1], [x16]
	tbnz	w14, #2, LBB0_183
LBB0_190:                               ; %else253
	fmul.4s	v0, v0, v21
	fmul.4s	v1, v3, v1
	tbz	w14, #3, LBB0_184
LBB0_191:                               ; %cond.store254
	add	x16, x15, #12
	st1.s	{ v2 }[3], [x16]
	fadd.4s	v0, v1, v0
	tbnz	w14, #4, LBB0_185
LBB0_192:                               ; %else257
	tbz	w14, #5, LBB0_186
LBB0_193:                               ; %cond.store258
	add	x16, x15, #20
	st1.s	{ v0 }[1], [x16]
	tbnz	w14, #6, LBB0_187
LBB0_194:                               ; %else261
	tbz	w14, #7, LBB0_196
LBB0_195:                               ; %cond.store262
	add	x14, x15, #28
	st1.s	{ v0 }[3], [x14]
LBB0_196:                               ; %else263
	fmov	w17, s19
	and	w15, w17, #0xff
	mov	w14, #16                        ; =0x10
	dup.2d	v0, x14
	orr.16b	v4, v6, v0
	add.2d	v0, v17, v4
	fmov	x14, d0
	lsl	x14, x14, #2
	add	x16, x11, x14
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w17, #0, LBB0_204
; %bb.197:                              ; %cond.load265
	ldr	s1, [x16]
	tbnz	w15, #1, LBB0_205
LBB0_198:                               ; %else269
	tbz	w15, #2, LBB0_206
LBB0_199:                               ; %cond.load271
	add	x17, x16, #8
	ld1.s	{ v1 }[2], [x17]
	tbnz	w15, #3, LBB0_207
LBB0_200:                               ; %else275
	tbz	w15, #4, LBB0_208
LBB0_201:                               ; %cond.load277
	add	x17, x16, #16
	ld1.s	{ v0 }[0], [x17]
	tbnz	w15, #5, LBB0_209
LBB0_202:                               ; %else281
	tbz	w15, #6, LBB0_210
LBB0_203:                               ; %cond.load283
	add	x17, x16, #24
	ld1.s	{ v0 }[2], [x17]
	tbnz	w15, #7, LBB0_211
	b	LBB0_212
LBB0_204:                               ; %else266
	tbz	w15, #1, LBB0_198
LBB0_205:                               ; %cond.load268
	add	x17, x16, #4
	ld1.s	{ v1 }[1], [x17]
	tbnz	w15, #2, LBB0_199
LBB0_206:                               ; %else272
	tbz	w15, #3, LBB0_200
LBB0_207:                               ; %cond.load274
	add	x17, x16, #12
	ld1.s	{ v1 }[3], [x17]
	tbnz	w15, #4, LBB0_201
LBB0_208:                               ; %else278
	tbz	w15, #5, LBB0_202
LBB0_209:                               ; %cond.load280
	add	x17, x16, #20
	ld1.s	{ v0 }[1], [x17]
	tbnz	w15, #6, LBB0_203
LBB0_210:                               ; %else284
	tbz	w15, #7, LBB0_212
LBB0_211:                               ; %cond.load286
	add	x15, x16, #28
	ld1.s	{ v0 }[3], [x15]
LBB0_212:                               ; %else287
	fmov	w0, s19
	and	w16, w0, #0xff
	add	x15, x13, #196
	add	x17, x11, x15
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w0, #0, LBB0_220
; %bb.213:                              ; %cond.load290
	ldr	s3, [x17]
	tbnz	w16, #1, LBB0_221
LBB0_214:                               ; %else294
	tbz	w16, #2, LBB0_222
LBB0_215:                               ; %cond.load296
	add	x0, x17, #8
	ld1.s	{ v3 }[2], [x0]
	tbnz	w16, #3, LBB0_223
LBB0_216:                               ; %else300
	tbz	w16, #4, LBB0_224
LBB0_217:                               ; %cond.load302
	add	x0, x17, #16
	ld1.s	{ v2 }[0], [x0]
	tbnz	w16, #5, LBB0_225
LBB0_218:                               ; %else306
	tbz	w16, #6, LBB0_226
LBB0_219:                               ; %cond.load308
	add	x0, x17, #24
	ld1.s	{ v2 }[2], [x0]
	tbnz	w16, #7, LBB0_227
	b	LBB0_228
LBB0_220:                               ; %else291
	tbz	w16, #1, LBB0_214
LBB0_221:                               ; %cond.load293
	add	x0, x17, #4
	ld1.s	{ v3 }[1], [x0]
	tbnz	w16, #2, LBB0_215
LBB0_222:                               ; %else297
	tbz	w16, #3, LBB0_216
LBB0_223:                               ; %cond.load299
	add	x0, x17, #12
	ld1.s	{ v3 }[3], [x0]
	tbnz	w16, #4, LBB0_217
LBB0_224:                               ; %else303
	tbz	w16, #5, LBB0_218
LBB0_225:                               ; %cond.load305
	add	x0, x17, #20
	ld1.s	{ v2 }[1], [x0]
	tbnz	w16, #6, LBB0_219
LBB0_226:                               ; %else309
	tbz	w16, #7, LBB0_228
LBB0_227:                               ; %cond.load311
	add	x16, x17, #28
	ld1.s	{ v2 }[3], [x16]
LBB0_228:                               ; %else312
	fmov	w1, s19
	and	w17, w1, #0xff
	add.2d	v4, v20, v4
	fmov	x16, d4
	lsl	x16, x16, #2
	add	x0, x10, x16
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w1, #0, LBB0_244
; %bb.229:                              ; %cond.load315
	ldr	s5, [x0]
	tbnz	w17, #1, LBB0_245
LBB0_230:                               ; %else319
	tbz	w17, #2, LBB0_246
LBB0_231:                               ; %cond.load321
	add	x1, x0, #8
	ld1.s	{ v5 }[2], [x1]
	tbnz	w17, #3, LBB0_247
LBB0_232:                               ; %else325
	tbz	w17, #4, LBB0_248
LBB0_233:                               ; %cond.load327
	add	x1, x0, #16
	ld1.s	{ v4 }[0], [x1]
	tbnz	w17, #5, LBB0_249
LBB0_234:                               ; %else331
	tbz	w17, #6, LBB0_250
LBB0_235:                               ; %cond.load333
	add	x1, x0, #24
	ld1.s	{ v4 }[2], [x1]
	tbnz	w17, #7, LBB0_251
LBB0_236:                               ; %else337
	fmov	w0, s19
	and	w17, w0, #0xff
	add	x16, x9, x16
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w0, #0, LBB0_252
LBB0_237:                               ; %cond.load340
	ldr	s22, [x16]
	tbnz	w17, #1, LBB0_253
LBB0_238:                               ; %else344
	tbz	w17, #2, LBB0_254
LBB0_239:                               ; %cond.load346
	add	x0, x16, #8
	ld1.s	{ v22 }[2], [x0]
	tbnz	w17, #3, LBB0_255
LBB0_240:                               ; %else350
	tbz	w17, #4, LBB0_256
LBB0_241:                               ; %cond.load352
	add	x0, x16, #16
	ld1.s	{ v21 }[0], [x0]
	tbnz	w17, #5, LBB0_257
LBB0_242:                               ; %else356
	tbz	w17, #6, LBB0_258
LBB0_243:                               ; %cond.load358
	add	x0, x16, #24
	ld1.s	{ v21 }[2], [x0]
	tbnz	w17, #7, LBB0_259
	b	LBB0_260
LBB0_244:                               ; %else316
	tbz	w17, #1, LBB0_230
LBB0_245:                               ; %cond.load318
	add	x1, x0, #4
	ld1.s	{ v5 }[1], [x1]
	tbnz	w17, #2, LBB0_231
LBB0_246:                               ; %else322
	tbz	w17, #3, LBB0_232
LBB0_247:                               ; %cond.load324
	add	x1, x0, #12
	ld1.s	{ v5 }[3], [x1]
	tbnz	w17, #4, LBB0_233
LBB0_248:                               ; %else328
	tbz	w17, #5, LBB0_234
LBB0_249:                               ; %cond.load330
	add	x1, x0, #20
	ld1.s	{ v4 }[1], [x1]
	tbnz	w17, #6, LBB0_235
LBB0_250:                               ; %else334
	tbz	w17, #7, LBB0_236
LBB0_251:                               ; %cond.load336
	add	x17, x0, #28
	ld1.s	{ v4 }[3], [x17]
	fmov	w0, s19
	and	w17, w0, #0xff
	add	x16, x9, x16
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w0, #0, LBB0_237
LBB0_252:                               ; %else341
	tbz	w17, #1, LBB0_238
LBB0_253:                               ; %cond.load343
	add	x0, x16, #4
	ld1.s	{ v22 }[1], [x0]
	tbnz	w17, #2, LBB0_239
LBB0_254:                               ; %else347
	tbz	w17, #3, LBB0_240
LBB0_255:                               ; %cond.load349
	add	x0, x16, #12
	ld1.s	{ v22 }[3], [x0]
	tbnz	w17, #4, LBB0_241
LBB0_256:                               ; %else353
	tbz	w17, #5, LBB0_242
LBB0_257:                               ; %cond.load355
	add	x0, x16, #20
	ld1.s	{ v21 }[1], [x0]
	tbnz	w17, #6, LBB0_243
LBB0_258:                               ; %else359
	tbz	w17, #7, LBB0_260
LBB0_259:                               ; %cond.load361
	add	x16, x16, #28
	ld1.s	{ v21 }[3], [x16]
LBB0_260:                               ; %else362
	fmov	w17, s19
	and	w16, w17, #0xff
	fmul.4s	v23, v1, v5
	fmul.4s	v24, v3, v22
	fsub.4s	v23, v23, v24
	add	x14, x8, x14
	tbz	w17, #0, LBB0_268
; %bb.261:                              ; %cond.store365
	str	s23, [x14]
	tbnz	w16, #1, LBB0_269
LBB0_262:                               ; %else368
	tbz	w16, #2, LBB0_270
LBB0_263:                               ; %cond.store369
	add	x17, x14, #8
	st1.s	{ v23 }[2], [x17]
	fmul.4s	v24, v0, v4
	fmul.4s	v25, v2, v21
	tbnz	w16, #3, LBB0_271
LBB0_264:                               ; %else372
	fsub.4s	v23, v24, v25
	tbz	w16, #4, LBB0_272
LBB0_265:                               ; %cond.store373
	str	s23, [x14, #16]
	tbnz	w16, #5, LBB0_273
LBB0_266:                               ; %else376
	tbz	w16, #6, LBB0_274
LBB0_267:                               ; %cond.store377
	add	x17, x14, #24
	st1.s	{ v23 }[2], [x17]
	tbnz	w16, #7, LBB0_275
	b	LBB0_276
LBB0_268:                               ; %else366
	tbz	w16, #1, LBB0_262
LBB0_269:                               ; %cond.store367
	add	x17, x14, #4
	st1.s	{ v23 }[1], [x17]
	tbnz	w16, #2, LBB0_263
LBB0_270:                               ; %else370
	fmul.4s	v24, v0, v4
	fmul.4s	v25, v2, v21
	tbz	w16, #3, LBB0_264
LBB0_271:                               ; %cond.store371
	add	x17, x14, #12
	st1.s	{ v23 }[3], [x17]
	fsub.4s	v23, v24, v25
	tbnz	w16, #4, LBB0_265
LBB0_272:                               ; %else374
	tbz	w16, #5, LBB0_266
LBB0_273:                               ; %cond.store375
	add	x17, x14, #20
	st1.s	{ v23 }[1], [x17]
	tbnz	w16, #6, LBB0_267
LBB0_274:                               ; %else378
	tbz	w16, #7, LBB0_276
LBB0_275:                               ; %cond.store379
	add	x14, x14, #28
	st1.s	{ v23 }[3], [x14]
LBB0_276:                               ; %else380
	fmov	w16, s19
	and	w14, w16, #0xff
	fmul.4s	v1, v1, v22
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	add	x15, x8, x15
	tbz	w16, #0, LBB0_284
; %bb.277:                              ; %cond.store382
	str	s1, [x15]
	tbnz	w14, #1, LBB0_285
LBB0_278:                               ; %else385
	tbz	w14, #2, LBB0_286
LBB0_279:                               ; %cond.store386
	add	x16, x15, #8
	st1.s	{ v1 }[2], [x16]
	fmul.4s	v0, v0, v21
	fmul.4s	v2, v2, v4
	tbnz	w14, #3, LBB0_287
LBB0_280:                               ; %else389
	fadd.4s	v0, v2, v0
	tbz	w14, #4, LBB0_288
LBB0_281:                               ; %cond.store390
	str	s0, [x15, #16]
	tbnz	w14, #5, LBB0_289
LBB0_282:                               ; %else393
	tbz	w14, #6, LBB0_290
LBB0_283:                               ; %cond.store394
	add	x16, x15, #24
	st1.s	{ v0 }[2], [x16]
	tbnz	w14, #7, LBB0_291
	b	LBB0_292
LBB0_284:                               ; %else383
	tbz	w14, #1, LBB0_278
LBB0_285:                               ; %cond.store384
	add	x16, x15, #4
	st1.s	{ v1 }[1], [x16]
	tbnz	w14, #2, LBB0_279
LBB0_286:                               ; %else387
	fmul.4s	v0, v0, v21
	fmul.4s	v2, v2, v4
	tbz	w14, #3, LBB0_280
LBB0_287:                               ; %cond.store388
	add	x16, x15, #12
	st1.s	{ v1 }[3], [x16]
	fadd.4s	v0, v2, v0
	tbnz	w14, #4, LBB0_281
LBB0_288:                               ; %else391
	tbz	w14, #5, LBB0_282
LBB0_289:                               ; %cond.store392
	add	x16, x15, #20
	st1.s	{ v0 }[1], [x16]
	tbnz	w14, #6, LBB0_283
LBB0_290:                               ; %else395
	tbz	w14, #7, LBB0_292
LBB0_291:                               ; %cond.store396
	add	x14, x15, #28
	st1.s	{ v0 }[3], [x14]
LBB0_292:                               ; %else397
	fmov	w17, s19
	and	w15, w17, #0xff
	mov	w14, #24                        ; =0x18
	dup.2d	v0, x14
	orr.16b	v4, v6, v0
	add.2d	v0, v17, v4
	fmov	x14, d0
	lsl	x14, x14, #2
	add	x16, x11, x14
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w17, #0, LBB0_300
; %bb.293:                              ; %cond.load399
	ldr	s1, [x16]
	tbnz	w15, #1, LBB0_301
LBB0_294:                               ; %else403
	tbz	w15, #2, LBB0_302
LBB0_295:                               ; %cond.load405
	add	x17, x16, #8
	ld1.s	{ v1 }[2], [x17]
	tbnz	w15, #3, LBB0_303
LBB0_296:                               ; %else409
	tbz	w15, #4, LBB0_304
LBB0_297:                               ; %cond.load411
	add	x17, x16, #16
	ld1.s	{ v0 }[0], [x17]
	tbnz	w15, #5, LBB0_305
LBB0_298:                               ; %else415
	tbz	w15, #6, LBB0_306
LBB0_299:                               ; %cond.load417
	add	x17, x16, #24
	ld1.s	{ v0 }[2], [x17]
	tbnz	w15, #7, LBB0_307
	b	LBB0_308
LBB0_300:                               ; %else400
	tbz	w15, #1, LBB0_294
LBB0_301:                               ; %cond.load402
	add	x17, x16, #4
	ld1.s	{ v1 }[1], [x17]
	tbnz	w15, #2, LBB0_295
LBB0_302:                               ; %else406
	tbz	w15, #3, LBB0_296
LBB0_303:                               ; %cond.load408
	add	x17, x16, #12
	ld1.s	{ v1 }[3], [x17]
	tbnz	w15, #4, LBB0_297
LBB0_304:                               ; %else412
	tbz	w15, #5, LBB0_298
LBB0_305:                               ; %cond.load414
	add	x17, x16, #20
	ld1.s	{ v0 }[1], [x17]
	tbnz	w15, #6, LBB0_299
LBB0_306:                               ; %else418
	tbz	w15, #7, LBB0_308
LBB0_307:                               ; %cond.load420
	add	x15, x16, #28
	ld1.s	{ v0 }[3], [x15]
LBB0_308:                               ; %else421
	fmov	w17, s19
	and	w15, w17, #0xff
	add	x13, x13, #228
	add	x16, x11, x13
	movi.2d	v3, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w17, #0, LBB0_316
; %bb.309:                              ; %cond.load424
	ldr	s3, [x16]
	tbnz	w15, #1, LBB0_317
LBB0_310:                               ; %else428
	tbz	w15, #2, LBB0_318
LBB0_311:                               ; %cond.load430
	add	x17, x16, #8
	ld1.s	{ v3 }[2], [x17]
	tbnz	w15, #3, LBB0_319
LBB0_312:                               ; %else434
	tbz	w15, #4, LBB0_320
LBB0_313:                               ; %cond.load436
	add	x17, x16, #16
	ld1.s	{ v2 }[0], [x17]
	tbnz	w15, #5, LBB0_321
LBB0_314:                               ; %else440
	tbz	w15, #6, LBB0_322
LBB0_315:                               ; %cond.load442
	add	x17, x16, #24
	ld1.s	{ v2 }[2], [x17]
	tbnz	w15, #7, LBB0_323
	b	LBB0_324
LBB0_316:                               ; %else425
	tbz	w15, #1, LBB0_310
LBB0_317:                               ; %cond.load427
	add	x17, x16, #4
	ld1.s	{ v3 }[1], [x17]
	tbnz	w15, #2, LBB0_311
LBB0_318:                               ; %else431
	tbz	w15, #3, LBB0_312
LBB0_319:                               ; %cond.load433
	add	x17, x16, #12
	ld1.s	{ v3 }[3], [x17]
	tbnz	w15, #4, LBB0_313
LBB0_320:                               ; %else437
	tbz	w15, #5, LBB0_314
LBB0_321:                               ; %cond.load439
	add	x17, x16, #20
	ld1.s	{ v2 }[1], [x17]
	tbnz	w15, #6, LBB0_315
LBB0_322:                               ; %else443
	tbz	w15, #7, LBB0_324
LBB0_323:                               ; %cond.load445
	add	x15, x16, #28
	ld1.s	{ v2 }[3], [x15]
LBB0_324:                               ; %else446
	fmov	w0, s19
	and	w16, w0, #0xff
	add.2d	v4, v20, v4
	fmov	x15, d4
	lsl	x15, x15, #2
	add	x17, x10, x15
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w0, #0, LBB0_340
; %bb.325:                              ; %cond.load449
	ldr	s5, [x17]
	tbnz	w16, #1, LBB0_341
LBB0_326:                               ; %else453
	tbz	w16, #2, LBB0_342
LBB0_327:                               ; %cond.load455
	add	x0, x17, #8
	ld1.s	{ v5 }[2], [x0]
	tbnz	w16, #3, LBB0_343
LBB0_328:                               ; %else459
	tbz	w16, #4, LBB0_344
LBB0_329:                               ; %cond.load461
	add	x0, x17, #16
	ld1.s	{ v4 }[0], [x0]
	tbnz	w16, #5, LBB0_345
LBB0_330:                               ; %else465
	tbz	w16, #6, LBB0_346
LBB0_331:                               ; %cond.load467
	add	x0, x17, #24
	ld1.s	{ v4 }[2], [x0]
	tbnz	w16, #7, LBB0_347
LBB0_332:                               ; %else471
	fmov	w17, s19
	and	w16, w17, #0xff
	add	x15, x9, x15
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w17, #0, LBB0_348
LBB0_333:                               ; %cond.load474
	ldr	s22, [x15]
	tbnz	w16, #1, LBB0_349
LBB0_334:                               ; %else478
	tbz	w16, #2, LBB0_350
LBB0_335:                               ; %cond.load480
	add	x17, x15, #8
	ld1.s	{ v22 }[2], [x17]
	tbnz	w16, #3, LBB0_351
LBB0_336:                               ; %else484
	tbz	w16, #4, LBB0_352
LBB0_337:                               ; %cond.load486
	add	x17, x15, #16
	ld1.s	{ v21 }[0], [x17]
	tbnz	w16, #5, LBB0_353
LBB0_338:                               ; %else490
	tbz	w16, #6, LBB0_354
LBB0_339:                               ; %cond.load492
	add	x17, x15, #24
	ld1.s	{ v21 }[2], [x17]
	tbnz	w16, #7, LBB0_355
	b	LBB0_356
LBB0_340:                               ; %else450
	tbz	w16, #1, LBB0_326
LBB0_341:                               ; %cond.load452
	add	x0, x17, #4
	ld1.s	{ v5 }[1], [x0]
	tbnz	w16, #2, LBB0_327
LBB0_342:                               ; %else456
	tbz	w16, #3, LBB0_328
LBB0_343:                               ; %cond.load458
	add	x0, x17, #12
	ld1.s	{ v5 }[3], [x0]
	tbnz	w16, #4, LBB0_329
LBB0_344:                               ; %else462
	tbz	w16, #5, LBB0_330
LBB0_345:                               ; %cond.load464
	add	x0, x17, #20
	ld1.s	{ v4 }[1], [x0]
	tbnz	w16, #6, LBB0_331
LBB0_346:                               ; %else468
	tbz	w16, #7, LBB0_332
LBB0_347:                               ; %cond.load470
	add	x16, x17, #28
	ld1.s	{ v4 }[3], [x16]
	fmov	w17, s19
	and	w16, w17, #0xff
	add	x15, x9, x15
	movi.2d	v22, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w17, #0, LBB0_333
LBB0_348:                               ; %else475
	tbz	w16, #1, LBB0_334
LBB0_349:                               ; %cond.load477
	add	x17, x15, #4
	ld1.s	{ v22 }[1], [x17]
	tbnz	w16, #2, LBB0_335
LBB0_350:                               ; %else481
	tbz	w16, #3, LBB0_336
LBB0_351:                               ; %cond.load483
	add	x17, x15, #12
	ld1.s	{ v22 }[3], [x17]
	tbnz	w16, #4, LBB0_337
LBB0_352:                               ; %else487
	tbz	w16, #5, LBB0_338
LBB0_353:                               ; %cond.load489
	add	x17, x15, #20
	ld1.s	{ v21 }[1], [x17]
	tbnz	w16, #6, LBB0_339
LBB0_354:                               ; %else493
	tbz	w16, #7, LBB0_356
LBB0_355:                               ; %cond.load495
	add	x15, x15, #28
	ld1.s	{ v21 }[3], [x15]
LBB0_356:                               ; %else496
	fmov	w16, s19
	and	w15, w16, #0xff
	fmul.4s	v23, v1, v5
	fmul.4s	v24, v3, v22
	fsub.4s	v23, v23, v24
	add	x14, x8, x14
	tbz	w16, #0, LBB0_364
; %bb.357:                              ; %cond.store499
	str	s23, [x14]
	tbnz	w15, #1, LBB0_365
LBB0_358:                               ; %else502
	tbz	w15, #2, LBB0_366
LBB0_359:                               ; %cond.store503
	add	x16, x14, #8
	st1.s	{ v23 }[2], [x16]
	fmul.4s	v24, v0, v4
	fmul.4s	v25, v2, v21
	tbnz	w15, #3, LBB0_367
LBB0_360:                               ; %else506
	fsub.4s	v23, v24, v25
	tbz	w15, #4, LBB0_368
LBB0_361:                               ; %cond.store507
	str	s23, [x14, #16]
	tbnz	w15, #5, LBB0_369
LBB0_362:                               ; %else510
	tbz	w15, #6, LBB0_370
LBB0_363:                               ; %cond.store511
	add	x16, x14, #24
	st1.s	{ v23 }[2], [x16]
	tbnz	w15, #7, LBB0_371
	b	LBB0_372
LBB0_364:                               ; %else500
	tbz	w15, #1, LBB0_358
LBB0_365:                               ; %cond.store501
	add	x16, x14, #4
	st1.s	{ v23 }[1], [x16]
	tbnz	w15, #2, LBB0_359
LBB0_366:                               ; %else504
	fmul.4s	v24, v0, v4
	fmul.4s	v25, v2, v21
	tbz	w15, #3, LBB0_360
LBB0_367:                               ; %cond.store505
	add	x16, x14, #12
	st1.s	{ v23 }[3], [x16]
	fsub.4s	v23, v24, v25
	tbnz	w15, #4, LBB0_361
LBB0_368:                               ; %else508
	tbz	w15, #5, LBB0_362
LBB0_369:                               ; %cond.store509
	add	x16, x14, #20
	st1.s	{ v23 }[1], [x16]
	tbnz	w15, #6, LBB0_363
LBB0_370:                               ; %else512
	tbz	w15, #7, LBB0_372
LBB0_371:                               ; %cond.store513
	add	x14, x14, #28
	st1.s	{ v23 }[3], [x14]
LBB0_372:                               ; %else514
	fmov	w15, s19
	and	w14, w15, #0xff
	fmul.4s	v1, v1, v22
	fmul.4s	v3, v3, v5
	fadd.4s	v1, v3, v1
	add	x13, x8, x13
	tbz	w15, #0, LBB0_380
; %bb.373:                              ; %cond.store516
	str	s1, [x13]
	tbnz	w14, #1, LBB0_381
LBB0_374:                               ; %else519
	tbz	w14, #2, LBB0_382
LBB0_375:                               ; %cond.store520
	add	x15, x13, #8
	st1.s	{ v1 }[2], [x15]
	fmul.4s	v0, v0, v21
	fmul.4s	v2, v2, v4
	tbnz	w14, #3, LBB0_383
LBB0_376:                               ; %else523
	fadd.4s	v0, v2, v0
	tbz	w14, #4, LBB0_384
LBB0_377:                               ; %cond.store524
	str	s0, [x13, #16]
	tbnz	w14, #5, LBB0_385
LBB0_378:                               ; %else527
	tbz	w14, #6, LBB0_386
LBB0_379:                               ; %cond.store528
	add	x15, x13, #24
	st1.s	{ v0 }[2], [x15]
	tbnz	w14, #7, LBB0_387
	b	LBB0_388
LBB0_380:                               ; %else517
	tbz	w14, #1, LBB0_374
LBB0_381:                               ; %cond.store518
	add	x15, x13, #4
	st1.s	{ v1 }[1], [x15]
	tbnz	w14, #2, LBB0_375
LBB0_382:                               ; %else521
	fmul.4s	v0, v0, v21
	fmul.4s	v2, v2, v4
	tbz	w14, #3, LBB0_376
LBB0_383:                               ; %cond.store522
	add	x15, x13, #12
	st1.s	{ v1 }[3], [x15]
	fadd.4s	v0, v2, v0
	tbnz	w14, #4, LBB0_377
LBB0_384:                               ; %else525
	tbz	w14, #5, LBB0_378
LBB0_385:                               ; %cond.store526
	add	x15, x13, #20
	st1.s	{ v0 }[1], [x15]
	tbnz	w14, #6, LBB0_379
LBB0_386:                               ; %else529
	tbz	w14, #7, LBB0_388
LBB0_387:                               ; %cond.store530
	add	x13, x13, #28
	st1.s	{ v0 }[3], [x13]
LBB0_388:                               ; %else531
	xtn.8b	v1, v18
	movi.8b	v0, #1
	and.8b	v0, v1, v0
	umov.b	w14, v0[0]
	movi.2d	v23, #0000000000000000
	mov.b	v23[0], v1[0]
	movi.2d	v0, #0000000000000000
	umaxv.8b	b2, v23
	fmov	w16, s2
	rbit	w13, w14
	clz	w13, w13
	tst	w16, #0x1
	csel	w13, w13, wzr, ne
	mov	w15, #32                        ; =0x20
	dup.2d	v25, x15
	orr.16b	v24, v6, v25
	add.2d	v2, v17, v24
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v1[0]
	ushll.2d	v1, v3, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v1, v1, v2
	stp	q0, q0, [sp, #848]
	stp	q1, q0, [sp, #816]
	and	x15, x13, #0x7
	add	x17, sp, #816
	ldr	x15, [x17, x15, lsl #3]
	sub	x15, x15, x13
	add	x15, x11, x15, lsl #2
	movi.2d	v1, #0000000000000000
	tbz	w16, #0, LBB0_396
; %bb.389:                              ; %cond.load533
	ldr	s0, [x15]
	tbnz	w14, #1, LBB0_397
LBB0_390:                               ; %else537
	tbz	w14, #2, LBB0_398
LBB0_391:                               ; %cond.load539
	add	x16, x15, #8
	ld1.s	{ v0 }[2], [x16]
	tbnz	w14, #3, LBB0_399
LBB0_392:                               ; %else543
	tbz	w14, #4, LBB0_400
LBB0_393:                               ; %cond.load545
	add	x16, x15, #16
	ld1.s	{ v1 }[0], [x16]
	tbnz	w14, #5, LBB0_401
LBB0_394:                               ; %else549
	xtn.2s	v28, v28
	xtn.2s	v29, v31
	xtn.2s	v30, v26
	tbz	w14, #6, LBB0_402
LBB0_395:                               ; %cond.load551
	add	x16, x15, #24
	ld1.s	{ v1 }[2], [x16]
	umull.2d	v18, v28, v7
	umull.2d	v21, v29, v7
	umull.2d	v19, v30, v7
	tbnz	w14, #7, LBB0_403
	b	LBB0_404
LBB0_396:                               ; %else534
	tbz	w14, #1, LBB0_390
LBB0_397:                               ; %cond.load536
	add	x16, x15, #4
	ld1.s	{ v0 }[1], [x16]
	tbnz	w14, #2, LBB0_391
LBB0_398:                               ; %else540
	tbz	w14, #3, LBB0_392
LBB0_399:                               ; %cond.load542
	add	x16, x15, #12
	ld1.s	{ v0 }[3], [x16]
	tbnz	w14, #4, LBB0_393
LBB0_400:                               ; %else546
	tbz	w14, #5, LBB0_394
LBB0_401:                               ; %cond.load548
	add	x16, x15, #20
	ld1.s	{ v1 }[1], [x16]
	xtn.2s	v28, v28
	xtn.2s	v29, v31
	xtn.2s	v30, v26
	tbnz	w14, #6, LBB0_395
LBB0_402:                               ; %else552
	umull.2d	v18, v28, v7
	umull.2d	v21, v29, v7
	umull.2d	v19, v30, v7
	tbz	w14, #7, LBB0_404
LBB0_403:                               ; %cond.load554
	add	x14, x15, #28
	ld1.s	{ v1 }[3], [x14]
LBB0_404:                               ; %else555
	add.2d	v6, v6, v17
	add.2d	v5, v9, v18
	add.2d	v4, v10, v21
	add.2d	v3, v8, v19
	mov	w14, #65                        ; =0x41
	dup.2d	v7, x14
	add.2d	v3, v3, v7
	add.2d	v4, v4, v7
	add.2d	v5, v5, v7
	add.2d	v6, v6, v7
	mov	b7, v23[0]
	mov.b	v7[4], v23[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v17, v7, v6
	mov	b7, v23[2]
	mov.b	v7[4], v23[3]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	mov	b22, v23[4]
	mov.b	v22[4], v23[5]
	and.16b	v26, v7, v5
	ushll.2d	v7, v22, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v22, v7, v4
	mov	b7, v23[6]
	mov.b	v7[4], v23[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v27, v7, v3
	ldr	d7, [x12, lCPI0_30@PAGEOFF]
	shl.8b	v31, v23, #7
	cmlt.8b	v31, v31, #0
	and.8b	v7, v31, v7
	addv.8b	b7, v7
	fmov	w12, s7
	stp	q22, q27, [sp, #784]
	stp	q17, q26, [sp, #752]
	and	x14, x13, #0x7
	add	x15, sp, #752
	ldr	x14, [x15, x14, lsl #3]
	sub	x14, x14, x13
	add	x11, x11, x14, lsl #2
	movi.2d	v22, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w12, #0, LBB0_430
; %bb.405:                              ; %cond.load558
	ldr	s22, [x11]
	tbnz	w12, #1, LBB0_431
LBB0_406:                               ; %else562
	tbz	w12, #2, LBB0_432
LBB0_407:                               ; %cond.load564
	add	x14, x11, #8
	ld1.s	{ v22 }[2], [x14]
	tbnz	w12, #3, LBB0_433
LBB0_408:                               ; %else568
	tbz	w12, #4, LBB0_434
LBB0_409:                               ; %cond.load570
	add	x14, x11, #16
	ld1.s	{ v17 }[0], [x14]
	tbnz	w12, #5, LBB0_435
LBB0_410:                               ; %else574
	tbz	w12, #6, LBB0_412
LBB0_411:                               ; %cond.load576
	add	x14, x11, #24
	ld1.s	{ v17 }[2], [x14]
LBB0_412:                               ; %else577
	orr.16b	v26, v8, v25
	orr.16b	v27, v9, v25
	orr.16b	v25, v10, v25
	umull.2d	v28, v28, v16
	umull.2d	v29, v29, v16
	umull.2d	v16, v30, v16
	tbz	w12, #7, LBB0_414
; %bb.413:                              ; %cond.load579
	add	x11, x11, #28
	ld1.s	{ v17 }[3], [x11]
LBB0_414:                               ; %else580
	add.2d	v16, v16, v26
	add.2d	v29, v29, v25
	add.2d	v28, v28, v27
	add.2d	v20, v20, v24
	mov	b24, v23[0]
	mov.b	v24[4], v23[1]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	and.16b	v20, v24, v20
	mov	b24, v23[2]
	mov.b	v24[4], v23[3]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	and.16b	v24, v24, v28
	mov	b28, v23[4]
	mov.b	v28[4], v23[5]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v28, v28, v29
	mov	b29, v23[6]
	mov.b	v29[4], v23[7]
	ushll.2d	v23, v29, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v16, v23, v16
	stp	q28, q16, [sp, #720]
	stp	q20, q24, [sp, #688]
	and	x11, x13, #0x7
	add	x12, sp, #688
	ldr	x11, [x12, x11, lsl #3]
	fmov	w12, s7
	sub	x11, x11, x13
	lsl	x11, x11, #2
	add	x10, x10, x11
	movi.2d	v20, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w12, #0, LBB0_436
; %bb.415:                              ; %cond.load583
	ldr	s20, [x10]
	tbnz	w12, #1, LBB0_437
LBB0_416:                               ; %else587
	tbz	w12, #2, LBB0_438
LBB0_417:                               ; %cond.load589
	add	x14, x10, #8
	ld1.s	{ v20 }[2], [x14]
	tbnz	w12, #3, LBB0_439
LBB0_418:                               ; %else593
	tbz	w12, #4, LBB0_440
LBB0_419:                               ; %cond.load595
	add	x14, x10, #16
	ld1.s	{ v16 }[0], [x14]
	tbnz	w12, #5, LBB0_441
LBB0_420:                               ; %else599
	tbz	w12, #6, LBB0_442
LBB0_421:                               ; %cond.load601
	add	x14, x10, #24
	ld1.s	{ v16 }[2], [x14]
	tbnz	w12, #7, LBB0_443
LBB0_422:                               ; %else605
	add	x9, x9, x11
	fmov	w10, s7
	movi.2d	v24, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbz	w10, #0, LBB0_444
LBB0_423:                               ; %cond.load608
	ldr	s24, [x9]
	tbnz	w10, #1, LBB0_445
LBB0_424:                               ; %else612
	tbz	w10, #2, LBB0_446
LBB0_425:                               ; %cond.load614
	add	x11, x9, #8
	ld1.s	{ v24 }[2], [x11]
	tbnz	w10, #3, LBB0_447
LBB0_426:                               ; %else618
	tbz	w10, #4, LBB0_448
LBB0_427:                               ; %cond.load620
	add	x11, x9, #16
	ld1.s	{ v23 }[0], [x11]
	tbnz	w10, #5, LBB0_449
LBB0_428:                               ; %else624
	tbz	w10, #6, LBB0_450
LBB0_429:                               ; %cond.load626
	add	x11, x9, #24
	ld1.s	{ v23 }[2], [x11]
	add.2d	v21, v21, v25
	add.2d	v25, v18, v27
	add.2d	v19, v19, v26
	tbnz	w10, #7, LBB0_451
	b	LBB0_452
LBB0_430:                               ; %else559
	tbz	w12, #1, LBB0_406
LBB0_431:                               ; %cond.load561
	add	x14, x11, #4
	ld1.s	{ v22 }[1], [x14]
	tbnz	w12, #2, LBB0_407
LBB0_432:                               ; %else565
	tbz	w12, #3, LBB0_408
LBB0_433:                               ; %cond.load567
	add	x14, x11, #12
	ld1.s	{ v22 }[3], [x14]
	tbnz	w12, #4, LBB0_409
LBB0_434:                               ; %else571
	tbz	w12, #5, LBB0_410
LBB0_435:                               ; %cond.load573
	add	x14, x11, #20
	ld1.s	{ v17 }[1], [x14]
	tbnz	w12, #6, LBB0_411
	b	LBB0_412
LBB0_436:                               ; %else584
	tbz	w12, #1, LBB0_416
LBB0_437:                               ; %cond.load586
	add	x14, x10, #4
	ld1.s	{ v20 }[1], [x14]
	tbnz	w12, #2, LBB0_417
LBB0_438:                               ; %else590
	tbz	w12, #3, LBB0_418
LBB0_439:                               ; %cond.load592
	add	x14, x10, #12
	ld1.s	{ v20 }[3], [x14]
	tbnz	w12, #4, LBB0_419
LBB0_440:                               ; %else596
	tbz	w12, #5, LBB0_420
LBB0_441:                               ; %cond.load598
	add	x14, x10, #20
	ld1.s	{ v16 }[1], [x14]
	tbnz	w12, #6, LBB0_421
LBB0_442:                               ; %else602
	tbz	w12, #7, LBB0_422
LBB0_443:                               ; %cond.load604
	add	x10, x10, #28
	ld1.s	{ v16 }[3], [x10]
	add	x9, x9, x11
	fmov	w10, s7
	movi.2d	v24, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w10, #0, LBB0_423
LBB0_444:                               ; %else609
	tbz	w10, #1, LBB0_424
LBB0_445:                               ; %cond.load611
	add	x11, x9, #4
	ld1.s	{ v24 }[1], [x11]
	tbnz	w10, #2, LBB0_425
LBB0_446:                               ; %else615
	tbz	w10, #3, LBB0_426
LBB0_447:                               ; %cond.load617
	add	x11, x9, #12
	ld1.s	{ v24 }[3], [x11]
	tbnz	w10, #4, LBB0_427
LBB0_448:                               ; %else621
	tbz	w10, #5, LBB0_428
LBB0_449:                               ; %cond.load623
	add	x11, x9, #20
	ld1.s	{ v23 }[1], [x11]
	tbnz	w10, #6, LBB0_429
LBB0_450:                               ; %else627
	add.2d	v21, v21, v25
	add.2d	v25, v18, v27
	add.2d	v19, v19, v26
	tbz	w10, #7, LBB0_452
LBB0_451:                               ; %cond.load629
	add	x9, x9, #28
	ld1.s	{ v23 }[3], [x9]
LBB0_452:                               ; %else630
	fmul.4s	v18, v0, v20
	fmul.4s	v26, v22, v24
	fsub.4s	v18, v18, v26
	stp	q2, q25, [sp, #624]
	stp	q21, q19, [sp, #656]
	and	x9, x13, #0x7
	add	x10, sp, #624
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x13
	add	x9, x8, x9, lsl #2
	fmov	w10, s7
	tbz	w10, #0, LBB0_460
; %bb.453:                              ; %cond.store633
	str	s18, [x9]
	tbnz	w10, #1, LBB0_461
LBB0_454:                               ; %else636
	tbz	w10, #2, LBB0_462
LBB0_455:                               ; %cond.store637
	add	x11, x9, #8
	st1.s	{ v18 }[2], [x11]
	fmul.4s	v2, v1, v16
	fmul.4s	v19, v17, v23
	tbnz	w10, #3, LBB0_463
LBB0_456:                               ; %else640
	fsub.4s	v2, v2, v19
	tbz	w10, #4, LBB0_464
LBB0_457:                               ; %cond.store641
	str	s2, [x9, #16]
	tbnz	w10, #5, LBB0_465
LBB0_458:                               ; %else644
	tbz	w10, #6, LBB0_466
LBB0_459:                               ; %cond.store645
	add	x11, x9, #24
	st1.s	{ v2 }[2], [x11]
	tbnz	w10, #7, LBB0_467
	b	LBB0_468
LBB0_460:                               ; %else634
	tbz	w10, #1, LBB0_454
LBB0_461:                               ; %cond.store635
	add	x11, x9, #4
	st1.s	{ v18 }[1], [x11]
	tbnz	w10, #2, LBB0_455
LBB0_462:                               ; %else638
	fmul.4s	v2, v1, v16
	fmul.4s	v19, v17, v23
	tbz	w10, #3, LBB0_456
LBB0_463:                               ; %cond.store639
	add	x11, x9, #12
	st1.s	{ v18 }[3], [x11]
	fsub.4s	v2, v2, v19
	tbnz	w10, #4, LBB0_457
LBB0_464:                               ; %else642
	tbz	w10, #5, LBB0_458
LBB0_465:                               ; %cond.store643
	add	x11, x9, #20
	st1.s	{ v2 }[1], [x11]
	tbnz	w10, #6, LBB0_459
LBB0_466:                               ; %else646
	tbz	w10, #7, LBB0_468
LBB0_467:                               ; %cond.store647
	add	x9, x9, #28
	st1.s	{ v2 }[3], [x9]
LBB0_468:                               ; %else648
	fmul.4s	v0, v0, v24
	fmul.4s	v2, v22, v20
	fadd.4s	v0, v2, v0
	stp	q6, q5, [sp, #560]
	stp	q4, q3, [sp, #592]
	and	x9, x13, #0x7
	add	x10, sp, #560
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x13
	add	x8, x8, x9, lsl #2
	fmov	w9, s7
	tbz	w9, #0, LBB0_476
; %bb.469:                              ; %cond.store650
	str	s0, [x8]
	tbnz	w9, #1, LBB0_477
LBB0_470:                               ; %else653
	tbz	w9, #2, LBB0_478
LBB0_471:                               ; %cond.store654
	add	x10, x8, #8
	st1.s	{ v0 }[2], [x10]
	fmul.4s	v1, v1, v23
	fmul.4s	v2, v17, v16
	tbnz	w9, #3, LBB0_479
LBB0_472:                               ; %else657
	fadd.4s	v0, v2, v1
	tbz	w9, #4, LBB0_950
LBB0_473:                               ; %cond.store658
	str	s0, [x8, #16]
	tbnz	w9, #5, LBB0_951
LBB0_474:                               ; %else661
	tbz	w9, #6, LBB0_952
LBB0_475:                               ; %cond.store662
	add	x10, x8, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_953
	b	LBB0_954
LBB0_476:                               ; %else651
	tbz	w9, #1, LBB0_470
LBB0_477:                               ; %cond.store652
	add	x10, x8, #4
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #2, LBB0_471
LBB0_478:                               ; %else655
	fmul.4s	v1, v1, v23
	fmul.4s	v2, v17, v16
	tbz	w9, #3, LBB0_472
LBB0_479:                               ; %cond.store656
	add	x10, x8, #12
	st1.s	{ v0 }[3], [x10]
	fadd.4s	v0, v2, v1
	tbz	w9, #4, LBB0_950
	b	LBB0_473
LBB0_480:                               ; %direct.false
	ldr	q2, [x17, lCPI0_6@PAGEOFF]
	and.16b	v2, v18, v2
	addv.8h	h17, v2
	fmov	w15, s17
	and	w13, w15, #0xff
	movi.2s	v2, #66
	umull.2d	v2, v1, v2
	add.2d	v21, v2, v6
	fmov	x14, d21
	add	x14, x11, x14, lsl #2
	tbz	w15, #0, LBB0_482
; %bb.481:                              ; %cond.load667
	ldr	s1, [x14]
	tbnz	w13, #1, LBB0_483
	b	LBB0_484
LBB0_482:
                                        ; implicit-def: $q1
	tbz	w13, #1, LBB0_484
LBB0_483:                               ; %cond.load670
	add	x15, x14, #4
	ld1.s	{ v1 }[1], [x15]
LBB0_484:                               ; %else671
	tbz	w13, #2, LBB0_488
; %bb.485:                              ; %cond.load673
	add	x15, x14, #8
	ld1.s	{ v1 }[2], [x15]
	tbnz	w13, #3, LBB0_489
LBB0_486:                               ; %else677
	tbz	w13, #4, LBB0_490
LBB0_487:                               ; %cond.load679
	add	x15, x14, #16
	ld1.s	{ v3 }[0], [x15]
	tbnz	w13, #5, LBB0_491
	b	LBB0_492
LBB0_488:                               ; %else674
	tbz	w13, #3, LBB0_486
LBB0_489:                               ; %cond.load676
	add	x15, x14, #12
	ld1.s	{ v1 }[3], [x15]
	tbnz	w13, #4, LBB0_487
LBB0_490:
                                        ; implicit-def: $q3
	tbz	w13, #5, LBB0_492
LBB0_491:                               ; %cond.load682
	add	x15, x14, #20
	ld1.s	{ v3 }[1], [x15]
LBB0_492:                               ; %else683
	tbz	w13, #6, LBB0_494
; %bb.493:                              ; %cond.load685
	add	x15, x14, #24
	ld1.s	{ v3 }[2], [x15]
	tbnz	w13, #7, LBB0_495
	b	LBB0_496
LBB0_494:                               ; %else686
	tbz	w13, #7, LBB0_496
LBB0_495:                               ; %cond.load688
	add	x13, x14, #28
	ld1.s	{ v3 }[3], [x13]
LBB0_496:                               ; %else689
	fmov	w15, s17
	and	w13, w15, #0xff
	str	q1, [sp, #1920]
	str	q3, [sp, #1936]
	mov	w14, #8                         ; =0x8
	dup.2d	v1, x14
	add.2d	v11, v21, v1
	fmov	x14, d11
	add	x14, x11, x14, lsl #2
	tbz	w15, #0, LBB0_498
; %bb.497:                              ; %cond.load692
	ldr	s1, [x14]
	tbnz	w13, #1, LBB0_499
	b	LBB0_500
LBB0_498:
                                        ; implicit-def: $q1
	tbz	w13, #1, LBB0_500
LBB0_499:                               ; %cond.load695
	add	x15, x14, #4
	ld1.s	{ v1 }[1], [x15]
LBB0_500:                               ; %else696
	tbz	w13, #2, LBB0_504
; %bb.501:                              ; %cond.load698
	add	x15, x14, #8
	ld1.s	{ v1 }[2], [x15]
	tbnz	w13, #3, LBB0_505
LBB0_502:                               ; %else702
	tbz	w13, #4, LBB0_506
LBB0_503:                               ; %cond.load704
	add	x15, x14, #16
	ld1.s	{ v3 }[0], [x15]
	tbnz	w13, #5, LBB0_507
	b	LBB0_508
LBB0_504:                               ; %else699
	tbz	w13, #3, LBB0_502
LBB0_505:                               ; %cond.load701
	add	x15, x14, #12
	ld1.s	{ v1 }[3], [x15]
	tbnz	w13, #4, LBB0_503
LBB0_506:
                                        ; implicit-def: $q3
	tbz	w13, #5, LBB0_508
LBB0_507:                               ; %cond.load707
	add	x15, x14, #20
	ld1.s	{ v3 }[1], [x15]
LBB0_508:                               ; %else708
	tbz	w13, #6, LBB0_510
; %bb.509:                              ; %cond.load710
	add	x15, x14, #24
	ld1.s	{ v3 }[2], [x15]
	tbnz	w13, #7, LBB0_511
	b	LBB0_512
LBB0_510:                               ; %else711
	tbz	w13, #7, LBB0_512
LBB0_511:                               ; %cond.load713
	add	x13, x14, #28
	ld1.s	{ v3 }[3], [x13]
LBB0_512:                               ; %else714
	fmov	w15, s17
	and	w13, w15, #0xff
	str	q1, [sp, #1952]
	str	q3, [sp, #1968]
	mov	w14, #16                        ; =0x10
	dup.2d	v1, x14
	add.2d	v15, v21, v1
	fmov	x14, d15
	add	x14, x11, x14, lsl #2
	tbz	w15, #0, LBB0_514
; %bb.513:                              ; %cond.load717
	ldr	s1, [x14]
	tbnz	w13, #1, LBB0_515
	b	LBB0_516
LBB0_514:
                                        ; implicit-def: $q1
	tbz	w13, #1, LBB0_516
LBB0_515:                               ; %cond.load720
	add	x15, x14, #4
	ld1.s	{ v1 }[1], [x15]
LBB0_516:                               ; %else721
	tbz	w13, #2, LBB0_520
; %bb.517:                              ; %cond.load723
	add	x15, x14, #8
	ld1.s	{ v1 }[2], [x15]
	tbnz	w13, #3, LBB0_521
LBB0_518:                               ; %else727
	tbz	w13, #4, LBB0_522
LBB0_519:                               ; %cond.load729
	add	x15, x14, #16
	ld1.s	{ v3 }[0], [x15]
	tbnz	w13, #5, LBB0_523
	b	LBB0_524
LBB0_520:                               ; %else724
	tbz	w13, #3, LBB0_518
LBB0_521:                               ; %cond.load726
	add	x15, x14, #12
	ld1.s	{ v1 }[3], [x15]
	tbnz	w13, #4, LBB0_519
LBB0_522:
                                        ; implicit-def: $q3
	tbz	w13, #5, LBB0_524
LBB0_523:                               ; %cond.load732
	add	x15, x14, #20
	ld1.s	{ v3 }[1], [x15]
LBB0_524:                               ; %else733
	tbz	w13, #6, LBB0_526
; %bb.525:                              ; %cond.load735
	add	x15, x14, #24
	ld1.s	{ v3 }[2], [x15]
	tbnz	w13, #7, LBB0_527
	b	LBB0_528
LBB0_526:                               ; %else736
	tbz	w13, #7, LBB0_528
LBB0_527:                               ; %cond.load738
	add	x13, x14, #28
	ld1.s	{ v3 }[3], [x13]
LBB0_528:                               ; %else739
	fmov	w15, s17
	and	w13, w15, #0xff
	str	q1, [sp, #1984]
	str	q3, [sp, #2000]
	mov	w14, #24                        ; =0x18
	dup.2d	v1, x14
	add.2d	v1, v21, v1
	str	q1, [sp, #528]                  ; 16-byte Spill
	fmov	x14, d1
	add	x14, x11, x14, lsl #2
	tbz	w15, #0, LBB0_530
; %bb.529:                              ; %cond.load742
	ldr	s1, [x14]
	tbnz	w13, #1, LBB0_531
	b	LBB0_532
LBB0_530:
                                        ; implicit-def: $q1
	tbz	w13, #1, LBB0_532
LBB0_531:                               ; %cond.load745
	add	x15, x14, #4
	ld1.s	{ v1 }[1], [x15]
LBB0_532:                               ; %else746
	tbz	w13, #2, LBB0_536
; %bb.533:                              ; %cond.load748
	add	x15, x14, #8
	ld1.s	{ v1 }[2], [x15]
	tbnz	w13, #3, LBB0_537
LBB0_534:                               ; %else752
	tbz	w13, #4, LBB0_538
LBB0_535:                               ; %cond.load754
	add	x15, x14, #16
	ld1.s	{ v3 }[0], [x15]
	tbnz	w13, #5, LBB0_539
	b	LBB0_540
LBB0_536:                               ; %else749
	tbz	w13, #3, LBB0_534
LBB0_537:                               ; %cond.load751
	add	x15, x14, #12
	ld1.s	{ v1 }[3], [x15]
	tbnz	w13, #4, LBB0_535
LBB0_538:
                                        ; implicit-def: $q3
	tbz	w13, #5, LBB0_540
LBB0_539:                               ; %cond.load757
	add	x15, x14, #20
	ld1.s	{ v3 }[1], [x15]
LBB0_540:                               ; %else758
	tbz	w13, #6, LBB0_542
; %bb.541:                              ; %cond.load760
	add	x15, x14, #24
	ld1.s	{ v3 }[2], [x15]
	tbnz	w13, #7, LBB0_543
	b	LBB0_544
LBB0_542:                               ; %else761
	tbz	w13, #7, LBB0_544
LBB0_543:                               ; %cond.load763
	add	x13, x14, #28
	ld1.s	{ v3 }[3], [x13]
LBB0_544:                               ; %else764
	xtn.8b	v4, v18
	str	q1, [sp, #2016]
	str	q3, [sp, #2032]
	movi.8b	v1, #1
	and.8b	v1, v4, v1
	umov.b	w14, v1[0]
	movi.2d	v3, #0000000000000000
	movi.2d	v18, #0000000000000000
	mov.b	v18[0], v4[0]
	umaxv.8b	b1, v18
	fmov	w1, s1
	rbit	w13, w14
	clz	w13, w13
	tst	w1, #0x1
	mov	w15, #32                        ; =0x20
	dup.2d	v1, x15
	csel	w13, w13, wzr, ne
	orr.16b	v5, v6, v1
	mov.16b	v24, v5
	add.2d	v5, v2, v5
	movi.2d	v7, #0000000000000000
	mov.b	v7[0], v4[0]
	ushll.2d	v4, v7, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v4, v4, v5
	str	q3, [sp, #1344]
	str	q3, [sp, #1328]
	str	q3, [sp, #1312]
	str	q4, [sp, #1296]
	ubfiz	x15, x13, #3, #3
	add	x16, sp, #1296
	ldr	x16, [x16, x15]
	sub	x16, x16, x13
	add	x17, x11, x16, lsl #2
Lloh12:
	adrp	x16, lCPI0_26@PAGE
Lloh13:
	ldr	q3, [x16, lCPI0_26@PAGEOFF]
Lloh14:
	adrp	x16, lCPI0_27@PAGE
Lloh15:
	ldr	q4, [x16, lCPI0_27@PAGEOFF]
	str	q3, [sp, #1408]
	str	q4, [sp, #1392]
Lloh16:
	adrp	x16, lCPI0_28@PAGE
Lloh17:
	ldr	q3, [x16, lCPI0_28@PAGEOFF]
Lloh18:
	adrp	x16, lCPI0_29@PAGE
Lloh19:
	ldr	q4, [x16, lCPI0_29@PAGEOFF]
	str	q3, [sp, #1376]
	str	q4, [sp, #1360]
	add	x16, sp, #1360
	ldr	x16, [x16, x15]
	ubfiz	x15, x13, #2, #32
	sub	x16, x16, x15
	tst	w14, #0x1
	csel	x16, xzr, x16, eq
	add	x0, sp, #1920
	add	x0, x0, x16
	ldr	q3, [x0]
	tbz	w1, #0, LBB0_552
; %bb.545:                              ; %cond.load767
	ld1.s	{ v3 }[0], [x17]
	tbnz	w14, #1, LBB0_553
LBB0_546:                               ; %else771
	tbz	w14, #2, LBB0_554
LBB0_547:                               ; %cond.load773
	add	x1, x17, #8
	ld1.s	{ v3 }[2], [x1]
	tbnz	w14, #3, LBB0_555
LBB0_548:                               ; %else777
	ldr	q4, [x0, #16]
	tbz	w14, #4, LBB0_556
LBB0_549:                               ; %cond.load779
	add	x0, x17, #16
	ld1.s	{ v4 }[0], [x0]
	tbnz	w14, #5, LBB0_557
LBB0_550:                               ; %else783
	sshll.2d	v12, v16, #0
	tbz	w14, #6, LBB0_558
LBB0_551:                               ; %cond.load785
	add	x0, x17, #24
	ld1.s	{ v4 }[2], [x0]
	and.16b	v7, v12, v2
	tbnz	w14, #7, LBB0_559
	b	LBB0_560
LBB0_552:                               ; %else768
	tbz	w14, #1, LBB0_546
LBB0_553:                               ; %cond.load770
	add	x1, x17, #4
	ld1.s	{ v3 }[1], [x1]
	tbnz	w14, #2, LBB0_547
LBB0_554:                               ; %else774
	tbz	w14, #3, LBB0_548
LBB0_555:                               ; %cond.load776
	add	x1, x17, #12
	ld1.s	{ v3 }[3], [x1]
	ldr	q4, [x0, #16]
	tbnz	w14, #4, LBB0_549
LBB0_556:                               ; %else780
	tbz	w14, #5, LBB0_550
LBB0_557:                               ; %cond.load782
	add	x0, x17, #20
	ld1.s	{ v4 }[1], [x0]
	sshll.2d	v12, v16, #0
	tbnz	w14, #6, LBB0_551
LBB0_558:                               ; %else786
	and.16b	v7, v12, v2
	tbz	w14, #7, LBB0_560
LBB0_559:                               ; %cond.load788
	add	x17, x17, #28
	ld1.s	{ v4 }[3], [x17]
LBB0_560:                               ; %else789
	fmov	w1, s17
	and	w17, w1, #0xff
	add	x0, sp, #1920
	add	x0, x0, x16
	stp	q3, q4, [x0]
	add.2d	v3, v6, v7
	mov	w0, #33                         ; =0x21
	dup.2d	v2, x0
	add.2d	v2, v3, v2
	str	q2, [sp, #512]                  ; 16-byte Spill
	fmov	x0, d2
	add	x0, x11, x0, lsl #2
	tbz	w1, #0, LBB0_562
; %bb.561:                              ; %cond.load792
	ldr	s4, [x0]
	tbnz	w17, #1, LBB0_563
	b	LBB0_564
LBB0_562:
                                        ; implicit-def: $q4
	tbz	w17, #1, LBB0_564
LBB0_563:                               ; %cond.load795
	add	x1, x0, #4
	ld1.s	{ v4 }[1], [x1]
LBB0_564:                               ; %else796
	tbz	w17, #2, LBB0_568
; %bb.565:                              ; %cond.load798
	add	x1, x0, #8
	ld1.s	{ v4 }[2], [x1]
	tbnz	w17, #3, LBB0_569
LBB0_566:                               ; %else802
	tbz	w17, #4, LBB0_570
LBB0_567:                               ; %cond.load804
	add	x1, x0, #16
	ld1.s	{ v5 }[0], [x1]
	adrp	x1, lCPI0_14@PAGE
	tbnz	w17, #5, LBB0_571
	b	LBB0_572
LBB0_568:                               ; %else799
	tbz	w17, #3, LBB0_566
LBB0_569:                               ; %cond.load801
	add	x1, x0, #12
	ld1.s	{ v4 }[3], [x1]
	tbnz	w17, #4, LBB0_567
LBB0_570:
                                        ; implicit-def: $q5
	adrp	x1, lCPI0_14@PAGE
	tbz	w17, #5, LBB0_572
LBB0_571:                               ; %cond.load807
	add	x2, x0, #20
	ld1.s	{ v5 }[1], [x2]
LBB0_572:                               ; %else808
	sshll.2d	v13, v16, #0
	ldr	q2, [x1, lCPI0_14@PAGEOFF]
	tbz	w17, #6, LBB0_574
; %bb.573:                              ; %cond.load810
	add	x1, x0, #24
	ld1.s	{ v5 }[2], [x1]
	and.16b	v2, v13, v2
	tbnz	w17, #7, LBB0_575
	b	LBB0_576
LBB0_574:                               ; %else811
	and.16b	v2, v13, v2
	tbz	w17, #7, LBB0_576
LBB0_575:                               ; %cond.load813
	add	x17, x0, #28
	ld1.s	{ v5 }[3], [x17]
LBB0_576:                               ; %else814
	fmov	w1, s17
	and	w17, w1, #0xff
	str	q4, [sp, #1760]
	str	q5, [sp, #1776]
	mov	w0, #33                         ; =0x21
	dup.2d	v4, x0
	add.2d	v4, v7, v4
	add.2d	v5, v4, v2
	str	q5, [sp, #496]                  ; 16-byte Spill
	fmov	x0, d5
	add	x0, x11, x0, lsl #2
	tbz	w1, #0, LBB0_578
; %bb.577:                              ; %cond.load817
	ldr	s5, [x0]
	tbnz	w17, #1, LBB0_579
	b	LBB0_580
LBB0_578:
                                        ; implicit-def: $q5
	tbz	w17, #1, LBB0_580
LBB0_579:                               ; %cond.load820
	add	x1, x0, #4
	ld1.s	{ v5 }[1], [x1]
LBB0_580:                               ; %else821
	tbz	w17, #2, LBB0_584
; %bb.581:                              ; %cond.load823
	add	x1, x0, #8
	ld1.s	{ v5 }[2], [x1]
	tbnz	w17, #3, LBB0_585
LBB0_582:                               ; %else827
	str	q7, [sp, #480]                  ; 16-byte Spill
	tbz	w17, #4, LBB0_586
LBB0_583:                               ; %cond.load829
	add	x1, x0, #16
	ld1.s	{ v7 }[0], [x1]
	adrp	x1, lCPI0_19@PAGE
	tbnz	w17, #5, LBB0_587
	b	LBB0_588
LBB0_584:                               ; %else824
	tbz	w17, #3, LBB0_582
LBB0_585:                               ; %cond.load826
	add	x1, x0, #12
	ld1.s	{ v5 }[3], [x1]
	str	q7, [sp, #480]                  ; 16-byte Spill
	tbnz	w17, #4, LBB0_583
LBB0_586:
                                        ; implicit-def: $q7
	adrp	x1, lCPI0_19@PAGE
	tbz	w17, #5, LBB0_588
LBB0_587:                               ; %cond.load832
	add	x2, x0, #20
	ld1.s	{ v7 }[1], [x2]
LBB0_588:                               ; %else833
	sshll.2d	v14, v16, #0
	ldr	q19, [x1, lCPI0_19@PAGEOFF]
	tbz	w17, #6, LBB0_590
; %bb.589:                              ; %cond.load835
	add	x1, x0, #24
	ld1.s	{ v7 }[2], [x1]
	and.16b	v27, v14, v19
	tbnz	w17, #7, LBB0_591
	b	LBB0_592
LBB0_590:                               ; %else836
	and.16b	v27, v14, v19
	tbz	w17, #7, LBB0_592
LBB0_591:                               ; %cond.load838
	add	x17, x0, #28
	ld1.s	{ v7 }[3], [x17]
LBB0_592:                               ; %else839
	fmov	w1, s17
	and	w17, w1, #0xff
	str	q5, [sp, #1792]
	str	q7, [sp, #1808]
	add.2d	v5, v4, v27
	str	q5, [sp, #464]                  ; 16-byte Spill
	fmov	x0, d5
	add	x0, x11, x0, lsl #2
	tbz	w1, #0, LBB0_594
; %bb.593:                              ; %cond.load842
	ldr	s5, [x0]
	tbnz	w17, #1, LBB0_595
	b	LBB0_596
LBB0_594:
                                        ; implicit-def: $q5
	tbz	w17, #1, LBB0_596
LBB0_595:                               ; %cond.load845
	add	x1, x0, #4
	ld1.s	{ v5 }[1], [x1]
LBB0_596:                               ; %else846
	tbz	w17, #2, LBB0_600
; %bb.597:                              ; %cond.load848
	add	x1, x0, #8
	ld1.s	{ v5 }[2], [x1]
	tbnz	w17, #3, LBB0_601
LBB0_598:                               ; %else852
	tbz	w17, #4, LBB0_602
LBB0_599:                               ; %cond.load854
	add	x1, x0, #16
	ld1.s	{ v7 }[0], [x1]
	adrp	x1, lCPI0_24@PAGE
	tbnz	w17, #5, LBB0_603
	b	LBB0_604
LBB0_600:                               ; %else849
	tbz	w17, #3, LBB0_598
LBB0_601:                               ; %cond.load851
	add	x1, x0, #12
	ld1.s	{ v5 }[3], [x1]
	tbnz	w17, #4, LBB0_599
LBB0_602:
                                        ; implicit-def: $q7
	adrp	x1, lCPI0_24@PAGE
	tbz	w17, #5, LBB0_604
LBB0_603:                               ; %cond.load857
	add	x2, x0, #20
	ld1.s	{ v7 }[1], [x2]
LBB0_604:                               ; %else858
	sshll.2d	v20, v16, #0
	ldr	q19, [x1, lCPI0_24@PAGEOFF]
	tbz	w17, #6, LBB0_606
; %bb.605:                              ; %cond.load860
	add	x1, x0, #24
	ld1.s	{ v7 }[2], [x1]
	and.16b	v29, v20, v19
	tbnz	w17, #7, LBB0_607
	b	LBB0_608
LBB0_606:                               ; %else861
	and.16b	v29, v20, v19
	tbz	w17, #7, LBB0_608
LBB0_607:                               ; %cond.load863
	add	x17, x0, #28
	ld1.s	{ v7 }[3], [x17]
LBB0_608:                               ; %else864
	fmov	w17, s17
	and	w2, w17, #0xff
	str	q5, [sp, #1824]
	str	q7, [sp, #1840]
	add.2d	v4, v4, v29
	str	q4, [sp, #448]                  ; 16-byte Spill
	fmov	x0, d4
	add	x3, x11, x0, lsl #2
	tbz	w17, #0, LBB0_610
; %bb.609:                              ; %cond.load867
	ldr	s4, [x3]
	tbnz	w2, #1, LBB0_611
	b	LBB0_612
LBB0_610:
                                        ; implicit-def: $q4
	tbz	w2, #1, LBB0_612
LBB0_611:                               ; %cond.load870
	add	x17, x3, #4
	ld1.s	{ v4 }[1], [x17]
LBB0_612:                               ; %else871
	fmov	x17, d26
	fmov	x1, d31
	fmov	x4, d28
	tbz	w2, #2, LBB0_614
; %bb.613:                              ; %cond.load873
	add	x0, x3, #8
	ld1.s	{ v4 }[2], [x0]
LBB0_614:                               ; %else874
	add	x17, x17, x17, lsl #5
	mov.d	x0, v26[1]
	add	x1, x1, x1, lsl #5
	mov.d	x5, v31[1]
	mov.d	x19, v28[1]
	add	x7, x4, x4, lsl #5
	tbz	w2, #3, LBB0_616
; %bb.615:                              ; %cond.load876
	add	x4, x3, #12
	ld1.s	{ v4 }[3], [x4]
LBB0_616:                               ; %else877
	lsl	x4, x17, #1
	add	x17, x0, x0, lsl #5
	lsl	x6, x1, #1
	add	x0, x5, x5, lsl #5
	lsl	x7, x7, #1
	add	x1, x19, x19, lsl #5
	str	q20, [sp, #368]                 ; 16-byte Spill
	tbz	w2, #4, LBB0_618
; %bb.617:                              ; %cond.load879
	add	x5, x3, #16
	ld1.s	{ v5 }[0], [x5]
	b	LBB0_619
LBB0_618:
                                        ; implicit-def: $q5
LBB0_619:                               ; %else880
	lsl	x5, x17, #1
	fmov	d7, x4
	fmov	d19, x6
	lsl	x4, x0, #1
	fmov	d20, x7
	lsl	x6, x1, #1
	tbz	w2, #5, LBB0_631
; %bb.620:                              ; %cond.load882
	add	x7, x3, #20
	ld1.s	{ v5 }[1], [x7]
	sshll.2d	v30, v23, #0
	mov.d	v7[1], x5
	mov.d	v19[1], x4
	mov.d	v20[1], x6
	tbnz	w2, #6, LBB0_632
LBB0_621:                               ; %else886
	and.16b	v20, v22, v20
	and.16b	v19, v30, v19
	and.16b	v7, v25, v7
	str	q30, [sp, #352]                 ; 16-byte Spill
	tbz	w2, #7, LBB0_623
LBB0_622:                               ; %cond.load888
	add	x2, x3, #28
	ld1.s	{ v5 }[3], [x2]
LBB0_623:                               ; %else889
	str	q4, [sp, #1856]
	str	q5, [sp, #1872]
	stp	q19, q20, [sp, #320]            ; 32-byte Folded Spill
	add.2d	v4, v9, v20
	add.2d	v5, v10, v19
	str	q7, [sp, #304]                  ; 16-byte Spill
	add.2d	v7, v8, v7
	mov	w2, #65                         ; =0x41
	dup.2d	v19, x2
	add.2d	v20, v7, v19
	add.2d	v30, v5, v19
	add.2d	v5, v4, v19
	add.2d	v4, v3, v19
	mov	b3, v18[0]
	mov.b	v3[4], v18[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	stp	q4, q5, [sp, #384]              ; 32-byte Folded Spill
	and.16b	v3, v3, v4
	mov	b4, v18[2]
	mov.b	v4[4], v18[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v4, v4, v5
	mov	b5, v18[4]
	mov.b	v5[4], v18[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	mov	b7, v18[6]
	mov.b	v7[4], v18[7]
	stp	q30, q20, [sp, #416]            ; 32-byte Folded Spill
	and.16b	v5, v5, v30
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v20
	ldr	d19, [x12, lCPI0_30@PAGEOFF]
	shl.8b	v20, v18, #7
	cmlt.8b	v20, v20, #0
	and.8b	v19, v20, v19
	addv.8b	b19, v19
	str	q7, [sp, #1264]
	str	q5, [sp, #1248]
	str	q4, [sp, #1232]
	str	q3, [sp, #1216]
	and	x12, x13, #0x7
	add	x2, sp, #1216
	ldr	x2, [x2, x12, lsl #3]
	str	d19, [sp, #552]                 ; 8-byte Spill
	fmov	w12, s19
	sub	x2, x2, x13
	add	x11, x11, x2, lsl #2
	add	x2, sp, #1760
	add	x2, x2, x16
	ldr	q3, [x2]
	tbz	w12, #0, LBB0_633
; %bb.624:                              ; %cond.load892
	ld1.s	{ v3 }[0], [x11]
	tbnz	w12, #1, LBB0_634
LBB0_625:                               ; %else896
	tbz	w12, #2, LBB0_635
LBB0_626:                               ; %cond.load898
	add	x3, x11, #8
	ld1.s	{ v3 }[2], [x3]
	tbnz	w12, #3, LBB0_636
LBB0_627:                               ; %else902
	ldr	q4, [x2, #16]
	tbz	w12, #4, LBB0_637
LBB0_628:                               ; %cond.load904
	add	x2, x11, #16
	ld1.s	{ v4 }[0], [x2]
	tbnz	w12, #5, LBB0_638
LBB0_629:                               ; %else908
	tbz	w12, #6, LBB0_639
LBB0_630:                               ; %cond.load910
	add	x2, x11, #24
	ld1.s	{ v4 }[2], [x2]
	tbnz	w12, #7, LBB0_640
	b	LBB0_641
LBB0_631:                               ; %else883
	sshll.2d	v30, v23, #0
	mov.d	v7[1], x5
	mov.d	v19[1], x4
	mov.d	v20[1], x6
	tbz	w2, #6, LBB0_621
LBB0_632:                               ; %cond.load885
	add	x4, x3, #24
	ld1.s	{ v5 }[2], [x4]
	and.16b	v20, v22, v20
	and.16b	v19, v30, v19
	and.16b	v7, v25, v7
	str	q30, [sp, #352]                 ; 16-byte Spill
	tbnz	w2, #7, LBB0_622
	b	LBB0_623
LBB0_633:                               ; %else893
	tbz	w12, #1, LBB0_625
LBB0_634:                               ; %cond.load895
	add	x3, x11, #4
	ld1.s	{ v3 }[1], [x3]
	tbnz	w12, #2, LBB0_626
LBB0_635:                               ; %else899
	tbz	w12, #3, LBB0_627
LBB0_636:                               ; %cond.load901
	add	x3, x11, #12
	ld1.s	{ v3 }[3], [x3]
	ldr	q4, [x2, #16]
	tbnz	w12, #4, LBB0_628
LBB0_637:                               ; %else905
	tbz	w12, #5, LBB0_629
LBB0_638:                               ; %cond.load907
	add	x2, x11, #20
	ld1.s	{ v4 }[1], [x2]
	tbnz	w12, #6, LBB0_630
LBB0_639:                               ; %else911
	tbz	w12, #7, LBB0_641
LBB0_640:                               ; %cond.load913
	add	x11, x11, #28
	ld1.s	{ v4 }[3], [x11]
LBB0_641:                               ; %else914
	fmov	w2, s17
	and	w11, w2, #0xff
	fmov	x12, d0
	add	x12, x12, x12, lsl #5
	fmov	d5, x12
	mov.d	x12, v0[1]
	sshll.2d	v30, v16, #0
	add	x12, x12, x12, lsl #5
	mov.d	v5[1], x12
	add	x12, sp, #1760
	add	x12, x12, x16
	stp	q3, q4, [x12]
	and.16b	v5, v30, v5
	add.2d	v4, v5, v6
	fmov	x12, d4
	add	x12, x10, x12, lsl #2
	ldr	q0, [sp, #1600]
	tbz	w2, #0, LBB0_649
; %bb.642:                              ; %cond.load917
	ld1.s	{ v0 }[0], [x12]
	tbnz	w11, #1, LBB0_650
LBB0_643:                               ; %else921
	tbz	w11, #2, LBB0_651
LBB0_644:                               ; %cond.load923
	add	x2, x12, #8
	ld1.s	{ v0 }[2], [x2]
	tbnz	w11, #3, LBB0_652
LBB0_645:                               ; %else927
	ldr	q3, [sp, #1616]
	tbz	w11, #4, LBB0_653
LBB0_646:                               ; %cond.load929
	add	x2, x12, #16
	ld1.s	{ v3 }[0], [x2]
	tbnz	w11, #5, LBB0_654
LBB0_647:                               ; %else933
	tbz	w11, #6, LBB0_655
LBB0_648:                               ; %cond.load935
	add	x2, x12, #24
	ld1.s	{ v3 }[2], [x2]
	tbnz	w11, #7, LBB0_656
	b	LBB0_657
LBB0_649:                               ; %else918
	tbz	w11, #1, LBB0_643
LBB0_650:                               ; %cond.load920
	add	x2, x12, #4
	ld1.s	{ v0 }[1], [x2]
	tbnz	w11, #2, LBB0_644
LBB0_651:                               ; %else924
	tbz	w11, #3, LBB0_645
LBB0_652:                               ; %cond.load926
	add	x2, x12, #12
	ld1.s	{ v0 }[3], [x2]
	ldr	q3, [sp, #1616]
	tbnz	w11, #4, LBB0_646
LBB0_653:                               ; %else930
	tbz	w11, #5, LBB0_647
LBB0_654:                               ; %cond.load932
	add	x2, x12, #20
	ld1.s	{ v3 }[1], [x2]
	tbnz	w11, #6, LBB0_648
LBB0_655:                               ; %else936
	tbz	w11, #7, LBB0_657
LBB0_656:                               ; %cond.load938
	add	x11, x12, #28
	ld1.s	{ v3 }[3], [x11]
LBB0_657:                               ; %else939
	fmov	w2, s17
	and	w11, w2, #0xff
	str	q0, [sp, #1600]
	str	q3, [sp, #1616]
	add.2d	v3, v5, v2
	fmov	x12, d3
	add	x12, x10, x12, lsl #2
	ldr	q0, [sp, #1632]
	tbz	w2, #0, LBB0_665
; %bb.658:                              ; %cond.load942
	ld1.s	{ v0 }[0], [x12]
	tbnz	w11, #1, LBB0_666
LBB0_659:                               ; %else946
	tbz	w11, #2, LBB0_667
LBB0_660:                               ; %cond.load948
	add	x2, x12, #8
	ld1.s	{ v0 }[2], [x2]
	tbnz	w11, #3, LBB0_668
LBB0_661:                               ; %else952
	ldr	q2, [sp, #1648]
	tbz	w11, #4, LBB0_669
LBB0_662:                               ; %cond.load954
	add	x2, x12, #16
	ld1.s	{ v2 }[0], [x2]
	tbnz	w11, #5, LBB0_670
LBB0_663:                               ; %else958
	tbz	w11, #6, LBB0_671
LBB0_664:                               ; %cond.load960
	add	x2, x12, #24
	ld1.s	{ v2 }[2], [x2]
	tbnz	w11, #7, LBB0_672
	b	LBB0_673
LBB0_665:                               ; %else943
	tbz	w11, #1, LBB0_659
LBB0_666:                               ; %cond.load945
	add	x2, x12, #4
	ld1.s	{ v0 }[1], [x2]
	tbnz	w11, #2, LBB0_660
LBB0_667:                               ; %else949
	tbz	w11, #3, LBB0_661
LBB0_668:                               ; %cond.load951
	add	x2, x12, #12
	ld1.s	{ v0 }[3], [x2]
	ldr	q2, [sp, #1648]
	tbnz	w11, #4, LBB0_662
LBB0_669:                               ; %else955
	tbz	w11, #5, LBB0_663
LBB0_670:                               ; %cond.load957
	add	x2, x12, #20
	ld1.s	{ v2 }[1], [x2]
	tbnz	w11, #6, LBB0_664
LBB0_671:                               ; %else961
	tbz	w11, #7, LBB0_673
LBB0_672:                               ; %cond.load963
	add	x11, x12, #28
	ld1.s	{ v2 }[3], [x11]
LBB0_673:                               ; %else964
	fmov	w2, s17
	and	w11, w2, #0xff
	str	q0, [sp, #1632]
	str	q2, [sp, #1648]
	add.2d	v27, v5, v27
	fmov	x12, d27
	add	x12, x10, x12, lsl #2
	ldr	q0, [sp, #1664]
	tbz	w2, #0, LBB0_681
; %bb.674:                              ; %cond.load967
	ld1.s	{ v0 }[0], [x12]
	tbnz	w11, #1, LBB0_682
LBB0_675:                               ; %else971
	tbz	w11, #2, LBB0_683
LBB0_676:                               ; %cond.load973
	add	x2, x12, #8
	ld1.s	{ v0 }[2], [x2]
	tbnz	w11, #3, LBB0_684
LBB0_677:                               ; %else977
	ldr	q2, [sp, #1680]
	tbz	w11, #4, LBB0_685
LBB0_678:                               ; %cond.load979
	add	x2, x12, #16
	ld1.s	{ v2 }[0], [x2]
	tbnz	w11, #5, LBB0_686
LBB0_679:                               ; %else983
	tbz	w11, #6, LBB0_687
LBB0_680:                               ; %cond.load985
	add	x2, x12, #24
	ld1.s	{ v2 }[2], [x2]
	tbnz	w11, #7, LBB0_688
	b	LBB0_689
LBB0_681:                               ; %else968
	tbz	w11, #1, LBB0_675
LBB0_682:                               ; %cond.load970
	add	x2, x12, #4
	ld1.s	{ v0 }[1], [x2]
	tbnz	w11, #2, LBB0_676
LBB0_683:                               ; %else974
	tbz	w11, #3, LBB0_677
LBB0_684:                               ; %cond.load976
	add	x2, x12, #12
	ld1.s	{ v0 }[3], [x2]
	ldr	q2, [sp, #1680]
	tbnz	w11, #4, LBB0_678
LBB0_685:                               ; %else980
	tbz	w11, #5, LBB0_679
LBB0_686:                               ; %cond.load982
	add	x2, x12, #20
	ld1.s	{ v2 }[1], [x2]
	tbnz	w11, #6, LBB0_680
LBB0_687:                               ; %else986
	tbz	w11, #7, LBB0_689
LBB0_688:                               ; %cond.load988
	add	x11, x12, #28
	ld1.s	{ v2 }[3], [x11]
LBB0_689:                               ; %else989
	fmov	w2, s17
	and	w11, w2, #0xff
	str	q0, [sp, #1664]
	str	q2, [sp, #1680]
	add.2d	v6, v5, v29
	fmov	x12, d6
	add	x12, x10, x12, lsl #2
	ldr	q0, [sp, #1696]
	tbz	w2, #0, LBB0_707
; %bb.690:                              ; %cond.load992
	ld1.s	{ v0 }[0], [x12]
	tbnz	w11, #1, LBB0_708
LBB0_691:                               ; %else996
	tbz	w11, #2, LBB0_709
LBB0_692:                               ; %cond.load998
	add	x2, x12, #8
	ld1.s	{ v0 }[2], [x2]
	fmov	x2, d28
	fmov	x3, d31
	fmov	x4, d26
	tbnz	w11, #3, LBB0_710
LBB0_693:                               ; %else1002
	mov.16b	v31, v24
	add	x2, x2, x2, lsl #5
	add	x3, x3, x3, lsl #5
	ldr	q2, [sp, #1712]
	add	x4, x4, x4, lsl #5
	tbz	w11, #4, LBB0_711
LBB0_694:                               ; %cond.load1004
	add	x5, x12, #16
	ld1.s	{ v2 }[0], [x5]
	fmov	d7, x2
	fmov	d19, x3
	fmov	d20, x4
	mov.16b	v24, v22
	tbnz	w11, #5, LBB0_712
LBB0_695:                               ; %else1008
	sshll.2d	v22, v23, #0
	mov.d	v7[1], x1
	mov.d	v19[1], x0
	mov.d	v20[1], x17
	tbz	w11, #6, LBB0_697
LBB0_696:                               ; %cond.load1010
	add	x17, x12, #24
	ld1.s	{ v2 }[2], [x17]
LBB0_697:                               ; %else1011
	orr.16b	v10, v10, v1
	orr.16b	v9, v9, v1
	orr.16b	v8, v8, v1
	and.16b	v20, v25, v20
	and.16b	v19, v22, v19
	mov.16b	v22, v24
	and.16b	v1, v24, v7
	tbz	w11, #7, LBB0_699
; %bb.698:                              ; %cond.load1013
	add	x11, x12, #28
	ld1.s	{ v2 }[3], [x11]
LBB0_699:                               ; %else1014
	str	q0, [sp, #1696]
	str	q2, [sp, #1712]
	add.2d	v0, v20, v8
	add.2d	v2, v19, v10
	add.2d	v1, v1, v9
	add.2d	v5, v5, v31
	mov	b7, v18[0]
	mov.b	v7[4], v18[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v5, v7, v5
	mov	b7, v18[2]
	mov.b	v7[4], v18[3]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v1, v7, v1
	mov	b7, v18[4]
	mov.b	v7[4], v18[5]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v2, v7, v2
	mov	b7, v18[6]
	mov.b	v7[4], v18[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v0, v7, v0
	ldr	d7, [sp, #552]                  ; 8-byte Reload
	fmov	w12, s7
	str	q0, [sp, #1184]
	str	q2, [sp, #1168]
	str	q1, [sp, #1152]
	str	q5, [sp, #1136]
	and	x11, x13, #0x7
	add	x17, sp, #1136
	ldr	x11, [x17, x11, lsl #3]
	sub	x11, x11, x13
	lsl	x11, x11, #2
	add	x10, x10, x11
	add	x17, sp, #1600
	add	x17, x17, x16
	ldr	q0, [x17]
	tbz	w12, #0, LBB0_713
; %bb.700:                              ; %cond.load1017
	ld1.s	{ v0 }[0], [x10]
	tbnz	w12, #1, LBB0_714
LBB0_701:                               ; %else1021
	tbz	w12, #2, LBB0_715
LBB0_702:                               ; %cond.load1023
	add	x0, x10, #8
	ld1.s	{ v0 }[2], [x0]
	tbnz	w12, #3, LBB0_716
LBB0_703:                               ; %else1027
	ldr	q1, [x17, #16]
	tbz	w12, #4, LBB0_717
LBB0_704:                               ; %cond.load1029
	add	x17, x10, #16
	ld1.s	{ v1 }[0], [x17]
	tbnz	w12, #5, LBB0_718
LBB0_705:                               ; %else1033
	tbz	w12, #6, LBB0_719
LBB0_706:                               ; %cond.load1035
	add	x17, x10, #24
	ld1.s	{ v1 }[2], [x17]
	and.16b	v2, v30, v4
	tbnz	w12, #7, LBB0_720
	b	LBB0_721
LBB0_707:                               ; %else993
	tbz	w11, #1, LBB0_691
LBB0_708:                               ; %cond.load995
	add	x2, x12, #4
	ld1.s	{ v0 }[1], [x2]
	tbnz	w11, #2, LBB0_692
LBB0_709:                               ; %else999
	fmov	x2, d28
	fmov	x3, d31
	fmov	x4, d26
	tbz	w11, #3, LBB0_693
LBB0_710:                               ; %cond.load1001
	add	x5, x12, #12
	ld1.s	{ v0 }[3], [x5]
	mov.16b	v31, v24
	add	x2, x2, x2, lsl #5
	add	x3, x3, x3, lsl #5
	ldr	q2, [sp, #1712]
	add	x4, x4, x4, lsl #5
	tbnz	w11, #4, LBB0_694
LBB0_711:                               ; %else1005
	fmov	d7, x2
	fmov	d19, x3
	fmov	d20, x4
	mov.16b	v24, v22
	tbz	w11, #5, LBB0_695
LBB0_712:                               ; %cond.load1007
	add	x2, x12, #20
	ld1.s	{ v2 }[1], [x2]
	sshll.2d	v22, v23, #0
	mov.d	v7[1], x1
	mov.d	v19[1], x0
	mov.d	v20[1], x17
	tbnz	w11, #6, LBB0_696
	b	LBB0_697
LBB0_713:                               ; %else1018
	tbz	w12, #1, LBB0_701
LBB0_714:                               ; %cond.load1020
	add	x0, x10, #4
	ld1.s	{ v0 }[1], [x0]
	tbnz	w12, #2, LBB0_702
LBB0_715:                               ; %else1024
	tbz	w12, #3, LBB0_703
LBB0_716:                               ; %cond.load1026
	add	x0, x10, #12
	ld1.s	{ v0 }[3], [x0]
	ldr	q1, [x17, #16]
	tbnz	w12, #4, LBB0_704
LBB0_717:                               ; %else1030
	tbz	w12, #5, LBB0_705
LBB0_718:                               ; %cond.load1032
	add	x17, x10, #20
	ld1.s	{ v1 }[1], [x17]
	tbnz	w12, #6, LBB0_706
LBB0_719:                               ; %else1036
	and.16b	v2, v30, v4
	tbz	w12, #7, LBB0_721
LBB0_720:                               ; %cond.load1038
	add	x10, x10, #28
	ld1.s	{ v1 }[3], [x10]
LBB0_721:                               ; %else1039
	fmov	w17, s17
	and	w10, w17, #0xff
	add	x12, sp, #1600
	add	x12, x12, x16
	stp	q0, q1, [x12]
	fmov	x12, d2
	add	x12, x9, x12, lsl #2
	ldr	q0, [sp, #1440]
	tbz	w17, #0, LBB0_729
; %bb.722:                              ; %cond.load1042
	ld1.s	{ v0 }[0], [x12]
	tbnz	w10, #1, LBB0_730
LBB0_723:                               ; %else1046
	tbz	w10, #2, LBB0_731
LBB0_724:                               ; %cond.load1048
	add	x17, x12, #8
	ld1.s	{ v0 }[2], [x17]
	tbnz	w10, #3, LBB0_732
LBB0_725:                               ; %else1052
	ldr	q1, [sp, #1456]
	tbz	w10, #4, LBB0_733
LBB0_726:                               ; %cond.load1054
	add	x17, x12, #16
	ld1.s	{ v1 }[0], [x17]
	tbnz	w10, #5, LBB0_734
LBB0_727:                               ; %else1058
	sshll.2d	v2, v16, #0
	tbz	w10, #6, LBB0_735
LBB0_728:                               ; %cond.load1060
	add	x17, x12, #24
	ld1.s	{ v1 }[2], [x17]
	and.16b	v2, v2, v3
	tbnz	w10, #7, LBB0_736
	b	LBB0_737
LBB0_729:                               ; %else1043
	tbz	w10, #1, LBB0_723
LBB0_730:                               ; %cond.load1045
	add	x17, x12, #4
	ld1.s	{ v0 }[1], [x17]
	tbnz	w10, #2, LBB0_724
LBB0_731:                               ; %else1049
	tbz	w10, #3, LBB0_725
LBB0_732:                               ; %cond.load1051
	add	x17, x12, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q1, [sp, #1456]
	tbnz	w10, #4, LBB0_726
LBB0_733:                               ; %else1055
	tbz	w10, #5, LBB0_727
LBB0_734:                               ; %cond.load1057
	add	x17, x12, #20
	ld1.s	{ v1 }[1], [x17]
	sshll.2d	v2, v16, #0
	tbnz	w10, #6, LBB0_728
LBB0_735:                               ; %else1061
	and.16b	v2, v2, v3
	tbz	w10, #7, LBB0_737
LBB0_736:                               ; %cond.load1063
	add	x10, x12, #28
	ld1.s	{ v1 }[3], [x10]
LBB0_737:                               ; %else1064
	fmov	w17, s17
	and	w10, w17, #0xff
	str	q0, [sp, #1440]
	str	q1, [sp, #1456]
	fmov	x12, d2
	add	x12, x9, x12, lsl #2
	ldr	q0, [sp, #1472]
	tbz	w17, #0, LBB0_745
; %bb.738:                              ; %cond.load1067
	ld1.s	{ v0 }[0], [x12]
	tbnz	w10, #1, LBB0_746
LBB0_739:                               ; %else1071
	tbz	w10, #2, LBB0_747
LBB0_740:                               ; %cond.load1073
	add	x17, x12, #8
	ld1.s	{ v0 }[2], [x17]
	tbnz	w10, #3, LBB0_748
LBB0_741:                               ; %else1077
	ldr	q1, [sp, #1488]
	tbz	w10, #4, LBB0_749
LBB0_742:                               ; %cond.load1079
	add	x17, x12, #16
	ld1.s	{ v1 }[0], [x17]
	tbnz	w10, #5, LBB0_750
LBB0_743:                               ; %else1083
	sshll.2d	v2, v16, #0
	tbz	w10, #6, LBB0_751
LBB0_744:                               ; %cond.load1085
	add	x17, x12, #24
	ld1.s	{ v1 }[2], [x17]
	and.16b	v2, v2, v27
	tbnz	w10, #7, LBB0_752
	b	LBB0_753
LBB0_745:                               ; %else1068
	tbz	w10, #1, LBB0_739
LBB0_746:                               ; %cond.load1070
	add	x17, x12, #4
	ld1.s	{ v0 }[1], [x17]
	tbnz	w10, #2, LBB0_740
LBB0_747:                               ; %else1074
	tbz	w10, #3, LBB0_741
LBB0_748:                               ; %cond.load1076
	add	x17, x12, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q1, [sp, #1488]
	tbnz	w10, #4, LBB0_742
LBB0_749:                               ; %else1080
	tbz	w10, #5, LBB0_743
LBB0_750:                               ; %cond.load1082
	add	x17, x12, #20
	ld1.s	{ v1 }[1], [x17]
	sshll.2d	v2, v16, #0
	tbnz	w10, #6, LBB0_744
LBB0_751:                               ; %else1086
	and.16b	v2, v2, v27
	tbz	w10, #7, LBB0_753
LBB0_752:                               ; %cond.load1088
	add	x10, x12, #28
	ld1.s	{ v1 }[3], [x10]
LBB0_753:                               ; %else1089
	fmov	w17, s17
	and	w10, w17, #0xff
	str	q0, [sp, #1472]
	str	q1, [sp, #1488]
	fmov	x12, d2
	add	x12, x9, x12, lsl #2
	ldr	q0, [sp, #1504]
	tbz	w17, #0, LBB0_761
; %bb.754:                              ; %cond.load1092
	ld1.s	{ v0 }[0], [x12]
	tbnz	w10, #1, LBB0_762
LBB0_755:                               ; %else1096
	tbz	w10, #2, LBB0_763
LBB0_756:                               ; %cond.load1098
	add	x17, x12, #8
	ld1.s	{ v0 }[2], [x17]
	tbnz	w10, #3, LBB0_764
LBB0_757:                               ; %else1102
	ldr	q1, [sp, #1520]
	tbz	w10, #4, LBB0_765
LBB0_758:                               ; %cond.load1104
	add	x17, x12, #16
	ld1.s	{ v1 }[0], [x17]
	tbnz	w10, #5, LBB0_766
LBB0_759:                               ; %else1108
	sshll.2d	v2, v16, #0
	tbz	w10, #6, LBB0_767
LBB0_760:                               ; %cond.load1110
	add	x17, x12, #24
	ld1.s	{ v1 }[2], [x17]
	and.16b	v2, v2, v6
	tbnz	w10, #7, LBB0_768
	b	LBB0_769
LBB0_761:                               ; %else1093
	tbz	w10, #1, LBB0_755
LBB0_762:                               ; %cond.load1095
	add	x17, x12, #4
	ld1.s	{ v0 }[1], [x17]
	tbnz	w10, #2, LBB0_756
LBB0_763:                               ; %else1099
	tbz	w10, #3, LBB0_757
LBB0_764:                               ; %cond.load1101
	add	x17, x12, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q1, [sp, #1520]
	tbnz	w10, #4, LBB0_758
LBB0_765:                               ; %else1105
	tbz	w10, #5, LBB0_759
LBB0_766:                               ; %cond.load1107
	add	x17, x12, #20
	ld1.s	{ v1 }[1], [x17]
	sshll.2d	v2, v16, #0
	tbnz	w10, #6, LBB0_760
LBB0_767:                               ; %else1111
	and.16b	v2, v2, v6
	tbz	w10, #7, LBB0_769
LBB0_768:                               ; %cond.load1113
	add	x10, x12, #28
	ld1.s	{ v1 }[3], [x10]
LBB0_769:                               ; %else1114
	fmov	w17, s17
	and	w10, w17, #0xff
	str	q0, [sp, #1504]
	str	q1, [sp, #1520]
	fmov	x12, d2
	add	x12, x9, x12, lsl #2
	ldr	q0, [sp, #1536]
	tbz	w17, #0, LBB0_777
; %bb.770:                              ; %cond.load1117
	ld1.s	{ v0 }[0], [x12]
	tbnz	w10, #1, LBB0_778
LBB0_771:                               ; %else1121
	tbz	w10, #2, LBB0_779
LBB0_772:                               ; %cond.load1123
	add	x17, x12, #8
	ld1.s	{ v0 }[2], [x17]
	tbnz	w10, #3, LBB0_780
LBB0_773:                               ; %else1127
	ldr	q1, [sp, #1552]
	tbz	w10, #4, LBB0_781
LBB0_774:                               ; %cond.load1129
	add	x17, x12, #16
	ld1.s	{ v1 }[0], [x17]
	tbnz	w10, #5, LBB0_782
LBB0_775:                               ; %else1133
	tbz	w10, #6, LBB0_783
LBB0_776:                               ; %cond.load1135
	add	x17, x12, #24
	ld1.s	{ v1 }[2], [x17]
	tbnz	w10, #7, LBB0_784
	b	LBB0_785
LBB0_777:                               ; %else1118
	tbz	w10, #1, LBB0_771
LBB0_778:                               ; %cond.load1120
	add	x17, x12, #4
	ld1.s	{ v0 }[1], [x17]
	tbnz	w10, #2, LBB0_772
LBB0_779:                               ; %else1124
	tbz	w10, #3, LBB0_773
LBB0_780:                               ; %cond.load1126
	add	x17, x12, #12
	ld1.s	{ v0 }[3], [x17]
	ldr	q1, [sp, #1552]
	tbnz	w10, #4, LBB0_774
LBB0_781:                               ; %else1130
	tbz	w10, #5, LBB0_775
LBB0_782:                               ; %cond.load1132
	add	x17, x12, #20
	ld1.s	{ v1 }[1], [x17]
	tbnz	w10, #6, LBB0_776
LBB0_783:                               ; %else1136
	tbz	w10, #7, LBB0_785
LBB0_784:                               ; %cond.load1138
	add	x10, x12, #28
	ld1.s	{ v1 }[3], [x10]
LBB0_785:                               ; %else1139
	str	q0, [sp, #1536]
	str	q1, [sp, #1552]
	add	x9, x9, x11
	add	x10, sp, #1440
	add	x11, x10, x16
	ldr	q0, [x11]
	ldr	d1, [sp, #552]                  ; 8-byte Reload
	fmov	w10, s1
	tbz	w10, #0, LBB0_793
; %bb.786:                              ; %cond.load1142
	ld1.s	{ v0 }[0], [x9]
	tbnz	w10, #1, LBB0_794
LBB0_787:                               ; %else1146
	tbz	w10, #2, LBB0_795
LBB0_788:                               ; %cond.load1148
	add	x12, x9, #8
	ld1.s	{ v0 }[2], [x12]
	tbnz	w10, #3, LBB0_796
LBB0_789:                               ; %else1152
	ldr	q1, [x11, #16]
	tbz	w10, #4, LBB0_797
LBB0_790:                               ; %cond.load1154
	add	x11, x9, #16
	ld1.s	{ v1 }[0], [x11]
	adrp	x11, lCPI0_10@PAGE
	tbnz	w10, #5, LBB0_798
LBB0_791:                               ; %else1158
	ldr	q2, [x11, lCPI0_10@PAGEOFF]
	tbz	w10, #6, LBB0_799
LBB0_792:                               ; %cond.load1160
	add	x11, x9, #24
	ld1.s	{ v1 }[2], [x11]
	and.16b	v6, v12, v2
	and.16b	v2, v12, v21
	tbnz	w10, #7, LBB0_800
	b	LBB0_801
LBB0_793:                               ; %else1143
	tbz	w10, #1, LBB0_787
LBB0_794:                               ; %cond.load1145
	add	x12, x9, #4
	ld1.s	{ v0 }[1], [x12]
	tbnz	w10, #2, LBB0_788
LBB0_795:                               ; %else1149
	tbz	w10, #3, LBB0_789
LBB0_796:                               ; %cond.load1151
	add	x12, x9, #12
	ld1.s	{ v0 }[3], [x12]
	ldr	q1, [x11, #16]
	tbnz	w10, #4, LBB0_790
LBB0_797:                               ; %else1155
	adrp	x11, lCPI0_10@PAGE
	tbz	w10, #5, LBB0_791
LBB0_798:                               ; %cond.load1157
	add	x12, x9, #20
	ld1.s	{ v1 }[1], [x12]
	ldr	q2, [x11, lCPI0_10@PAGEOFF]
	tbnz	w10, #6, LBB0_792
LBB0_799:                               ; %else1161
	and.16b	v6, v12, v2
	and.16b	v2, v12, v21
	tbz	w10, #7, LBB0_801
LBB0_800:                               ; %cond.load1163
	add	x9, x9, #28
	ld1.s	{ v1 }[3], [x9]
LBB0_801:                               ; %else1164
	fmov	w0, s17
	and	w9, w0, #0xff
	add	x10, sp, #1440
	add	x11, x10, x16
	stp	q0, q1, [x11]
	fmov	x17, d6
	add	x11, sp, #1920
	add	x11, x11, x17
	ldr	q0, [x11]
	add	x12, sp, #1600
	add	x12, x12, x17
	ldr	q1, [x12]
	stp	q1, q0, [sp, #272]              ; 32-byte Folded Spill
	fmul.4s	v0, v0, v1
	add	x16, sp, #1760
	add	x16, x16, x17
	ldr	q1, [x16]
	add	x17, x10, x17
	ldr	q3, [x17]
	stp	q3, q1, [sp, #208]              ; 32-byte Folded Spill
	fmul.4s	v1, v1, v3
	fsub.4s	v0, v0, v1
	and.16b	v0, v16, v0
	fmov	x10, d2
	add	x10, x8, x10, lsl #2
	tbz	w0, #0, LBB0_809
; %bb.802:                              ; %cond.store1167
	str	s0, [x10]
	ldr	q1, [x11, #16]
	ldr	q2, [x12, #16]
	ldr	q26, [x16, #16]
	ldr	q28, [x17, #16]
	tbnz	w9, #1, LBB0_810
LBB0_803:                               ; %else1170
	stp	q2, q1, [sp, #240]              ; 32-byte Folded Spill
	fmul.4s	v1, v1, v2
	fmul.4s	v2, v26, v28
	tbz	w9, #2, LBB0_811
LBB0_804:                               ; %cond.store1171
	add	x11, x10, #8
	st1.s	{ v0 }[2], [x11]
	fsub.4s	v1, v1, v2
	tbnz	w9, #3, LBB0_812
LBB0_805:                               ; %else1174
	and.16b	v0, v23, v1
	tbz	w9, #4, LBB0_813
LBB0_806:                               ; %cond.store1175
	str	s0, [x10, #16]
	adrp	x11, lCPI0_15@PAGE
	tbnz	w9, #5, LBB0_814
LBB0_807:                               ; %else1178
	ldr	q2, [x11, lCPI0_15@PAGEOFF]
	tbz	w9, #6, LBB0_815
LBB0_808:                               ; %cond.store1179
	add	x11, x10, #24
	st1.s	{ v0 }[2], [x11]
	and.16b	v1, v13, v11
	and.16b	v2, v13, v2
	tbnz	w9, #7, LBB0_816
	b	LBB0_817
LBB0_809:                               ; %else1168
	ldr	q1, [x11, #16]
	ldr	q2, [x12, #16]
	ldr	q26, [x16, #16]
	ldr	q28, [x17, #16]
	tbz	w9, #1, LBB0_803
LBB0_810:                               ; %cond.store1169
	add	x11, x10, #4
	st1.s	{ v0 }[1], [x11]
	stp	q2, q1, [sp, #240]              ; 32-byte Folded Spill
	fmul.4s	v1, v1, v2
	fmul.4s	v2, v26, v28
	tbnz	w9, #2, LBB0_804
LBB0_811:                               ; %else1172
	fsub.4s	v1, v1, v2
	tbz	w9, #3, LBB0_805
LBB0_812:                               ; %cond.store1173
	add	x11, x10, #12
	st1.s	{ v0 }[3], [x11]
	and.16b	v0, v23, v1
	tbnz	w9, #4, LBB0_806
LBB0_813:                               ; %else1176
	adrp	x11, lCPI0_15@PAGE
	tbz	w9, #5, LBB0_807
LBB0_814:                               ; %cond.store1177
	add	x12, x10, #20
	st1.s	{ v0 }[1], [x12]
	ldr	q2, [x11, lCPI0_15@PAGEOFF]
	tbnz	w9, #6, LBB0_808
LBB0_815:                               ; %else1180
	and.16b	v1, v13, v11
	and.16b	v2, v13, v2
	tbz	w9, #7, LBB0_817
LBB0_816:                               ; %cond.store1181
	add	x9, x10, #28
	st1.s	{ v0 }[3], [x9]
LBB0_817:                               ; %else1182
	fmov	w0, s17
	and	w9, w0, #0xff
	fmov	x10, d2
	add	x11, sp, #1920
	add	x11, x11, x10
	ldr	q0, [x11]
	add	x12, sp, #1600
	add	x12, x12, x10
	ldr	q2, [x12]
	stp	q2, q0, [sp, #176]              ; 32-byte Folded Spill
	fmul.4s	v0, v0, v2
	add	x16, sp, #1760
	add	x16, x16, x10
	ldr	q2, [x16]
	add	x17, sp, #1440
	add	x17, x17, x10
	ldr	q3, [x17]
	str	q2, [sp, #112]                  ; 16-byte Spill
	str	q3, [sp, #80]                   ; 16-byte Spill
	fmul.4s	v2, v2, v3
	fsub.4s	v0, v0, v2
	and.16b	v0, v16, v0
	fmov	x10, d1
	add	x10, x8, x10, lsl #2
	tbz	w0, #0, LBB0_825
; %bb.818:                              ; %cond.store1184
	str	s0, [x10]
	ldr	q1, [x11, #16]
	ldr	q2, [x12, #16]
	ldr	q3, [x16, #16]
	ldr	q4, [x17, #16]
	tbnz	w9, #1, LBB0_826
LBB0_819:                               ; %else1187
	stp	q2, q1, [sp, #144]              ; 32-byte Folded Spill
	fmul.4s	v1, v1, v2
	fmul.4s	v2, v3, v4
	tbz	w9, #2, LBB0_827
LBB0_820:                               ; %cond.store1188
	add	x11, x10, #8
	st1.s	{ v0 }[2], [x11]
	fsub.4s	v1, v1, v2
	tbnz	w9, #3, LBB0_828
LBB0_821:                               ; %else1191
	and.16b	v0, v23, v1
	tbz	w9, #4, LBB0_829
LBB0_822:                               ; %cond.store1192
	str	s0, [x10, #16]
	adrp	x11, lCPI0_20@PAGE
	tbnz	w9, #5, LBB0_830
LBB0_823:                               ; %else1195
	ldr	q2, [x11, lCPI0_20@PAGEOFF]
	tbz	w9, #6, LBB0_831
LBB0_824:                               ; %cond.store1196
	add	x11, x10, #24
	st1.s	{ v0 }[2], [x11]
	and.16b	v1, v14, v15
	and.16b	v2, v14, v2
	tbnz	w9, #7, LBB0_832
	b	LBB0_833
LBB0_825:                               ; %else1185
	ldr	q1, [x11, #16]
	ldr	q2, [x12, #16]
	ldr	q3, [x16, #16]
	ldr	q4, [x17, #16]
	tbz	w9, #1, LBB0_819
LBB0_826:                               ; %cond.store1186
	add	x11, x10, #4
	st1.s	{ v0 }[1], [x11]
	stp	q2, q1, [sp, #144]              ; 32-byte Folded Spill
	fmul.4s	v1, v1, v2
	fmul.4s	v2, v3, v4
	tbnz	w9, #2, LBB0_820
LBB0_827:                               ; %else1189
	fsub.4s	v1, v1, v2
	tbz	w9, #3, LBB0_821
LBB0_828:                               ; %cond.store1190
	add	x11, x10, #12
	st1.s	{ v0 }[3], [x11]
	and.16b	v0, v23, v1
	tbnz	w9, #4, LBB0_822
LBB0_829:                               ; %else1193
	adrp	x11, lCPI0_20@PAGE
	tbz	w9, #5, LBB0_823
LBB0_830:                               ; %cond.store1194
	add	x12, x10, #20
	st1.s	{ v0 }[1], [x12]
	ldr	q2, [x11, lCPI0_20@PAGEOFF]
	tbnz	w9, #6, LBB0_824
LBB0_831:                               ; %else1197
	and.16b	v1, v14, v15
	and.16b	v2, v14, v2
	tbz	w9, #7, LBB0_833
LBB0_832:                               ; %cond.store1198
	add	x9, x10, #28
	st1.s	{ v0 }[3], [x9]
LBB0_833:                               ; %else1199
	fmov	w0, s17
	and	w9, w0, #0xff
	fmov	x10, d2
	add	x11, sp, #1920
	add	x11, x11, x10
	ldr	q0, [x11]
	add	x12, sp, #1600
	add	x12, x12, x10
	ldr	q2, [x12]
	stp	q2, q0, [sp, #48]               ; 32-byte Folded Spill
	fmul.4s	v0, v0, v2
	add	x16, sp, #1760
	add	x16, x16, x10
	ldr	q15, [x16]
	add	x17, sp, #1440
	add	x17, x17, x10
	ldr	q20, [x17]
	fmul.4s	v2, v15, v20
	fsub.4s	v0, v0, v2
	and.16b	v0, v16, v0
	fmov	x10, d1
	add	x10, x8, x10, lsl #2
	tbz	w0, #0, LBB0_851
; %bb.834:                              ; %cond.store1201
	str	s0, [x10]
	ldr	q1, [x11, #16]
	ldr	q2, [x12, #16]
	ldr	q5, [x16, #16]
	ldr	q19, [x17, #16]
	tbnz	w9, #1, LBB0_852
LBB0_835:                               ; %else1204
	stp	q2, q1, [sp, #16]               ; 32-byte Folded Spill
	fmul.4s	v1, v1, v2
	fmul.4s	v2, v5, v19
	tbz	w9, #2, LBB0_853
LBB0_836:                               ; %cond.store1205
	add	x11, x10, #8
	st1.s	{ v0 }[2], [x11]
	fsub.4s	v1, v1, v2
	tbnz	w9, #3, LBB0_854
LBB0_837:                               ; %else1208
	and.16b	v0, v23, v1
	tbz	w9, #4, LBB0_855
LBB0_838:                               ; %cond.store1209
	str	s0, [x10, #16]
	adrp	x11, lCPI0_25@PAGE
	tbnz	w9, #5, LBB0_856
LBB0_839:                               ; %else1212
	str	q3, [sp, #128]                  ; 16-byte Spill
	ldr	q2, [x11, lCPI0_25@PAGEOFF]
	tbz	w9, #6, LBB0_841
LBB0_840:                               ; %cond.store1213
	add	x11, x10, #24
	st1.s	{ v0 }[2], [x11]
LBB0_841:                               ; %else1214
	str	q5, [sp]                        ; 16-byte Spill
	str	q4, [sp, #96]                   ; 16-byte Spill
	ldr	q1, [sp, #528]                  ; 16-byte Reload
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	and.16b	v1, v3, v1
	and.16b	v2, v3, v2
	tbz	w9, #7, LBB0_843
; %bb.842:                              ; %cond.store1215
	add	x9, x10, #28
	st1.s	{ v0 }[3], [x9]
LBB0_843:                               ; %else1216
	fmov	w0, s17
	and	w9, w0, #0xff
	fmov	x10, d2
	add	x11, sp, #1920
	add	x11, x11, x10
	ldr	q0, [x11]
	add	x12, sp, #1600
	add	x12, x12, x10
	ldr	q2, [x12]
	fmul.4s	v3, v0, v2
	add	x16, sp, #1760
	add	x16, x16, x10
	ldr	q4, [x16]
	add	x17, sp, #1440
	add	x17, x17, x10
	ldr	q21, [x17]
	fmul.4s	v5, v4, v21
	fsub.4s	v3, v3, v5
	and.16b	v7, v16, v3
	fmov	x10, d1
	add	x10, x8, x10, lsl #2
	tbz	w0, #0, LBB0_857
; %bb.844:                              ; %cond.store1218
	str	s7, [x10]
	mov.16b	v24, v25
	ldr	q1, [x11, #16]
	ldr	q11, [x12, #16]
	ldr	q3, [x16, #16]
	ldr	q5, [x17, #16]
	tbnz	w9, #1, LBB0_858
LBB0_845:                               ; %else1221
	fmul.4s	v27, v1, v11
	fmul.4s	v25, v3, v5
	tbz	w9, #2, LBB0_859
LBB0_846:                               ; %cond.store1222
	add	x11, x10, #8
	st1.s	{ v7 }[2], [x11]
	fsub.4s	v25, v27, v25
	tbnz	w9, #3, LBB0_860
LBB0_847:                               ; %else1225
	and.16b	v7, v23, v25
	tbz	w9, #4, LBB0_861
LBB0_848:                               ; %cond.store1226
	str	s7, [x10, #16]
	adrp	x11, lCPI0_7@PAGE
	adrp	x12, lCPI0_8@PAGE
	adrp	x16, lCPI0_9@PAGE
	mov.16b	v25, v24
	tbnz	w9, #5, LBB0_862
LBB0_849:                               ; %else1229
	ldr	q27, [x11, lCPI0_7@PAGEOFF]
	ldr	q29, [x12, lCPI0_8@PAGEOFF]
	ldr	q30, [x16, lCPI0_9@PAGEOFF]
	tbz	w9, #6, LBB0_863
LBB0_850:                               ; %cond.store1230
	add	x11, x10, #24
	st1.s	{ v7 }[2], [x11]
	mov.16b	v24, v23
	and.16b	v27, v25, v27
	and.16b	v29, v22, v29
	ldr	q22, [sp, #352]                 ; 16-byte Reload
	and.16b	v30, v22, v30
	tbnz	w9, #7, LBB0_864
	b	LBB0_865
LBB0_851:                               ; %else1202
	ldr	q1, [x11, #16]
	ldr	q2, [x12, #16]
	ldr	q5, [x16, #16]
	ldr	q19, [x17, #16]
	tbz	w9, #1, LBB0_835
LBB0_852:                               ; %cond.store1203
	add	x11, x10, #4
	st1.s	{ v0 }[1], [x11]
	stp	q2, q1, [sp, #16]               ; 32-byte Folded Spill
	fmul.4s	v1, v1, v2
	fmul.4s	v2, v5, v19
	tbnz	w9, #2, LBB0_836
LBB0_853:                               ; %else1206
	fsub.4s	v1, v1, v2
	tbz	w9, #3, LBB0_837
LBB0_854:                               ; %cond.store1207
	add	x11, x10, #12
	st1.s	{ v0 }[3], [x11]
	and.16b	v0, v23, v1
	tbnz	w9, #4, LBB0_838
LBB0_855:                               ; %else1210
	adrp	x11, lCPI0_25@PAGE
	tbz	w9, #5, LBB0_839
LBB0_856:                               ; %cond.store1211
	add	x12, x10, #20
	st1.s	{ v0 }[1], [x12]
	str	q3, [sp, #128]                  ; 16-byte Spill
	ldr	q2, [x11, lCPI0_25@PAGEOFF]
	tbnz	w9, #6, LBB0_840
	b	LBB0_841
LBB0_857:                               ; %else1219
	mov.16b	v24, v25
	ldr	q1, [x11, #16]
	ldr	q11, [x12, #16]
	ldr	q3, [x16, #16]
	ldr	q5, [x17, #16]
	tbz	w9, #1, LBB0_845
LBB0_858:                               ; %cond.store1220
	add	x11, x10, #4
	st1.s	{ v7 }[1], [x11]
	fmul.4s	v27, v1, v11
	fmul.4s	v25, v3, v5
	tbnz	w9, #2, LBB0_846
LBB0_859:                               ; %else1223
	fsub.4s	v25, v27, v25
	tbz	w9, #3, LBB0_847
LBB0_860:                               ; %cond.store1224
	add	x11, x10, #12
	st1.s	{ v7 }[3], [x11]
	and.16b	v7, v23, v25
	tbnz	w9, #4, LBB0_848
LBB0_861:                               ; %else1227
	adrp	x11, lCPI0_7@PAGE
	adrp	x12, lCPI0_8@PAGE
	adrp	x16, lCPI0_9@PAGE
	mov.16b	v25, v24
	tbz	w9, #5, LBB0_849
LBB0_862:                               ; %cond.store1228
	add	x17, x10, #20
	st1.s	{ v7 }[1], [x17]
	ldr	q27, [x11, lCPI0_7@PAGEOFF]
	ldr	q29, [x12, lCPI0_8@PAGEOFF]
	ldr	q30, [x16, lCPI0_9@PAGEOFF]
	tbnz	w9, #6, LBB0_850
LBB0_863:                               ; %else1231
	mov.16b	v24, v23
	and.16b	v27, v25, v27
	and.16b	v29, v22, v29
	ldr	q22, [sp, #352]                 ; 16-byte Reload
	and.16b	v30, v22, v30
	tbz	w9, #7, LBB0_865
LBB0_864:                               ; %cond.store1232
	add	x9, x10, #28
	st1.s	{ v7 }[3], [x9]
LBB0_865:                               ; %else1233
	ldr	q7, [sp, #304]                  ; 16-byte Reload
	add.2d	v25, v7, v8
	ldr	q7, [sp, #320]                  ; 16-byte Reload
	add.2d	v10, v7, v10
	ldr	q7, [sp, #336]                  ; 16-byte Reload
	add.2d	v22, v7, v9
	ldr	q7, [sp, #480]                  ; 16-byte Reload
	add.2d	v14, v7, v31
	str	q6, [sp, #1056]
	str	q29, [sp, #1072]
	str	q30, [sp, #1088]
	str	q27, [sp, #1104]
	ubfiz	x10, x13, #3, #3
	add	x9, sp, #1056
	ldr	x9, [x9, x10]
	orr	x9, x9, #0x80
	sub	x9, x9, x15
	tst	w14, #0xff
	csel	x9, xzr, x9, eq
	add	x11, sp, #1920
	add	x11, x11, x9
	ldp	q12, q6, [x11]
	add	x11, sp, #1600
	add	x11, x11, x9
	ldp	q7, q27, [x11]
	fmul.4s	v8, v12, v7
	add	x11, sp, #1760
	add	x11, x11, x9
	ldp	q13, q29, [x11]
	add	x11, sp, #1440
	add	x9, x11, x9
	ldp	q31, q30, [x9]
	fmul.4s	v9, v13, v31
	fsub.4s	v8, v8, v9
	zip2.8b	v9, v18, v0
	zip1.8b	v23, v18, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmlt.4s	v23, v23, #0
	and.16b	v8, v23, v8
	ldr	d23, [sp, #552]                 ; 8-byte Reload
	fmov	w9, s23
	stp	q14, q22, [sp, #992]
	str	q10, [sp, #1024]
	str	q25, [sp, #1040]
	add	x11, sp, #992
	ldr	x10, [x11, x10]
	sub	x10, x10, x13
	add	x10, x8, x10, lsl #2
	tbz	w9, #0, LBB0_873
; %bb.866:                              ; %cond.store1235
	str	s8, [x10]
	ushll.4s	v10, v9, #0
	tbnz	w9, #1, LBB0_874
LBB0_867:                               ; %else1238
	fmul.4s	v9, v6, v27
	fmul.4s	v25, v29, v30
	shl.4s	v10, v10, #31
	tbz	w9, #2, LBB0_875
LBB0_868:                               ; %cond.store1239
	add	x11, x10, #8
	st1.s	{ v8 }[2], [x11]
	fsub.4s	v25, v9, v25
	cmlt.4s	v9, v10, #0
	tbnz	w9, #3, LBB0_876
LBB0_869:                               ; %else1242
	and.16b	v8, v9, v25
	tbz	w9, #4, LBB0_877
LBB0_870:                               ; %cond.store1243
	str	s8, [x10, #16]
	tbnz	w9, #5, LBB0_878
LBB0_871:                               ; %else1246
	sshll.2d	v25, v16, #0
	tbz	w9, #6, LBB0_879
LBB0_872:                               ; %cond.store1247
	add	x11, x10, #24
	st1.s	{ v8 }[2], [x11]
	ldr	q22, [sp, #512]                 ; 16-byte Reload
	and.16b	v9, v25, v22
	tbnz	w9, #7, LBB0_880
	b	LBB0_881
LBB0_873:                               ; %else1236
	ushll.4s	v10, v9, #0
	tbz	w9, #1, LBB0_867
LBB0_874:                               ; %cond.store1237
	add	x11, x10, #4
	st1.s	{ v8 }[1], [x11]
	fmul.4s	v9, v6, v27
	fmul.4s	v25, v29, v30
	shl.4s	v10, v10, #31
	tbnz	w9, #2, LBB0_868
LBB0_875:                               ; %else1240
	fsub.4s	v25, v9, v25
	cmlt.4s	v9, v10, #0
	tbz	w9, #3, LBB0_869
LBB0_876:                               ; %cond.store1241
	add	x11, x10, #12
	st1.s	{ v8 }[3], [x11]
	and.16b	v8, v9, v25
	tbnz	w9, #4, LBB0_870
LBB0_877:                               ; %else1244
	tbz	w9, #5, LBB0_871
LBB0_878:                               ; %cond.store1245
	add	x11, x10, #20
	st1.s	{ v8 }[1], [x11]
	sshll.2d	v25, v16, #0
	tbnz	w9, #6, LBB0_872
LBB0_879:                               ; %else1248
	ldr	q22, [sp, #512]                 ; 16-byte Reload
	and.16b	v9, v25, v22
	tbz	w9, #7, LBB0_881
LBB0_880:                               ; %cond.store1249
	add	x9, x10, #28
	st1.s	{ v8 }[3], [x9]
LBB0_881:                               ; %else1250
	fmov	w11, s17
	and	w9, w11, #0xff
	ldr	q22, [sp, #288]                 ; 16-byte Reload
	ldp	q23, q25, [sp, #208]            ; 32-byte Folded Reload
	fmul.4s	v22, v22, v23
	ldr	q23, [sp, #272]                 ; 16-byte Reload
	fmul.4s	v23, v23, v25
	fadd.4s	v22, v23, v22
	and.16b	v8, v16, v22
	fmov	x10, d9
	add	x10, x8, x10, lsl #2
	tbz	w11, #0, LBB0_889
; %bb.882:                              ; %cond.store1252
	str	s8, [x10]
	mov.16b	v22, v24
	tbnz	w9, #1, LBB0_890
LBB0_883:                               ; %else1255
	ldr	q23, [sp, #256]                 ; 16-byte Reload
	fmul.4s	v25, v23, v28
	ldr	q23, [sp, #240]                 ; 16-byte Reload
	fmul.4s	v9, v23, v26
	tbz	w9, #2, LBB0_891
LBB0_884:                               ; %cond.store1256
	add	x11, x10, #8
	st1.s	{ v8 }[2], [x11]
	fadd.4s	v25, v9, v25
	tbnz	w9, #3, LBB0_892
LBB0_885:                               ; %else1259
	and.16b	v8, v22, v25
	tbz	w9, #4, LBB0_893
LBB0_886:                               ; %cond.store1260
	str	s8, [x10, #16]
	tbnz	w9, #5, LBB0_894
LBB0_887:                               ; %else1263
	sshll.2d	v25, v16, #0
	tbz	w9, #6, LBB0_895
LBB0_888:                               ; %cond.store1264
	add	x11, x10, #24
	st1.s	{ v8 }[2], [x11]
	ldr	q22, [sp, #496]                 ; 16-byte Reload
	and.16b	v9, v25, v22
	tbnz	w9, #7, LBB0_896
	b	LBB0_897
LBB0_889:                               ; %else1253
	mov.16b	v22, v24
	tbz	w9, #1, LBB0_883
LBB0_890:                               ; %cond.store1254
	add	x11, x10, #4
	st1.s	{ v8 }[1], [x11]
	ldr	q23, [sp, #256]                 ; 16-byte Reload
	fmul.4s	v25, v23, v28
	ldr	q23, [sp, #240]                 ; 16-byte Reload
	fmul.4s	v9, v23, v26
	tbnz	w9, #2, LBB0_884
LBB0_891:                               ; %else1257
	fadd.4s	v25, v9, v25
	tbz	w9, #3, LBB0_885
LBB0_892:                               ; %cond.store1258
	add	x11, x10, #12
	st1.s	{ v8 }[3], [x11]
	and.16b	v8, v22, v25
	tbnz	w9, #4, LBB0_886
LBB0_893:                               ; %else1261
	tbz	w9, #5, LBB0_887
LBB0_894:                               ; %cond.store1262
	add	x11, x10, #20
	st1.s	{ v8 }[1], [x11]
	sshll.2d	v25, v16, #0
	tbnz	w9, #6, LBB0_888
LBB0_895:                               ; %else1265
	ldr	q22, [sp, #496]                 ; 16-byte Reload
	and.16b	v9, v25, v22
	tbz	w9, #7, LBB0_897
LBB0_896:                               ; %cond.store1266
	add	x9, x10, #28
	st1.s	{ v8 }[3], [x9]
LBB0_897:                               ; %else1267
	fmov	w11, s17
	and	w9, w11, #0xff
	ldr	q22, [sp, #192]                 ; 16-byte Reload
	ldr	q23, [sp, #80]                  ; 16-byte Reload
	fmul.4s	v22, v22, v23
	ldr	q23, [sp, #176]                 ; 16-byte Reload
	ldr	q25, [sp, #112]                 ; 16-byte Reload
	fmul.4s	v23, v23, v25
	fadd.4s	v22, v23, v22
	and.16b	v22, v16, v22
	fmov	x10, d9
	add	x10, x8, x10, lsl #2
	tbz	w11, #0, LBB0_905
; %bb.898:                              ; %cond.store1269
	str	s22, [x10]
	tbnz	w9, #1, LBB0_906
LBB0_899:                               ; %else1272
	ldp	q23, q26, [sp, #144]            ; 32-byte Folded Reload
	ldr	q25, [sp, #96]                  ; 16-byte Reload
	fmul.4s	v25, v26, v25
	ldr	q26, [sp, #128]                 ; 16-byte Reload
	fmul.4s	v8, v23, v26
	tbz	w9, #2, LBB0_907
LBB0_900:                               ; %cond.store1273
	add	x11, x10, #8
	st1.s	{ v22 }[2], [x11]
	fadd.4s	v25, v8, v25
	tbnz	w9, #3, LBB0_908
LBB0_901:                               ; %else1276
	and.16b	v22, v24, v25
	tbz	w9, #4, LBB0_909
LBB0_902:                               ; %cond.store1277
	str	s22, [x10, #16]
	tbnz	w9, #5, LBB0_910
LBB0_903:                               ; %else1280
	sshll.2d	v25, v16, #0
	tbz	w9, #6, LBB0_911
LBB0_904:                               ; %cond.store1281
	add	x11, x10, #24
	st1.s	{ v22 }[2], [x11]
	ldr	q23, [sp, #464]                 ; 16-byte Reload
	and.16b	v25, v25, v23
	tbnz	w9, #7, LBB0_912
	b	LBB0_913
LBB0_905:                               ; %else1270
	tbz	w9, #1, LBB0_899
LBB0_906:                               ; %cond.store1271
	add	x11, x10, #4
	st1.s	{ v22 }[1], [x11]
	ldp	q23, q26, [sp, #144]            ; 32-byte Folded Reload
	ldr	q25, [sp, #96]                  ; 16-byte Reload
	fmul.4s	v25, v26, v25
	ldr	q26, [sp, #128]                 ; 16-byte Reload
	fmul.4s	v8, v23, v26
	tbnz	w9, #2, LBB0_900
LBB0_907:                               ; %else1274
	fadd.4s	v25, v8, v25
	tbz	w9, #3, LBB0_901
LBB0_908:                               ; %cond.store1275
	add	x11, x10, #12
	st1.s	{ v22 }[3], [x11]
	and.16b	v22, v24, v25
	tbnz	w9, #4, LBB0_902
LBB0_909:                               ; %else1278
	tbz	w9, #5, LBB0_903
LBB0_910:                               ; %cond.store1279
	add	x11, x10, #20
	st1.s	{ v22 }[1], [x11]
	sshll.2d	v25, v16, #0
	tbnz	w9, #6, LBB0_904
LBB0_911:                               ; %else1282
	ldr	q23, [sp, #464]                 ; 16-byte Reload
	and.16b	v25, v25, v23
	tbz	w9, #7, LBB0_913
LBB0_912:                               ; %cond.store1283
	add	x9, x10, #28
	st1.s	{ v22 }[3], [x9]
LBB0_913:                               ; %else1284
	fmov	w11, s17
	and	w9, w11, #0xff
	ldp	q22, q23, [sp, #48]             ; 32-byte Folded Reload
	fmul.4s	v20, v23, v20
	fmul.4s	v22, v22, v15
	fadd.4s	v20, v22, v20
	and.16b	v20, v16, v20
	fmov	x10, d25
	add	x10, x8, x10, lsl #2
	tbz	w11, #0, LBB0_921
; %bb.914:                              ; %cond.store1286
	str	s20, [x10]
	tbnz	w9, #1, LBB0_922
LBB0_915:                               ; %else1289
	ldp	q22, q23, [sp, #16]             ; 32-byte Folded Reload
	fmul.4s	v19, v23, v19
	ldr	q23, [sp]                       ; 16-byte Reload
	fmul.4s	v22, v22, v23
	tbz	w9, #2, LBB0_923
LBB0_916:                               ; %cond.store1290
	add	x11, x10, #8
	st1.s	{ v20 }[2], [x11]
	fadd.4s	v19, v22, v19
	tbnz	w9, #3, LBB0_924
LBB0_917:                               ; %else1293
	and.16b	v19, v24, v19
	tbz	w9, #4, LBB0_925
LBB0_918:                               ; %cond.store1294
	str	s19, [x10, #16]
	tbnz	w9, #5, LBB0_926
LBB0_919:                               ; %else1297
	sshll.2d	v20, v16, #0
	tbz	w9, #6, LBB0_927
LBB0_920:                               ; %cond.store1298
	add	x11, x10, #24
	st1.s	{ v19 }[2], [x11]
	ldr	q22, [sp, #448]                 ; 16-byte Reload
	and.16b	v20, v20, v22
	tbnz	w9, #7, LBB0_928
	b	LBB0_929
LBB0_921:                               ; %else1287
	tbz	w9, #1, LBB0_915
LBB0_922:                               ; %cond.store1288
	add	x11, x10, #4
	st1.s	{ v20 }[1], [x11]
	ldp	q22, q23, [sp, #16]             ; 32-byte Folded Reload
	fmul.4s	v19, v23, v19
	ldr	q23, [sp]                       ; 16-byte Reload
	fmul.4s	v22, v22, v23
	tbnz	w9, #2, LBB0_916
LBB0_923:                               ; %else1291
	fadd.4s	v19, v22, v19
	tbz	w9, #3, LBB0_917
LBB0_924:                               ; %cond.store1292
	add	x11, x10, #12
	st1.s	{ v20 }[3], [x11]
	and.16b	v19, v24, v19
	tbnz	w9, #4, LBB0_918
LBB0_925:                               ; %else1295
	tbz	w9, #5, LBB0_919
LBB0_926:                               ; %cond.store1296
	add	x11, x10, #20
	st1.s	{ v19 }[1], [x11]
	sshll.2d	v20, v16, #0
	tbnz	w9, #6, LBB0_920
LBB0_927:                               ; %else1299
	ldr	q22, [sp, #448]                 ; 16-byte Reload
	and.16b	v20, v20, v22
	tbz	w9, #7, LBB0_929
LBB0_928:                               ; %cond.store1300
	add	x9, x10, #28
	st1.s	{ v19 }[3], [x9]
LBB0_929:                               ; %else1301
	fmov	w11, s17
	and	w9, w11, #0xff
	fmul.4s	v0, v0, v21
	fmul.4s	v2, v2, v4
	fadd.4s	v0, v2, v0
	and.16b	v0, v16, v0
	fmov	x10, d20
	add	x10, x8, x10, lsl #2
	tbz	w11, #0, LBB0_937
; %bb.930:                              ; %cond.store1303
	str	s0, [x10]
	tbnz	w9, #1, LBB0_938
LBB0_931:                               ; %else1306
	fmul.4s	v1, v1, v5
	fmul.4s	v2, v11, v3
	tbz	w9, #2, LBB0_939
LBB0_932:                               ; %cond.store1307
	add	x11, x10, #8
	st1.s	{ v0 }[2], [x11]
	fadd.4s	v1, v2, v1
	tbnz	w9, #3, LBB0_940
LBB0_933:                               ; %else1310
	and.16b	v0, v24, v1
	tbz	w9, #4, LBB0_941
LBB0_934:                               ; %cond.store1311
	str	s0, [x10, #16]
	tbnz	w9, #5, LBB0_942
LBB0_935:                               ; %else1314
	tbz	w9, #6, LBB0_943
LBB0_936:                               ; %cond.store1315
	add	x11, x10, #24
	st1.s	{ v0 }[2], [x11]
	tbnz	w9, #7, LBB0_944
	b	LBB0_945
LBB0_937:                               ; %else1304
	tbz	w9, #1, LBB0_931
LBB0_938:                               ; %cond.store1305
	add	x11, x10, #4
	st1.s	{ v0 }[1], [x11]
	fmul.4s	v1, v1, v5
	fmul.4s	v2, v11, v3
	tbnz	w9, #2, LBB0_932
LBB0_939:                               ; %else1308
	fadd.4s	v1, v2, v1
	tbz	w9, #3, LBB0_933
LBB0_940:                               ; %cond.store1309
	add	x11, x10, #12
	st1.s	{ v0 }[3], [x11]
	and.16b	v0, v24, v1
	tbnz	w9, #4, LBB0_934
LBB0_941:                               ; %else1312
	tbz	w9, #5, LBB0_935
LBB0_942:                               ; %cond.store1313
	add	x11, x10, #20
	st1.s	{ v0 }[1], [x11]
	tbnz	w9, #6, LBB0_936
LBB0_943:                               ; %else1316
	tbz	w9, #7, LBB0_945
LBB0_944:                               ; %cond.store1317
	add	x9, x10, #28
	st1.s	{ v0 }[3], [x9]
LBB0_945:                               ; %else1318
	fmul.4s	v0, v12, v31
	fmul.4s	v1, v7, v13
	fadd.4s	v0, v1, v0
	zip2.8b	v1, v18, v0
	zip1.8b	v2, v18, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v0, v2, v0
	ldr	d2, [sp, #552]                  ; 8-byte Reload
	fmov	w9, s2
	ldp	q3, q2, [sp, #384]              ; 32-byte Folded Reload
	stp	q3, q2, [sp, #912]
	ldp	q3, q2, [sp, #416]              ; 32-byte Folded Reload
	stp	q3, q2, [sp, #944]
	and	x10, x13, #0x7
	add	x11, sp, #912
	ldr	x10, [x11, x10, lsl #3]
	sub	x10, x10, x13
	add	x8, x8, x10, lsl #2
	tbz	w9, #0, LBB0_956
; %bb.946:                              ; %cond.store1320
	str	s0, [x8]
	ushll.4s	v2, v1, #0
	tbnz	w9, #1, LBB0_957
LBB0_947:                               ; %else1323
	fmul.4s	v1, v6, v30
	fmul.4s	v3, v27, v29
	shl.4s	v2, v2, #31
	tbz	w9, #2, LBB0_958
LBB0_948:                               ; %cond.store1324
	add	x10, x8, #8
	st1.s	{ v0 }[2], [x10]
	fadd.4s	v1, v3, v1
	cmlt.4s	v2, v2, #0
	tbnz	w9, #3, LBB0_959
LBB0_949:                               ; %else1327
	and.16b	v0, v2, v1
	tbnz	w9, #4, LBB0_473
LBB0_950:                               ; %else659
	tbz	w9, #5, LBB0_474
LBB0_951:                               ; %cond.store660
	add	x10, x8, #20
	st1.s	{ v0 }[1], [x10]
	tbnz	w9, #6, LBB0_475
LBB0_952:                               ; %else663
	tbz	w9, #7, LBB0_954
LBB0_953:                               ; %cond.store1334
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_954:
	add	sp, sp, #2080
	ldp	x20, x19, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
LBB0_955:                               ; %common.ret
	ret
LBB0_956:                               ; %else1321
	ushll.4s	v2, v1, #0
	tbz	w9, #1, LBB0_947
LBB0_957:                               ; %cond.store1322
	add	x10, x8, #4
	st1.s	{ v0 }[1], [x10]
	fmul.4s	v1, v6, v30
	fmul.4s	v3, v27, v29
	shl.4s	v2, v2, #31
	tbnz	w9, #2, LBB0_948
LBB0_958:                               ; %else1325
	fadd.4s	v1, v3, v1
	cmlt.4s	v2, v2, #0
	tbz	w9, #3, LBB0_949
LBB0_959:                               ; %cond.store1326
	add	x10, x8, #12
	st1.s	{ v0 }[3], [x10]
	and.16b	v0, v2, v1
	tbz	w9, #4, LBB0_950
	b	LBB0_473
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

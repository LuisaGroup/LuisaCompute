#!/usr/bin/env python3
"""Archive this frozen cohort without executing kernels or repeating its audit."""
import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import time

RAW = Path('/tmp/luisa-pointwise-no-specialization.whVpcS').resolve()
OUT = Path('/Users/mike/CLionProjects/luisa/scripts/benchmark/tile_torch/results/m1-max-20260910-no-specialization')
OUT.mkdir(parents=True, exist_ok=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(path):
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=sha(data))


def write_json(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write('\n')


m = json.loads((RAW / 'capture/manifest.json').read_text())
r = json.loads((RAW / 'replay/results.json').read_text())
a = json.loads((RAW / 'audit.json').read_text())
assert m['status'] == 'captured' and r['status'] == a['status'] == 'passed'
assert len(m['cases']) == len(r['cases']) == 6
assert sum(len(c['results']) for c in r['cases']) == 108
assert len(a['rejected_mutations']) == 11 and a['identity_checks'] == 373
assert r['manifest_sha256'] == a['manifest_sha256'] == record(RAW / 'capture/manifest.json')['sha256']
assert a['replay_sha256'] == record(RAW / 'replay/results.json')['sha256']
frozen = RAW / 'archival-source-freeze'
assert a['auditor_sha256'] == record(frozen / 'audit_native_pointwise.py')['sha256']
assert m['runner_sha256'] == r['runner_sha256']
for original, expected in m['runner_sha256'].items():
    assert record(frozen / Path(original).name)['sha256'] == expected
for case in m['cases']:
    for variant in ('off', 'on'):
        e = case['entries'][variant]
        assert e['environment']['LUISA_SIMD_DISABLE_FULL_PACKET_SPECIALIZATION'] == '1'
        assert e['realization_fields']['full_packet_specializations'] == '0'
        assert e['realization_fields']['full_packet_cloned_instructions'] == '0'
        assert e['realization_fields']['pointwise_fusion'] == str(variant == 'on').lower()

files = {}
excluded = []
recorded_hashes = m['artifact_sha256'] | r['artifact_sha256']
for phase in ('capture', 'replay'):
    for path in sorted((RAW / phase).rglob('*')):
        if not path.is_file():
            continue
        if path.suffix in ('.f32', '.f64'):
            excluded.append(dict(raw_path=str(path), bytes=path.stat().st_size,
                                 recorded_sha256=recorded_hashes.get(str(path))))
        elif path.name not in ('manifest.json', 'results.json'):
            files[str(path.relative_to(RAW))] = path
for path in sorted(frozen.iterdir()):
    files['runners/' + path.name] = path
for path in sorted(RAW.glob('*.log')):
    files['logs/' + path.name] = path
fixture = Path(m['source_root']) / 'src/tests/common/tile_llm_test_utils.h'
assert record(fixture)['sha256'] == m['source_sha256'][str(fixture)]
files['validation/tile_llm_test_utils.h'] = fixture
files['validation/full-build-rope-test-final.log'] = Path(m['full_build_gate']['log'])
files['archiver/archive_checkpoint.py'] = Path(__file__).resolve()

members = []
for name, source in sorted(files.items()):
    assert not name.startswith('/') and '..' not in Path(name).parts
    assert not source.is_symlink()
    item = dict(name=name, raw_path=str(source), **record(source))
    if str(source) in recorded_hashes:
        assert item['sha256'] == recorded_hashes[str(source)]
    members.append(item)

with (OUT / 'evidence.tar.gz').open('xb') as raw_stream:
    with gzip.GzipFile(fileobj=raw_stream, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for item in members:
                data = files[item['name']].read_bytes()
                assert sha(data) == item['sha256']
                info = tarfile.TarInfo(item['name'])
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))

artifacts = []
for original, name in [('capture/manifest.json', 'capture.json.gz'),
                       ('replay/results.json', 'replay.json.gz'),
                       ('audit.json', 'audit.json')]:
    source = RAW / original
    data = source.read_bytes()
    with (OUT / name).open('xb') as stream:
        stream.write(gzip.compress(data, mtime=0) if name.endswith('.gz') else data)
    restored = gzip.decompress((OUT / name).read_bytes()) if name.endswith('.gz') else (OUT / name).read_bytes()
    assert restored == data
    artifacts.append(dict(name=name, raw_path=str(source), original=record(source), **record(OUT / name)))

with tarfile.open(OUT / 'evidence.tar.gz', 'r:gz') as archive:
    assert archive.getnames() == [item['name'] for item in members]
    for item in members:
        data = archive.extractfile(item['name']).read()
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
for item in members:
    assert record(Path(item['raw_path'])) == {key: item[key] for key in ('bytes', 'sha256')}
artifacts.append(dict(name='evidence.tar.gz', **record(OUT / 'evidence.tar.gz')))
assert sum(item['bytes'] for item in artifacts) < 4 * 1024 * 1024
inventory = dict(format='native-cohort-archive-inventory-v1', artifacts=artifacts,
                 members=members, excluded_tensor_files=excluded)
write_json('inventory.json', inventory)
provenance = dict(
    format='native-no-specialization-checkpoint-v1', frozen_unix=time.time(),
    raw_root=str(RAW), raw_user_spelling='/tmp/luisa-pointwise-no-specialization.whVpcS',
    inventory_sha256=record(OUT / 'inventory.json')['sha256'],
    raw_capture=str(RAW / 'capture/manifest.json'), raw_replay=str(RAW / 'replay/results.json'),
    raw_audit=str(RAW / 'audit.json'), selected_cases=m['selected_cases'],
    captured_cases=6, native_timed_visits=108, native_output_checks=len(a['native_output_checks']),
    identity_checks=a['identity_checks'], rejected_mutations=a['rejected_mutations'], audit_status=a['status'],
    source_root=m['source_root'], binary=m['binary'], baseline_manifest=m['baseline_manifest'],
    full_build_gate=m['full_build_gate'], fixed_environment=m['fixed_environment'],
    comparison='Only pointwise fusion off/on within this independent no-specialization cohort is a paired causal comparison. Both sides disable full-packet specialization. Do not compare against earlier specialization-enabled cohorts as a paired single-variable experiment.',
    timing_scope='Fixed-candidate, one-host-thread native-entry host-wall replay under recorded desktop background load. Capture Runtime timing is not comparative. Not a default-planner result, quiet-machine claim or global parity claim. Original Inductor same-cohort visits are retained as baseline observations.',
    raw_json_policy='Original JSON bytes preserved without rewriting paths, hashes, sources, metadata or results.',
    runner_freeze='Seven supplemental runner/auditor/test source copies were frozen before canonical runner changes; five capture/replay runner identities match the manifests. Actual capture/replay runner-sources directories are also retained.',
    included='Actual emitted LLVM, ORC object and assembly, linked entry dylib, Inductor source/wrapper/library, ABI header/helper dylib, logs, frozen runners, fixture source and referenced full-build log.',
    excluded=dict(tensor_files=len(excluded), tensor_bytes=sum(item['bytes'] for item in excluded),
                  tensor_hash_policy='Recorded hashes are copied from original artifact maps without re-reading tensor bytes during archival.',
                  other=['full compiler source tree', 'whole build binary closure', 'external LLVM/Torch/TVM installation', 'Doxygen XML']),
    replayability=dict(self_contained=False, tensor_payloads_persistently_archived=False,
        limitation='The original raw inputs/expected/output arrays and external dependencies are required to replay or independently repeat the full tensor audit. The audit actually re-read outputs at audit time; archive verification does not repeat numerical validation. Runtime/workspace guards were checked during execution and were not retained.',
        regeneration='The archived validation/tile_llm_test_utils.h and runners/compare_llm.py identify fixture/oracle rules. Regenerated inputs must match original input SHA256 values; different host float/libm evaluation is not assumed bit-identical. New capture/replay/audit is a new experiment and cannot restore original missing output bytes.'),
    verification=dict(tar_members=len(members), compressed_json_streams=2, raw_audit_copied=True,
                      source_members_rehashed_before_after=True, byte_identity_passed=True),
    ownership='notes.md and other root-authored reporting files are outside this inventory; no kernels, builds, benchmarks or tests were executed by the archiver.')
write_json('provenance.json', provenance)
print(json.dumps(dict(output=str(OUT), bytes=sum(item['bytes'] for item in artifacts),
                      members=len(members), excluded_tensors=len(excluded),
                      excluded_tensor_bytes=sum(item['bytes'] for item in excluded),
                      archive_sha256=record(OUT / 'evidence.tar.gz')['sha256'],
                      evidence_extensions=collections.Counter(Path(item['name']).suffix for item in members)), indent=2))

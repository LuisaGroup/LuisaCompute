
/private/tmp/luisa-load-reduction.5Rhilw/native-1024-l8/inductor/nd/cndhjxaimbuivqizlftzw46bjr5cc3olpwt2i4tjsllowei7vu46.main.so:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000006b0 <_kernel>:
     6b0:      	sub	sp, sp, #0xb0
     6b4:      	stp	d11, d10, [sp, #0x40]
     6b8:      	stp	d9, d8, [sp, #0x50]
     6bc:      	stp	x26, x25, [sp, #0x60]
     6c0:      	stp	x24, x23, [sp, #0x70]
     6c4:      	stp	x22, x21, [sp, #0x80]
     6c8:      	stp	x20, x19, [sp, #0x90]
     6cc:      	stp	x29, x30, [sp, #0xa0]
     6d0:      	add	x29, sp, #0xa0
     6d4:      	mov	x19, #0x0               ; =0
     6d8:      	str	wzr, [sp, #0x20]
     6dc:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     6e0:      	ldr	x20, [x20, #0x90]
     6e4:      	add	x8, sp, #0x20
     6e8:      	str	x8, [x20]
     6ec:      	mov	w8, #0x39800000         ; =964689920
     6f0:      	fmov	s8, w8
     6f4:      	mov	w8, #0xc5ac             ; =50604
     6f8:      	movk	w8, #0x3727, lsl #16
     6fc:      	fmov	s9, w8
     700:      	fmov	s10, #1.00000000
     704:      	b	0x71c <_kernel+0x6c>
     708:      	add	x19, x19, #0x1
     70c:      	add	x0, x0, #0x4, lsl #12   ; =0x4000
     710:      	add	x3, x3, #0x4, lsl #12   ; =0x4000
     714:      	cmp	x19, #0x400
     718:      	b.eq	0x7d0 <_kernel+0x120>
     71c:      	movi.2d	v0, #0000000000000000
     720:      	mov	x8, #-0x4               ; =-4
     724:      	mov	x9, x0
     728:      	ldr	q1, [x9], #0x10
     72c:      	fmul.4s	v1, v1, v1
     730:      	fadd.4s	v0, v0, v1
     734:      	add	x8, x8, #0x4
     738:      	cmp	x8, #0xffc
     73c:      	b.lo	0x728 <_kernel+0x78>
     740:      	mov	x21, #0x0               ; =0
     744:      	dup.2d	v1, v0[1]
     748:      	fadd.4s	v0, v0, v1
     74c:      	faddp.2s	s0, v0
     750:      	str	s0, [x2, x19, lsl #2]
     754:      	mov	x22, #-0x4              ; =-4
     758:      	ldr	q2, [x0, x21]
     75c:      	ldr	s0, [x2, x19, lsl #2]
     760:      	ldr	q3, [x1, x21]
     764:      	fmul	s0, s0, s8
     768:      	fadd	s1, s0, s9
     76c:      	fsqrt	s0, s1
     770:      	fcmp	s0, s0
     774:      	b.vs	0x79c <_kernel+0xec>
     778:      	fdiv	s0, s10, s0
     77c:      	fmul.4s	v0, v2, v0[0]
     780:      	fmul.4s	v0, v3, v0
     784:      	str	q0, [x3, x21]
     788:      	add	x22, x22, #0x4
     78c:      	add	x21, x21, #0x10
     790:      	cmp	x22, #0xffc
     794:      	b.lo	0x758 <_kernel+0xa8>
     798:      	b	0x708 <_kernel+0x58>
     79c:      	mov.16b	v0, v1
     7a0:      	mov	x23, x3
     7a4:      	mov	x25, x2
     7a8:      	mov	x24, x1
     7ac:      	mov	x26, x0
     7b0:      	stp	q3, q2, [sp]
     7b4:      	bl	0x1770 <dyld_stub_binder+0x1770>
     7b8:      	ldp	q3, q2, [sp]
     7bc:      	mov	x0, x26
     7c0:      	mov	x1, x24
     7c4:      	mov	x2, x25
     7c8:      	mov	x3, x23
     7cc:      	b	0x778 <_kernel+0xc8>
     7d0:      	str	xzr, [x20]
     7d4:      	add	x8, sp, #0x20
     7d8:      	ldapr	w8, [x8]
     7dc:      	cbnz	w8, 0x804 <_kernel+0x154>
     7e0:      	ldp	x29, x30, [sp, #0xa0]
     7e4:      	ldp	x20, x19, [sp, #0x90]
     7e8:      	ldp	x22, x21, [sp, #0x80]
     7ec:      	ldp	x24, x23, [sp, #0x70]
     7f0:      	ldp	x26, x25, [sp, #0x60]
     7f4:      	ldp	d9, d8, [sp, #0x50]
     7f8:      	ldp	d11, d10, [sp, #0x40]
     7fc:      	add	sp, sp, #0xb0
     800:      	ret
     804:      	mov	w0, #0x10               ; =16
     808:      	bl	0x1704 <dyld_stub_binder+0x1704>
     80c:      	mov	x19, x0
     810:      	mov	w8, #0x33d              ; =829
     814:      	str	w8, [sp, #0x24]
     818:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     81c:      	add	x0, x0, #0xa40
     820:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     824:      	add	x1, x1, #0xacc
     828:      	adrp	x3, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     82c:      	add	x3, x3, #0xaf7
     830:      	adrp	x4, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     834:      	add	x4, x4, #0xb75
     838:      	adrp	x2, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     83c:      	add	x2, x2, #0xaf4
     840:      	add	x8, sp, #0x28
     844:      	add	x5, sp, #0x24
     848:      	adrp	x7, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     84c:      	add	x7, x7, #0xb77
     850:      	mov	x6, x2
     854:      	bl	0x8c8 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>
     858:      	mov	w21, #0x1               ; =1
     85c:      	add	x1, sp, #0x28
     860:      	mov	x0, x19
     864:      	bl	0x1650 <dyld_stub_binder+0x1650>
     868:      	mov	w21, #0x0               ; =0
     86c:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     870:      	ldr	x1, [x1, #0x18]
     874:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     878:      	ldr	x2, [x2, #0x8]
     87c:      	mov	x0, x19
     880:      	bl	0x1734 <dyld_stub_binder+0x1734>
     884:      	brk	#0x1
     888:      	mov	x20, x0
     88c:      	ldrsb	w8, [sp, #0x3f]
     890:      	tbz	w8, #0x1f, 0x8ac <_kernel+0x1fc>
     894:      	ldr	x0, [sp, #0x28]
     898:      	ldr	x8, [sp, #0x38]
     89c:      	and	x1, x8, #0x7fffffffffffffff
     8a0:      	bl	0x16ec <dyld_stub_binder+0x16ec>
     8a4:      	tbnz	w21, #0x0, 0x8b8 <_kernel+0x208>
     8a8:      	b	0x8c0 <_kernel+0x210>
     8ac:      	cbnz	w21, 0x8b8 <_kernel+0x208>
     8b0:      	b	0x8c0 <_kernel+0x210>
     8b4:      	mov	x20, x0
     8b8:      	mov	x0, x19
     8bc:      	bl	0x1728 <dyld_stub_binder+0x1728>
     8c0:      	mov	x0, x20
     8c4:      	bl	0x1614 <dyld_stub_binder+0x1614>

00000000000008c8 <__ZN3c106detail17torchCheckMsgImplIJA40_cA3_cA126_cA2_ciS3_A18_cEEEDaPKcDpRKT_>:
     8c8:      	sub	sp, sp, #0x40
     8cc:      	stp	x29, x30, [sp, #0x30]
     8d0:      	add	x29, sp, #0x30
     8d4:      	mov	x9, x5
     8d8:      	stp	x2, x1, [x29, #-0x10]
     8dc:      	stp	x4, x3, [sp, #0x10]
     8e0:      	stp	x7, x6, [sp]
     8e4:      	sub	x0, x29, #0x8
     8e8:      	sub	x1, x29, #0x10
     8ec:      	add	x2, sp, #0x18
     8f0:      	add	x3, sp, #0x10
     8f4:      	add	x5, sp, #0x8
     8f8:      	mov	x6, sp
     8fc:      	mov	x4, x9
     900:      	bl	0x910 <__ZN3c106detail12_str_wrapperIJPKcS3_S3_S3_RKiS3_S3_EE4callERKS3_S8_S8_S8_S5_S8_S8_>
     904:      	ldp	x29, x30, [sp, #0x30]
     908:      	add	sp, sp, #0x40
     90c:      	ret

0000000000000910 <__ZN3c106detail12_str_wrapperIJPKcS3_S3_S3_RKiS3_S3_EE4callERKS3_S8_S8_S8_S5_S8_S8_>:
     910:      	sub	sp, sp, #0x170
     914:      	stp	x28, x27, [sp, #0x110]
     918:      	stp	x26, x25, [sp, #0x120]
     91c:      	stp	x24, x23, [sp, #0x130]
     920:      	stp	x22, x21, [sp, #0x140]
     924:      	stp	x20, x19, [sp, #0x150]
     928:      	stp	x29, x30, [sp, #0x160]
     92c:      	add	x29, sp, #0x160
     930:      	mov	x20, x6
     934:      	mov	x21, x5
     938:      	mov	x22, x4
     93c:      	mov	x23, x3
     940:      	mov	x24, x2
     944:      	mov	x25, x1
     948:      	mov	x26, x0
     94c:      	mov	x19, x8
     950:      	add	x0, sp, #0x8
     954:      	bl	0xac4 <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEEC1B9nqe220108Ev>
     958:      	ldr	x26, [x26]
     95c:      	mov	x0, x26
     960:      	bl	0x177c <dyld_stub_binder+0x177c>
     964:      	mov	x2, x0
     968:      	add	x0, sp, #0x8
     96c:      	mov	x1, x26
     970:      	bl	0xe64 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     974:      	ldr	x25, [x25]
     978:      	mov	x0, x25
     97c:      	bl	0x177c <dyld_stub_binder+0x177c>
     980:      	mov	x2, x0
     984:      	add	x0, sp, #0x8
     988:      	mov	x1, x25
     98c:      	bl	0xe64 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     990:      	ldr	x24, [x24]
     994:      	mov	x0, x24
     998:      	bl	0x177c <dyld_stub_binder+0x177c>
     99c:      	mov	x2, x0
     9a0:      	add	x0, sp, #0x8
     9a4:      	mov	x1, x24
     9a8:      	bl	0xe64 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     9ac:      	ldr	x23, [x23]
     9b0:      	mov	x0, x23
     9b4:      	bl	0x177c <dyld_stub_binder+0x177c>
     9b8:      	mov	x2, x0
     9bc:      	add	x0, sp, #0x8
     9c0:      	mov	x1, x23
     9c4:      	bl	0xe64 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     9c8:      	ldr	w1, [x22]
     9cc:      	add	x0, sp, #0x8
     9d0:      	bl	0x168c <dyld_stub_binder+0x168c>
     9d4:      	ldr	x21, [x21]
     9d8:      	mov	x0, x21
     9dc:      	bl	0x177c <dyld_stub_binder+0x177c>
     9e0:      	mov	x2, x0
     9e4:      	add	x0, sp, #0x8
     9e8:      	mov	x1, x21
     9ec:      	bl	0xe64 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     9f0:      	ldr	x20, [x20]
     9f4:      	mov	x0, x20
     9f8:      	bl	0x177c <dyld_stub_binder+0x177c>
     9fc:      	mov	x2, x0
     a00:      	add	x21, sp, #0x8
     a04:      	add	x0, sp, #0x8
     a08:      	mov	x1, x20
     a0c:      	bl	0xe64 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>
     a10:      	add	x0, x21, #0x8
     a14:      	mov	x8, x19
     a18:      	bl	0x1188 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev>
     a1c:      	adrp	x19, 0x4000 <dyld_stub_binder+0x4000>
     a20:      	ldr	x19, [x19, #0x28]
     a24:      	ldr	x8, [x19]
     a28:      	str	x8, [sp, #0x8]
     a2c:      	ldr	x9, [x19, #0x18]
     a30:      	ldur	x8, [x8, #-0x18]
     a34:      	add	x20, sp, #0x8
     a38:      	str	x9, [x20, x8]
     a3c:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     a40:      	ldr	x8, [x8, #0x38]
     a44:      	add	x8, x8, #0x10
     a48:      	str	x8, [sp, #0x10]
     a4c:      	ldrsb	w8, [sp, #0x67]
     a50:      	tbz	w8, #0x1f, 0xa64 <__ZN3c106detail12_str_wrapperIJPKcS3_S3_S3_RKiS3_S3_EE4callERKS3_S8_S8_S8_S5_S8_S8_+0x154>
     a54:      	ldr	x0, [sp, #0x50]
     a58:      	ldr	x8, [sp, #0x60]
     a5c:      	and	x1, x8, #0x7fffffffffffffff
     a60:      	bl	0x16ec <dyld_stub_binder+0x16ec>
     a64:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     a68:      	ldr	x8, [x8, #0x30]
     a6c:      	add	x8, x8, #0x10
     a70:      	str	x8, [sp, #0x10]
     a74:      	add	x0, x20, #0x10
     a78:      	bl	0x16a4 <dyld_stub_binder+0x16a4>
     a7c:      	add	x0, sp, #0x8
     a80:      	add	x1, x19, #0x8
     a84:      	bl	0x1680 <dyld_stub_binder+0x1680>
     a88:      	add	x0, x20, #0x70
     a8c:      	bl	0x16d4 <dyld_stub_binder+0x16d4>
     a90:      	ldp	x29, x30, [sp, #0x160]
     a94:      	ldp	x20, x19, [sp, #0x150]
     a98:      	ldp	x22, x21, [sp, #0x140]
     a9c:      	ldp	x24, x23, [sp, #0x130]
     aa0:      	ldp	x26, x25, [sp, #0x120]
     aa4:      	ldp	x28, x27, [sp, #0x110]
     aa8:      	add	sp, sp, #0x170
     aac:      	ret
     ab0:      	mov	x19, x0
     ab4:      	add	x0, sp, #0x8
     ab8:      	bl	0xbfc <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEED1Ev>
     abc:      	mov	x0, x19
     ac0:      	bl	0x1614 <dyld_stub_binder+0x1614>

0000000000000ac4 <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEEC1B9nqe220108Ev>:
     ac4:      	stp	x24, x23, [sp, #-0x40]!
     ac8:      	stp	x22, x21, [sp, #0x10]
     acc:      	stp	x20, x19, [sp, #0x20]
     ad0:      	stp	x29, x30, [sp, #0x30]
     ad4:      	add	x29, sp, #0x30
     ad8:      	mov	x20, x0
     adc:      	adrp	x24, 0x4000 <dyld_stub_binder+0x4000>
     ae0:      	ldr	x24, [x24, #0x40]
     ae4:      	add	x23, x24, #0x40
     ae8:      	mov	x19, x0
     aec:      	str	x23, [x19, #0x70]!
     af0:      	str	xzr, [x0, #0xa0]
     af4:      	adrp	x22, 0x4000 <dyld_stub_binder+0x4000>
     af8:      	ldr	x22, [x22, #0x28]
     afc:      	ldp	x8, x9, [x22, #0x8]
     b00:      	str	x8, [x0]
     b04:      	ldur	x8, [x8, #-0x18]
     b08:      	str	x9, [x0, x8]
     b0c:      	ldr	x8, [x0]
     b10:      	ldur	x8, [x8, #-0x18]
     b14:      	add	x21, x0, x8
     b18:      	add	x1, x0, #0x8
     b1c:      	mov	x0, x21
     b20:      	bl	0x16bc <dyld_stub_binder+0x16bc>
     b24:      	str	xzr, [x21, #0x88]
     b28:      	mov	w8, #-0x1               ; =-1
     b2c:      	str	w8, [x21, #0x90]
     b30:      	add	x8, x24, #0x18
     b34:      	str	x23, [x20, #0x70]
     b38:      	adrp	x23, 0x4000 <dyld_stub_binder+0x4000>
     b3c:      	ldr	x23, [x23, #0x30]
     b40:      	add	x9, x23, #0x10
     b44:      	stp	x8, x9, [x20]
     b48:      	add	x0, x20, #0x10
     b4c:      	bl	0x1698 <dyld_stub_binder+0x1698>
     b50:      	movi.2d	v0, #0000000000000000
     b54:      	stur	q0, [x20, #0x38]
     b58:      	stur	q0, [x20, #0x28]
     b5c:      	stur	q0, [x20, #0x18]
     b60:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     b64:      	ldr	x8, [x8, #0x38]
     b68:      	add	x8, x8, #0x10
     b6c:      	str	x8, [x20, #0x8]
     b70:      	stur	q0, [x20, #0x48]
     b74:      	stur	q0, [x20, #0x58]
     b78:      	mov	w8, #0x10               ; =16
     b7c:      	str	w8, [x20, #0x68]
     b80:      	add	x0, x20, #0x8
     b84:      	bl	0xc8c <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev>
     b88:      	mov	x0, x20
     b8c:      	ldp	x29, x30, [sp, #0x30]
     b90:      	ldp	x20, x19, [sp, #0x20]
     b94:      	ldp	x22, x21, [sp, #0x10]
     b98:      	ldp	x24, x23, [sp], #0x40
     b9c:      	ret
     ba0:      	mov	x21, x0
     ba4:      	ldrsb	w8, [x20, #0x5f]
     ba8:      	tbz	w8, #0x1f, 0xbbc <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEEC1B9nqe220108Ev+0xf8>
     bac:      	ldr	x0, [x20, #0x48]
     bb0:      	ldr	x8, [x20, #0x58]
     bb4:      	and	x1, x8, #0x7fffffffffffffff
     bb8:      	bl	0x16ec <dyld_stub_binder+0x16ec>
     bbc:      	add	x8, x23, #0x10
     bc0:      	str	x8, [x20, #0x8]
     bc4:      	add	x0, x20, #0x10
     bc8:      	bl	0x16a4 <dyld_stub_binder+0x16a4>
     bcc:      	add	x1, x22, #0x8
     bd0:      	mov	x0, x20
     bd4:      	bl	0x1680 <dyld_stub_binder+0x1680>
     bd8:      	mov	x0, x19
     bdc:      	bl	0x16d4 <dyld_stub_binder+0x16d4>
     be0:      	mov	x0, x21
     be4:      	bl	0x1614 <dyld_stub_binder+0x1614>
     be8:      	mov	x21, x0
     bec:      	mov	x0, x19
     bf0:      	bl	0x16d4 <dyld_stub_binder+0x16d4>
     bf4:      	mov	x0, x21
     bf8:      	bl	0x1614 <dyld_stub_binder+0x1614>

0000000000000bfc <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEED1Ev>:
     bfc:      	stp	x20, x19, [sp, #-0x20]!
     c00:      	stp	x29, x30, [sp, #0x10]
     c04:      	add	x29, sp, #0x10
     c08:      	mov	x19, x0
     c0c:      	adrp	x20, 0x4000 <dyld_stub_binder+0x4000>
     c10:      	ldr	x20, [x20, #0x28]
     c14:      	ldr	x8, [x20]
     c18:      	str	x8, [x0]
     c1c:      	ldr	x9, [x20, #0x18]
     c20:      	ldur	x8, [x8, #-0x18]
     c24:      	str	x9, [x0, x8]
     c28:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     c2c:      	ldr	x8, [x8, #0x38]
     c30:      	add	x8, x8, #0x10
     c34:      	str	x8, [x0, #0x8]
     c38:      	ldrsb	w8, [x0, #0x5f]
     c3c:      	tbz	w8, #0x1f, 0xc50 <__ZNSt3__119basic_ostringstreamIcNS_11char_traitsIcEENS_9allocatorIcEEED1Ev+0x54>
     c40:      	ldr	x0, [x19, #0x48]
     c44:      	ldr	x8, [x19, #0x58]
     c48:      	and	x1, x8, #0x7fffffffffffffff
     c4c:      	bl	0x16ec <dyld_stub_binder+0x16ec>
     c50:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     c54:      	ldr	x8, [x8, #0x30]
     c58:      	add	x8, x8, #0x10
     c5c:      	str	x8, [x19, #0x8]
     c60:      	add	x0, x19, #0x10
     c64:      	bl	0x16a4 <dyld_stub_binder+0x16a4>
     c68:      	add	x1, x20, #0x8
     c6c:      	mov	x0, x19
     c70:      	bl	0x1680 <dyld_stub_binder+0x1680>
     c74:      	add	x0, x19, #0x70
     c78:      	bl	0x16d4 <dyld_stub_binder+0x16d4>
     c7c:      	mov	x0, x19
     c80:      	ldp	x29, x30, [sp, #0x10]
     c84:      	ldp	x20, x19, [sp], #0x20
     c88:      	ret

0000000000000c8c <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev>:
     c8c:      	stp	x22, x21, [sp, #-0x30]!
     c90:      	stp	x20, x19, [sp, #0x10]
     c94:      	stp	x29, x30, [sp, #0x20]
     c98:      	add	x29, sp, #0x20
     c9c:      	mov	x8, x0
     ca0:      	ldr	x9, [x8, #0x40]!
     ca4:      	str	xzr, [x8, #0x18]
     ca8:      	ldrb	w11, [x8, #0x17]
     cac:      	sxtb	w10, w11
     cb0:      	cmp	w10, #0x0
     cb4:      	csel	x19, x9, x8, mi
     cb8:      	ldr	x12, [x8, #0x8]
     cbc:      	and	x11, x11, #0xff
     cc0:      	csel	x20, x12, x11, mi
     cc4:      	ldr	w11, [x8, #0x20]
     cc8:      	tbz	w11, #0x3, 0xcdc <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x50>
     ccc:      	add	x12, x19, x20
     cd0:      	str	x12, [x0, #0x58]
     cd4:      	stp	x19, x19, [x0, #0x10]
     cd8:      	str	x12, [x0, #0x20]
     cdc:      	tbz	w11, #0x4, 0xdbc <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x130>
     ce0:      	add	x11, x19, x20
     ce4:      	str	x11, [x0, #0x58]
     ce8:      	ldr	x11, [x0, #0x50]
     cec:      	and	x11, x11, #0x7fffffffffffffff
     cf0:      	sub	x12, x11, #0x1
     cf4:      	cmp	w10, #0x0
     cf8:      	mov	w11, #0x16              ; =22
     cfc:      	csel	x11, x12, x11, mi
     d00:      	subs	x1, x11, x20
     d04:      	b.ls	0xd20 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x94>
     d08:      	mov	x21, x0
     d0c:      	mov	x0, x8
     d10:      	mov	w2, #0x0                ; =0
     d14:      	bl	0x165c <dyld_stub_binder+0x165c>
     d18:      	mov	x0, x21
     d1c:      	b	0xd3c <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xb0>
     d20:      	tbnz	w10, #0x1f, 0xd30 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xa4>
     d24:      	mov	w9, #0x16               ; =22
     d28:      	strb	w9, [x0, #0x57]
     d2c:      	b	0xd38 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0xac>
     d30:      	str	x12, [x0, #0x48]
     d34:      	mov	x8, x9
     d38:      	strb	wzr, [x8, x11]
     d3c:      	ldrb	w8, [x0, #0x57]
     d40:      	ldr	x9, [x0, #0x48]
     d44:      	tst	w8, #0x80
     d48:      	csel	x8, x9, x8, ne
     d4c:      	add	x8, x19, x8
     d50:      	stp	x19, x19, [x0, #0x28]
     d54:      	str	x8, [x0, #0x38]
     d58:      	ldrb	w8, [x0, #0x60]
     d5c:      	tst	w8, #0x3
     d60:      	b.eq	0xdbc <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x130>
     d64:      	lsr	x8, x20, #31
     d68:      	cbz	x8, 0xdb0 <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x124>
     d6c:      	mov	x8, #-0x80000000        ; =-2147483648
     d70:      	add	x8, x20, x8
     d74:      	mov	x9, #0x5                ; =5
     d78:      	movk	x9, #0x2, lsl #32
     d7c:      	umulh	x9, x8, x9
     d80:      	sub	x8, x8, x9
     d84:      	add	x8, x9, x8, lsr #1
     d88:      	lsr	x8, x8, #30
     d8c:      	lsl	x9, x8, #31
     d90:      	mov	w10, #0x7fffffff        ; =2147483647
     d94:      	sub	x8, x9, x8
     d98:      	sub	x9, x20, x8
     d9c:      	add	x10, x19, x10
     da0:      	add	x19, x10, x8
     da4:      	mov	x8, #-0x7fffffff        ; =-2147483647
     da8:      	add	x20, x9, x8
     dac:      	str	x19, [x0, #0x30]
     db0:      	cbz	x20, 0xdbc <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev+0x130>
     db4:      	add	x8, x19, x20
     db8:      	str	x8, [x0, #0x30]
     dbc:      	ldp	x29, x30, [sp, #0x20]
     dc0:      	ldp	x20, x19, [sp, #0x10]
     dc4:      	ldp	x22, x21, [sp], #0x30
     dc8:      	ret

0000000000000dcc <___clang_call_terminate>:
     dcc:      	stp	x29, x30, [sp, #-0x10]!
     dd0:      	mov	x29, sp
     dd4:      	bl	0x1710 <dyld_stub_binder+0x1710>
     dd8:      	bl	0x16e0 <dyld_stub_binder+0x16e0>

0000000000000ddc <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE20__throw_length_errorB9nqe220108Ev>:
     ddc:      	stp	x29, x30, [sp, #-0x10]!
     de0:      	mov	x29, sp
     de4:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
     de8:      	add	x0, x0, #0xb89
     dec:      	bl	0xdf0 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc>

0000000000000df0 <__ZNSt3__120__throw_length_errorB9nqe220108EPKc>:
     df0:      	stp	x20, x19, [sp, #-0x20]!
     df4:      	stp	x29, x30, [sp, #0x10]
     df8:      	add	x29, sp, #0x10
     dfc:      	mov	x20, x0
     e00:      	mov	w0, #0x10               ; =16
     e04:      	bl	0x1704 <dyld_stub_binder+0x1704>
     e08:      	mov	x19, x0
     e0c:      	mov	x1, x20
     e10:      	bl	0xe40 <__ZNSt12length_errorC1B9nqe220108EPKc>
     e14:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     e18:      	ldr	x1, [x1, #0x78]
     e1c:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
     e20:      	ldr	x2, [x2]
     e24:      	mov	x0, x19
     e28:      	bl	0x1734 <dyld_stub_binder+0x1734>
     e2c:      	mov	x20, x0
     e30:      	mov	x0, x19
     e34:      	bl	0x1728 <dyld_stub_binder+0x1728>
     e38:      	mov	x0, x20
     e3c:      	bl	0x1614 <dyld_stub_binder+0x1614>

0000000000000e40 <__ZNSt12length_errorC1B9nqe220108EPKc>:
     e40:      	stp	x29, x30, [sp, #-0x10]!
     e44:      	mov	x29, sp
     e48:      	bl	0x1638 <dyld_stub_binder+0x1638>
     e4c:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
     e50:      	ldr	x8, [x8, #0x48]
     e54:      	add	x8, x8, #0x10
     e58:      	str	x8, [x0]
     e5c:      	ldp	x29, x30, [sp], #0x10
     e60:      	ret

0000000000000e64 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m>:
     e64:      	sub	sp, sp, #0x70
     e68:      	stp	x26, x25, [sp, #0x20]
     e6c:      	stp	x24, x23, [sp, #0x30]
     e70:      	stp	x22, x21, [sp, #0x40]
     e74:      	stp	x20, x19, [sp, #0x50]
     e78:      	stp	x29, x30, [sp, #0x60]
     e7c:      	add	x29, sp, #0x60
     e80:      	mov	x21, x2
     e84:      	mov	x20, x1
     e88:      	mov	x19, x0
     e8c:      	add	x0, sp, #0x8
     e90:      	mov	x1, x19
     e94:      	bl	0x1668 <dyld_stub_binder+0x1668>
     e98:      	ldrb	w8, [sp, #0x8]
     e9c:      	cmp	w8, #0x1
     ea0:      	b.ne	0xf4c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xe8>
     ea4:      	ldr	x8, [x19]
     ea8:      	ldur	x8, [x8, #-0x18]
     eac:      	add	x4, x19, x8
     eb0:      	ldr	x22, [x4, #0x28]
     eb4:      	ldr	w24, [x4, #0x8]
     eb8:      	ldr	w23, [x4, #0x90]
     ebc:      	cmn	w23, #0x1
     ec0:      	b.ne	0xf08 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xa4>
     ec4:      	add	x8, sp, #0x18
     ec8:      	mov	x25, x4
     ecc:      	mov	x0, x4
     ed0:      	bl	0x162c <dyld_stub_binder+0x162c>
     ed4:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
     ed8:      	ldr	x1, [x1, #0x10]
     edc:      	add	x0, sp, #0x18
     ee0:      	bl	0x1620 <dyld_stub_binder+0x1620>
     ee4:      	ldr	x8, [x0]
     ee8:      	ldr	x8, [x8, #0x38]
     eec:      	mov	w1, #0x20               ; =32
     ef0:      	blr	x8
     ef4:      	mov	x23, x0
     ef8:      	add	x0, sp, #0x18
     efc:      	bl	0x16a4 <dyld_stub_binder+0x16a4>
     f00:      	mov	x4, x25
     f04:      	str	w23, [x25, #0x90]
     f08:      	mov	w8, #0xb0               ; =176
     f0c:      	and	w8, w24, w8
     f10:      	add	x3, x20, x21
     f14:      	cmp	w8, #0x20
     f18:      	csel	x2, x3, x20, eq
     f1c:      	sxtb	w5, w23
     f20:      	mov	x0, x22
     f24:      	mov	x1, x20
     f28:      	bl	0xfd0 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_>
     f2c:      	cbnz	x0, 0xf4c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xe8>
     f30:      	ldr	x8, [x19]
     f34:      	ldur	x8, [x8, #-0x18]
     f38:      	add	x0, x19, x8
     f3c:      	ldr	w8, [x0, #0x20]
     f40:      	mov	w9, #0x5                ; =5
     f44:      	orr	w1, w8, w9
     f48:      	bl	0x16c8 <dyld_stub_binder+0x16c8>
     f4c:      	add	x0, sp, #0x8
     f50:      	bl	0x1674 <dyld_stub_binder+0x1674>
     f54:      	mov	x0, x19
     f58:      	ldp	x29, x30, [sp, #0x60]
     f5c:      	ldp	x20, x19, [sp, #0x50]
     f60:      	ldp	x22, x21, [sp, #0x40]
     f64:      	ldp	x24, x23, [sp, #0x30]
     f68:      	ldp	x26, x25, [sp, #0x20]
     f6c:      	add	sp, sp, #0x70
     f70:      	ret
     f74:      	b	0xf88 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x124>
     f78:      	mov	x20, x0
     f7c:      	add	x0, sp, #0x18
     f80:      	bl	0x16a4 <dyld_stub_binder+0x16a4>
     f84:      	b	0xf8c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x128>
     f88:      	mov	x20, x0
     f8c:      	add	x0, sp, #0x8
     f90:      	bl	0x1674 <dyld_stub_binder+0x1674>
     f94:      	b	0xf9c <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0x138>
     f98:      	mov	x20, x0
     f9c:      	mov	x0, x20
     fa0:      	bl	0x1710 <dyld_stub_binder+0x1710>
     fa4:      	ldr	x8, [x19]
     fa8:      	ldur	x8, [x8, #-0x18]
     fac:      	add	x0, x19, x8
     fb0:      	bl	0x16b0 <dyld_stub_binder+0x16b0>
     fb4:      	bl	0x171c <dyld_stub_binder+0x171c>
     fb8:      	b	0xf54 <__ZNSt3__124__put_character_sequenceB9nqe220108IcNS_11char_traitsIcEEEERNS_13basic_ostreamIT_T0_EES7_PKS4_m+0xf0>
     fbc:      	mov	x19, x0
     fc0:      	bl	0x171c <dyld_stub_binder+0x171c>
     fc4:      	mov	x0, x19
     fc8:      	bl	0x1614 <dyld_stub_binder+0x1614>
     fcc:      	bl	0xdcc <___clang_call_terminate>

0000000000000fd0 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_>:
     fd0:      	sub	sp, sp, #0x70
     fd4:      	stp	x26, x25, [sp, #0x20]
     fd8:      	stp	x24, x23, [sp, #0x30]
     fdc:      	stp	x22, x21, [sp, #0x40]
     fe0:      	stp	x20, x19, [sp, #0x50]
     fe4:      	stp	x29, x30, [sp, #0x60]
     fe8:      	add	x29, sp, #0x60
     fec:      	mov	x19, x0
     ff0:      	cbz	x0, 0x1140 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x170>
     ff4:      	mov	x24, x5
     ff8:      	mov	x20, x4
     ffc:      	mov	x22, x3
    1000:      	mov	x21, x2
    1004:      	mov	x23, x1
    1008:      	ldr	x25, [x4, #0x18]
    100c:      	sub	x26, x2, x1
    1010:      	cmp	x26, #0x1
    1014:      	b.lt	0x1038 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x68>
    1018:      	ldr	x8, [x19]
    101c:      	ldr	x8, [x8, #0x60]
    1020:      	sub	x2, x21, x23
    1024:      	mov	x0, x19
    1028:      	mov	x1, x23
    102c:      	blr	x8
    1030:      	cmp	x0, x26
    1034:      	b.ne	0x113c <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x16c>
    1038:      	sub	x8, x22, x23
    103c:      	cmp	x25, x8
    1040:      	b.le	0x1108 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x138>
    1044:      	mov	x9, #-0x9               ; =-9
    1048:      	movk	x9, #0x7fff, lsl #48
    104c:      	sub	x23, x25, x8
    1050:      	cmp	x23, x9
    1054:      	b.hs	0x1160 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x190>
    1058:      	cmp	x23, #0x17
    105c:      	b.hs	0x106c <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x9c>
    1060:      	strb	w23, [sp, #0x1f]
    1064:      	add	x25, sp, #0x8
    1068:      	b	0x1098 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0xc8>
    106c:      	and	x8, x23, #0x7ffffffffffffff8
    1070:      	add	x8, x8, #0x8
    1074:      	mov	w9, #0x19               ; =25
    1078:      	cmp	x8, #0x18
    107c:      	csel	x26, x9, x8, eq
    1080:      	mov	x0, x26
    1084:      	bl	0x16f8 <dyld_stub_binder+0x16f8>
    1088:      	mov	x25, x0
    108c:      	orr	x8, x26, #0x8000000000000000
    1090:      	stp	x0, x23, [sp, #0x8]
    1094:      	str	x8, [sp, #0x18]
    1098:      	mov	x0, x25
    109c:      	mov	x1, x24
    10a0:      	mov	x2, x23
    10a4:      	bl	0x1764 <dyld_stub_binder+0x1764>
    10a8:      	strb	wzr, [x25, x23]
    10ac:      	ldrsb	w8, [sp, #0x1f]
    10b0:      	ldr	x9, [sp, #0x8]
    10b4:      	cmp	w8, #0x0
    10b8:      	add	x8, sp, #0x8
    10bc:      	csel	x1, x9, x8, mi
    10c0:      	ldr	x8, [x19]
    10c4:      	ldr	x8, [x8, #0x60]
    10c8:      	mov	x0, x19
    10cc:      	mov	x2, x23
    10d0:      	blr	x8
    10d4:      	ldrsb	w8, [sp, #0x1f]
    10d8:      	tbnz	w8, #0x1f, 0x10e8 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x118>
    10dc:      	cmp	x0, x23
    10e0:      	b.ne	0x113c <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x16c>
    10e4:      	b	0x1108 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x138>
    10e8:      	ldr	x8, [sp, #0x8]
    10ec:      	ldr	x9, [sp, #0x18]
    10f0:      	and	x1, x9, #0x7fffffffffffffff
    10f4:      	mov	x24, x0
    10f8:      	mov	x0, x8
    10fc:      	bl	0x16ec <dyld_stub_binder+0x16ec>
    1100:      	cmp	x24, x23
    1104:      	b.ne	0x113c <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x16c>
    1108:      	sub	x22, x22, x21
    110c:      	cmp	x22, #0x1
    1110:      	b.lt	0x1134 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x164>
    1114:      	ldr	x8, [x19]
    1118:      	ldr	x8, [x8, #0x60]
    111c:      	mov	x0, x19
    1120:      	mov	x1, x21
    1124:      	mov	x2, x22
    1128:      	blr	x8
    112c:      	cmp	x0, x22
    1130:      	b.ne	0x113c <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x16c>
    1134:      	str	xzr, [x20, #0x18]
    1138:      	b	0x1140 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x170>
    113c:      	mov	x19, #0x0               ; =0
    1140:      	mov	x0, x19
    1144:      	ldp	x29, x30, [sp, #0x60]
    1148:      	ldp	x20, x19, [sp, #0x50]
    114c:      	ldp	x22, x21, [sp, #0x40]
    1150:      	ldp	x24, x23, [sp, #0x30]
    1154:      	ldp	x26, x25, [sp, #0x20]
    1158:      	add	sp, sp, #0x70
    115c:      	ret
    1160:      	bl	0xddc <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE20__throw_length_errorB9nqe220108Ev>
    1164:      	mov	x19, x0
    1168:      	ldrsb	w8, [sp, #0x1f]
    116c:      	tbz	w8, #0x1f, 0x1180 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x1b0>
    1170:      	ldr	x0, [sp, #0x8]
    1174:      	ldr	x8, [sp, #0x18]
    1178:      	and	x1, x8, #0x7fffffffffffffff
    117c:      	bl	0x16ec <dyld_stub_binder+0x16ec>
    1180:      	mov	x0, x19
    1184:      	bl	0x1614 <dyld_stub_binder+0x1614>

0000000000001188 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev>:
    1188:      	stp	x22, x21, [sp, #-0x30]!
    118c:      	stp	x20, x19, [sp, #0x10]
    1190:      	stp	x29, x30, [sp, #0x20]
    1194:      	add	x29, sp, #0x20
    1198:      	mov	x20, x0
    119c:      	mov	x19, x8
    11a0:      	ldr	w8, [x0, #0x60]
    11a4:      	tbnz	w8, #0x4, 0x11b4 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x2c>
    11a8:      	tbnz	w8, #0x3, 0x11f8 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x70>
    11ac:      	mov	x8, #0x0                ; =0
    11b0:      	b	0x120c <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x84>
    11b4:      	ldr	x8, [x20, #0x58]
    11b8:      	ldr	x9, [x20, #0x30]
    11bc:      	cmp	x8, x9
    11c0:      	b.hs	0x11cc <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x44>
    11c4:      	str	x9, [x20, #0x58]
    11c8:      	mov	x8, x9
    11cc:      	add	x9, x20, #0x28
    11d0:      	ldr	x9, [x9]
    11d4:      	subs	x8, x8, x9
    11d8:      	b.eq	0x120c <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x84>
    11dc:      	mov	x10, x20
    11e0:      	ldr	x11, [x10, #0x40]!
    11e4:      	ldrsb	w12, [x10, #0x17]
    11e8:      	cmp	w12, #0x0
    11ec:      	csel	x10, x11, x10, mi
    11f0:      	sub	x21, x9, x10
    11f4:      	b	0x1210 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x88>
    11f8:      	add	x9, x20, #0x10
    11fc:      	ldr	x8, [x20, #0x20]
    1200:      	ldr	x9, [x9]
    1204:      	subs	x8, x8, x9
    1208:      	b.ne	0x11dc <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x54>
    120c:      	mov	x21, #0x0               ; =0
    1210:      	ldr	x9, [x20, #0x50]
    1214:      	str	x9, [x19, #0x10]
    1218:      	ldr	q0, [x20, #0x40]
    121c:      	str	q0, [x19]
    1220:      	stp	xzr, xzr, [x20, #0x48]
    1224:      	str	xzr, [x20, #0x40]
    1228:      	lsr	x10, x9, #56
    122c:      	sxtb	w9, w10
    1230:      	ldr	x11, [x19, #0x8]
    1234:      	cmp	w9, #0x0
    1238:      	csel	x10, x11, x10, mi
    123c:      	add	x8, x21, x8
    1240:      	subs	x1, x8, x10
    1244:      	b.ls	0x1270 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0xe8>
    1248:      	mov	x0, x19
    124c:      	mov	w2, #0x0                ; =0
    1250:      	bl	0x165c <dyld_stub_binder+0x165c>
    1254:      	cmn	x21, #0x1
    1258:      	b.eq	0x1288 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x100>
    125c:      	mov	x0, x19
    1260:      	mov	x1, #0x0                ; =0
    1264:      	mov	x2, x21
    1268:      	bl	0x12fc <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm>
    126c:      	b	0x12c0 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x138>
    1270:      	tbnz	w9, #0x1f, 0x129c <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x114>
    1274:      	and	w9, w8, #0x7f
    1278:      	strb	w9, [x19, #0x17]
    127c:      	strb	wzr, [x19, x8]
    1280:      	cmn	x21, #0x1
    1284:      	b.ne	0x125c <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0xd4>
    1288:      	ldrsb	w8, [x19, #0x17]
    128c:      	tbnz	w8, #0x1f, 0x12b4 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x12c>
    1290:      	strb	wzr, [x19, #0x17]
    1294:      	strb	wzr, [x19]
    1298:      	b	0x12c0 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x138>
    129c:      	ldr	x9, [x19]
    12a0:      	str	x8, [x19, #0x8]
    12a4:      	strb	wzr, [x9, x8]
    12a8:      	cmn	x21, #0x1
    12ac:      	b.ne	0x125c <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0xd4>
    12b0:      	b	0x1288 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x100>
    12b4:      	ldr	x8, [x19]
    12b8:      	str	xzr, [x19, #0x8]
    12bc:      	strb	wzr, [x8]
    12c0:      	mov	x0, x20
    12c4:      	bl	0xc8c <__ZNSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE15__init_buf_ptrsB9nqe220108Ev>
    12c8:      	ldp	x29, x30, [sp, #0x20]
    12cc:      	ldp	x20, x19, [sp, #0x10]
    12d0:      	ldp	x22, x21, [sp], #0x30
    12d4:      	ret
    12d8:      	mov	x20, x0
    12dc:      	ldrsb	w8, [x19, #0x17]
    12e0:      	tbz	w8, #0x1f, 0x12f4 <__ZNOSt3__115basic_stringbufIcNS_11char_traitsIcEENS_9allocatorIcEEE3strB9nqe220108Ev+0x16c>
    12e4:      	ldr	x0, [x19]
    12e8:      	ldr	x8, [x19, #0x10]
    12ec:      	and	x1, x8, #0x7fffffffffffffff
    12f0:      	bl	0x16ec <dyld_stub_binder+0x16ec>
    12f4:      	mov	x0, x20
    12f8:      	bl	0x1614 <dyld_stub_binder+0x1614>

00000000000012fc <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm>:
    12fc:      	cbz	x2, 0x1380 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm+0x84>
    1300:      	stp	x22, x21, [sp, #-0x30]!
    1304:      	stp	x20, x19, [sp, #0x10]
    1308:      	stp	x29, x30, [sp, #0x20]
    130c:      	add	x29, sp, #0x20
    1310:      	ldrb	w9, [x0, #0x17]
    1314:      	sxtb	w8, w9
    1318:      	cmp	w8, #0x0
    131c:      	ldp	x11, x10, [x0]
    1320:      	csel	x20, x10, x9, mi
    1324:      	csel	x19, x11, x0, mi
    1328:      	sub	x9, x20, x1
    132c:      	cmp	x9, x2
    1330:      	csel	x21, x9, x2, lo
    1334:      	b.ls	0x1358 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm+0x5c>
    1338:      	sub	x2, x9, x21
    133c:      	add	x8, x19, x1
    1340:      	add	x1, x8, x21
    1344:      	mov	x22, x0
    1348:      	mov	x0, x8
    134c:      	bl	0x1758 <dyld_stub_binder+0x1758>
    1350:      	mov	x0, x22
    1354:      	ldrb	w8, [x22, #0x17]
    1358:      	sub	x9, x20, x21
    135c:      	tbnz	w8, #0x7, 0x136c <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm+0x70>
    1360:      	and	w8, w9, #0x7f
    1364:      	strb	w8, [x0, #0x17]
    1368:      	b	0x1370 <__ZNSt3__112basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEE26__erase_external_with_moveEmm+0x74>
    136c:      	str	x9, [x0, #0x8]
    1370:      	strb	wzr, [x19, x9]
    1374:      	ldp	x29, x30, [sp, #0x20]
    1378:      	ldp	x20, x19, [sp, #0x10]
    137c:      	ldp	x22, x21, [sp], #0x30
    1380:      	ret

0000000000001384 <_PyInit_kernel>:
    1384:      	sub	sp, sp, #0x30
    1388:      	stp	x20, x19, [sp, #0x10]
    138c:      	stp	x29, x30, [sp, #0x20]
    1390:      	add	x29, sp, #0x20
    1394:      	adrp	x0, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
    1398:      	add	x0, x0, #0xb96
    139c:      	bl	0x174c <dyld_stub_binder+0x174c>
    13a0:      	cbz	x0, 0x1400 <_PyInit_kernel+0x7c>
    13a4:      	mov	x19, x0
    13a8:      	str	xzr, [sp, #0x8]
    13ac:      	bl	0x1740 <dyld_stub_binder+0x1740>
    13b0:      	str	wzr, [x0]
    13b4:      	add	x1, sp, #0x8
    13b8:      	mov	x0, x19
    13bc:      	mov	w2, #0xa                ; =10
    13c0:      	bl	0x1788 <dyld_stub_binder+0x1788>
    13c4:      	mov	x20, x0
    13c8:      	bl	0x1740 <dyld_stub_binder+0x1740>
    13cc:      	ldr	w8, [x0]
    13d0:      	cbz	w8, 0x142c <_PyInit_kernel+0xa8>
    13d4:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
    13d8:      	ldr	x8, [x8, #0x60]
    13dc:      	ldr	x0, [x8]
    13e0:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
    13e4:      	add	x1, x1, #0xbf2
    13e8:      	bl	0x15fc <dyld_stub_binder+0x15fc>
    13ec:      	mov	x0, #0x0                ; =0
    13f0:      	ldp	x29, x30, [sp, #0x20]
    13f4:      	ldp	x20, x19, [sp, #0x10]
    13f8:      	add	sp, sp, #0x30
    13fc:      	ret
    1400:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
    1404:      	ldr	x8, [x8, #0x60]
    1408:      	ldr	x0, [x8]
    140c:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
    1410:      	add	x1, x1, #0xbbe
    1414:      	bl	0x15fc <dyld_stub_binder+0x15fc>
    1418:      	mov	x0, #0x0                ; =0
    141c:      	ldp	x29, x30, [sp, #0x20]
    1420:      	ldp	x20, x19, [sp, #0x10]
    1424:      	add	sp, sp, #0x30
    1428:      	ret
    142c:      	ldr	x8, [sp, #0x8]
    1430:      	cmp	x8, x19
    1434:      	b.eq	0x13d4 <_PyInit_kernel+0x50>
    1438:      	cbz	x20, 0x13d4 <_PyInit_kernel+0x50>
    143c:      	adrp	x8, 0x8000 <dyld_stub_binder+0x8000>
    1440:      	str	x20, [x8, #0x1b8]
    1444:      	adrp	x0, 0x8000 <dyld_stub_binder+0x8000>
    1448:      	add	x0, x0, #0x108
    144c:      	mov	w1, #0x3f5              ; =1013
    1450:      	bl	0x1608 <dyld_stub_binder+0x1608>
    1454:      	ldp	x29, x30, [sp, #0x20]
    1458:      	ldp	x20, x19, [sp, #0x10]
    145c:      	add	sp, sp, #0x30
    1460:      	ret

0000000000001464 <__ZL9kernel_pyP7_objectS0_>:
    1464:      	stp	x24, x23, [sp, #-0x40]!
    1468:      	stp	x22, x21, [sp, #0x10]
    146c:      	stp	x20, x19, [sp, #0x20]
    1470:      	stp	x29, x30, [sp, #0x30]
    1474:      	add	x29, sp, #0x30
    1478:      	ldr	x8, [x1, #0x8]
    147c:      	adrp	x9, 0x4000 <dyld_stub_binder+0x4000>
    1480:      	ldr	x9, [x9, #0x68]
    1484:      	cmp	x8, x9
    1488:      	b.ne	0x150c <__ZL9kernel_pyP7_objectS0_+0xa8>
    148c:      	mov	x19, x1
    1490:      	ldr	x8, [x1, #0x10]
    1494:      	cmp	x8, #0x4
    1498:      	b.ne	0x1528 <__ZL9kernel_pyP7_objectS0_+0xc4>
    149c:      	adrp	x23, 0x8000 <dyld_stub_binder+0x8000>
    14a0:      	ldr	x8, [x23, #0x1b8]
    14a4:      	ldr	x0, [x19, #0x18]
    14a8:      	blr	x8
    14ac:      	mov	x20, x0
    14b0:      	ldr	x8, [x23, #0x1b8]
    14b4:      	ldr	x0, [x19, #0x20]
    14b8:      	blr	x8
    14bc:      	mov	x21, x0
    14c0:      	ldr	x8, [x23, #0x1b8]
    14c4:      	ldr	x0, [x19, #0x28]
    14c8:      	blr	x8
    14cc:      	mov	x22, x0
    14d0:      	ldr	x8, [x23, #0x1b8]
    14d4:      	ldr	x0, [x19, #0x30]
    14d8:      	blr	x8
    14dc:      	mov	x3, x0
    14e0:      	mov	x0, x20
    14e4:      	mov	x1, x21
    14e8:      	mov	x2, x22
    14ec:      	bl	0x6b0 <_kernel>
    14f0:      	adrp	x0, 0x4000 <dyld_stub_binder+0x4000>
    14f4:      	ldr	x0, [x0, #0x70]
    14f8:      	ldp	x29, x30, [sp, #0x30]
    14fc:      	ldp	x20, x19, [sp, #0x20]
    1500:      	ldp	x22, x21, [sp, #0x10]
    1504:      	ldp	x24, x23, [sp], #0x40
    1508:      	ret
    150c:      	mov	w0, #0x10               ; =16
    1510:      	bl	0x1704 <dyld_stub_binder+0x1704>
    1514:      	mov	x19, x0
    1518:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
    151c:      	add	x1, x1, #0xc32
    1520:      	bl	0x1644 <dyld_stub_binder+0x1644>
    1524:      	b	0x1540 <__ZL9kernel_pyP7_objectS0_+0xdc>
    1528:      	mov	w0, #0x10               ; =16
    152c:      	bl	0x1704 <dyld_stub_binder+0x1704>
    1530:      	mov	x19, x0
    1534:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
    1538:      	add	x1, x1, #0xc46
    153c:      	bl	0x1644 <dyld_stub_binder+0x1644>
    1540:      	adrp	x1, 0x4000 <dyld_stub_binder+0x4000>
    1544:      	ldr	x1, [x1, #0x18]
    1548:      	adrp	x2, 0x4000 <dyld_stub_binder+0x4000>
    154c:      	ldr	x2, [x2, #0x8]
    1550:      	mov	x0, x19
    1554:      	bl	0x1734 <dyld_stub_binder+0x1734>
    1558:      	brk	#0x1
    155c:      	b	0x1560 <__ZL9kernel_pyP7_objectS0_+0xfc>
    1560:      	mov	x20, x1
    1564:      	mov	x21, x0
    1568:      	mov	x0, x19
    156c:      	bl	0x1728 <dyld_stub_binder+0x1728>
    1570:      	mov	x0, x21
    1574:      	b	0x157c <__ZL9kernel_pyP7_objectS0_+0x118>
    1578:      	mov	x20, x1
    157c:      	bl	0x1710 <dyld_stub_binder+0x1710>
    1580:      	adrp	x8, 0x4000 <dyld_stub_binder+0x4000>
    1584:      	ldr	x8, [x8, #0x60]
    1588:      	ldr	x19, [x8]
    158c:      	cmp	w20, #0x2
    1590:      	b.ne	0x15b0 <__ZL9kernel_pyP7_objectS0_+0x14c>
    1594:      	ldr	x8, [x0]
    1598:      	ldr	x8, [x8, #0x10]
    159c:      	blr	x8
    15a0:      	mov	x1, x0
    15a4:      	mov	x0, x19
    15a8:      	bl	0x15fc <dyld_stub_binder+0x15fc>
    15ac:      	b	0x15c0 <__ZL9kernel_pyP7_objectS0_+0x15c>
    15b0:      	adrp	x1, 0x1000 <__ZNSt3__116__pad_and_outputB9nqe220108IcNS_11char_traitsIcEEEENS_19ostreambuf_iteratorIT_T0_EES6_PKS4_S8_S8_RNS_8ios_baseES4_+0x30>
    15b4:      	add	x1, x1, #0xc56
    15b8:      	mov	x0, x19
    15bc:      	bl	0x15fc <dyld_stub_binder+0x15fc>
    15c0:      	bl	0x171c <dyld_stub_binder+0x171c>
    15c4:      	mov	x0, #0x0                ; =0
    15c8:      	ldp	x29, x30, [sp, #0x30]
    15cc:      	ldp	x20, x19, [sp, #0x20]
    15d0:      	ldp	x22, x21, [sp, #0x10]
    15d4:      	ldp	x24, x23, [sp], #0x40
    15d8:      	ret
    15dc:      	mov	x19, x0
    15e0:      	bl	0x171c <dyld_stub_binder+0x171c>
    15e4:      	b	0x15f0 <__ZL9kernel_pyP7_objectS0_+0x18c>
    15e8:      	mov	x19, x0
    15ec:      	bl	0x171c <dyld_stub_binder+0x171c>
    15f0:      	mov	x0, x19
    15f4:      	bl	0x1614 <dyld_stub_binder+0x1614>
    15f8:      	bl	0xdcc <___clang_call_terminate>

Disassembly of section __TEXT,__stubs:

00000000000015fc <__stubs>:
    15fc:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1600:      	ldr	x16, [x16]
    1604:      	br	x16
    1608:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    160c:      	ldr	x16, [x16, #0x8]
    1610:      	br	x16
    1614:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1618:      	ldr	x16, [x16, #0x10]
    161c:      	br	x16
    1620:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1624:      	ldr	x16, [x16, #0x18]
    1628:      	br	x16
    162c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1630:      	ldr	x16, [x16, #0x20]
    1634:      	br	x16
    1638:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    163c:      	ldr	x16, [x16, #0x28]
    1640:      	br	x16
    1644:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1648:      	ldr	x16, [x16, #0x30]
    164c:      	br	x16
    1650:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1654:      	ldr	x16, [x16, #0x38]
    1658:      	br	x16
    165c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1660:      	ldr	x16, [x16, #0x40]
    1664:      	br	x16
    1668:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    166c:      	ldr	x16, [x16, #0x48]
    1670:      	br	x16
    1674:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1678:      	ldr	x16, [x16, #0x50]
    167c:      	br	x16
    1680:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1684:      	ldr	x16, [x16, #0x58]
    1688:      	br	x16
    168c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1690:      	ldr	x16, [x16, #0x60]
    1694:      	br	x16
    1698:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    169c:      	ldr	x16, [x16, #0x68]
    16a0:      	br	x16
    16a4:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16a8:      	ldr	x16, [x16, #0x70]
    16ac:      	br	x16
    16b0:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16b4:      	ldr	x16, [x16, #0x78]
    16b8:      	br	x16
    16bc:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16c0:      	ldr	x16, [x16, #0x80]
    16c4:      	br	x16
    16c8:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16cc:      	ldr	x16, [x16, #0x88]
    16d0:      	br	x16
    16d4:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16d8:      	ldr	x16, [x16, #0x90]
    16dc:      	br	x16
    16e0:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    16e4:      	ldr	x16, [x16, #0x98]
    16e8:      	br	x16
    16ec:      	adrp	x16, 0x4000 <dyld_stub_binder+0x4000>
    16f0:      	ldr	x16, [x16, #0x80]
    16f4:      	br	x16
    16f8:      	adrp	x16, 0x4000 <dyld_stub_binder+0x4000>
    16fc:      	ldr	x16, [x16, #0x88]
    1700:      	br	x16
    1704:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1708:      	ldr	x16, [x16, #0xa0]
    170c:      	br	x16
    1710:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1714:      	ldr	x16, [x16, #0xa8]
    1718:      	br	x16
    171c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1720:      	ldr	x16, [x16, #0xb0]
    1724:      	br	x16
    1728:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    172c:      	ldr	x16, [x16, #0xb8]
    1730:      	br	x16
    1734:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1738:      	ldr	x16, [x16, #0xc0]
    173c:      	br	x16
    1740:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1744:      	ldr	x16, [x16, #0xc8]
    1748:      	br	x16
    174c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1750:      	ldr	x16, [x16, #0xd0]
    1754:      	br	x16
    1758:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    175c:      	ldr	x16, [x16, #0xd8]
    1760:      	br	x16
    1764:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1768:      	ldr	x16, [x16, #0xe0]
    176c:      	br	x16
    1770:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1774:      	ldr	x16, [x16, #0xe8]
    1778:      	br	x16
    177c:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    1780:      	ldr	x16, [x16, #0xf0]
    1784:      	br	x16
    1788:      	adrp	x16, 0x8000 <dyld_stub_binder+0x8000>
    178c:      	ldr	x16, [x16, #0xf8]
    1790:      	br	x16

Disassembly of section __TEXT,__stub_helper:

0000000000001794 <__stub_helper>:
    1794:      	adrp	x17, 0x8000 <dyld_stub_binder+0x8000>
    1798:      	add	x17, x17, #0x1b0
    179c:      	stp	x16, x17, [sp, #-0x10]!
    17a0:      	adrp	x16, 0x4000 <dyld_stub_binder+0x4000>
    17a4:      	ldr	x16, [x16, #0x58]
    17a8:      	br	x16
    17ac:      	ldr	w16, 0x17b4 <__stub_helper+0x20>
    17b0:      	b	0x1794 <__stub_helper>
    17b4:      	udf	#0x0
    17b8:      	ldr	w16, 0x17c0 <__stub_helper+0x2c>
    17bc:      	b	0x1794 <__stub_helper>
    17c0:      	udf	#0x17
    17c4:      	ldr	w16, 0x17cc <__stub_helper+0x38>
    17c8:      	b	0x1794 <__stub_helper>
    17cc:      	udf	#0x2f
    17d0:      	ldr	w16, 0x17d8 <__stub_helper+0x44>
    17d4:      	b	0x1794 <__stub_helper>
    17d8:      	udf	#0x45
    17dc:      	ldr	w16, 0x17e4 <__stub_helper+0x50>
    17e0:      	b	0x1794 <__stub_helper>
    17e4:      	udf	#0x72
    17e8:      	ldr	w16, 0x17f0 <__stub_helper+0x5c>
    17ec:      	b	0x1794 <__stub_helper>
    17f0:      	udf	#0x96
    17f4:      	ldr	w16, 0x17fc <__stub_helper+0x68>
    17f8:      	b	0x1794 <__stub_helper>
    17fc:      	udf	#0xb6
    1800:      	ldr	w16, 0x1808 <__stub_helper+0x74>
    1804:      	b	0x1794 <__stub_helper>
    1808:      	udf	#0xd8
    180c:      	ldr	w16, 0x1814 <__stub_helper+0x80>
    1810:      	b	0x1794 <__stub_helper>
    1814:      	udf	#0x139
    1818:      	ldr	w16, 0x1820 <__stub_helper+0x8c>
    181c:      	b	0x1794 <__stub_helper>
    1820:      	udf	#0x18a
    1824:      	ldr	w16, 0x182c <__stub_helper+0x98>
    1828:      	b	0x1794 <__stub_helper>
    182c:      	udf	#0x1cf
    1830:      	ldr	w16, 0x1838 <__stub_helper+0xa4>
    1834:      	b	0x1794 <__stub_helper>
    1838:      	udf	#0x211
    183c:      	ldr	w16, 0x1844 <__stub_helper+0xb0>
    1840:      	b	0x1794 <__stub_helper>
    1844:      	udf	#0x24c
    1848:      	ldr	w16, 0x1850 <__stub_helper+0xbc>
    184c:      	b	0x1794 <__stub_helper>
    1850:      	udf	#0x287
    1854:      	ldr	w16, 0x185c <__stub_helper+0xc8>
    1858:      	b	0x1794 <__stub_helper>
    185c:      	udf	#0x2a3
    1860:      	ldr	w16, 0x1868 <__stub_helper+0xd4>
    1864:      	b	0x1794 <__stub_helper>
    1868:      	udf	#0x2bf
    186c:      	ldr	w16, 0x1874 <__stub_helper+0xe0>
    1870:      	b	0x1794 <__stub_helper>
    1874:      	udf	#0x2fe
    1878:      	ldr	w16, 0x1880 <__stub_helper+0xec>
    187c:      	b	0x1794 <__stub_helper>
    1880:      	udf	#0x321
    1884:      	ldr	w16, 0x188c <__stub_helper+0xf8>
    1888:      	b	0x1794 <__stub_helper>
    188c:      	udf	#0x344
    1890:      	ldr	w16, 0x1898 <__stub_helper+0x104>
    1894:      	b	0x1794 <__stub_helper>
    1898:      	udf	#0x37b
    189c:      	ldr	w16, 0x18a4 <__stub_helper+0x110>
    18a0:      	b	0x1794 <__stub_helper>
    18a4:      	udf	#0x393
    18a8:      	ldr	w16, 0x18b0 <__stub_helper+0x11c>
    18ac:      	b	0x1794 <__stub_helper>
    18b0:      	udf	#0x3b4
    18b4:      	ldr	w16, 0x18bc <__stub_helper+0x128>
    18b8:      	b	0x1794 <__stub_helper>
    18bc:      	udf	#0x3ce
    18c0:      	ldr	w16, 0x18c8 <__stub_helper+0x134>
    18c4:      	b	0x1794 <__stub_helper>
    18c8:      	udf	#0x3e6
    18cc:      	ldr	w16, 0x18d4 <__stub_helper+0x140>
    18d0:      	b	0x1794 <__stub_helper>
    18d4:      	udf	#0x403
    18d8:      	ldr	w16, 0x18e0 <__stub_helper+0x14c>
    18dc:      	b	0x1794 <__stub_helper>
    18e0:      	udf	#0x417
    18e4:      	ldr	w16, 0x18ec <__stub_helper+0x158>
    18e8:      	b	0x1794 <__stub_helper>
    18ec:      	udf	#0x427
    18f0:      	ldr	w16, 0x18f8 <__stub_helper+0x164>
    18f4:      	b	0x1794 <__stub_helper>
    18f8:      	udf	#0x436
    18fc:      	ldr	w16, 0x1904 <__stub_helper+0x170>
    1900:      	b	0x1794 <__stub_helper>
    1904:      	udf	#0x446
    1908:      	ldr	w16, 0x1910 <__stub_helper+0x17c>
    190c:      	b	0x1794 <__stub_helper>
    1910:      	udf	#0x455
    1914:      	ldr	w16, 0x191c <__stub_helper+0x188>
    1918:      	b	0x1794 <__stub_helper>
    191c:      	udf	#0x463
    1920:      	ldr	w16, 0x1928 <__stub_helper+0x194>
    1924:      	b	0x1794 <__stub_helper>
    1928:      	udf	#0x472

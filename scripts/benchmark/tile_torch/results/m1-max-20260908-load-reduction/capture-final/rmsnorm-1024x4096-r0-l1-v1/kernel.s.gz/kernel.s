	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	sub	sp, sp, #48
	stp	d11, d10, [sp, #16]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v4
	cmhi.4s	v1, v1, v3
	uzp1.8h	v2, v1, v0
	umaxv.8h	h5, v2
	fmov	w8, s5
	tbz	w8, #0, LBB0_124
; %bb.1:                                ; %direct.activate
	ldr	x8, [x0]
Lloh4:
	adrp	x9, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x9, lCPI0_2@PAGEOFF]
	and.16b	v2, v2, v5
	addv.8h	h2, v2
	fmov	w10, s2
	and	w9, w10, #0xff
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #10
	dup.4s	v5, w11
	add.4s	v7, v5, v4
	add.4s	v3, v5, v3
	and.16b	v4, v1, v3
	ushll.2d	v19, v4, #14
	dup.2d	v3, x8
	add.2d	v17, v3, v19
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w10, #0, LBB0_125
; %bb.2:                                ; %else
	and.16b	v7, v0, v7
	ushll2.2d	v16, v4, #14
	tbnz	w9, #1, LBB0_126
LBB0_3:                                 ; %else21
	add.2d	v17, v3, v16
	tbnz	w9, #2, LBB0_127
LBB0_4:                                 ; %else24
	ushll.2d	v18, v7, #14
	tbnz	w9, #3, LBB0_128
LBB0_5:                                 ; %else27
	add.2d	v20, v3, v18
	tbnz	w9, #4, LBB0_129
LBB0_6:                                 ; %else30
	ushll2.2d	v17, v7, #14
	tbnz	w9, #5, LBB0_130
LBB0_7:                                 ; %else33
	ldr	x8, [x1, #136]
	add.2d	v20, v3, v17
	tbnz	w9, #6, LBB0_131
LBB0_8:                                 ; %else36
	tbz	w9, #7, LBB0_10
LBB0_9:                                 ; %cond.load38
	mov.d	x9, v20[1]
	ld1.s	{ v6 }[3], [x9]
LBB0_10:                                ; %else39
	ldr	x10, [x0, #16]
	ldr	x9, [x0, #48]
	fmov	w12, s2
	and	w11, w12, #0xff
	ldp	q20, q21, [x8]
	bit.16b	v21, v6, v0
	bit.16b	v20, v5, v1
	stp	q20, q21, [x8]
	mov	w13, #4                         ; =0x4
	dup.2d	v20, x13
	add.2d	v22, v3, v20
	add.2d	v23, v22, v19
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w12, #0, LBB0_132
; %bb.11:                               ; %else46
	tbnz	w11, #1, LBB0_133
LBB0_12:                                ; %else52
	add.2d	v23, v22, v16
	tbnz	w11, #2, LBB0_134
LBB0_13:                                ; %else58
	tbnz	w11, #3, LBB0_135
LBB0_14:                                ; %else64
	add.2d	v23, v22, v18
	tbnz	w11, #4, LBB0_136
LBB0_15:                                ; %else70
	tbnz	w11, #5, LBB0_137
LBB0_16:                                ; %else76
	add.2d	v22, v22, v17
	tbnz	w11, #6, LBB0_138
LBB0_17:                                ; %else82
	tbz	w11, #7, LBB0_19
LBB0_18:                                ; %cond.load84
	mov.d	x11, v22[1]
	ld1.s	{ v21 }[3], [x11]
LBB0_19:                                ; %else88
	fmov	w12, s2
	and	w11, w12, #0xff
	ldp	q22, q23, [x8, #32]
	bit.16b	v23, v21, v0
	bit.16b	v22, v20, v1
	stp	q22, q23, [x8, #32]
	mov	w13, #8                         ; =0x8
	dup.2d	v22, x13
	add.2d	v24, v3, v22
	add.2d	v25, v24, v19
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w12, #0, LBB0_139
; %bb.20:                               ; %else95
	tbnz	w11, #1, LBB0_140
LBB0_21:                                ; %else101
	add.2d	v25, v24, v16
	tbnz	w11, #2, LBB0_141
LBB0_22:                                ; %else107
	tbnz	w11, #3, LBB0_142
LBB0_23:                                ; %else113
	add.2d	v25, v24, v18
	tbnz	w11, #4, LBB0_143
LBB0_24:                                ; %else119
	tbnz	w11, #5, LBB0_144
LBB0_25:                                ; %else125
	add.2d	v24, v24, v17
	tbnz	w11, #6, LBB0_145
LBB0_26:                                ; %else131
	tbz	w11, #7, LBB0_28
LBB0_27:                                ; %cond.load133
	mov.d	x11, v24[1]
	ld1.s	{ v23 }[3], [x11]
LBB0_28:                                ; %else137
	fmov	w12, s2
	and	w11, w12, #0xff
	ldp	q24, q25, [x8, #64]
	bit.16b	v25, v23, v0
	bit.16b	v24, v22, v1
	stp	q24, q25, [x8, #64]
	mov	w13, #12                        ; =0xc
	dup.2d	v24, x13
	add.2d	v25, v3, v24
	add.2d	v26, v25, v19
	movi.2d	v19, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w12, #0, LBB0_146
; %bb.29:                               ; %else144
	tbnz	w11, #1, LBB0_147
LBB0_30:                                ; %else150
	add.2d	v16, v25, v16
	tbnz	w11, #2, LBB0_148
LBB0_31:                                ; %else156
	tbnz	w11, #3, LBB0_149
LBB0_32:                                ; %else162
	add.2d	v16, v25, v18
	tbnz	w11, #4, LBB0_150
LBB0_33:                                ; %else168
	tbnz	w11, #5, LBB0_151
LBB0_34:                                ; %else174
	add.2d	v28, v25, v17
	tbz	w11, #6, LBB0_36
LBB0_35:                                ; %cond.load176
	fmov	x12, d28
	ld1.s	{ v24 }[2], [x12]
LBB0_36:                                ; %else180
	sshll.2d	v27, v1, #0
	sshll.2d	v29, v0, #0
	sshll2.2d	v30, v1, #0
	sshll2.2d	v8, v0, #0
	ushll.2d	v31, v4, #12
	ushll.2d	v9, v7, #12
	ushll2.2d	v10, v4, #12
	ushll2.2d	v4, v7, #12
	fmul.4s	v16, v5, v5
	fmul.4s	v18, v6, v6
	fmul.4s	v17, v20, v20
	fmul.4s	v21, v21, v21
	fmul.4s	v25, v22, v22
	fmul.4s	v26, v23, v23
	tbz	w11, #7, LBB0_38
; %bb.37:                               ; %cond.load182
	mov.d	x11, v28[1]
	ld1.s	{ v24 }[3], [x11]
LBB0_38:                                ; %else186
	add	x11, x8, #32, lsl #12           ; =131072
	and.16b	v4, v8, v4
	and.16b	v5, v30, v10
	and.16b	v6, v29, v9
	and.16b	v7, v27, v31
	ldp	q20, q22, [x8, #96]
	bit.16b	v22, v24, v0
	bit.16b	v20, v19, v1
	stp	q20, q22, [x8, #96]
	fmul.4s	v19, v19, v19
	fmul.4s	v24, v24, v24
	and.16b	v20, v0, v18
	and.16b	v22, v1, v16
	and.16b	v21, v0, v21
	and.16b	v23, v1, v17
	and.16b	v18, v0, v26
	and.16b	v17, v1, v25
	and.16b	v16, v0, v24
	and.16b	v19, v1, v19
	add	x12, x8, #224
	mov	w13, #7                         ; =0x7
	fmov	w14, s2
	b	LBB0_40
LBB0_39:                                ; %else382
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v24, v22, v24
	fadd.4s	v25, v20, v25
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v26, v23, v26
	fadd.4s	v27, v21, v27
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v28, v17, v28
	fadd.4s	v29, v18, v29
	ldp	q8, q9, [x12]
	bit.16b	v9, v31, v0
	bit.16b	v8, v30, v1
	stp	q8, q9, [x12], #128
	fmul.4s	v30, v30, v30
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v16, v31
	fadd.4s	v30, v19, v30
	bit.16b	v20, v25, v0
	bit.16b	v22, v24, v1
	bit.16b	v21, v27, v0
	bit.16b	v23, v26, v1
	bit.16b	v18, v29, v0
	add	x13, x13, #4
	bit.16b	v17, v28, v1
	bit.16b	v19, v30, v1
	sub	x15, x15, #3
	bit.16b	v16, v31, v0
	cmp	x15, #4092
	b.hs	LBB0_104
LBB0_40:                                ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	sub	x15, x13, #3
	dup.2d	v26, x15
	add.2d	v24, v26, v7
	shl.2d	v24, v24, #2
	add.2d	v27, v3, v24
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w14, #0, LBB0_75
; %bb.41:                               ; %else193
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w16, w14, #0xff
	tbnz	w16, #1, LBB0_76
LBB0_42:                                ; %else199
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v27, v26, v5
	shl.2d	v27, v27, #2
	add.2d	v27, v3, v27
	tbnz	w16, #2, LBB0_77
LBB0_43:                                ; %else205
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #3, LBB0_78
LBB0_44:                                ; %else211
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v27, v26, v6
	shl.2d	v27, v27, #2
	add.2d	v27, v3, v27
	tbnz	w16, #4, LBB0_79
LBB0_45:                                ; %else217
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #5, LBB0_80
LBB0_46:                                ; %else223
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v26, v26, v4
	shl.2d	v26, v26, #2
	add.2d	v26, v3, v26
	tbnz	w16, #6, LBB0_81
LBB0_47:                                ; %else229
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #7, LBB0_49
LBB0_48:                                ; %cond.load231
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x16, v26[1]
	ld1.s	{ v25 }[3], [x16]
LBB0_49:                                ; %else235
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	w16, s2
	ldp	q26, q27, [x12, #-96]
	bit.16b	v27, v25, v0
	bit.16b	v26, v24, v1
	add	x15, x15, #1
	dup.2d	v28, x15
	stp	q26, q27, [x12, #-96]
	add.2d	v26, v28, v7
	shl.2d	v26, v26, #2
	add.2d	v29, v3, v26
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w16, #0, LBB0_82
; %bb.50:                               ; %else242
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_83
LBB0_51:                                ; %else248
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v29, v28, v5
	shl.2d	v29, v29, #2
	add.2d	v29, v3, v29
	tbnz	w16, #2, LBB0_84
LBB0_52:                                ; %else254
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #3, LBB0_85
LBB0_53:                                ; %else260
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v29, v28, v6
	shl.2d	v29, v29, #2
	add.2d	v29, v3, v29
	tbnz	w16, #4, LBB0_86
LBB0_54:                                ; %else266
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #5, LBB0_87
LBB0_55:                                ; %else272
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v28, v28, v4
	shl.2d	v28, v28, #2
	add.2d	v28, v3, v28
	tbnz	w16, #6, LBB0_88
LBB0_56:                                ; %else278
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #7, LBB0_58
LBB0_57:                                ; %cond.load280
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x16, v28[1]
	ld1.s	{ v27 }[3], [x16]
LBB0_58:                                ; %else284
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	w16, s2
	ldp	q28, q29, [x12, #-64]
	bit.16b	v29, v27, v0
	bit.16b	v28, v26, v1
	add	x15, x15, #1
	dup.2d	v30, x15
	stp	q28, q29, [x12, #-64]
	add.2d	v28, v30, v7
	shl.2d	v28, v28, #2
	add.2d	v31, v3, v28
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w16, #0, LBB0_89
; %bb.59:                               ; %else291
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_90
LBB0_60:                                ; %else297
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v31, v30, v5
	shl.2d	v31, v31, #2
	add.2d	v31, v3, v31
	tbnz	w16, #2, LBB0_91
LBB0_61:                                ; %else303
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #3, LBB0_92
LBB0_62:                                ; %else309
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v31, v30, v6
	shl.2d	v31, v31, #2
	add.2d	v31, v3, v31
	tbnz	w16, #4, LBB0_93
LBB0_63:                                ; %else315
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #5, LBB0_94
LBB0_64:                                ; %else321
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v30, v30, v4
	shl.2d	v30, v30, #2
	add.2d	v30, v3, v30
	tbnz	w16, #6, LBB0_95
LBB0_65:                                ; %else327
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #7, LBB0_67
LBB0_66:                                ; %cond.load329
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x16, v30[1]
	ld1.s	{ v29 }[3], [x16]
LBB0_67:                                ; %else333
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	w16, s2
	ldp	q30, q31, [x12, #-32]
	bit.16b	v31, v29, v0
	bit.16b	v30, v28, v1
	add	x15, x15, #1
	dup.2d	v8, x15
	stp	q30, q31, [x12, #-32]
	add.2d	v30, v8, v7
	shl.2d	v30, v30, #2
	add.2d	v9, v3, v30
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w16, #0, LBB0_96
; %bb.68:                               ; %else340
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_97
LBB0_69:                                ; %else346
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v9, v8, v5
	shl.2d	v9, v9, #2
	add.2d	v9, v3, v9
	tbnz	w16, #2, LBB0_98
LBB0_70:                                ; %else352
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #3, LBB0_99
LBB0_71:                                ; %else358
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v9, v8, v6
	shl.2d	v9, v9, #2
	add.2d	v9, v3, v9
	tbnz	w16, #4, LBB0_100
LBB0_72:                                ; %else364
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #5, LBB0_101
LBB0_73:                                ; %else370
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v8, v8, v4
	shl.2d	v8, v8, #2
	add.2d	v8, v3, v8
	tbnz	w16, #6, LBB0_102
LBB0_74:                                ; %else376
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #7, LBB0_39
	b	LBB0_103
LBB0_75:                                ; %cond.load189
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x16, d27
	ldr	s24, [x16]
	and	w16, w14, #0xff
	tbz	w16, #1, LBB0_42
LBB0_76:                                ; %cond.load195
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v27[1]
	ld1.s	{ v24 }[1], [x17]
	add.2d	v27, v26, v5
	shl.2d	v27, v27, #2
	add.2d	v27, v3, v27
	tbz	w16, #2, LBB0_43
LBB0_77:                                ; %cond.load201
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d27
	ld1.s	{ v24 }[2], [x17]
	tbz	w16, #3, LBB0_44
LBB0_78:                                ; %cond.load207
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v27[1]
	ld1.s	{ v24 }[3], [x17]
	add.2d	v27, v26, v6
	shl.2d	v27, v27, #2
	add.2d	v27, v3, v27
	tbz	w16, #4, LBB0_45
LBB0_79:                                ; %cond.load213
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d27
	ld1.s	{ v25 }[0], [x17]
	tbz	w16, #5, LBB0_46
LBB0_80:                                ; %cond.load219
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v27[1]
	ld1.s	{ v25 }[1], [x17]
	add.2d	v26, v26, v4
	shl.2d	v26, v26, #2
	add.2d	v26, v3, v26
	tbz	w16, #6, LBB0_47
LBB0_81:                                ; %cond.load225
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d26
	ld1.s	{ v25 }[2], [x17]
	tbnz	w16, #7, LBB0_48
	b	LBB0_49
LBB0_82:                                ; %cond.load238
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d29
	ldr	s26, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_51
LBB0_83:                                ; %cond.load244
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v29[1]
	ld1.s	{ v26 }[1], [x17]
	add.2d	v29, v28, v5
	shl.2d	v29, v29, #2
	add.2d	v29, v3, v29
	tbz	w16, #2, LBB0_52
LBB0_84:                                ; %cond.load250
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d29
	ld1.s	{ v26 }[2], [x17]
	tbz	w16, #3, LBB0_53
LBB0_85:                                ; %cond.load256
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v29[1]
	ld1.s	{ v26 }[3], [x17]
	add.2d	v29, v28, v6
	shl.2d	v29, v29, #2
	add.2d	v29, v3, v29
	tbz	w16, #4, LBB0_54
LBB0_86:                                ; %cond.load262
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d29
	ld1.s	{ v27 }[0], [x17]
	tbz	w16, #5, LBB0_55
LBB0_87:                                ; %cond.load268
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v29[1]
	ld1.s	{ v27 }[1], [x17]
	add.2d	v28, v28, v4
	shl.2d	v28, v28, #2
	add.2d	v28, v3, v28
	tbz	w16, #6, LBB0_56
LBB0_88:                                ; %cond.load274
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d28
	ld1.s	{ v27 }[2], [x17]
	tbnz	w16, #7, LBB0_57
	b	LBB0_58
LBB0_89:                                ; %cond.load287
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d31
	ldr	s28, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_60
LBB0_90:                                ; %cond.load293
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v31[1]
	ld1.s	{ v28 }[1], [x17]
	add.2d	v31, v30, v5
	shl.2d	v31, v31, #2
	add.2d	v31, v3, v31
	tbz	w16, #2, LBB0_61
LBB0_91:                                ; %cond.load299
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d31
	ld1.s	{ v28 }[2], [x17]
	tbz	w16, #3, LBB0_62
LBB0_92:                                ; %cond.load305
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v31[1]
	ld1.s	{ v28 }[3], [x17]
	add.2d	v31, v30, v6
	shl.2d	v31, v31, #2
	add.2d	v31, v3, v31
	tbz	w16, #4, LBB0_63
LBB0_93:                                ; %cond.load311
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d31
	ld1.s	{ v29 }[0], [x17]
	tbz	w16, #5, LBB0_64
LBB0_94:                                ; %cond.load317
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v31[1]
	ld1.s	{ v29 }[1], [x17]
	add.2d	v30, v30, v4
	shl.2d	v30, v30, #2
	add.2d	v30, v3, v30
	tbz	w16, #6, LBB0_65
LBB0_95:                                ; %cond.load323
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d30
	ld1.s	{ v29 }[2], [x17]
	tbnz	w16, #7, LBB0_66
	b	LBB0_67
LBB0_96:                                ; %cond.load336
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d9
	ldr	s30, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_69
LBB0_97:                                ; %cond.load342
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v9[1]
	ld1.s	{ v30 }[1], [x17]
	add.2d	v9, v8, v5
	shl.2d	v9, v9, #2
	add.2d	v9, v3, v9
	tbz	w16, #2, LBB0_70
LBB0_98:                                ; %cond.load348
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d9
	ld1.s	{ v30 }[2], [x17]
	tbz	w16, #3, LBB0_71
LBB0_99:                                ; %cond.load354
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v9[1]
	ld1.s	{ v30 }[3], [x17]
	add.2d	v9, v8, v6
	shl.2d	v9, v9, #2
	add.2d	v9, v3, v9
	tbz	w16, #4, LBB0_72
LBB0_100:                               ; %cond.load360
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d9
	ld1.s	{ v31 }[0], [x17]
	tbz	w16, #5, LBB0_73
LBB0_101:                               ; %cond.load366
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v9[1]
	ld1.s	{ v31 }[1], [x17]
	add.2d	v8, v8, v4
	shl.2d	v8, v8, #2
	add.2d	v8, v3, v8
	tbz	w16, #6, LBB0_74
LBB0_102:                               ; %cond.load372
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d8
	ld1.s	{ v31 }[2], [x17]
	tbz	w16, #7, LBB0_39
LBB0_103:                               ; %cond.load378
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x16, v8[1]
	ld1.s	{ v31 }[3], [x16]
	b	LBB0_39
LBB0_104:                               ; %direct.true85.preheader
	mov	x12, #0                         ; =0x0
LBB0_105:                               ; %direct.true85
                                        ; =>This Inner Loop Header: Depth=1
	add	x13, x10, x12, lsl #2
	ld1r.4s	{ v3 }, [x13]
	add	x13, x11, x12, lsl #5
	ldp	q24, q25, [x13]
	bit.16b	v25, v3, v0
	bif.16b	v3, v24, v1
	stp	q3, q25, [x13]
	add	x12, x12, #1
	cmp	x12, #1, lsl #12                ; =4096
	b.ne	LBB0_105
; %bb.106:                              ; %direct.false86
	mov	x10, #0                         ; =0x0
	fadd.4s	v3, v22, v23
	fadd.4s	v20, v20, v21
	mov	w11, #964689920                 ; =0x39800000
	dup.4s	v21, w11
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	dup.4s	v22, w11
	fadd.4s	v18, v20, v18
	fadd.4s	v3, v3, v17
	fadd.4s	v3, v3, v19
	fadd.4s	v16, v18, v16
	fmul.4s	v16, v16, v21
	fmul.4s	v3, v3, v21
	fadd.4s	v3, v3, v22
	fadd.4s	v16, v16, v22
	fsqrt.4s	v16, v16
	fsqrt.4s	v3, v3
	and.16b	v3, v1, v3
	and.16b	v16, v0, v16
	dup.2d	v17, x9
	fmov	w9, s2
	b	LBB0_108
LBB0_107:                               ; %else407
                                        ;   in Loop: Header=BB0_108 Depth=1
	add	x10, x10, #1
	cmp	x10, #1, lsl #12                ; =4096
	b.eq	LBB0_124
LBB0_108:                               ; %direct.true100
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v2, x10
	add.2d	v21, v2, v7
	add	x11, x8, x10, lsl #5
	ldp	q19, q18, [x11]
	and.16b	v19, v1, v19
	fdiv.4s	v20, v19, v3
	add	x11, x11, #32, lsl #12          ; =131072
	ldp	q22, q19, [x11]
	and.16b	v22, v1, v22
	fmul.4s	v20, v20, v22
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w9, #0, LBB0_117
; %bb.109:                              ; %else386
                                        ;   in Loop: Header=BB0_108 Depth=1
	and	w11, w9, #0xff
	tbnz	w11, #1, LBB0_118
LBB0_110:                               ; %else389
                                        ;   in Loop: Header=BB0_108 Depth=1
	add.2d	v21, v2, v5
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbnz	w11, #2, LBB0_119
LBB0_111:                               ; %else392
                                        ;   in Loop: Header=BB0_108 Depth=1
	tbz	w11, #3, LBB0_113
LBB0_112:                               ; %cond.store393
                                        ;   in Loop: Header=BB0_108 Depth=1
	mov.d	x12, v21[1]
	st1.s	{ v20 }[3], [x12]
LBB0_113:                               ; %else395
                                        ;   in Loop: Header=BB0_108 Depth=1
	add.2d	v20, v2, v6
	and.16b	v18, v0, v18
	fdiv.4s	v18, v18, v16
	and.16b	v19, v0, v19
	fmul.4s	v18, v18, v19
	shl.2d	v19, v20, #2
	add.2d	v19, v17, v19
	tbnz	w11, #4, LBB0_120
; %bb.114:                              ; %else398
                                        ;   in Loop: Header=BB0_108 Depth=1
	tbnz	w11, #5, LBB0_121
LBB0_115:                               ; %else401
                                        ;   in Loop: Header=BB0_108 Depth=1
	add.2d	v2, v2, v4
	shl.2d	v2, v2, #2
	add.2d	v2, v17, v2
	tbnz	w11, #6, LBB0_122
LBB0_116:                               ; %else404
                                        ;   in Loop: Header=BB0_108 Depth=1
	tbz	w11, #7, LBB0_107
	b	LBB0_123
LBB0_117:                               ; %cond.store
                                        ;   in Loop: Header=BB0_108 Depth=1
	fmov	x11, d21
	str	s20, [x11]
	and	w11, w9, #0xff
	tbz	w11, #1, LBB0_110
LBB0_118:                               ; %cond.store387
                                        ;   in Loop: Header=BB0_108 Depth=1
	mov.d	x12, v21[1]
	st1.s	{ v20 }[1], [x12]
	add.2d	v21, v2, v5
	shl.2d	v21, v21, #2
	add.2d	v21, v17, v21
	tbz	w11, #2, LBB0_111
LBB0_119:                               ; %cond.store390
                                        ;   in Loop: Header=BB0_108 Depth=1
	fmov	x12, d21
	st1.s	{ v20 }[2], [x12]
	tbnz	w11, #3, LBB0_112
	b	LBB0_113
LBB0_120:                               ; %cond.store396
                                        ;   in Loop: Header=BB0_108 Depth=1
	fmov	x12, d19
	str	s18, [x12]
	tbz	w11, #5, LBB0_115
LBB0_121:                               ; %cond.store399
                                        ;   in Loop: Header=BB0_108 Depth=1
	mov.d	x12, v19[1]
	st1.s	{ v18 }[1], [x12]
	add.2d	v2, v2, v4
	shl.2d	v2, v2, #2
	add.2d	v2, v17, v2
	tbz	w11, #6, LBB0_116
LBB0_122:                               ; %cond.store402
                                        ;   in Loop: Header=BB0_108 Depth=1
	fmov	x12, d2
	st1.s	{ v18 }[2], [x12]
	tbz	w11, #7, LBB0_107
LBB0_123:                               ; %cond.store405
                                        ;   in Loop: Header=BB0_108 Depth=1
	mov.d	x11, v2[1]
	st1.s	{ v18 }[3], [x11]
	b	LBB0_107
LBB0_124:                               ; %common.ret
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #48
	ret
LBB0_125:                               ; %cond.load
	fmov	x8, d17
	ldr	s5, [x8]
	and.16b	v7, v0, v7
	ushll2.2d	v16, v4, #14
	tbz	w9, #1, LBB0_3
LBB0_126:                               ; %cond.load20
	mov.d	x8, v17[1]
	ld1.s	{ v5 }[1], [x8]
	add.2d	v17, v3, v16
	tbz	w9, #2, LBB0_4
LBB0_127:                               ; %cond.load23
	fmov	x8, d17
	ld1.s	{ v5 }[2], [x8]
	ushll.2d	v18, v7, #14
	tbz	w9, #3, LBB0_5
LBB0_128:                               ; %cond.load26
	mov.d	x8, v17[1]
	ld1.s	{ v5 }[3], [x8]
	add.2d	v20, v3, v18
	tbz	w9, #4, LBB0_6
LBB0_129:                               ; %cond.load29
	fmov	x8, d20
	ld1.s	{ v6 }[0], [x8]
	ushll2.2d	v17, v7, #14
	tbz	w9, #5, LBB0_7
LBB0_130:                               ; %cond.load32
	mov.d	x8, v20[1]
	ld1.s	{ v6 }[1], [x8]
	ldr	x8, [x1, #136]
	add.2d	v20, v3, v17
	tbz	w9, #6, LBB0_8
LBB0_131:                               ; %cond.load35
	fmov	x10, d20
	ld1.s	{ v6 }[2], [x10]
	tbnz	w9, #7, LBB0_9
	b	LBB0_10
LBB0_132:                               ; %cond.load42
	fmov	x12, d23
	ldr	s20, [x12]
	tbz	w11, #1, LBB0_12
LBB0_133:                               ; %cond.load48
	mov.d	x12, v23[1]
	ld1.s	{ v20 }[1], [x12]
	add.2d	v23, v22, v16
	tbz	w11, #2, LBB0_13
LBB0_134:                               ; %cond.load54
	fmov	x12, d23
	ld1.s	{ v20 }[2], [x12]
	tbz	w11, #3, LBB0_14
LBB0_135:                               ; %cond.load60
	mov.d	x12, v23[1]
	ld1.s	{ v20 }[3], [x12]
	add.2d	v23, v22, v18
	tbz	w11, #4, LBB0_15
LBB0_136:                               ; %cond.load66
	fmov	x12, d23
	ld1.s	{ v21 }[0], [x12]
	tbz	w11, #5, LBB0_16
LBB0_137:                               ; %cond.load72
	mov.d	x12, v23[1]
	ld1.s	{ v21 }[1], [x12]
	add.2d	v22, v22, v17
	tbz	w11, #6, LBB0_17
LBB0_138:                               ; %cond.load78
	fmov	x12, d22
	ld1.s	{ v21 }[2], [x12]
	tbnz	w11, #7, LBB0_18
	b	LBB0_19
LBB0_139:                               ; %cond.load91
	fmov	x12, d25
	ldr	s22, [x12]
	tbz	w11, #1, LBB0_21
LBB0_140:                               ; %cond.load97
	mov.d	x12, v25[1]
	ld1.s	{ v22 }[1], [x12]
	add.2d	v25, v24, v16
	tbz	w11, #2, LBB0_22
LBB0_141:                               ; %cond.load103
	fmov	x12, d25
	ld1.s	{ v22 }[2], [x12]
	tbz	w11, #3, LBB0_23
LBB0_142:                               ; %cond.load109
	mov.d	x12, v25[1]
	ld1.s	{ v22 }[3], [x12]
	add.2d	v25, v24, v18
	tbz	w11, #4, LBB0_24
LBB0_143:                               ; %cond.load115
	fmov	x12, d25
	ld1.s	{ v23 }[0], [x12]
	tbz	w11, #5, LBB0_25
LBB0_144:                               ; %cond.load121
	mov.d	x12, v25[1]
	ld1.s	{ v23 }[1], [x12]
	add.2d	v24, v24, v17
	tbz	w11, #6, LBB0_26
LBB0_145:                               ; %cond.load127
	fmov	x12, d24
	ld1.s	{ v23 }[2], [x12]
	tbnz	w11, #7, LBB0_27
	b	LBB0_28
LBB0_146:                               ; %cond.load140
	fmov	x12, d26
	ldr	s19, [x12]
	tbz	w11, #1, LBB0_30
LBB0_147:                               ; %cond.load146
	mov.d	x12, v26[1]
	ld1.s	{ v19 }[1], [x12]
	add.2d	v16, v25, v16
	tbz	w11, #2, LBB0_31
LBB0_148:                               ; %cond.load152
	fmov	x12, d16
	ld1.s	{ v19 }[2], [x12]
	tbz	w11, #3, LBB0_32
LBB0_149:                               ; %cond.load158
	mov.d	x12, v16[1]
	ld1.s	{ v19 }[3], [x12]
	add.2d	v16, v25, v18
	tbz	w11, #4, LBB0_33
LBB0_150:                               ; %cond.load164
	fmov	x12, d16
	ld1.s	{ v24 }[0], [x12]
	tbz	w11, #5, LBB0_34
LBB0_151:                               ; %cond.load170
	mov.d	x12, v16[1]
	ld1.s	{ v24 }[1], [x12]
	add.2d	v28, v25, v17
	tbnz	w11, #6, LBB0_35
	b	LBB0_36
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_13
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w24, w8, [x2, #44]
	stp	w3, w8, [sp, #8]                ; 8-byte Folded Spill
	ldp	w25, w26, [x2]
	ldp	w28, w27, [x2, #8]
	str	w24, [sp, #4]                   ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #1016                       ; =0x3f8
	str	w8, [x20, #36]
	ldp	w24, w19, [sp, #4]              ; 8-byte Folded Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w24
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_12
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_9 Depth 2
                                        ;     Child Loop BB1_6 Depth 2
	ubfiz	x8, x25, #10, #32
	cmp	x8, x27
	csel	x9, x8, xzr, ls
	subs	x10, x27, x9
	cmp	x10, #1024
	mov	w11, #1024                      ; =0x400
	csel	x10, x10, x11, lo
	cmp	x27, x9
	stp	w25, w26, [x20]
	str	w28, [x20, #8]
	ccmp	x8, x27, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #1024
	b.lo	LBB1_7
; %bb.5:                                ; %packet.batch.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w23, #0                         ; =0x0
LBB1_6:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w23, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w23, w23, #8
	cmp	w23, #1024
	b.ne	LBB1_6
	b	LBB1_3
LBB1_7:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x8, x23, #3
	lsl	w24, w8, #3
	cmp	x23, #8
	b.lo	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w19, #0                         ; =0x0
LBB1_9:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w19, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w19, w19, #8
	cmp	w24, w19
	b.ne	LBB1_9
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w23, #0x7
	cbz	w2, LBB1_2
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w24, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
	b	LBB1_2
LBB1_12:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_13:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_68
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #144
	stp	d11, d10, [sp, #16]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	mov	w8, #0                          ; =0x0
	ldp	w9, w10, [x2, #44]
	str	w9, [sp, #8]                    ; 4-byte Folded Spill
	ldp	w4, w5, [x2]
Lloh0:
	adrp	x12, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x12, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x12, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x12, lCPI0_1@PAGEOFF]
	adrp	x14, lCPI0_2@PAGE
	ldp	w6, w15, [x2, #8]
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w9, w1, #1
	ldr	w11, [sp, #8]                   ; 4-byte Folded Reload
	cmp	w9, w11
	cset	w9, eq
	csinc	w4, wzr, w1, eq
	cinc	w11, w17, eq
	cmp	w11, w10
	cset	w12, eq
	ands	w9, w9, w12
	csel	w5, wzr, w11, ne
	add	w6, w16, w9
	add	w8, w8, #1
	cmp	w8, w3
	b.eq	LBB0_67
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_16 Depth 2
                                        ;       Child Loop BB0_17 Depth 3
                                        ;       Child Loop BB0_19 Depth 3
                                        ;       Child Loop BB0_21 Depth 3
                                        ;       Child Loop BB0_23 Depth 3
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_46 Depth 2
                                        ;     Child Loop BB0_48 Depth 2
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;       Child Loop BB0_6 Depth 3
                                        ;       Child Loop BB0_8 Depth 3
                                        ;       Child Loop BB0_10 Depth 3
                                        ;       Child Loop BB0_12 Depth 3
	mov	x16, x6
	mov	x17, x5
	mov	x1, x4
	ubfiz	x4, x4, #10, #32
	cmp	x4, x15
	csel	x5, x4, xzr, ls
	subs	x6, x15, x5
	cmp	x6, #1024
	mov	w9, #1024                       ; =0x400
	csel	x6, x6, x9, lo
	cmp	x15, x5
	ccmp	x4, x15, #2, hi
	csel	x4, x6, xzr, ls
	mov	w9, #964689920                  ; =0x39800000
	dup.4s	v3, w9
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	dup.4s	v2, w9
	cmp	x4, #1024
	b.lo	LBB0_14
; %bb.4:                                ; %packet.batch.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w4, #0                          ; =0x0
	ldr	x5, [x2, #136]
	add	x6, x5, #32, lsl #12            ; =131072
	ldr	x22, [x0]
	ldr	x7, [x0, #16]
	ldr	x19, [x0, #48]
	lsl	w20, w1, #10
	add	x21, x5, #224
	dup.2d	v4, x22
LBB0_5:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_6 Depth 3
                                        ;       Child Loop BB0_8 Depth 3
                                        ;       Child Loop BB0_10 Depth 3
                                        ;       Child Loop BB0_12 Depth 3
	mov	x22, #0                         ; =0x0
	add	w23, w20, w4, lsl #3
	dup.4s	v5, w23
	orr.16b	v7, v5, v0
	orr.16b	v16, v5, v1
	ushll2.2d	v5, v7, #14
	ushll2.2d	v6, v16, #14
	ushll.2d	v7, v7, #14
	ushll.2d	v16, v16, #14
	mov	x23, x5
LBB0_6:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v17, x22
	add.2d	v18, v17, v16
	add.2d	v19, v17, v6
	add.2d	v20, v17, v7
	add.2d	v17, v17, v5
	add.2d	v17, v4, v17
	add.2d	v20, v4, v20
	add.2d	v19, v4, v19
	add.2d	v18, v4, v18
	mov.d	x24, v18[1]
	fmov	x25, d18
	mov.d	x26, v19[1]
	fmov	x27, d19
	mov.d	x28, v20[1]
	fmov	x30, d20
	mov.d	x11, v17[1]
	ldr	s18, [x25]
	ld1.s	{ v18 }[1], [x24]
	fmov	x24, d17
	ld1.s	{ v18 }[2], [x27]
	ld1.s	{ v18 }[3], [x26]
	ldr	s17, [x30]
	ld1.s	{ v17 }[1], [x28]
	ld1.s	{ v17 }[2], [x24]
	ld1.s	{ v17 }[3], [x11]
	stp	q18, q17, [x23], #32
	add	x22, x22, #4
	cmp	x22, #4, lsl #12                ; =16384
	b.ne	LBB0_6
; %bb.7:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_5 Depth=2
	ldp	q17, q18, [x5]
	fmul.4s	v18, v18, v18
	fmul.4s	v17, v17, v17
	ldp	q19, q20, [x5, #32]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	ldp	q22, q21, [x5, #64]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	ldp	q23, q24, [x5, #96]
	fmul.4s	v24, v24, v24
	fmul.4s	v23, v23, v23
	mov	x22, x21
	mov	w23, #4                         ; =0x4
LBB0_8:                                 ; %direct.true48.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q26, q25, [x22, #-96]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v18, v18, v25
	fadd.4s	v17, v17, v26
	ldp	q26, q25, [x22, #-64]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v25
	fadd.4s	v19, v19, v26
	ldp	q26, q25, [x22, #-32]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v21, v21, v25
	fadd.4s	v22, v22, v26
	ldp	q26, q25, [x22], #128
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v24, v24, v25
	fadd.4s	v23, v23, v26
	cmp	x23, #4092
	add	x23, x23, #4
	b.lo	LBB0_8
; %bb.9:                                ; %direct.true95.i.i.preheader
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov	x22, #0                         ; =0x0
LBB0_10:                                ; %direct.true95.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x11, x7, x22, lsl #2
	ld1r.4s	{ v25 }, [x11]
	add	x11, x6, x22, lsl #5
	stp	q25, q25, [x11]
	add	x22, x22, #1
	cmp	x22, #1, lsl #12                ; =4096
	b.ne	LBB0_10
; %bb.11:                               ; %direct.false96.i.i
                                        ;   in Loop: Header=BB0_5 Depth=2
	mov	x22, #0                         ; =0x0
	fadd.4s	v18, v18, v20
	fadd.4s	v17, v17, v19
	fadd.4s	v17, v17, v22
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v17, v17, v23
	fmul.4s	v17, v17, v3
	fmul.4s	v18, v18, v3
	fadd.4s	v18, v18, v2
	fadd.4s	v17, v17, v2
	fsqrt.4s	v17, v17
	fsqrt.4s	v18, v18
	mov	x23, x5
LBB0_12:                                ; %direct.true110.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_5 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q20, q19, [x23]
	fdiv.4s	v20, v20, v17
	fdiv.4s	v19, v19, v18
	add	x11, x23, #32, lsl #12          ; =131072
	ldp	q21, q22, [x11]
	fmul.4s	v19, v19, v22
	fmul.4s	v20, v20, v21
	dup.2d	v21, x22
	add.2d	v22, v21, v16
	add.2d	v23, v21, v6
	add.2d	v24, v21, v7
	add.2d	v21, v21, v5
	dup.2d	v25, x19
	add.2d	v23, v25, v23
	add.2d	v22, v25, v22
	mov.d	x11, v22[1]
	fmov	x24, d22
	str	s20, [x24]
	st1.s	{ v20 }[1], [x11]
	mov.d	x11, v23[1]
	add.2d	v22, v25, v24
	fmov	x24, d23
	st1.s	{ v20 }[2], [x24]
	st1.s	{ v20 }[3], [x11]
	mov.d	x11, v22[1]
	fmov	x24, d22
	str	s19, [x24]
	st1.s	{ v19 }[1], [x11]
	add.2d	v20, v25, v21
	mov.d	x11, v20[1]
	fmov	x24, d20
	st1.s	{ v19 }[2], [x24]
	st1.s	{ v19 }[3], [x11]
	add	x22, x22, #4
	add	x23, x23, #32
	cmp	x22, #4, lsl #12                ; =16384
	b.ne	LBB0_12
; %bb.13:                               ; %llm_rows.exit.i
                                        ;   in Loop: Header=BB0_5 Depth=2
	add	w4, w4, #1
	cmp	w4, #128
	b.ne	LBB0_5
	b	LBB0_2
LBB0_14:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x19, x4, #3
	cmp	x4, #8
	b.lo	LBB0_25
; %bb.15:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w5, #0                          ; =0x0
	ldr	x6, [x2, #136]
	add	x7, x6, #32, lsl #12            ; =131072
	ldr	x20, [x0]
	ldr	x21, [x0, #16]
	ldr	x22, [x0, #48]
	lsl	w23, w1, #10
	add	x24, x6, #224
LBB0_16:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_17 Depth 3
                                        ;       Child Loop BB0_19 Depth 3
                                        ;       Child Loop BB0_21 Depth 3
                                        ;       Child Loop BB0_23 Depth 3
	mov	x25, #0                         ; =0x0
	add	w11, w23, w5, lsl #3
	dup.4s	v4, w11
	orr.16b	v6, v4, v0
	orr.16b	v7, v4, v1
	ushll2.2d	v4, v6, #14
	ushll2.2d	v5, v7, #14
	ushll.2d	v6, v6, #14
	ushll.2d	v7, v7, #14
	mov	x26, x6
LBB0_17:                                ; %direct.true.i6.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v16, x25
	add.2d	v17, v16, v7
	add.2d	v18, v16, v5
	add.2d	v19, v16, v6
	add.2d	v16, v16, v4
	dup.2d	v20, x20
	add.2d	v16, v20, v16
	add.2d	v19, v20, v19
	add.2d	v18, v20, v18
	add.2d	v17, v20, v17
	mov.d	x11, v17[1]
	fmov	x27, d17
	mov.d	x28, v18[1]
	fmov	x30, d18
	mov.d	x12, v19[1]
	fmov	x13, d19
	mov.d	x9, v16[1]
	ldr	s17, [x27]
	ld1.s	{ v17 }[1], [x11]
	fmov	x11, d16
	ld1.s	{ v17 }[2], [x30]
	ld1.s	{ v17 }[3], [x28]
	ldr	s16, [x13]
	ld1.s	{ v16 }[1], [x12]
	ld1.s	{ v16 }[2], [x11]
	ld1.s	{ v16 }[3], [x9]
	stp	q17, q16, [x26], #32
	add	x25, x25, #4
	cmp	x25, #4, lsl #12                ; =16384
	b.ne	LBB0_17
; %bb.18:                               ; %direct.false.i12.i
                                        ;   in Loop: Header=BB0_16 Depth=2
	ldp	q16, q17, [x6]
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	ldp	q18, q19, [x6, #32]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q21, q20, [x6, #64]
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	ldp	q22, q23, [x6, #96]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
	mov	x25, x24
	mov	w26, #4                         ; =0x4
LBB0_19:                                ; %direct.true48.i20.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q25, q24, [x25, #-96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v17, v17, v24
	fadd.4s	v16, v16, v25
	ldp	q25, q24, [x25, #-64]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v19, v19, v24
	fadd.4s	v18, v18, v25
	ldp	q25, q24, [x25, #-32]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v20, v20, v24
	fadd.4s	v21, v21, v25
	ldp	q25, q24, [x25], #128
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v25
	cmp	x26, #4092
	add	x26, x26, #4
	b.lo	LBB0_19
; %bb.20:                               ; %direct.true95.i35.i.preheader
                                        ;   in Loop: Header=BB0_16 Depth=2
	mov	x25, #0                         ; =0x0
LBB0_21:                                ; %direct.true95.i35.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x9, x21, x25, lsl #2
	ld1r.4s	{ v24 }, [x9]
	add	x9, x7, x25, lsl #5
	stp	q24, q24, [x9]
	add	x25, x25, #1
	cmp	x25, #1, lsl #12                ; =4096
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false96.i42.i
                                        ;   in Loop: Header=BB0_16 Depth=2
	mov	x25, #0                         ; =0x0
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	fadd.4s	v16, v16, v21
	fadd.4s	v17, v17, v20
	fadd.4s	v17, v17, v23
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v16, v3
	fmul.4s	v17, v17, v3
	fadd.4s	v17, v17, v2
	fadd.4s	v16, v16, v2
	fsqrt.4s	v16, v16
	fsqrt.4s	v17, v17
	mov	x26, x6
LBB0_23:                                ; %direct.true110.i43.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_16 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q19, q18, [x26]
	fdiv.4s	v19, v19, v16
	fdiv.4s	v18, v18, v17
	add	x9, x26, #32, lsl #12           ; =131072
	ldp	q20, q21, [x9]
	fmul.4s	v18, v18, v21
	fmul.4s	v19, v19, v20
	dup.2d	v20, x25
	add.2d	v21, v20, v7
	add.2d	v22, v20, v5
	add.2d	v23, v20, v6
	add.2d	v20, v20, v4
	dup.2d	v24, x22
	add.2d	v22, v24, v22
	add.2d	v21, v24, v21
	mov.d	x9, v21[1]
	fmov	x11, d21
	str	s19, [x11]
	st1.s	{ v19 }[1], [x9]
	mov.d	x9, v22[1]
	add.2d	v21, v24, v23
	fmov	x11, d22
	st1.s	{ v19 }[2], [x11]
	st1.s	{ v19 }[3], [x9]
	mov.d	x9, v21[1]
	fmov	x11, d21
	str	s18, [x11]
	st1.s	{ v18 }[1], [x9]
	add.2d	v19, v24, v20
	mov.d	x9, v19[1]
	fmov	x11, d19
	st1.s	{ v18 }[2], [x11]
	st1.s	{ v18 }[3], [x9]
	add	x25, x25, #4
	add	x26, x26, #32
	cmp	x25, #4, lsl #12                ; =16384
	b.ne	LBB0_23
; %bb.24:                               ; %llm_rows.exit51.i
                                        ;   in Loop: Header=BB0_16 Depth=2
	add	w5, w5, #1
	cmp	w5, w19
	b.ne	LBB0_16
LBB0_25:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w4, w4, #0x7
	cbz	w4, LBB0_2
; %bb.26:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v5, w4
	cmhi.4s	v4, v5, v0
	cmhi.4s	v5, v5, v1
	uzp1.8h	v19, v5, v4
	umaxv.8h	h6, v19
	fmov	w9, s6
	tbz	w9, #0, LBB0_2
; %bb.27:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x20, #0                         ; =0x0
	ldr	x4, [x2, #136]
	add	x6, x4, #32, lsl #12            ; =131072
	ldr	x21, [x0]
	ldr	x7, [x0, #16]
	ldr	x5, [x0, #48]
	lsl	w9, w19, #3
	orr	w9, w9, w1, lsl #10
	dup.4s	v6, w9
	orr.16b	v7, v6, v1
	orr.16b	v6, v6, v0
	and.16b	v16, v4, v6
	and.16b	v17, v5, v7
	ushll2.2d	v6, v16, #14
	ushll2.2d	v7, v17, #14
	ushll.2d	v16, v16, #14
	ushll.2d	v17, v17, #14
	mov	x19, x4
	b	LBB0_29
LBB0_28:                                ; %else212
                                        ;   in Loop: Header=BB0_29 Depth=2
	ldp	q22, q23, [x19]
	bif.16b	v21, v23, v4
	bif.16b	v20, v22, v5
	stp	q20, q21, [x19], #32
	add	x20, x20, #4
	cmp	x20, #4, lsl #12                ; =16384
	b.eq	LBB0_45
LBB0_29:                                ; %direct.true.i55.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q18, [x14, lCPI0_2@PAGEOFF]
	and.16b	v18, v19, v18
	addv.8h	h18, v18
	fmov	w22, s18
	dup.2d	v22, x20
	add.2d	v20, v22, v17
	dup.2d	v23, x21
	add.2d	v24, v23, v20
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w22, #0, LBB0_37
; %bb.30:                               ; %else
                                        ;   in Loop: Header=BB0_29 Depth=2
	and	w22, w22, #0xff
	tbnz	w22, #1, LBB0_38
LBB0_31:                                ; %else176
                                        ;   in Loop: Header=BB0_29 Depth=2
	add.2d	v24, v22, v7
	add.2d	v24, v23, v24
	tbnz	w22, #2, LBB0_39
LBB0_32:                                ; %else182
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbnz	w22, #3, LBB0_40
LBB0_33:                                ; %else188
                                        ;   in Loop: Header=BB0_29 Depth=2
	add.2d	v24, v22, v16
	add.2d	v24, v23, v24
	tbnz	w22, #4, LBB0_41
LBB0_34:                                ; %else194
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbnz	w22, #5, LBB0_42
LBB0_35:                                ; %else200
                                        ;   in Loop: Header=BB0_29 Depth=2
	add.2d	v22, v22, v6
	add.2d	v22, v23, v22
	tbnz	w22, #6, LBB0_43
LBB0_36:                                ; %else206
                                        ;   in Loop: Header=BB0_29 Depth=2
	tbz	w22, #7, LBB0_28
	b	LBB0_44
LBB0_37:                                ; %cond.load
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x9, d24
	ldr	s20, [x9]
	and	w22, w22, #0xff
	tbz	w22, #1, LBB0_31
LBB0_38:                                ; %cond.load172
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x9, v24[1]
	ld1.s	{ v20 }[1], [x9]
	add.2d	v24, v22, v7
	add.2d	v24, v23, v24
	tbz	w22, #2, LBB0_32
LBB0_39:                                ; %cond.load178
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x9, d24
	ld1.s	{ v20 }[2], [x9]
	tbz	w22, #3, LBB0_33
LBB0_40:                                ; %cond.load184
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x9, v24[1]
	ld1.s	{ v20 }[3], [x9]
	add.2d	v24, v22, v16
	add.2d	v24, v23, v24
	tbz	w22, #4, LBB0_34
LBB0_41:                                ; %cond.load190
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x9, d24
	ld1.s	{ v21 }[0], [x9]
	tbz	w22, #5, LBB0_35
LBB0_42:                                ; %cond.load196
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x9, v24[1]
	ld1.s	{ v21 }[1], [x9]
	add.2d	v22, v22, v6
	add.2d	v22, v23, v22
	tbz	w22, #6, LBB0_36
LBB0_43:                                ; %cond.load202
                                        ;   in Loop: Header=BB0_29 Depth=2
	fmov	x9, d22
	ld1.s	{ v21 }[2], [x9]
	tbz	w22, #7, LBB0_28
LBB0_44:                                ; %cond.load208
                                        ;   in Loop: Header=BB0_29 Depth=2
	mov.d	x9, v22[1]
	ld1.s	{ v21 }[3], [x9]
	b	LBB0_28
LBB0_45:                                ; %direct.false.i61.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q20, q19, [x4]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	ldp	q22, q21, [x4, #32]
	fmul.4s	v23, v22, v22
	fmul.4s	v21, v21, v21
	ldp	q24, q22, [x4, #64]
	fmul.4s	v25, v24, v24
	fmul.4s	v24, v22, v22
	ldp	q26, q22, [x4, #96]
	fmul.4s	v27, v26, v26
	fmul.4s	v28, v22, v22
	and.16b	v19, v4, v19
	and.16b	v22, v5, v20
	and.16b	v21, v4, v21
	and.16b	v26, v5, v23
	and.16b	v24, v4, v24
	and.16b	v23, v5, v25
	and.16b	v20, v4, v28
	and.16b	v25, v5, v27
	add	x19, x4, #224
	mov	w20, #4                         ; =0x4
LBB0_46:                                ; %direct.true48.i69.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q28, q27, [x19, #-96]
	and.16b	v28, v5, v28
	and.16b	v27, v4, v27
	fmul.4s	v27, v27, v27
	fmul.4s	v28, v28, v28
	fadd.4s	v28, v22, v28
	fadd.4s	v27, v19, v27
	ldp	q30, q29, [x19, #-64]
	and.16b	v30, v5, v30
	and.16b	v29, v4, v29
	fmul.4s	v29, v29, v29
	fmul.4s	v30, v30, v30
	fadd.4s	v30, v26, v30
	fadd.4s	v29, v21, v29
	ldp	q8, q31, [x19, #-32]
	and.16b	v8, v5, v8
	and.16b	v31, v4, v31
	fmul.4s	v31, v31, v31
	fmul.4s	v8, v8, v8
	fadd.4s	v8, v23, v8
	fadd.4s	v31, v24, v31
	ldp	q10, q9, [x19], #128
	and.16b	v10, v5, v10
	and.16b	v9, v4, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v10, v10, v10
	fadd.4s	v10, v25, v10
	fadd.4s	v9, v20, v9
	bit.16b	v19, v27, v4
	bit.16b	v22, v28, v5
	bit.16b	v21, v29, v4
	bit.16b	v26, v30, v5
	bit.16b	v24, v31, v4
	bit.16b	v23, v8, v5
	bit.16b	v20, v9, v4
	bit.16b	v25, v10, v5
	cmp	x20, #4092
	add	x20, x20, #4
	b.lo	LBB0_46
; %bb.47:                               ; %direct.true95.i84.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
LBB0_48:                                ; %direct.true95.i84.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x9, x7, x19, lsl #2
	ld1r.4s	{ v27 }, [x9]
	add	x9, x6, x19, lsl #5
	ldp	q28, q29, [x9]
	bit.16b	v29, v27, v4
	bif.16b	v27, v28, v5
	stp	q27, q29, [x9]
	add	x19, x19, #1
	cmp	x19, #1, lsl #12                ; =4096
	b.ne	LBB0_48
; %bb.49:                               ; %direct.false96.i91.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x6, #0                          ; =0x0
	fadd.4s	v22, v22, v26
	fadd.4s	v19, v19, v21
	fadd.4s	v19, v19, v24
	fadd.4s	v21, v22, v23
	fadd.4s	v21, v21, v25
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v19, v3
	fmul.4s	v3, v21, v3
	fadd.4s	v3, v3, v2
	fadd.4s	v2, v19, v2
	fsqrt.4s	v19, v2
	fsqrt.4s	v2, v3
	and.16b	v2, v5, v2
	and.16b	v3, v4, v19
	b	LBB0_51
LBB0_50:                                ; %else245
                                        ;   in Loop: Header=BB0_51 Depth=2
	add	x6, x6, #4
	add	x4, x4, #32
	cmp	x6, #4, lsl #12                 ; =16384
	b.eq	LBB0_2
LBB0_51:                                ; %direct.true110.i92.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w7, s18
	ldp	q19, q21, [x4]
	and.16b	v19, v5, v19
	fdiv.4s	v19, v19, v2
	add	x9, x4, #32, lsl #12            ; =131072
	ldp	q20, q22, [x9]
	and.16b	v20, v5, v20
	fmul.4s	v23, v19, v20
	dup.2d	v19, x6
	add.2d	v24, v19, v17
	dup.2d	v20, x5
	add.2d	v24, v20, v24
	tbnz	w7, #0, LBB0_60
; %bb.52:                               ; %else217
                                        ;   in Loop: Header=BB0_51 Depth=2
	and	w7, w7, #0xff
	tbnz	w7, #1, LBB0_61
LBB0_53:                                ; %else221
                                        ;   in Loop: Header=BB0_51 Depth=2
	add.2d	v24, v19, v7
	add.2d	v24, v20, v24
	tbnz	w7, #2, LBB0_62
LBB0_54:                                ; %else225
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbz	w7, #3, LBB0_56
LBB0_55:                                ; %cond.store226
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x9, v24[1]
	st1.s	{ v23 }[3], [x9]
LBB0_56:                                ; %else229
                                        ;   in Loop: Header=BB0_51 Depth=2
	and.16b	v21, v4, v21
	fdiv.4s	v21, v21, v3
	and.16b	v22, v4, v22
	fmul.4s	v21, v21, v22
	add.2d	v22, v19, v16
	add.2d	v22, v20, v22
	tbnz	w7, #4, LBB0_63
; %bb.57:                               ; %else233
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbnz	w7, #5, LBB0_64
LBB0_58:                                ; %else237
                                        ;   in Loop: Header=BB0_51 Depth=2
	add.2d	v19, v19, v6
	add.2d	v19, v20, v19
	tbnz	w7, #6, LBB0_65
LBB0_59:                                ; %else241
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbz	w7, #7, LBB0_50
	b	LBB0_66
LBB0_60:                                ; %cond.store
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x9, d24
	str	s23, [x9]
	and	w7, w7, #0xff
	tbz	w7, #1, LBB0_53
LBB0_61:                                ; %cond.store218
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x9, v24[1]
	st1.s	{ v23 }[1], [x9]
	add.2d	v24, v19, v7
	add.2d	v24, v20, v24
	tbz	w7, #2, LBB0_54
LBB0_62:                                ; %cond.store222
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x9, d24
	st1.s	{ v23 }[2], [x9]
	tbnz	w7, #3, LBB0_55
	b	LBB0_56
LBB0_63:                                ; %cond.store230
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x9, d22
	str	s21, [x9]
	tbz	w7, #5, LBB0_58
LBB0_64:                                ; %cond.store234
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x9, v22[1]
	st1.s	{ v21 }[1], [x9]
	add.2d	v19, v19, v6
	add.2d	v19, v20, v19
	tbz	w7, #6, LBB0_59
LBB0_65:                                ; %cond.store238
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x9, d19
	st1.s	{ v21 }[2], [x9]
	tbz	w7, #7, LBB0_50
LBB0_66:                                ; %cond.store242
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x9, v19[1]
	st1.s	{ v21 }[3], [x9]
	b	LBB0_50
LBB0_67:                                ; %block.batch.exit.loopexit
	stp	w1, w17, [x2]
	str	w16, [x2, #8]
	mov	w8, #1016                       ; =0x3f8
	str	w8, [x2, #36]
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #144
LBB0_68:                                ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

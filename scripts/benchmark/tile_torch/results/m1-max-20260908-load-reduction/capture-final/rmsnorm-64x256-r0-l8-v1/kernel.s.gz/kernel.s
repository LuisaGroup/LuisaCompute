	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_6:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_7:
	.quad	8                               ; 0x8
	.quad	9                               ; 0x9
lCPI0_8:
	.quad	12                              ; 0xc
	.quad	13                              ; 0xd
lCPI0_9:
	.quad	10                              ; 0xa
	.quad	11                              ; 0xb
lCPI0_10:
	.quad	14                              ; 0xe
	.quad	15                              ; 0xf
lCPI0_11:
	.quad	16                              ; 0x10
	.quad	17                              ; 0x11
lCPI0_12:
	.quad	20                              ; 0x14
	.quad	21                              ; 0x15
lCPI0_13:
	.quad	18                              ; 0x12
	.quad	19                              ; 0x13
lCPI0_14:
	.quad	22                              ; 0x16
	.quad	23                              ; 0x17
lCPI0_15:
	.quad	24                              ; 0x18
	.quad	25                              ; 0x19
lCPI0_16:
	.quad	28                              ; 0x1c
	.quad	29                              ; 0x1d
lCPI0_17:
	.quad	26                              ; 0x1a
	.quad	27                              ; 0x1b
lCPI0_18:
	.quad	30                              ; 0x1e
	.quad	31                              ; 0x1f
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #2560
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q0, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v0
	cmhi.4s	v1, v1, v2
	uzp1.8h	v3, v1, v0
	umaxv.8h	h2, v3
	fmov	w8, s2
	tbz	w8, #0, LBB0_140
; %bb.1:                                ; %direct.activate
	ldr	x9, [x0]
Lloh4:
	adrp	x8, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x8, lCPI0_0@PAGEOFF]
	str	q3, [sp, #64]                   ; 16-byte Folded Spill
	and.16b	v2, v3, v2
	addv.8h	h12, v2
	fmov	w10, s12
	and	w8, w10, #0xff
	sshll2.2d	v16, v1, #0
	sshll.2d	v23, v0, #0
	sshll.2d	v24, v1, #0
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #9
Lloh6:
	adrp	x12, lCPI0_3@PAGE
Lloh7:
	ldr	q2, [x12, lCPI0_3@PAGEOFF]
	str	q2, [sp, #112]                  ; 16-byte Folded Spill
	and.16b	v2, v24, v2
Lloh8:
	adrp	x12, lCPI0_4@PAGE
Lloh9:
	ldr	q18, [x12, lCPI0_4@PAGEOFF]
Lloh10:
	adrp	x12, lCPI0_5@PAGE
Lloh11:
	ldr	q19, [x12, lCPI0_5@PAGEOFF]
	and.16b	v5, v16, v19
	lsr	w11, w11, #3
	dup.4s	v3, w11
	and.16b	v4, v1, v3
	and.16b	v3, v0, v3
	ushll.2d	v25, v4, #8
	ushll2.2d	v26, v4, #8
	stp	q5, q2, [sp, #32]               ; 32-byte Folded Spill
	orr.16b	v4, v26, v5
	orr.16b	v5, v25, v2
	shl.2d	v5, v5, #2
	dup.2d	v20, x9
	add.2d	v5, v20, v5
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w10, #0, LBB0_141
; %bb.2:                                ; %else
	adrp	x9, lCPI0_6@PAGE
	and.16b	v2, v23, v18
	ushll.2d	v27, v3, #8
	shl.2d	v4, v4, #2
	tbnz	w8, #1, LBB0_142
LBB0_3:                                 ; %else27
	sshll2.2d	v21, v0, #0
	ldr	q22, [x9, lCPI0_6@PAGEOFF]
	orr.16b	v5, v27, v2
	add.2d	v4, v20, v4
	tbnz	w8, #2, LBB0_143
LBB0_4:                                 ; %else30
	and.16b	v6, v21, v22
	ushll2.2d	v30, v3, #8
	shl.2d	v3, v5, #2
	tbnz	w8, #3, LBB0_144
LBB0_5:                                 ; %else33
	orr.16b	v4, v30, v6
	add.2d	v3, v20, v3
	tbnz	w8, #4, LBB0_145
LBB0_6:                                 ; %else36
	shl.2d	v4, v4, #2
	tbnz	w8, #5, LBB0_146
LBB0_7:                                 ; %else39
	add.2d	v3, v20, v4
	tbnz	w8, #6, LBB0_147
LBB0_8:                                 ; %else42
	add	x9, sp, #272
	stp	q6, q2, [sp]                    ; 32-byte Folded Spill
	tbz	w8, #7, LBB0_10
LBB0_9:                                 ; %cond.load44
	mov.d	x8, v3[1]
	ld1.s	{ v29 }[3], [x8]
LBB0_10:                                ; %else45
	ldr	x10, [x0, #16]
	ldr	x8, [x0, #48]
	fmov	w12, s12
	and	w11, w12, #0xff
	sshll.2d	v3, v0, #0
	sshll.2d	v4, v1, #0
	str	q28, [x9, #1264]
	str	q29, [x9, #1280]
Lloh12:
	adrp	x13, lCPI0_7@PAGE
Lloh13:
	ldr	q5, [x13, lCPI0_7@PAGEOFF]
	and.16b	v4, v4, v5
Lloh14:
	adrp	x13, lCPI0_8@PAGE
Lloh15:
	ldr	q5, [x13, lCPI0_8@PAGEOFF]
Lloh16:
	adrp	x13, lCPI0_9@PAGE
Lloh17:
	ldr	q6, [x13, lCPI0_9@PAGEOFF]
	and.16b	v6, v16, v6
	orr.16b	v7, v26, v6
	orr.16b	v4, v25, v4
	shl.2d	v4, v4, #2
	add.2d	v6, v20, v4
	movi.2d	v4, #0000000000000000
	movi.2d	v31, #0000000000000000
	ldr	q2, [sp, #112]                  ; 16-byte Folded Reload
	tbnz	w12, #0, LBB0_148
; %bb.11:                               ; %else52
	adrp	x12, lCPI0_10@PAGE
	and.16b	v3, v3, v5
	shl.2d	v7, v7, #2
	tbnz	w11, #1, LBB0_149
LBB0_12:                                ; %else58
	ldr	q5, [x12, lCPI0_10@PAGEOFF]
	orr.16b	v6, v27, v3
	add.2d	v3, v20, v7
	tbnz	w11, #2, LBB0_150
LBB0_13:                                ; %else64
	and.16b	v5, v21, v5
	shl.2d	v6, v6, #2
	tbnz	w11, #3, LBB0_151
LBB0_14:                                ; %else70
	orr.16b	v5, v30, v5
	add.2d	v3, v20, v6
	tbnz	w11, #4, LBB0_152
LBB0_15:                                ; %else76
	shl.2d	v5, v5, #2
	tbnz	w11, #5, LBB0_153
LBB0_16:                                ; %else82
	add.2d	v3, v20, v5
	tbnz	w11, #6, LBB0_154
LBB0_17:                                ; %else88
	tbz	w11, #7, LBB0_19
LBB0_18:                                ; %cond.load90
	mov.d	x11, v3[1]
	ld1.s	{ v31 }[3], [x11]
LBB0_19:                                ; %else94
	fmov	w12, s12
	and	w11, w12, #0xff
	sshll.2d	v3, v0, #0
	sshll.2d	v5, v1, #0
	str	q4, [x9, #1296]
	str	q31, [x9, #1312]
Lloh18:
	adrp	x13, lCPI0_11@PAGE
Lloh19:
	ldr	q6, [x13, lCPI0_11@PAGEOFF]
	and.16b	v5, v5, v6
Lloh20:
	adrp	x13, lCPI0_12@PAGE
Lloh21:
	ldr	q7, [x13, lCPI0_12@PAGEOFF]
Lloh22:
	adrp	x13, lCPI0_13@PAGE
Lloh23:
	ldr	q6, [x13, lCPI0_13@PAGEOFF]
	and.16b	v6, v16, v6
	orr.16b	v9, v26, v6
	orr.16b	v5, v25, v5
	shl.2d	v5, v5, #2
	add.2d	v8, v20, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w12, #0, LBB0_155
; %bb.20:                               ; %else101
	adrp	x12, lCPI0_14@PAGE
	and.16b	v3, v3, v7
	shl.2d	v9, v9, #2
	tbnz	w11, #1, LBB0_156
LBB0_21:                                ; %else107
	ldr	q7, [x12, lCPI0_14@PAGEOFF]
	orr.16b	v8, v27, v3
	add.2d	v3, v20, v9
	tbnz	w11, #2, LBB0_157
LBB0_22:                                ; %else113
	and.16b	v7, v21, v7
	shl.2d	v8, v8, #2
	tbnz	w11, #3, LBB0_158
LBB0_23:                                ; %else119
	orr.16b	v7, v30, v7
	add.2d	v3, v20, v8
	tbnz	w11, #4, LBB0_159
LBB0_24:                                ; %else125
	shl.2d	v7, v7, #2
	tbnz	w11, #5, LBB0_160
LBB0_25:                                ; %else131
	add.2d	v3, v20, v7
	tbnz	w11, #6, LBB0_161
LBB0_26:                                ; %else137
	tbz	w11, #7, LBB0_28
LBB0_27:                                ; %cond.load139
	mov.d	x11, v3[1]
	ld1.s	{ v6 }[3], [x11]
LBB0_28:                                ; %else143
	fmov	w12, s12
	and	w11, w12, #0xff
	sshll.2d	v8, v0, #0
	sshll.2d	v3, v1, #0
	str	q5, [x9, #1328]
	str	q6, [x9, #1344]
Lloh24:
	adrp	x13, lCPI0_15@PAGE
Lloh25:
	ldr	q7, [x13, lCPI0_15@PAGEOFF]
	and.16b	v3, v3, v7
Lloh26:
	adrp	x13, lCPI0_16@PAGE
Lloh27:
	ldr	q9, [x13, lCPI0_16@PAGEOFF]
Lloh28:
	adrp	x13, lCPI0_17@PAGE
Lloh29:
	ldr	q7, [x13, lCPI0_17@PAGEOFF]
	and.16b	v7, v16, v7
	orr.16b	v11, v26, v7
	orr.16b	v3, v25, v3
	shl.2d	v3, v3, #2
	add.2d	v10, v20, v3
	movi.2d	v3, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w12, #0, LBB0_162
; %bb.29:                               ; %else150
	adrp	x12, lCPI0_18@PAGE
	and.16b	v8, v8, v9
	shl.2d	v11, v11, #2
	tbnz	w11, #1, LBB0_163
LBB0_30:                                ; %else156
	ldr	q9, [x12, lCPI0_18@PAGEOFF]
	orr.16b	v10, v27, v8
	add.2d	v8, v20, v11
	tbnz	w11, #2, LBB0_164
LBB0_31:                                ; %else162
	and.16b	v9, v21, v9
	shl.2d	v10, v10, #2
	tbnz	w11, #3, LBB0_165
LBB0_32:                                ; %else168
	orr.16b	v9, v30, v9
	add.2d	v8, v20, v10
	tbnz	w11, #4, LBB0_166
LBB0_33:                                ; %else174
	shl.2d	v9, v9, #2
	tbnz	w11, #5, LBB0_167
LBB0_34:                                ; %else180
	add.2d	v8, v20, v9
	tbz	w11, #6, LBB0_36
LBB0_35:                                ; %cond.load182
	fmov	x12, d8
	ld1.s	{ v7 }[2], [x12]
LBB0_36:                                ; %else186
	fmov	w13, s12
	fmul.4s	v28, v28, v28
	fmul.4s	v29, v29, v29
	fmul.4s	v4, v4, v4
	fmul.4s	v31, v31, v31
	fmul.4s	v5, v5, v5
	fmul.4s	v6, v6, v6
	tbz	w11, #7, LBB0_38
; %bb.37:                               ; %cond.load188
	mov.d	x11, v8[1]
	ld1.s	{ v7 }[3], [x11]
LBB0_38:                                ; %else192
	mov	x12, #0                         ; =0x0
	and.16b	v8, v21, v30
	and.16b	v9, v16, v26
	and	w11, w13, #0xff
	and.16b	v10, v23, v27
	and.16b	v23, v24, v25
	str	q3, [x9, #1360]
	str	q7, [x9, #1376]
	fmul.4s	v3, v3, v3
	fmul.4s	v7, v7, v7
	and.16b	v25, v0, v29
	and.16b	v24, v1, v28
	and.16b	v29, v0, v31
	and.16b	v28, v1, v4
	and.16b	v26, v0, v6
	and.16b	v30, v1, v5
	and.16b	v27, v0, v7
	add	x13, sp, #1536
	and.16b	v31, v1, v3
	add	x13, x13, #224
	mov	w14, #32                        ; =0x20
	fmov	w15, s12
	sshll.2d	v4, v0, #0
	sshll.2d	v3, v1, #0
	stp	q3, q4, [sp, #80]               ; 32-byte Folded Spill
	b	LBB0_40
LBB0_39:                                ; %else388
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmul.4s	v2, v14, v14
	fmul.4s	v11, v13, v13
	fadd.4s	v11, v24, v11
	fadd.4s	v2, v25, v2
	fmul.4s	v4, v4, v4
	fmul.4s	v12, v15, v15
	fadd.4s	v12, v28, v12
	fadd.4s	v4, v29, v4
	fmul.4s	v6, v6, v6
	fmul.4s	v5, v5, v5
	fadd.4s	v5, v30, v5
	fadd.4s	v6, v26, v6
	ldp	q13, q14, [x13]
	bit.16b	v14, v3, v0
	bit.16b	v13, v7, v1
	stp	q13, q14, [x13], #128
	fmul.4s	v7, v7, v7
	fmul.4s	v3, v3, v3
	fadd.4s	v3, v27, v3
	fadd.4s	v7, v31, v7
	bit.16b	v25, v2, v0
	bit.16b	v24, v11, v1
	bit.16b	v29, v4, v0
	bit.16b	v28, v12, v1
	bit.16b	v26, v6, v0
	add	x12, x12, #4
	bit.16b	v30, v5, v1
	add	x14, x14, #32
	bit.16b	v31, v7, v1
	bit.16b	v27, v3, v0
	cmp	x12, #28
	mov.16b	v12, v17
	ldr	q2, [sp, #112]                  ; 16-byte Folded Reload
	b.hs	LBB0_104
LBB0_40:                                ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v3, x14
	orr.16b	v4, v3, v2
	ldr	q5, [sp, #80]                   ; 16-byte Folded Reload
	and.16b	v4, v5, v4
	add.2d	v4, v4, v23
	shl.2d	v4, v4, #2
	add.2d	v4, v20, v4
	movi.2d	v13, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w15, #0, LBB0_79
; %bb.41:                               ; %else199
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w16, w15, #0xff
	tbnz	w16, #1, LBB0_80
LBB0_42:                                ; %else205
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v4, v3, v19
	and.16b	v4, v16, v4
	add.2d	v4, v4, v9
	shl.2d	v4, v4, #2
	add.2d	v4, v20, v4
	tbnz	w16, #2, LBB0_81
LBB0_43:                                ; %else211
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #3, LBB0_45
LBB0_44:                                ; %cond.load213
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v4[1]
	ld1.s	{ v13 }[3], [x17]
LBB0_45:                                ; %else217
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v4, v3, v18
	ldr	q5, [sp, #96]                   ; 16-byte Folded Reload
	and.16b	v4, v5, v4
	add.2d	v4, v4, v10
	shl.2d	v4, v4, #2
	add.2d	v4, v20, v4
	tbnz	w16, #4, LBB0_82
; %bb.46:                               ; %else223
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #5, LBB0_83
LBB0_47:                                ; %else229
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v3, v3, v22
	and.16b	v3, v21, v3
	add.2d	v3, v3, v8
	shl.2d	v3, v3, #2
	add.2d	v3, v20, v3
	tbnz	w16, #6, LBB0_84
LBB0_48:                                ; %else235
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #7, LBB0_50
LBB0_49:                                ; %cond.load237
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x16, v3[1]
	ld1.s	{ v14 }[3], [x16]
LBB0_50:                                ; %else241
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	w16, s12
	sshll.2d	v4, v1, #0
	ldp	q3, q5, [x13, #-96]
	bit.16b	v5, v14, v0
	bit.16b	v3, v13, v1
	stp	q3, q5, [x13, #-96]
	add	x17, x14, #8
	dup.2d	v3, x17
	orr.16b	v5, v3, v2
	and.16b	v4, v4, v5
	add.2d	v4, v4, v23
	shl.2d	v4, v4, #2
	add.2d	v5, v20, v4
	movi.2d	v15, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w16, #0, LBB0_85
; %bb.51:                               ; %else248
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_86
LBB0_52:                                ; %else254
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v5, v3, v19
	and.16b	v5, v16, v5
	add.2d	v5, v5, v9
	shl.2d	v5, v5, #2
	add.2d	v5, v20, v5
	tbnz	w16, #2, LBB0_87
LBB0_53:                                ; %else260
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #3, LBB0_55
LBB0_54:                                ; %cond.load262
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v5[1]
	ld1.s	{ v15 }[3], [x17]
LBB0_55:                                ; %else266
                                        ;   in Loop: Header=BB0_40 Depth=1
	sshll.2d	v5, v0, #0
	orr.16b	v6, v3, v18
	and.16b	v5, v5, v6
	add.2d	v5, v5, v10
	shl.2d	v5, v5, #2
	add.2d	v5, v20, v5
	tbnz	w16, #4, LBB0_88
; %bb.56:                               ; %else272
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #5, LBB0_89
LBB0_57:                                ; %else278
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v3, v3, v22
	and.16b	v3, v21, v3
	add.2d	v3, v3, v8
	shl.2d	v3, v3, #2
	add.2d	v3, v20, v3
	tbnz	w16, #6, LBB0_90
LBB0_58:                                ; %else284
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #7, LBB0_60
LBB0_59:                                ; %cond.load286
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x16, v3[1]
	ld1.s	{ v4 }[3], [x16]
LBB0_60:                                ; %else290
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	w16, s12
	sshll.2d	v5, v1, #0
	ldp	q3, q6, [x13, #-64]
	bit.16b	v6, v4, v0
	bit.16b	v3, v15, v1
	stp	q3, q6, [x13, #-64]
	add	x17, x14, #16
	dup.2d	v3, x17
	orr.16b	v6, v3, v2
	and.16b	v5, v5, v6
	add.2d	v5, v5, v23
	shl.2d	v5, v5, #2
	add.2d	v7, v20, v5
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w16, #0, LBB0_91
; %bb.61:                               ; %else297
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_92
LBB0_62:                                ; %else303
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v7, v3, v19
	and.16b	v7, v16, v7
	add.2d	v7, v7, v9
	shl.2d	v7, v7, #2
	add.2d	v7, v20, v7
	tbnz	w16, #2, LBB0_93
LBB0_63:                                ; %else309
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #3, LBB0_65
LBB0_64:                                ; %cond.load311
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v7[1]
	ld1.s	{ v5 }[3], [x17]
LBB0_65:                                ; %else315
                                        ;   in Loop: Header=BB0_40 Depth=1
	sshll.2d	v7, v0, #0
	orr.16b	v11, v3, v18
	and.16b	v7, v7, v11
	add.2d	v7, v7, v10
	shl.2d	v7, v7, #2
	add.2d	v7, v20, v7
	tbnz	w16, #4, LBB0_94
; %bb.66:                               ; %else321
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #5, LBB0_95
LBB0_67:                                ; %else327
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v3, v3, v22
	and.16b	v3, v21, v3
	add.2d	v3, v3, v8
	shl.2d	v3, v3, #2
	add.2d	v3, v20, v3
	tbnz	w16, #6, LBB0_96
LBB0_68:                                ; %else333
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #7, LBB0_70
LBB0_69:                                ; %cond.load335
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x16, v3[1]
	ld1.s	{ v6 }[3], [x16]
LBB0_70:                                ; %else339
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.16b	v17, v12
	fmov	w16, s12
	sshll.2d	v3, v1, #0
	ldp	q7, q11, [x13, #-32]
	bit.16b	v11, v6, v0
	bit.16b	v7, v5, v1
	stp	q7, q11, [x13, #-32]
	add	x17, x14, #24
	dup.2d	v11, x17
	orr.16b	v7, v11, v2
	and.16b	v3, v3, v7
	add.2d	v3, v3, v23
	shl.2d	v3, v3, #2
	add.2d	v12, v20, v3
	movi.2d	v7, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w16, #0, LBB0_97
; %bb.71:                               ; %else346
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w16, w16, #0xff
	tbnz	w16, #1, LBB0_98
LBB0_72:                                ; %else352
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v12, v11, v19
	and.16b	v12, v16, v12
	add.2d	v12, v12, v9
	shl.2d	v12, v12, #2
	add.2d	v12, v20, v12
	tbnz	w16, #2, LBB0_99
LBB0_73:                                ; %else358
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #3, LBB0_75
LBB0_74:                                ; %cond.load360
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v12[1]
	ld1.s	{ v7 }[3], [x17]
LBB0_75:                                ; %else364
                                        ;   in Loop: Header=BB0_40 Depth=1
	sshll.2d	v12, v0, #0
	orr.16b	v2, v11, v18
	and.16b	v2, v12, v2
	add.2d	v2, v2, v10
	shl.2d	v2, v2, #2
	add.2d	v12, v20, v2
	tbnz	w16, #4, LBB0_100
; %bb.76:                               ; %else370
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w16, #5, LBB0_101
LBB0_77:                                ; %else376
                                        ;   in Loop: Header=BB0_40 Depth=1
	orr.16b	v2, v11, v22
	and.16b	v2, v21, v2
	add.2d	v2, v2, v8
	shl.2d	v2, v2, #2
	add.2d	v11, v20, v2
	tbnz	w16, #6, LBB0_102
LBB0_78:                                ; %else382
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w16, #7, LBB0_39
	b	LBB0_103
LBB0_79:                                ; %cond.load195
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x16, d4
	ldr	s13, [x16]
	and	w16, w15, #0xff
	tbz	w16, #1, LBB0_42
LBB0_80:                                ; %cond.load201
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v4[1]
	ld1.s	{ v13 }[1], [x17]
	orr.16b	v4, v3, v19
	and.16b	v4, v16, v4
	add.2d	v4, v4, v9
	shl.2d	v4, v4, #2
	add.2d	v4, v20, v4
	tbz	w16, #2, LBB0_43
LBB0_81:                                ; %cond.load207
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d4
	ld1.s	{ v13 }[2], [x17]
	tbnz	w16, #3, LBB0_44
	b	LBB0_45
LBB0_82:                                ; %cond.load219
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d4
	ld1.s	{ v14 }[0], [x17]
	tbz	w16, #5, LBB0_47
LBB0_83:                                ; %cond.load225
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v4[1]
	ld1.s	{ v14 }[1], [x17]
	orr.16b	v3, v3, v22
	and.16b	v3, v21, v3
	add.2d	v3, v3, v8
	shl.2d	v3, v3, #2
	add.2d	v3, v20, v3
	tbz	w16, #6, LBB0_48
LBB0_84:                                ; %cond.load231
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d3
	ld1.s	{ v14 }[2], [x17]
	tbnz	w16, #7, LBB0_49
	b	LBB0_50
LBB0_85:                                ; %cond.load244
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d5
	ldr	s15, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_52
LBB0_86:                                ; %cond.load250
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v5[1]
	ld1.s	{ v15 }[1], [x17]
	orr.16b	v5, v3, v19
	and.16b	v5, v16, v5
	add.2d	v5, v5, v9
	shl.2d	v5, v5, #2
	add.2d	v5, v20, v5
	tbz	w16, #2, LBB0_53
LBB0_87:                                ; %cond.load256
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d5
	ld1.s	{ v15 }[2], [x17]
	tbnz	w16, #3, LBB0_54
	b	LBB0_55
LBB0_88:                                ; %cond.load268
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d5
	ld1.s	{ v4 }[0], [x17]
	tbz	w16, #5, LBB0_57
LBB0_89:                                ; %cond.load274
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v5[1]
	ld1.s	{ v4 }[1], [x17]
	orr.16b	v3, v3, v22
	and.16b	v3, v21, v3
	add.2d	v3, v3, v8
	shl.2d	v3, v3, #2
	add.2d	v3, v20, v3
	tbz	w16, #6, LBB0_58
LBB0_90:                                ; %cond.load280
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d3
	ld1.s	{ v4 }[2], [x17]
	tbnz	w16, #7, LBB0_59
	b	LBB0_60
LBB0_91:                                ; %cond.load293
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d7
	ldr	s5, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_62
LBB0_92:                                ; %cond.load299
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v7[1]
	ld1.s	{ v5 }[1], [x17]
	orr.16b	v7, v3, v19
	and.16b	v7, v16, v7
	add.2d	v7, v7, v9
	shl.2d	v7, v7, #2
	add.2d	v7, v20, v7
	tbz	w16, #2, LBB0_63
LBB0_93:                                ; %cond.load305
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d7
	ld1.s	{ v5 }[2], [x17]
	tbnz	w16, #3, LBB0_64
	b	LBB0_65
LBB0_94:                                ; %cond.load317
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d7
	ld1.s	{ v6 }[0], [x17]
	tbz	w16, #5, LBB0_67
LBB0_95:                                ; %cond.load323
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v7[1]
	ld1.s	{ v6 }[1], [x17]
	orr.16b	v3, v3, v22
	and.16b	v3, v21, v3
	add.2d	v3, v3, v8
	shl.2d	v3, v3, #2
	add.2d	v3, v20, v3
	tbz	w16, #6, LBB0_68
LBB0_96:                                ; %cond.load329
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d3
	ld1.s	{ v6 }[2], [x17]
	tbnz	w16, #7, LBB0_69
	b	LBB0_70
LBB0_97:                                ; %cond.load342
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d12
	ldr	s7, [x17]
	and	w16, w16, #0xff
	tbz	w16, #1, LBB0_72
LBB0_98:                                ; %cond.load348
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v12[1]
	ld1.s	{ v7 }[1], [x17]
	orr.16b	v12, v11, v19
	and.16b	v12, v16, v12
	add.2d	v12, v12, v9
	shl.2d	v12, v12, #2
	add.2d	v12, v20, v12
	tbz	w16, #2, LBB0_73
LBB0_99:                                ; %cond.load354
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d12
	ld1.s	{ v7 }[2], [x17]
	tbnz	w16, #3, LBB0_74
	b	LBB0_75
LBB0_100:                               ; %cond.load366
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d12
	ld1.s	{ v3 }[0], [x17]
	tbz	w16, #5, LBB0_77
LBB0_101:                               ; %cond.load372
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x17, v12[1]
	ld1.s	{ v3 }[1], [x17]
	orr.16b	v2, v11, v22
	and.16b	v2, v21, v2
	add.2d	v2, v2, v8
	shl.2d	v2, v2, #2
	add.2d	v11, v20, v2
	tbz	w16, #6, LBB0_78
LBB0_102:                               ; %cond.load378
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x17, d11
	ld1.s	{ v3 }[2], [x17]
	tbz	w16, #7, LBB0_39
LBB0_103:                               ; %cond.load384
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x16, v11[1]
	ld1.s	{ v3 }[3], [x16]
	b	LBB0_39
LBB0_104:                               ; %direct.true95.preheader
	mov	x12, #0                         ; =0x0
	fmov	w13, s12
	add	x14, sp, #512
	b	LBB0_106
LBB0_105:                               ; %else413
                                        ;   in Loop: Header=BB0_106 Depth=1
	add	x15, x14, x12
	ldp	q2, q5, [x15]
	bif.16b	v4, v5, v0
	bit.16b	v2, v3, v1
	stp	q2, q4, [x15]
	add	x12, x12, #32
	cmp	x12, #1024
	b.eq	LBB0_122
LBB0_106:                               ; %direct.true95
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x10, x12
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w13, #0, LBB0_114
; %bb.107:                              ; %else392
                                        ;   in Loop: Header=BB0_106 Depth=1
	and	w16, w13, #0xff
	tbnz	w16, #1, LBB0_115
LBB0_108:                               ; %else395
                                        ;   in Loop: Header=BB0_106 Depth=1
	tbnz	w16, #2, LBB0_116
LBB0_109:                               ; %else398
                                        ;   in Loop: Header=BB0_106 Depth=1
	tbnz	w16, #3, LBB0_117
LBB0_110:                               ; %else401
                                        ;   in Loop: Header=BB0_106 Depth=1
	tbnz	w16, #4, LBB0_118
LBB0_111:                               ; %else404
                                        ;   in Loop: Header=BB0_106 Depth=1
	tbnz	w16, #5, LBB0_119
LBB0_112:                               ; %else407
                                        ;   in Loop: Header=BB0_106 Depth=1
	tbnz	w16, #6, LBB0_120
LBB0_113:                               ; %else410
                                        ;   in Loop: Header=BB0_106 Depth=1
	tbz	w16, #7, LBB0_105
	b	LBB0_121
LBB0_114:                               ; %cond.load391
                                        ;   in Loop: Header=BB0_106 Depth=1
	ldr	s3, [x15]
	and	w16, w13, #0xff
	tbz	w16, #1, LBB0_108
LBB0_115:                               ; %cond.load394
                                        ;   in Loop: Header=BB0_106 Depth=1
	add	x17, x15, #4
	ld1.s	{ v3 }[1], [x17]
	tbz	w16, #2, LBB0_109
LBB0_116:                               ; %cond.load397
                                        ;   in Loop: Header=BB0_106 Depth=1
	add	x17, x15, #8
	ld1.s	{ v3 }[2], [x17]
	tbz	w16, #3, LBB0_110
LBB0_117:                               ; %cond.load400
                                        ;   in Loop: Header=BB0_106 Depth=1
	add	x17, x15, #12
	ld1.s	{ v3 }[3], [x17]
	tbz	w16, #4, LBB0_111
LBB0_118:                               ; %cond.load403
                                        ;   in Loop: Header=BB0_106 Depth=1
	add	x17, x15, #16
	ld1.s	{ v4 }[0], [x17]
	tbz	w16, #5, LBB0_112
LBB0_119:                               ; %cond.load406
                                        ;   in Loop: Header=BB0_106 Depth=1
	add	x17, x15, #20
	ld1.s	{ v4 }[1], [x17]
	tbz	w16, #6, LBB0_113
LBB0_120:                               ; %cond.load409
                                        ;   in Loop: Header=BB0_106 Depth=1
	add	x17, x15, #24
	ld1.s	{ v4 }[2], [x17]
	tbz	w16, #7, LBB0_105
LBB0_121:                               ; %cond.load412
                                        ;   in Loop: Header=BB0_106 Depth=1
	add	x15, x15, #28
	ld1.s	{ v4 }[3], [x15]
	b	LBB0_105
LBB0_122:                               ; %direct.false96
	mov	x10, #0                         ; =0x0
	ldr	q2, [sp, #64]                   ; 16-byte Folded Reload
	xtn.8b	v17, v2
	fadd.4s	v2, v25, v29
	fadd.4s	v3, v24, v28
	fadd.4s	v3, v3, v30
	fadd.4s	v2, v2, v26
	fadd.4s	v6, v2, v27
	fadd.4s	v16, v3, v31
	ldp	q3, q2, [sp, #32]               ; 32-byte Folded Reload
	uzp1.4s	v5, v2, v3
	ldp	q3, q2, [sp]                    ; 32-byte Folded Reload
	uzp1.4s	v4, v2, v3
	movi.4s	v2, #1
	eor.16b	v18, v4, v2
	eor.16b	v2, v5, v2
	mov.s	w15, v2[1]
	mov.s	w16, v2[2]
	mov.s	w17, v2[3]
	fmov	w12, s2
	add	x13, sp, #136
	bfxil	x13, x12, #0, #3
	str	d17, [sp, #136]
	ldrb	w13, [x13]
	and	x14, x12, #0x7
	umov.b	w12, v17[0]
	stp	q16, q6, [x9, #64]
	add	x0, sp, #336
	ldr	s2, [x0, x14, lsl #2]
	ands	w14, w12, #0x1
	tst	w14, w13
	movi	d3, #0000000000000000
	fcsel	s7, s2, s3, ne
	add	x13, sp, #136
	bfxil	x13, x15, #0, #3
	ldrb	w0, [x13]
	umov.b	w13, v17[1]
	and	x15, x15, #0x7
	stp	q16, q6, [x9, #32]
	add	x1, sp, #304
	ldr	s2, [x1, x15, lsl #2]
	ands	w15, w13, #0x1
	tst	w15, w0
	fcsel	s19, s2, s3, ne
	add	x15, sp, #136
	bfxil	x15, x16, #0, #3
	ldrb	w0, [x15]
	and	x16, x16, #0x7
	umov.b	w15, v17[2]
	stp	q16, q6, [x9]
	add	x1, sp, #272
	ldr	s2, [x1, x16, lsl #2]
	ands	w16, w15, #0x1
	tst	w16, w0
	fcsel	s20, s2, s3, ne
	add	x16, sp, #136
	bfxil	x16, x17, #0, #3
	ldrb	w0, [x16]
	and	x17, x17, #0x7
	umov.b	w16, v17[3]
	stp	q16, q6, [sp, #240]
	add	x1, sp, #240
	ldr	s2, [x1, x17, lsl #2]
	ands	w17, w16, #0x1
	tst	w17, w0
	mov.s	w0, v18[1]
	mov.s	w1, v18[2]
	mov.s	w3, v18[3]
	fmov	w17, s18
	and	x2, x17, #0x7
	add	x4, sp, #136
	bfxil	x4, x17, #0, #3
	ldrb	w4, [x4]
	stp	q16, q6, [x9, #192]
	add	x17, sp, #464
	ldr	s18, [x17, x2, lsl #2]
	umov.b	w17, v17[4]
	fcsel	s2, s2, s3, ne
	and	w2, w17, w4
	tst	w2, #0x1
	add	x2, sp, #136
	bfxil	x2, x0, #0, #3
	ldrb	w2, [x2]
	and	x0, x0, #0x7
	stp	q16, q6, [x9, #160]
	add	x4, sp, #432
	ldr	s21, [x4, x0, lsl #2]
	fcsel	s18, s18, s3, ne
	umov.b	w0, v17[5]
	ands	w4, w0, #0x1
	tst	w4, w2
	fcsel	s21, s21, s3, ne
	add	x2, sp, #136
	bfxil	x2, x1, #0, #3
	ldrb	w2, [x2]
	and	x1, x1, #0x7
	stp	q16, q6, [x9, #128]
	add	x4, sp, #400
	ldr	s22, [x4, x1, lsl #2]
	umov.b	w1, v17[6]
	ands	w4, w1, #0x1
	tst	w4, w2
	add	x2, sp, #136
	bfxil	x2, x3, #0, #3
	ldrb	w4, [x2]
	umov.b	w2, v17[7]
	and	x3, x3, #0x7
	stp	q16, q6, [x9, #96]
	add	x9, sp, #368
	ldr	s17, [x9, x3, lsl #2]
	fcsel	s22, s22, s3, ne
	ands	w9, w2, #0x1
	tst	w9, w4
	fcsel	s17, s17, s3, ne
	mov.s	v7[1], v19[0]
	mov.s	v7[2], v20[0]
	mov.s	v7[3], v2[0]
	mov.s	v18[1], v21[0]
	mov.s	v18[2], v22[0]
	mov.s	v18[3], v17[0]
	fadd.4s	v2, v6, v18
	fadd.4s	v6, v16, v7
	movi.4s	v7, #2
	eor.16b	v5, v5, v7
	fmov	w9, s5
	add	x3, sp, #136
	bfxil	x3, x9, #0, #3
	ldrb	w3, [x3]
	and	x9, x9, #0x7
	stp	q6, q2, [sp, #208]
	add	x4, sp, #208
	ldr	s5, [x4, x9, lsl #2]
	add	x9, sp, #136
	eor.16b	v4, v4, v7
	tst	w14, w3
	fcsel	s5, s5, s3, ne
	fmov	w3, s4
	and	x4, x3, #0x7
	bfxil	x9, x3, #0, #3
	ldrb	w9, [x9]
	and	w9, w17, w9
	stp	q6, q2, [sp, #176]
	add	x3, sp, #176
	ldr	s4, [x3, x4, lsl #2]
	tst	w9, #0x1
	fcsel	s4, s4, s3, ne
	fadd.4s	v2, v2, v4
	tst	w14, w17
	fcsel	s2, s2, s3, ne
	ands	w9, w12, #0x1
	fadd.4s	v4, v6, v5
	fadd	s2, s4, s2
	fcsel	s4, s2, s3, ne
	tst	w13, #0x1
	fcsel	s5, s4, s3, ne
	tst	w15, #0x1
	fcsel	s6, s4, s3, ne
	tst	w16, #0x1
	fcsel	s7, s4, s3, ne
	tst	w9, w17
	fcsel	s2, s2, s3, ne
	tst	w0, #0x1
	fcsel	s16, s4, s3, ne
	tst	w1, #0x1
	fcsel	s17, s4, s3, ne
	tst	w2, #0x1
	fcsel	s18, s4, s3, ne
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v7[0]
	mov.s	v2[1], v16[0]
	mov.s	v2[2], v17[0]
	mov.s	v2[3], v18[0]
	rbit	w9, w11
	clz	w9, w9
	stp	q4, q2, [sp, #144]
	and	x9, x9, #0x7
	add	x11, sp, #144
	ldr	s2, [x11, x9, lsl #2]
	fadd	s2, s2, s3
	mov	w9, #998244352                  ; =0x3b800000
	fmov	s3, w9
	fmul	s2, s2, s3
	mov	w9, #50604                      ; =0xc5ac
	movk	w9, #14119, lsl #16
	fmov	s3, w9
	fadd	s2, s2, s3
	fsqrt	s2, s2
	dup.4s	v3, v2[0]
	fmov	x9, d23
	add	x8, x8, x9, lsl #2
	add	x9, sp, #1536
	add	x11, sp, #512
	b	LBB0_124
LBB0_123:                               ; %else430
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x10, x10, #32
	cmp	x10, #1024
	b.eq	LBB0_140
LBB0_124:                               ; %direct.true113
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w13, s12
	add	x14, x9, x10
	ldr	q2, [x14]
	and.16b	v2, v1, v2
	fdiv.4s	v2, v2, v3
	add	x15, x11, x10
	ldr	q4, [x15]
	and.16b	v4, v1, v4
	fmul.4s	v4, v2, v4
	add	x12, x8, x10
	tbnz	w13, #0, LBB0_133
; %bb.125:                              ; %else416
                                        ;   in Loop: Header=BB0_124 Depth=1
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_134
LBB0_126:                               ; %else418
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbnz	w13, #2, LBB0_135
LBB0_127:                               ; %else420
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbz	w13, #3, LBB0_129
LBB0_128:                               ; %cond.store421
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x16, x12, #12
	st1.s	{ v4 }[3], [x16]
LBB0_129:                               ; %else422
                                        ;   in Loop: Header=BB0_124 Depth=1
	ldr	q2, [x14, #16]
	and.16b	v2, v0, v2
	fdiv.4s	v2, v2, v3
	ldr	q4, [x15, #16]
	and.16b	v4, v0, v4
	fmul.4s	v4, v2, v4
	tbnz	w13, #4, LBB0_136
; %bb.130:                              ; %else424
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbnz	w13, #5, LBB0_137
LBB0_131:                               ; %else426
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbnz	w13, #6, LBB0_138
LBB0_132:                               ; %else428
                                        ;   in Loop: Header=BB0_124 Depth=1
	tbz	w13, #7, LBB0_123
	b	LBB0_139
LBB0_133:                               ; %cond.store
                                        ;   in Loop: Header=BB0_124 Depth=1
	str	s4, [x12]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_126
LBB0_134:                               ; %cond.store417
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x16, x12, #4
	st1.s	{ v4 }[1], [x16]
	tbz	w13, #2, LBB0_127
LBB0_135:                               ; %cond.store419
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x16, x12, #8
	st1.s	{ v4 }[2], [x16]
	tbnz	w13, #3, LBB0_128
	b	LBB0_129
LBB0_136:                               ; %cond.store423
                                        ;   in Loop: Header=BB0_124 Depth=1
	str	s4, [x12, #16]
	tbz	w13, #5, LBB0_131
LBB0_137:                               ; %cond.store425
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x14, x12, #20
	st1.s	{ v4 }[1], [x14]
	tbz	w13, #6, LBB0_132
LBB0_138:                               ; %cond.store427
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x14, x12, #24
	st1.s	{ v4 }[2], [x14]
	tbz	w13, #7, LBB0_123
LBB0_139:                               ; %cond.store429
                                        ;   in Loop: Header=BB0_124 Depth=1
	add	x12, x12, #28
	st1.s	{ v4 }[3], [x12]
	b	LBB0_123
LBB0_140:                               ; %common.ret
	add	sp, sp, #2560
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
LBB0_141:                               ; %cond.load
	fmov	x9, d5
	ldr	s28, [x9]
	adrp	x9, lCPI0_6@PAGE
	and.16b	v2, v23, v18
	ushll.2d	v27, v3, #8
	shl.2d	v4, v4, #2
	tbz	w8, #1, LBB0_3
LBB0_142:                               ; %cond.load26
	mov.d	x10, v5[1]
	ld1.s	{ v28 }[1], [x10]
	sshll2.2d	v21, v0, #0
	ldr	q22, [x9, lCPI0_6@PAGEOFF]
	orr.16b	v5, v27, v2
	add.2d	v4, v20, v4
	tbz	w8, #2, LBB0_4
LBB0_143:                               ; %cond.load29
	fmov	x9, d4
	ld1.s	{ v28 }[2], [x9]
	and.16b	v6, v21, v22
	ushll2.2d	v30, v3, #8
	shl.2d	v3, v5, #2
	tbz	w8, #3, LBB0_5
LBB0_144:                               ; %cond.load32
	mov.d	x9, v4[1]
	ld1.s	{ v28 }[3], [x9]
	orr.16b	v4, v30, v6
	add.2d	v3, v20, v3
	tbz	w8, #4, LBB0_6
LBB0_145:                               ; %cond.load35
	fmov	x9, d3
	ld1.s	{ v29 }[0], [x9]
	shl.2d	v4, v4, #2
	tbz	w8, #5, LBB0_7
LBB0_146:                               ; %cond.load38
	mov.d	x9, v3[1]
	ld1.s	{ v29 }[1], [x9]
	add.2d	v3, v20, v4
	tbz	w8, #6, LBB0_8
LBB0_147:                               ; %cond.load41
	fmov	x9, d3
	ld1.s	{ v29 }[2], [x9]
	add	x9, sp, #272
	stp	q6, q2, [sp]                    ; 32-byte Folded Spill
	tbnz	w8, #7, LBB0_9
	b	LBB0_10
LBB0_148:                               ; %cond.load48
	fmov	x12, d6
	ldr	s4, [x12]
	adrp	x12, lCPI0_10@PAGE
	and.16b	v3, v3, v5
	shl.2d	v7, v7, #2
	tbz	w11, #1, LBB0_12
LBB0_149:                               ; %cond.load54
	mov.d	x13, v6[1]
	ld1.s	{ v4 }[1], [x13]
	ldr	q5, [x12, lCPI0_10@PAGEOFF]
	orr.16b	v6, v27, v3
	add.2d	v3, v20, v7
	tbz	w11, #2, LBB0_13
LBB0_150:                               ; %cond.load60
	fmov	x12, d3
	ld1.s	{ v4 }[2], [x12]
	and.16b	v5, v21, v5
	shl.2d	v6, v6, #2
	tbz	w11, #3, LBB0_14
LBB0_151:                               ; %cond.load66
	mov.d	x12, v3[1]
	ld1.s	{ v4 }[3], [x12]
	orr.16b	v5, v30, v5
	add.2d	v3, v20, v6
	tbz	w11, #4, LBB0_15
LBB0_152:                               ; %cond.load72
	fmov	x12, d3
	ld1.s	{ v31 }[0], [x12]
	shl.2d	v5, v5, #2
	tbz	w11, #5, LBB0_16
LBB0_153:                               ; %cond.load78
	mov.d	x12, v3[1]
	ld1.s	{ v31 }[1], [x12]
	add.2d	v3, v20, v5
	tbz	w11, #6, LBB0_17
LBB0_154:                               ; %cond.load84
	fmov	x12, d3
	ld1.s	{ v31 }[2], [x12]
	tbnz	w11, #7, LBB0_18
	b	LBB0_19
LBB0_155:                               ; %cond.load97
	fmov	x12, d8
	ldr	s5, [x12]
	adrp	x12, lCPI0_14@PAGE
	and.16b	v3, v3, v7
	shl.2d	v9, v9, #2
	tbz	w11, #1, LBB0_21
LBB0_156:                               ; %cond.load103
	mov.d	x13, v8[1]
	ld1.s	{ v5 }[1], [x13]
	ldr	q7, [x12, lCPI0_14@PAGEOFF]
	orr.16b	v8, v27, v3
	add.2d	v3, v20, v9
	tbz	w11, #2, LBB0_22
LBB0_157:                               ; %cond.load109
	fmov	x12, d3
	ld1.s	{ v5 }[2], [x12]
	and.16b	v7, v21, v7
	shl.2d	v8, v8, #2
	tbz	w11, #3, LBB0_23
LBB0_158:                               ; %cond.load115
	mov.d	x12, v3[1]
	ld1.s	{ v5 }[3], [x12]
	orr.16b	v7, v30, v7
	add.2d	v3, v20, v8
	tbz	w11, #4, LBB0_24
LBB0_159:                               ; %cond.load121
	fmov	x12, d3
	ld1.s	{ v6 }[0], [x12]
	shl.2d	v7, v7, #2
	tbz	w11, #5, LBB0_25
LBB0_160:                               ; %cond.load127
	mov.d	x12, v3[1]
	ld1.s	{ v6 }[1], [x12]
	add.2d	v3, v20, v7
	tbz	w11, #6, LBB0_26
LBB0_161:                               ; %cond.load133
	fmov	x12, d3
	ld1.s	{ v6 }[2], [x12]
	tbnz	w11, #7, LBB0_27
	b	LBB0_28
LBB0_162:                               ; %cond.load146
	fmov	x12, d10
	ldr	s3, [x12]
	adrp	x12, lCPI0_18@PAGE
	and.16b	v8, v8, v9
	shl.2d	v11, v11, #2
	tbz	w11, #1, LBB0_30
LBB0_163:                               ; %cond.load152
	mov.d	x13, v10[1]
	ld1.s	{ v3 }[1], [x13]
	ldr	q9, [x12, lCPI0_18@PAGEOFF]
	orr.16b	v10, v27, v8
	add.2d	v8, v20, v11
	tbz	w11, #2, LBB0_31
LBB0_164:                               ; %cond.load158
	fmov	x12, d8
	ld1.s	{ v3 }[2], [x12]
	and.16b	v9, v21, v9
	shl.2d	v10, v10, #2
	tbz	w11, #3, LBB0_32
LBB0_165:                               ; %cond.load164
	mov.d	x12, v8[1]
	ld1.s	{ v3 }[3], [x12]
	orr.16b	v9, v30, v9
	add.2d	v8, v20, v10
	tbz	w11, #4, LBB0_33
LBB0_166:                               ; %cond.load170
	fmov	x12, d8
	ld1.s	{ v7 }[0], [x12]
	shl.2d	v9, v9, #2
	tbz	w11, #5, LBB0_34
LBB0_167:                               ; %cond.load176
	mov.d	x12, v8[1]
	ld1.s	{ v7 }[1], [x12]
	add.2d	v8, v20, v9
	tbnz	w11, #6, LBB0_35
	b	LBB0_36
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_13
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w24, w8, [x2, #44]
	stp	w3, w8, [sp, #8]                ; 8-byte Folded Spill
	ldp	w25, w26, [x2]
	ldp	w28, w27, [x2, #8]
	str	w24, [sp, #4]                   ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #504                        ; =0x1f8
	str	w8, [x20, #36]
	ldp	w24, w19, [sp, #4]              ; 8-byte Folded Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w24
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_12
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_9 Depth 2
                                        ;     Child Loop BB1_6 Depth 2
	ubfiz	x8, x25, #9, #32
	cmp	x8, x27
	csel	x9, x8, xzr, ls
	subs	x10, x27, x9
	cmp	x10, #512
	mov	w11, #512                       ; =0x200
	csel	x10, x10, x11, lo
	cmp	x27, x9
	stp	w25, w26, [x20]
	str	w28, [x20, #8]
	ccmp	x8, x27, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #512
	b.lo	LBB1_7
; %bb.5:                                ; %packet.batch.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w23, #0                         ; =0x0
LBB1_6:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w23, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w23, w23, #8
	cmp	w23, #512
	b.ne	LBB1_6
	b	LBB1_3
LBB1_7:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x8, x23, #3
	lsl	w24, w8, #3
	cmp	x23, #8
	b.lo	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w19, #0                         ; =0x0
LBB1_9:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w19, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w19, w19, #8
	cmp	w24, w19
	b.ne	LBB1_9
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w23, #0x7
	cbz	w2, LBB1_2
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w24, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
	b	LBB1_2
LBB1_12:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_13:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

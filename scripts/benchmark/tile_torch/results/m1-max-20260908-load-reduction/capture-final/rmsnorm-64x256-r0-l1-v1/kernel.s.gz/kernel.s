	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d9, d8, [sp, #-32]!             ; 16-byte Folded Spill
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	sub	sp, sp, #4, lsl #12             ; =16384
	sub	sp, sp, #16
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v1, v4
	cmhi.4s	v1, v1, v3
	uzp1.8h	v2, v1, v0
	umaxv.8h	h5, v2
	fmov	w8, s5
	tbz	w8, #0, LBB0_124
; %bb.1:                                ; %direct.activate
	ldr	x9, [x0]
Lloh4:
	adrp	x8, lCPI0_2@PAGE
Lloh5:
	ldr	q5, [x8, lCPI0_2@PAGEOFF]
	and.16b	v2, v2, v5
	addv.8h	h2, v2
	fmov	w10, s2
	and	w8, w10, #0xff
	ldr	w11, [x1]
	ldr	w12, [x1, #36]
	add	w11, w12, w11, lsl #6
	dup.4s	v5, w11
	add.4s	v7, v5, v4
	add.4s	v3, v5, v3
	and.16b	v4, v1, v3
	ushll.2d	v19, v4, #10
	dup.2d	v3, x9
	add.2d	v17, v3, v19
	movi.2d	v5, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w10, #0, LBB0_125
; %bb.2:                                ; %else
	and.16b	v7, v0, v7
	ushll2.2d	v16, v4, #10
	tbnz	w8, #1, LBB0_126
LBB0_3:                                 ; %else20
	add.2d	v17, v3, v16
	tbnz	w8, #2, LBB0_127
LBB0_4:                                 ; %else23
	ushll.2d	v18, v7, #10
	tbnz	w8, #3, LBB0_128
LBB0_5:                                 ; %else26
	add.2d	v20, v3, v18
	tbnz	w8, #4, LBB0_129
LBB0_6:                                 ; %else29
	ushll2.2d	v17, v7, #10
	tbnz	w8, #5, LBB0_130
LBB0_7:                                 ; %else32
	add.2d	v20, v3, v17
	tbnz	w8, #6, LBB0_131
LBB0_8:                                 ; %else35
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #16
	tbz	w8, #7, LBB0_10
LBB0_9:                                 ; %cond.load37
	mov.d	x8, v20[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_10:                                ; %else38
	ldr	x9, [x0, #16]
	ldr	x8, [x0, #48]
	fmov	w12, s2
	and	w11, w12, #0xff
	stp	q5, q6, [x10]
	mov	w13, #4                         ; =0x4
	dup.2d	v20, x13
	add.2d	v22, v3, v20
	add.2d	v23, v22, v19
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w12, #0, LBB0_132
; %bb.11:                               ; %else45
	tbnz	w11, #1, LBB0_133
LBB0_12:                                ; %else51
	add.2d	v23, v22, v16
	tbnz	w11, #2, LBB0_134
LBB0_13:                                ; %else57
	tbnz	w11, #3, LBB0_135
LBB0_14:                                ; %else63
	add.2d	v23, v22, v18
	tbnz	w11, #4, LBB0_136
LBB0_15:                                ; %else69
	tbnz	w11, #5, LBB0_137
LBB0_16:                                ; %else75
	add.2d	v22, v22, v17
	tbnz	w11, #6, LBB0_138
LBB0_17:                                ; %else81
	tbz	w11, #7, LBB0_19
LBB0_18:                                ; %cond.load83
	mov.d	x11, v22[1]
	ld1.s	{ v21 }[3], [x11]
LBB0_19:                                ; %else87
	fmov	w12, s2
	and	w11, w12, #0xff
	stp	q20, q21, [x10, #32]
	mov	w13, #8                         ; =0x8
	dup.2d	v22, x13
	add.2d	v24, v3, v22
	add.2d	v25, v24, v19
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w12, #0, LBB0_139
; %bb.20:                               ; %else94
	tbnz	w11, #1, LBB0_140
LBB0_21:                                ; %else100
	add.2d	v25, v24, v16
	tbnz	w11, #2, LBB0_141
LBB0_22:                                ; %else106
	tbnz	w11, #3, LBB0_142
LBB0_23:                                ; %else112
	add.2d	v25, v24, v18
	tbnz	w11, #4, LBB0_143
LBB0_24:                                ; %else118
	tbnz	w11, #5, LBB0_144
LBB0_25:                                ; %else124
	add.2d	v24, v24, v17
	tbnz	w11, #6, LBB0_145
LBB0_26:                                ; %else130
	tbz	w11, #7, LBB0_28
LBB0_27:                                ; %cond.load132
	mov.d	x11, v24[1]
	ld1.s	{ v23 }[3], [x11]
LBB0_28:                                ; %else136
	fmov	w12, s2
	and	w11, w12, #0xff
	stp	q22, q23, [x10, #64]
	mov	w13, #12                        ; =0xc
	dup.2d	v24, x13
	add.2d	v25, v3, v24
	add.2d	v26, v25, v19
	movi.2d	v19, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w12, #0, LBB0_146
; %bb.29:                               ; %else143
	tbnz	w11, #1, LBB0_147
LBB0_30:                                ; %else149
	add.2d	v16, v25, v16
	tbnz	w11, #2, LBB0_148
LBB0_31:                                ; %else155
	tbnz	w11, #3, LBB0_149
LBB0_32:                                ; %else161
	add.2d	v16, v25, v18
	tbnz	w11, #4, LBB0_150
LBB0_33:                                ; %else167
	tbnz	w11, #5, LBB0_151
LBB0_34:                                ; %else173
	add.2d	v16, v25, v17
	tbz	w11, #6, LBB0_36
LBB0_35:                                ; %cond.load175
	fmov	x12, d16
	ld1.s	{ v24 }[2], [x12]
LBB0_36:                                ; %else179
	sshll.2d	v17, v1, #0
	sshll.2d	v25, v0, #0
	sshll2.2d	v28, v1, #0
	sshll2.2d	v30, v0, #0
	ushll.2d	v29, v4, #8
	ushll.2d	v31, v7, #8
	ushll2.2d	v8, v4, #8
	ushll2.2d	v4, v7, #8
	fmul.4s	v18, v5, v5
	fmul.4s	v26, v6, v6
	fmul.4s	v20, v20, v20
	fmul.4s	v27, v21, v21
	fmul.4s	v21, v22, v22
	fmul.4s	v22, v23, v23
	tbz	w11, #7, LBB0_38
; %bb.37:                               ; %cond.load181
	mov.d	x11, v16[1]
	ld1.s	{ v24 }[3], [x11]
LBB0_38:                                ; %else185
	and.16b	v4, v30, v4
	and.16b	v5, v28, v8
	and.16b	v6, v25, v31
	and.16b	v7, v17, v29
	stp	q19, q24, [x10, #96]
	fmul.4s	v23, v19, v19
	fmul.4s	v24, v24, v24
	and.16b	v16, v0, v26
	and.16b	v18, v1, v18
	and.16b	v17, v0, v27
	and.16b	v20, v1, v20
	and.16b	v19, v0, v22
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #16
	and.16b	v22, v1, v21
	add	x10, x10, #224
	and.16b	v21, v0, v24
	mov	w11, #7                         ; =0x7
	fmov	w12, s2
	and.16b	v23, v1, v23
	b	LBB0_40
LBB0_39:                                ; %else381
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v24, v18, v24
	fadd.4s	v25, v16, v25
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v26, v20, v26
	fadd.4s	v27, v17, v27
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v28, v22, v28
	fadd.4s	v29, v19, v29
	ldp	q8, q9, [x10]
	bit.16b	v9, v31, v0
	bit.16b	v8, v30, v1
	stp	q8, q9, [x10], #128
	fmul.4s	v30, v30, v30
	fmul.4s	v31, v31, v31
	fadd.4s	v31, v21, v31
	fadd.4s	v30, v23, v30
	bit.16b	v16, v25, v0
	bit.16b	v18, v24, v1
	bit.16b	v17, v27, v0
	bit.16b	v20, v26, v1
	bit.16b	v19, v29, v0
	add	x11, x11, #4
	bit.16b	v22, v28, v1
	bit.16b	v23, v30, v1
	sub	x13, x13, #3
	bit.16b	v21, v31, v0
	cmp	x13, #252
	b.hs	LBB0_104
LBB0_40:                                ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	sub	x13, x11, #3
	dup.2d	v26, x13
	add.2d	v24, v26, v7
	shl.2d	v24, v24, #2
	add.2d	v27, v3, v24
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w12, #0, LBB0_75
; %bb.41:                               ; %else192
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w14, w12, #0xff
	tbnz	w14, #1, LBB0_76
LBB0_42:                                ; %else198
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v27, v26, v5
	shl.2d	v27, v27, #2
	add.2d	v27, v3, v27
	tbnz	w14, #2, LBB0_77
LBB0_43:                                ; %else204
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w14, #3, LBB0_78
LBB0_44:                                ; %else210
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v27, v26, v6
	shl.2d	v27, v27, #2
	add.2d	v27, v3, v27
	tbnz	w14, #4, LBB0_79
LBB0_45:                                ; %else216
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w14, #5, LBB0_80
LBB0_46:                                ; %else222
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v26, v26, v4
	shl.2d	v26, v26, #2
	add.2d	v26, v3, v26
	tbnz	w14, #6, LBB0_81
LBB0_47:                                ; %else228
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w14, #7, LBB0_49
LBB0_48:                                ; %cond.load230
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x14, v26[1]
	ld1.s	{ v25 }[3], [x14]
LBB0_49:                                ; %else234
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	w14, s2
	ldp	q26, q27, [x10, #-96]
	bit.16b	v27, v25, v0
	bit.16b	v26, v24, v1
	add	x13, x13, #1
	dup.2d	v28, x13
	stp	q26, q27, [x10, #-96]
	add.2d	v26, v28, v7
	shl.2d	v26, v26, #2
	add.2d	v29, v3, v26
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	tbnz	w14, #0, LBB0_82
; %bb.50:                               ; %else241
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_83
LBB0_51:                                ; %else247
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v29, v28, v5
	shl.2d	v29, v29, #2
	add.2d	v29, v3, v29
	tbnz	w14, #2, LBB0_84
LBB0_52:                                ; %else253
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w14, #3, LBB0_85
LBB0_53:                                ; %else259
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v29, v28, v6
	shl.2d	v29, v29, #2
	add.2d	v29, v3, v29
	tbnz	w14, #4, LBB0_86
LBB0_54:                                ; %else265
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w14, #5, LBB0_87
LBB0_55:                                ; %else271
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v28, v28, v4
	shl.2d	v28, v28, #2
	add.2d	v28, v3, v28
	tbnz	w14, #6, LBB0_88
LBB0_56:                                ; %else277
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w14, #7, LBB0_58
LBB0_57:                                ; %cond.load279
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x14, v28[1]
	ld1.s	{ v27 }[3], [x14]
LBB0_58:                                ; %else283
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	w14, s2
	ldp	q28, q29, [x10, #-64]
	bit.16b	v29, v27, v0
	bit.16b	v28, v26, v1
	add	x13, x13, #1
	dup.2d	v30, x13
	stp	q28, q29, [x10, #-64]
	add.2d	v28, v30, v7
	shl.2d	v28, v28, #2
	add.2d	v31, v3, v28
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w14, #0, LBB0_89
; %bb.59:                               ; %else290
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_90
LBB0_60:                                ; %else296
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v31, v30, v5
	shl.2d	v31, v31, #2
	add.2d	v31, v3, v31
	tbnz	w14, #2, LBB0_91
LBB0_61:                                ; %else302
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w14, #3, LBB0_92
LBB0_62:                                ; %else308
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v31, v30, v6
	shl.2d	v31, v31, #2
	add.2d	v31, v3, v31
	tbnz	w14, #4, LBB0_93
LBB0_63:                                ; %else314
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w14, #5, LBB0_94
LBB0_64:                                ; %else320
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v30, v30, v4
	shl.2d	v30, v30, #2
	add.2d	v30, v3, v30
	tbnz	w14, #6, LBB0_95
LBB0_65:                                ; %else326
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w14, #7, LBB0_67
LBB0_66:                                ; %cond.load328
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x14, v30[1]
	ld1.s	{ v29 }[3], [x14]
LBB0_67:                                ; %else332
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	w14, s2
	ldp	q30, q31, [x10, #-32]
	bit.16b	v31, v29, v0
	bit.16b	v30, v28, v1
	add	x13, x13, #1
	dup.2d	v8, x13
	stp	q30, q31, [x10, #-32]
	add.2d	v30, v8, v7
	shl.2d	v30, v30, #2
	add.2d	v9, v3, v30
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w14, #0, LBB0_96
; %bb.68:                               ; %else339
                                        ;   in Loop: Header=BB0_40 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_97
LBB0_69:                                ; %else345
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v9, v8, v5
	shl.2d	v9, v9, #2
	add.2d	v9, v3, v9
	tbnz	w14, #2, LBB0_98
LBB0_70:                                ; %else351
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w14, #3, LBB0_99
LBB0_71:                                ; %else357
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v9, v8, v6
	shl.2d	v9, v9, #2
	add.2d	v9, v3, v9
	tbnz	w14, #4, LBB0_100
LBB0_72:                                ; %else363
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbnz	w14, #5, LBB0_101
LBB0_73:                                ; %else369
                                        ;   in Loop: Header=BB0_40 Depth=1
	add.2d	v8, v8, v4
	shl.2d	v8, v8, #2
	add.2d	v8, v3, v8
	tbnz	w14, #6, LBB0_102
LBB0_74:                                ; %else375
                                        ;   in Loop: Header=BB0_40 Depth=1
	tbz	w14, #7, LBB0_39
	b	LBB0_103
LBB0_75:                                ; %cond.load188
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x14, d27
	ldr	s24, [x14]
	and	w14, w12, #0xff
	tbz	w14, #1, LBB0_42
LBB0_76:                                ; %cond.load194
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v27[1]
	ld1.s	{ v24 }[1], [x15]
	add.2d	v27, v26, v5
	shl.2d	v27, v27, #2
	add.2d	v27, v3, v27
	tbz	w14, #2, LBB0_43
LBB0_77:                                ; %cond.load200
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d27
	ld1.s	{ v24 }[2], [x15]
	tbz	w14, #3, LBB0_44
LBB0_78:                                ; %cond.load206
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v27[1]
	ld1.s	{ v24 }[3], [x15]
	add.2d	v27, v26, v6
	shl.2d	v27, v27, #2
	add.2d	v27, v3, v27
	tbz	w14, #4, LBB0_45
LBB0_79:                                ; %cond.load212
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d27
	ld1.s	{ v25 }[0], [x15]
	tbz	w14, #5, LBB0_46
LBB0_80:                                ; %cond.load218
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v27[1]
	ld1.s	{ v25 }[1], [x15]
	add.2d	v26, v26, v4
	shl.2d	v26, v26, #2
	add.2d	v26, v3, v26
	tbz	w14, #6, LBB0_47
LBB0_81:                                ; %cond.load224
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d26
	ld1.s	{ v25 }[2], [x15]
	tbnz	w14, #7, LBB0_48
	b	LBB0_49
LBB0_82:                                ; %cond.load237
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d29
	ldr	s26, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_51
LBB0_83:                                ; %cond.load243
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v29[1]
	ld1.s	{ v26 }[1], [x15]
	add.2d	v29, v28, v5
	shl.2d	v29, v29, #2
	add.2d	v29, v3, v29
	tbz	w14, #2, LBB0_52
LBB0_84:                                ; %cond.load249
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d29
	ld1.s	{ v26 }[2], [x15]
	tbz	w14, #3, LBB0_53
LBB0_85:                                ; %cond.load255
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v29[1]
	ld1.s	{ v26 }[3], [x15]
	add.2d	v29, v28, v6
	shl.2d	v29, v29, #2
	add.2d	v29, v3, v29
	tbz	w14, #4, LBB0_54
LBB0_86:                                ; %cond.load261
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d29
	ld1.s	{ v27 }[0], [x15]
	tbz	w14, #5, LBB0_55
LBB0_87:                                ; %cond.load267
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v29[1]
	ld1.s	{ v27 }[1], [x15]
	add.2d	v28, v28, v4
	shl.2d	v28, v28, #2
	add.2d	v28, v3, v28
	tbz	w14, #6, LBB0_56
LBB0_88:                                ; %cond.load273
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d28
	ld1.s	{ v27 }[2], [x15]
	tbnz	w14, #7, LBB0_57
	b	LBB0_58
LBB0_89:                                ; %cond.load286
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d31
	ldr	s28, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_60
LBB0_90:                                ; %cond.load292
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v31[1]
	ld1.s	{ v28 }[1], [x15]
	add.2d	v31, v30, v5
	shl.2d	v31, v31, #2
	add.2d	v31, v3, v31
	tbz	w14, #2, LBB0_61
LBB0_91:                                ; %cond.load298
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d31
	ld1.s	{ v28 }[2], [x15]
	tbz	w14, #3, LBB0_62
LBB0_92:                                ; %cond.load304
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v31[1]
	ld1.s	{ v28 }[3], [x15]
	add.2d	v31, v30, v6
	shl.2d	v31, v31, #2
	add.2d	v31, v3, v31
	tbz	w14, #4, LBB0_63
LBB0_93:                                ; %cond.load310
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d31
	ld1.s	{ v29 }[0], [x15]
	tbz	w14, #5, LBB0_64
LBB0_94:                                ; %cond.load316
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v31[1]
	ld1.s	{ v29 }[1], [x15]
	add.2d	v30, v30, v4
	shl.2d	v30, v30, #2
	add.2d	v30, v3, v30
	tbz	w14, #6, LBB0_65
LBB0_95:                                ; %cond.load322
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d30
	ld1.s	{ v29 }[2], [x15]
	tbnz	w14, #7, LBB0_66
	b	LBB0_67
LBB0_96:                                ; %cond.load335
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d9
	ldr	s30, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_69
LBB0_97:                                ; %cond.load341
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v9[1]
	ld1.s	{ v30 }[1], [x15]
	add.2d	v9, v8, v5
	shl.2d	v9, v9, #2
	add.2d	v9, v3, v9
	tbz	w14, #2, LBB0_70
LBB0_98:                                ; %cond.load347
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d9
	ld1.s	{ v30 }[2], [x15]
	tbz	w14, #3, LBB0_71
LBB0_99:                                ; %cond.load353
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v9[1]
	ld1.s	{ v30 }[3], [x15]
	add.2d	v9, v8, v6
	shl.2d	v9, v9, #2
	add.2d	v9, v3, v9
	tbz	w14, #4, LBB0_72
LBB0_100:                               ; %cond.load359
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d9
	ld1.s	{ v31 }[0], [x15]
	tbz	w14, #5, LBB0_73
LBB0_101:                               ; %cond.load365
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x15, v9[1]
	ld1.s	{ v31 }[1], [x15]
	add.2d	v8, v8, v4
	shl.2d	v8, v8, #2
	add.2d	v8, v3, v8
	tbz	w14, #6, LBB0_74
LBB0_102:                               ; %cond.load371
                                        ;   in Loop: Header=BB0_40 Depth=1
	fmov	x15, d8
	ld1.s	{ v31 }[2], [x15]
	tbz	w14, #7, LBB0_39
LBB0_103:                               ; %cond.load377
                                        ;   in Loop: Header=BB0_40 Depth=1
	mov.d	x14, v8[1]
	ld1.s	{ v31 }[3], [x14]
	b	LBB0_39
LBB0_104:                               ; %direct.true84.preheader
	mov	x10, #0                         ; =0x0
	add	x11, sp, #16
LBB0_105:                               ; %direct.true84
                                        ; =>This Inner Loop Header: Depth=1
	add	x12, x9, x10, lsl #2
	ld1r.4s	{ v3 }, [x12]
	add	x12, x11, x10, lsl #5
	ldp	q24, q25, [x12]
	bit.16b	v25, v3, v0
	bif.16b	v3, v24, v1
	stp	q3, q25, [x12]
	add	x10, x10, #1
	cmp	x10, #256
	b.ne	LBB0_105
; %bb.106:                              ; %direct.false85
	mov	x9, #0                          ; =0x0
	fadd.4s	v3, v18, v20
	fadd.4s	v16, v16, v17
	fadd.4s	v16, v16, v19
	fadd.4s	v3, v3, v22
	fadd.4s	v3, v3, v23
	fadd.4s	v16, v16, v21
	mov	w10, #998244352                 ; =0x3b800000
	dup.4s	v17, w10
	fmul.4s	v16, v16, v17
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	dup.4s	v18, w10
	fmul.4s	v3, v3, v17
	fadd.4s	v3, v3, v18
	fadd.4s	v16, v16, v18
	fsqrt.4s	v16, v16
	fsqrt.4s	v3, v3
	and.16b	v3, v1, v3
	and.16b	v16, v0, v16
	fmov	w10, s2
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #16
	dup.2d	v2, x8
	add	x8, sp, #16
	b	LBB0_108
LBB0_107:                               ; %else406
                                        ;   in Loop: Header=BB0_108 Depth=1
	add	x9, x9, #1
	cmp	x9, #256
	b.eq	LBB0_124
LBB0_108:                               ; %direct.true99
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v17, x9
	add.2d	v19, v17, v7
	lsl	x12, x9, #5
	add	x13, x11, x12
	ldr	q18, [x13]
	and.16b	v18, v1, v18
	fdiv.4s	v18, v18, v3
	add	x14, x8, x12
	ldr	q20, [x14]
	and.16b	v20, v1, v20
	fmul.4s	v18, v18, v20
	shl.2d	v19, v19, #2
	add.2d	v19, v2, v19
	tbnz	w10, #0, LBB0_117
; %bb.109:                              ; %else385
                                        ;   in Loop: Header=BB0_108 Depth=1
	and	w12, w10, #0xff
	tbnz	w12, #1, LBB0_118
LBB0_110:                               ; %else388
                                        ;   in Loop: Header=BB0_108 Depth=1
	add.2d	v19, v17, v5
	shl.2d	v19, v19, #2
	add.2d	v19, v2, v19
	tbnz	w12, #2, LBB0_119
LBB0_111:                               ; %else391
                                        ;   in Loop: Header=BB0_108 Depth=1
	tbz	w12, #3, LBB0_113
LBB0_112:                               ; %cond.store392
                                        ;   in Loop: Header=BB0_108 Depth=1
	mov.d	x15, v19[1]
	st1.s	{ v18 }[3], [x15]
LBB0_113:                               ; %else394
                                        ;   in Loop: Header=BB0_108 Depth=1
	add.2d	v19, v17, v6
	ldr	q18, [x13, #16]
	and.16b	v18, v0, v18
	fdiv.4s	v18, v18, v16
	ldr	q20, [x14, #16]
	and.16b	v20, v0, v20
	fmul.4s	v18, v18, v20
	shl.2d	v19, v19, #2
	add.2d	v19, v2, v19
	tbnz	w12, #4, LBB0_120
; %bb.114:                              ; %else397
                                        ;   in Loop: Header=BB0_108 Depth=1
	tbnz	w12, #5, LBB0_121
LBB0_115:                               ; %else400
                                        ;   in Loop: Header=BB0_108 Depth=1
	add.2d	v17, v17, v4
	shl.2d	v17, v17, #2
	add.2d	v17, v2, v17
	tbnz	w12, #6, LBB0_122
LBB0_116:                               ; %else403
                                        ;   in Loop: Header=BB0_108 Depth=1
	tbz	w12, #7, LBB0_107
	b	LBB0_123
LBB0_117:                               ; %cond.store
                                        ;   in Loop: Header=BB0_108 Depth=1
	fmov	x12, d19
	str	s18, [x12]
	and	w12, w10, #0xff
	tbz	w12, #1, LBB0_110
LBB0_118:                               ; %cond.store386
                                        ;   in Loop: Header=BB0_108 Depth=1
	mov.d	x15, v19[1]
	st1.s	{ v18 }[1], [x15]
	add.2d	v19, v17, v5
	shl.2d	v19, v19, #2
	add.2d	v19, v2, v19
	tbz	w12, #2, LBB0_111
LBB0_119:                               ; %cond.store389
                                        ;   in Loop: Header=BB0_108 Depth=1
	fmov	x15, d19
	st1.s	{ v18 }[2], [x15]
	tbnz	w12, #3, LBB0_112
	b	LBB0_113
LBB0_120:                               ; %cond.store395
                                        ;   in Loop: Header=BB0_108 Depth=1
	fmov	x13, d19
	str	s18, [x13]
	tbz	w12, #5, LBB0_115
LBB0_121:                               ; %cond.store398
                                        ;   in Loop: Header=BB0_108 Depth=1
	mov.d	x13, v19[1]
	st1.s	{ v18 }[1], [x13]
	add.2d	v17, v17, v4
	shl.2d	v17, v17, #2
	add.2d	v17, v2, v17
	tbz	w12, #6, LBB0_116
LBB0_122:                               ; %cond.store401
                                        ;   in Loop: Header=BB0_108 Depth=1
	fmov	x13, d17
	st1.s	{ v18 }[2], [x13]
	tbz	w12, #7, LBB0_107
LBB0_123:                               ; %cond.store404
                                        ;   in Loop: Header=BB0_108 Depth=1
	mov.d	x12, v17[1]
	st1.s	{ v18 }[3], [x12]
	b	LBB0_107
LBB0_124:                               ; %common.ret
	add	sp, sp, #4, lsl #12             ; =16384
	add	sp, sp, #16
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp], #32               ; 16-byte Folded Reload
	ret
LBB0_125:                               ; %cond.load
	fmov	x9, d17
	ldr	s5, [x9]
	and.16b	v7, v0, v7
	ushll2.2d	v16, v4, #10
	tbz	w8, #1, LBB0_3
LBB0_126:                               ; %cond.load19
	mov.d	x9, v17[1]
	ld1.s	{ v5 }[1], [x9]
	add.2d	v17, v3, v16
	tbz	w8, #2, LBB0_4
LBB0_127:                               ; %cond.load22
	fmov	x9, d17
	ld1.s	{ v5 }[2], [x9]
	ushll.2d	v18, v7, #10
	tbz	w8, #3, LBB0_5
LBB0_128:                               ; %cond.load25
	mov.d	x9, v17[1]
	ld1.s	{ v5 }[3], [x9]
	add.2d	v20, v3, v18
	tbz	w8, #4, LBB0_6
LBB0_129:                               ; %cond.load28
	fmov	x9, d20
	ld1.s	{ v6 }[0], [x9]
	ushll2.2d	v17, v7, #10
	tbz	w8, #5, LBB0_7
LBB0_130:                               ; %cond.load31
	mov.d	x9, v20[1]
	ld1.s	{ v6 }[1], [x9]
	add.2d	v20, v3, v17
	tbz	w8, #6, LBB0_8
LBB0_131:                               ; %cond.load34
	fmov	x9, d20
	ld1.s	{ v6 }[2], [x9]
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #16
	tbnz	w8, #7, LBB0_9
	b	LBB0_10
LBB0_132:                               ; %cond.load41
	fmov	x12, d23
	ldr	s20, [x12]
	tbz	w11, #1, LBB0_12
LBB0_133:                               ; %cond.load47
	mov.d	x12, v23[1]
	ld1.s	{ v20 }[1], [x12]
	add.2d	v23, v22, v16
	tbz	w11, #2, LBB0_13
LBB0_134:                               ; %cond.load53
	fmov	x12, d23
	ld1.s	{ v20 }[2], [x12]
	tbz	w11, #3, LBB0_14
LBB0_135:                               ; %cond.load59
	mov.d	x12, v23[1]
	ld1.s	{ v20 }[3], [x12]
	add.2d	v23, v22, v18
	tbz	w11, #4, LBB0_15
LBB0_136:                               ; %cond.load65
	fmov	x12, d23
	ld1.s	{ v21 }[0], [x12]
	tbz	w11, #5, LBB0_16
LBB0_137:                               ; %cond.load71
	mov.d	x12, v23[1]
	ld1.s	{ v21 }[1], [x12]
	add.2d	v22, v22, v17
	tbz	w11, #6, LBB0_17
LBB0_138:                               ; %cond.load77
	fmov	x12, d22
	ld1.s	{ v21 }[2], [x12]
	tbnz	w11, #7, LBB0_18
	b	LBB0_19
LBB0_139:                               ; %cond.load90
	fmov	x12, d25
	ldr	s22, [x12]
	tbz	w11, #1, LBB0_21
LBB0_140:                               ; %cond.load96
	mov.d	x12, v25[1]
	ld1.s	{ v22 }[1], [x12]
	add.2d	v25, v24, v16
	tbz	w11, #2, LBB0_22
LBB0_141:                               ; %cond.load102
	fmov	x12, d25
	ld1.s	{ v22 }[2], [x12]
	tbz	w11, #3, LBB0_23
LBB0_142:                               ; %cond.load108
	mov.d	x12, v25[1]
	ld1.s	{ v22 }[3], [x12]
	add.2d	v25, v24, v18
	tbz	w11, #4, LBB0_24
LBB0_143:                               ; %cond.load114
	fmov	x12, d25
	ld1.s	{ v23 }[0], [x12]
	tbz	w11, #5, LBB0_25
LBB0_144:                               ; %cond.load120
	mov.d	x12, v25[1]
	ld1.s	{ v23 }[1], [x12]
	add.2d	v24, v24, v17
	tbz	w11, #6, LBB0_26
LBB0_145:                               ; %cond.load126
	fmov	x12, d24
	ld1.s	{ v23 }[2], [x12]
	tbnz	w11, #7, LBB0_27
	b	LBB0_28
LBB0_146:                               ; %cond.load139
	fmov	x12, d26
	ldr	s19, [x12]
	tbz	w11, #1, LBB0_30
LBB0_147:                               ; %cond.load145
	mov.d	x12, v26[1]
	ld1.s	{ v19 }[1], [x12]
	add.2d	v16, v25, v16
	tbz	w11, #2, LBB0_31
LBB0_148:                               ; %cond.load151
	fmov	x12, d16
	ld1.s	{ v19 }[2], [x12]
	tbz	w11, #3, LBB0_32
LBB0_149:                               ; %cond.load157
	mov.d	x12, v16[1]
	ld1.s	{ v19 }[3], [x12]
	add.2d	v16, v25, v18
	tbz	w11, #4, LBB0_33
LBB0_150:                               ; %cond.load163
	fmov	x12, d16
	ld1.s	{ v24 }[0], [x12]
	tbz	w11, #5, LBB0_34
LBB0_151:                               ; %cond.load169
	mov.d	x12, v16[1]
	ld1.s	{ v24 }[1], [x12]
	add.2d	v16, v25, v17
	tbnz	w11, #6, LBB0_35
	b	LBB0_36
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_17
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w26, w23, [x2, #44]
	ldp	w27, w28, [x2]
	ldp	w25, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #56                         ; =0x38
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w27, #1
	cmp	w8, w26
	cset	w8, eq
	csinc	w27, wzr, w27, eq
	cinc	w9, w28, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w28, wzr, w9, ne
	add	w25, w25, w8
	subs	w19, w19, #1
	b.eq	LBB1_16
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x27, #6, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #64
	mov	w11, #64                        ; =0x40
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w27, w28, [x20]
	str	w25, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #64
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x26
	lsr	x26, x22, #3
	cmp	x22, #8
	b.lo	LBB1_13
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x26, #1
	b.eq	LBB1_13
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x26, #2
	b.eq	LBB1_13
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x26, #3
	b.eq	LBB1_13
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x26, #4
	b.eq	LBB1_13
; %bb.10:                               ; %packet.batch.partial.full.loop.i.4
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x26, #5
	b.eq	LBB1_13
; %bb.11:                               ; %packet.batch.partial.full.loop.i.5
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x26, #6
	b.eq	LBB1_13
; %bb.12:                               ; %packet.batch.partial.full.loop.i.6
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_13:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_15
; %bb.14:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w26, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_15:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #56                         ; =0x38
	str	w8, [x20, #36]
	mov	x26, x23
	ldr	w23, [sp, #12]                  ; 4-byte Folded Reload
	b	LBB1_3
LBB1_16:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_17:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

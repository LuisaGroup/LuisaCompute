	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	x28, x27, [sp, #-16]!           ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #384
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v0, v1, v4
	cmhi.4s	v1, v1, v3
	uzp1.8h	v5, v1, v0
	umaxv.8h	h2, v5
	fmov	w8, s2
	tbz	w8, #0, LBB0_57
; %bb.1:                                ; %direct.activate
	mov	x13, #0                         ; =0x0
	add	x11, sp, #144
	ldr	x12, [x0, #16]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x9, lCPI0_0@PAGE
Lloh5:
	ldr	q2, [x9, lCPI0_0@PAGEOFF]
	and.16b	v2, v5, v2
	addv.8h	h2, v2
	fmov	w9, s2
	and	w10, w9, #0xff
	ldr	x14, [x0]
	ldr	w9, [x1]
	ldr	w15, [x1, #36]
	add	w9, w15, w9, lsl #10
	lsr	w9, w9, #3
	fmov	s6, w9
	and.16b	v6, v1, v6
	fmov	w9, s6
	ubfiz	x9, x9, #14, #32
	add	x14, x14, x9
	fmov	w15, s2
	add	x16, sp, #4, lsl #12            ; =16384
	add	x16, x16, #384
	b	LBB0_3
LBB0_2:                                 ; %else45
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x16, x13
	ldp	q16, q17, [x17]
	bif.16b	v7, v17, v0
	bif.16b	v6, v16, v1
	stp	q6, q7, [x17]
	add	x13, x13, #32
	cmp	x13, #4, lsl #12                ; =16384
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x17, x14, x13
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w15, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w0, w15, #0xff
	tbnz	w0, #1, LBB0_12
LBB0_5:                                 ; %else27
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #2, LBB0_13
LBB0_6:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #3, LBB0_14
LBB0_7:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #4, LBB0_15
LBB0_8:                                 ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #5, LBB0_16
LBB0_9:                                 ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w0, #6, LBB0_17
LBB0_10:                                ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w0, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	s6, [x17]
	and	w0, w15, #0xff
	tbz	w0, #1, LBB0_5
LBB0_12:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #4
	ld1.s	{ v6 }[1], [x1]
	tbz	w0, #2, LBB0_6
LBB0_13:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #8
	ld1.s	{ v6 }[2], [x1]
	tbz	w0, #3, LBB0_7
LBB0_14:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #12
	ld1.s	{ v6 }[3], [x1]
	tbz	w0, #4, LBB0_8
LBB0_15:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #16
	ld1.s	{ v7 }[0], [x1]
	tbz	w0, #5, LBB0_9
LBB0_16:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #20
	ld1.s	{ v7 }[1], [x1]
	tbz	w0, #6, LBB0_10
LBB0_17:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x17, #24
	ld1.s	{ v7 }[2], [x1]
	tbz	w0, #7, LBB0_2
LBB0_18:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x17, #28
	ld1.s	{ v7 }[3], [x17]
	b	LBB0_2
LBB0_19:                                ; %direct.false
	ldr	q6, [x11, #16640]
	ldr	q7, [x11, #16624]
	fmul.4s	v16, v7, v7
	fmul.4s	v6, v6, v6
	ldr	q7, [x11, #16672]
	ldr	q17, [x11, #16656]
	fmul.4s	v17, v17, v17
	fmul.4s	v18, v7, v7
	ldr	q7, [x11, #16704]
	ldr	q19, [x11, #16688]
	fmul.4s	v21, v19, v19
	fmul.4s	v22, v7, v7
	ldr	q7, [x11, #16736]
	ldr	q19, [x11, #16720]
	fmul.4s	v23, v19, v19
	fmul.4s	v24, v7, v7
	and.16b	v7, v0, v6
	and.16b	v6, v1, v16
	and.16b	v20, v0, v18
	and.16b	v19, v1, v17
	and.16b	v16, v0, v22
	and.16b	v21, v1, v21
	and.16b	v18, v0, v24
	and.16b	v17, v1, v23
	add	x13, sp, #4, lsl #12            ; =16384
	add	x13, x13, #384
	add	x13, x13, #224
	mov	w14, #4                         ; =0x4
LBB0_20:                                ; %direct.true47
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q23, q22, [x13, #-96]
	and.16b	v23, v1, v23
	and.16b	v22, v0, v22
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	fadd.4s	v23, v6, v23
	fadd.4s	v22, v7, v22
	ldp	q25, q24, [x13, #-64]
	and.16b	v25, v1, v25
	and.16b	v24, v0, v24
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v25, v25
	fadd.4s	v25, v19, v25
	fadd.4s	v24, v20, v24
	ldp	q27, q26, [x13, #-32]
	and.16b	v27, v1, v27
	and.16b	v26, v0, v26
	fmul.4s	v26, v26, v26
	fmul.4s	v27, v27, v27
	fadd.4s	v27, v21, v27
	fadd.4s	v26, v16, v26
	ldp	q29, q28, [x13], #128
	and.16b	v29, v1, v29
	and.16b	v28, v0, v28
	fmul.4s	v28, v28, v28
	fmul.4s	v29, v29, v29
	fadd.4s	v29, v17, v29
	fadd.4s	v28, v18, v28
	bit.16b	v7, v22, v0
	bit.16b	v6, v23, v1
	bit.16b	v20, v24, v0
	bit.16b	v19, v25, v1
	bit.16b	v16, v26, v0
	bit.16b	v21, v27, v1
	bit.16b	v18, v28, v0
	bit.16b	v17, v29, v1
	cmp	x14, #508
	add	x14, x14, #4
	b.lo	LBB0_20
; %bb.21:                               ; %direct.true85.preheader
	mov	x13, #0                         ; =0x0
	fmov	w14, s2
	add	x15, sp, #384
	b	LBB0_23
LBB0_22:                                ; %else70
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x16, x15, x13
	ldp	q24, q25, [x16]
	bif.16b	v23, v25, v0
	bif.16b	v22, v24, v1
	stp	q22, q23, [x16]
	add	x13, x13, #32
	cmp	x13, #4, lsl #12                ; =16384
	b.eq	LBB0_39
LBB0_23:                                ; %direct.true85
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x12, x13
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w14, #0, LBB0_31
; %bb.24:                               ; %else49
                                        ;   in Loop: Header=BB0_23 Depth=1
	and	w17, w14, #0xff
	tbnz	w17, #1, LBB0_32
LBB0_25:                                ; %else52
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #2, LBB0_33
LBB0_26:                                ; %else55
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #3, LBB0_34
LBB0_27:                                ; %else58
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #4, LBB0_35
LBB0_28:                                ; %else61
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #5, LBB0_36
LBB0_29:                                ; %else64
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w17, #6, LBB0_37
LBB0_30:                                ; %else67
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbz	w17, #7, LBB0_22
	b	LBB0_38
LBB0_31:                                ; %cond.load48
                                        ;   in Loop: Header=BB0_23 Depth=1
	ldr	s22, [x16]
	and	w17, w14, #0xff
	tbz	w17, #1, LBB0_25
LBB0_32:                                ; %cond.load51
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #4
	ld1.s	{ v22 }[1], [x0]
	tbz	w17, #2, LBB0_26
LBB0_33:                                ; %cond.load54
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #8
	ld1.s	{ v22 }[2], [x0]
	tbz	w17, #3, LBB0_27
LBB0_34:                                ; %cond.load57
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #12
	ld1.s	{ v22 }[3], [x0]
	tbz	w17, #4, LBB0_28
LBB0_35:                                ; %cond.load60
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #16
	ld1.s	{ v23 }[0], [x0]
	tbz	w17, #5, LBB0_29
LBB0_36:                                ; %cond.load63
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #20
	ld1.s	{ v23 }[1], [x0]
	tbz	w17, #6, LBB0_30
LBB0_37:                                ; %cond.load66
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x0, x16, #24
	ld1.s	{ v23 }[2], [x0]
	tbz	w17, #7, LBB0_22
LBB0_38:                                ; %cond.load69
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x16, x16, #28
	ld1.s	{ v23 }[3], [x16]
	b	LBB0_22
LBB0_39:                                ; %direct.false86
	mov	x12, #0                         ; =0x0
	xtn.8b	v22, v5
	fadd.4s	v5, v7, v20
	fadd.4s	v6, v6, v19
	fadd.4s	v6, v6, v21
	fadd.4s	v5, v5, v16
	fadd.4s	v5, v5, v18
	fadd.4s	v6, v6, v17
	and.16b	v3, v1, v3
	and.16b	v4, v0, v4
	movi.4s	v7, #1
	eor.16b	v16, v4, v7
	eor.16b	v19, v3, v7
	umov.b	w14, v22[0]
	str	q6, [x11, #192]
	ldr	s7, [x11, #196]
	umov.b	w13, v22[1]
	ands	w15, w14, #0x1
	tst	w15, w13
	movi	d3, #0000000000000000
	fcsel	s7, s7, s3, ne
	mov.s	w16, v19[1]
	add	x17, sp, #8
	add	x0, sp, #8
	bfxil	x0, x16, #0, #3
	str	d22, [sp, #8]
	ldrb	w0, [x0]
	add	x1, sp, #304
	orr	x16, x1, x16, lsl #2
	stp	q6, q5, [x11, #160]
	ldr	s17, [x16]
	ands	w16, w13, #0x1
	tst	w16, w0
	mov.s	w16, v19[2]
	fcsel	s17, s17, s3, ne
	add	x0, sp, #8
	bfxil	x0, x16, #0, #3
	ldrb	w0, [x0]
	add	x1, sp, #272
	orr	x1, x1, x16, lsl #2
	umov.b	w16, v22[2]
	stp	q6, q5, [x11, #128]
	ldr	s18, [x1]
	ands	w1, w16, #0x1
	tst	w1, w0
	fcsel	s18, s18, s3, ne
	mov.s	w0, v19[3]
	add	x1, sp, #8
	bfxil	x1, x0, #0, #3
	ldrb	w1, [x1]
	add	x2, sp, #240
	orr	x2, x2, x0, lsl #2
	umov.b	w0, v22[3]
	stp	q6, q5, [x11, #96]
	ldr	s19, [x2]
	ands	w2, w0, #0x1
	tst	w2, w1
	fcsel	s19, s19, s3, ne
	fmov	w2, s16
	add	x1, sp, #8
	bfxil	x1, x2, #0, #3
	ldrb	w3, [x1]
	umov.b	w1, v22[4]
	and	w3, w1, w3
	stp	q6, q5, [x11, #64]
	add	x4, sp, #208
	ldr	s20, [x4, w2, uxtw #2]
	tst	w3, #0x1
	mov.s	w3, v16[1]
	add	x4, sp, #8
	bfxil	x4, x3, #0, #3
	umov.b	w2, v22[5]
	ldrb	w4, [x4]
	stp	q6, q5, [x11, #32]
	add	x5, sp, #176
	ldr	s21, [x5, w3, uxtw #2]
	fcsel	s20, s20, s3, ne
	ands	w3, w2, #0x1
	tst	w3, w4
	fcsel	s21, s21, s3, ne
	mov.s	w4, v16[2]
	add	x3, sp, #8
	bfxil	x3, x4, #0, #3
	ldrb	w5, [x3]
	umov.b	w3, v22[6]
	stp	q6, q5, [x11]
	add	x11, sp, #144
	ldr	s23, [x11, w4, uxtw #2]
	ands	w11, w3, #0x1
	tst	w11, w5
	mov.s	w11, v16[3]
	add	x4, sp, #8
	bfxil	x4, x11, #0, #3
	ldrb	w4, [x4]
	stp	q6, q5, [sp, #112]
	add	x5, sp, #112
	ldr	s16, [x5, w11, uxtw #2]
	umov.b	w11, v22[7]
	fcsel	s22, s23, s3, ne
	ands	w5, w11, #0x1
	tst	w5, w4
	fcsel	s16, s16, s3, ne
	mov.s	v7[1], v17[0]
	mov.s	v7[2], v18[0]
	mov.s	v7[3], v19[0]
	mov.s	v20[1], v21[0]
	mov.s	v20[2], v22[0]
	mov.s	v20[3], v16[0]
	fadd.4s	v5, v5, v20
	fadd.4s	v6, v6, v7
	movi.4s	v7, #2
	eor.16b	v4, v4, v7
	str	q6, [sp, #80]
	ldr	s7, [sp, #88]
	tst	w15, w16
	fcsel	s7, s7, s3, ne
	fmov	w4, s4
	bfxil	x17, x4, #0, #3
	ldrb	w17, [x17]
	and	w17, w1, w17
	stp	q6, q5, [sp, #48]
	add	x5, sp, #48
	ldr	s4, [x5, w4, uxtw #2]
	tst	w17, #0x1
	fcsel	s4, s4, s3, ne
	fadd.4s	v4, v5, v4
	tst	w15, w1
	fcsel	s4, s4, s3, ne
	ands	w14, w14, #0x1
	fadd.4s	v5, v6, v7
	fadd	s4, s5, s4
	fcsel	s5, s4, s3, ne
	tst	w13, #0x1
	fcsel	s6, s5, s3, ne
	tst	w16, #0x1
	fcsel	s7, s5, s3, ne
	tst	w0, #0x1
	fcsel	s16, s5, s3, ne
	tst	w14, w1
	fcsel	s4, s4, s3, ne
	tst	w2, #0x1
	fcsel	s17, s5, s3, ne
	tst	w3, #0x1
	fcsel	s18, s5, s3, ne
	tst	w11, #0x1
	fcsel	s19, s5, s3, ne
	mov.s	v5[1], v6[0]
	mov.s	v5[2], v7[0]
	mov.s	v5[3], v16[0]
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v18[0]
	mov.s	v4[3], v19[0]
	rbit	w10, w10
	clz	w10, w10
	stp	q5, q4, [sp, #16]
	and	x10, x10, #0x7
	add	x11, sp, #16
	ldr	s4, [x11, x10, lsl #2]
	fadd	s3, s4, s3
	mov	w10, #964689920                 ; =0x39800000
	fmov	s4, w10
	fmul	s3, s3, s4
	mov	w10, #50604                     ; =0xc5ac
	movk	w10, #14119, lsl #16
	fmov	s4, w10
	fadd	s3, s3, s4
	fsqrt	s3, s3
	dup.4s	v3, v3[0]
	add	x8, x8, x9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #384
	add	x10, sp, #384
	b	LBB0_41
LBB0_40:                                ; %else87
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x12, x12, #32
	cmp	x12, #4, lsl #12                ; =16384
	b.eq	LBB0_57
LBB0_41:                                ; %direct.true105
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w13, s2
	add	x14, x9, x12
	ldr	q4, [x14]
	and.16b	v4, v1, v4
	fdiv.4s	v4, v4, v3
	add	x15, x10, x12
	ldr	q5, [x15]
	and.16b	v5, v1, v5
	fmul.4s	v4, v4, v5
	add	x11, x8, x12
	tbnz	w13, #0, LBB0_50
; %bb.42:                               ; %else73
                                        ;   in Loop: Header=BB0_41 Depth=1
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_51
LBB0_43:                                ; %else75
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w13, #2, LBB0_52
LBB0_44:                                ; %else77
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w13, #3, LBB0_46
LBB0_45:                                ; %cond.store78
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x16, x11, #12
	st1.s	{ v4 }[3], [x16]
LBB0_46:                                ; %else79
                                        ;   in Loop: Header=BB0_41 Depth=1
	ldr	q4, [x14, #16]
	and.16b	v4, v0, v4
	fdiv.4s	v4, v4, v3
	ldr	q5, [x15, #16]
	and.16b	v5, v0, v5
	fmul.4s	v4, v4, v5
	tbnz	w13, #4, LBB0_53
; %bb.47:                               ; %else81
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w13, #5, LBB0_54
LBB0_48:                                ; %else83
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w13, #6, LBB0_55
LBB0_49:                                ; %else85
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w13, #7, LBB0_40
	b	LBB0_56
LBB0_50:                                ; %cond.store
                                        ;   in Loop: Header=BB0_41 Depth=1
	str	s4, [x11]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_43
LBB0_51:                                ; %cond.store74
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x16, x11, #4
	st1.s	{ v4 }[1], [x16]
	tbz	w13, #2, LBB0_44
LBB0_52:                                ; %cond.store76
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x16, x11, #8
	st1.s	{ v4 }[2], [x16]
	tbnz	w13, #3, LBB0_45
	b	LBB0_46
LBB0_53:                                ; %cond.store80
                                        ;   in Loop: Header=BB0_41 Depth=1
	str	s4, [x11, #16]
	tbz	w13, #5, LBB0_48
LBB0_54:                                ; %cond.store82
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x14, x11, #20
	st1.s	{ v4 }[1], [x14]
	tbz	w13, #6, LBB0_49
LBB0_55:                                ; %cond.store84
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x14, x11, #24
	st1.s	{ v4 }[2], [x14]
	tbz	w13, #7, LBB0_40
LBB0_56:                                ; %cond.store86
                                        ;   in Loop: Header=BB0_41 Depth=1
	add	x11, x11, #28
	st1.s	{ v4 }[3], [x11]
	b	LBB0_40
LBB0_57:                                ; %common.ret
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #384
	ldp	x28, x27, [sp], #16             ; 16-byte Folded Reload
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_13
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	mov	w22, #0                         ; =0x0
	ldp	w24, w8, [x2, #44]
	stp	w3, w8, [sp, #8]                ; 8-byte Folded Spill
	ldp	w25, w26, [x2]
	ldp	w28, w27, [x2, #8]
	str	w24, [sp, #4]                   ; 4-byte Folded Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #1016                       ; =0x3f8
	str	w8, [x20, #36]
	ldp	w24, w19, [sp, #4]              ; 8-byte Folded Reload
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w24
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w26, eq
	ldr	w10, [sp, #12]                  ; 4-byte Folded Reload
	cmp	w9, w10
	cset	w10, eq
	ands	w8, w8, w10
	csel	w26, wzr, w9, ne
	add	w28, w28, w8
	add	w22, w22, #1
	cmp	w22, w19
	b.eq	LBB1_12
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB1_9 Depth 2
                                        ;     Child Loop BB1_6 Depth 2
	ubfiz	x8, x25, #10, #32
	cmp	x8, x27
	csel	x9, x8, xzr, ls
	subs	x10, x27, x9
	cmp	x10, #1024
	mov	w11, #1024                      ; =0x400
	csel	x10, x10, x11, lo
	cmp	x27, x9
	stp	w25, w26, [x20]
	str	w28, [x20, #8]
	ccmp	x8, x27, #2, hi
	csel	x23, x10, xzr, ls
	cmp	x23, #1024
	b.lo	LBB1_7
; %bb.5:                                ; %packet.batch.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w23, #0                         ; =0x0
LBB1_6:                                 ; %packet.batch.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w23, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w23, w23, #8
	cmp	w23, #1024
	b.ne	LBB1_6
	b	LBB1_3
LBB1_7:                                 ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsr	x8, x23, #3
	lsl	w24, w8, #3
	cmp	x23, #8
	b.lo	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.preheader
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w19, #0                         ; =0x0
LBB1_9:                                 ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB1_4 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	w19, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	add	w19, w19, #8
	cmp	w24, w19
	b.ne	LBB1_9
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w23, #0x7
	cbz	w2, LBB1_2
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	w24, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
	b	LBB1_2
LBB1_12:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_13:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

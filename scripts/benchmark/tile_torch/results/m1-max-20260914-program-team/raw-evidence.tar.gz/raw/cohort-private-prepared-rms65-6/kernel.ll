; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [288 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill4 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill4, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill5 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill5, align 1
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.slot7 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot7, align 64
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.slot12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot12, align 32
  %.spill13 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill13, align 4
  %tile_snapshot.spill14 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill14, align 64
  %.slot15 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot15, align 64
  %.spill16 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill16, align 4
  %.slot17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot17, align 64
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert18 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat19 = shufflevector <8 x i32> %.splatinsert18, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat19, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert20 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat21 = shufflevector <8 x i32> %.splatinsert20, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat21, %41
  %44 = mul i32 %32, 1
  %.splatinsert22 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat23 = shufflevector <8 x i32> %.splatinsert22, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat23, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert24 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat25 = shufflevector <8 x i32> %.splatinsert24, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat25, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert26 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat27 = shufflevector <8 x i32> %.splatinsert26, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat27
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = load <8 x i64>, ptr %.spill, align 64
  %55 = select <8 x i1> %51, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %54
  store <8 x i64> %55, ptr %.spill, align 64
  %56 = sub <8 x i32> %53, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %57 = select <8 x i1> %51, <8 x i32> %56, <8 x i32> zeroinitializer
  %58 = select <8 x i1> %51, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %59 = lshr <8 x i32> %57, %58
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %51, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill4, align 64
  %65 = select <8 x i1> %51, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill4, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %51, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %51, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 8
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state28 = load i64, ptr %.slot, align 4
  %76 = mul i64 %.state28, 8
  %.splatinsert29 = insertelement <8 x i64> poison, i64 %76, i64 0
  %.splat30 = shufflevector <8 x i64> %.splatinsert29, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %77 = add <8 x i64> %.splat30, %.spill.load
  %.spill.load31 = load <8 x i64>, ptr %.spill4, align 64
  %78 = add <8 x i64> %.spill.load31, zeroinitializer
  %79 = add <8 x i64> zeroinitializer, %78
  %80 = add <8 x i64> zeroinitializer, %77
  %81 = mul <8 x i64> %79, splat (i64 65)
  %82 = add <8 x i64> %81, %80
  %83 = extractvalue { ptr, i64 } %9, 0
  %84 = extractelement <8 x i64> %82, i32 0
  %85 = sub i64 %84, 0
  %86 = mul i64 %85, 4
  %buffer.contiguous.address = getelementptr i8, ptr %83, i64 %86
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %87 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %88 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state32 = load i64, ptr %.slot, align 4
  %.splatinsert33 = insertelement <8 x i64> poison, i64 %.state32, i64 0
  %.splat34 = shufflevector <8 x i64> %.splatinsert33, <8 x i64> poison, <8 x i32> zeroinitializer
  %89 = mul <8 x i64> %.splat34, splat (i64 32)
  %90 = add <8 x i64> %88, %89
  %91 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %87, 0
  %92 = insertvalue { <8 x ptr>, <8 x i64> } %91, <8 x i64> %90, 1
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %92, 1
  %95 = extractelement <8 x ptr> %93, i32 0
  %96 = extractelement <8 x i64> %94, i32 0
  %97 = sub i64 %96, 0
  %98 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %99 = select i1 %98, i64 %97, i64 0
  %private.contiguous.address = getelementptr i8, ptr %95, i64 %99
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %100 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %100, ptr %private.contiguous.address, align 4
  %.state35 = load i64, ptr %.slot, align 4
  %101 = add i64 %.state35, 1
  store i64 %101, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load36 = load <8 x i64>, ptr %.spill, align 64
  %102 = icmp slt <8 x i64> %.spill.load36, splat (i64 1)
  %103 = load <8 x i1>, ptr %.spill5, align 1
  %104 = select <8 x i1> %51, <8 x i1> %102, <8 x i1> %103
  store <8 x i1> %104, ptr %.spill5, align 1
  %105 = and <8 x i1> %51, %102
  %106 = xor <8 x i1> %102, splat (i1 true)
  %107 = and <8 x i1> %51, %106
  %108 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %109 = bitcast <8 x i1> %105 to i8
  %110 = call i8 @llvm.cttz.i8(i8 %109, i1 false)
  %111 = zext i8 %110 to i32
  %112 = select i1 %108, i32 %111, i32 0
  %.spill.load37 = load <8 x i64>, ptr %.spill, align 64
  %113 = add <8 x i64> splat (i64 64), %.spill.load37
  %.spill.load38 = load <8 x i64>, ptr %.spill4, align 64
  %114 = add <8 x i64> %.spill.load38, zeroinitializer
  %115 = add <8 x i64> zeroinitializer, %114
  %116 = add <8 x i64> zeroinitializer, %113
  %117 = mul <8 x i64> %115, splat (i64 65)
  %118 = add <8 x i64> %117, %116
  %119 = extractvalue { ptr, i64 } %9, 0
  %120 = select <8 x i1> %105, <8 x i64> %118, <8 x i64> zeroinitializer
  %121 = extractelement <8 x i64> %120, i32 %112
  %122 = zext i32 %112 to i64
  %123 = sub i64 %121, %122
  %124 = mul i64 %123, 4
  %buffer.contiguous.address39 = getelementptr i8, ptr %119, i64 %124
  %buffer.contiguous.load40 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address39, <8 x i1> %105, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load41 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %125 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load41, 0
  %126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load41, 1
  %127 = add <8 x i64> %126, splat (i64 256)
  %128 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %125, 0
  %129 = insertvalue { <8 x ptr>, <8 x i64> } %128, <8 x i64> %127, 1
  %130 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %129, 1
  %132 = extractelement <8 x ptr> %130, i32 0
  %133 = extractelement <8 x i64> %131, i32 %112
  %134 = zext i32 %112 to i64
  %135 = mul i64 %134, 4
  %136 = sub i64 %133, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %105)
  %138 = select i1 %137, i64 %136, i64 0
  %private.contiguous.address42 = getelementptr i8, ptr %132, i64 %138
  %private.contiguous.preserve43 = load <8 x float>, ptr %private.contiguous.address42, align 4
  %139 = select <8 x i1> %105, <8 x float> %buffer.contiguous.load40, <8 x float> %private.contiguous.preserve43
  store <8 x float> %139, ptr %private.contiguous.address42, align 4
  %140 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %107)
  %141 = bitcast <8 x i1> %107 to i8
  %142 = call i8 @llvm.cttz.i8(i8 %141, i1 false)
  %143 = zext i8 %142 to i32
  %144 = select i1 %140, i32 %143, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  store i64 0, ptr %.spill6, align 4
  %tile_snapshot.spill.load44 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %145 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 0
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load44, 1
  %147 = add <8 x i64> %146, zeroinitializer
  %148 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %145, 0
  %149 = insertvalue { <8 x ptr>, <8 x i64> } %148, <8 x i64> %147, 1
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %151 = extractvalue { <8 x ptr>, <8 x i64> } %149, 1
  %152 = extractelement <8 x ptr> %150, i32 0
  %153 = extractelement <8 x i64> %151, i32 0
  %154 = sub i64 %153, 0
  %155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %156 = select i1 %155, i64 %154, i64 0
  %private.contiguous.address45 = getelementptr i8, ptr %152, i64 %156
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address45, align 4
  %157 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %158 = fmul <8 x float> %157, %157
  %tile_snapshot.spill.load46 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load46, 0
  %160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load46, 1
  %161 = add <8 x i64> %160, splat (i64 32)
  %162 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %159, 0
  %163 = insertvalue { <8 x ptr>, <8 x i64> } %162, <8 x i64> %161, 1
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %165 = extractvalue { <8 x ptr>, <8 x i64> } %163, 1
  %166 = extractelement <8 x ptr> %164, i32 0
  %167 = extractelement <8 x i64> %165, i32 0
  %168 = sub i64 %167, 0
  %169 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %170 = select i1 %169, i64 %168, i64 0
  %private.contiguous.address47 = getelementptr i8, ptr %166, i64 %170
  %private.contiguous.load48 = load <8 x float>, ptr %private.contiguous.address47, align 4
  %171 = select <8 x i1> %51, <8 x float> %private.contiguous.load48, <8 x float> zeroinitializer
  %172 = fmul <8 x float> %171, %171
  %tile_snapshot.spill.load49 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 0
  %174 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load49, 1
  %175 = add <8 x i64> %174, splat (i64 64)
  %176 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %173, 0
  %177 = insertvalue { <8 x ptr>, <8 x i64> } %176, <8 x i64> %175, 1
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %179 = extractvalue { <8 x ptr>, <8 x i64> } %177, 1
  %180 = extractelement <8 x ptr> %178, i32 0
  %181 = extractelement <8 x i64> %179, i32 0
  %182 = sub i64 %181, 0
  %183 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %184 = select i1 %183, i64 %182, i64 0
  %private.contiguous.address50 = getelementptr i8, ptr %180, i64 %184
  %private.contiguous.load51 = load <8 x float>, ptr %private.contiguous.address50, align 4
  %185 = select <8 x i1> %51, <8 x float> %private.contiguous.load51, <8 x float> zeroinitializer
  %186 = fmul <8 x float> %185, %185
  %tile_snapshot.spill.load52 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load52, 1
  %189 = add <8 x i64> %188, splat (i64 96)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 0
  %196 = sub i64 %195, 0
  %197 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %198 = select i1 %197, i64 %196, i64 0
  %private.contiguous.address53 = getelementptr i8, ptr %194, i64 %198
  %private.contiguous.load54 = load <8 x float>, ptr %private.contiguous.address53, align 4
  %199 = select <8 x i1> %51, <8 x float> %private.contiguous.load54, <8 x float> zeroinitializer
  %200 = fmul <8 x float> %199, %199
  %201 = load <8 x i64>, ptr %.slot7, align 64
  %202 = select <8 x i1> %51, <8 x i64> splat (i64 4), <8 x i64> %201
  store <8 x i64> %202, ptr %.slot7, align 64
  %203 = load <8 x float>, ptr %.slot8, align 32
  %204 = select <8 x i1> %51, <8 x float> %158, <8 x float> %203
  store <8 x float> %204, ptr %.slot8, align 32
  %205 = load <8 x float>, ptr %.slot9, align 32
  %206 = select <8 x i1> %51, <8 x float> %172, <8 x float> %205
  store <8 x float> %206, ptr %.slot9, align 32
  %207 = load <8 x float>, ptr %.slot10, align 32
  %208 = select <8 x i1> %51, <8 x float> %186, <8 x float> %207
  store <8 x float> %208, ptr %.slot10, align 32
  %209 = load <8 x float>, ptr %.slot11, align 32
  %210 = select <8 x i1> %51, <8 x float> %200, <8 x float> %209
  store <8 x float> %210, ptr %.slot11, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state55 = load <8 x i64>, ptr %.slot7, align 64
  %211 = icmp slt <8 x i64> %.state55, splat (i64 8)
  %212 = extractelement <8 x i1> %211, i32 0
  br i1 %212, label %direct.true56, label %direct.false57

direct.schedule.7:                                ; preds = %direct.true56
  %.state58 = load <8 x i64>, ptr %.slot7, align 64
  %213 = add <8 x i64> %.state58, zeroinitializer
  %tile_snapshot.spill.load59 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 0
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load59, 1
  %216 = mul <8 x i64> %213, splat (i64 32)
  %217 = add <8 x i64> %215, %216
  %218 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %214, 0
  %219 = insertvalue { <8 x ptr>, <8 x i64> } %218, <8 x i64> %217, 1
  %220 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %221 = extractvalue { <8 x ptr>, <8 x i64> } %219, 1
  %222 = extractelement <8 x ptr> %220, i32 0
  %223 = extractelement <8 x i64> %221, i32 0
  %224 = sub i64 %223, 0
  %225 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %226 = select i1 %225, i64 %224, i64 0
  %private.contiguous.address60 = getelementptr i8, ptr %222, i64 %226
  %private.contiguous.load61 = load <8 x float>, ptr %private.contiguous.address60, align 4
  %227 = select <8 x i1> %51, <8 x float> %private.contiguous.load61, <8 x float> zeroinitializer
  %228 = fmul <8 x float> %227, %227
  %.state62 = load <8 x float>, ptr %.slot8, align 32
  %229 = fadd <8 x float> %.state62, %228
  %.state63 = load <8 x i64>, ptr %.slot7, align 64
  %230 = add <8 x i64> %.state63, splat (i64 1)
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %233 = mul <8 x i64> %230, splat (i64 32)
  %234 = add <8 x i64> %232, %233
  %235 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %231, 0
  %236 = insertvalue { <8 x ptr>, <8 x i64> } %235, <8 x i64> %234, 1
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %238 = extractvalue { <8 x ptr>, <8 x i64> } %236, 1
  %239 = extractelement <8 x ptr> %237, i32 0
  %240 = extractelement <8 x i64> %238, i32 0
  %241 = sub i64 %240, 0
  %242 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %243 = select i1 %242, i64 %241, i64 0
  %private.contiguous.address65 = getelementptr i8, ptr %239, i64 %243
  %private.contiguous.load66 = load <8 x float>, ptr %private.contiguous.address65, align 4
  %244 = select <8 x i1> %51, <8 x float> %private.contiguous.load66, <8 x float> zeroinitializer
  %245 = fmul <8 x float> %244, %244
  %.state67 = load <8 x float>, ptr %.slot9, align 32
  %246 = fadd <8 x float> %.state67, %245
  %.state68 = load <8 x i64>, ptr %.slot7, align 64
  %247 = add <8 x i64> %.state68, splat (i64 2)
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %250 = mul <8 x i64> %247, splat (i64 32)
  %251 = add <8 x i64> %249, %250
  %252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %253 = insertvalue { <8 x ptr>, <8 x i64> } %252, <8 x i64> %251, 1
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %253, 1
  %256 = extractelement <8 x ptr> %254, i32 0
  %257 = extractelement <8 x i64> %255, i32 0
  %258 = sub i64 %257, 0
  %259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %260 = select i1 %259, i64 %258, i64 0
  %private.contiguous.address70 = getelementptr i8, ptr %256, i64 %260
  %private.contiguous.load71 = load <8 x float>, ptr %private.contiguous.address70, align 4
  %261 = select <8 x i1> %51, <8 x float> %private.contiguous.load71, <8 x float> zeroinitializer
  %262 = fmul <8 x float> %261, %261
  %.state72 = load <8 x float>, ptr %.slot10, align 32
  %263 = fadd <8 x float> %.state72, %262
  %.state73 = load <8 x i64>, ptr %.slot7, align 64
  %264 = add <8 x i64> %.state73, splat (i64 3)
  %tile_snapshot.spill.load74 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 0
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load74, 1
  %267 = mul <8 x i64> %264, splat (i64 32)
  %268 = add <8 x i64> %266, %267
  %269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %265, 0
  %270 = insertvalue { <8 x ptr>, <8 x i64> } %269, <8 x i64> %268, 1
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %270, 1
  %273 = extractelement <8 x ptr> %271, i32 0
  %274 = extractelement <8 x i64> %272, i32 0
  %275 = sub i64 %274, 0
  %276 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %277 = select i1 %276, i64 %275, i64 0
  %private.contiguous.address75 = getelementptr i8, ptr %273, i64 %277
  %private.contiguous.load76 = load <8 x float>, ptr %private.contiguous.address75, align 4
  %278 = select <8 x i1> %51, <8 x float> %private.contiguous.load76, <8 x float> zeroinitializer
  %279 = fmul <8 x float> %278, %278
  %.state77 = load <8 x float>, ptr %.slot11, align 32
  %280 = fadd <8 x float> %.state77, %279
  %.state78 = load <8 x i64>, ptr %.slot7, align 64
  %281 = add <8 x i64> %.state78, splat (i64 4)
  %282 = load <8 x i64>, ptr %.slot7, align 64
  %283 = select <8 x i1> %51, <8 x i64> %281, <8 x i64> %282
  store <8 x i64> %283, ptr %.slot7, align 64
  %284 = load <8 x float>, ptr %.slot8, align 32
  %285 = select <8 x i1> %51, <8 x float> %229, <8 x float> %284
  store <8 x float> %285, ptr %.slot8, align 32
  %286 = load <8 x float>, ptr %.slot9, align 32
  %287 = select <8 x i1> %51, <8 x float> %246, <8 x float> %286
  store <8 x float> %287, ptr %.slot9, align 32
  %288 = load <8 x float>, ptr %.slot10, align 32
  %289 = select <8 x i1> %51, <8 x float> %263, <8 x float> %288
  store <8 x float> %289, ptr %.slot10, align 32
  %290 = load <8 x float>, ptr %.slot11, align 32
  %291 = select <8 x i1> %51, <8 x float> %280, <8 x float> %290
  store <8 x float> %291, ptr %.slot11, align 32
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false57
  %.spill.load79 = load <8 x i1>, ptr %.spill5, align 1
  %292 = and <8 x i1> %51, %.spill.load79
  %293 = xor <8 x i1> %.spill.load79, splat (i1 true)
  %294 = and <8 x i1> %51, %293
  %295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %292)
  %296 = bitcast <8 x i1> %292 to i8
  %297 = call i8 @llvm.cttz.i8(i8 %296, i1 false)
  %298 = zext i8 %297 to i32
  %299 = select i1 %295, i32 %298, i32 0
  %tile_snapshot.spill.load80 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load80, 1
  %302 = add <8 x i64> %301, splat (i64 256)
  %303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %300, 0
  %304 = insertvalue { <8 x ptr>, <8 x i64> } %303, <8 x i64> %302, 1
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %304, 1
  %307 = extractelement <8 x ptr> %305, i32 0
  %308 = extractelement <8 x i64> %306, i32 %299
  %309 = zext i32 %299 to i64
  %310 = mul i64 %309, 4
  %311 = sub i64 %308, %310
  %312 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %292)
  %313 = select i1 %312, i64 %311, i64 0
  %private.contiguous.address81 = getelementptr i8, ptr %307, i64 %313
  %private.contiguous.load82 = load <8 x float>, ptr %private.contiguous.address81, align 4
  %314 = select <8 x i1> %292, <8 x float> %private.contiguous.load82, <8 x float> zeroinitializer
  %315 = fmul <8 x float> %314, %314
  %.state83 = load <8 x float>, ptr %.slot8, align 32
  %316 = fadd <8 x float> %.state83, %315
  %317 = load <8 x float>, ptr %.slot12, align 32
  %318 = select <8 x i1> %292, <8 x float> %316, <8 x float> %317
  store <8 x float> %318, ptr %.slot12, align 32
  %319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %294)
  %320 = bitcast <8 x i1> %294 to i8
  %321 = call i8 @llvm.cttz.i8(i8 %320, i1 false)
  %322 = zext i8 %321 to i32
  %323 = select i1 %319, i32 %322, i32 0
  %.state84 = load <8 x float>, ptr %.slot8, align 32
  %324 = load <8 x float>, ptr %.slot12, align 32
  %325 = select <8 x i1> %294, <8 x float> %.state84, <8 x float> %324
  store <8 x float> %325, ptr %.slot12, align 32
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.state85 = load <8 x float>, ptr %.slot12, align 32
  %.state86 = load <8 x float>, ptr %.slot9, align 32
  %326 = fadd <8 x float> %.state85, %.state86
  %.state87 = load <8 x float>, ptr %.slot10, align 32
  %327 = fadd <8 x float> %326, %.state87
  %.state88 = load <8 x float>, ptr %.slot11, align 32
  %328 = fadd <8 x float> %327, %.state88
  %.spill.load89 = load <8 x i64>, ptr %.spill, align 64
  %329 = trunc <8 x i64> %.spill.load89 to <8 x i32>
  %330 = xor <8 x i32> %329, splat (i32 1)
  %331 = extractelement <8 x i32> %330, i64 0
  %332 = icmp ult i32 %331, 8
  %333 = select i1 %332, i32 %331, i32 0
  %334 = extractelement <8 x i1> %51, i32 %333
  %335 = extractelement <8 x i1> %51, i64 0
  %336 = and i1 %332, %334
  %337 = and i1 %335, %336
  %338 = extractelement <8 x float> %328, i32 %333
  %339 = select i1 %337, float %338, float 0.000000e+00
  %340 = insertelement <8 x float> poison, float %339, i64 0
  %341 = xor i1 %337, true
  %342 = and i1 %335, %341
  %343 = insertelement <8 x i1> poison, i1 %342, i64 0
  %344 = extractelement <8 x i32> %330, i64 1
  %345 = icmp ult i32 %344, 8
  %346 = select i1 %345, i32 %344, i32 0
  %347 = extractelement <8 x i1> %51, i32 %346
  %348 = extractelement <8 x i1> %51, i64 1
  %349 = and i1 %345, %347
  %350 = and i1 %348, %349
  %351 = extractelement <8 x float> %328, i32 %346
  %352 = select i1 %350, float %351, float 0.000000e+00
  %353 = insertelement <8 x float> %340, float %352, i64 1
  %354 = xor i1 %350, true
  %355 = and i1 %348, %354
  %356 = insertelement <8 x i1> %343, i1 %355, i64 1
  %357 = extractelement <8 x i32> %330, i64 2
  %358 = icmp ult i32 %357, 8
  %359 = select i1 %358, i32 %357, i32 0
  %360 = extractelement <8 x i1> %51, i32 %359
  %361 = extractelement <8 x i1> %51, i64 2
  %362 = and i1 %358, %360
  %363 = and i1 %361, %362
  %364 = extractelement <8 x float> %328, i32 %359
  %365 = select i1 %363, float %364, float 0.000000e+00
  %366 = insertelement <8 x float> %353, float %365, i64 2
  %367 = xor i1 %363, true
  %368 = and i1 %361, %367
  %369 = insertelement <8 x i1> %356, i1 %368, i64 2
  %370 = extractelement <8 x i32> %330, i64 3
  %371 = icmp ult i32 %370, 8
  %372 = select i1 %371, i32 %370, i32 0
  %373 = extractelement <8 x i1> %51, i32 %372
  %374 = extractelement <8 x i1> %51, i64 3
  %375 = and i1 %371, %373
  %376 = and i1 %374, %375
  %377 = extractelement <8 x float> %328, i32 %372
  %378 = select i1 %376, float %377, float 0.000000e+00
  %379 = insertelement <8 x float> %366, float %378, i64 3
  %380 = xor i1 %376, true
  %381 = and i1 %374, %380
  %382 = insertelement <8 x i1> %369, i1 %381, i64 3
  %383 = extractelement <8 x i32> %330, i64 4
  %384 = icmp ult i32 %383, 8
  %385 = select i1 %384, i32 %383, i32 0
  %386 = extractelement <8 x i1> %51, i32 %385
  %387 = extractelement <8 x i1> %51, i64 4
  %388 = and i1 %384, %386
  %389 = and i1 %387, %388
  %390 = extractelement <8 x float> %328, i32 %385
  %391 = select i1 %389, float %390, float 0.000000e+00
  %392 = insertelement <8 x float> %379, float %391, i64 4
  %393 = xor i1 %389, true
  %394 = and i1 %387, %393
  %395 = insertelement <8 x i1> %382, i1 %394, i64 4
  %396 = extractelement <8 x i32> %330, i64 5
  %397 = icmp ult i32 %396, 8
  %398 = select i1 %397, i32 %396, i32 0
  %399 = extractelement <8 x i1> %51, i32 %398
  %400 = extractelement <8 x i1> %51, i64 5
  %401 = and i1 %397, %399
  %402 = and i1 %400, %401
  %403 = extractelement <8 x float> %328, i32 %398
  %404 = select i1 %402, float %403, float 0.000000e+00
  %405 = insertelement <8 x float> %392, float %404, i64 5
  %406 = xor i1 %402, true
  %407 = and i1 %400, %406
  %408 = insertelement <8 x i1> %395, i1 %407, i64 5
  %409 = extractelement <8 x i32> %330, i64 6
  %410 = icmp ult i32 %409, 8
  %411 = select i1 %410, i32 %409, i32 0
  %412 = extractelement <8 x i1> %51, i32 %411
  %413 = extractelement <8 x i1> %51, i64 6
  %414 = and i1 %410, %412
  %415 = and i1 %413, %414
  %416 = extractelement <8 x float> %328, i32 %411
  %417 = select i1 %415, float %416, float 0.000000e+00
  %418 = insertelement <8 x float> %405, float %417, i64 6
  %419 = xor i1 %415, true
  %420 = and i1 %413, %419
  %421 = insertelement <8 x i1> %408, i1 %420, i64 6
  %422 = extractelement <8 x i32> %330, i64 7
  %423 = icmp ult i32 %422, 8
  %424 = select i1 %423, i32 %422, i32 0
  %425 = extractelement <8 x i1> %51, i32 %424
  %426 = extractelement <8 x i1> %51, i64 7
  %427 = and i1 %423, %425
  %428 = and i1 %426, %427
  %429 = extractelement <8 x float> %328, i32 %424
  %430 = select i1 %428, float %429, float 0.000000e+00
  %431 = insertelement <8 x float> %418, float %430, i64 7
  %432 = xor i1 %428, true
  %433 = and i1 %426, %432
  %434 = insertelement <8 x i1> %421, i1 %433, i64 7
  %435 = fadd <8 x float> %328, %431
  %436 = xor <8 x i32> %329, splat (i32 2)
  %437 = extractelement <8 x i32> %436, i64 0
  %438 = icmp ult i32 %437, 8
  %439 = select i1 %438, i32 %437, i32 0
  %440 = extractelement <8 x i1> %51, i32 %439
  %441 = extractelement <8 x i1> %51, i64 0
  %442 = and i1 %438, %440
  %443 = and i1 %441, %442
  %444 = extractelement <8 x float> %435, i32 %439
  %445 = select i1 %443, float %444, float 0.000000e+00
  %446 = insertelement <8 x float> poison, float %445, i64 0
  %447 = xor i1 %443, true
  %448 = and i1 %441, %447
  %449 = insertelement <8 x i1> poison, i1 %448, i64 0
  %450 = extractelement <8 x i32> %436, i64 1
  %451 = icmp ult i32 %450, 8
  %452 = select i1 %451, i32 %450, i32 0
  %453 = extractelement <8 x i1> %51, i32 %452
  %454 = extractelement <8 x i1> %51, i64 1
  %455 = and i1 %451, %453
  %456 = and i1 %454, %455
  %457 = extractelement <8 x float> %435, i32 %452
  %458 = select i1 %456, float %457, float 0.000000e+00
  %459 = insertelement <8 x float> %446, float %458, i64 1
  %460 = xor i1 %456, true
  %461 = and i1 %454, %460
  %462 = insertelement <8 x i1> %449, i1 %461, i64 1
  %463 = extractelement <8 x i32> %436, i64 2
  %464 = icmp ult i32 %463, 8
  %465 = select i1 %464, i32 %463, i32 0
  %466 = extractelement <8 x i1> %51, i32 %465
  %467 = extractelement <8 x i1> %51, i64 2
  %468 = and i1 %464, %466
  %469 = and i1 %467, %468
  %470 = extractelement <8 x float> %435, i32 %465
  %471 = select i1 %469, float %470, float 0.000000e+00
  %472 = insertelement <8 x float> %459, float %471, i64 2
  %473 = xor i1 %469, true
  %474 = and i1 %467, %473
  %475 = insertelement <8 x i1> %462, i1 %474, i64 2
  %476 = extractelement <8 x i32> %436, i64 3
  %477 = icmp ult i32 %476, 8
  %478 = select i1 %477, i32 %476, i32 0
  %479 = extractelement <8 x i1> %51, i32 %478
  %480 = extractelement <8 x i1> %51, i64 3
  %481 = and i1 %477, %479
  %482 = and i1 %480, %481
  %483 = extractelement <8 x float> %435, i32 %478
  %484 = select i1 %482, float %483, float 0.000000e+00
  %485 = insertelement <8 x float> %472, float %484, i64 3
  %486 = xor i1 %482, true
  %487 = and i1 %480, %486
  %488 = insertelement <8 x i1> %475, i1 %487, i64 3
  %489 = extractelement <8 x i32> %436, i64 4
  %490 = icmp ult i32 %489, 8
  %491 = select i1 %490, i32 %489, i32 0
  %492 = extractelement <8 x i1> %51, i32 %491
  %493 = extractelement <8 x i1> %51, i64 4
  %494 = and i1 %490, %492
  %495 = and i1 %493, %494
  %496 = extractelement <8 x float> %435, i32 %491
  %497 = select i1 %495, float %496, float 0.000000e+00
  %498 = insertelement <8 x float> %485, float %497, i64 4
  %499 = xor i1 %495, true
  %500 = and i1 %493, %499
  %501 = insertelement <8 x i1> %488, i1 %500, i64 4
  %502 = extractelement <8 x i32> %436, i64 5
  %503 = icmp ult i32 %502, 8
  %504 = select i1 %503, i32 %502, i32 0
  %505 = extractelement <8 x i1> %51, i32 %504
  %506 = extractelement <8 x i1> %51, i64 5
  %507 = and i1 %503, %505
  %508 = and i1 %506, %507
  %509 = extractelement <8 x float> %435, i32 %504
  %510 = select i1 %508, float %509, float 0.000000e+00
  %511 = insertelement <8 x float> %498, float %510, i64 5
  %512 = xor i1 %508, true
  %513 = and i1 %506, %512
  %514 = insertelement <8 x i1> %501, i1 %513, i64 5
  %515 = extractelement <8 x i32> %436, i64 6
  %516 = icmp ult i32 %515, 8
  %517 = select i1 %516, i32 %515, i32 0
  %518 = extractelement <8 x i1> %51, i32 %517
  %519 = extractelement <8 x i1> %51, i64 6
  %520 = and i1 %516, %518
  %521 = and i1 %519, %520
  %522 = extractelement <8 x float> %435, i32 %517
  %523 = select i1 %521, float %522, float 0.000000e+00
  %524 = insertelement <8 x float> %511, float %523, i64 6
  %525 = xor i1 %521, true
  %526 = and i1 %519, %525
  %527 = insertelement <8 x i1> %514, i1 %526, i64 6
  %528 = extractelement <8 x i32> %436, i64 7
  %529 = icmp ult i32 %528, 8
  %530 = select i1 %529, i32 %528, i32 0
  %531 = extractelement <8 x i1> %51, i32 %530
  %532 = extractelement <8 x i1> %51, i64 7
  %533 = and i1 %529, %531
  %534 = and i1 %532, %533
  %535 = extractelement <8 x float> %435, i32 %530
  %536 = select i1 %534, float %535, float 0.000000e+00
  %537 = insertelement <8 x float> %524, float %536, i64 7
  %538 = xor i1 %534, true
  %539 = and i1 %532, %538
  %540 = insertelement <8 x i1> %527, i1 %539, i64 7
  %541 = fadd <8 x float> %435, %537
  %542 = xor <8 x i32> %329, splat (i32 4)
  %543 = extractelement <8 x i32> %542, i64 0
  %544 = icmp ult i32 %543, 8
  %545 = select i1 %544, i32 %543, i32 0
  %546 = extractelement <8 x i1> %51, i32 %545
  %547 = extractelement <8 x i1> %51, i64 0
  %548 = and i1 %544, %546
  %549 = and i1 %547, %548
  %550 = extractelement <8 x float> %541, i32 %545
  %551 = select i1 %549, float %550, float 0.000000e+00
  %552 = insertelement <8 x float> poison, float %551, i64 0
  %553 = xor i1 %549, true
  %554 = and i1 %547, %553
  %555 = insertelement <8 x i1> poison, i1 %554, i64 0
  %556 = extractelement <8 x i32> %542, i64 1
  %557 = icmp ult i32 %556, 8
  %558 = select i1 %557, i32 %556, i32 0
  %559 = extractelement <8 x i1> %51, i32 %558
  %560 = extractelement <8 x i1> %51, i64 1
  %561 = and i1 %557, %559
  %562 = and i1 %560, %561
  %563 = extractelement <8 x float> %541, i32 %558
  %564 = select i1 %562, float %563, float 0.000000e+00
  %565 = insertelement <8 x float> %552, float %564, i64 1
  %566 = xor i1 %562, true
  %567 = and i1 %560, %566
  %568 = insertelement <8 x i1> %555, i1 %567, i64 1
  %569 = extractelement <8 x i32> %542, i64 2
  %570 = icmp ult i32 %569, 8
  %571 = select i1 %570, i32 %569, i32 0
  %572 = extractelement <8 x i1> %51, i32 %571
  %573 = extractelement <8 x i1> %51, i64 2
  %574 = and i1 %570, %572
  %575 = and i1 %573, %574
  %576 = extractelement <8 x float> %541, i32 %571
  %577 = select i1 %575, float %576, float 0.000000e+00
  %578 = insertelement <8 x float> %565, float %577, i64 2
  %579 = xor i1 %575, true
  %580 = and i1 %573, %579
  %581 = insertelement <8 x i1> %568, i1 %580, i64 2
  %582 = extractelement <8 x i32> %542, i64 3
  %583 = icmp ult i32 %582, 8
  %584 = select i1 %583, i32 %582, i32 0
  %585 = extractelement <8 x i1> %51, i32 %584
  %586 = extractelement <8 x i1> %51, i64 3
  %587 = and i1 %583, %585
  %588 = and i1 %586, %587
  %589 = extractelement <8 x float> %541, i32 %584
  %590 = select i1 %588, float %589, float 0.000000e+00
  %591 = insertelement <8 x float> %578, float %590, i64 3
  %592 = xor i1 %588, true
  %593 = and i1 %586, %592
  %594 = insertelement <8 x i1> %581, i1 %593, i64 3
  %595 = extractelement <8 x i32> %542, i64 4
  %596 = icmp ult i32 %595, 8
  %597 = select i1 %596, i32 %595, i32 0
  %598 = extractelement <8 x i1> %51, i32 %597
  %599 = extractelement <8 x i1> %51, i64 4
  %600 = and i1 %596, %598
  %601 = and i1 %599, %600
  %602 = extractelement <8 x float> %541, i32 %597
  %603 = select i1 %601, float %602, float 0.000000e+00
  %604 = insertelement <8 x float> %591, float %603, i64 4
  %605 = xor i1 %601, true
  %606 = and i1 %599, %605
  %607 = insertelement <8 x i1> %594, i1 %606, i64 4
  %608 = extractelement <8 x i32> %542, i64 5
  %609 = icmp ult i32 %608, 8
  %610 = select i1 %609, i32 %608, i32 0
  %611 = extractelement <8 x i1> %51, i32 %610
  %612 = extractelement <8 x i1> %51, i64 5
  %613 = and i1 %609, %611
  %614 = and i1 %612, %613
  %615 = extractelement <8 x float> %541, i32 %610
  %616 = select i1 %614, float %615, float 0.000000e+00
  %617 = insertelement <8 x float> %604, float %616, i64 5
  %618 = xor i1 %614, true
  %619 = and i1 %612, %618
  %620 = insertelement <8 x i1> %607, i1 %619, i64 5
  %621 = extractelement <8 x i32> %542, i64 6
  %622 = icmp ult i32 %621, 8
  %623 = select i1 %622, i32 %621, i32 0
  %624 = extractelement <8 x i1> %51, i32 %623
  %625 = extractelement <8 x i1> %51, i64 6
  %626 = and i1 %622, %624
  %627 = and i1 %625, %626
  %628 = extractelement <8 x float> %541, i32 %623
  %629 = select i1 %627, float %628, float 0.000000e+00
  %630 = insertelement <8 x float> %617, float %629, i64 6
  %631 = xor i1 %627, true
  %632 = and i1 %625, %631
  %633 = insertelement <8 x i1> %620, i1 %632, i64 6
  %634 = extractelement <8 x i32> %542, i64 7
  %635 = icmp ult i32 %634, 8
  %636 = select i1 %635, i32 %634, i32 0
  %637 = extractelement <8 x i1> %51, i32 %636
  %638 = extractelement <8 x i1> %51, i64 7
  %639 = and i1 %635, %637
  %640 = and i1 %638, %639
  %641 = extractelement <8 x float> %541, i32 %636
  %642 = select i1 %640, float %641, float 0.000000e+00
  %643 = insertelement <8 x float> %630, float %642, i64 7
  %644 = xor i1 %640, true
  %645 = and i1 %638, %644
  %646 = insertelement <8 x i1> %633, i1 %645, i64 7
  %647 = fadd <8 x float> %541, %643
  %648 = extractelement <8 x i1> %51, i32 0
  %649 = extractelement <8 x i1> %51, i64 0
  %650 = and i1 true, %648
  %651 = and i1 %649, %650
  %652 = extractelement <8 x float> %647, i32 0
  %653 = select i1 %651, float %652, float 0.000000e+00
  %654 = insertelement <8 x float> poison, float %653, i64 0
  %655 = xor i1 %651, true
  %656 = and i1 %649, %655
  %657 = insertelement <8 x i1> poison, i1 %656, i64 0
  %658 = extractelement <8 x i1> %51, i32 0
  %659 = extractelement <8 x i1> %51, i64 1
  %660 = and i1 true, %658
  %661 = and i1 %659, %660
  %662 = extractelement <8 x float> %647, i32 0
  %663 = select i1 %661, float %662, float 0.000000e+00
  %664 = insertelement <8 x float> %654, float %663, i64 1
  %665 = xor i1 %661, true
  %666 = and i1 %659, %665
  %667 = insertelement <8 x i1> %657, i1 %666, i64 1
  %668 = extractelement <8 x i1> %51, i32 0
  %669 = extractelement <8 x i1> %51, i64 2
  %670 = and i1 true, %668
  %671 = and i1 %669, %670
  %672 = extractelement <8 x float> %647, i32 0
  %673 = select i1 %671, float %672, float 0.000000e+00
  %674 = insertelement <8 x float> %664, float %673, i64 2
  %675 = xor i1 %671, true
  %676 = and i1 %669, %675
  %677 = insertelement <8 x i1> %667, i1 %676, i64 2
  %678 = extractelement <8 x i1> %51, i32 0
  %679 = extractelement <8 x i1> %51, i64 3
  %680 = and i1 true, %678
  %681 = and i1 %679, %680
  %682 = extractelement <8 x float> %647, i32 0
  %683 = select i1 %681, float %682, float 0.000000e+00
  %684 = insertelement <8 x float> %674, float %683, i64 3
  %685 = xor i1 %681, true
  %686 = and i1 %679, %685
  %687 = insertelement <8 x i1> %677, i1 %686, i64 3
  %688 = extractelement <8 x i1> %51, i32 0
  %689 = extractelement <8 x i1> %51, i64 4
  %690 = and i1 true, %688
  %691 = and i1 %689, %690
  %692 = extractelement <8 x float> %647, i32 0
  %693 = select i1 %691, float %692, float 0.000000e+00
  %694 = insertelement <8 x float> %684, float %693, i64 4
  %695 = xor i1 %691, true
  %696 = and i1 %689, %695
  %697 = insertelement <8 x i1> %687, i1 %696, i64 4
  %698 = extractelement <8 x i1> %51, i32 0
  %699 = extractelement <8 x i1> %51, i64 5
  %700 = and i1 true, %698
  %701 = and i1 %699, %700
  %702 = extractelement <8 x float> %647, i32 0
  %703 = select i1 %701, float %702, float 0.000000e+00
  %704 = insertelement <8 x float> %694, float %703, i64 5
  %705 = xor i1 %701, true
  %706 = and i1 %699, %705
  %707 = insertelement <8 x i1> %697, i1 %706, i64 5
  %708 = extractelement <8 x i1> %51, i32 0
  %709 = extractelement <8 x i1> %51, i64 6
  %710 = and i1 true, %708
  %711 = and i1 %709, %710
  %712 = extractelement <8 x float> %647, i32 0
  %713 = select i1 %711, float %712, float 0.000000e+00
  %714 = insertelement <8 x float> %704, float %713, i64 6
  %715 = xor i1 %711, true
  %716 = and i1 %709, %715
  %717 = insertelement <8 x i1> %707, i1 %716, i64 6
  %718 = extractelement <8 x i1> %51, i32 0
  %719 = extractelement <8 x i1> %51, i64 7
  %720 = and i1 true, %718
  %721 = and i1 %719, %720
  %722 = extractelement <8 x float> %647, i32 0
  %723 = select i1 %721, float %722, float 0.000000e+00
  %724 = insertelement <8 x float> %714, float %723, i64 7
  %725 = xor i1 %721, true
  %726 = and i1 %719, %725
  %727 = insertelement <8 x i1> %717, i1 %726, i64 7
  %728 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %729 = bitcast <8 x i1> %51 to i8
  %730 = call i8 @llvm.cttz.i8(i8 %729, i1 false)
  %731 = zext i8 %730 to i32
  %732 = select i1 %728, i32 %731, i32 0
  %733 = extractelement <8 x float> %724, i32 %732
  %734 = fadd float 0.000000e+00, %733
  %735 = fdiv float %734, 6.500000e+01
  store float %735, ptr %.spill13, align 4
  %736 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %737 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %738 = extractvalue { <8 x ptr>, <8 x i64> } %736, 0
  %739 = select <8 x i1> %51, <8 x ptr> %737, <8 x ptr> %738
  %740 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %741 = extractvalue { <8 x ptr>, <8 x i64> } %736, 1
  %742 = select <8 x i1> %51, <8 x i64> %740, <8 x i64> %741
  %743 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %739, 0
  %744 = insertvalue { <8 x ptr>, <8 x i64> } %743, <8 x i64> %742, 1
  store { <8 x ptr>, <8 x i64> } %744, ptr %tile_snapshot.spill14, align 64
  %745 = load <8 x i64>, ptr %.slot15, align 64
  %746 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %745
  store <8 x i64> %746, ptr %.slot15, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state90 = load <8 x i64>, ptr %.slot15, align 64
  %747 = icmp slt <8 x i64> %.state90, splat (i64 8)
  %748 = extractelement <8 x i1> %747, i32 0
  br i1 %748, label %direct.true91, label %direct.false92

direct.schedule.12:                               ; preds = %direct.true91
  %.state93 = load <8 x i64>, ptr %.slot15, align 64
  %749 = mul <8 x i64> %.state93, splat (i64 8)
  %.spill.load94 = load <8 x i64>, ptr %.spill, align 64
  %750 = add <8 x i64> %749, %.spill.load94
  %.spill.load95 = load i64, ptr %.spill6, align 4
  %751 = add i64 %.spill.load95, 0
  %752 = add <8 x i64> zeroinitializer, %750
  %753 = mul i64 %751, 65
  %.splatinsert96 = insertelement <8 x i64> poison, i64 %753, i64 0
  %.splat97 = shufflevector <8 x i64> %.splatinsert96, <8 x i64> poison, <8 x i32> zeroinitializer
  %754 = add <8 x i64> %.splat97, %752
  %755 = extractvalue { ptr, i64 } %15, 0
  %756 = extractelement <8 x i64> %754, i32 0
  %757 = sub i64 %756, 0
  %758 = mul i64 %757, 4
  %buffer.contiguous.address98 = getelementptr i8, ptr %755, i64 %758
  %buffer.contiguous.load99 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address98, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 0
  %760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load100, 1
  %.state101 = load <8 x i64>, ptr %.slot15, align 64
  %761 = mul <8 x i64> %.state101, splat (i64 32)
  %762 = add <8 x i64> %760, %761
  %763 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %759, 0
  %764 = insertvalue { <8 x ptr>, <8 x i64> } %763, <8 x i64> %762, 1
  %765 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %766 = extractvalue { <8 x ptr>, <8 x i64> } %764, 1
  %767 = extractelement <8 x ptr> %765, i32 0
  %768 = extractelement <8 x i64> %766, i32 0
  %769 = sub i64 %768, 0
  %770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %771 = select i1 %770, i64 %769, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %767, i64 %771
  %private.contiguous.preserve103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %772 = select <8 x i1> %51, <8 x float> %buffer.contiguous.load99, <8 x float> %private.contiguous.preserve103
  store <8 x float> %772, ptr %private.contiguous.address102, align 4
  %.state104 = load <8 x i64>, ptr %.slot15, align 64
  %773 = add <8 x i64> %.state104, splat (i64 1)
  %774 = load <8 x i64>, ptr %.slot15, align 64
  %775 = select <8 x i1> %51, <8 x i64> %773, <8 x i64> %774
  store <8 x i64> %775, ptr %.slot15, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false92
  %.spill.load105 = load <8 x i1>, ptr %.spill5, align 1
  %776 = and <8 x i1> %51, %.spill.load105
  %777 = xor <8 x i1> %.spill.load105, splat (i1 true)
  %778 = and <8 x i1> %51, %777
  %779 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %776)
  %780 = bitcast <8 x i1> %776 to i8
  %781 = call i8 @llvm.cttz.i8(i8 %780, i1 false)
  %782 = zext i8 %781 to i32
  %783 = select i1 %779, i32 %782, i32 0
  %.spill.load106 = load <8 x i64>, ptr %.spill, align 64
  %784 = add <8 x i64> splat (i64 64), %.spill.load106
  %.spill.load107 = load i64, ptr %.spill6, align 4
  %785 = add i64 %.spill.load107, 0
  %786 = add <8 x i64> zeroinitializer, %784
  %787 = mul i64 %785, 65
  %.splatinsert108 = insertelement <8 x i64> poison, i64 %787, i64 0
  %.splat109 = shufflevector <8 x i64> %.splatinsert108, <8 x i64> poison, <8 x i32> zeroinitializer
  %788 = add <8 x i64> %.splat109, %786
  %789 = extractvalue { ptr, i64 } %15, 0
  %790 = select <8 x i1> %776, <8 x i64> %788, <8 x i64> zeroinitializer
  %791 = extractelement <8 x i64> %790, i32 %783
  %792 = zext i32 %783 to i64
  %793 = sub i64 %791, %792
  %794 = mul i64 %793, 4
  %buffer.contiguous.address110 = getelementptr i8, ptr %789, i64 %794
  %buffer.contiguous.load111 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address110, <8 x i1> %776, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load112 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %795 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 0
  %796 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load112, 1
  %797 = add <8 x i64> %796, splat (i64 256)
  %798 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %795, 0
  %799 = insertvalue { <8 x ptr>, <8 x i64> } %798, <8 x i64> %797, 1
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %799, 1
  %802 = extractelement <8 x ptr> %800, i32 0
  %803 = extractelement <8 x i64> %801, i32 %783
  %804 = zext i32 %783 to i64
  %805 = mul i64 %804, 4
  %806 = sub i64 %803, %805
  %807 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %776)
  %808 = select i1 %807, i64 %806, i64 0
  %private.contiguous.address113 = getelementptr i8, ptr %802, i64 %808
  %private.contiguous.preserve114 = load <8 x float>, ptr %private.contiguous.address113, align 4
  %809 = select <8 x i1> %776, <8 x float> %buffer.contiguous.load111, <8 x float> %private.contiguous.preserve114
  store <8 x float> %809, ptr %private.contiguous.address113, align 4
  %810 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %778)
  %811 = bitcast <8 x i1> %778 to i8
  %812 = call i8 @llvm.cttz.i8(i8 %811, i1 false)
  %813 = zext i8 %812 to i32
  %814 = select i1 %810, i32 %813, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %.spill.load115 = load float, ptr %.spill13, align 4
  %815 = fadd float %.spill.load115, 0x3EE4F8B580000000
  %816 = call float @llvm.sqrt.f32(float %815)
  store float %816, ptr %.spill16, align 4
  %817 = load <8 x i64>, ptr %.slot17, align 64
  %818 = select <8 x i1> %51, <8 x i64> zeroinitializer, <8 x i64> %817
  store <8 x i64> %818, ptr %.slot17, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state116 = load <8 x i64>, ptr %.slot17, align 64
  %819 = icmp slt <8 x i64> %.state116, splat (i64 8)
  %820 = extractelement <8 x i1> %819, i32 0
  br i1 %820, label %direct.true117, label %direct.false118

direct.schedule.17:                               ; preds = %direct.true117
  %.state119 = load <8 x i64>, ptr %.slot17, align 64
  %821 = mul <8 x i64> %.state119, splat (i64 8)
  %.spill.load120 = load <8 x i64>, ptr %.spill, align 64
  %822 = add <8 x i64> %821, %.spill.load120
  %.spill.load121 = load <8 x i64>, ptr %.spill4, align 64
  %823 = add <8 x i64> %.spill.load121, zeroinitializer
  %824 = add <8 x i64> zeroinitializer, %823
  %825 = add <8 x i64> zeroinitializer, %822
  %826 = mul <8 x i64> %824, splat (i64 65)
  %827 = add <8 x i64> %826, %825
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %829 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %.state123 = load <8 x i64>, ptr %.slot17, align 64
  %830 = mul <8 x i64> %.state123, splat (i64 32)
  %831 = add <8 x i64> %829, %830
  %832 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %828, 0
  %833 = insertvalue { <8 x ptr>, <8 x i64> } %832, <8 x i64> %831, 1
  %834 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %833, 1
  %836 = extractelement <8 x ptr> %834, i32 0
  %837 = extractelement <8 x i64> %835, i32 0
  %838 = sub i64 %837, 0
  %839 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %840 = select i1 %839, i64 %838, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %836, i64 %840
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %841 = select <8 x i1> %51, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %.spill.load126 = load float, ptr %.spill16, align 4
  %.splatinsert127 = insertelement <8 x float> poison, float %.spill.load126, i64 0
  %.splat128 = shufflevector <8 x float> %.splatinsert127, <8 x float> poison, <8 x i32> zeroinitializer
  %842 = fdiv <8 x float> %841, %.splat128
  %tile_snapshot.spill.load129 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 0
  %844 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load129, 1
  %.state130 = load <8 x i64>, ptr %.slot17, align 64
  %845 = mul <8 x i64> %.state130, splat (i64 32)
  %846 = add <8 x i64> %844, %845
  %847 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %843, 0
  %848 = insertvalue { <8 x ptr>, <8 x i64> } %847, <8 x i64> %846, 1
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %850 = extractvalue { <8 x ptr>, <8 x i64> } %848, 1
  %851 = extractelement <8 x ptr> %849, i32 0
  %852 = extractelement <8 x i64> %850, i32 0
  %853 = sub i64 %852, 0
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %855 = select i1 %854, i64 %853, i64 0
  %private.contiguous.address131 = getelementptr i8, ptr %851, i64 %855
  %private.contiguous.load132 = load <8 x float>, ptr %private.contiguous.address131, align 4
  %856 = select <8 x i1> %51, <8 x float> %private.contiguous.load132, <8 x float> zeroinitializer
  %857 = fmul <8 x float> %842, %856
  %858 = extractvalue { ptr, i64 } %27, 0
  %859 = extractelement <8 x i64> %827, i32 0
  %860 = sub i64 %859, 0
  %861 = mul i64 %860, 4
  %buffer.contiguous.address133 = getelementptr i8, ptr %858, i64 %861
  call void @llvm.masked.store.v8f32.p0(<8 x float> %857, ptr align 1 %buffer.contiguous.address133, <8 x i1> %51)
  %.state134 = load <8 x i64>, ptr %.slot17, align 64
  %862 = add <8 x i64> %.state134, splat (i64 1)
  %863 = load <8 x i64>, ptr %.slot17, align 64
  %864 = select <8 x i1> %51, <8 x i64> %862, <8 x i64> %863
  store <8 x i64> %864, ptr %.slot17, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false118
  %.spill.load135 = load <8 x i1>, ptr %.spill5, align 1
  %865 = and <8 x i1> %51, %.spill.load135
  %866 = xor <8 x i1> %.spill.load135, splat (i1 true)
  %867 = and <8 x i1> %51, %866
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %865)
  %869 = bitcast <8 x i1> %865 to i8
  %870 = call i8 @llvm.cttz.i8(i8 %869, i1 false)
  %871 = zext i8 %870 to i32
  %872 = select i1 %868, i32 %871, i32 0
  %.spill.load136 = load <8 x i64>, ptr %.spill, align 64
  %873 = add <8 x i64> splat (i64 64), %.spill.load136
  %.spill.load137 = load <8 x i64>, ptr %.spill4, align 64
  %874 = add <8 x i64> %.spill.load137, zeroinitializer
  %875 = add <8 x i64> zeroinitializer, %874
  %876 = add <8 x i64> zeroinitializer, %873
  %877 = mul <8 x i64> %875, splat (i64 65)
  %878 = add <8 x i64> %877, %876
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %879 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %880 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %881 = add <8 x i64> %880, splat (i64 256)
  %882 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %879, 0
  %883 = insertvalue { <8 x ptr>, <8 x i64> } %882, <8 x i64> %881, 1
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %885 = extractvalue { <8 x ptr>, <8 x i64> } %883, 1
  %886 = extractelement <8 x ptr> %884, i32 0
  %887 = extractelement <8 x i64> %885, i32 %872
  %888 = zext i32 %872 to i64
  %889 = mul i64 %888, 4
  %890 = sub i64 %887, %889
  %891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %865)
  %892 = select i1 %891, i64 %890, i64 0
  %private.contiguous.address139 = getelementptr i8, ptr %886, i64 %892
  %private.contiguous.load140 = load <8 x float>, ptr %private.contiguous.address139, align 4
  %893 = select <8 x i1> %865, <8 x float> %private.contiguous.load140, <8 x float> zeroinitializer
  %.spill.load141 = load float, ptr %.spill16, align 4
  %.splatinsert142 = insertelement <8 x float> poison, float %.spill.load141, i64 0
  %.splat143 = shufflevector <8 x float> %.splatinsert142, <8 x float> poison, <8 x i32> zeroinitializer
  %894 = fdiv <8 x float> %893, %.splat143
  %tile_snapshot.spill.load144 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill14, align 64
  %895 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 0
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load144, 1
  %897 = add <8 x i64> %896, splat (i64 256)
  %898 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %895, 0
  %899 = insertvalue { <8 x ptr>, <8 x i64> } %898, <8 x i64> %897, 1
  %900 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %901 = extractvalue { <8 x ptr>, <8 x i64> } %899, 1
  %902 = extractelement <8 x ptr> %900, i32 0
  %903 = extractelement <8 x i64> %901, i32 %872
  %904 = zext i32 %872 to i64
  %905 = mul i64 %904, 4
  %906 = sub i64 %903, %905
  %907 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %865)
  %908 = select i1 %907, i64 %906, i64 0
  %private.contiguous.address145 = getelementptr i8, ptr %902, i64 %908
  %private.contiguous.load146 = load <8 x float>, ptr %private.contiguous.address145, align 4
  %909 = select <8 x i1> %865, <8 x float> %private.contiguous.load146, <8 x float> zeroinitializer
  %910 = fmul <8 x float> %894, %909
  %911 = extractvalue { ptr, i64 } %27, 0
  %912 = extractelement <8 x i64> %878, i32 %872
  %913 = zext i32 %872 to i64
  %914 = sub i64 %912, %913
  %915 = mul i64 %914, 4
  %buffer.contiguous.address147 = getelementptr i8, ptr %911, i64 %915
  call void @llvm.masked.store.v8f32.p0(<8 x float> %910, ptr align 1 %buffer.contiguous.address147, <8 x i1> %865)
  %916 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %867)
  %917 = bitcast <8 x i1> %867 to i8
  %918 = call i8 @llvm.cttz.i8(i8 %917, i1 false)
  %919 = zext i8 %918 to i32
  %920 = select i1 %916, i32 %919, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true56:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false57:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true91:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false92:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true117:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false118:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.sqrt.f32(float) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #3

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

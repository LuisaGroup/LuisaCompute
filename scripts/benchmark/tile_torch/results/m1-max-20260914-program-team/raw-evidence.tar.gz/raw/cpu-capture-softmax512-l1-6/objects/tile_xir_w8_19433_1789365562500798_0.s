	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	3072                            ; 0xc00
	.quad	3584                            ; 0xe00
lCPI0_4:
	.quad	1024                            ; 0x400
	.quad	1536                            ; 0x600
lCPI0_5:
	.quad	2048                            ; 0x800
	.quad	2560                            ; 0xa00
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	512                             ; 0x200
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v23, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q24, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q25, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v23, v25
	cmhi.4s	v1, v23, v24
	uzp1.8h	v6, v1, v0
	umaxv.8h	h2, v6
	fmov	w8, s2
	tbz	w8, #0, LBB0_98
; %bb.1:                                ; %direct.activate
	sub	sp, sp, #144
	stp	d15, d14, [sp, #80]             ; 16-byte Folded Spill
	stp	d13, d12, [sp, #96]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #112]            ; 16-byte Folded Spill
	stp	d9, d8, [sp, #128]              ; 16-byte Folded Spill
	mov	x13, #0                         ; =0x0
	ldr	x10, [x1, #136]
	add	x8, x10, #12, lsl #12           ; =49152
	dup.2d	v18, x8
	add	x12, x10, #4, lsl #12           ; =16384
	add	x11, x10, #13, lsl #12          ; =53248
	add	x8, x10, #17, lsl #12           ; =69632
	ldr	w9, [x1]
	ldr	w14, [x1, #36]
	add	w14, w14, w9, lsl #5
	ldr	x15, [x0]
	ldr	x9, [x0, #48]
	dup.4s	v2, w14
	add.4s	v3, v2, v25
	add.4s	v2, v2, v24
	and.16b	v5, v1, v2
	and.16b	v4, v0, v3
	ushll2.2d	v7, v4, #0
	ushll2.2d	v16, v5, #0
	ushll.2d	v19, v4, #0
	ushll.2d	v17, v5, #0
	ushll2.2d	v2, v4, #11
	ushll2.2d	v3, v5, #11
	ushll.2d	v4, v4, #11
	ushll.2d	v5, v5, #11
Lloh4:
	adrp	x14, lCPI0_2@PAGE
Lloh5:
	ldr	q20, [x14, lCPI0_2@PAGEOFF]
	and.16b	v6, v6, v20
	addv.8h	h6, v6
	fmov	w14, s6
	dup.2d	v20, x15
	mov	x15, x10
	b	LBB0_3
LBB0_2:                                 ; %else72
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q26, q27, [x15]
	bif.16b	v22, v27, v0
	bif.16b	v21, v26, v1
	stp	q21, q22, [x15], #32
	add	x13, x13, #4
	cmp	x13, #2048
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v26, x13
	add.2d	v21, v26, v5
	add.2d	v27, v20, v21
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w14, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w16, w14, #0xff
	tbnz	w16, #1, LBB0_12
LBB0_5:                                 ; %else54
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v27, v26, v3
	add.2d	v27, v20, v27
	tbnz	w16, #2, LBB0_13
LBB0_6:                                 ; %else57
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #3, LBB0_14
LBB0_7:                                 ; %else60
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v27, v26, v4
	add.2d	v27, v20, v27
	tbnz	w16, #4, LBB0_15
LBB0_8:                                 ; %else63
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #5, LBB0_16
LBB0_9:                                 ; %else66
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v26, v26, v2
	add.2d	v26, v20, v26
	tbnz	w16, #6, LBB0_17
LBB0_10:                                ; %else69
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w16, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x16, d27
	ldr	s21, [x16]
	and	w16, w14, #0xff
	tbz	w16, #1, LBB0_5
LBB0_12:                                ; %cond.load53
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x17, v27[1]
	ld1.s	{ v21 }[1], [x17]
	add.2d	v27, v26, v3
	add.2d	v27, v20, v27
	tbz	w16, #2, LBB0_6
LBB0_13:                                ; %cond.load56
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x17, d27
	ld1.s	{ v21 }[2], [x17]
	tbz	w16, #3, LBB0_7
LBB0_14:                                ; %cond.load59
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x17, v27[1]
	ld1.s	{ v21 }[3], [x17]
	add.2d	v27, v26, v4
	add.2d	v27, v20, v27
	tbz	w16, #4, LBB0_8
LBB0_15:                                ; %cond.load62
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x17, d27
	ld1.s	{ v22 }[0], [x17]
	tbz	w16, #5, LBB0_9
LBB0_16:                                ; %cond.load65
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x17, v27[1]
	ld1.s	{ v22 }[1], [x17]
	add.2d	v26, v26, v2
	add.2d	v26, v20, v26
	tbz	w16, #6, LBB0_10
LBB0_17:                                ; %cond.load68
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x17, d26
	ld1.s	{ v22 }[2], [x17]
	tbz	w16, #7, LBB0_2
LBB0_18:                                ; %cond.load71
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x16, v26[1]
	ld1.s	{ v22 }[3], [x16]
	b	LBB0_2
LBB0_19:                                ; %direct.true62.preheader
	stp	q4, q3, [sp, #16]               ; 32-byte Folded Spill
	mov	x13, #0                         ; =0x0
	sshll2.2d	v21, v0, #0
	sshll2.2d	v20, v1, #0
	sshll.2d	v22, v0, #0
	sshll.2d	v26, v1, #0
LBB0_20:                                ; %direct.true62
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v27, x13
	add	x14, x12, x13, lsl #6
	ldp	q29, q28, [x14, #32]
	ldp	q31, q30, [x14]
	bit.16b	v31, v27, v26
	bit.16b	v29, v27, v22
	bit.16b	v30, v27, v20
	bif.16b	v27, v28, v21
	stp	q29, q27, [x14, #32]
	stp	q31, q30, [x14]
	add	x13, x13, #1
	cmp	x13, #512
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false63
	mov	x13, #0                         ; =0x0
	sshll.2d	v22, v1, #0
	sshll.2d	v30, v0, #0
	mov	w14, #511                       ; =0x1ff
	dup.2d	v29, x14
	and.16b	v26, v19, v29
	and.16b	v27, v16, v29
	and.16b	v28, v17, v29
	and.16b	v29, v7, v29
	and.16b	v7, v21, v18
	and.16b	v16, v20, v18
	and.16b	v17, v30, v18
	and.16b	v18, v22, v18
Lloh6:
	adrp	x14, lCPI0_3@PAGE
Lloh7:
	ldr	q19, [x14, lCPI0_3@PAGEOFF]
	and.16b	v19, v21, v19
Lloh8:
	adrp	x14, lCPI0_4@PAGE
Lloh9:
	ldr	q21, [x14, lCPI0_4@PAGEOFF]
	and.16b	v20, v20, v21
Lloh10:
	adrp	x14, lCPI0_5@PAGE
Lloh11:
	ldr	q21, [x14, lCPI0_5@PAGEOFF]
	and.16b	v21, v30, v21
Lloh12:
	adrp	x14, lCPI0_6@PAGE
Lloh13:
	ldr	q30, [x14, lCPI0_6@PAGEOFF]
	and.16b	v22, v22, v30
	cmhs.4s	v25, v25, v23
	cmhs.4s	v23, v24, v23
	uzp1.8h	v23, v23, v25
	xtn.8b	v23, v23
	fmov	w14, s6
	movi.8b	v24, #1
	b	LBB0_23
LBB0_22:                                ; %else97
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x13, x13, #1
	cmp	x13, #512
	b.eq	LBB0_39
LBB0_23:                                ; %direct.true76
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v25, x13
	add	x15, x12, x13, lsl #6
	ldp	q31, q30, [x15, #32]
	ldp	q8, q9, [x15]
	cmge.2d	v9, v27, v9
	cmge.2d	v8, v28, v8
	uzp1.4s	v8, v8, v9
	cmge.2d	v31, v26, v31
	cmge.2d	v30, v29, v30
	uzp1.4s	v30, v31, v30
	uzp1.8h	v30, v8, v30
	xtn.8b	v30, v30
	orr.8b	v30, v23, v30
	orr.16b	v31, v25, v22
	add.2d	v31, v18, v31
	and.8b	v30, v30, v24
	tbnz	w14, #0, LBB0_31
; %bb.24:                               ; %else76
                                        ;   in Loop: Header=BB0_23 Depth=1
	and	w15, w14, #0xff
	tbnz	w15, #1, LBB0_32
LBB0_25:                                ; %else79
                                        ;   in Loop: Header=BB0_23 Depth=1
	orr.16b	v31, v25, v20
	add.2d	v31, v16, v31
	tbnz	w15, #2, LBB0_33
LBB0_26:                                ; %else82
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w15, #3, LBB0_34
LBB0_27:                                ; %else85
                                        ;   in Loop: Header=BB0_23 Depth=1
	orr.16b	v31, v25, v21
	add.2d	v31, v17, v31
	tbnz	w15, #4, LBB0_35
LBB0_28:                                ; %else88
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w15, #5, LBB0_36
LBB0_29:                                ; %else91
                                        ;   in Loop: Header=BB0_23 Depth=1
	orr.16b	v25, v25, v19
	add.2d	v25, v7, v25
	tbnz	w15, #6, LBB0_37
LBB0_30:                                ; %else94
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbz	w15, #7, LBB0_22
	b	LBB0_38
LBB0_31:                                ; %cond.store
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x15, d31
	str	b30, [x15]
	and	w15, w14, #0xff
	tbz	w15, #1, LBB0_25
LBB0_32:                                ; %cond.store77
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x16, v31[1]
	st1.b	{ v30 }[1], [x16]
	orr.16b	v31, v25, v20
	add.2d	v31, v16, v31
	tbz	w15, #2, LBB0_26
LBB0_33:                                ; %cond.store80
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x16, d31
	st1.b	{ v30 }[2], [x16]
	tbz	w15, #3, LBB0_27
LBB0_34:                                ; %cond.store83
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x16, v31[1]
	st1.b	{ v30 }[3], [x16]
	orr.16b	v31, v25, v21
	add.2d	v31, v17, v31
	tbz	w15, #4, LBB0_28
LBB0_35:                                ; %cond.store86
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x16, d31
	st1.b	{ v30 }[4], [x16]
	tbz	w15, #5, LBB0_29
LBB0_36:                                ; %cond.store89
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x16, v31[1]
	st1.b	{ v30 }[5], [x16]
	orr.16b	v25, v25, v19
	add.2d	v25, v7, v25
	tbz	w15, #6, LBB0_30
LBB0_37:                                ; %cond.store92
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x16, d25
	st1.b	{ v30 }[6], [x16]
	tbz	w15, #7, LBB0_22
LBB0_38:                                ; %cond.store95
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x15, v25[1]
	st1.b	{ v30 }[7], [x15]
	b	LBB0_22
LBB0_39:                                ; %direct.true90.preheader
	mov	x12, #0                         ; =0x0
	fmov	w13, s6
	mov	w14, #62154                     ; =0xf2ca
	movk	w14, #61769, lsl #16
	dup.4s	v23, w14
	b	LBB0_41
LBB0_40:                                ; %else145
                                        ;   in Loop: Header=BB0_41 Depth=1
	cmeq.8b	v24, v24, #0
	sshll.8h	v24, v24, #0
	sshll2.4s	v25, v24, #0
	sshll.4s	v24, v24, #0
	add	x14, x10, x12, lsl #5
	ldp	q26, q27, [x14]
	and.16b	v27, v0, v27
	and.16b	v26, v1, v26
	bsl.16b	v24, v23, v26
	bsl.16b	v25, v23, v27
	ldr	q26, [x14, #53248]
	ldr	q27, [x14, #53264]
	bif.16b	v25, v27, v0
	bif.16b	v24, v26, v1
	str	q24, [x14, #53248]
	str	q25, [x14, #53264]
	add	x12, x12, #1
	cmp	x12, #512
	b.eq	LBB0_57
LBB0_41:                                ; %direct.true90
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v25, x12
	orr.16b	v24, v25, v22
	add.2d	v26, v18, v24
	tbz	w13, #0, LBB0_50
; %bb.42:                               ; %cond.load99
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x14, d26
	ldr	b24, [x14]
	and	w14, w13, #0xff
	tbz	w14, #1, LBB0_44
LBB0_43:                                ; %cond.load105
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v26[1]
	ld1.b	{ v24 }[1], [x15]
LBB0_44:                                ; %else109
                                        ;   in Loop: Header=BB0_41 Depth=1
	orr.16b	v26, v25, v20
	add.2d	v26, v16, v26
	tbnz	w14, #2, LBB0_51
; %bb.45:                               ; %else115
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #3, LBB0_52
LBB0_46:                                ; %else121
                                        ;   in Loop: Header=BB0_41 Depth=1
	orr.16b	v26, v25, v21
	add.2d	v26, v17, v26
	tbnz	w14, #4, LBB0_53
LBB0_47:                                ; %else127
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #5, LBB0_54
LBB0_48:                                ; %else133
                                        ;   in Loop: Header=BB0_41 Depth=1
	orr.16b	v25, v25, v19
	add.2d	v25, v7, v25
	tbnz	w14, #6, LBB0_55
LBB0_49:                                ; %else139
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w14, #7, LBB0_40
	b	LBB0_56
LBB0_50:                                ;   in Loop: Header=BB0_41 Depth=1
	movi.2d	v24, #0000000000000000
	and	w14, w13, #0xff
	tbnz	w14, #1, LBB0_43
	b	LBB0_44
LBB0_51:                                ; %cond.load111
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d26
	ld1.b	{ v24 }[2], [x15]
	tbz	w14, #3, LBB0_46
LBB0_52:                                ; %cond.load117
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v26[1]
	ld1.b	{ v24 }[3], [x15]
	orr.16b	v26, v25, v21
	add.2d	v26, v17, v26
	tbz	w14, #4, LBB0_47
LBB0_53:                                ; %cond.load123
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d26
	ld1.b	{ v24 }[4], [x15]
	tbz	w14, #5, LBB0_48
LBB0_54:                                ; %cond.load129
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v26[1]
	ld1.b	{ v24 }[5], [x15]
	orr.16b	v25, v25, v19
	add.2d	v25, v7, v25
	tbz	w14, #6, LBB0_49
LBB0_55:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d25
	ld1.b	{ v24 }[6], [x15]
	tbz	w14, #7, LBB0_40
LBB0_56:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x14, v25[1]
	ld1.b	{ v24 }[7], [x14]
	b	LBB0_40
LBB0_57:                                ; %direct.false91
	ldr	q23, [x10, #53248]
	ldr	q24, [x10, #53264]
	ldr	q25, [x10, #53280]
	ldr	q28, [x10, #53296]
	ldr	q30, [x10, #53312]
	ldr	q29, [x10, #53328]
	ldr	q8, [x10, #53344]
	and.16b	v27, v0, v24
	and.16b	v26, v1, v23
	ldr	q23, [x10, #53360]
	and.16b	v24, v0, v28
	and.16b	v31, v1, v25
	and.16b	v29, v0, v29
	and.16b	v28, v1, v30
	and.16b	v25, v0, v23
	and.16b	v30, v1, v8
	mov	w12, #53472                     ; =0xd0e0
	add	x12, x10, x12
	mov	w13, #1668                      ; =0x684
LBB0_58:                                ; %direct.true121
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q23, q8, [x12, #-96]
	and.16b	v8, v0, v8
	and.16b	v23, v1, v23
	fmaxnm.4s	v23, v26, v23
	fmaxnm.4s	v8, v27, v8
	ldp	q9, q10, [x12, #-64]
	and.16b	v10, v0, v10
	and.16b	v9, v1, v9
	fmaxnm.4s	v9, v31, v9
	fmaxnm.4s	v10, v24, v10
	ldp	q11, q12, [x12, #-32]
	and.16b	v12, v0, v12
	and.16b	v11, v1, v11
	fmaxnm.4s	v11, v28, v11
	fmaxnm.4s	v12, v29, v12
	ldp	q13, q14, [x12], #128
	and.16b	v14, v0, v14
	and.16b	v13, v1, v13
	fmaxnm.4s	v13, v30, v13
	fmaxnm.4s	v14, v25, v14
	bit.16b	v27, v8, v0
	bit.16b	v26, v23, v1
	bit.16b	v24, v10, v0
	bit.16b	v31, v9, v1
	bit.16b	v29, v12, v0
	bit.16b	v28, v11, v1
	bit.16b	v25, v14, v0
	bit.16b	v30, v13, v1
	sub	x14, x13, #1664
	add	x13, x13, #4
	cmp	x14, #508
	b.lo	LBB0_58
; %bb.59:                               ; %direct.false122
	str	q2, [sp, #48]                   ; 16-byte Spill
	mvni.4s	v2, #127, msl #16
	fmaxnm.4s	v27, v27, v2
	fmaxnm.4s	v26, v26, v2
	fmaxnm.4s	v26, v26, v31
	fmaxnm.4s	v24, v27, v24
	fmaxnm.4s	v27, v24, v29
	fmaxnm.4s	v24, v26, v28
	fmaxnm.4s	v24, v24, v30
	fmaxnm.4s	v25, v27, v25
	mov	x12, #-512                      ; =0xfffffffffffffe00
	str	q6, [sp]                        ; 16-byte Spill
	fmov	w13, s6
	mov	w14, #-1026555904               ; =0xc2d00000
	mov	w15, #1120403456                ; =0x42c80000
	mov	w16, #43579                     ; =0xaa3b
	movk	w16, #16312, lsl #16
	movi.4s	v26, #75, lsl #24
	mvni.4s	v27, #128, lsl #24
	mov	w17, #29184                     ; =0x7200
	movk	w17, #48945, lsl #16
	mov	w0, #48782                      ; =0xbe8e
	movk	w0, #46527, lsl #16
	mov	w1, #11226                      ; =0x2bda
	movk	w1, #14672, lsl #16
	mov	w2, #38601                      ; =0x96c9
	movk	w2, #15030, lsl #16
	mov	w3, #34982                      ; =0x88a6
	movk	w3, #15368, lsl #16
	mov	w4, #43642                      ; =0xaa7a
	movk	w4, #15658, lsl #16
	mov	w5, #43691                      ; =0xaaab
	movk	w5, #15914, lsl #16
	movi.4s	v28, #63, lsl #24
	fmov.4s	v29, #1.00000000
	mvni.4s	v30, #63, msl #16
	fneg.4s	v30, v30
	b	LBB0_61
LBB0_60:                                ; %else194
                                        ;   in Loop: Header=BB0_61 Depth=1
	cmeq.8b	v31, v31, #0
	sshll.8h	v8, v31, #0
	sshll2.4s	v31, v8, #0
	sshll.4s	v8, v8, #0
	ldp	q10, q9, [x11]
	fsub.4s	v10, v10, v24
	fsub.4s	v9, v9, v25
	and.16b	v9, v0, v9
	dup.4s	v11, w14
	and.16b	v10, v1, v10
	fcmge.4s	v13, v10, v11
	fcmge.4s	v14, v9, v11
	dup.4s	v12, w15
	fcmge.4s	v15, v12, v10
	fcmge.4s	v6, v12, v9
	and.16b	v6, v14, v6
	and.16b	v13, v13, v15
	and.16b	v13, v13, v10
	dup.4s	v14, w16
	and.16b	v6, v6, v9
	fmul.4s	v15, v6, v14
	fmul.4s	v14, v13, v14
	mov.16b	v23, v27
	bsl.16b	v23, v26, v14
	mov.16b	v2, v27
	bsl.16b	v2, v26, v15
	fadd.4s	v15, v15, v2
	fadd.4s	v14, v14, v23
	fsub.4s	v23, v14, v23
	fsub.4s	v2, v15, v2
	fcvtzs.4s	v2, v2
	fcvtzs.4s	v23, v23
	scvtf.4s	v14, v23
	scvtf.4s	v15, v2
	dup.4s	v3, w17
	fmul.4s	v4, v15, v3
	fmul.4s	v3, v14, v3
	fadd.4s	v3, v13, v3
	fadd.4s	v4, v6, v4
	dup.4s	v6, w0
	fmul.4s	v13, v14, v6
	fmul.4s	v6, v15, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v3, v3, v13
	dup.4s	v6, w1
	fmul.4s	v13, v3, v6
	dup.4s	v14, w2
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v14
	fadd.4s	v13, v13, v14
	fmul.4s	v13, v3, v13
	dup.4s	v14, w3
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v14
	fadd.4s	v13, v13, v14
	fmul.4s	v13, v3, v13
	dup.4s	v14, w4
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v14
	fadd.4s	v13, v13, v14
	fmul.4s	v13, v3, v13
	dup.4s	v14, w5
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v14
	fadd.4s	v13, v13, v14
	fmul.4s	v13, v3, v13
	fmul.4s	v6, v4, v6
	fadd.4s	v6, v6, v28
	fadd.4s	v13, v13, v28
	fmul.4s	v14, v4, v4
	fmul.4s	v15, v3, v3
	fmul.4s	v13, v15, v13
	fmul.4s	v6, v14, v6
	fadd.4s	v4, v4, v6
	fadd.4s	v3, v3, v13
	fadd.4s	v3, v3, v29
	fadd.4s	v4, v4, v29
	sshr.4s	v6, v23, #1
	sshr.4s	v13, v2, #1
	shl.4s	v14, v13, #23
	shl.4s	v15, v6, #23
	add.4s	v15, v15, v29
	add.4s	v14, v14, v29
	fmul.4s	v4, v4, v14
	fmul.4s	v3, v3, v15
	sub.4s	v2, v2, v13
	sub.4s	v6, v23, v6
	shl.4s	v6, v6, #23
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v29
	add.4s	v6, v6, v29
	fmul.4s	v3, v3, v6
	fmul.4s	v2, v4, v2
	fcmgt.4s	v4, v11, v9
	bic.16b	v2, v2, v4
	fcmgt.4s	v4, v11, v10
	bic.16b	v3, v3, v4
	fcmgt.4s	v4, v9, v12
	fcmgt.4s	v6, v10, v12
	mvni.4s	v23, #127, msl #16
	fneg.4s	v23, v23
	bit.16b	v3, v23, v6
	bit.16b	v2, v23, v4
	fcmeq.4s	v4, v10, v10
	fcmeq.4s	v6, v9, v9
	bif.16b	v2, v30, v6
	bif.16b	v3, v30, v4
	bic.16b	v3, v3, v8
	bic.16b	v2, v2, v31
	ldr	q4, [x11, #16384]
	ldr	q6, [x11, #16400]
	bif.16b	v2, v6, v0
	bif.16b	v3, v4, v1
	str	q3, [x11, #16384]
	str	q2, [x11, #16400]
	add	x11, x11, #32
	adds	x12, x12, #1
	b.hs	LBB0_77
LBB0_61:                                ; %direct.true161
                                        ; =>This Inner Loop Header: Depth=1
	add	x6, x12, #512
	dup.2d	v8, x6
	orr.16b	v31, v8, v22
	add.2d	v9, v18, v31
	tbz	w13, #0, LBB0_70
; %bb.62:                               ; %cond.load148
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x6, d9
	ldr	b31, [x6]
	and	w6, w13, #0xff
	tbz	w6, #1, LBB0_64
LBB0_63:                                ; %cond.load154
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x7, v9[1]
	ld1.b	{ v31 }[1], [x7]
LBB0_64:                                ; %else158
                                        ;   in Loop: Header=BB0_61 Depth=1
	orr.16b	v9, v8, v20
	add.2d	v9, v16, v9
	tbnz	w6, #2, LBB0_71
; %bb.65:                               ; %else164
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbnz	w6, #3, LBB0_72
LBB0_66:                                ; %else170
                                        ;   in Loop: Header=BB0_61 Depth=1
	orr.16b	v9, v8, v21
	add.2d	v9, v17, v9
	tbnz	w6, #4, LBB0_73
LBB0_67:                                ; %else176
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbnz	w6, #5, LBB0_74
LBB0_68:                                ; %else182
                                        ;   in Loop: Header=BB0_61 Depth=1
	orr.16b	v8, v8, v19
	add.2d	v8, v7, v8
	tbnz	w6, #6, LBB0_75
LBB0_69:                                ; %else188
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbz	w6, #7, LBB0_60
	b	LBB0_76
LBB0_70:                                ;   in Loop: Header=BB0_61 Depth=1
	movi.2d	v31, #0000000000000000
	and	w6, w13, #0xff
	tbnz	w6, #1, LBB0_63
	b	LBB0_64
LBB0_71:                                ; %cond.load160
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x7, d9
	ld1.b	{ v31 }[2], [x7]
	tbz	w6, #3, LBB0_66
LBB0_72:                                ; %cond.load166
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x7, v9[1]
	ld1.b	{ v31 }[3], [x7]
	orr.16b	v9, v8, v21
	add.2d	v9, v17, v9
	tbz	w6, #4, LBB0_67
LBB0_73:                                ; %cond.load172
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x7, d9
	ld1.b	{ v31 }[4], [x7]
	tbz	w6, #5, LBB0_68
LBB0_74:                                ; %cond.load178
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x7, v9[1]
	ld1.b	{ v31 }[5], [x7]
	orr.16b	v8, v8, v19
	add.2d	v8, v7, v8
	tbz	w6, #6, LBB0_69
LBB0_75:                                ; %cond.load184
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x7, d8
	ld1.b	{ v31 }[6], [x7]
	tbz	w6, #7, LBB0_60
LBB0_76:                                ; %cond.load190
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x6, v8[1]
	ld1.b	{ v31 }[7], [x6]
	b	LBB0_60
LBB0_77:                                ; %direct.false162
	add	x11, x10, #17, lsl #12          ; =69632
	ldp	q2, q3, [x11]
	add	x11, x10, #17, lsl #12          ; =69632
	ldp	q4, q6, [x11, #32]!
	add	x11, x10, #17, lsl #12          ; =69632
	ldp	q20, q16, [x11, #64]!
	add	x11, x10, #17, lsl #12          ; =69632
	and.16b	v7, v0, v3
	and.16b	v17, v1, v2
	ldp	q2, q3, [x11, #96]!
	and.16b	v19, v0, v6
	and.16b	v18, v1, v4
	and.16b	v16, v0, v16
	and.16b	v20, v1, v20
	and.16b	v21, v0, v3
	and.16b	v22, v1, v2
	add	x10, x10, #17, lsl #12          ; =69632
	add	x10, x10, #224
	mov	w11, #2180                      ; =0x884
LBB0_78:                                ; %direct.true205
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q3, q2, [x10, #-96]
	fadd.4s	v3, v17, v3
	fadd.4s	v2, v7, v2
	ldp	q6, q4, [x10, #-64]
	fadd.4s	v6, v18, v6
	fadd.4s	v4, v19, v4
	ldp	q24, q23, [x10, #-32]
	fadd.4s	v25, v20, v24
	fadd.4s	v26, v16, v23
	ldp	q23, q24, [x10], #128
	fadd.4s	v23, v22, v23
	fadd.4s	v24, v21, v24
	bit.16b	v7, v2, v0
	bit.16b	v17, v3, v1
	bit.16b	v19, v4, v0
	bit.16b	v18, v6, v1
	bit.16b	v16, v26, v0
	bit.16b	v20, v25, v1
	bit.16b	v21, v24, v0
	bit.16b	v22, v23, v1
	sub	x12, x11, #2176
	add	x11, x11, #4
	cmp	x12, #508
	b.lo	LBB0_78
; %bb.79:                               ; %direct.false206
	mov	x10, #0                         ; =0x0
	movi.2d	v2, #0000000000000000
	fadd.4s	v3, v17, v2
	fadd.4s	v2, v7, v2
	fadd.4s	v2, v2, v19
	fadd.4s	v3, v3, v18
	fadd.4s	v3, v3, v20
	fadd.4s	v2, v2, v16
	fadd.4s	v2, v2, v24
	fadd.4s	v3, v3, v23
	and.16b	v7, v1, v3
	and.16b	v16, v0, v2
	ldp	q2, q21, [sp]                   ; 32-byte Folded Reload
	fmov	w11, s2
	dup.2d	v6, x9
	ldp	q4, q3, [sp, #32]               ; 32-byte Folded Reload
	b	LBB0_81
LBB0_80:                                ; %else228
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x10, x10, #4
	add	x8, x8, #32
	cmp	x10, #2048
	b.eq	LBB0_97
LBB0_81:                                ; %direct.true245
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q2, q18, [x8]
	and.16b	v2, v1, v2
	fdiv.4s	v19, v2, v7
	dup.2d	v17, x10
	add.2d	v2, v17, v5
	add.2d	v20, v6, v2
	tbnz	w11, #0, LBB0_89
; %bb.82:                               ; %else200
                                        ;   in Loop: Header=BB0_81 Depth=1
	and	w9, w11, #0xff
	tbnz	w9, #1, LBB0_90
LBB0_83:                                ; %else204
                                        ;   in Loop: Header=BB0_81 Depth=1
	add.2d	v2, v17, v4
	add.2d	v20, v6, v2
	tbnz	w9, #2, LBB0_91
LBB0_84:                                ; %else208
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbnz	w9, #3, LBB0_92
LBB0_85:                                ; %else212
                                        ;   in Loop: Header=BB0_81 Depth=1
	and.16b	v2, v0, v18
	fdiv.4s	v18, v2, v16
	add.2d	v2, v17, v21
	add.2d	v19, v6, v2
	tbnz	w9, #4, LBB0_93
LBB0_86:                                ; %else216
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbnz	w9, #5, LBB0_94
LBB0_87:                                ; %else220
                                        ;   in Loop: Header=BB0_81 Depth=1
	add.2d	v2, v17, v3
	add.2d	v17, v6, v2
	tbnz	w9, #6, LBB0_95
LBB0_88:                                ; %else224
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbz	w9, #7, LBB0_80
	b	LBB0_96
LBB0_89:                                ; %cond.store197
                                        ;   in Loop: Header=BB0_81 Depth=1
	fmov	x9, d20
	str	s19, [x9]
	and	w9, w11, #0xff
	tbz	w9, #1, LBB0_83
LBB0_90:                                ; %cond.store201
                                        ;   in Loop: Header=BB0_81 Depth=1
	mov.d	x12, v20[1]
	st1.s	{ v19 }[1], [x12]
	add.2d	v2, v17, v4
	add.2d	v20, v6, v2
	tbz	w9, #2, LBB0_84
LBB0_91:                                ; %cond.store205
                                        ;   in Loop: Header=BB0_81 Depth=1
	fmov	x12, d20
	st1.s	{ v19 }[2], [x12]
	tbz	w9, #3, LBB0_85
LBB0_92:                                ; %cond.store209
                                        ;   in Loop: Header=BB0_81 Depth=1
	mov.d	x12, v20[1]
	st1.s	{ v19 }[3], [x12]
	and.16b	v2, v0, v18
	fdiv.4s	v18, v2, v16
	add.2d	v2, v17, v21
	add.2d	v19, v6, v2
	tbz	w9, #4, LBB0_86
LBB0_93:                                ; %cond.store213
                                        ;   in Loop: Header=BB0_81 Depth=1
	fmov	x12, d19
	str	s18, [x12]
	tbz	w9, #5, LBB0_87
LBB0_94:                                ; %cond.store217
                                        ;   in Loop: Header=BB0_81 Depth=1
	mov.d	x12, v19[1]
	st1.s	{ v18 }[1], [x12]
	add.2d	v2, v17, v3
	add.2d	v17, v6, v2
	tbz	w9, #6, LBB0_88
LBB0_95:                                ; %cond.store221
                                        ;   in Loop: Header=BB0_81 Depth=1
	fmov	x12, d17
	st1.s	{ v18 }[2], [x12]
	tbz	w9, #7, LBB0_80
LBB0_96:                                ; %cond.store225
                                        ;   in Loop: Header=BB0_81 Depth=1
	mov.d	x9, v17[1]
	st1.s	{ v18 }[3], [x9]
	b	LBB0_80
LBB0_97:
	ldp	d9, d8, [sp, #128]              ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #112]            ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #96]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp, #80]             ; 16-byte Folded Reload
	add	sp, sp, #144
LBB0_98:                                ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

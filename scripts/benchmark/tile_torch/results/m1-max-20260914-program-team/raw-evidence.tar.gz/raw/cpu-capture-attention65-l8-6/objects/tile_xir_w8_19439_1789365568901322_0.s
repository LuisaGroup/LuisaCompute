	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_12:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI0_13:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI0_14:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI0_15:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI0_16:
	.quad	54                              ; 0x36
	.quad	63                              ; 0x3f
lCPI0_17:
	.quad	18                              ; 0x12
	.quad	27                              ; 0x1b
lCPI0_18:
	.quad	36                              ; 0x24
	.quad	45                              ; 0x2d
lCPI0_19:
	.quad	0                               ; 0x0
	.quad	9                               ; 0x9
lCPI0_20:
	.quad	108                             ; 0x6c
	.quad	126                             ; 0x7e
lCPI0_21:
	.quad	36                              ; 0x24
	.quad	54                              ; 0x36
lCPI0_22:
	.quad	72                              ; 0x48
	.quad	90                              ; 0x5a
lCPI0_23:
	.quad	0                               ; 0x0
	.quad	18                              ; 0x12
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v2, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q3, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q4, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v30, v2, v4
	cmhi.4s	v31, v2, v3
	uzp1.8h	v1, v31, v30
	umaxv.8h	h0, v1
	fmov	w8, s0
	tbnz	w8, #0, LBB0_1
	b	LBB0_1556
LBB0_1:                                 ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #9, lsl #12             ; =36864
	sub	sp, sp, #320
	str	q4, [sp, #13248]                ; 16-byte Spill
	str	q3, [sp, #13264]                ; 16-byte Spill
	str	q2, [sp, #13296]                ; 16-byte Spill
	add	x13, sp, #3, lsl #12            ; =12288
	add	x13, x13, #1200
	ldr	x14, [x0]
	ldr	x8, [x0, #16]
	str	x8, [sp, #4632]                 ; 8-byte Spill
	ldr	x8, [x0, #32]
	str	x8, [sp, #4624]                 ; 8-byte Spill
	ldr	x8, [x0, #48]
	str	x8, [sp, #40]                   ; 8-byte Spill
Lloh4:
	adrp	x9, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x9, lCPI0_0@PAGEOFF]
	str	q1, [sp, #13280]                ; 16-byte Spill
	and.16b	v0, v1, v0
	addv.8h	h0, v0
	str	q0, [sp, #7936]                 ; 16-byte Spill
	fmov	w9, s0
	and	w8, w9, #0xff
	str	w8, [sp, #12976]                ; 4-byte Spill
	ldr	w9, [x1]
	ldr	w10, [x1, #36]
	add	x11, sp, #9, lsl #12            ; =36864
	dup.2d	v0, x11
	add	w9, w10, w9, lsl #5
Lloh6:
	adrp	x10, lCPI0_3@PAGE
Lloh7:
	ldr	q1, [x10, lCPI0_3@PAGEOFF]
	sshll2.2d	v14, v30, #0
	and.16b	v1, v14, v1
	str	q1, [sp, #13088]                ; 16-byte Spill
	sshll2.2d	v11, v31, #0
Lloh8:
	adrp	x10, lCPI0_5@PAGE
Lloh9:
	ldr	q1, [x10, lCPI0_5@PAGEOFF]
	sshll.2d	v3, v30, #0
	str	q1, [sp, #688]                  ; 16-byte Spill
	and.16b	v1, v3, v1
	str	q1, [sp, #13136]                ; 16-byte Spill
	sshll.2d	v1, v31, #0
	lsr	w9, w9, #3
	dup.4s	v4, w9
	and.16b	v5, v31, v4
	and.16b	v4, v30, v4
	ushll2.2d	v2, v4, #0
	ushll2.2d	v22, v5, #0
	ushll.2d	v23, v4, #0
	ushll.2d	v24, v5, #0
	mov	w9, #2                          ; =0x2
	dup.2d	v4, x9
	and.16b	v5, v1, v4
	mvn.16b	v16, v1
	sub.2d	v27, v5, v16
	and.16b	v5, v3, v4
	mvn.16b	v19, v3
	sub.2d	v5, v5, v19
	and.16b	v6, v11, v4
	mvn.16b	v29, v11
	sub.2d	v6, v6, v29
	and.16b	v4, v14, v4
	mvn.16b	v9, v14
	sub.2d	v28, v4, v9
	mov	w9, #1                          ; =0x1
	dup.2d	v4, x9
	ushr.2d	v7, v24, #1
	ushr.2d	v17, v23, #1
	ushr.2d	v18, v22, #1
	ushr.2d	v20, v2, #1
	str	q2, [sp, #13232]                ; 16-byte Spill
	and.16b	v21, v14, v2
	str	q22, [sp, #13216]               ; 16-byte Spill
	and.16b	v22, v11, v22
	str	q23, [sp, #13200]               ; 16-byte Spill
	and.16b	v23, v3, v23
	str	q24, [sp, #13184]               ; 16-byte Spill
	and.16b	v24, v1, v24
	movi.2d	v25, #0xffffffffffffffff
	add.2d	v26, v27, v25
	and.16b	v24, v24, v26
	add.2d	v26, v5, v25
	and.16b	v23, v23, v26
	add.2d	v26, v28, v25
	add.2d	v25, v6, v25
	and.16b	v22, v22, v25
	and.16b	v21, v21, v26
	add.2d	v21, v21, v21
	add.2d	v22, v22, v22
	add.2d	v23, v23, v23
	add.2d	v24, v24, v24
	and.16b	v2, v1, v24
	and.16b	v23, v3, v23
	and.16b	v24, v11, v22
	and.16b	v25, v14, v21
	mov	w9, #5                          ; =0x5
	dup.2d	v21, x9
	and.16b	v22, v3, v21
	sub.2d	v19, v22, v19
	and.16b	v22, v1, v21
	sub.2d	v16, v22, v16
	mov.d	x9, v20[1]
	and.16b	v22, v14, v0
	str	q22, [sp, #11808]               ; 16-byte Spill
	fmov	x10, d20
	mov.d	x11, v18[1]
	mov.d	x17, v17[1]
	fmov	x12, d18
	fmov	x16, d17
	mov.d	x1, v7[1]
	fmov	x0, d7
	ushll2.2d	v7, v30, #0
	and.16b	v8, v7, v4
	ushll2.2d	v7, v31, #0
	and.16b	v10, v7, v4
	ushll.2d	v7, v30, #0
	and.16b	v15, v7, v4
	ushll.2d	v7, v31, #0
	and.16b	v18, v7, v4
	and.16b	v4, v14, v21
	str	q9, [sp, #13072]                ; 16-byte Spill
	sub.2d	v4, v4, v9
	and.16b	v7, v11, v21
	mov.d	x15, v4[1]
	add	x2, x16, x16, lsl #1
	fmov	x16, d4
	fmov	d4, x2
	add	x17, x17, x17, lsl #1
	mov.d	v4[1], x17
	str	q29, [sp, #13152]               ; 16-byte Spill
	sub.2d	v7, v7, v29
	add	x2, x0, x0, lsl #1
	mov.d	x17, v19[1]
	fmov	x0, d19
	fmov	d17, x2
	add	x1, x1, x1, lsl #1
	mov.d	v17[1], x1
	mov.d	x1, v7[1]
	fmov	x2, d7
	and.16b	v7, v11, v0
	str	q7, [sp, #11792]                ; 16-byte Spill
	mov.d	x3, v16[1]
	fmov	x4, d16
	and.16b	v7, v3, v0
	str	q7, [sp, #11776]                ; 16-byte Spill
	and.16b	v0, v1, v0
	str	q0, [sp, #11760]                ; 16-byte Spill
	and.16b	v0, v3, v4
Lloh10:
	adrp	x5, lCPI0_9@PAGE
Lloh11:
	ldr	q4, [x5, lCPI0_9@PAGEOFF]
	str	q4, [sp, #4720]                 ; 16-byte Spill
	and.16b	v3, v3, v4
	str	q3, [sp, #12320]                ; 16-byte Spill
	and.16b	v3, v1, v17
Lloh12:
	adrp	x5, lCPI0_10@PAGE
Lloh13:
	adrp	x6, lCPI0_6@PAGE
Lloh14:
	ldr	q4, [x6, lCPI0_6@PAGEOFF]
	str	q4, [sp, #5680]                 ; 16-byte Spill
	and.16b	v4, v1, v4
	str	q4, [sp, #13120]                ; 16-byte Spill
Lloh15:
	ldr	q4, [x5, lCPI0_10@PAGEOFF]
	str	q4, [sp, #4704]                 ; 16-byte Spill
	and.16b	v1, v1, v4
	str	q1, [sp, #12304]                ; 16-byte Spill
	add	x10, x10, x10, lsl #1
	add	x5, x9, x9, lsl #1
	fmov	d1, x10
	mov.d	v1[1], x5
	add	x10, x12, x12, lsl #1
	add	x11, x11, x11, lsl #1
	fmov	d4, x10
	mov.d	v4[1], x11
	mov.d	x8, v28[1]
	str	x8, [sp, #11368]                ; 8-byte Spill
	and.16b	v4, v11, v4
	and.16b	v1, v14, v1
	mov.d	x8, v5[1]
	str	x8, [sp, #11560]                ; 8-byte Spill
	mov.d	x8, v6[1]
	str	x8, [sp, #11568]                ; 8-byte Spill
	str	q25, [sp, #3088]                ; 16-byte Spill
	add.2d	v1, v25, v1
	str	q1, [sp, #1952]                 ; 16-byte Spill
	str	q24, [sp, #3104]                ; 16-byte Spill
	add.2d	v1, v24, v4
	str	q1, [sp, #1936]                 ; 16-byte Spill
	str	q23, [sp, #3120]                ; 16-byte Spill
	add.2d	v0, v23, v0
	str	q0, [sp, #1920]                 ; 16-byte Spill
	str	q2, [sp, #3136]                 ; 16-byte Spill
	add.2d	v0, v2, v3
	str	q0, [sp, #1904]                 ; 16-byte Spill
	str	q27, [sp, #11680]               ; 16-byte Spill
	mov.d	x8, v27[1]
	str	x8, [sp, #11704]                ; 8-byte Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #1016
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #952
	add	x22, sp, #5, lsl #12            ; =20480
	add	x22, x22, #888
	add	x23, sp, #5, lsl #12            ; =20480
	add	x23, x23, #824
	add	x24, sp, #5, lsl #12            ; =20480
	add	x24, x24, #760
	add	x25, sp, #5, lsl #12            ; =20480
	add	x25, x25, #616
	add	x26, sp, #5, lsl #12            ; =20480
	add	x26, x26, #472
	add	x27, sp, #4, lsl #12            ; =16384
	add	x27, x27, #3992
	add	x28, sp, #4, lsl #12            ; =16384
	add	x28, x28, #3928
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #3896
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #1848
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1784
	mov	w5, #3                          ; =0x3
	mov	w6, #33                         ; =0x21
	mov	w7, #32                         ; =0x20
	str	q28, [sp, #11632]               ; 16-byte Spill
	fmov	x19, d28
	str	q5, [sp, #11664]                ; 16-byte Spill
	fmov	x20, d5
	str	q6, [sp, #11648]                ; 16-byte Spill
	fmov	x21, d6
	add	x10, sp, #8, lsl #12            ; =32768
	add	x10, x10, #4064
	dup.2d	v1, x10
	add	x10, sp, #8, lsl #12            ; =32768
	add	x10, x10, #4032
	dup.2d	v0, x10
	str	q0, [sp, #12928]                ; 16-byte Spill
	add	x10, sp, #8, lsl #12            ; =32768
	add	x10, x10, #4000
	dup.2d	v0, x10
	add	x10, sp, #8, lsl #12            ; =32768
	add	x10, x10, #3968
	dup.2d	v2, x10
	str	q2, [sp, #12944]                ; 16-byte Spill
	add	x10, sp, #8, lsl #12            ; =32768
	add	x10, x10, #3904
	dup.2d	v22, x10
	add	x10, sp, #8, lsl #12            ; =32768
	add	x10, x10, #3840
	dup.2d	v2, x10
	str	q2, [sp, #12960]                ; 16-byte Spill
	add	x10, sp, #6, lsl #12            ; =24576
	add	x10, x10, #2528
	dup.2d	v3, x10
	add	x10, sp, #6, lsl #12            ; =24576
	add	x10, x10, #448
	dup.2d	v2, x10
	stp	q2, q3, [sp, #640]              ; 32-byte Folded Spill
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #3968
	dup.2d	v3, x10
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #3392
	dup.2d	v2, x10
	stp	q2, q3, [sp, #608]              ; 32-byte Folded Spill
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2816
	dup.2d	v3, x10
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2240
	dup.2d	v2, x10
	stp	q2, q3, [sp, #576]              ; 32-byte Folded Spill
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2168
	dup.2d	v3, x10
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #1592
	dup.2d	v2, x10
	stp	q2, q3, [sp, #544]              ; 32-byte Folded Spill
	dup.2d	v3, x8
	dup.2d	v2, x9
	stp	q2, q3, [sp, #512]              ; 32-byte Folded Spill
	dup.2d	v3, x22
	dup.2d	v2, x23
	stp	q2, q3, [sp, #480]              ; 32-byte Folded Spill
	dup.2d	v3, x24
	dup.2d	v2, x25
	stp	q2, q3, [sp, #448]              ; 32-byte Folded Spill
	dup.2d	v3, x26
	dup.2d	v2, x27
	stp	q2, q3, [sp, #416]              ; 32-byte Folded Spill
	dup.2d	v3, x28
	dup.2d	v2, x30
	stp	q2, q3, [sp, #384]              ; 32-byte Folded Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #3864
	dup.2d	v3, x8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #3832
	dup.2d	v2, x8
	stp	q2, q3, [sp, #352]              ; 32-byte Folded Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #3256
	dup.2d	v3, x8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2680
	dup.2d	v2, x8
	stp	q2, q3, [sp, #320]              ; 32-byte Folded Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2104
	dup.2d	v3, x8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2072
	dup.2d	v2, x8
	stp	q2, q3, [sp, #288]              ; 32-byte Folded Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2008
	dup.2d	v3, x8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1976
	dup.2d	v2, x8
	stp	q2, q3, [sp, #256]              ; 32-byte Folded Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1912
	dup.2d	v3, x8
Lloh16:
	adrp	x8, lCPI0_11@PAGE
	dup.2d	v2, x11
	stp	q2, q3, [sp, #224]              ; 32-byte Folded Spill
	dup.2d	v2, x12
	str	q2, [sp, #16]                   ; 16-byte Spill
Lloh17:
	adrp	x9, lCPI0_4@PAGE
Lloh18:
	ldr	q2, [x9, lCPI0_4@PAGEOFF]
Lloh19:
	adrp	x9, lCPI0_7@PAGE
Lloh20:
	ldr	q3, [x9, lCPI0_7@PAGEOFF]
Lloh21:
	adrp	x9, lCPI0_8@PAGE
Lloh22:
	ldr	q4, [x9, lCPI0_8@PAGEOFF]
	str	q2, [sp, #672]                  ; 16-byte Spill
	and.16b	v2, v11, v2
	str	q2, [sp, #13104]                ; 16-byte Spill
	str	q3, [sp, #4688]                 ; 16-byte Spill
	and.16b	v2, v14, v3
	str	q2, [sp, #12288]                ; 16-byte Spill
	str	q4, [sp, #4672]                 ; 16-byte Spill
	and.16b	v2, v11, v4
	str	q2, [sp, #12272]                ; 16-byte Spill
	movi.2d	v23, #0000000000000000
Lloh23:
	ldr	d2, [x8, lCPI0_11@PAGEOFF]
	str	d2, [sp, #13344]                ; 8-byte Spill
	movi.2d	v26, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v27, #0000000000000000
	str	q14, [sp, #12720]               ; 16-byte Spill
	str	q11, [sp, #12736]               ; 16-byte Spill
	str	q8, [sp, #12880]                ; 16-byte Spill
	str	q10, [sp, #13056]               ; 16-byte Spill
	str	q15, [sp, #13328]               ; 16-byte Spill
	str	q18, [sp, #13312]               ; 16-byte Spill
	ldr	d5, [sp, #13344]                ; 8-byte Reload
	b	LBB0_3
LBB0_2:                                 ; %else436
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v24, v24, v10
	add.2d	v25, v25, v15
	add.2d	v27, v27, v8
	add.2d	v23, v23, v18
	fmov	x8, d23
	cmp	x8, #10
	b.ge	LBB0_35
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v3, v30, #0
	sshll.2d	v17, v31, #0
	and.16b	v4, v17, v23
	and.16b	v7, v11, v24
	and.16b	v18, v3, v25
	and.16b	v19, v14, v27
	fmov	x8, d19
	sdiv	x8, x8, x16
	mul	x9, x8, x16
	fmov	d8, x8
	mov.d	x8, v19[1]
	sdiv	x8, x8, x15
	mov.d	v8[1], x8
	fmov	x22, d18
	sdiv	x22, x22, x0
	mul	x23, x22, x0
	fmov	d13, x22
	mov.d	x22, v18[1]
	sdiv	x22, x22, x17
	mov.d	v13[1], x22
	fmov	x24, d7
	sdiv	x24, x24, x2
	mul	x25, x24, x2
	fmov	d16, x24
	mov.d	x24, v7[1]
	sdiv	x24, x24, x1
	mov.d	v16[1], x24
	fmov	x26, d4
	sdiv	x26, x26, x4
	mul	x27, x26, x4
	fmov	d15, x26
	mov.d	x26, v4[1]
	sdiv	x26, x26, x3
	mov.d	v15[1], x26
	mul	x8, x8, x15
	fmov	d20, x9
	mov.d	v20[1], x8
	mul	x8, x22, x17
	fmov	d29, x23
	mov.d	v29[1], x8
	mul	x8, x24, x1
	fmov	d9, x25
	mov.d	v9[1], x8
	mul	x8, x26, x3
	fmov	d10, x27
	mov.d	v10[1], x8
	ldr	q2, [sp, #13280]                ; 16-byte Reload
	xtn.8b	v6, v2
	sub.2d	v4, v4, v10
	sub.2d	v7, v7, v9
	sub.2d	v18, v18, v29
	sub.2d	v19, v19, v20
	shl.2d	v19, v19, #3
	shl.2d	v18, v18, #3
	shl.2d	v7, v7, #3
	shl.2d	v4, v4, #3
	dup.2d	v12, x5
	ldr	q2, [sp, #13120]                ; 16-byte Reload
	orr.16b	v29, v4, v2
	ldr	q2, [sp, #13104]                ; 16-byte Reload
	orr.16b	v2, v7, v2
	ldr	q4, [sp, #13136]                ; 16-byte Reload
	orr.16b	v9, v18, v4
	ldr	q4, [sp, #13088]                ; 16-byte Reload
	orr.16b	v10, v19, v4
	dup.2d	v7, x6
	mov.16b	v19, v14
	cmgt.2d	v14, v7, v10
	cmgt.2d	v4, v7, v9
	uzp1.4s	v18, v4, v14
	cmgt.2d	v20, v7, v2
	cmgt.2d	v21, v7, v29
	uzp1.4s	v7, v21, v20
	uzp1.8h	v18, v7, v18
	and.16b	v17, v17, v15
	and.16b	v7, v11, v16
	and.16b	v3, v3, v13
	and.16b	v16, v19, v8
	mov.d	x8, v16[1]
	ldr	x10, [sp, #11368]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d16
	sdiv	x22, x9, x19
	msub	x9, x22, x19, x9
	fmov	d8, x9
	mov.d	v8[1], x8
	mov.d	x8, v3[1]
	ldr	x10, [sp, #11560]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d3
	sdiv	x22, x9, x20
	msub	x9, x22, x20, x9
	fmov	d19, x9
	mov.d	v19[1], x8
	mov.d	x8, v7[1]
	ldr	x10, [sp, #11568]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d7
	sdiv	x22, x9, x21
	msub	x9, x22, x21, x9
	fmov	d7, x9
	mov.d	v7[1], x8
	mov.d	x8, v17[1]
	ldr	x10, [sp, #11704]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d17
	ldr	q3, [sp, #11680]                ; 16-byte Reload
	fmov	x22, d3
	sdiv	x23, x9, x22
	msub	x9, x23, x22, x9
	fmov	d3, x9
	mov.d	v3[1], x8
	ldr	q16, [sp, #3136]                ; 16-byte Reload
	add.2d	v16, v3, v16
	ldr	q17, [sp, #3120]                ; 16-byte Reload
	add.2d	v17, v19, v17
	ldr	q11, [sp, #3088]                ; 16-byte Reload
	add.2d	v13, v8, v11
	cmhi.2d	v13, v12, v13
	cmhi.2d	v17, v12, v17
	uzp1.4s	v13, v17, v13
	ldr	q17, [sp, #3104]                ; 16-byte Reload
	add.2d	v17, v7, v17
	cmhi.2d	v15, v12, v17
	cmhi.2d	v16, v12, v16
	dup.2d	v17, x7
	bsl.16b	v21, v29, v17
	ldr	q11, [sp, #1904]                ; 16-byte Reload
	add.2d	v3, v3, v11
	uzp1.4s	v16, v16, v15
	uzp1.8h	v16, v16, v13
	mov.d	x8, v3[1]
	fmov	x9, d3
	add	x9, x9, x9, lsl #5
	fmov	d3, x9
	add	x8, x8, x8, lsl #5
	mov.d	v3[1], x8
	add.2d	v3, v3, v21
	and.16b	v16, v18, v16
	xtn.8b	v15, v16
	str	q6, [sp, #13168]                ; 16-byte Spill
	and.8b	v12, v6, v15
	shl.8b	v16, v12, #7
	cmlt.8b	v16, v16, #0
	and.8b	v16, v16, v5
	addv.8b	b16, v16
	fmov	w8, s16
	shl.2d	v3, v3, #2
	mov	b16, v12[0]
	mov.b	v16[4], v12[1]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	and.16b	v3, v16, v3
	dup.2d	v18, x14
	add.2d	v16, v18, v3
	movi.2d	v3, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbz	w8, #0, LBB0_5
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x9, d16
	ldr	s3, [x9]
LBB0_5:                                 ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #1, LBB0_7
; %bb.6:                                ; %cond.load392
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v16[1]
	ld1.s	{ v3 }[1], [x9]
LBB0_7:                                 ; %else393
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q16, [sp, #1936]                ; 16-byte Reload
	add.2d	v7, v7, v16
	mov.d	x9, v7[1]
	fmov	x22, d7
	add	x22, x22, x22, lsl #5
	fmov	d7, x22
	mov.16b	v16, v20
	bsl.16b	v16, v2, v17
	add	x9, x9, x9, lsl #5
	mov.d	v7[1], x9
	add.2d	v7, v7, v16
	mov	b16, v12[2]
	mov.b	v16[4], v12[3]
	shl.2d	v7, v7, #2
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	and.16b	v7, v16, v7
	add.2d	v7, v18, v7
	tbz	w8, #2, LBB0_9
; %bb.8:                                ; %cond.load395
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x9, d7
	ld1.s	{ v3 }[2], [x9]
LBB0_9:                                 ; %else396
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #3, LBB0_11
; %bb.10:                               ; %cond.load398
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v7[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_11:                                ; %else399
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q7, [sp, #1920]                 ; 16-byte Reload
	add.2d	v7, v19, v7
	mov.d	x9, v7[1]
	fmov	x22, d7
	add	x22, x22, x22, lsl #5
	fmov	d7, x22
	bsl.16b	v4, v9, v17
	add	x9, x9, x9, lsl #5
	mov.d	v7[1], x9
	add.2d	v4, v7, v4
	mov	b7, v12[4]
	mov.b	v7[4], v12[5]
	shl.2d	v4, v4, #2
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v4, v7, v4
	add.2d	v4, v18, v4
	tbz	w8, #4, LBB0_13
; %bb.12:                               ; %cond.load401
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x9, d4
	ld1.s	{ v13 }[0], [x9]
LBB0_13:                                ; %else402
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #5, LBB0_15
; %bb.14:                               ; %cond.load404
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v13 }[1], [x9]
LBB0_15:                                ; %else405
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q4, [sp, #1952]                 ; 16-byte Reload
	add.2d	v4, v8, v4
	mov.d	x9, v4[1]
	fmov	x22, d4
	add	x22, x22, x22, lsl #5
	fmov	d4, x22
	mov.16b	v7, v14
	bsl.16b	v7, v10, v17
	add	x9, x9, x9, lsl #5
	mov.d	v4[1], x9
	add.2d	v4, v4, v7
	mov	b7, v12[6]
	mov.b	v7[4], v12[7]
	shl.2d	v4, v4, #2
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v4, v7, v4
	add.2d	v4, v18, v4
	tbz	w8, #6, LBB0_17
; %bb.16:                               ; %cond.load407
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x9, d4
	ld1.s	{ v13 }[2], [x9]
LBB0_17:                                ; %else408
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q14, [sp, #12720]               ; 16-byte Reload
	ldr	q8, [sp, #12880]                ; 16-byte Reload
	tbz	w8, #7, LBB0_19
; %bb.18:                               ; %cond.load410
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x8, v4[1]
	ld1.s	{ v13 }[3], [x8]
LBB0_19:                                ; %else411
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q4, [sp, #13168]                ; 16-byte Reload
	bic.8b	v4, v4, v15
	dup.2d	v7, x6
	cmgt.2d	v16, v7, v2
	cmgt.2d	v17, v7, v29
	uzp1.4s	v16, v17, v16
	cmgt.2d	v17, v7, v9
	cmgt.2d	v7, v7, v10
	uzp1.4s	v7, v17, v7
	uzp1.8h	v7, v16, v7
	zip1.8b	v16, v12, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bif.16b	v3, v26, v16
	zip1.8b	v16, v4, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmge.4s	v16, v16, #0
	and.16b	v26, v16, v3
	ldr	q2, [sp, #13280]                ; 16-byte Reload
	and.16b	v3, v2, v7
	xtn.8b	v3, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	ldr	d2, [sp, #13344]                ; 8-byte Reload
	and.8b	v3, v3, v2
	addv.8b	b3, v3
	fmov	w8, s3
	shl.2d	v3, v23, #5
	ldr	q2, [sp, #12304]                ; 16-byte Reload
	orr.16b	v3, v3, v2
	ldr	q2, [sp, #11760]                ; 16-byte Reload
	add.2d	v3, v2, v3
	tbnz	w8, #0, LBB0_28
; %bb.20:                               ; %else415
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q11, [sp, #12736]               ; 16-byte Reload
	ldr	q10, [sp, #13056]               ; 16-byte Reload
	ldr	q18, [sp, #13312]               ; 16-byte Reload
	tbnz	w8, #1, LBB0_29
LBB0_21:                                ; %else418
                                        ;   in Loop: Header=BB0_3 Depth=1
	shl.2d	v3, v24, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v3, v3, v2
	ldr	q2, [sp, #11792]                ; 16-byte Reload
	add.2d	v3, v2, v3
	tbnz	w8, #2, LBB0_30
LBB0_22:                                ; %else421
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #3, LBB0_24
LBB0_23:                                ; %cond.store422
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v3[1]
	st1.s	{ v26 }[3], [x9]
LBB0_24:                                ; %else424
                                        ;   in Loop: Header=BB0_3 Depth=1
	zip2.8b	v3, v12, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v13, v28
	zip2.8b	v4, v4, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v4, v4, #0
	and.16b	v28, v4, v3
	shl.2d	v3, v25, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v3, v3, v2
	ldr	q2, [sp, #11776]                ; 16-byte Reload
	add.2d	v3, v2, v3
	tbnz	w8, #4, LBB0_31
; %bb.25:                               ; %else427
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q15, [sp, #13328]               ; 16-byte Reload
	tbnz	w8, #5, LBB0_32
LBB0_26:                                ; %else430
                                        ;   in Loop: Header=BB0_3 Depth=1
	shl.2d	v3, v27, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v3, v3, v2
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	add.2d	v3, v2, v3
	tbnz	w8, #6, LBB0_33
LBB0_27:                                ; %else433
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w8, #7, LBB0_2
	b	LBB0_34
LBB0_28:                                ; %cond.store
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x9, d3
	str	s26, [x9]
	ldr	q11, [sp, #12736]               ; 16-byte Reload
	ldr	q10, [sp, #13056]               ; 16-byte Reload
	ldr	q18, [sp, #13312]               ; 16-byte Reload
	tbz	w8, #1, LBB0_21
LBB0_29:                                ; %cond.store416
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v3[1]
	st1.s	{ v26 }[1], [x9]
	shl.2d	v3, v24, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v3, v3, v2
	ldr	q2, [sp, #11792]                ; 16-byte Reload
	add.2d	v3, v2, v3
	tbz	w8, #2, LBB0_22
LBB0_30:                                ; %cond.store419
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x9, d3
	st1.s	{ v26 }[2], [x9]
	tbnz	w8, #3, LBB0_23
	b	LBB0_24
LBB0_31:                                ; %cond.store425
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x9, d3
	str	s28, [x9]
	ldr	q15, [sp, #13328]               ; 16-byte Reload
	tbz	w8, #5, LBB0_26
LBB0_32:                                ; %cond.store428
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v3[1]
	st1.s	{ v28 }[1], [x9]
	shl.2d	v3, v27, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v3, v3, v2
	ldr	q2, [sp, #11808]                ; 16-byte Reload
	add.2d	v3, v2, v3
	tbz	w8, #6, LBB0_27
LBB0_33:                                ; %cond.store431
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x9, d3
	st1.s	{ v28 }[2], [x9]
	tbz	w8, #7, LBB0_2
LBB0_34:                                ; %cond.store434
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x8, v3[1]
	st1.s	{ v28 }[3], [x8]
	b	LBB0_2
LBB0_35:                                ; %direct.false
	sshll.2d	v3, v31, #0
	sshll.2d	v4, v30, #0
	and.16b	v2, v14, v1
	str	q2, [sp, #3072]                 ; 16-byte Spill
	and.16b	v2, v11, v1
	str	q2, [sp, #3056]                 ; 16-byte Spill
	and.16b	v2, v4, v1
	str	q2, [sp, #3040]                 ; 16-byte Spill
	and.16b	v1, v3, v1
	str	q1, [sp, #3024]                 ; 16-byte Spill
	movi	d1, #0x0000000000ffff
	ldr	q2, [sp, #13168]                ; 16-byte Reload
	and.8b	v2, v2, v1
	movi.2d	v1, #0000000000000000
	str	q2, [sp, #11600]                ; 16-byte Spill
	shl.8b	v3, v2, #7
	cmlt.8b	v3, v3, #0
	ldr	d2, [sp, #13344]                ; 8-byte Reload
	and.8b	v3, v3, v2
	addv.8b	b12, v3
	fmov	w8, s12
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v7, #0000000000000000
	ldr	q28, [sp, #13280]               ; 16-byte Reload
	b	LBB0_37
LBB0_36:                                ; %else461
                                        ;   in Loop: Header=BB0_37 Depth=1
	add.2d	v3, v3, v10
	add.2d	v4, v4, v15
	add.2d	v7, v7, v8
	add.2d	v1, v1, v18
	fmov	x14, d1
	cmp	x14, #1
	b.ge	LBB0_53
LBB0_37:                                ; %direct.true338
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v16, v1, #5
	ldr	q2, [sp, #12304]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #3024]                 ; 16-byte Reload
	add.2d	v16, v2, v16
	tbnz	w8, #0, LBB0_45
; %bb.38:                               ; %else440
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w8, #1, LBB0_46
LBB0_39:                                ; %else443
                                        ;   in Loop: Header=BB0_37 Depth=1
	shl.2d	v16, v3, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #3056]                 ; 16-byte Reload
	add.2d	v16, v2, v16
	tbnz	w8, #2, LBB0_47
LBB0_40:                                ; %else446
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w8, #3, LBB0_48
LBB0_41:                                ; %else449
                                        ;   in Loop: Header=BB0_37 Depth=1
	shl.2d	v16, v4, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #3040]                 ; 16-byte Reload
	add.2d	v16, v2, v16
	tbnz	w8, #4, LBB0_49
LBB0_42:                                ; %else452
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w8, #5, LBB0_50
LBB0_43:                                ; %else455
                                        ;   in Loop: Header=BB0_37 Depth=1
	shl.2d	v16, v7, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #3072]                 ; 16-byte Reload
	add.2d	v16, v2, v16
	tbnz	w8, #6, LBB0_51
LBB0_44:                                ; %else458
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbz	w8, #7, LBB0_36
	b	LBB0_52
LBB0_45:                                ; %cond.store438
                                        ;   in Loop: Header=BB0_37 Depth=1
	fmov	x14, d16
	str	w9, [x14]
	tbz	w8, #1, LBB0_39
LBB0_46:                                ; %cond.store441
                                        ;   in Loop: Header=BB0_37 Depth=1
	mov.d	x14, v16[1]
	str	w9, [x14]
	shl.2d	v16, v3, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #3056]                 ; 16-byte Reload
	add.2d	v16, v2, v16
	tbz	w8, #2, LBB0_40
LBB0_47:                                ; %cond.store444
                                        ;   in Loop: Header=BB0_37 Depth=1
	fmov	x14, d16
	str	w9, [x14]
	tbz	w8, #3, LBB0_41
LBB0_48:                                ; %cond.store447
                                        ;   in Loop: Header=BB0_37 Depth=1
	mov.d	x14, v16[1]
	str	w9, [x14]
	shl.2d	v16, v4, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #3040]                 ; 16-byte Reload
	add.2d	v16, v2, v16
	tbz	w8, #4, LBB0_42
LBB0_49:                                ; %cond.store450
                                        ;   in Loop: Header=BB0_37 Depth=1
	fmov	x14, d16
	str	w9, [x14]
	tbz	w8, #5, LBB0_43
LBB0_50:                                ; %cond.store453
                                        ;   in Loop: Header=BB0_37 Depth=1
	mov.d	x14, v16[1]
	str	w9, [x14]
	shl.2d	v16, v7, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #3072]                 ; 16-byte Reload
	add.2d	v16, v2, v16
	tbz	w8, #6, LBB0_44
LBB0_51:                                ; %cond.store456
                                        ;   in Loop: Header=BB0_37 Depth=1
	fmov	x14, d16
	str	w9, [x14]
	tbz	w8, #7, LBB0_36
LBB0_52:                                ; %cond.store459
                                        ;   in Loop: Header=BB0_37 Depth=1
	mov.d	x14, v16[1]
	str	w9, [x14]
	b	LBB0_36
LBB0_53:                                ; %direct.false339
	sshll.2d	v1, v31, #0
	sshll.2d	v3, v30, #0
	and.16b	v2, v14, v0
	str	q2, [sp, #3200]                 ; 16-byte Spill
	and.16b	v2, v11, v0
	str	q2, [sp, #3184]                 ; 16-byte Spill
	and.16b	v2, v3, v0
	str	q2, [sp, #3168]                 ; 16-byte Spill
	and.16b	v0, v1, v0
	str	q0, [sp, #3152]                 ; 16-byte Spill
	movi.2d	v0, #0000000000000000
	fmov	w8, s12
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	b	LBB0_55
LBB0_54:                                ; %else486
                                        ;   in Loop: Header=BB0_55 Depth=1
	add.2d	v1, v1, v10
	add.2d	v3, v3, v15
	add.2d	v4, v4, v8
	add.2d	v0, v0, v18
	fmov	x9, d0
	cmp	x9, #1
	b.ge	LBB0_71
LBB0_55:                                ; %direct.true346
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v7, v0, #5
	ldr	q2, [sp, #12304]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #3152]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbnz	w8, #0, LBB0_63
; %bb.56:                               ; %else465
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w8, #1, LBB0_64
LBB0_57:                                ; %else468
                                        ;   in Loop: Header=BB0_55 Depth=1
	shl.2d	v7, v1, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #3184]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbnz	w8, #2, LBB0_65
LBB0_58:                                ; %else471
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w8, #3, LBB0_66
LBB0_59:                                ; %else474
                                        ;   in Loop: Header=BB0_55 Depth=1
	shl.2d	v7, v3, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #3168]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbnz	w8, #4, LBB0_67
LBB0_60:                                ; %else477
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w8, #5, LBB0_68
LBB0_61:                                ; %else480
                                        ;   in Loop: Header=BB0_55 Depth=1
	shl.2d	v7, v4, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #3200]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbnz	w8, #6, LBB0_69
LBB0_62:                                ; %else483
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w8, #7, LBB0_54
	b	LBB0_70
LBB0_63:                                ; %cond.store463
                                        ;   in Loop: Header=BB0_55 Depth=1
	fmov	x9, d7
	str	wzr, [x9]
	tbz	w8, #1, LBB0_57
LBB0_64:                                ; %cond.store466
                                        ;   in Loop: Header=BB0_55 Depth=1
	mov.d	x9, v7[1]
	str	wzr, [x9]
	shl.2d	v7, v1, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #3184]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbz	w8, #2, LBB0_58
LBB0_65:                                ; %cond.store469
                                        ;   in Loop: Header=BB0_55 Depth=1
	fmov	x9, d7
	str	wzr, [x9]
	tbz	w8, #3, LBB0_59
LBB0_66:                                ; %cond.store472
                                        ;   in Loop: Header=BB0_55 Depth=1
	mov.d	x9, v7[1]
	str	wzr, [x9]
	shl.2d	v7, v3, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #3168]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbz	w8, #4, LBB0_60
LBB0_67:                                ; %cond.store475
                                        ;   in Loop: Header=BB0_55 Depth=1
	fmov	x9, d7
	str	wzr, [x9]
	tbz	w8, #5, LBB0_61
LBB0_68:                                ; %cond.store478
                                        ;   in Loop: Header=BB0_55 Depth=1
	mov.d	x9, v7[1]
	str	wzr, [x9]
	shl.2d	v7, v4, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #3200]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbz	w8, #6, LBB0_62
LBB0_69:                                ; %cond.store481
                                        ;   in Loop: Header=BB0_55 Depth=1
	fmov	x9, d7
	str	wzr, [x9]
	tbz	w8, #7, LBB0_54
LBB0_70:                                ; %cond.store484
                                        ;   in Loop: Header=BB0_55 Depth=1
	mov.d	x9, v7[1]
	str	wzr, [x9]
	b	LBB0_54
LBB0_71:                                ; %direct.false347
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	and.16b	v2, v14, v22
	str	q2, [sp, #9776]                 ; 16-byte Spill
	and.16b	v2, v11, v22
	str	q2, [sp, #9760]                 ; 16-byte Spill
	and.16b	v1, v1, v22
	str	q1, [sp, #9744]                 ; 16-byte Spill
	and.16b	v0, v0, v22
	str	q0, [sp, #9728]                 ; 16-byte Spill
	ldr	q1, [sp, #13168]                ; 16-byte Reload
	mov.b	v1[7], wzr
	movi.2d	v0, #0000000000000000
	str	q1, [sp, #4640]                 ; 16-byte Spill
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #13344]                ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	str	d1, [sp, #12344]                ; 8-byte Spill
	fmov	w8, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	str	d12, [sp, #11576]               ; 8-byte Spill
	b	LBB0_73
LBB0_72:                                ; %else511
                                        ;   in Loop: Header=BB0_73 Depth=1
	add.2d	v1, v1, v10
	add.2d	v3, v3, v15
	add.2d	v4, v4, v8
	add.2d	v0, v0, v18
	fmov	x9, d0
	cmp	x9, #2
	b.ge	LBB0_89
LBB0_73:                                ; %direct.true354
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v7, v0, #5
	ldr	q2, [sp, #12304]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #9728]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbnz	w8, #0, LBB0_81
; %bb.74:                               ; %else490
                                        ;   in Loop: Header=BB0_73 Depth=1
	tbnz	w8, #1, LBB0_82
LBB0_75:                                ; %else493
                                        ;   in Loop: Header=BB0_73 Depth=1
	shl.2d	v7, v1, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #9760]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbnz	w8, #2, LBB0_83
LBB0_76:                                ; %else496
                                        ;   in Loop: Header=BB0_73 Depth=1
	tbnz	w8, #3, LBB0_84
LBB0_77:                                ; %else499
                                        ;   in Loop: Header=BB0_73 Depth=1
	shl.2d	v7, v3, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #9744]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbnz	w8, #4, LBB0_85
LBB0_78:                                ; %else502
                                        ;   in Loop: Header=BB0_73 Depth=1
	tbnz	w8, #5, LBB0_86
LBB0_79:                                ; %else505
                                        ;   in Loop: Header=BB0_73 Depth=1
	shl.2d	v7, v4, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #9776]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbnz	w8, #6, LBB0_87
LBB0_80:                                ; %else508
                                        ;   in Loop: Header=BB0_73 Depth=1
	tbz	w8, #7, LBB0_72
	b	LBB0_88
LBB0_81:                                ; %cond.store488
                                        ;   in Loop: Header=BB0_73 Depth=1
	fmov	x9, d7
	str	wzr, [x9]
	tbz	w8, #1, LBB0_75
LBB0_82:                                ; %cond.store491
                                        ;   in Loop: Header=BB0_73 Depth=1
	mov.d	x9, v7[1]
	str	wzr, [x9]
	shl.2d	v7, v1, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #9760]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbz	w8, #2, LBB0_76
LBB0_83:                                ; %cond.store494
                                        ;   in Loop: Header=BB0_73 Depth=1
	fmov	x9, d7
	str	wzr, [x9]
	tbz	w8, #3, LBB0_77
LBB0_84:                                ; %cond.store497
                                        ;   in Loop: Header=BB0_73 Depth=1
	mov.d	x9, v7[1]
	str	wzr, [x9]
	shl.2d	v7, v3, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #9744]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbz	w8, #4, LBB0_78
LBB0_85:                                ; %cond.store500
                                        ;   in Loop: Header=BB0_73 Depth=1
	fmov	x9, d7
	str	wzr, [x9]
	tbz	w8, #5, LBB0_79
LBB0_86:                                ; %cond.store503
                                        ;   in Loop: Header=BB0_73 Depth=1
	mov.d	x9, v7[1]
	str	wzr, [x9]
	shl.2d	v7, v4, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v7, v7, v2
	ldr	q2, [sp, #9776]                 ; 16-byte Reload
	add.2d	v7, v2, v7
	tbz	w8, #6, LBB0_80
LBB0_87:                                ; %cond.store506
                                        ;   in Loop: Header=BB0_73 Depth=1
	fmov	x9, d7
	str	wzr, [x9]
	tbz	w8, #7, LBB0_72
LBB0_88:                                ; %cond.store509
                                        ;   in Loop: Header=BB0_73 Depth=1
	mov.d	x9, v7[1]
	str	wzr, [x9]
	b	LBB0_72
LBB0_89:                                ; %direct.schedule.23.preheader
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q2, [sp, #13184]                ; 16-byte Reload
	ushr.2d	v7, v2, #2
	ldr	q2, [sp, #13216]                ; 16-byte Reload
	ushr.2d	v16, v2, #2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	ushr.2d	v17, v2, #2
	ldr	q2, [sp, #13232]                ; 16-byte Reload
	ushr.2d	v18, v2, #2
	ldr	q22, [sp, #12928]               ; 16-byte Reload
	and.16b	v2, v14, v22
	str	q2, [sp, #5664]                 ; 16-byte Spill
	mov	w8, #33                         ; =0x21
	dup.2d	v4, x8
	and.16b	v3, v14, v4
	ldr	q6, [sp, #13072]                ; 16-byte Reload
	sub.2d	v2, v3, v6
	str	q2, [sp, #4608]                 ; 16-byte Spill
	and.16b	v3, v11, v4
	ldr	q21, [sp, #13152]               ; 16-byte Reload
	sub.2d	v2, v3, v21
	str	q2, [sp, #4592]                 ; 16-byte Spill
	and.16b	v19, v1, v4
	mvn.16b	v3, v1
	sub.2d	v2, v19, v3
	str	q2, [sp, #4576]                 ; 16-byte Spill
	and.16b	v19, v0, v4
	mvn.16b	v4, v0
	sub.2d	v2, v19, v4
	str	q2, [sp, #4560]                 ; 16-byte Spill
	mov	w8, #9                          ; =0x9
	dup.2d	v19, x8
	and.16b	v20, v14, v19
	sub.2d	v2, v20, v6
	str	q2, [sp, #13232]                ; 16-byte Spill
	and.16b	v20, v11, v19
	sub.2d	v2, v20, v21
	str	q2, [sp, #13216]                ; 16-byte Spill
	and.16b	v20, v1, v19
	sub.2d	v2, v20, v3
	str	q2, [sp, #13200]                ; 16-byte Spill
	and.16b	v19, v0, v19
	sub.2d	v2, v19, v4
	str	q2, [sp, #13184]                ; 16-byte Spill
	mov.d	x16, v18[1]
	fmov	x17, d18
	mov.d	x0, v17[1]
	fmov	x1, d17
	mov.d	x2, v16[1]
	fmov	x3, d16
	mov.d	x4, v7[1]
	fmov	x5, d7
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	ldr	q5, [sp, #13248]                ; 16-byte Reload
	cmhs.4s	v7, v5, v2
	ldr	q5, [sp, #13264]                ; 16-byte Reload
	cmhs.4s	v2, v5, v2
	uzp1.8h	v2, v2, v7
	xtn.8b	v2, v2
	movi	d5, #0xffffffffffffff
	str	d2, [sp, #11552]                ; 8-byte Spill
	orr.8b	v5, v2, v5
	mov	b2, v5[6]
	str	q5, [sp, #4544]                 ; 16-byte Spill
	mov.b	v2[4], v5[7]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v7, v2, #0
	mov	w8, #6                          ; =0x6
	dup.2d	v16, x8
	mov	w8, #65                         ; =0x41
	dup.2d	v2, x8
	ldr	q17, [sp, #13088]               ; 16-byte Reload
	mov.16b	v5, v7
	bsl.16b	v5, v17, v16
	str	q5, [sp, #4528]                 ; 16-byte Spill
	and.16b	v7, v14, v2
	sub.2d	v5, v7, v6
	str	q5, [sp, #4512]                 ; 16-byte Spill
	and.16b	v7, v11, v2
	sub.2d	v5, v7, v21
	str	q5, [sp, #4496]                 ; 16-byte Spill
	and.16b	v7, v1, v2
	sub.2d	v5, v7, v3
	str	q5, [sp, #4480]                 ; 16-byte Spill
	and.16b	v7, v0, v2
	sub.2d	v5, v7, v4
	str	q5, [sp, #4464]                 ; 16-byte Spill
	mov	w8, #8                          ; =0x8
	dup.2d	v7, x8
	and.16b	v16, v14, v7
	sub.2d	v5, v16, v6
	str	q5, [sp, #13040]                ; 16-byte Spill
	and.16b	v6, v11, v7
	sub.2d	v5, v6, v21
	str	q5, [sp, #13024]                ; 16-byte Spill
	and.16b	v5, v1, v7
	sub.2d	v3, v5, v3
	str	q3, [sp, #13008]                ; 16-byte Spill
	and.16b	v3, v0, v7
	sub.2d	v3, v3, v4
	str	q3, [sp, #12992]                ; 16-byte Spill
	ldr	q16, [sp, #13120]               ; 16-byte Reload
	ldr	q18, [sp, #13104]               ; 16-byte Reload
	uzp1.4s	v3, v16, v18
	ldr	q7, [sp, #13136]                ; 16-byte Reload
	uzp1.4s	v4, v7, v17
	movi.4s	v6, #1
	eor.16b	v5, v3, v6
	mov.s	w27, v5[1]
	str	x27, [sp, #12912]               ; 8-byte Spill
	mov.s	w15, v5[2]
	str	x15, [sp, #12896]               ; 8-byte Spill
	mov.s	w14, v5[3]
	str	x14, [sp, #12864]               ; 8-byte Spill
	eor.16b	v6, v4, v6
	fmov	w23, s5
	mov.s	w12, v6[1]
	str	x12, [sp, #12816]               ; 8-byte Spill
	mov.s	w22, v6[2]
	str	x22, [sp, #12800]               ; 8-byte Spill
	mov.s	w8, v6[3]
	str	x8, [sp, #13072]                ; 8-byte Spill
	fmov	w6, s6
	movi.4s	v5, #2
	eor.16b	v4, v4, v5
	eor.16b	v5, v3, v5
	mov.s	w25, v5[1]
	str	x25, [sp, #12784]               ; 8-byte Spill
	mov.s	w30, v5[2]
	mov.s	w26, v5[3]
	and.16b	v6, v11, v22
	str	q6, [sp, #5648]                 ; 16-byte Spill
	fmov	w19, s5
	and.16b	v5, v1, v22
	str	q5, [sp, #5632]                 ; 16-byte Spill
	and.16b	v5, v0, v22
	str	q5, [sp, #5616]                 ; 16-byte Spill
	mov.s	w28, v4[3]
	mov.s	w8, v4[1]
	str	x8, [sp, #12848]                ; 8-byte Spill
	mov.s	w8, v4[2]
	str	x8, [sp, #12928]                ; 8-byte Spill
	fmov	w20, s4
	movi.4s	v4, #4
	eor.16b	v3, v3, v4
	ldr	q5, [sp, #12944]                ; 16-byte Reload
	and.16b	v4, v14, v5
	str	q4, [sp, #5600]                 ; 16-byte Spill
	mov.s	w24, v3[1]
	mov.s	w8, v3[2]
	str	x8, [sp, #12832]                ; 8-byte Spill
	mov.s	w11, v3[3]
	str	x11, [sp, #12768]               ; 8-byte Spill
	fmov	w21, s3
	and.16b	v3, v11, v5
	str	q3, [sp, #5584]                 ; 16-byte Spill
	and.16b	v3, v1, v5
	str	q3, [sp, #5568]                 ; 16-byte Spill
	and.16b	v3, v0, v5
	str	q3, [sp, #5552]                 ; 16-byte Spill
	ldr	q4, [sp, #12960]                ; 16-byte Reload
	and.16b	v3, v14, v4
	str	q3, [sp, #7920]                 ; 16-byte Spill
	and.16b	v3, v11, v4
	str	q3, [sp, #7904]                 ; 16-byte Spill
	and.16b	v3, v1, v4
	str	q3, [sp, #7888]                 ; 16-byte Spill
	and.16b	v3, v0, v4
	str	q3, [sp, #7872]                 ; 16-byte Spill
	mov	w10, #67                        ; =0x43
	mul	x8, x16, x10
	mul	x9, x17, x10
	mov	w7, #1                          ; =0x1
	fmov	d3, x9
	mov.d	v3[1], x8
	mul	x8, x0, x10
	mul	x9, x1, x10
	fmov	d4, x9
	mov.d	v4[1], x8
	mul	x8, x2, x10
	mul	x9, x3, x10
	fmov	d5, x9
	mov.d	v5[1], x8
	mul	x8, x4, x10
	mul	x9, x5, x10
	fmov	d6, x9
	mov.d	v6[1], x8
	and.16b	v6, v0, v6
	and.16b	v5, v11, v5
	stp	q5, q6, [sp, #192]              ; 32-byte Folded Spill
	and.16b	v4, v1, v4
	and.16b	v3, v14, v3
	stp	q3, q4, [sp, #160]              ; 32-byte Folded Spill
	sub.2d	v6, v2, v7
	sub.2d	v3, v2, v18
	str	q3, [sp, #13248]                ; 16-byte Spill
	sub.2d	v25, v2, v16
	sub.2d	v2, v2, v17
	str	q2, [sp, #13264]                ; 16-byte Spill
	ldr	q5, [sp, #13168]                ; 16-byte Reload
	umov.b	w16, v5[0]
	umov.b	w17, v5[1]
	umov.b	w0, v5[2]
	umov.b	w1, v5[3]
	dup.2d	v2, x7
	and.16b	v3, v1, v2
	and.16b	v1, v14, v2
	stp	q1, q3, [sp, #64]               ; 32-byte Folded Spill
	and.16b	v1, v11, v2
	str	q1, [sp, #2944]                 ; 16-byte Spill
	ldr	q1, [sp, #5680]                 ; 16-byte Reload
	and.16b	v0, v0, v1
	str	q0, [sp, #2928]                 ; 16-byte Spill
	movi	d0, #0xffffffffffff0000
	and.8b	v4, v5, v0
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x23, #0, #3
	str	d5, [sp, #18152]
	ldrb	w8, [x8]
	and	w8, w16, w8
	str	w8, [sp, #7868]                 ; 4-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x27, #0, #3
	ldrb	w8, [x8]
	and	w8, w17, w8
	str	w8, [sp, #7864]                 ; 4-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x15, #0, #3
	ldrb	w8, [x8]
	and	w8, w0, w8
	str	w8, [sp, #7860]                 ; 4-byte Spill
	movi.2d	v2, #0000000000000000
	mov.b	v2[7], v5[7]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x14, #0, #3
	ldr	q3, [sp, #11600]                ; 16-byte Reload
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ldrb	w8, [x9]
	shl.4s	v0, v0, #31
	and	w8, w1, w8
	str	w8, [sp, #7856]                 ; 4-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2912]                 ; 16-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x6, #0, #3
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ldrb	w8, [x8]
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2896]                 ; 16-byte Spill
	umov.b	w2, v5[4]
	and	w8, w2, w8
	str	w8, [sp, #7852]                 ; 4-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x12, #0, #3
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2880]                 ; 16-byte Spill
	ldrb	w8, [x8]
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	umov.b	w3, v5[5]
	and	w8, w3, w8
	str	w8, [sp, #7848]                 ; 4-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2864]                 ; 16-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x22, #0, #3
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ldrb	w8, [x8]
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2848]                 ; 16-byte Spill
	umov.b	w4, v5[6]
	and	w8, w4, w8
	str	w8, [sp, #7844]                 ; 4-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	ldr	x9, [sp, #13072]                ; 8-byte Reload
	bfxil	x8, x9, #0, #3
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2832]                 ; 16-byte Spill
	ldrb	w8, [x8]
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	umov.b	w5, v5[7]
	and	w8, w5, w8
	str	w8, [sp, #7840]                 ; 4-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2816]                 ; 16-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x19, #0, #3
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ldrb	w8, [x8]
	shl.4s	v0, v0, #31
	and	w8, w16, w8
	str	w8, [sp, #7836]                 ; 4-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2800]                 ; 16-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x25, #0, #3
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ldrb	w8, [x8]
	shl.4s	v0, v0, #31
	and	w8, w17, w8
	str	w8, [sp, #7832]                 ; 4-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2784]                 ; 16-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x30, #0, #3
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ldrb	w8, [x8]
	shl.4s	v0, v0, #31
	and	w8, w0, w8
	str	w8, [sp, #7828]                 ; 4-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2768]                 ; 16-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	mov	x27, x26
	bfxil	x8, x26, #0, #3
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ldrb	w8, [x8]
	shl.4s	v0, v0, #31
	and	w8, w1, w8
	str	w8, [sp, #7824]                 ; 4-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2752]                 ; 16-byte Spill
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #1768
	bfxil	x14, x20, #0, #3
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x28, #0, #3
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2736]                 ; 16-byte Spill
	ldrb	w15, [x9]
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x21, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w7, [x9]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2720]                 ; 16-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	mov	x26, x24
	bfxil	x9, x24, #0, #3
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ldrb	w9, [x9]
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2704]                 ; 16-byte Spill
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #1768
	ldr	x25, [sp, #12832]               ; 8-byte Reload
	bfxil	x22, x25, #0, #3
	ldrb	w22, [x22]
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x11, #0, #3
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2688]                 ; 16-byte Spill
	ldrb	w8, [x8]
	ldrb	w14, [x14]
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	and	w10, w2, w14
	str	w10, [sp, #7820]                ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2672]                 ; 16-byte Spill
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #1768
	ldr	x24, [sp, #12848]               ; 8-byte Reload
	bfxil	x14, x24, #0, #3
	ldrb	w14, [x14]
	mvni.4s	v0, #127, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #11264]                ; 16-byte Spill
	and	w10, w3, w14
	str	w10, [sp, #7816]                ; 4-byte Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #11248]                ; 16-byte Spill
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #1768
	ldr	x12, [sp, #12928]               ; 8-byte Reload
	bfxil	x14, x12, #0, #3
	ldrb	w14, [x14]
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	and	w10, w4, w14
	str	w10, [sp, #7812]                ; 4-byte Spill
	shl.4s	v0, v0, #31
	and	w10, w5, w15
	str	w10, [sp, #7808]                ; 4-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2656]                 ; 16-byte Spill
	and	w10, w16, w7
	str	w10, [sp, #7804]                ; 4-byte Spill
	and	w9, w17, w9
	str	w9, [sp, #7800]                 ; 4-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	and	w9, w0, w22
	str	w9, [sp, #7796]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	and	w8, w1, w8
	str	w8, [sp, #7792]                 ; 4-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2640]                 ; 16-byte Spill
	ldr	w8, [sp, #12976]                ; 4-byte Reload
	rbit	w8, w8
	clz	w9, w8
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	mov	x7, x23
                                        ; kill: def $w23 killed $w23 killed $x23 def $x23
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2624]                 ; 16-byte Spill
	ubfiz	x8, x23, #2, #3
	str	x8, [sp, #4456]                 ; 8-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	mov	x8, x6
                                        ; kill: def $w6 killed $w6 killed $x6 def $x6
	shl.4s	v0, v0, #31
	ubfiz	x10, x6, #2, #3
	str	x10, [sp, #4448]                ; 8-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2608]                 ; 16-byte Spill
	mov	x6, x19
                                        ; kill: def $w19 killed $w19 killed $x19 def $x19
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ubfiz	x10, x19, #2, #3
	str	x10, [sp, #4440]                ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2592]                 ; 16-byte Spill
	mov	x19, x20
                                        ; kill: def $w20 killed $w20 killed $x20 def $x20
	ubfiz	x10, x20, #2, #3
	str	x10, [sp, #4432]                ; 8-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	mov	x14, x21
                                        ; kill: def $w21 killed $w21 killed $x21 def $x21
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2576]                 ; 16-byte Spill
	ubfiz	x10, x21, #2, #3
	str	x10, [sp, #4424]                ; 8-byte Spill
	ubfiz	x10, x7, #2, #3
	str	x10, [sp, #4416]                ; 8-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ldr	x11, [sp, #12912]               ; 8-byte Reload
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4408]                ; 8-byte Spill
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4400]                ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2560]                 ; 16-byte Spill
	ldr	x11, [sp, #12896]               ; 8-byte Reload
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4392]                ; 8-byte Spill
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4384]                ; 8-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ldr	x11, [sp, #12864]               ; 8-byte Reload
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4376]                ; 8-byte Spill
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4368]                ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2544]                 ; 16-byte Spill
	ubfiz	x8, x8, #2, #3
	str	x8, [sp, #4360]                 ; 8-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ldr	x10, [sp, #12816]               ; 8-byte Reload
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4352]                 ; 8-byte Spill
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4344]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2528]                 ; 16-byte Spill
	ldr	x10, [sp, #12800]               ; 8-byte Reload
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4336]                 ; 8-byte Spill
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4328]                 ; 8-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ldr	x10, [sp, #13072]               ; 8-byte Reload
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4320]                 ; 8-byte Spill
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4312]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	ubfiz	x8, x6, #2, #3
	str	x8, [sp, #4304]                 ; 8-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2512]                 ; 16-byte Spill
	ldr	x10, [sp, #12784]               ; 8-byte Reload
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4296]                 ; 8-byte Spill
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4288]                 ; 8-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ubfiz	x8, x30, #2, #3
	str	x8, [sp, #4280]                 ; 8-byte Spill
	ubfiz	x8, x30, #2, #3
	str	x8, [sp, #4272]                 ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2496]                 ; 16-byte Spill
	ubfiz	x8, x27, #2, #3
	str	x8, [sp, #4264]                 ; 8-byte Spill
	ubfiz	x8, x27, #2, #3
	str	x8, [sp, #4256]                 ; 8-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ubfiz	x8, x19, #2, #3
	str	x8, [sp, #4248]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2480]                 ; 16-byte Spill
	ubfiz	x8, x24, #2, #3
	str	x8, [sp, #4240]                 ; 8-byte Spill
	ubfiz	x8, x24, #2, #3
	str	x8, [sp, #4232]                 ; 8-byte Spill
	ldr	q1, [sp, #4640]                 ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	ubfiz	x8, x12, #2, #3
	str	x8, [sp, #4224]                 ; 8-byte Spill
	ubfiz	x8, x12, #2, #3
	str	x8, [sp, #4216]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #4192]                 ; 16-byte Spill
	ubfiz	x8, x28, #2, #3
	str	x8, [sp, #4184]                 ; 8-byte Spill
	ubfiz	x8, x28, #2, #3
	str	x8, [sp, #4176]                 ; 8-byte Spill
	ubfiz	x8, x14, #2, #3
	str	x8, [sp, #4168]                 ; 8-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ubfiz	x8, x26, #2, #3
	str	x8, [sp, #4160]                 ; 8-byte Spill
	and	x8, x26, #0x7
	str	x8, [sp, #4152]                 ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #4128]                 ; 16-byte Spill
	ubfiz	x8, x25, #2, #3
	str	x8, [sp, #4120]                 ; 8-byte Spill
	and	x8, x25, #0x7
	str	x8, [sp, #4112]                 ; 8-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ldr	x10, [sp, #12768]               ; 8-byte Reload
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4104]                 ; 8-byte Spill
	and	x8, x10, #0x7
	str	x8, [sp, #4096]                 ; 8-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #4080]                 ; 16-byte Spill
	and	x8, x9, #0x7
	str	x8, [sp, #4072]                 ; 8-byte Spill
	and	x8, x9, #0x7
	str	x8, [sp, #4064]                 ; 8-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #4048]                 ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #4032]                 ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #4016]                 ; 16-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #4000]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3984]                 ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #11744]                ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #11728]                ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2464]                 ; 16-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2448]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2432]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2416]                 ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2400]                 ; 16-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2384]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2368]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2352]                 ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3968]                 ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3952]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3936]                 ; 16-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3920]                 ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2336]                 ; 16-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2320]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2304]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2288]                 ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2272]                 ; 16-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2256]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2240]                 ; 16-byte Spill
	str	q4, [sp, #11584]                ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2224]                 ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3904]                 ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3888]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3872]                 ; 16-byte Spill
	str	q2, [sp, #48]                   ; 16-byte Spill
	zip1.8b	v0, v2, v0
	mov.16b	v2, v6
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3856]                 ; 16-byte Spill
Lloh24:
	adrp	x6, lCPI0_13@PAGE
Lloh25:
	adrp	x7, lCPI0_14@PAGE
Lloh26:
	adrp	x19, lCPI0_15@PAGE
Lloh27:
	adrp	x12, lCPI0_16@PAGE
Lloh28:
	adrp	x15, lCPI0_17@PAGE
Lloh29:
	adrp	x10, lCPI0_18@PAGE
Lloh30:
	adrp	x11, lCPI0_19@PAGE
Lloh31:
	adrp	x30, lCPI0_20@PAGE
Lloh32:
	adrp	x14, lCPI0_21@PAGE
Lloh33:
	adrp	x28, lCPI0_22@PAGE
Lloh34:
	adrp	x8, lCPI0_23@PAGE
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #7776]                 ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	movi.2d	v22, #0000000000000000
	str	q0, [sp, #7760]                 ; 16-byte Spill
	str	q0, [sp, #7744]                 ; 16-byte Spill
	str	q0, [sp, #10960]                ; 16-byte Spill
	str	q0, [sp, #10944]                ; 16-byte Spill
	str	q0, [sp, #10928]                ; 16-byte Spill
	str	q0, [sp, #832]                  ; 16-byte Spill
	str	q0, [sp, #3840]                 ; 16-byte Spill
	str	q0, [sp, #12576]                ; 16-byte Spill
	str	q0, [sp, #12704]                ; 16-byte Spill
	str	q0, [sp, #12688]                ; 16-byte Spill
	str	q0, [sp, #12672]                ; 16-byte Spill
	str	q0, [sp, #12656]                ; 16-byte Spill
	str	q0, [sp, #9712]                 ; 16-byte Spill
	str	q0, [sp, #9696]                 ; 16-byte Spill
	str	q0, [sp, #12640]                ; 16-byte Spill
	str	q0, [sp, #12592]                ; 16-byte Spill
	str	q0, [sp, #12624]                ; 16-byte Spill
	str	q0, [sp, #12608]                ; 16-byte Spill
	str	q0, [sp, #9680]                 ; 16-byte Spill
	str	q0, [sp, #9664]                 ; 16-byte Spill
	str	q0, [sp, #9648]                 ; 16-byte Spill
	str	q0, [sp, #9632]                 ; 16-byte Spill
	str	q0, [sp, #9616]                 ; 16-byte Spill
	str	q0, [sp, #9600]                 ; 16-byte Spill
	str	q0, [sp, #7712]                 ; 16-byte Spill
	str	q0, [sp, #7728]                 ; 16-byte Spill
	str	q0, [sp, #1888]                 ; 16-byte Spill
	str	q0, [sp, #1872]                 ; 16-byte Spill
	str	q0, [sp, #1856]                 ; 16-byte Spill
	str	q0, [sp, #1840]                 ; 16-byte Spill
	str	q0, [sp, #9584]                 ; 16-byte Spill
	str	q0, [sp, #9568]                 ; 16-byte Spill
	str	q0, [sp, #9552]                 ; 16-byte Spill
	str	q0, [sp, #9536]                 ; 16-byte Spill
	str	q0, [sp, #9520]                 ; 16-byte Spill
	str	q0, [sp, #9504]                 ; 16-byte Spill
	str	q0, [sp, #1824]                 ; 16-byte Spill
	str	q0, [sp, #1808]                 ; 16-byte Spill
	str	q0, [sp, #1792]                 ; 16-byte Spill
	str	q0, [sp, #2080]                 ; 16-byte Spill
	str	q0, [sp, #9488]                 ; 16-byte Spill
	str	q0, [sp, #9472]                 ; 16-byte Spill
	str	q0, [sp, #9456]                 ; 16-byte Spill
	str	q0, [sp, #9440]                 ; 16-byte Spill
	str	q0, [sp, #9424]                 ; 16-byte Spill
	str	q0, [sp, #9408]                 ; 16-byte Spill
	str	q0, [sp, #9392]                 ; 16-byte Spill
	str	q0, [sp, #9376]                 ; 16-byte Spill
	str	q0, [sp, #1776]                 ; 16-byte Spill
	str	q0, [sp, #1760]                 ; 16-byte Spill
	str	q0, [sp, #1744]                 ; 16-byte Spill
	str	q0, [sp, #1728]                 ; 16-byte Spill
	str	q0, [sp, #9360]                 ; 16-byte Spill
	str	q0, [sp, #9344]                 ; 16-byte Spill
	str	q0, [sp, #9328]                 ; 16-byte Spill
	str	q0, [sp, #9312]                 ; 16-byte Spill
	str	q0, [sp, #7696]                 ; 16-byte Spill
	str	q0, [sp, #7680]                 ; 16-byte Spill
	str	q0, [sp, #7664]                 ; 16-byte Spill
	str	q0, [sp, #7648]                 ; 16-byte Spill
	str	q0, [sp, #9296]                 ; 16-byte Spill
	str	q0, [sp, #9280]                 ; 16-byte Spill
	str	q0, [sp, #9264]                 ; 16-byte Spill
	str	q0, [sp, #9248]                 ; 16-byte Spill
	str	q0, [sp, #9232]                 ; 16-byte Spill
	str	q0, [sp, #9216]                 ; 16-byte Spill
	str	q0, [sp, #7536]                 ; 16-byte Spill
	str	q0, [sp, #7520]                 ; 16-byte Spill
	str	q0, [sp, #1712]                 ; 16-byte Spill
	str	q0, [sp, #2064]                 ; 16-byte Spill
	str	q0, [sp, #2048]                 ; 16-byte Spill
	str	q0, [sp, #2032]                 ; 16-byte Spill
	str	q0, [sp, #9200]                 ; 16-byte Spill
	str	q0, [sp, #1696]                 ; 16-byte Spill
	str	q0, [sp, #9184]                 ; 16-byte Spill
	str	q0, [sp, #9168]                 ; 16-byte Spill
	str	q0, [sp, #7632]                 ; 16-byte Spill
	str	q0, [sp, #7552]                 ; 16-byte Spill
	str	q0, [sp, #1680]                 ; 16-byte Spill
	str	q0, [sp, #1664]                 ; 16-byte Spill
	str	q0, [sp, #9152]                 ; 16-byte Spill
	str	q0, [sp, #9136]                 ; 16-byte Spill
	str	q0, [sp, #9120]                 ; 16-byte Spill
	str	q0, [sp, #9104]                 ; 16-byte Spill
	str	q0, [sp, #9088]                 ; 16-byte Spill
	str	q0, [sp, #9072]                 ; 16-byte Spill
	str	q0, [sp, #9056]                 ; 16-byte Spill
	str	q0, [sp, #9040]                 ; 16-byte Spill
	str	q0, [sp, #1648]                 ; 16-byte Spill
	str	q0, [sp, #1632]                 ; 16-byte Spill
	str	q0, [sp, #1616]                 ; 16-byte Spill
	str	q0, [sp, #1600]                 ; 16-byte Spill
	str	q0, [sp, #9024]                 ; 16-byte Spill
	str	q0, [sp, #9008]                 ; 16-byte Spill
	str	q0, [sp, #8992]                 ; 16-byte Spill
	str	q0, [sp, #8976]                 ; 16-byte Spill
	str	q0, [sp, #7616]                 ; 16-byte Spill
	str	q0, [sp, #7600]                 ; 16-byte Spill
	str	q0, [sp, #7584]                 ; 16-byte Spill
	str	q0, [sp, #7568]                 ; 16-byte Spill
	str	q0, [sp, #1584]                 ; 16-byte Spill
	str	q0, [sp, #1568]                 ; 16-byte Spill
	str	q0, [sp, #3824]                 ; 16-byte Spill
	str	q0, [sp, #1552]                 ; 16-byte Spill
	str	q0, [sp, #3808]                 ; 16-byte Spill
	str	q0, [sp, #3792]                 ; 16-byte Spill
	str	q0, [sp, #3776]                 ; 16-byte Spill
	str	q0, [sp, #3760]                 ; 16-byte Spill
	str	q0, [sp, #1536]                 ; 16-byte Spill
	str	q0, [sp, #10448]                ; 16-byte Spill
	str	q0, [sp, #10432]                ; 16-byte Spill
	str	q0, [sp, #10416]                ; 16-byte Spill
	str	q0, [sp, #3744]                 ; 16-byte Spill
	str	q0, [sp, #3728]                 ; 16-byte Spill
	str	q0, [sp, #3712]                 ; 16-byte Spill
	str	q0, [sp, #3696]                 ; 16-byte Spill
	str	q0, [sp, #3680]                 ; 16-byte Spill
	str	q0, [sp, #3664]                 ; 16-byte Spill
	str	q0, [sp, #3648]                 ; 16-byte Spill
	str	q0, [sp, #3632]                 ; 16-byte Spill
	str	q0, [sp, #10400]                ; 16-byte Spill
	str	q0, [sp, #10384]                ; 16-byte Spill
	str	q0, [sp, #10368]                ; 16-byte Spill
	str	q0, [sp, #10352]                ; 16-byte Spill
	str	q0, [sp, #3616]                 ; 16-byte Spill
	str	q0, [sp, #3600]                 ; 16-byte Spill
	str	q0, [sp, #3584]                 ; 16-byte Spill
	str	q0, [sp, #3568]                 ; 16-byte Spill
	str	q0, [sp, #5520]                 ; 16-byte Spill
	str	q0, [sp, #5536]                 ; 16-byte Spill
	str	q0, [sp, #5504]                 ; 16-byte Spill
	str	q0, [sp, #5488]                 ; 16-byte Spill
	str	q0, [sp, #3552]                 ; 16-byte Spill
	str	q0, [sp, #3536]                 ; 16-byte Spill
	str	q0, [sp, #3520]                 ; 16-byte Spill
	str	q0, [sp, #3504]                 ; 16-byte Spill
	str	q0, [sp, #3488]                 ; 16-byte Spill
	str	q0, [sp, #3472]                 ; 16-byte Spill
	str	q0, [sp, #5472]                 ; 16-byte Spill
	str	q0, [sp, #5456]                 ; 16-byte Spill
	str	q0, [sp, #10336]                ; 16-byte Spill
	str	q0, [sp, #10320]                ; 16-byte Spill
	str	q0, [sp, #10304]                ; 16-byte Spill
	str	q0, [sp, #10288]                ; 16-byte Spill
	str	q0, [sp, #6192]                 ; 16-byte Spill
	str	q0, [sp, #6176]                 ; 16-byte Spill
	str	q0, [sp, #6160]                 ; 16-byte Spill
	str	q0, [sp, #6144]                 ; 16-byte Spill
	str	q0, [sp, #5424]                 ; 16-byte Spill
	str	q0, [sp, #5440]                 ; 16-byte Spill
	str	q0, [sp, #10272]                ; 16-byte Spill
	str	q0, [sp, #10256]                ; 16-byte Spill
	str	q0, [sp, #6128]                 ; 16-byte Spill
	str	q0, [sp, #6112]                 ; 16-byte Spill
	str	q0, [sp, #6096]                 ; 16-byte Spill
	str	q0, [sp, #6080]                 ; 16-byte Spill
	str	q0, [sp, #5392]                 ; 16-byte Spill
	str	q0, [sp, #5408]                 ; 16-byte Spill
	str	q0, [sp, #5376]                 ; 16-byte Spill
	str	q0, [sp, #1520]                 ; 16-byte Spill
	str	q0, [sp, #10240]                ; 16-byte Spill
	str	q0, [sp, #10224]                ; 16-byte Spill
	str	q0, [sp, #8960]                 ; 16-byte Spill
	str	q0, [sp, #8944]                 ; 16-byte Spill
	str	q0, [sp, #8928]                 ; 16-byte Spill
	str	q0, [sp, #8912]                 ; 16-byte Spill
	str	q0, [sp, #8896]                 ; 16-byte Spill
	str	q0, [sp, #8880]                 ; 16-byte Spill
	str	q0, [sp, #8864]                 ; 16-byte Spill
	str	q0, [sp, #11216]                ; 16-byte Spill
	str	q0, [sp, #1504]                 ; 16-byte Spill
	str	q0, [sp, #1488]                 ; 16-byte Spill
	str	q0, [sp, #8848]                 ; 16-byte Spill
	str	q0, [sp, #8832]                 ; 16-byte Spill
	str	q0, [sp, #10912]                ; 16-byte Spill
	str	q0, [sp, #10896]                ; 16-byte Spill
	str	q0, [sp, #10800]                ; 16-byte Spill
	str	q0, [sp, #1360]                 ; 16-byte Spill
	str	q0, [sp, #10832]                ; 16-byte Spill
	str	q0, [sp, #10848]                ; 16-byte Spill
	str	q0, [sp, #7504]                 ; 16-byte Spill
	str	q0, [sp, #7328]                 ; 16-byte Spill
	str	q0, [sp, #7104]                 ; 16-byte Spill
	str	q0, [sp, #6992]                 ; 16-byte Spill
	str	q0, [sp, #10880]                ; 16-byte Spill
	str	q0, [sp, #10864]                ; 16-byte Spill
	str	q0, [sp, #11200]                ; 16-byte Spill
	str	q0, [sp, #11184]                ; 16-byte Spill
	str	q0, [sp, #11168]                ; 16-byte Spill
	str	q0, [sp, #11152]                ; 16-byte Spill
	str	q0, [sp, #11136]                ; 16-byte Spill
	str	q0, [sp, #11120]                ; 16-byte Spill
	str	q0, [sp, #1472]                 ; 16-byte Spill
	str	q0, [sp, #1456]                 ; 16-byte Spill
	str	q0, [sp, #1440]                 ; 16-byte Spill
	str	q0, [sp, #1424]                 ; 16-byte Spill
	str	q0, [sp, #11104]                ; 16-byte Spill
	str	q0, [sp, #11088]                ; 16-byte Spill
	str	q0, [sp, #7488]                 ; 16-byte Spill
	str	q0, [sp, #7472]                 ; 16-byte Spill
	str	q0, [sp, #7456]                 ; 16-byte Spill
	str	q0, [sp, #7440]                 ; 16-byte Spill
	str	q0, [sp, #7424]                 ; 16-byte Spill
	str	q0, [sp, #7408]                 ; 16-byte Spill
	str	q0, [sp, #12256]                ; 16-byte Spill
	str	q0, [sp, #12240]                ; 16-byte Spill
	str	q0, [sp, #7344]                 ; 16-byte Spill
	str	q0, [sp, #7376]                 ; 16-byte Spill
	str	q0, [sp, #7392]                 ; 16-byte Spill
	str	q0, [sp, #7360]                 ; 16-byte Spill
	str	q0, [sp, #12224]                ; 16-byte Spill
	str	q0, [sp, #12208]                ; 16-byte Spill
	str	q0, [sp, #12192]                ; 16-byte Spill
	str	q0, [sp, #12176]                ; 16-byte Spill
	str	q0, [sp, #12160]                ; 16-byte Spill
	str	q0, [sp, #12144]                ; 16-byte Spill
	str	q0, [sp, #7312]                 ; 16-byte Spill
	str	q0, [sp, #7296]                 ; 16-byte Spill
	str	q0, [sp, #1408]                 ; 16-byte Spill
	str	q0, [sp, #1392]                 ; 16-byte Spill
	str	q0, [sp, #1376]                 ; 16-byte Spill
	str	q0, [sp, #2016]                 ; 16-byte Spill
	str	q0, [sp, #7280]                 ; 16-byte Spill
	str	q0, [sp, #7264]                 ; 16-byte Spill
	str	q0, [sp, #7248]                 ; 16-byte Spill
	str	q0, [sp, #7232]                 ; 16-byte Spill
	str	q0, [sp, #7216]                 ; 16-byte Spill
	str	q0, [sp, #7200]                 ; 16-byte Spill
	str	q0, [sp, #6064]                 ; 16-byte Spill
	str	q0, [sp, #6048]                 ; 16-byte Spill
	str	q0, [sp, #7168]                 ; 16-byte Spill
	str	q0, [sp, #7152]                 ; 16-byte Spill
	str	q0, [sp, #10816]                ; 16-byte Spill
	str	q0, [sp, #7184]                 ; 16-byte Spill
	str	q0, [sp, #6032]                 ; 16-byte Spill
	str	q0, [sp, #6016]                 ; 16-byte Spill
	str	q0, [sp, #6000]                 ; 16-byte Spill
	str	q0, [sp, #5984]                 ; 16-byte Spill
	str	q0, [sp, #5968]                 ; 16-byte Spill
	str	q0, [sp, #5952]                 ; 16-byte Spill
	str	q0, [sp, #7136]                 ; 16-byte Spill
	str	q0, [sp, #7120]                 ; 16-byte Spill
	str	q0, [sp, #8816]                 ; 16-byte Spill
	str	q0, [sp, #1344]                 ; 16-byte Spill
	str	q0, [sp, #8800]                 ; 16-byte Spill
	str	q0, [sp, #8784]                 ; 16-byte Spill
	str	q0, [sp, #7088]                 ; 16-byte Spill
	str	q0, [sp, #7072]                 ; 16-byte Spill
	str	q0, [sp, #7056]                 ; 16-byte Spill
	str	q0, [sp, #7040]                 ; 16-byte Spill
	str	q0, [sp, #7024]                 ; 16-byte Spill
	str	q0, [sp, #7008]                 ; 16-byte Spill
	str	q0, [sp, #10576]                ; 16-byte Spill
	str	q0, [sp, #12560]                ; 16-byte Spill
	str	q0, [sp, #12544]                ; 16-byte Spill
	str	q0, [sp, #12976]                ; 16-byte Spill
	str	q0, [sp, #12960]                ; 16-byte Spill
	str	q0, [sp, #12944]                ; 16-byte Spill
	str	q0, [sp, #10560]                ; 16-byte Spill
	str	q0, [sp, #10544]                ; 16-byte Spill
	str	q0, [sp, #10528]                ; 16-byte Spill
	str	q0, [sp, #10512]                ; 16-byte Spill
	str	q0, [sp, #10496]                ; 16-byte Spill
	str	q0, [sp, #10480]                ; 16-byte Spill
	str	q0, [sp, #5360]                 ; 16-byte Spill
	str	q0, [sp, #10208]                ; 16-byte Spill
	str	q0, [sp, #10192]                ; 16-byte Spill
	str	q0, [sp, #1328]                 ; 16-byte Spill
	str	q0, [sp, #1312]                 ; 16-byte Spill
	str	q0, [sp, #10464]                ; 16-byte Spill
	str	q0, [sp, #5344]                 ; 16-byte Spill
	str	q0, [sp, #5328]                 ; 16-byte Spill
	str	q0, [sp, #5312]                 ; 16-byte Spill
	str	q0, [sp, #5296]                 ; 16-byte Spill
	str	q0, [sp, #5280]                 ; 16-byte Spill
	str	q0, [sp, #5264]                 ; 16-byte Spill
	str	q0, [sp, #3456]                 ; 16-byte Spill
	str	q0, [sp, #3440]                 ; 16-byte Spill
	str	q0, [sp, #3424]                 ; 16-byte Spill
	str	q0, [sp, #3408]                 ; 16-byte Spill
	str	q0, [sp, #5248]                 ; 16-byte Spill
	str	q0, [sp, #5232]                 ; 16-byte Spill
	str	q0, [sp, #10176]                ; 16-byte Spill
	str	q0, [sp, #10160]                ; 16-byte Spill
	str	q0, [sp, #3392]                 ; 16-byte Spill
	str	q0, [sp, #3376]                 ; 16-byte Spill
	str	q0, [sp, #3360]                 ; 16-byte Spill
	str	q0, [sp, #3344]                 ; 16-byte Spill
	str	q0, [sp, #5168]                 ; 16-byte Spill
	str	q0, [sp, #5216]                 ; 16-byte Spill
	str	q0, [sp, #5200]                 ; 16-byte Spill
	str	q0, [sp, #5184]                 ; 16-byte Spill
	str	q0, [sp, #10144]                ; 16-byte Spill
	str	q0, [sp, #10128]                ; 16-byte Spill
	str	q0, [sp, #6320]                 ; 16-byte Spill
	str	q0, [sp, #6304]                 ; 16-byte Spill
	str	q0, [sp, #6288]                 ; 16-byte Spill
	str	q0, [sp, #6272]                 ; 16-byte Spill
	str	q0, [sp, #6256]                 ; 16-byte Spill
	str	q0, [sp, #5152]                 ; 16-byte Spill
	str	q0, [sp, #10112]                ; 16-byte Spill
	str	q0, [sp, #10096]                ; 16-byte Spill
	str	q0, [sp, #10080]                ; 16-byte Spill
	str	q0, [sp, #6240]                 ; 16-byte Spill
	str	q0, [sp, #6224]                 ; 16-byte Spill
	str	q0, [sp, #6208]                 ; 16-byte Spill
	str	q0, [sp, #8768]                 ; 16-byte Spill
	str	q0, [sp, #8752]                 ; 16-byte Spill
	str	q0, [sp, #8736]                 ; 16-byte Spill
	str	q0, [sp, #5136]                 ; 16-byte Spill
	str	q0, [sp, #5120]                 ; 16-byte Spill
	str	q0, [sp, #10064]                ; 16-byte Spill
	str	q0, [sp, #1296]                 ; 16-byte Spill
	str	q0, [sp, #8720]                 ; 16-byte Spill
	str	q0, [sp, #8704]                 ; 16-byte Spill
	str	q0, [sp, #8688]                 ; 16-byte Spill
	str	q0, [sp, #8672]                 ; 16-byte Spill
	str	q0, [sp, #8656]                 ; 16-byte Spill
	str	q0, [sp, #10784]                ; 16-byte Spill
	str	q0, [sp, #10768]                ; 16-byte Spill
	str	q0, [sp, #6976]                 ; 16-byte Spill
	str	q0, [sp, #1280]                 ; 16-byte Spill
	str	q0, [sp, #2000]                 ; 16-byte Spill
	str	q0, [sp, #1264]                 ; 16-byte Spill
	str	q0, [sp, #8640]                 ; 16-byte Spill
	str	q0, [sp, #6928]                 ; 16-byte Spill
	str	q0, [sp, #6896]                 ; 16-byte Spill
	str	q0, [sp, #6960]                 ; 16-byte Spill
	str	q0, [sp, #10752]                ; 16-byte Spill
	str	q0, [sp, #6944]                 ; 16-byte Spill
	str	q0, [sp, #8624]                 ; 16-byte Spill
	str	q0, [sp, #8608]                 ; 16-byte Spill
	str	q0, [sp, #8592]                 ; 16-byte Spill
	str	q0, [sp, #8576]                 ; 16-byte Spill
	str	q0, [sp, #8560]                 ; 16-byte Spill
	str	q0, [sp, #8544]                 ; 16-byte Spill
	str	q0, [sp, #6912]                 ; 16-byte Spill
	str	q0, [sp, #1248]                 ; 16-byte Spill
	str	q0, [sp, #1232]                 ; 16-byte Spill
	str	q0, [sp, #1216]                 ; 16-byte Spill
	str	q0, [sp, #1984]                 ; 16-byte Spill
	str	q0, [sp, #8528]                 ; 16-byte Spill
	str	q0, [sp, #12864]                ; 16-byte Spill
	str	q0, [sp, #12848]                ; 16-byte Spill
	str	q0, [sp, #12832]                ; 16-byte Spill
	str	q0, [sp, #12816]                ; 16-byte Spill
	str	q0, [sp, #12800]                ; 16-byte Spill
	str	q0, [sp, #1152]                 ; 16-byte Spill
	str	q0, [sp, #1200]                 ; 16-byte Spill
	str	q0, [sp, #1184]                 ; 16-byte Spill
	str	q0, [sp, #1168]                 ; 16-byte Spill
	str	q0, [sp, #12784]                ; 16-byte Spill
	str	q0, [sp, #12768]                ; 16-byte Spill
	str	q0, [sp, #12752]                ; 16-byte Spill
	str	q0, [sp, #6880]                 ; 16-byte Spill
	str	q0, [sp, #6864]                 ; 16-byte Spill
	str	q0, [sp, #6848]                 ; 16-byte Spill
	str	q0, [sp, #6832]                 ; 16-byte Spill
	str	q0, [sp, #6816]                 ; 16-byte Spill
	str	q0, [sp, #1136]                 ; 16-byte Spill
	str	q0, [sp, #6752]                 ; 16-byte Spill
	str	q0, [sp, #1120]                 ; 16-byte Spill
	str	q0, [sp, #6800]                 ; 16-byte Spill
	str	q0, [sp, #6784]                 ; 16-byte Spill
	str	q0, [sp, #6768]                 ; 16-byte Spill
	str	q0, [sp, #6736]                 ; 16-byte Spill
	str	q0, [sp, #3328]                 ; 16-byte Spill
	str	q0, [sp, #3312]                 ; 16-byte Spill
	str	q0, [sp, #3296]                 ; 16-byte Spill
	str	q0, [sp, #3280]                 ; 16-byte Spill
	str	q0, [sp, #3264]                 ; 16-byte Spill
	str	q0, [sp, #6720]                 ; 16-byte Spill
	str	q0, [sp, #4784]                 ; 16-byte Spill
	str	q0, [sp, #4768]                 ; 16-byte Spill
	str	q0, [sp, #10048]                ; 16-byte Spill
	str	q0, [sp, #3248]                 ; 16-byte Spill
	str	q0, [sp, #3232]                 ; 16-byte Spill
	str	q0, [sp, #3216]                 ; 16-byte Spill
	str	q0, [sp, #5056]                 ; 16-byte Spill
	str	q0, [sp, #5040]                 ; 16-byte Spill
	str	q0, [sp, #5104]                 ; 16-byte Spill
	str	q0, [sp, #5088]                 ; 16-byte Spill
	str	q0, [sp, #5072]                 ; 16-byte Spill
	str	q0, [sp, #10032]                ; 16-byte Spill
	str	q0, [sp, #5936]                 ; 16-byte Spill
	str	q0, [sp, #5920]                 ; 16-byte Spill
	str	q0, [sp, #5904]                 ; 16-byte Spill
	str	q0, [sp, #5888]                 ; 16-byte Spill
	str	q0, [sp, #5872]                 ; 16-byte Spill
	str	q0, [sp, #5856]                 ; 16-byte Spill
	str	q0, [sp, #8512]                 ; 16-byte Spill
	str	q0, [sp, #8496]                 ; 16-byte Spill
	str	q0, [sp, #8480]                 ; 16-byte Spill
	str	q0, [sp, #11536]                ; 16-byte Spill
	str	q0, [sp, #5840]                 ; 16-byte Spill
	str	q0, [sp, #5824]                 ; 16-byte Spill
	str	q0, [sp, #6704]                 ; 16-byte Spill
	str	q0, [sp, #6688]                 ; 16-byte Spill
	str	q0, [sp, #6672]                 ; 16-byte Spill
	str	q0, [sp, #6656]                 ; 16-byte Spill
	str	q0, [sp, #6640]                 ; 16-byte Spill
	str	q0, [sp, #6624]                 ; 16-byte Spill
	str	q0, [sp, #12528]                ; 16-byte Spill
	str	q0, [sp, #12928]                ; 16-byte Spill
	str	q0, [sp, #12912]                ; 16-byte Spill
	str	q0, [sp, #12896]                ; 16-byte Spill
	str	q0, [sp, #6608]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q0, [sp, #5808]                 ; 16-byte Spill
	str	q0, [sp, #5792]                 ; 16-byte Spill
	str	q0, [sp, #5776]                 ; 16-byte Spill
	str	q0, [sp, #5760]                 ; 16-byte Spill
	str	q0, [sp, #5744]                 ; 16-byte Spill
	str	q0, [sp, #12512]                ; 16-byte Spill
	str	q0, [sp, #4752]                 ; 16-byte Spill
	str	q0, [sp, #4736]                 ; 16-byte Spill
	str	q0, [sp, #10016]                ; 16-byte Spill
	str	q0, [sp, #5728]                 ; 16-byte Spill
	str	q0, [sp, #5712]                 ; 16-byte Spill
	str	q0, [sp, #5696]                 ; 16-byte Spill
	str	q0, [sp, #5024]                 ; 16-byte Spill
	str	q0, [sp, #5008]                 ; 16-byte Spill
	str	q0, [sp, #4992]                 ; 16-byte Spill
	str	q0, [sp, #4976]                 ; 16-byte Spill
	str	q0, [sp, #4960]                 ; 16-byte Spill
	str	q0, [sp, #10000]                ; 16-byte Spill
	str	q0, [sp, #8464]                 ; 16-byte Spill
	str	q0, [sp, #8448]                 ; 16-byte Spill
	str	q0, [sp, #4912]                 ; 16-byte Spill
	str	q0, [sp, #4896]                 ; 16-byte Spill
	str	q0, [sp, #4944]                 ; 16-byte Spill
	str	q0, [sp, #4928]                 ; 16-byte Spill
	str	q0, [sp, #8432]                 ; 16-byte Spill
	str	q0, [sp, #8416]                 ; 16-byte Spill
	str	q0, [sp, #8400]                 ; 16-byte Spill
	str	q0, [sp, #8384]                 ; 16-byte Spill
	str	q0, [sp, #8368]                 ; 16-byte Spill
	str	q0, [sp, #8352]                 ; 16-byte Spill
	str	q0, [sp, #10736]                ; 16-byte Spill
	str	q0, [sp, #6592]                 ; 16-byte Spill
	str	q0, [sp, #1104]                 ; 16-byte Spill
	str	q0, [sp, #11520]                ; 16-byte Spill
	str	q0, [sp, #11504]                ; 16-byte Spill
	str	q0, [sp, #11488]                ; 16-byte Spill
	str	q0, [sp, #6576]                 ; 16-byte Spill
	str	q0, [sp, #6560]                 ; 16-byte Spill
	str	q0, [sp, #10720]                ; 16-byte Spill
	str	q0, [sp, #10704]                ; 16-byte Spill
	str	q0, [sp, #10688]                ; 16-byte Spill
	str	q0, [sp, #10672]                ; 16-byte Spill
	str	q0, [sp, #8336]                 ; 16-byte Spill
	str	q0, [sp, #8320]                 ; 16-byte Spill
	str	q0, [sp, #8304]                 ; 16-byte Spill
	str	q0, [sp, #8288]                 ; 16-byte Spill
	str	q0, [sp, #8272]                 ; 16-byte Spill
	str	q0, [sp, #8256]                 ; 16-byte Spill
	movi.2d	v17, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v23, #0000000000000000
	str	q0, [sp, #8240]                 ; 16-byte Spill
	str	q0, [sp, #8224]                 ; 16-byte Spill
	str	q0, [sp, #6432]                 ; 16-byte Spill
	str	q0, [sp, #6544]                 ; 16-byte Spill
	str	q0, [sp, #6528]                 ; 16-byte Spill
	str	q0, [sp, #6512]                 ; 16-byte Spill
	str	q0, [sp, #6496]                 ; 16-byte Spill
	str	q0, [sp, #6480]                 ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	movi.2d	v13, #0000000000000000
	movi.2d	v27, #0000000000000000
	str	q0, [sp, #6464]                 ; 16-byte Spill
	str	q0, [sp, #6448]                 ; 16-byte Spill
	str	q0, [sp, #6416]                 ; 16-byte Spill
	str	q0, [sp, #12368]                ; 16-byte Spill
	str	q0, [sp, #12496]                ; 16-byte Spill
	str	q0, [sp, #12480]                ; 16-byte Spill
	str	q0, [sp, #12464]                ; 16-byte Spill
	str	q0, [sp, #12448]                ; 16-byte Spill
	str	q0, [sp, #13072]                ; 16-byte Spill
	str	q0, [sp, #9984]                 ; 16-byte Spill
	str	q0, [sp, #12432]                ; 16-byte Spill
	str	q0, [sp, #12384]                ; 16-byte Spill
	str	q0, [sp, #12416]                ; 16-byte Spill
	str	q0, [sp, #12400]                ; 16-byte Spill
	str	q0, [sp, #12352]                ; 16-byte Spill
	str	q0, [sp, #9968]                 ; 16-byte Spill
	str	q0, [sp, #10656]                ; 16-byte Spill
	str	q0, [sp, #4880]                 ; 16-byte Spill
	str	q0, [sp, #1088]                 ; 16-byte Spill
	str	q0, [sp, #9952]                 ; 16-byte Spill
	str	q0, [sp, #9936]                 ; 16-byte Spill
	str	q0, [sp, #1072]                 ; 16-byte Spill
	str	q0, [sp, #10640]                ; 16-byte Spill
	str	q0, [sp, #10624]                ; 16-byte Spill
	str	q0, [sp, #1056]                 ; 16-byte Spill
	str	q0, [sp, #9920]                 ; 16-byte Spill
	str	q0, [sp, #9904]                 ; 16-byte Spill
	str	q0, [sp, #9888]                 ; 16-byte Spill
	str	q0, [sp, #11408]                ; 16-byte Spill
	str	q0, [sp, #6400]                 ; 16-byte Spill
	str	q0, [sp, #1040]                 ; 16-byte Spill
	str	q0, [sp, #11072]                ; 16-byte Spill
	str	q0, [sp, #11056]                ; 16-byte Spill
	str	q0, [sp, #9872]                 ; 16-byte Spill
	str	q0, [sp, #10608]                ; 16-byte Spill
	str	q0, [sp, #4864]                 ; 16-byte Spill
	stp	q0, q0, [sp, #1008]             ; 32-byte Folded Spill
	str	q0, [sp, #9856]                 ; 16-byte Spill
	str	q0, [sp, #9840]                 ; 16-byte Spill
	str	q0, [sp, #11040]                ; 16-byte Spill
	str	q0, [sp, #10592]                ; 16-byte Spill
	str	q0, [sp, #4848]                 ; 16-byte Spill
	str	q0, [sp, #9824]                 ; 16-byte Spill
	str	q0, [sp, #9808]                 ; 16-byte Spill
	str	q0, [sp, #11392]                ; 16-byte Spill
	str	q0, [sp, #6384]                 ; 16-byte Spill
	str	q0, [sp, #11024]                ; 16-byte Spill
	str	q0, [sp, #11008]                ; 16-byte Spill
Lloh35:
	adrp	x9, lCPI0_12@PAGE
Lloh36:
	ldr	q0, [x9, lCPI0_12@PAGEOFF]
	str	q0, [sp, #2144]                 ; 16-byte Spill
Lloh37:
	ldr	q0, [x6, lCPI0_13@PAGEOFF]
	str	q0, [sp, #2128]                 ; 16-byte Spill
Lloh38:
	ldr	q0, [x7, lCPI0_14@PAGEOFF]
	str	q0, [sp, #2112]                 ; 16-byte Spill
Lloh39:
	ldr	q0, [x19, lCPI0_15@PAGEOFF]
	str	q0, [sp, #2096]                 ; 16-byte Spill
Lloh40:
	ldr	q0, [x8, lCPI0_23@PAGEOFF]
	str	q0, [sp, #992]                  ; 16-byte Spill
Lloh41:
	ldr	q0, [x12, lCPI0_16@PAGEOFF]
	str	q0, [sp, #144]                  ; 16-byte Spill
Lloh42:
	ldr	q0, [x15, lCPI0_17@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Spill
Lloh43:
	ldr	q0, [x30, lCPI0_20@PAGEOFF]
	str	q0, [sp, #976]                  ; 16-byte Spill
Lloh44:
	ldr	q0, [x14, lCPI0_21@PAGEOFF]
	str	q0, [sp, #960]                  ; 16-byte Spill
Lloh45:
	ldr	q0, [x28, lCPI0_22@PAGEOFF]
	str	q0, [sp, #944]                  ; 16-byte Spill
Lloh46:
	ldr	q0, [x10, lCPI0_18@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Spill
Lloh47:
	ldr	q0, [x11, lCPI0_19@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Spill
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	ldr	q0, [sp, #3024]                 ; 16-byte Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #3008]                 ; 16-byte Spill
	ldr	q4, [sp, #12272]                ; 16-byte Reload
	ldr	q0, [sp, #3056]                 ; 16-byte Reload
	add.2d	v0, v0, v4
	str	q0, [sp, #2992]                 ; 16-byte Spill
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	add.2d	v3, v3, v0
	str	q3, [sp, #2976]                 ; 16-byte Spill
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	ldr	q5, [sp, #3072]                 ; 16-byte Reload
	add.2d	v5, v5, v3
	str	q5, [sp, #2960]                 ; 16-byte Spill
	ldr	q5, [sp, #3152]                 ; 16-byte Reload
	add.2d	v1, v5, v1
	str	q1, [sp, #2208]                 ; 16-byte Spill
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	str	q1, [sp, #2192]                 ; 16-byte Spill
	ldr	q1, [sp, #3168]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	str	q0, [sp, #2176]                 ; 16-byte Spill
	ldr	q0, [sp, #3200]                 ; 16-byte Reload
	add.2d	v0, v0, v3
	str	q0, [sp, #2160]                 ; 16-byte Spill
	movi.2d	v20, #0000000000000000
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #4800]                 ; 16-byte Spill
	str	q0, [sp, #8016]                 ; 16-byte Spill
	str	q0, [sp, #8000]                 ; 16-byte Spill
	str	q0, [sp, #7984]                 ; 16-byte Spill
	str	q0, [sp, #7968]                 ; 16-byte Spill
	str	q0, [sp, #10992]                ; 16-byte Spill
	str	q0, [sp, #7952]                 ; 16-byte Spill
	str	q0, [sp, #4832]                 ; 16-byte Spill
	str	q0, [sp, #4816]                 ; 16-byte Spill
	str	q0, [sp, #9792]                 ; 16-byte Spill
	str	q0, [sp, #8208]                 ; 16-byte Spill
	str	q0, [sp, #8192]                 ; 16-byte Spill
	str	q0, [sp, #8176]                 ; 16-byte Spill
	str	q0, [sp, #8160]                 ; 16-byte Spill
	str	q0, [sp, #8144]                 ; 16-byte Spill
	str	q0, [sp, #8128]                 ; 16-byte Spill
	str	q0, [sp, #8112]                 ; 16-byte Spill
	str	q0, [sp, #8096]                 ; 16-byte Spill
	str	q0, [sp, #11376]                ; 16-byte Spill
	str	q0, [sp, #6368]                 ; 16-byte Spill
	stp	q0, q0, [sp, #912]              ; 32-byte Folded Spill
	stp	q0, q0, [sp, #880]              ; 32-byte Folded Spill
	str	q0, [sp, #1968]                 ; 16-byte Spill
	str	q0, [sp, #12128]                ; 16-byte Spill
	str	q0, [sp, #12112]                ; 16-byte Spill
	str	q0, [sp, #12096]                ; 16-byte Spill
	str	q0, [sp, #12080]                ; 16-byte Spill
	str	q0, [sp, #12064]                ; 16-byte Spill
	str	q0, [sp, #12048]                ; 16-byte Spill
	str	q0, [sp, #12032]                ; 16-byte Spill
	str	q0, [sp, #12016]                ; 16-byte Spill
	str	q0, [sp, #6352]                 ; 16-byte Spill
	str	q0, [sp, #6336]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	stp	q0, q0, [sp, #848]              ; 32-byte Folded Spill
	str	q0, [sp, #12000]                ; 16-byte Spill
	str	q0, [sp, #11984]                ; 16-byte Spill
	str	q0, [sp, #11968]                ; 16-byte Spill
	str	q0, [sp, #11952]                ; 16-byte Spill
	str	q0, [sp, #11936]                ; 16-byte Spill
	str	q0, [sp, #11920]                ; 16-byte Spill
	str	q0, [sp, #11904]                ; 16-byte Spill
	str	q0, [sp, #11888]                ; 16-byte Spill
	str	q0, [sp, #11472]                ; 16-byte Spill
	str	q0, [sp, #11456]                ; 16-byte Spill
	str	q0, [sp, #11440]                ; 16-byte Spill
	str	q0, [sp, #11424]                ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v1, #0000000000000000
	ldr	x27, [sp, #11368]               ; 8-byte Reload
	ldr	x26, [sp, #11560]               ; 8-byte Reload
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	str	q2, [sp, #13296]                ; 16-byte Spill
	str	q25, [sp, #13152]               ; 16-byte Spill
	b	LBB0_92
LBB0_90:                                ;   in Loop: Header=BB0_92 Depth=1
	ldp	q29, q21, [sp, #736]            ; 32-byte Folded Reload
LBB0_91:                                ; %direct.false900
                                        ;   in Loop: Header=BB0_92 Depth=1
	add.2d	v29, v29, v10
	ldp	q1, q0, [sp, #704]              ; 32-byte Folded Reload
	add.2d	v0, v0, v15
	add.2d	v1, v1, v8
	ldr	q3, [sp, #13312]                ; 16-byte Reload
	add.2d	v21, v21, v3
	fmov	x8, d21
	cmp	x8, #2
	b.ge	LBB0_1471
LBB0_92:                                ; %direct.true362
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_95 Depth 2
                                        ;     Child Loop BB0_131 Depth 2
                                        ;     Child Loop BB0_167 Depth 2
                                        ;       Child Loop BB0_170 Depth 3
                                        ;     Child Loop BB0_225 Depth 2
                                        ;     Child Loop BB0_258 Depth 2
                                        ;     Child Loop BB0_280 Depth 2
                                        ;     Child Loop BB0_313 Depth 2
                                        ;     Child Loop BB0_349 Depth 2
                                        ;     Child Loop BB0_369 Depth 2
                                        ;     Child Loop BB0_1135 Depth 2
                                        ;     Child Loop BB0_1153 Depth 2
                                        ;     Child Loop BB0_1187 Depth 2
                                        ;     Child Loop BB0_1221 Depth 2
                                        ;     Child Loop BB0_410 Depth 2
                                        ;     Child Loop BB0_460 Depth 2
                                        ;     Child Loop BB0_512 Depth 2
                                        ;     Child Loop BB0_564 Depth 2
                                        ;       Child Loop BB0_567 Depth 3
                                        ;     Child Loop BB0_657 Depth 2
                                        ;     Child Loop BB0_1255 Depth 2
                                        ;     Child Loop BB0_1305 Depth 2
                                        ;     Child Loop BB0_608 Depth 2
                                        ;     Child Loop BB0_709 Depth 2
                                        ;     Child Loop BB0_748 Depth 2
                                        ;     Child Loop BB0_1339 Depth 2
                                        ;     Child Loop BB0_797 Depth 2
                                        ;       Child Loop BB0_800 Depth 3
                                        ;     Child Loop BB0_1389 Depth 2
                                        ;     Child Loop BB0_840 Depth 2
                                        ;     Child Loop BB0_889 Depth 2
                                        ;       Child Loop BB0_908 Depth 3
                                        ;     Child Loop BB0_997 Depth 2
                                        ;     Child Loop BB0_1439 Depth 2
                                        ;     Child Loop BB0_964 Depth 2
                                        ;     Child Loop BB0_1030 Depth 2
                                        ;     Child Loop BB0_1065 Depth 2
                                        ;     Child Loop BB0_1101 Depth 2
	stp	q27, q24, [sp, #800]            ; 32-byte Folded Spill
	str	q13, [sp, #10976]               ; 16-byte Spill
	str	q23, [sp, #8032]                ; 16-byte Spill
	str	q19, [sp, #8048]                ; 16-byte Spill
	str	q18, [sp, #8064]                ; 16-byte Spill
	str	q17, [sp, #8080]                ; 16-byte Spill
	str	q26, [sp, #11232]               ; 16-byte Spill
	str	q22, [sp, #11712]               ; 16-byte Spill
	str	q6, [sp, #11616]                ; 16-byte Spill
	mov.16b	v6, v0
	sshll.2d	v0, v30, #0
	mov.16b	v4, v1
	sshll.2d	v1, v31, #0
	fmov	x8, d4
	add	x8, x8, x8, lsl #6
	fmov	d3, x8
	str	q4, [sp, #704]                  ; 16-byte Spill
	mov.d	x8, v4[1]
	add	x8, x8, x8, lsl #6
	mov.d	v3[1], x8
	fmov	x8, d6
	fmov	x9, d29
	add	x9, x9, x9, lsl #6
	fmov	x14, d21
	add	x14, x14, x14, lsl #6
	fmov	d4, x14
	stp	q29, q21, [sp, #736]            ; 32-byte Folded Spill
	mov.d	x14, v21[1]
	add	x14, x14, x14, lsl #6
	mov.d	v4[1], x14
	ldr	q5, [sp, #11472]                ; 16-byte Reload
	bit.16b	v5, v4, v1
	fmov	d4, x9
	mov.d	x9, v29[1]
	add	x9, x9, x9, lsl #6
	mov.d	v4[1], x9
	add	x8, x8, x8, lsl #6
	ldr	q16, [sp, #11456]               ; 16-byte Reload
	bit.16b	v16, v4, v11
	fmov	d4, x8
	str	q6, [sp, #720]                  ; 16-byte Spill
	mov.d	x8, v6[1]
	add	x8, x8, x8, lsl #6
	mov.d	v4[1], x8
	ldr	q18, [sp, #11440]               ; 16-byte Reload
	bit.16b	v18, v4, v0
	ldr	q19, [sp, #11424]               ; 16-byte Reload
	bit.16b	v19, v3, v14
	ldr	q3, [sp, #656]                  ; 16-byte Reload
	ldr	q4, [sp, #11952]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #11952]                ; 16-byte Spill
	ldr	q4, [sp, #11984]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #11984]                ; 16-byte Spill
	ldr	q4, [sp, #11968]                ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #11968]                ; 16-byte Spill
	ldr	q4, [sp, #12000]                ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #12000]                ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #11888]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #11888]                ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #11920]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #11920]                ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #11904]                ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #11904]                ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #11936]                ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #11936]                ; 16-byte Spill
	ldp	q17, q7, [sp, #848]             ; 32-byte Folded Reload
	bic.16b	v17, v17, v14
	ldr	q6, [sp, #880]                  ; 16-byte Reload
	bic.16b	v6, v6, v11
	bic.16b	v7, v7, v0
	bic.16b	v9, v9, v1
	fmov	x9, d9
	ldr	q0, [sp, #208]                  ; 16-byte Reload
	str	q5, [sp, #11472]                ; 16-byte Spill
	add.2d	v0, v5, v0
	str	q0, [sp, #11872]                ; 16-byte Spill
	ldr	q0, [sp, #192]                  ; 16-byte Reload
	str	q16, [sp, #11456]               ; 16-byte Spill
	add.2d	v0, v16, v0
	str	q0, [sp, #11856]                ; 16-byte Spill
	ldr	q0, [sp, #176]                  ; 16-byte Reload
	str	q18, [sp, #11440]               ; 16-byte Spill
	add.2d	v0, v18, v0
	str	q0, [sp, #11840]                ; 16-byte Spill
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	mov.d	x28, v0[1]
	ldr	q0, [sp, #13216]                ; 16-byte Reload
	mov.d	x30, v0[1]
	ldr	q0, [sp, #160]                  ; 16-byte Reload
	str	q19, [sp, #11424]               ; 16-byte Spill
	add.2d	v0, v19, v0
	str	q0, [sp, #11824]                ; 16-byte Spill
	ldr	q0, [sp, #13200]                ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	q0, [sp, #13232]                ; 16-byte Reload
	mov.d	x14, v0[1]
	cmp	x9, #296
	b.gt	LBB0_127
; %bb.93:                               ; %direct.true366.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q26, [sp, #13168]               ; 16-byte Reload
	b	LBB0_95
LBB0_94:                                ; %else593
                                        ;   in Loop: Header=BB0_95 Depth=2
	str	q1, [sp, #6336]                 ; 16-byte Spill
	str	q5, [sp, #6352]                 ; 16-byte Spill
	add.2d	v6, v6, v10
	add.2d	v7, v7, v15
	add.2d	v17, v17, v8
	ldr	q0, [sp, #13312]                ; 16-byte Reload
	add.2d	v9, v9, v0
	fmov	x9, d9
	cmp	x9, #297
	b.ge	LBB0_128
LBB0_95:                                ; %direct.true366
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v2, v15
	sshll.2d	v3, v31, #0
	sshll.2d	v0, v30, #0
	and.16b	v4, v3, v9
	fmov	x9, d4
	ldr	q1, [sp, #4560]                 ; 16-byte Reload
	fmov	x15, d1
	sdiv	x9, x9, x15
	mov.d	x6, v4[1]
	mul	x24, x9, x15
	fmov	d5, x9
	mov.d	x10, v1[1]
	sdiv	x11, x6, x10
	mov.d	v5[1], x11
	mov.16b	v15, v6
	and.16b	v25, v11, v6
	fmov	x15, d25
	ldr	q1, [sp, #4592]                 ; 16-byte Reload
	fmov	x9, d1
	sdiv	x25, x15, x9
	mov.d	x15, v25[1]
	fmov	d6, x25
	mov.d	x26, v1[1]
	sdiv	x27, x15, x26
	mov.d	v6[1], x27
	mov.16b	v21, v7
	and.16b	v18, v0, v7
	fmov	x15, d18
	ldr	q1, [sp, #4576]                 ; 16-byte Reload
	fmov	x20, d1
	sdiv	x21, x15, x20
	mov.d	x15, v18[1]
	fmov	d7, x21
	mov.d	x22, v1[1]
	sdiv	x23, x15, x22
	mov.d	v7[1], x23
	mov.16b	v12, v17
	and.16b	v1, v14, v17
	fmov	x6, d1
	ldr	q16, [sp, #4608]                ; 16-byte Reload
	fmov	x15, d16
	sdiv	x6, x6, x15
	mov.d	x19, v1[1]
	fmov	d17, x6
	mov.d	x7, v16[1]
	sdiv	x19, x19, x7
	mov.d	v17[1], x19
	mul	x10, x11, x10
	fmov	d16, x24
	mov.d	v16[1], x10
	sub.2d	v16, v4, v16
	and.16b	v4, v14, v17
	and.16b	v3, v3, v5
	mov.d	x10, v3[1]
	sdiv	x11, x10, x28
	msub	x10, x11, x28, x10
	fmov	x11, d3
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	fmov	x24, d3
	sdiv	x12, x11, x24
	msub	x11, x12, x24, x11
	fmov	d3, x11
	mov.d	v3[1], x10
	and.16b	v5, v11, v6
	mov.d	x10, v5[1]
	sdiv	x11, x10, x30
	msub	x10, x11, x30, x10
	fmov	x11, d5
	ldr	q5, [sp, #13216]                ; 16-byte Reload
	fmov	x12, d5
	sdiv	x24, x11, x12
	msub	x11, x24, x12, x11
	fmov	d5, x11
	mov.d	v5[1], x10
	and.16b	v0, v0, v7
	mov.d	x10, v0[1]
	sdiv	x11, x10, x8
	msub	x10, x11, x8, x10
	fmov	x11, d0
	ldr	q0, [sp, #13200]                ; 16-byte Reload
	fmov	x12, d0
	sdiv	x24, x11, x12
	msub	x11, x24, x12, x11
	fmov	d0, x11
	mov.d	v0[1], x10
	mov.d	x10, v4[1]
	sdiv	x11, x10, x14
	msub	x10, x11, x14, x10
	fmov	x11, d4
	ldr	q4, [sp, #13232]                ; 16-byte Reload
	fmov	x12, d4
	sdiv	x24, x11, x12
	msub	x11, x24, x12, x11
	fmov	d4, x11
	mov.d	v4[1], x10
	shl.2d	v6, v4, #3
	shl.2d	v0, v0, #3
	shl.2d	v5, v5, #3
	shl.2d	v3, v3, #3
	ldr	q4, [sp, #13120]                ; 16-byte Reload
	orr.16b	v4, v3, v4
	ldr	q3, [sp, #13104]                ; 16-byte Reload
	orr.16b	v7, v5, v3
	ldr	q3, [sp, #13136]                ; 16-byte Reload
	orr.16b	v5, v0, v3
	ldr	q0, [sp, #13088]                ; 16-byte Reload
	orr.16b	v6, v6, v0
	mov	w10, #65                        ; =0x41
	dup.2d	v0, x10
	cmgt.2d	v3, v0, v6
	cmgt.2d	v17, v0, v5
	uzp1.4s	v19, v17, v3
	cmgt.2d	v22, v0, v7
	cmgt.2d	v0, v0, v4
	uzp1.4s	v23, v0, v22
	uzp1.8h	v19, v23, v19
	mov	w10, #64                        ; =0x40
	dup.2d	v23, x10
	bsl.16b	v3, v6, v23
	bsl.16b	v17, v5, v23
	mov.16b	v24, v22
	bsl.16b	v24, v7, v23
	bsl.16b	v0, v4, v23
	ldr	q22, [sp, #11472]               ; 16-byte Reload
	add.2d	v22, v0, v22
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	add.2d	v23, v17, v23
	mov.16b	v13, v26
	ldr	q26, [sp, #11424]               ; 16-byte Reload
	add.2d	v26, v3, v26
	mov	w10, #67                        ; =0x43
	dup.2d	v27, x10
	cmhi.2d	v26, v27, v26
	cmhi.2d	v23, v27, v23
	uzp1.4s	v23, v23, v26
	ldr	q26, [sp, #11456]               ; 16-byte Reload
	add.2d	v26, v24, v26
	cmhi.2d	v26, v27, v26
	cmhi.2d	v22, v27, v22
	ldr	q27, [sp, #11872]               ; 16-byte Reload
	add.2d	v0, v0, v27
	uzp1.4s	v22, v22, v26
	uzp1.8h	v22, v22, v23
	mov.d	x10, v0[1]
	fmov	x11, d0
	add	x11, x11, x11, lsl #5
	fmov	d0, x11
	add	x10, x10, x10, lsl #5
	mov.d	v0[1], x10
	add.2d	v16, v0, v16
	and.16b	v0, v19, v22
	xtn.8b	v19, v0
	and.8b	v0, v13, v19
	shl.8b	v22, v0, #7
	cmlt.8b	v22, v22, #0
	ldr	d23, [sp, #13344]               ; 8-byte Reload
	and.8b	v22, v22, v23
	addv.8b	b22, v22
	fmov	w24, s22
	shl.2d	v16, v16, #2
	mov	b22, v0[0]
	mov.b	v22[4], v0[1]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmlt.2d	v22, v22, #0
	and.16b	v16, v22, v16
	ldr	x10, [sp, #4632]                ; 8-byte Reload
	dup.2d	v23, x10
	add.2d	v26, v23, v16
	movi.2d	v22, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w24, #0, LBB0_97
; %bb.96:                               ; %cond.load513
                                        ;   in Loop: Header=BB0_95 Depth=2
	fmov	x10, d26
	ldr	s22, [x10]
LBB0_97:                                ; %else517
                                        ;   in Loop: Header=BB0_95 Depth=2
	tbz	w24, #1, LBB0_99
; %bb.98:                               ; %cond.load519
                                        ;   in Loop: Header=BB0_95 Depth=2
	mov.d	x10, v26[1]
	ld1.s	{ v22 }[1], [x10]
LBB0_99:                                ; %else523
                                        ;   in Loop: Header=BB0_95 Depth=2
	ldr	q27, [sp, #8000]                ; 16-byte Reload
	ldr	q29, [sp, #7984]                ; 16-byte Reload
	ldr	q13, [sp, #7968]                ; 16-byte Reload
	mul	x10, x27, x26
	mul	x9, x25, x9
	fmov	d26, x9
	mov.d	v26[1], x10
	sub.2d	v25, v25, v26
	ldr	q26, [sp, #11856]               ; 16-byte Reload
	add.2d	v24, v24, v26
	mov.d	x9, v24[1]
	fmov	x10, d24
	add	x10, x10, x10, lsl #5
	fmov	d24, x10
	add	x9, x9, x9, lsl #5
	mov.d	v24[1], x9
	add.2d	v24, v24, v25
	mov	b25, v0[2]
	mov.b	v25[4], v0[3]
	shl.2d	v24, v24, #2
	ushll.2d	v25, v25, #0
	shl.2d	v25, v25, #63
	cmlt.2d	v25, v25, #0
	and.16b	v24, v25, v24
	add.2d	v24, v23, v24
	tbz	w24, #2, LBB0_101
; %bb.100:                              ; %cond.load525
                                        ;   in Loop: Header=BB0_95 Depth=2
	fmov	x9, d24
	ld1.s	{ v22 }[2], [x9]
LBB0_101:                               ; %else529
                                        ;   in Loop: Header=BB0_95 Depth=2
	ldr	x27, [sp, #11368]               ; 8-byte Reload
	ldr	x26, [sp, #11560]               ; 8-byte Reload
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	ldr	q26, [sp, #13168]               ; 16-byte Reload
	tbz	w24, #3, LBB0_103
; %bb.102:                              ; %cond.load531
                                        ;   in Loop: Header=BB0_95 Depth=2
	mov.d	x9, v24[1]
	ld1.s	{ v22 }[3], [x9]
LBB0_103:                               ; %else535
                                        ;   in Loop: Header=BB0_95 Depth=2
	mul	x9, x23, x22
	mul	x10, x21, x20
	fmov	d24, x10
	mov.d	v24[1], x9
	sub.2d	v18, v18, v24
	ldr	q24, [sp, #11840]               ; 16-byte Reload
	add.2d	v17, v17, v24
	mov.d	x9, v17[1]
	fmov	x10, d17
	add	x10, x10, x10, lsl #5
	fmov	d17, x10
	add	x9, x9, x9, lsl #5
	mov.d	v17[1], x9
	add.2d	v17, v17, v18
	mov	b18, v0[4]
	mov.b	v18[4], v0[5]
	shl.2d	v17, v17, #2
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v17, v18, v17
	add.2d	v17, v23, v17
	tbz	w24, #4, LBB0_105
; %bb.104:                              ; %cond.load537
                                        ;   in Loop: Header=BB0_95 Depth=2
	fmov	x9, d17
	ld1.s	{ v16 }[0], [x9]
LBB0_105:                               ; %else541
                                        ;   in Loop: Header=BB0_95 Depth=2
	ldr	q24, [sp, #8016]                ; 16-byte Reload
	tbz	w24, #5, LBB0_107
; %bb.106:                              ; %cond.load543
                                        ;   in Loop: Header=BB0_95 Depth=2
	mov.d	x9, v17[1]
	ld1.s	{ v16 }[1], [x9]
LBB0_107:                               ; %else547
                                        ;   in Loop: Header=BB0_95 Depth=2
	mul	x9, x19, x7
	mul	x10, x6, x15
	fmov	d17, x10
	mov.d	v17[1], x9
	sub.2d	v1, v1, v17
	ldr	q17, [sp, #11824]               ; 16-byte Reload
	add.2d	v3, v3, v17
	mov.d	x9, v3[1]
	fmov	x10, d3
	add	x10, x10, x10, lsl #5
	fmov	d3, x10
	add	x9, x9, x9, lsl #5
	mov.d	v3[1], x9
	add.2d	v1, v3, v1
	mov	b3, v0[6]
	mov.b	v3[4], v0[7]
	shl.2d	v1, v1, #2
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	and.16b	v1, v3, v1
	add.2d	v1, v23, v1
	tbz	w24, #6, LBB0_109
; %bb.108:                              ; %cond.load549
                                        ;   in Loop: Header=BB0_95 Depth=2
	fmov	x9, d1
	ld1.s	{ v16 }[2], [x9]
LBB0_109:                               ; %else553
                                        ;   in Loop: Header=BB0_95 Depth=2
	ldr	q23, [sp, #7952]                ; 16-byte Reload
	tbz	w24, #7, LBB0_111
; %bb.110:                              ; %cond.load555
                                        ;   in Loop: Header=BB0_95 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v16 }[3], [x9]
LBB0_111:                               ; %else559
                                        ;   in Loop: Header=BB0_95 Depth=2
	bic.8b	v1, v26, v19
	mov	w9, #65                         ; =0x41
	dup.2d	v3, x9
	cmgt.2d	v7, v3, v7
	cmgt.2d	v4, v3, v4
	uzp1.4s	v4, v4, v7
	cmgt.2d	v5, v3, v5
	cmgt.2d	v3, v3, v6
	uzp1.4s	v3, v5, v3
	uzp1.8h	v3, v4, v3
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #6352]                 ; 16-byte Reload
	bsl.16b	v4, v22, v5
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v5, v5, v4
	and.16b	v3, v28, v3
	xtn.8b	v3, v3
	shl.8b	v3, v3, #7
	cmlt.8b	v3, v3, #0
	ldr	d4, [sp, #13344]                ; 8-byte Reload
	and.8b	v3, v3, v4
	addv.8b	b3, v3
	fmov	w9, s3
	shl.2d	v3, v9, #5
	ldr	q4, [sp, #11936]                ; 16-byte Reload
	orr.16b	v3, v3, v4
	ldr	q4, [sp, #12000]                ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w9, #0, LBB0_113
; %bb.112:                              ; %cond.store562
                                        ;   in Loop: Header=BB0_95 Depth=2
	fmov	x10, d3
	str	s5, [x10]
LBB0_113:                               ; %else565
                                        ;   in Loop: Header=BB0_95 Depth=2
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	mov.16b	v6, v15
	mov.16b	v7, v21
	mov.16b	v17, v12
	tbz	w9, #1, LBB0_115
; %bb.114:                              ; %cond.store566
                                        ;   in Loop: Header=BB0_95 Depth=2
	mov.d	x10, v3[1]
	st1.s	{ v5 }[1], [x10]
LBB0_115:                               ; %else569
                                        ;   in Loop: Header=BB0_95 Depth=2
	shl.2d	v3, v6, #5
	ldr	q4, [sp, #11920]                ; 16-byte Reload
	orr.16b	v3, v3, v4
	ldr	q4, [sp, #11984]                ; 16-byte Reload
	add.2d	v3, v4, v3
	mov.16b	v15, v2
	tbz	w9, #2, LBB0_117
; %bb.116:                              ; %cond.store570
                                        ;   in Loop: Header=BB0_95 Depth=2
	fmov	x10, d3
	st1.s	{ v5 }[2], [x10]
LBB0_117:                               ; %else573
                                        ;   in Loop: Header=BB0_95 Depth=2
	tbz	w9, #3, LBB0_119
; %bb.118:                              ; %cond.store574
                                        ;   in Loop: Header=BB0_95 Depth=2
	mov.d	x10, v3[1]
	st1.s	{ v5 }[3], [x10]
LBB0_119:                               ; %else577
                                        ;   in Loop: Header=BB0_95 Depth=2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q3, [sp, #6336]                 ; 16-byte Reload
	bsl.16b	v0, v16, v3
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v1, v1, v0
	shl.2d	v0, v7, #5
	ldr	q3, [sp, #11904]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #11968]                ; 16-byte Reload
	add.2d	v0, v3, v0
	tbnz	w9, #4, LBB0_123
; %bb.120:                              ; %else581
                                        ;   in Loop: Header=BB0_95 Depth=2
	tbnz	w9, #5, LBB0_124
LBB0_121:                               ; %else585
                                        ;   in Loop: Header=BB0_95 Depth=2
	shl.2d	v0, v17, #5
	ldr	q3, [sp, #11888]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #11952]                ; 16-byte Reload
	add.2d	v0, v3, v0
	tbnz	w9, #6, LBB0_125
LBB0_122:                               ; %else589
                                        ;   in Loop: Header=BB0_95 Depth=2
	tbz	w9, #7, LBB0_94
	b	LBB0_126
LBB0_123:                               ; %cond.store578
                                        ;   in Loop: Header=BB0_95 Depth=2
	fmov	x10, d0
	str	s1, [x10]
	tbz	w9, #5, LBB0_121
LBB0_124:                               ; %cond.store582
                                        ;   in Loop: Header=BB0_95 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v1 }[1], [x10]
	shl.2d	v0, v17, #5
	ldr	q3, [sp, #11888]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #11952]                ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #6, LBB0_122
LBB0_125:                               ; %cond.store586
                                        ;   in Loop: Header=BB0_95 Depth=2
	fmov	x10, d0
	st1.s	{ v1 }[2], [x10]
	tbz	w9, #7, LBB0_94
LBB0_126:                               ; %cond.store590
                                        ;   in Loop: Header=BB0_95 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[3], [x9]
	b	LBB0_94
LBB0_127:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q26, [sp, #13168]               ; 16-byte Reload
	ldr	q24, [sp, #8016]                ; 16-byte Reload
	ldr	q27, [sp, #8000]                ; 16-byte Reload
	ldr	q29, [sp, #7984]                ; 16-byte Reload
	ldr	q13, [sp, #7968]                ; 16-byte Reload
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	ldr	q23, [sp, #7952]                ; 16-byte Reload
LBB0_128:                               ; %direct.false367
                                        ;   in Loop: Header=BB0_92 Depth=1
	stp	q17, q7, [sp, #848]             ; 32-byte Folded Spill
	str	q6, [sp, #880]                  ; 16-byte Spill
	str	q9, [sp, #768]                  ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #640]                  ; 16-byte Reload
	ldr	q4, [sp, #12080]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #12080]                ; 16-byte Spill
	ldr	q4, [sp, #12112]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #12112]                ; 16-byte Spill
	ldr	q4, [sp, #12096]                ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #12096]                ; 16-byte Spill
	ldr	q4, [sp, #12128]                ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #12128]                ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #12016]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #12016]                ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #12048]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #12048]                ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #12032]                ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #12032]                ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #12064]                ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #12064]                ; 16-byte Spill
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #1968]                 ; 16-byte Spill
	ldp	q5, q3, [sp, #896]              ; 32-byte Folded Reload
	bic.16b	v3, v3, v11
	bic.16b	v5, v5, v1
	ldr	q6, [sp, #928]                  ; 16-byte Reload
	bic.16b	v6, v6, v0
	fmov	x9, d6
	cmp	x9, #64
	b.gt	LBB0_163
; %bb.129:                              ; %direct.true379.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
	b	LBB0_131
LBB0_130:                               ; %else675
                                        ;   in Loop: Header=BB0_131 Depth=2
	str	q1, [sp, #6368]                 ; 16-byte Spill
	add.2d	v3, v3, v10
	add.2d	v5, v19, v15
	add.2d	v4, v9, v8
	ldr	q0, [sp, #13312]                ; 16-byte Reload
	add.2d	v6, v6, v0
	fmov	x9, d6
	cmp	x9, #65
	b.ge	LBB0_164
LBB0_131:                               ; %direct.true379
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	mov.16b	v12, v6
	and.16b	v1, v1, v6
	mov.16b	v21, v3
	and.16b	v3, v11, v3
	mov.16b	v9, v4
	and.16b	v4, v14, v4
	mov.d	x9, v4[1]
	mov.16b	v19, v5
	and.16b	v0, v0, v5
	fmov	x10, d4
	ldr	q4, [sp, #4512]                 ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	mov.d	x15, v4[1]
	msub	x10, x12, x11, x10
	sdiv	x11, x9, x15
	msub	x9, x11, x15, x9
	mov.d	x11, v0[1]
	fmov	x12, d0
	ldr	q0, [sp, #4480]                 ; 16-byte Reload
	fmov	x15, d0
	sdiv	x6, x12, x15
	msub	x12, x6, x15, x12
	mov.d	x15, v0[1]
	sdiv	x6, x11, x15
	msub	x11, x6, x15, x11
	mov.d	x15, v3[1]
	fmov	x6, d3
	ldr	q0, [sp, #4496]                 ; 16-byte Reload
	fmov	x7, d0
	sdiv	x19, x6, x7
	msub	x6, x19, x7, x6
	mov.d	x7, v0[1]
	sdiv	x19, x15, x7
	mov.d	x20, v1[1]
	msub	x15, x19, x7, x15
	fmov	x7, d1
	ldr	q1, [sp, #4464]                 ; 16-byte Reload
	fmov	x19, d1
	sdiv	x21, x7, x19
	msub	x7, x21, x19, x7
	fmov	d3, x10
	mov.d	v3[1], x9
	fmov	d7, x12
	mov.d	v7[1], x11
	fmov	d16, x6
	mov.d	v16[1], x15
	fmov	d0, x7
	mov.d	x9, v1[1]
	sdiv	x10, x20, x9
	msub	x9, x10, x9, x20
	mov.d	v0[1], x9
	ldr	q1, [sp, #11472]                ; 16-byte Reload
	add.2d	v1, v0, v1
	ldr	q4, [sp, #11456]                ; 16-byte Reload
	add.2d	v4, v16, v4
	ldr	q5, [sp, #11440]                ; 16-byte Reload
	add.2d	v5, v7, v5
	ldr	q6, [sp, #11424]                ; 16-byte Reload
	add.2d	v6, v3, v6
	ldr	q17, [sp, #11872]               ; 16-byte Reload
	add.2d	v0, v0, v17
	mov	w9, #67                         ; =0x43
	dup.2d	v17, x9
	cmhi.2d	v6, v17, v6
	cmhi.2d	v5, v17, v5
	uzp1.4s	v5, v5, v6
	cmhi.2d	v4, v17, v4
	cmhi.2d	v1, v17, v1
	uzp1.4s	v1, v1, v4
	uzp1.8h	v1, v1, v5
	xtn.8b	v4, v1
	mov.d	x9, v0[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d0
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	ldr	q1, [sp, #13120]                ; 16-byte Reload
	add.2d	v1, v0, v1
	ldr	q0, [sp, #4640]                 ; 16-byte Reload
	and.8b	v0, v4, v0
	shl.8b	v5, v0, #7
	cmlt.8b	v5, v5, #0
	ldr	d6, [sp, #13344]                ; 8-byte Reload
	and.8b	v5, v5, v6
	addv.8b	b5, v5
	fmov	w9, s5
	shl.2d	v1, v1, #2
	mov	b5, v0[0]
	mov.b	v5[4], v0[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v1, v5, v1
	ldr	x10, [sp, #4624]                ; 8-byte Reload
	dup.2d	v6, x10
	add.2d	v17, v6, v1
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w9, #0, LBB0_133
; %bb.132:                              ; %cond.load595
                                        ;   in Loop: Header=BB0_131 Depth=2
	fmov	x10, d17
	ldr	s5, [x10]
LBB0_133:                               ; %else599
                                        ;   in Loop: Header=BB0_131 Depth=2
	tbz	w9, #1, LBB0_135
; %bb.134:                              ; %cond.load601
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v5 }[1], [x10]
LBB0_135:                               ; %else605
                                        ;   in Loop: Header=BB0_131 Depth=2
	ldr	q17, [sp, #11856]               ; 16-byte Reload
	add.2d	v16, v16, v17
	mov.d	x10, v16[1]
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	x11, d16
	lsl	x12, x11, #3
	sub	x11, x12, x11
	fmov	d16, x11
	mov.d	v16[1], x10
	ldr	q17, [sp, #13104]               ; 16-byte Reload
	add.2d	v16, v16, v17
	mov	b17, v0[2]
	mov.b	v17[4], v0[3]
	shl.2d	v16, v16, #2
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	and.16b	v16, v17, v16
	add.2d	v16, v6, v16
	tbz	w9, #2, LBB0_137
; %bb.136:                              ; %cond.load607
                                        ;   in Loop: Header=BB0_131 Depth=2
	fmov	x10, d16
	ld1.s	{ v5 }[2], [x10]
LBB0_137:                               ; %else611
                                        ;   in Loop: Header=BB0_131 Depth=2
	tbz	w9, #3, LBB0_139
; %bb.138:                              ; %cond.load613
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.d	x10, v16[1]
	ld1.s	{ v5 }[3], [x10]
LBB0_139:                               ; %else617
                                        ;   in Loop: Header=BB0_131 Depth=2
	ldr	q16, [sp, #11840]               ; 16-byte Reload
	add.2d	v7, v7, v16
	mov.d	x10, v7[1]
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	x11, d7
	lsl	x12, x11, #3
	sub	x11, x12, x11
	fmov	d7, x11
	mov.d	v7[1], x10
	ldr	q16, [sp, #13136]               ; 16-byte Reload
	add.2d	v7, v7, v16
	mov	b16, v0[4]
	mov.b	v16[4], v0[5]
	shl.2d	v7, v7, #2
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	and.16b	v7, v16, v7
	add.2d	v7, v6, v7
	tbz	w9, #4, LBB0_141
; %bb.140:                              ; %cond.load619
                                        ;   in Loop: Header=BB0_131 Depth=2
	fmov	x10, d7
	ld1.s	{ v1 }[0], [x10]
LBB0_141:                               ; %else623
                                        ;   in Loop: Header=BB0_131 Depth=2
	tbz	w9, #5, LBB0_143
; %bb.142:                              ; %cond.load625
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.d	x10, v7[1]
	ld1.s	{ v1 }[1], [x10]
LBB0_143:                               ; %else629
                                        ;   in Loop: Header=BB0_131 Depth=2
	ldr	q7, [sp, #11824]                ; 16-byte Reload
	add.2d	v3, v3, v7
	mov.d	x10, v3[1]
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	x11, d3
	lsl	x12, x11, #3
	sub	x11, x12, x11
	fmov	d3, x11
	mov.d	v3[1], x10
	ldr	q7, [sp, #4528]                 ; 16-byte Reload
	add.2d	v3, v3, v7
	mov	b7, v0[6]
	mov.b	v7[4], v0[7]
	shl.2d	v3, v3, #2
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v3, v7, v3
	add.2d	v3, v6, v3
	tbz	w9, #6, LBB0_145
; %bb.144:                              ; %cond.load631
                                        ;   in Loop: Header=BB0_131 Depth=2
	fmov	x10, d3
	ld1.s	{ v1 }[2], [x10]
LBB0_145:                               ; %else635
                                        ;   in Loop: Header=BB0_131 Depth=2
	tbz	w9, #7, LBB0_147
; %bb.146:                              ; %cond.load637
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.d	x9, v3[1]
	ld1.s	{ v1 }[3], [x9]
LBB0_147:                               ; %else641
                                        ;   in Loop: Header=BB0_131 Depth=2
	ldr	q3, [sp, #4544]                 ; 16-byte Reload
	and.8b	v3, v3, v4
	bic.8b	v3, v26, v3
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q6, [sp, #11376]                ; 16-byte Reload
	bsl.16b	v4, v5, v6
	zip1.8b	v5, v3, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v4, v5, v4
	str	q4, [sp, #11376]                ; 16-byte Spill
	mov.16b	v6, v12
	shl.2d	v4, v12, #5
	ldr	q5, [sp, #12064]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12128]                ; 16-byte Reload
	add.2d	v4, v5, v4
	ldr	d5, [sp, #12344]                ; 8-byte Reload
	fmov	w9, s5
	tbnz	w9, #0, LBB0_156
; %bb.148:                              ; %else647
                                        ;   in Loop: Header=BB0_131 Depth=2
	tbnz	w9, #1, LBB0_157
LBB0_149:                               ; %else651
                                        ;   in Loop: Header=BB0_131 Depth=2
	shl.2d	v4, v21, #5
	ldr	q5, [sp, #12048]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12112]                ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w9, #2, LBB0_158
LBB0_150:                               ; %else655
                                        ;   in Loop: Header=BB0_131 Depth=2
	tbz	w9, #3, LBB0_152
LBB0_151:                               ; %cond.store656
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.d	x10, v4[1]
	ldr	q4, [sp, #11376]                ; 16-byte Reload
	st1.s	{ v4 }[3], [x10]
LBB0_152:                               ; %else659
                                        ;   in Loop: Header=BB0_131 Depth=2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q4, [sp, #6368]                 ; 16-byte Reload
	bsl.16b	v0, v1, v4
	zip2.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v1, v1, v0
	shl.2d	v0, v19, #5
	ldr	q3, [sp, #12032]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #12096]                ; 16-byte Reload
	add.2d	v0, v3, v0
	tbnz	w9, #4, LBB0_159
; %bb.153:                              ; %else663
                                        ;   in Loop: Header=BB0_131 Depth=2
	tbnz	w9, #5, LBB0_160
LBB0_154:                               ; %else667
                                        ;   in Loop: Header=BB0_131 Depth=2
	shl.2d	v0, v9, #5
	ldr	q3, [sp, #12016]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #12080]                ; 16-byte Reload
	add.2d	v0, v3, v0
	tbnz	w9, #6, LBB0_161
LBB0_155:                               ; %else671
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.16b	v3, v21
	tbz	w9, #7, LBB0_130
	b	LBB0_162
LBB0_156:                               ; %cond.store644
                                        ;   in Loop: Header=BB0_131 Depth=2
	fmov	x10, d4
	ldr	q5, [sp, #11376]                ; 16-byte Reload
	str	s5, [x10]
	tbz	w9, #1, LBB0_149
LBB0_157:                               ; %cond.store648
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.d	x10, v4[1]
	ldr	q4, [sp, #11376]                ; 16-byte Reload
	st1.s	{ v4 }[1], [x10]
	shl.2d	v4, v21, #5
	ldr	q5, [sp, #12048]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12112]                ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w9, #2, LBB0_150
LBB0_158:                               ; %cond.store652
                                        ;   in Loop: Header=BB0_131 Depth=2
	fmov	x10, d4
	ldr	q5, [sp, #11376]                ; 16-byte Reload
	st1.s	{ v5 }[2], [x10]
	tbnz	w9, #3, LBB0_151
	b	LBB0_152
LBB0_159:                               ; %cond.store660
                                        ;   in Loop: Header=BB0_131 Depth=2
	fmov	x10, d0
	str	s1, [x10]
	tbz	w9, #5, LBB0_154
LBB0_160:                               ; %cond.store664
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v1 }[1], [x10]
	shl.2d	v0, v9, #5
	ldr	q3, [sp, #12016]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #12080]                ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #6, LBB0_155
LBB0_161:                               ; %cond.store668
                                        ;   in Loop: Header=BB0_131 Depth=2
	fmov	x10, d0
	st1.s	{ v1 }[2], [x10]
	mov.16b	v3, v21
	tbz	w9, #7, LBB0_130
LBB0_162:                               ; %cond.store672
                                        ;   in Loop: Header=BB0_131 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[3], [x9]
	b	LBB0_130
LBB0_163:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q4, [sp, #1968]                 ; 16-byte Reload
LBB0_164:                               ; %direct.false380
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q4, [sp, #1968]                 ; 16-byte Spill
	stp	q5, q3, [sp, #896]              ; 32-byte Folded Spill
	str	q6, [sp, #928]                  ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #624]                  ; 16-byte Reload
	ldr	q4, [sp, #8160]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8160]                 ; 16-byte Spill
	ldr	q4, [sp, #8192]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8192]                 ; 16-byte Spill
	ldr	q4, [sp, #8176]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8176]                 ; 16-byte Spill
	ldr	q4, [sp, #8208]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8208]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #8096]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8096]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #8128]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8128]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #8112]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8112]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #8144]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8144]                 ; 16-byte Spill
	ldr	q3, [sp, #9792]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #9792]                 ; 16-byte Spill
	ldr	q3, [sp, #4832]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #4832]                 ; 16-byte Spill
	ldr	q3, [sp, #4816]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #4816]                 ; 16-byte Spill
	bic.16b	v23, v23, v0
	fmov	x9, d23
	cmp	x9, #17
	str	q20, [sp, #784]                 ; 16-byte Spill
	b.gt	LBB0_220
; %bb.165:                              ; %direct.true392.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q16, [sp, #4832]                ; 16-byte Reload
	ldr	q20, [sp, #4816]                ; 16-byte Reload
	ldr	q3, [sp, #9792]                 ; 16-byte Reload
	ldr	q17, [sp, #832]                 ; 16-byte Reload
	ldr	q9, [sp, #13248]                ; 16-byte Reload
	ldr	q21, [sp, #4800]                ; 16-byte Reload
	b	LBB0_167
LBB0_166:                               ; %else806
                                        ;   in Loop: Header=BB0_167 Depth=2
	str	q12, [sp, #7744]                ; 16-byte Spill
	str	q15, [sp, #7760]                ; 16-byte Spill
	add.2d	v16, v16, v10
	mov.16b	v15, v2
	add.2d	v20, v20, v2
	add.2d	v3, v1, v8
	ldr	q0, [sp, #13312]                ; 16-byte Reload
	add.2d	v23, v23, v0
	fmov	x9, d23
	cmp	x9, #18
	b.ge	LBB0_221
LBB0_167:                               ; %direct.true392
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_170 Depth 3
	mov.16b	v2, v15
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	str	q3, [sp, #9792]                 ; 16-byte Spill
	and.16b	v3, v14, v3
	and.16b	v4, v11, v16
	and.16b	v5, v1, v20
	and.16b	v6, v0, v23
	fmov	x9, d6
	ldr	q7, [sp, #13184]                ; 16-byte Reload
	fmov	x10, d7
	sdiv	x19, x9, x10
	mov.d	x9, v6[1]
	sdiv	x21, x9, x28
	fmov	x9, d5
	ldr	q7, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d7
	sdiv	x20, x9, x11
	mov.d	x9, v5[1]
	sdiv	x22, x9, x8
	fmov	x9, d4
	ldr	q7, [sp, #13216]                ; 16-byte Reload
	fmov	x12, d7
	sdiv	x6, x9, x12
	mov.d	x9, v4[1]
	sdiv	x7, x9, x30
	fmov	x9, d3
	ldr	q7, [sp, #13232]                ; 16-byte Reload
	fmov	x23, d7
	sdiv	x9, x9, x23
	mov.d	x15, v3[1]
	sdiv	x15, x15, x14
	mul	x10, x19, x10
	fmov	d7, x10
	mul	x10, x21, x28
	mov.d	v7[1], x10
	mul	x10, x15, x14
	mul	x23, x9, x23
	mul	x11, x20, x11
	sub.2d	v6, v6, v7
	fmov	d7, x11
	mul	x11, x22, x8
	mov.d	v7[1], x11
	mul	x11, x7, x30
	mul	x12, x6, x12
	sub.2d	v5, v5, v7
	fmov	d7, x12
	mov.d	v7[1], x11
	sub.2d	v4, v4, v7
	fmov	d7, x23
	mov.d	v7[1], x10
	sub.2d	v3, v3, v7
	bit.16b	v18, v3, v14
	bit.16b	v13, v5, v1
	shl.2d	v5, v5, #3
	shl.2d	v3, v3, #3
	ldr	q7, [sp, #13264]                ; 16-byte Reload
	cmgt.2d	v3, v7, v3
	ldr	q7, [sp, #13296]                ; 16-byte Reload
	cmgt.2d	v5, v7, v5
	uzp1.4s	v3, v5, v3
	bit.16b	v29, v4, v11
	bit.16b	v27, v6, v0
	shl.2d	v5, v6, #3
	shl.2d	v4, v4, #3
	cmgt.2d	v4, v9, v4
	cmgt.2d	v5, v25, v5
	uzp1.4s	v4, v5, v4
	fmov	d5, x19
	mov.d	v5[1], x21
	uzp1.8h	v3, v4, v3
	and.16b	v4, v3, v28
	xtn.8b	v4, v4
	ldr	q7, [sp, #13168]                ; 16-byte Reload
	bic.8b	v6, v24, v7
	orr.8b	v24, v4, v6
	fmov	d4, x20
	mov.d	v4[1], x22
	and.16b	v4, v1, v4
	and.16b	v5, v0, v5
	mov.d	x10, v5[1]
	mov.d	x11, v4[1]
	fmov	x12, d5
	fmov	x19, d4
	fmov	d4, x6
	mov.d	v4[1], x7
	and.16b	v4, v11, v4
	mov.d	x6, v4[1]
	fmov	x7, d4
	fmov	d4, x9
	mov.d	v4[1], x15
	and.16b	v4, v14, v4
	ldr	x15, [sp, #11704]               ; 8-byte Reload
	sdiv	x9, x10, x15
	msub	x9, x9, x15, x10
	ldr	q5, [sp, #11680]                ; 16-byte Reload
	fmov	x10, d5
	sdiv	x15, x12, x10
	msub	x10, x15, x10, x12
	sdiv	x12, x11, x26
	msub	x11, x12, x26, x11
	ldr	q5, [sp, #11664]                ; 16-byte Reload
	fmov	x12, d5
	sdiv	x15, x6, x25
	msub	x15, x15, x25, x6
	ldr	q5, [sp, #11648]                ; 16-byte Reload
	fmov	x6, d5
	mov.d	x20, v4[1]
	fmov	x21, d4
	ldr	q4, [sp, #11632]                ; 16-byte Reload
	fmov	x22, d4
	sdiv	x23, x21, x22
	msub	x21, x23, x22, x21
	sdiv	x22, x7, x6
	sdiv	x23, x20, x27
	msub	x20, x23, x27, x20
	fmov	d4, x21
	mov.d	v4[1], x20
	msub	x6, x22, x6, x7
	bit.16b	v21, v4, v14
	fmov	d4, x6
	mov.d	v4[1], x15
	sdiv	x15, x19, x12
	msub	x12, x15, x12, x19
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	bit.16b	v6, v4, v11
	fmov	d4, x12
	mov.d	v4[1], x11
	bit.16b	v22, v4, v1
	fmov	d4, x10
	mov.d	v4[1], x9
	ldr	q5, [sp, #7776]                 ; 16-byte Reload
	bif.16b	v4, v5, v0
	ldr	q5, [sp, #10928]                ; 16-byte Reload
	bic.16b	v5, v5, v1
	str	q5, [sp, #10928]                ; 16-byte Spill
	ldr	q1, [sp, #10960]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	bic.16b	v17, v17, v14
	ldr	q0, [sp, #10944]                ; 16-byte Reload
	bic.16b	v0, v0, v11
	str	q0, [sp, #10944]                ; 16-byte Spill
	ldr	q12, [sp, #7744]                ; 16-byte Reload
	bic.16b	v12, v12, v30
	ldr	q15, [sp, #7760]                ; 16-byte Reload
	bic.16b	v15, v15, v31
	str	q1, [sp, #10960]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #33
	str	q4, [sp, #7776]                 ; 16-byte Spill
	str	q6, [sp, #11616]                ; 16-byte Spill
	str	q18, [sp, #10992]               ; 16-byte Spill
	b.ge	LBB0_202
; %bb.168:                              ; %direct.true398.lr.ph
                                        ;   in Loop: Header=BB0_167 Depth=2
	str	q20, [sp, #4816]                ; 16-byte Spill
	str	q16, [sp, #4832]                ; 16-byte Spill
	str	q23, [sp, #7952]                ; 16-byte Spill
	fmov	x9, d4
	add	x9, x9, x9, lsl #2
	fmov	d0, x9
	mov.d	x9, v4[1]
	add	x9, x9, x9, lsl #2
	mov.d	v0[1], x9
	str	q0, [sp, #11872]                ; 16-byte Spill
	fmov	x9, d6
	add	x9, x9, x9, lsl #2
	mov.d	x10, v6[1]
	mov.16b	v1, v7
	fmov	d0, x9
	add	x9, x10, x10, lsl #2
	mov.d	v0[1], x9
	str	q0, [sp, #11856]                ; 16-byte Spill
	fmov	x9, d22
	add	x9, x9, x9, lsl #2
	fmov	d0, x9
	str	q22, [sp, #11712]               ; 16-byte Spill
	mov.d	x9, v22[1]
	add	x9, x9, x9, lsl #2
	mov.d	v0[1], x9
	str	q0, [sp, #11840]                ; 16-byte Spill
	fmov	x9, d21
	add	x9, x9, x9, lsl #2
	fmov	d4, x9
	str	q21, [sp, #4800]                ; 16-byte Spill
	mov.d	x9, v21[1]
	add	x9, x9, x9, lsl #2
	mov.d	v4[1], x9
	fmov	x9, d27
	str	q27, [sp, #8000]                ; 16-byte Spill
	mov.d	x10, v27[1]
	add	x9, x9, x9, lsl #5
	fmov	d23, x9
	add	x9, x10, x10, lsl #5
	mov.d	v23[1], x9
	fmov	x9, d29
	add	x9, x9, x9, lsl #5
	fmov	d6, x9
	str	q29, [sp, #7984]                ; 16-byte Spill
	mov.d	x9, v29[1]
	add	x9, x9, x9, lsl #5
	mov.d	v6[1], x9
	fmov	x9, d13
	add	x9, x9, x9, lsl #5
	fmov	d25, x9
	str	q13, [sp, #7968]                ; 16-byte Spill
	mov.d	x9, v13[1]
	add	x9, x9, x9, lsl #5
	mov.d	v25[1], x9
	fmov	x9, d18
	add	x9, x9, x9, lsl #5
	fmov	d7, x9
	mov.d	x9, v18[1]
	add	x9, x9, x9, lsl #5
	mov.d	v7[1], x9
	and.16b	v0, v28, v3
	xtn.8b	v19, v0
	str	q24, [sp, #8016]                ; 16-byte Spill
	bic.8b	v3, v1, v24
	zip2.8b	v0, v19, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #11824]                ; 16-byte Spill
	zip1.8b	v0, v19, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	zip1.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	zip2.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v5, v3, #0
	ldr	q24, [sp, #10960]               ; 16-byte Reload
	ldr	q28, [sp, #10944]               ; 16-byte Reload
	ldr	q27, [sp, #10928]               ; 16-byte Reload
	mov.16b	v18, v17
	ldr	q20, [sp, #3840]                ; 16-byte Reload
	b	LBB0_170
LBB0_169:                               ; %else772
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.s	v3[1], v14[0]
	mov.s	v3[2], v9[0]
	mov.s	v3[3], v24[0]
	mov.s	v22[1], v26[0]
	mov.s	v22[2], v10[0]
	mov.s	v22[3], v8[0]
	ldr	q24, [sp, #12624]               ; 16-byte Reload
	bit.16b	v24, v22, v30
	ldr	q22, [sp, #12608]               ; 16-byte Reload
	bit.16b	v22, v3, v21
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	ldr	q2, [sp, #11824]                ; 16-byte Reload
	bit.16b	v3, v11, v2
	ldr	q18, [sp, #12640]               ; 16-byte Reload
	bif.16b	v17, v18, v0
	and.16b	v17, v1, v17
	and.16b	v3, v5, v3
	str	q22, [sp, #12608]               ; 16-byte Spill
	str	q3, [sp, #12592]                ; 16-byte Spill
	fmul.4s	v3, v3, v22
	str	q17, [sp, #12640]               ; 16-byte Spill
	str	q24, [sp, #12624]               ; 16-byte Spill
	fmul.4s	v17, v17, v24
	fadd.4s	v17, v15, v17
	fadd.4s	v3, v12, v3
	ldr	q10, [sp, #13056]               ; 16-byte Reload
	add.2d	v28, v27, v10
	ldr	q22, [sp, #13328]               ; 16-byte Reload
	add.2d	v27, v13, v22
	ldr	q8, [sp, #12880]                ; 16-byte Reload
	add.2d	v18, v16, v8
	ldr	q16, [sp, #13312]               ; 16-byte Reload
	mov.16b	v24, v31
	mov.16b	v31, v30
	mov.16b	v30, v21
	add.2d	v24, v24, v16
	bit.16b	v12, v3, v21
	bit.16b	v15, v17, v31
	fmov	x9, d24
	cmp	x9, #33
	ldr	q14, [sp, #12720]               ; 16-byte Reload
	ldr	q11, [sp, #12736]               ; 16-byte Reload
	b.ge	LBB0_203
LBB0_170:                               ; %direct.true398
                                        ;   Parent Loop BB0_92 Depth=1
                                        ;     Parent Loop BB0_167 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov.16b	v21, v30
	sshll.2d	v22, v30, #0
	mov.16b	v30, v31
	sshll.2d	v26, v31, #0
	mov.16b	v31, v24
	and.16b	v3, v26, v24
	mov.16b	v13, v27
	and.16b	v17, v22, v27
	mov.16b	v16, v18
	and.16b	v24, v14, v18
	mov.d	x9, v24[1]
	mov.16b	v27, v28
	and.16b	v9, v11, v28
	ldr	q28, [sp, #13040]               ; 16-byte Reload
	mov.d	x10, v28[1]
	sdiv	x9, x9, x10
	fmov	x11, d24
	fmov	x12, d28
	sdiv	x15, x11, x12
	mov.d	x11, v9[1]
	ldr	q28, [sp, #13024]               ; 16-byte Reload
	mov.d	x7, v28[1]
	sdiv	x19, x11, x7
	fmov	x11, d9
	fmov	x21, d28
	mov.d	x6, v17[1]
	ldr	q28, [sp, #13008]               ; 16-byte Reload
	mov.d	x22, v28[1]
	sdiv	x20, x11, x21
	sdiv	x6, x6, x22
	fmov	x11, d17
	fmov	x23, d28
	mov.d	x24, v3[1]
	ldr	q28, [sp, #12992]               ; 16-byte Reload
	mov.d	x25, v28[1]
	sdiv	x24, x24, x25
	fmov	x26, d3
	fmov	x27, d28
	sdiv	x26, x26, x27
	mul	x27, x26, x27
	fmov	d28, x26
	mov.d	v28[1], x24
	mul	x10, x9, x10
	mul	x12, x15, x12
	fmov	d11, x12
	mov.d	v11[1], x10
	mul	x10, x19, x7
	mul	x12, x20, x21
	fmov	d10, x12
	mov.d	v10[1], x10
	mul	x10, x6, x22
	sdiv	x21, x11, x23
	mul	x11, x21, x23
	fmov	d8, x11
	mov.d	v8[1], x10
	mul	x10, x24, x25
	fmov	d14, x27
	mov.d	v14[1], x10
	ldr	q2, [sp, #11872]                ; 16-byte Reload
	add.2d	v28, v28, v2
	sub.2d	v3, v3, v14
	sub.2d	v8, v17, v8
	sub.2d	v10, v9, v10
	sub.2d	v14, v24, v11
	ldr	q17, [sp, #13088]               ; 16-byte Reload
	cmeq.2d	v17, v17, v14
	ldr	q24, [sp, #13136]               ; 16-byte Reload
	cmeq.2d	v24, v24, v8
	uzp1.4s	v17, v24, v17
	ldr	q24, [sp, #13104]               ; 16-byte Reload
	cmeq.2d	v24, v24, v10
	ldr	q9, [sp, #13120]                ; 16-byte Reload
	cmeq.2d	v9, v9, v3
	uzp1.4s	v24, v9, v24
	uzp1.8h	v17, v24, v17
	ldr	q24, [sp, #13280]               ; 16-byte Reload
	and.16b	v24, v24, v17
	xtn.8b	v9, v24
	shl.8b	v24, v9, #7
	cmlt.8b	v24, v24, #0
	ldr	d18, [sp, #13344]               ; 8-byte Reload
	and.8b	v24, v24, v18
	addv.8b	b24, v24
	fmov	w7, s24
	shl.2d	v24, v28, #5
	ldr	q28, [sp, #12304]               ; 16-byte Reload
	orr.16b	v24, v24, v28
	ldr	q28, [sp, #11760]               ; 16-byte Reload
	add.2d	v28, v28, v24
	movi.2d	v24, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbz	w7, #0, LBB0_172
; %bb.171:                              ; %cond.load677
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	x10, d28
	ldr	s24, [x10]
LBB0_172:                               ; %else681
                                        ;   in Loop: Header=BB0_170 Depth=3
	tbz	w7, #1, LBB0_174
; %bb.173:                              ; %cond.load683
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v24 }[1], [x10]
LBB0_174:                               ; %else687
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	d28, x20
	mov.d	v28[1], x19
	ldr	q2, [sp, #11856]                ; 16-byte Reload
	add.2d	v28, v28, v2
	shl.2d	v28, v28, #5
	ldr	q29, [sp, #12272]               ; 16-byte Reload
	orr.16b	v28, v28, v29
	ldr	q29, [sp, #11792]               ; 16-byte Reload
	add.2d	v28, v29, v28
	tbz	w7, #2, LBB0_176
; %bb.175:                              ; %cond.load689
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	x10, d28
	ld1.s	{ v24 }[2], [x10]
LBB0_176:                               ; %else693
                                        ;   in Loop: Header=BB0_170 Depth=3
	tbz	w7, #3, LBB0_178
; %bb.177:                              ; %cond.load695
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v24 }[3], [x10]
LBB0_178:                               ; %else699
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	d28, x21
	mov.d	v28[1], x6
	ldr	q2, [sp, #11840]                ; 16-byte Reload
	add.2d	v28, v28, v2
	shl.2d	v28, v28, #5
	ldr	q29, [sp, #12320]               ; 16-byte Reload
	orr.16b	v28, v28, v29
	ldr	q29, [sp, #11776]               ; 16-byte Reload
	add.2d	v28, v29, v28
	tbz	w7, #4, LBB0_180
; %bb.179:                              ; %cond.load701
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	x10, d28
	ld1.s	{ v11 }[0], [x10]
LBB0_180:                               ; %else705
                                        ;   in Loop: Header=BB0_170 Depth=3
	tbz	w7, #5, LBB0_182
; %bb.181:                              ; %cond.load707
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v11 }[1], [x10]
LBB0_182:                               ; %else711
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	d28, x15
	mov.d	v28[1], x9
	add.2d	v28, v28, v4
	shl.2d	v28, v28, #5
	ldr	q29, [sp, #12288]               ; 16-byte Reload
	orr.16b	v28, v28, v29
	ldr	q29, [sp, #11808]               ; 16-byte Reload
	add.2d	v28, v29, v28
	tbz	w7, #6, LBB0_184
; %bb.183:                              ; %cond.load713
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	x9, d28
	ld1.s	{ v11 }[2], [x9]
LBB0_184:                               ; %else717
                                        ;   in Loop: Header=BB0_170 Depth=3
	tbz	w7, #7, LBB0_186
; %bb.185:                              ; %cond.load719
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.d	x9, v28[1]
	ld1.s	{ v11 }[3], [x9]
LBB0_186:                               ; %else723
                                        ;   in Loop: Header=BB0_170 Depth=3
	ldr	q28, [sp, #12720]               ; 16-byte Reload
	ldr	q29, [sp, #12656]               ; 16-byte Reload
	bit.16b	v29, v14, v28
	ldr	q28, [sp, #12736]               ; 16-byte Reload
	ldr	q14, [sp, #12688]               ; 16-byte Reload
	bit.16b	v14, v10, v28
	ldr	q28, [sp, #12672]               ; 16-byte Reload
	bit.16b	v28, v8, v22
	ldr	q18, [sp, #12704]               ; 16-byte Reload
	bit.16b	v18, v3, v26
	ldr	q3, [sp, #13280]                ; 16-byte Reload
	bic.16b	v3, v3, v17
	xtn.8b	v3, v3
	zip2.8b	v17, v9, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q2, [sp, #12576]                ; 16-byte Reload
	bit.16b	v2, v11, v17
	zip1.8b	v17, v9, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	bsl.16b	v17, v24, v20
	zip1.8b	v20, v3, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmge.4s	v20, v20, #0
	and.16b	v20, v20, v17
	zip2.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	and.16b	v2, v3, v2
	str	q29, [sp, #12656]               ; 16-byte Spill
	xtn.2s	v9, v29
	str	q28, [sp, #12672]               ; 16-byte Spill
	xtn.2s	v3, v28
	str	q14, [sp, #12688]               ; 16-byte Spill
	xtn.2s	v17, v14
	str	q18, [sp, #12704]               ; 16-byte Spill
	xtn.2s	v22, v18
	mov.s	w9, v22[1]
	fmov	w10, s22
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldr	q22, [sp, #13168]               ; 16-byte Reload
	str	d22, [sp, #17880]
	ldrb	w12, [x12]
	and	w12, w16, w12
	str	q2, [x13, #4416]
	str	q20, [x13, #4400]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1504
	ldr	s22, [x15, x10, lsl #2]
	tst	w11, w12
	movi.2d	v18, #0000000000000000
	fcsel	s22, s22, s18, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w17, w9
	str	q2, [x13, #4448]
	str	q20, [x13, #4432]
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1536
	ldr	s24, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s26, s24, s18, ne
	mov.s	w9, v17[1]
	fmov	w10, s17
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	str	q2, [x13, #4480]
	str	q20, [x13, #4464]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1568
	ldr	s17, [x15, x10, lsl #2]
	and	w10, w0, w12
	tst	w11, w10
	fcsel	s10, s17, s18, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w1, w9
	str	q2, [x13, #4512]
	str	q20, [x13, #4496]
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1600
	ldr	s17, [x12, x11, lsl #2]
	tst	w10, w9
	mov.s	w9, v3[1]
	fcsel	s8, s17, s18, ne
	fmov	w10, s3
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	and	w12, w2, w12
	str	q2, [x13, #4544]
	str	q20, [x13, #4528]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1632
	ldr	s3, [x15, x10, lsl #2]
	tst	w11, w12
	fcsel	s3, s3, s18, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w3, w9
	str	q2, [x13, #4576]
	str	q20, [x13, #4560]
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1664
	ldr	s17, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s14, s17, s18, ne
	mov.s	w9, v9[1]
	fmov	w10, s9
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	and	w12, w4, w12
	str	q2, [x13, #4608]
	str	q20, [x13, #4592]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1696
	ldr	s17, [x15, x10, lsl #2]
	tst	w11, w12
	fcsel	s9, s17, s18, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w5, w9
	str	q2, [sp, #12576]                ; 16-byte Spill
	str	q2, [x13, #4640]
	str	q20, [x13, #4624]
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1728
	ldr	s17, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s24, s17, s18, ne
	add.2d	v17, v31, v23
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #11936]               ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #12000]               ; 16-byte Reload
	add.2d	v28, v18, v17
	shl.8b	v17, v19, #7
	cmlt.8b	v17, v17, #0
	ldr	d18, [sp, #13344]               ; 8-byte Reload
	and.8b	v17, v17, v18
	addv.8b	b17, v17
	fmov	w9, s17
	movi.2d	v17, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbz	w9, #0, LBB0_188
; %bb.187:                              ; %cond.load726
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	x10, d28
	ldr	s17, [x10]
LBB0_188:                               ; %else730
                                        ;   in Loop: Header=BB0_170 Depth=3
	tbz	w9, #1, LBB0_190
; %bb.189:                              ; %cond.load732
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v17 }[1], [x10]
LBB0_190:                               ; %else736
                                        ;   in Loop: Header=BB0_170 Depth=3
	add.2d	v28, v27, v6
	shl.2d	v28, v28, #5
	ldr	q18, [sp, #11920]               ; 16-byte Reload
	orr.16b	v28, v28, v18
	ldr	q18, [sp, #11984]               ; 16-byte Reload
	add.2d	v28, v18, v28
	tbz	w9, #2, LBB0_192
; %bb.191:                              ; %cond.load738
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	x10, d28
	ld1.s	{ v17 }[2], [x10]
LBB0_192:                               ; %else742
                                        ;   in Loop: Header=BB0_170 Depth=3
	tbz	w9, #3, LBB0_194
; %bb.193:                              ; %cond.load744
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v17 }[3], [x10]
LBB0_194:                               ; %else748
                                        ;   in Loop: Header=BB0_170 Depth=3
	add.2d	v28, v13, v25
	shl.2d	v28, v28, #5
	ldr	q18, [sp, #11904]               ; 16-byte Reload
	orr.16b	v28, v28, v18
	ldr	q18, [sp, #11968]               ; 16-byte Reload
	add.2d	v28, v18, v28
	tbz	w9, #4, LBB0_196
; %bb.195:                              ; %cond.load750
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	x10, d28
	ld1.s	{ v11 }[0], [x10]
LBB0_196:                               ; %else754
                                        ;   in Loop: Header=BB0_170 Depth=3
	tbz	w9, #5, LBB0_198
; %bb.197:                              ; %cond.load756
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.d	x10, v28[1]
	ld1.s	{ v11 }[1], [x10]
LBB0_198:                               ; %else760
                                        ;   in Loop: Header=BB0_170 Depth=3
	add.2d	v28, v16, v7
	shl.2d	v28, v28, #5
	ldr	q18, [sp, #11888]               ; 16-byte Reload
	orr.16b	v28, v28, v18
	ldr	q18, [sp, #11952]               ; 16-byte Reload
	add.2d	v28, v18, v28
	tbz	w9, #6, LBB0_200
; %bb.199:                              ; %cond.load762
                                        ;   in Loop: Header=BB0_170 Depth=3
	fmov	x10, d28
	ld1.s	{ v11 }[2], [x10]
LBB0_200:                               ; %else766
                                        ;   in Loop: Header=BB0_170 Depth=3
	tbz	w9, #7, LBB0_169
; %bb.201:                              ; %cond.load768
                                        ;   in Loop: Header=BB0_170 Depth=3
	mov.d	x9, v28[1]
	ld1.s	{ v11 }[3], [x9]
	b	LBB0_169
LBB0_202:                               ; %direct.true392.direct.false399_crit_edge
                                        ;   in Loop: Header=BB0_167 Depth=2
	and.16b	v0, v28, v3
	xtn.8b	v19, v0
	b	LBB0_204
LBB0_203:                               ;   in Loop: Header=BB0_167 Depth=2
	str	q20, [sp, #3840]                ; 16-byte Spill
	mov.16b	v17, v18
	str	q27, [sp, #10928]               ; 16-byte Spill
	str	q28, [sp, #10944]               ; 16-byte Spill
	str	q24, [sp, #10960]               ; 16-byte Spill
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	ldr	x27, [sp, #11368]               ; 8-byte Reload
	ldr	x26, [sp, #11560]               ; 8-byte Reload
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	ldr	q28, [sp, #13280]               ; 16-byte Reload
	ldr	q9, [sp, #13248]                ; 16-byte Reload
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q21, [sp, #4800]                ; 16-byte Reload
	ldr	q24, [sp, #8016]                ; 16-byte Reload
	ldr	q27, [sp, #8000]                ; 16-byte Reload
	ldr	q29, [sp, #7984]                ; 16-byte Reload
	ldr	q13, [sp, #7968]                ; 16-byte Reload
	ldr	q23, [sp, #7952]                ; 16-byte Reload
	ldr	q16, [sp, #4832]                ; 16-byte Reload
	ldr	q20, [sp, #4816]                ; 16-byte Reload
LBB0_204:                               ; %direct.false399
                                        ;   in Loop: Header=BB0_167 Depth=2
	shl.2d	v0, v23, #5
	ldr	q1, [sp, #8144]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #8208]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	shl.8b	v1, v19, #7
	cmlt.8b	v1, v1, #0
	ldr	d3, [sp, #13344]                ; 8-byte Reload
	and.8b	v1, v1, v3
	addv.8b	b1, v1
	fmov	w9, s1
	tbnz	w9, #0, LBB0_212
; %bb.205:                              ; %else778
                                        ;   in Loop: Header=BB0_167 Depth=2
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	ldr	q1, [sp, #9792]                 ; 16-byte Reload
	tbnz	w9, #1, LBB0_213
LBB0_206:                               ; %else782
                                        ;   in Loop: Header=BB0_167 Depth=2
	shl.2d	v0, v16, #5
	ldr	q3, [sp, #8128]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #8192]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbnz	w9, #2, LBB0_214
LBB0_207:                               ; %else786
                                        ;   in Loop: Header=BB0_167 Depth=2
	tbnz	w9, #3, LBB0_215
LBB0_208:                               ; %else790
                                        ;   in Loop: Header=BB0_167 Depth=2
	shl.2d	v0, v20, #5
	ldr	q3, [sp, #8112]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #8176]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbnz	w9, #4, LBB0_216
LBB0_209:                               ; %else794
                                        ;   in Loop: Header=BB0_167 Depth=2
	tbnz	w9, #5, LBB0_217
LBB0_210:                               ; %else798
                                        ;   in Loop: Header=BB0_167 Depth=2
	shl.2d	v0, v1, #5
	ldr	q3, [sp, #8096]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #8160]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbnz	w9, #6, LBB0_218
LBB0_211:                               ; %else802
                                        ;   in Loop: Header=BB0_167 Depth=2
	tbz	w9, #7, LBB0_166
	b	LBB0_219
LBB0_212:                               ; %cond.store775
                                        ;   in Loop: Header=BB0_167 Depth=2
	fmov	x10, d0
	str	s15, [x10]
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	ldr	q1, [sp, #9792]                 ; 16-byte Reload
	tbz	w9, #1, LBB0_206
LBB0_213:                               ; %cond.store779
                                        ;   in Loop: Header=BB0_167 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v15 }[1], [x10]
	shl.2d	v0, v16, #5
	ldr	q3, [sp, #8128]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #8192]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #2, LBB0_207
LBB0_214:                               ; %cond.store783
                                        ;   in Loop: Header=BB0_167 Depth=2
	fmov	x10, d0
	st1.s	{ v15 }[2], [x10]
	tbz	w9, #3, LBB0_208
LBB0_215:                               ; %cond.store787
                                        ;   in Loop: Header=BB0_167 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v15 }[3], [x10]
	shl.2d	v0, v20, #5
	ldr	q3, [sp, #8112]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #8176]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #4, LBB0_209
LBB0_216:                               ; %cond.store791
                                        ;   in Loop: Header=BB0_167 Depth=2
	fmov	x10, d0
	str	s12, [x10]
	tbz	w9, #5, LBB0_210
LBB0_217:                               ; %cond.store795
                                        ;   in Loop: Header=BB0_167 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v12 }[1], [x10]
	shl.2d	v0, v1, #5
	ldr	q3, [sp, #8096]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #8160]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #6, LBB0_211
LBB0_218:                               ; %cond.store799
                                        ;   in Loop: Header=BB0_167 Depth=2
	fmov	x10, d0
	st1.s	{ v12 }[2], [x10]
	tbz	w9, #7, LBB0_166
LBB0_219:                               ; %cond.store803
                                        ;   in Loop: Header=BB0_167 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v12 }[3], [x9]
	b	LBB0_166
LBB0_220:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q16, [sp, #4832]                ; 16-byte Reload
	ldr	q20, [sp, #4816]                ; 16-byte Reload
	ldr	q3, [sp, #9792]                 ; 16-byte Reload
	ldr	q17, [sp, #832]                 ; 16-byte Reload
	ldr	q9, [sp, #13248]                ; 16-byte Reload
	ldr	q21, [sp, #4800]                ; 16-byte Reload
LBB0_221:                               ; %direct.false393
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q21, [sp, #4800]                ; 16-byte Spill
	str	q17, [sp, #832]                 ; 16-byte Spill
	str	q3, [sp, #9792]                 ; 16-byte Spill
	str	q20, [sp, #4816]                ; 16-byte Spill
	str	q16, [sp, #4832]                ; 16-byte Spill
	str	q23, [sp, #7952]                ; 16-byte Spill
	str	q18, [sp, #10992]               ; 16-byte Spill
	str	q13, [sp, #7968]                ; 16-byte Spill
	str	q29, [sp, #7984]                ; 16-byte Spill
	str	q27, [sp, #8000]                ; 16-byte Spill
	str	q22, [sp, #11712]               ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #608]                  ; 16-byte Reload
	ldr	q4, [sp, #9632]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #9632]                 ; 16-byte Spill
	ldr	q4, [sp, #9664]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #9664]                 ; 16-byte Spill
	ldr	q4, [sp, #9648]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9648]                 ; 16-byte Spill
	ldr	q4, [sp, #9680]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #9680]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #9696]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #9696]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #9600]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #9600]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #9712]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9712]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #9616]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #9616]                 ; 16-byte Spill
	ldr	q5, [sp, #1840]                 ; 16-byte Reload
	bic.16b	v5, v5, v14
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	ldr	q4, [sp, #1856]                 ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q22, [sp, #1888]                ; 16-byte Reload
	bic.16b	v22, v22, v0
	fmov	x9, d22
	cmp	x9, #17
	ldr	q26, [sp, #1728]                ; 16-byte Reload
	ldr	q20, [sp, #13312]               ; 16-byte Reload
	mov.16b	v27, v15
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	b.le	LBB0_225
LBB0_222:                               ; %direct.false428
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q5, [sp, #1840]                 ; 16-byte Spill
	str	q4, [sp, #1856]                 ; 16-byte Spill
	str	q3, [sp, #1872]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #592]                  ; 16-byte Reload
	ldr	q4, [sp, #9568]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #9568]                 ; 16-byte Spill
	ldr	q4, [sp, #9472]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #9472]                 ; 16-byte Spill
	ldr	q4, [sp, #9584]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9584]                 ; 16-byte Spill
	ldr	q4, [sp, #9488]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #9488]                 ; 16-byte Spill
	ldr	q3, [sp, #9504]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v3, v4, v14
	str	q3, [sp, #9504]                 ; 16-byte Spill
	ldr	q3, [sp, #9536]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #9536]                 ; 16-byte Spill
	ldr	q3, [sp, #9520]                 ; 16-byte Reload
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #9520]                 ; 16-byte Spill
	ldr	q3, [sp, #9552]                 ; 16-byte Reload
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #9552]                 ; 16-byte Spill
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #2080]                 ; 16-byte Spill
	ldr	q3, [sp, #1808]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	ldr	q4, [sp, #1792]                 ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q19, [sp, #1824]                ; 16-byte Reload
	bic.16b	v19, v19, v0
	fmov	x9, d19
	cmp	x9, #8
	b.gt	LBB0_274
; %bb.223:                              ; %direct.true439.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q5, [sp, #2080]                 ; 16-byte Reload
	b	LBB0_258
LBB0_224:                               ; %else888
                                        ;   in Loop: Header=BB0_225 Depth=2
	add.2d	v3, v3, v10
	add.2d	v4, v4, v15
	add.2d	v5, v5, v8
	add.2d	v22, v22, v20
	fmov	x9, d22
	cmp	x9, #18
	b.ge	LBB0_222
LBB0_225:                               ; %direct.true427
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v31, #0
	sshll.2d	v19, v30, #0
	mov.16b	v21, v5
	and.16b	v1, v14, v5
	mov.16b	v13, v3
	and.16b	v3, v11, v3
	mov.16b	v15, v4
	and.16b	v4, v19, v4
	mov.16b	v29, v22
	and.16b	v5, v0, v22
	fmov	x9, d5
	ldr	q6, [sp, #13184]                ; 16-byte Reload
	fmov	x10, d6
	sdiv	x11, x9, x10
	mov.d	x9, v5[1]
	sdiv	x12, x9, x28
	fmov	x9, d4
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x6, d6
	sdiv	x7, x9, x6
	mov.d	x9, v4[1]
	sdiv	x19, x9, x8
	fmov	x9, d3
	ldr	q6, [sp, #13216]                ; 16-byte Reload
	fmov	x22, d6
	sdiv	x20, x9, x22
	mov.d	x9, v3[1]
	sdiv	x21, x9, x30
	fmov	x9, d1
	ldr	q6, [sp, #13232]                ; 16-byte Reload
	fmov	x23, d6
	sdiv	x9, x9, x23
	mov.d	x15, v1[1]
	sdiv	x15, x15, x14
	mul	x10, x11, x10
	fmov	d6, x10
	mul	x10, x12, x28
	mov.d	v6[1], x10
	mul	x10, x21, x30
	mul	x22, x20, x22
	fmov	d7, x22
	mov.d	v7[1], x10
	mul	x10, x19, x8
	mul	x6, x7, x6
	fmov	d16, x6
	mov.d	v16[1], x10
	mul	x10, x15, x14
	mul	x6, x9, x23
	fmov	d17, x6
	mov.d	v17[1], x10
	sub.2d	v18, v1, v17
	sub.2d	v17, v4, v16
	sub.2d	v22, v3, v7
	sub.2d	v1, v5, v6
	shl.2d	v3, v1, #3
	shl.2d	v4, v22, #3
	shl.2d	v5, v17, #3
	shl.2d	v6, v18, #3
	ldr	q7, [sp, #13264]                ; 16-byte Reload
	cmgt.2d	v7, v7, v6
	cmgt.2d	v16, v2, v5
	uzp1.4s	v7, v16, v7
	cmgt.2d	v16, v9, v4
	cmgt.2d	v23, v25, v3
	uzp1.4s	v16, v23, v16
	fmov	d23, x11
	mov.d	v23[1], x12
	uzp1.8h	v7, v16, v7
	and.16b	v0, v0, v23
	mov.d	x10, v0[1]
	ldr	x12, [sp, #11704]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	x11, d0
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fmov	x12, d0
	sdiv	x6, x11, x12
	msub	x11, x6, x12, x11
	add	x11, x11, x11, lsl #3
	fmov	d0, x11
	add	x10, x10, x10, lsl #3
	mov.d	v0[1], x10
	add.2d	v1, v0, v1
	and.16b	v0, v28, v7
	xtn.8b	v0, v0
	shl.8b	v7, v0, #7
	cmlt.8b	v7, v7, #0
	ldr	d16, [sp, #13344]               ; 8-byte Reload
	and.8b	v7, v7, v16
	addv.8b	b7, v7
	fmov	w6, s7
	shl.2d	v1, v1, #5
	ldr	q16, [sp, #8144]                ; 16-byte Reload
	orr.16b	v1, v1, v16
	ldr	q16, [sp, #8208]                ; 16-byte Reload
	add.2d	v23, v16, v1
	movi.2d	v16, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w6, #0, LBB0_227
; %bb.226:                              ; %cond.load808
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	x10, d23
	ldr	s16, [x10]
LBB0_227:                               ; %else812
                                        ;   in Loop: Header=BB0_225 Depth=2
	tbz	w6, #1, LBB0_229
; %bb.228:                              ; %cond.load814
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v16 }[1], [x10]
LBB0_229:                               ; %else818
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	d23, x20
	mov.d	v23[1], x21
	and.16b	v23, v11, v23
	mov.d	x10, v23[1]
	sdiv	x11, x10, x25
	msub	x10, x11, x25, x10
	fmov	x11, d23
	ldr	q23, [sp, #11648]               ; 16-byte Reload
	fmov	x12, d23
	sdiv	x20, x11, x12
	msub	x11, x20, x12, x11
	add	x11, x11, x11, lsl #3
	fmov	d23, x11
	add	x10, x10, x10, lsl #3
	mov.d	v23[1], x10
	add.2d	v22, v23, v22
	shl.2d	v22, v22, #5
	ldr	q20, [sp, #8128]                ; 16-byte Reload
	orr.16b	v22, v22, v20
	ldr	q20, [sp, #8192]                ; 16-byte Reload
	add.2d	v22, v20, v22
	tbz	w6, #2, LBB0_231
; %bb.230:                              ; %cond.load820
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	x10, d22
	ld1.s	{ v16 }[2], [x10]
LBB0_231:                               ; %else824
                                        ;   in Loop: Header=BB0_225 Depth=2
	ldr	q20, [sp, #13312]               ; 16-byte Reload
	tbz	w6, #3, LBB0_233
; %bb.232:                              ; %cond.load826
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.d	x10, v22[1]
	ld1.s	{ v16 }[3], [x10]
LBB0_233:                               ; %else830
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	d22, x7
	mov.d	v22[1], x19
	and.16b	v19, v19, v22
	mov.d	x10, v19[1]
	sdiv	x11, x10, x26
	msub	x10, x11, x26, x10
	fmov	x11, d19
	ldr	q19, [sp, #11664]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x7, x11, x12
	msub	x11, x7, x12, x11
	add	x11, x11, x11, lsl #3
	fmov	d19, x11
	add	x10, x10, x10, lsl #3
	mov.d	v19[1], x10
	add.2d	v17, v19, v17
	shl.2d	v17, v17, #5
	ldr	q19, [sp, #8112]                ; 16-byte Reload
	orr.16b	v17, v17, v19
	ldr	q19, [sp, #8176]                ; 16-byte Reload
	add.2d	v17, v19, v17
	tbz	w6, #4, LBB0_235
; %bb.234:                              ; %cond.load832
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	x10, d17
	ld1.s	{ v1 }[0], [x10]
LBB0_235:                               ; %else836
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.16b	v22, v29
	tbz	w6, #5, LBB0_237
; %bb.236:                              ; %cond.load838
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v1 }[1], [x10]
LBB0_237:                               ; %else842
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	d17, x9
	mov.d	v17[1], x15
	and.16b	v17, v14, v17
	mov.d	x9, v17[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d17
	ldr	q17, [sp, #11632]               ; 16-byte Reload
	fmov	x11, d17
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	add	x10, x10, x10, lsl #3
	fmov	d17, x10
	add	x9, x9, x9, lsl #3
	mov.d	v17[1], x9
	add.2d	v17, v17, v18
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #8096]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #8160]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w6, #6, LBB0_239
; %bb.238:                              ; %cond.load844
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	x9, d17
	ld1.s	{ v1 }[2], [x9]
LBB0_239:                               ; %else848
                                        ;   in Loop: Header=BB0_225 Depth=2
	tbz	w6, #7, LBB0_241
; %bb.240:                              ; %cond.load850
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.d	x9, v17[1]
	ld1.s	{ v1 }[3], [x9]
LBB0_241:                               ; %else854
                                        ;   in Loop: Header=BB0_225 Depth=2
	ldr	q17, [sp, #13264]               ; 16-byte Reload
	cmge.2d	v6, v6, v17
	cmge.2d	v5, v5, v2
	uzp1.4s	v5, v5, v6
	cmge.2d	v4, v4, v9
	cmge.2d	v3, v3, v25
	uzp1.4s	v3, v3, v4
	uzp1.8h	v3, v3, v5
	and.16b	v3, v28, v3
	xtn.8b	v3, v3
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #7712]                 ; 16-byte Reload
	bit.16b	v5, v16, v4
	zip1.8b	v4, v3, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v6, v4, #0
	mov	w9, #16746                      ; =0x416a
	movk	w9, #15922, lsl #16
	dup.4s	v4, w9
	and.16b	v5, v6, v5
	str	q5, [sp, #7712]                 ; 16-byte Spill
	fmul.4s	v5, v5, v4
	fmov	w9, s7
	shl.2d	v6, v22, #5
	ldr	q7, [sp, #9616]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #9680]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbnz	w9, #0, LBB0_250
; %bb.242:                              ; %else860
                                        ;   in Loop: Header=BB0_225 Depth=2
	tbnz	w9, #1, LBB0_251
LBB0_243:                               ; %else864
                                        ;   in Loop: Header=BB0_225 Depth=2
	shl.2d	v6, v13, #5
	ldr	q7, [sp, #9600]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #9664]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbnz	w9, #2, LBB0_252
LBB0_244:                               ; %else868
                                        ;   in Loop: Header=BB0_225 Depth=2
	tbz	w9, #3, LBB0_246
LBB0_245:                               ; %cond.store869
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v5 }[3], [x10]
LBB0_246:                               ; %else872
                                        ;   in Loop: Header=BB0_225 Depth=2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q5, [sp, #7728]                 ; 16-byte Reload
	bsl.16b	v0, v1, v5
	zip2.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7728]                 ; 16-byte Spill
	fmul.4s	v0, v0, v4
	mov.16b	v4, v15
	shl.2d	v1, v15, #5
	ldr	q3, [sp, #9712]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #9648]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_253
; %bb.247:                              ; %else876
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.16b	v5, v21
	mov.16b	v15, v27
	tbnz	w9, #5, LBB0_254
LBB0_248:                               ; %else880
                                        ;   in Loop: Header=BB0_225 Depth=2
	shl.2d	v1, v5, #5
	ldr	q3, [sp, #9696]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #9632]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_255
LBB0_249:                               ; %else884
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.16b	v3, v13
	tbz	w9, #7, LBB0_224
	b	LBB0_256
LBB0_250:                               ; %cond.store857
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	x10, d6
	str	s5, [x10]
	tbz	w9, #1, LBB0_243
LBB0_251:                               ; %cond.store861
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v5 }[1], [x10]
	shl.2d	v6, v13, #5
	ldr	q7, [sp, #9600]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #9664]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #2, LBB0_244
LBB0_252:                               ; %cond.store865
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	x10, d6
	st1.s	{ v5 }[2], [x10]
	tbnz	w9, #3, LBB0_245
	b	LBB0_246
LBB0_253:                               ; %cond.store873
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	mov.16b	v5, v21
	mov.16b	v15, v27
	tbz	w9, #5, LBB0_248
LBB0_254:                               ; %cond.store877
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v5, #5
	ldr	q3, [sp, #9696]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #9632]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_249
LBB0_255:                               ; %cond.store881
                                        ;   in Loop: Header=BB0_225 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	mov.16b	v3, v13
	tbz	w9, #7, LBB0_224
LBB0_256:                               ; %cond.store885
                                        ;   in Loop: Header=BB0_225 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_224
LBB0_257:                               ; %else921
                                        ;   in Loop: Header=BB0_258 Depth=2
	add.2d	v3, v3, v10
	add.2d	v4, v29, v15
	add.2d	v5, v13, v8
	add.2d	v19, v19, v20
	fmov	x9, d19
	cmp	x9, #9
	b.ge	LBB0_275
LBB0_258:                               ; %direct.true439
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	and.16b	v0, v0, v19
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	mov.16b	v21, v19
	mov.16b	v23, v3
	and.16b	v3, v11, v3
	mov.d	x9, v3[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d3
	ldr	q3, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d3, x10
	mov.d	v3[1], x9
	mov.16b	v29, v4
	and.16b	v1, v1, v4
	mov.d	x9, v1[1]
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d1
	ldr	q1, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	mov.16b	v13, v5
	and.16b	v4, v14, v5
	mov.d	x9, v4[1]
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d4
	ldr	q4, [sp, #13232]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	shl.2d	v5, v4, #3
	shl.2d	v1, v1, #3
	shl.2d	v3, v3, #3
	shl.2d	v0, v0, #3
	ldr	q4, [sp, #13120]                ; 16-byte Reload
	orr.16b	v16, v0, v4
	ldr	q0, [sp, #13104]                ; 16-byte Reload
	orr.16b	v6, v3, v0
	ldr	q0, [sp, #13136]                ; 16-byte Reload
	orr.16b	v4, v1, v0
	ldr	q0, [sp, #13088]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	mov	w9, #65                         ; =0x41
	dup.2d	v3, x9
	cmgt.2d	v1, v3, v0
	cmgt.2d	v5, v3, v4
	uzp1.4s	v17, v5, v1
	cmgt.2d	v7, v3, v6
	cmgt.2d	v18, v3, v16
	uzp1.4s	v19, v18, v7
	mov	w9, #64                         ; =0x40
	dup.2d	v3, x9
	uzp1.8h	v17, v19, v17
	bif.16b	v16, v3, v18
	and.16b	v17, v28, v17
	xtn.8b	v17, v17
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	ldr	d18, [sp, #13344]               ; 8-byte Reload
	and.8b	v17, v17, v18
	addv.8b	b17, v17
	fmov	w9, s17
	mov.16b	v19, v21
	shl.2d	v17, v21, #6
	ldr	q18, [sp, #9552]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #9488]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w9, #0, LBB0_260
; %bb.259:                              ; %cond.store890
                                        ;   in Loop: Header=BB0_258 Depth=2
	fmov	x10, d17
	str	d16, [x10]
LBB0_260:                               ; %else893
                                        ;   in Loop: Header=BB0_258 Depth=2
	tbz	w9, #1, LBB0_262
; %bb.261:                              ; %cond.store894
                                        ;   in Loop: Header=BB0_258 Depth=2
	mov.d	x10, v17[1]
	st1.d	{ v16 }[1], [x10]
LBB0_262:                               ; %else897
                                        ;   in Loop: Header=BB0_258 Depth=2
	bif.16b	v6, v3, v7
	shl.2d	v7, v23, #6
	ldr	q16, [sp, #9536]                ; 16-byte Reload
	orr.16b	v7, v7, v16
	ldr	q16, [sp, #9472]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbz	w9, #2, LBB0_264
; %bb.263:                              ; %cond.store898
                                        ;   in Loop: Header=BB0_258 Depth=2
	fmov	x10, d7
	str	d6, [x10]
LBB0_264:                               ; %else901
                                        ;   in Loop: Header=BB0_258 Depth=2
	tbz	w9, #3, LBB0_266
; %bb.265:                              ; %cond.store902
                                        ;   in Loop: Header=BB0_258 Depth=2
	mov.d	x10, v7[1]
	st1.d	{ v6 }[1], [x10]
LBB0_266:                               ; %else905
                                        ;   in Loop: Header=BB0_258 Depth=2
	bif.16b	v4, v3, v5
	shl.2d	v5, v29, #6
	ldr	q6, [sp, #9520]                 ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #9584]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #4, LBB0_268
; %bb.267:                              ; %cond.store906
                                        ;   in Loop: Header=BB0_258 Depth=2
	fmov	x10, d5
	str	d4, [x10]
LBB0_268:                               ; %else909
                                        ;   in Loop: Header=BB0_258 Depth=2
	tbz	w9, #5, LBB0_270
; %bb.269:                              ; %cond.store910
                                        ;   in Loop: Header=BB0_258 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v4 }[1], [x10]
LBB0_270:                               ; %else913
                                        ;   in Loop: Header=BB0_258 Depth=2
	bif.16b	v0, v3, v1
	shl.2d	v1, v13, #6
	ldr	q3, [sp, #9504]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #9568]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_272
; %bb.271:                              ; %cond.store914
                                        ;   in Loop: Header=BB0_258 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_272:                               ; %else917
                                        ;   in Loop: Header=BB0_258 Depth=2
	mov.16b	v3, v23
	tbz	w9, #7, LBB0_257
; %bb.273:                              ; %cond.store918
                                        ;   in Loop: Header=BB0_258 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_257
LBB0_274:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q5, [sp, #2080]                 ; 16-byte Reload
LBB0_275:                               ; %direct.false440
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q24, [sp, #8016]                ; 16-byte Spill
	str	q5, [sp, #2080]                 ; 16-byte Spill
	str	q4, [sp, #1792]                 ; 16-byte Spill
	str	q3, [sp, #1808]                 ; 16-byte Spill
	str	q19, [sp, #1824]                ; 16-byte Spill
	str	q22, [sp, #1888]                ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #576]                  ; 16-byte Reload
	ldr	q4, [sp, #9440]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #9440]                 ; 16-byte Spill
	ldr	q4, [sp, #9344]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #9344]                 ; 16-byte Spill
	ldr	q4, [sp, #9456]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9456]                 ; 16-byte Spill
	ldr	q4, [sp, #9360]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #9360]                 ; 16-byte Spill
	ldr	q3, [sp, #9376]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v3, v4, v14
	str	q3, [sp, #9376]                 ; 16-byte Spill
	ldr	q3, [sp, #9408]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #9408]                 ; 16-byte Spill
	ldr	q3, [sp, #9392]                 ; 16-byte Reload
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #9392]                 ; 16-byte Spill
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #9424]                 ; 16-byte Spill
	bic.16b	v26, v26, v14
	ldr	q5, [sp, #1760]                 ; 16-byte Reload
	bic.16b	v5, v5, v11
	ldr	q6, [sp, #1744]                 ; 16-byte Reload
	bic.16b	v6, v6, v1
	ldr	q4, [sp, #1776]                 ; 16-byte Reload
	bic.16b	v4, v4, v0
	fmov	x9, d4
	cmp	x9, #8
	b.le	LBB0_280
; %bb.276:                              ;   in Loop: Header=BB0_92 Depth=1
	ldr	q22, [sp, #11712]               ; 16-byte Reload
LBB0_277:                               ; %direct.false448
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q6, [sp, #1744]                 ; 16-byte Spill
	str	q5, [sp, #1760]                 ; 16-byte Spill
	str	q4, [sp, #1776]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #560]                  ; 16-byte Reload
	ldr	q4, [sp, #9248]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #9248]                 ; 16-byte Spill
	ldr	q4, [sp, #9280]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #9280]                 ; 16-byte Spill
	ldr	q4, [sp, #9264]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9264]                 ; 16-byte Spill
	ldr	q4, [sp, #9296]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #9296]                 ; 16-byte Spill
	ldr	q3, [sp, #9312]                 ; 16-byte Reload
	ldp	q4, q2, [sp, #128]              ; 32-byte Folded Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #9312]                 ; 16-byte Spill
	ldr	q3, [sp, #9216]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #9216]                 ; 16-byte Spill
	ldp	q4, q3, [sp, #96]               ; 32-byte Folded Reload
	ldr	q2, [sp, #9328]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9328]                 ; 16-byte Spill
	ldr	q3, [sp, #9232]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #9232]                 ; 16-byte Spill
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #2032]                 ; 16-byte Spill
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #2064]                 ; 16-byte Spill
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #2048]                 ; 16-byte Spill
	ldr	q4, [sp, #1712]                 ; 16-byte Reload
	bic.16b	v4, v4, v0
	fmov	x9, d4
	cmp	x9, #8
	b.gt	LBB0_345
; %bb.278:                              ; %direct.true459.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q5, [sp, #2064]                 ; 16-byte Reload
	ldr	q6, [sp, #2048]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	b	LBB0_313
LBB0_279:                               ; %else1003
                                        ;   in Loop: Header=BB0_280 Depth=2
	add.2d	v5, v5, v10
	add.2d	v6, v12, v27
	add.2d	v26, v15, v8
	add.2d	v4, v29, v20
	fmov	x9, d4
	cmp	x9, #9
	b.ge	LBB0_277
LBB0_280:                               ; %direct.true447
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	mov.16b	v15, v26
	and.16b	v3, v14, v26
	mov.d	x9, v3[1]
	mov.16b	v12, v6
	and.16b	v0, v0, v6
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d22, x10
	mov.d	v22[1], x9
	mov.d	x9, v0[1]
	mov.16b	v13, v5
	and.16b	v3, v11, v5
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d0
	ldr	q0, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d17, x10
	mov.d	v17[1], x9
	mov.d	x9, v3[1]
	mov.16b	v29, v4
	and.16b	v0, v1, v4
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d3
	ldr	q1, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	shl.2d	v3, v1, #3
	shl.2d	v7, v23, #3
	shl.2d	v16, v17, #3
	shl.2d	v18, v22, #3
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	cmgt.2d	v0, v0, v18
	cmgt.2d	v4, v2, v16
	uzp1.4s	v0, v4, v0
	cmgt.2d	v4, v9, v7
	cmgt.2d	v5, v25, v3
	uzp1.4s	v4, v5, v4
	uzp1.8h	v0, v4, v0
	and.16b	v0, v28, v0
	xtn.8b	v0, v0
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #13344]                ; 8-byte Reload
	and.8b	v4, v4, v5
	addv.8b	b6, v4
	fmov	w9, s6
	shl.2d	v1, v1, #6
	ldr	q4, [sp, #9552]                 ; 16-byte Reload
	orr.16b	v1, v1, v4
	ldr	q4, [sp, #9488]                 ; 16-byte Reload
	add.2d	v24, v4, v1
	tbz	w9, #0, LBB0_282
; %bb.281:                              ; %cond.load923
                                        ;   in Loop: Header=BB0_280 Depth=2
	fmov	x10, d24
	ldr	d19, [x10]
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbnz	w9, #1, LBB0_283
	b	LBB0_284
LBB0_282:                               ;   in Loop: Header=BB0_280 Depth=2
	movi.2d	v19, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w9, #1, LBB0_284
LBB0_283:                               ; %cond.load929
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.d	x10, v24[1]
	ld1.d	{ v19 }[1], [x10]
LBB0_284:                               ; %else933
                                        ;   in Loop: Header=BB0_280 Depth=2
	ldr	q9, [sp, #13248]                ; 16-byte Reload
	shl.2d	v23, v23, #6
	ldr	q21, [sp, #9536]                ; 16-byte Reload
	orr.16b	v23, v23, v21
	ldr	q21, [sp, #9472]                ; 16-byte Reload
	add.2d	v23, v21, v23
	tbnz	w9, #2, LBB0_307
; %bb.285:                              ; %else939
                                        ;   in Loop: Header=BB0_280 Depth=2
	tbnz	w9, #3, LBB0_308
LBB0_286:                               ; %else945
                                        ;   in Loop: Header=BB0_280 Depth=2
	shl.2d	v17, v17, #6
	ldr	q21, [sp, #9520]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9584]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbnz	w9, #4, LBB0_309
LBB0_287:                               ; %else951
                                        ;   in Loop: Header=BB0_280 Depth=2
	tbnz	w9, #5, LBB0_310
LBB0_288:                               ; %else957
                                        ;   in Loop: Header=BB0_280 Depth=2
	shl.2d	v17, v22, #6
	ldr	q21, [sp, #9504]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9568]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbnz	w9, #6, LBB0_311
LBB0_289:                               ; %else963
                                        ;   in Loop: Header=BB0_280 Depth=2
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbz	w9, #7, LBB0_291
LBB0_290:                               ; %cond.load965
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.d	x9, v17[1]
	ld1.d	{ v1 }[1], [x9]
LBB0_291:                               ; %else969
                                        ;   in Loop: Header=BB0_280 Depth=2
	ldr	q17, [sp, #13264]               ; 16-byte Reload
	cmge.2d	v17, v18, v17
	cmge.2d	v16, v16, v2
	uzp1.4s	v16, v16, v17
	cmge.2d	v7, v7, v9
	cmge.2d	v3, v3, v25
	uzp1.4s	v3, v3, v7
	uzp1.8h	v3, v3, v16
	and.16b	v3, v28, v3
	xtn.8b	v3, v3
	mov	b7, v0[0]
	mov.b	v7[4], v0[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	ldr	q16, [sp, #7696]                ; 16-byte Reload
	bsl.16b	v7, v19, v16
	mov	b16, v3[0]
	mov.b	v16[4], v3[1]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmge.2d	v16, v16, #0
	and.16b	v7, v16, v7
	str	q7, [sp, #7696]                 ; 16-byte Spill
	ldr	q16, [sp, #11472]               ; 16-byte Reload
	add.2d	v7, v7, v16
	fmov	w9, s6
	shl.2d	v6, v29, #6
	ldr	q16, [sp, #9424]                ; 16-byte Reload
	orr.16b	v6, v6, v16
	ldr	q16, [sp, #9360]                ; 16-byte Reload
	add.2d	v6, v16, v6
	tbz	w9, #0, LBB0_293
; %bb.292:                              ; %cond.store972
                                        ;   in Loop: Header=BB0_280 Depth=2
	fmov	x10, d6
	str	d7, [x10]
LBB0_293:                               ; %else975
                                        ;   in Loop: Header=BB0_280 Depth=2
	tbz	w9, #1, LBB0_295
; %bb.294:                              ; %cond.store976
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.d	x10, v6[1]
	st1.d	{ v7 }[1], [x10]
LBB0_295:                               ; %else979
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov	b6, v0[2]
	mov.b	v6[4], v0[3]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q7, [sp, #7680]                 ; 16-byte Reload
	bif.16b	v5, v7, v6
	mov	b6, v3[2]
	mov.b	v6[4], v3[3]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmge.2d	v6, v6, #0
	and.16b	v5, v6, v5
	str	q5, [sp, #7680]                 ; 16-byte Spill
	ldr	q6, [sp, #11456]                ; 16-byte Reload
	add.2d	v5, v5, v6
	shl.2d	v6, v13, #6
	ldr	q7, [sp, #9408]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #9344]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #2, LBB0_297
; %bb.296:                              ; %cond.store980
                                        ;   in Loop: Header=BB0_280 Depth=2
	fmov	x10, d6
	str	d5, [x10]
LBB0_297:                               ; %else983
                                        ;   in Loop: Header=BB0_280 Depth=2
	tbz	w9, #3, LBB0_299
; %bb.298:                              ; %cond.store984
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.d	x10, v6[1]
	st1.d	{ v5 }[1], [x10]
LBB0_299:                               ; %else987
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov	b5, v0[4]
	mov.b	v5[4], v0[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q6, [sp, #7664]                 ; 16-byte Reload
	bif.16b	v4, v6, v5
	mov	b5, v3[4]
	mov.b	v5[4], v3[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v4, v5, v4
	str	q4, [sp, #7664]                 ; 16-byte Spill
	ldr	q5, [sp, #11440]                ; 16-byte Reload
	add.2d	v4, v4, v5
	shl.2d	v5, v12, #6
	ldr	q6, [sp, #9392]                 ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #9456]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #4, LBB0_301
; %bb.300:                              ; %cond.store988
                                        ;   in Loop: Header=BB0_280 Depth=2
	fmov	x10, d5
	str	d4, [x10]
LBB0_301:                               ; %else991
                                        ;   in Loop: Header=BB0_280 Depth=2
	tbz	w9, #5, LBB0_303
; %bb.302:                              ; %cond.store992
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v4 }[1], [x10]
LBB0_303:                               ; %else995
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov	b4, v0[6]
	mov.b	v4[4], v0[7]
	ushll.2d	v0, v4, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q4, [sp, #7648]                 ; 16-byte Reload
	bsl.16b	v0, v1, v4
	mov	b1, v3[6]
	mov.b	v1[4], v3[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7648]                 ; 16-byte Spill
	ldr	q1, [sp, #11424]                ; 16-byte Reload
	add.2d	v0, v0, v1
	shl.2d	v1, v15, #6
	ldr	q3, [sp, #9376]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #9440]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_305
; %bb.304:                              ; %cond.store996
                                        ;   in Loop: Header=BB0_280 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_305:                               ; %else999
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.16b	v5, v13
	tbz	w9, #7, LBB0_279
; %bb.306:                              ; %cond.store1000
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_279
LBB0_307:                               ; %cond.load935
                                        ;   in Loop: Header=BB0_280 Depth=2
	fmov	x10, d23
	ld1.d	{ v5 }[0], [x10]
	tbz	w9, #3, LBB0_286
LBB0_308:                               ; %cond.load941
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v5 }[1], [x10]
	shl.2d	v17, v17, #6
	ldr	q21, [sp, #9520]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9584]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbz	w9, #4, LBB0_287
LBB0_309:                               ; %cond.load947
                                        ;   in Loop: Header=BB0_280 Depth=2
	fmov	x10, d17
	ld1.d	{ v4 }[0], [x10]
	tbz	w9, #5, LBB0_288
LBB0_310:                               ; %cond.load953
                                        ;   in Loop: Header=BB0_280 Depth=2
	mov.d	x10, v17[1]
	ld1.d	{ v4 }[1], [x10]
	shl.2d	v17, v22, #6
	ldr	q21, [sp, #9504]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9568]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbz	w9, #6, LBB0_289
LBB0_311:                               ; %cond.load959
                                        ;   in Loop: Header=BB0_280 Depth=2
	fmov	x10, d17
	ld1.d	{ v1 }[0], [x10]
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbnz	w9, #7, LBB0_290
	b	LBB0_291
LBB0_312:                               ; %else1085
                                        ;   in Loop: Header=BB0_313 Depth=2
	add.2d	v5, v13, v10
	add.2d	v6, v15, v27
	add.2d	v3, v12, v8
	add.2d	v4, v29, v20
	fmov	x9, d4
	cmp	x9, #9
	b.ge	LBB0_346
LBB0_313:                               ; %direct.true459
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	mov.16b	v12, v3
	and.16b	v3, v14, v3
	mov.d	x9, v3[1]
	mov.16b	v15, v6
	and.16b	v0, v0, v6
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d19, x10
	mov.d	v19[1], x9
	mov.d	x9, v0[1]
	mov.16b	v13, v5
	and.16b	v3, v11, v5
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d0
	ldr	q0, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d17, x10
	mov.d	v17[1], x9
	mov.d	x9, v3[1]
	mov.16b	v29, v4
	and.16b	v0, v1, v4
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d3
	ldr	q1, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	shl.2d	v3, v4, #3
	shl.2d	v6, v23, #3
	shl.2d	v16, v17, #3
	shl.2d	v18, v19, #3
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	cmgt.2d	v0, v0, v18
	cmgt.2d	v1, v2, v16
	uzp1.4s	v0, v1, v0
	cmgt.2d	v1, v9, v6
	cmgt.2d	v5, v25, v3
	uzp1.4s	v1, v5, v1
	uzp1.8h	v0, v1, v0
	and.16b	v0, v28, v0
	xtn.8b	v1, v0
	shl.8b	v0, v1, #7
	cmlt.8b	v0, v0, #0
	ldr	d5, [sp, #13344]                ; 8-byte Reload
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	fmov	w9, s0
	shl.2d	v4, v4, #6
	ldr	q5, [sp, #9424]                 ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #9360]                 ; 16-byte Reload
	add.2d	v24, v5, v4
	tbz	w9, #0, LBB0_315
; %bb.314:                              ; %cond.load1005
                                        ;   in Loop: Header=BB0_313 Depth=2
	fmov	x10, d24
	ldr	d4, [x10]
	movi.2d	v5, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w9, #1, LBB0_316
	b	LBB0_317
LBB0_315:                               ;   in Loop: Header=BB0_313 Depth=2
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbz	w9, #1, LBB0_317
LBB0_316:                               ; %cond.load1011
                                        ;   in Loop: Header=BB0_313 Depth=2
	mov.d	x10, v24[1]
	ld1.d	{ v4 }[1], [x10]
LBB0_317:                               ; %else1015
                                        ;   in Loop: Header=BB0_313 Depth=2
	ldr	q9, [sp, #13248]                ; 16-byte Reload
	shl.2d	v23, v23, #6
	ldr	q21, [sp, #9408]                ; 16-byte Reload
	orr.16b	v23, v23, v21
	ldr	q21, [sp, #9344]                ; 16-byte Reload
	add.2d	v23, v21, v23
	tbnz	w9, #2, LBB0_332
; %bb.318:                              ; %else1021
                                        ;   in Loop: Header=BB0_313 Depth=2
	tbnz	w9, #3, LBB0_333
LBB0_319:                               ; %else1027
                                        ;   in Loop: Header=BB0_313 Depth=2
	shl.2d	v17, v17, #6
	ldr	q21, [sp, #9392]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9456]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbnz	w9, #4, LBB0_334
LBB0_320:                               ; %else1033
                                        ;   in Loop: Header=BB0_313 Depth=2
	tbnz	w9, #5, LBB0_335
LBB0_321:                               ; %else1039
                                        ;   in Loop: Header=BB0_313 Depth=2
	shl.2d	v17, v19, #6
	ldr	q19, [sp, #9376]                ; 16-byte Reload
	orr.16b	v17, v17, v19
	ldr	q19, [sp, #9440]                ; 16-byte Reload
	add.2d	v17, v19, v17
	tbnz	w9, #6, LBB0_336
LBB0_322:                               ; %else1045
                                        ;   in Loop: Header=BB0_313 Depth=2
	tbz	w9, #7, LBB0_324
LBB0_323:                               ; %cond.load1047
                                        ;   in Loop: Header=BB0_313 Depth=2
	mov.d	x9, v17[1]
	ld1.d	{ v22 }[1], [x9]
LBB0_324:                               ; %else1051
                                        ;   in Loop: Header=BB0_313 Depth=2
	ldr	q17, [sp, #13264]               ; 16-byte Reload
	cmge.2d	v17, v18, v17
	cmge.2d	v16, v16, v2
	uzp1.4s	v16, v16, v17
	cmge.2d	v6, v6, v9
	cmge.2d	v3, v3, v25
	uzp1.4s	v3, v3, v6
	uzp1.8h	v3, v3, v16
	and.16b	v3, v28, v3
	xtn.8b	v3, v3
	mov	b6, v1[6]
	mov.b	v6[4], v1[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q16, [sp, #7520]                ; 16-byte Reload
	bsl.16b	v6, v22, v16
	mov	b16, v1[4]
	mov.b	v16[4], v1[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	mov	b17, v1[2]
	mov.b	v17[4], v1[3]
	ldr	q18, [sp, #7536]                ; 16-byte Reload
	bif.16b	v7, v18, v16
	ushll.2d	v16, v17, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	ldr	q17, [sp, #7552]                ; 16-byte Reload
	bif.16b	v5, v17, v16
	mov	b16, v1[0]
	mov.b	v16[4], v1[1]
	ushll.2d	v1, v16, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q16, [sp, #7632]                ; 16-byte Reload
	bsl.16b	v1, v4, v16
	mov	b4, v3[0]
	mov.b	v4[4], v3[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmge.2d	v4, v4, #0
	and.16b	v16, v4, v1
	mov	b1, v3[2]
	mov.b	v1[4], v3[3]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v5, v1, v5
	mov	b1, v3[4]
	mov.b	v1[4], v3[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v4, v1, v7
	mov	b1, v3[6]
	mov.b	v1[4], v3[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v6, v1, v6
	mov	w9, #67                         ; =0x43
	dup.2d	v3, x9
	fmov	w9, s0
	ldr	q0, [sp, #9232]                 ; 16-byte Reload
	add.2d	v0, v29, v0
	ldr	q1, [sp, #9296]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q6, [sp, #7520]                 ; 16-byte Spill
	cmgt.2d	v0, v3, v6
	str	q4, [sp, #7536]                 ; 16-byte Spill
	cmgt.2d	v4, v3, v4
	uzp1.4s	v0, v4, v0
	str	q5, [sp, #7552]                 ; 16-byte Spill
	cmgt.2d	v4, v3, v5
	str	q16, [sp, #7632]                ; 16-byte Spill
	cmgt.2d	v3, v3, v16
	uzp1.4s	v3, v3, v4
	uzp1.8h	v0, v3, v0
	xtn.8b	v0, v0
	movi.8b	v3, #1
	and.8b	v0, v0, v3
	tbnz	w9, #0, LBB0_337
; %bb.325:                              ; %else1057
                                        ;   in Loop: Header=BB0_313 Depth=2
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbnz	w9, #1, LBB0_338
LBB0_326:                               ; %else1061
                                        ;   in Loop: Header=BB0_313 Depth=2
	ldr	q1, [sp, #9216]                 ; 16-byte Reload
	add.2d	v1, v13, v1
	ldr	q3, [sp, #9280]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #2, LBB0_339
LBB0_327:                               ; %else1065
                                        ;   in Loop: Header=BB0_313 Depth=2
	tbnz	w9, #3, LBB0_340
LBB0_328:                               ; %else1069
                                        ;   in Loop: Header=BB0_313 Depth=2
	ldr	q1, [sp, #9328]                 ; 16-byte Reload
	add.2d	v1, v15, v1
	ldr	q3, [sp, #9264]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_341
LBB0_329:                               ; %else1073
                                        ;   in Loop: Header=BB0_313 Depth=2
	tbnz	w9, #5, LBB0_342
LBB0_330:                               ; %else1077
                                        ;   in Loop: Header=BB0_313 Depth=2
	ldr	q1, [sp, #9312]                 ; 16-byte Reload
	add.2d	v1, v12, v1
	ldr	q3, [sp, #9248]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_343
LBB0_331:                               ; %else1081
                                        ;   in Loop: Header=BB0_313 Depth=2
	tbz	w9, #7, LBB0_312
	b	LBB0_344
LBB0_332:                               ; %cond.load1017
                                        ;   in Loop: Header=BB0_313 Depth=2
	fmov	x10, d23
	ld1.d	{ v5 }[0], [x10]
	tbz	w9, #3, LBB0_319
LBB0_333:                               ; %cond.load1023
                                        ;   in Loop: Header=BB0_313 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v5 }[1], [x10]
	shl.2d	v17, v17, #6
	ldr	q21, [sp, #9392]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9456]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbz	w9, #4, LBB0_320
LBB0_334:                               ; %cond.load1029
                                        ;   in Loop: Header=BB0_313 Depth=2
	fmov	x10, d17
	ld1.d	{ v7 }[0], [x10]
	tbz	w9, #5, LBB0_321
LBB0_335:                               ; %cond.load1035
                                        ;   in Loop: Header=BB0_313 Depth=2
	mov.d	x10, v17[1]
	ld1.d	{ v7 }[1], [x10]
	shl.2d	v17, v19, #6
	ldr	q19, [sp, #9376]                ; 16-byte Reload
	orr.16b	v17, v17, v19
	ldr	q19, [sp, #9440]                ; 16-byte Reload
	add.2d	v17, v19, v17
	tbz	w9, #6, LBB0_322
LBB0_336:                               ; %cond.load1041
                                        ;   in Loop: Header=BB0_313 Depth=2
	fmov	x10, d17
	ld1.d	{ v22 }[0], [x10]
	tbnz	w9, #7, LBB0_323
	b	LBB0_324
LBB0_337:                               ; %cond.store1054
                                        ;   in Loop: Header=BB0_313 Depth=2
	fmov	x10, d1
	str	b0, [x10]
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbz	w9, #1, LBB0_326
LBB0_338:                               ; %cond.store1058
                                        ;   in Loop: Header=BB0_313 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[1], [x10]
	ldr	q1, [sp, #9216]                 ; 16-byte Reload
	add.2d	v1, v13, v1
	ldr	q3, [sp, #9280]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #2, LBB0_327
LBB0_339:                               ; %cond.store1062
                                        ;   in Loop: Header=BB0_313 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[2], [x10]
	tbz	w9, #3, LBB0_328
LBB0_340:                               ; %cond.store1066
                                        ;   in Loop: Header=BB0_313 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[3], [x10]
	ldr	q1, [sp, #9328]                 ; 16-byte Reload
	add.2d	v1, v15, v1
	ldr	q3, [sp, #9264]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_329
LBB0_341:                               ; %cond.store1070
                                        ;   in Loop: Header=BB0_313 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[4], [x10]
	tbz	w9, #5, LBB0_330
LBB0_342:                               ; %cond.store1074
                                        ;   in Loop: Header=BB0_313 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[5], [x10]
	ldr	q1, [sp, #9312]                 ; 16-byte Reload
	add.2d	v1, v12, v1
	ldr	q3, [sp, #9248]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_331
LBB0_343:                               ; %cond.store1078
                                        ;   in Loop: Header=BB0_313 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[6], [x10]
	tbz	w9, #7, LBB0_312
LBB0_344:                               ; %cond.store1082
                                        ;   in Loop: Header=BB0_313 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[7], [x9]
	b	LBB0_312
LBB0_345:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q5, [sp, #2064]                 ; 16-byte Reload
	ldr	q6, [sp, #2048]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
LBB0_346:                               ; %direct.false460
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q3, [sp, #2032]                 ; 16-byte Spill
	str	q6, [sp, #2048]                 ; 16-byte Spill
	str	q5, [sp, #2064]                 ; 16-byte Spill
	str	q4, [sp, #1712]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #544]                  ; 16-byte Reload
	ldr	q4, [sp, #9104]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #9104]                 ; 16-byte Spill
	ldr	q4, [sp, #9136]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #9136]                 ; 16-byte Spill
	ldr	q4, [sp, #9120]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #9120]                 ; 16-byte Spill
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #9152]                 ; 16-byte Spill
	ldr	q3, [sp, #9168]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v3, v4, v14
	str	q3, [sp, #9168]                 ; 16-byte Spill
	ldr	q9, [sp, #1696]                 ; 16-byte Reload
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v9, v3, v11
	ldr	q3, [sp, #9184]                 ; 16-byte Reload
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #9184]                 ; 16-byte Spill
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	ldr	q2, [sp, #9200]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9200]                 ; 16-byte Spill
	ldr	q5, [sp, #1664]                 ; 16-byte Reload
	bic.16b	v5, v5, v14
	ldr	q3, [sp, #1632]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	ldr	q4, [sp, #1680]                 ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q19, [sp, #1648]                ; 16-byte Reload
	bic.16b	v19, v19, v0
	fmov	x9, d19
	cmp	x9, #8
	b.gt	LBB0_365
; %bb.347:                              ; %direct.true470.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q24, [sp, #1568]                ; 16-byte Reload
	mov.16b	v2, v27
	b	LBB0_349
LBB0_348:                               ; %else1118
                                        ;   in Loop: Header=BB0_349 Depth=2
	add.2d	v3, v3, v10
	add.2d	v4, v21, v2
	add.2d	v5, v5, v8
	add.2d	v19, v19, v20
	fmov	x9, d19
	cmp	x9, #9
	b.ge	LBB0_366
LBB0_349:                               ; %direct.true470
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	and.16b	v0, v0, v19
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	mov.16b	v29, v19
	mov.16b	v13, v3
	and.16b	v3, v11, v3
	mov.d	x9, v3[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d3
	ldr	q3, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d3, x10
	mov.d	v3[1], x9
	mov.16b	v21, v4
	and.16b	v1, v1, v4
	mov.d	x9, v1[1]
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d1
	ldr	q1, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	mov.16b	v23, v5
	and.16b	v4, v14, v5
	mov.d	x9, v4[1]
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d4
	ldr	q4, [sp, #13232]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	shl.2d	v5, v4, #3
	shl.2d	v1, v1, #3
	shl.2d	v3, v3, #3
	shl.2d	v0, v0, #3
	ldr	q4, [sp, #13120]                ; 16-byte Reload
	orr.16b	v16, v0, v4
	ldr	q0, [sp, #13104]                ; 16-byte Reload
	orr.16b	v6, v3, v0
	ldr	q0, [sp, #13136]                ; 16-byte Reload
	orr.16b	v4, v1, v0
	ldr	q0, [sp, #13088]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	mov	w9, #65                         ; =0x41
	dup.2d	v3, x9
	cmgt.2d	v1, v3, v0
	cmgt.2d	v5, v3, v4
	uzp1.4s	v17, v5, v1
	cmgt.2d	v7, v3, v6
	cmgt.2d	v18, v3, v16
	uzp1.4s	v19, v18, v7
	mov	w9, #64                         ; =0x40
	dup.2d	v3, x9
	uzp1.8h	v17, v19, v17
	bif.16b	v16, v3, v18
	and.16b	v17, v28, v17
	xtn.8b	v17, v17
	shl.8b	v17, v17, #7
	cmlt.8b	v17, v17, #0
	ldr	d18, [sp, #13344]               ; 8-byte Reload
	and.8b	v17, v17, v18
	addv.8b	b17, v17
	fmov	w9, s17
	mov.16b	v19, v29
	shl.2d	v17, v29, #6
	ldr	q18, [sp, #9200]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #9152]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbnz	w9, #0, LBB0_362
; %bb.350:                              ; %else1090
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbnz	w9, #1, LBB0_363
LBB0_351:                               ; %else1094
                                        ;   in Loop: Header=BB0_349 Depth=2
	bif.16b	v6, v3, v7
	shl.2d	v7, v13, #6
	orr.16b	v7, v7, v9
	ldr	q16, [sp, #9136]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbnz	w9, #2, LBB0_364
LBB0_352:                               ; %else1098
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbz	w9, #3, LBB0_354
LBB0_353:                               ; %cond.store1099
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x10, v7[1]
	st1.d	{ v6 }[1], [x10]
LBB0_354:                               ; %else1102
                                        ;   in Loop: Header=BB0_349 Depth=2
	bif.16b	v4, v3, v5
	shl.2d	v5, v21, #6
	ldr	q6, [sp, #9184]                 ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #9120]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #4, LBB0_356
; %bb.355:                              ; %cond.store1103
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x10, d5
	str	d4, [x10]
LBB0_356:                               ; %else1106
                                        ;   in Loop: Header=BB0_349 Depth=2
	tbz	w9, #5, LBB0_358
; %bb.357:                              ; %cond.store1107
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v4 }[1], [x10]
LBB0_358:                               ; %else1110
                                        ;   in Loop: Header=BB0_349 Depth=2
	bif.16b	v0, v3, v1
	mov.16b	v5, v23
	shl.2d	v1, v23, #6
	ldr	q3, [sp, #9168]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_360
; %bb.359:                              ; %cond.store1111
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_360:                               ; %else1114
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.16b	v3, v13
	tbz	w9, #7, LBB0_348
; %bb.361:                              ; %cond.store1115
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_348
LBB0_362:                               ; %cond.store1087
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x10, d17
	str	d16, [x10]
	tbz	w9, #1, LBB0_351
LBB0_363:                               ; %cond.store1091
                                        ;   in Loop: Header=BB0_349 Depth=2
	mov.d	x10, v17[1]
	st1.d	{ v16 }[1], [x10]
	bif.16b	v6, v3, v7
	shl.2d	v7, v13, #6
	orr.16b	v7, v7, v9
	ldr	q16, [sp, #9136]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbz	w9, #2, LBB0_352
LBB0_364:                               ; %cond.store1095
                                        ;   in Loop: Header=BB0_349 Depth=2
	fmov	x10, d7
	str	d6, [x10]
	tbnz	w9, #3, LBB0_353
	b	LBB0_354
LBB0_365:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q24, [sp, #1568]                ; 16-byte Reload
LBB0_366:                               ; %direct.false471
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q3, [sp, #1632]                 ; 16-byte Spill
	str	q19, [sp, #1648]                ; 16-byte Spill
	str	q5, [sp, #1664]                 ; 16-byte Spill
	str	q4, [sp, #1680]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #528]                  ; 16-byte Reload
	ldr	q4, [sp, #8976]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8976]                 ; 16-byte Spill
	ldr	q4, [sp, #9008]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #9008]                 ; 16-byte Spill
	ldr	q4, [sp, #8992]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8992]                 ; 16-byte Spill
	ldr	q4, [sp, #9024]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #9024]                 ; 16-byte Spill
	ldr	q3, [sp, #9040]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v3, v4, v14
	str	q3, [sp, #9040]                 ; 16-byte Spill
	ldr	q3, [sp, #9072]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #9072]                 ; 16-byte Spill
	ldr	q3, [sp, #9056]                 ; 16-byte Reload
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #9056]                 ; 16-byte Spill
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #9088]                 ; 16-byte Spill
	ldr	q4, [sp, #1600]                 ; 16-byte Reload
	bic.16b	v4, v4, v14
	bic.16b	v24, v24, v11
	ldr	q5, [sp, #1616]                 ; 16-byte Reload
	bic.16b	v5, v5, v1
	ldr	q6, [sp, #1584]                 ; 16-byte Reload
	bic.16b	v6, v6, v0
	fmov	x9, d6
	cmp	x9, #8
	b.gt	LBB0_401
; %bb.367:                              ; %direct.true478.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	b	LBB0_369
LBB0_368:                               ; %else1200
                                        ;   in Loop: Header=BB0_369 Depth=2
	add.2d	v24, v12, v10
	add.2d	v5, v5, v27
	add.2d	v4, v4, v8
	add.2d	v6, v15, v20
	fmov	x9, d6
	cmp	x9, #9
	b.ge	LBB0_401
LBB0_369:                               ; %direct.true478
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	mov.16b	v13, v4
	and.16b	v3, v14, v4
	mov.d	x9, v3[1]
	mov.16b	v29, v5
	and.16b	v0, v0, v5
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d22, x10
	mov.d	v22[1], x9
	mov.d	x9, v0[1]
	mov.16b	v12, v24
	and.16b	v3, v11, v24
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d0
	ldr	q0, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d17, x10
	mov.d	v17[1], x9
	mov.d	x9, v3[1]
	mov.16b	v15, v6
	and.16b	v0, v1, v6
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d3
	ldr	q1, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	shl.2d	v3, v1, #3
	shl.2d	v7, v23, #3
	shl.2d	v16, v17, #3
	shl.2d	v18, v22, #3
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	cmgt.2d	v0, v0, v18
	cmgt.2d	v4, v2, v16
	uzp1.4s	v0, v4, v0
	ldr	q2, [sp, #13248]                ; 16-byte Reload
	cmgt.2d	v4, v2, v7
	cmgt.2d	v5, v25, v3
	uzp1.4s	v4, v5, v4
	uzp1.8h	v0, v4, v0
	and.16b	v0, v28, v0
	xtn.8b	v0, v0
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #13344]                ; 8-byte Reload
	and.8b	v4, v4, v5
	addv.8b	b6, v4
	fmov	w9, s6
	shl.2d	v1, v1, #6
	ldr	q2, [sp, #9200]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	add.2d	v24, v4, v1
	tbz	w9, #0, LBB0_371
; %bb.370:                              ; %cond.load1120
                                        ;   in Loop: Header=BB0_369 Depth=2
	fmov	x10, d24
	ldr	d19, [x10]
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v1, #0000000000000000
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	tbnz	w9, #1, LBB0_372
	b	LBB0_373
LBB0_371:                               ;   in Loop: Header=BB0_369 Depth=2
	movi.2d	v19, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v1, #0000000000000000
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	tbz	w9, #1, LBB0_373
LBB0_372:                               ; %cond.load1126
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.d	x10, v24[1]
	ld1.d	{ v19 }[1], [x10]
LBB0_373:                               ; %else1130
                                        ;   in Loop: Header=BB0_369 Depth=2
	shl.2d	v23, v23, #6
	orr.16b	v23, v23, v9
	ldr	q21, [sp, #9136]                ; 16-byte Reload
	add.2d	v23, v21, v23
	tbnz	w9, #2, LBB0_396
; %bb.374:                              ; %else1136
                                        ;   in Loop: Header=BB0_369 Depth=2
	tbnz	w9, #3, LBB0_397
LBB0_375:                               ; %else1142
                                        ;   in Loop: Header=BB0_369 Depth=2
	shl.2d	v17, v17, #6
	ldr	q21, [sp, #9184]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9120]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbnz	w9, #4, LBB0_398
LBB0_376:                               ; %else1148
                                        ;   in Loop: Header=BB0_369 Depth=2
	tbnz	w9, #5, LBB0_399
LBB0_377:                               ; %else1154
                                        ;   in Loop: Header=BB0_369 Depth=2
	shl.2d	v17, v22, #6
	ldr	q21, [sp, #9168]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9104]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbnz	w9, #6, LBB0_400
LBB0_378:                               ; %else1160
                                        ;   in Loop: Header=BB0_369 Depth=2
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbz	w9, #7, LBB0_380
LBB0_379:                               ; %cond.load1162
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.d	x9, v17[1]
	ld1.d	{ v1 }[1], [x9]
LBB0_380:                               ; %else1166
                                        ;   in Loop: Header=BB0_369 Depth=2
	ldr	q17, [sp, #13264]               ; 16-byte Reload
	cmge.2d	v17, v18, v17
	cmge.2d	v16, v16, v2
	uzp1.4s	v16, v16, v17
	ldr	q17, [sp, #13248]               ; 16-byte Reload
	cmge.2d	v7, v7, v17
	cmge.2d	v3, v3, v25
	uzp1.4s	v3, v3, v7
	uzp1.8h	v3, v3, v16
	and.16b	v3, v28, v3
	xtn.8b	v3, v3
	mov	b7, v0[0]
	mov.b	v7[4], v0[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	ldr	q16, [sp, #7616]                ; 16-byte Reload
	bsl.16b	v7, v19, v16
	mov	b16, v3[0]
	mov.b	v16[4], v3[1]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmge.2d	v16, v16, #0
	and.16b	v7, v16, v7
	str	q7, [sp, #7616]                 ; 16-byte Spill
	ldr	q16, [sp, #11472]               ; 16-byte Reload
	add.2d	v7, v7, v16
	fmov	w9, s6
	shl.2d	v6, v15, #6
	ldr	q16, [sp, #9088]                ; 16-byte Reload
	orr.16b	v6, v6, v16
	ldr	q16, [sp, #9024]                ; 16-byte Reload
	add.2d	v6, v16, v6
	tbz	w9, #0, LBB0_382
; %bb.381:                              ; %cond.store1169
                                        ;   in Loop: Header=BB0_369 Depth=2
	fmov	x10, d6
	str	d7, [x10]
LBB0_382:                               ; %else1172
                                        ;   in Loop: Header=BB0_369 Depth=2
	tbz	w9, #1, LBB0_384
; %bb.383:                              ; %cond.store1173
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.d	x10, v6[1]
	st1.d	{ v7 }[1], [x10]
LBB0_384:                               ; %else1176
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov	b6, v0[2]
	mov.b	v6[4], v0[3]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q7, [sp, #7600]                 ; 16-byte Reload
	bif.16b	v5, v7, v6
	mov	b6, v3[2]
	mov.b	v6[4], v3[3]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmge.2d	v6, v6, #0
	and.16b	v5, v6, v5
	str	q5, [sp, #7600]                 ; 16-byte Spill
	ldr	q6, [sp, #11456]                ; 16-byte Reload
	add.2d	v5, v5, v6
	shl.2d	v6, v12, #6
	ldr	q7, [sp, #9072]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #9008]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #2, LBB0_386
; %bb.385:                              ; %cond.store1177
                                        ;   in Loop: Header=BB0_369 Depth=2
	fmov	x10, d6
	str	d5, [x10]
LBB0_386:                               ; %else1180
                                        ;   in Loop: Header=BB0_369 Depth=2
	tbz	w9, #3, LBB0_388
; %bb.387:                              ; %cond.store1181
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.d	x10, v6[1]
	st1.d	{ v5 }[1], [x10]
LBB0_388:                               ; %else1184
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov	b5, v0[4]
	mov.b	v5[4], v0[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q6, [sp, #7584]                 ; 16-byte Reload
	bif.16b	v4, v6, v5
	mov	b5, v3[4]
	mov.b	v5[4], v3[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v4, v5, v4
	str	q4, [sp, #7584]                 ; 16-byte Spill
	ldr	q5, [sp, #11440]                ; 16-byte Reload
	add.2d	v4, v4, v5
	shl.2d	v5, v29, #6
	ldr	q6, [sp, #9056]                 ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #8992]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #4, LBB0_390
; %bb.389:                              ; %cond.store1185
                                        ;   in Loop: Header=BB0_369 Depth=2
	fmov	x10, d5
	str	d4, [x10]
LBB0_390:                               ; %else1188
                                        ;   in Loop: Header=BB0_369 Depth=2
	tbz	w9, #5, LBB0_392
; %bb.391:                              ; %cond.store1189
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v4 }[1], [x10]
LBB0_392:                               ; %else1192
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov	b4, v0[6]
	mov.b	v4[4], v0[7]
	ushll.2d	v0, v4, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q4, [sp, #7568]                 ; 16-byte Reload
	bsl.16b	v0, v1, v4
	mov	b1, v3[6]
	mov.b	v1[4], v3[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7568]                 ; 16-byte Spill
	ldr	q1, [sp, #11424]                ; 16-byte Reload
	add.2d	v0, v0, v1
	mov.16b	v4, v13
	shl.2d	v1, v13, #6
	ldr	q3, [sp, #9040]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8976]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_394
; %bb.393:                              ; %cond.store1193
                                        ;   in Loop: Header=BB0_369 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_394:                               ; %else1196
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.16b	v5, v29
	tbz	w9, #7, LBB0_368
; %bb.395:                              ; %cond.store1197
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_368
LBB0_396:                               ; %cond.load1132
                                        ;   in Loop: Header=BB0_369 Depth=2
	fmov	x10, d23
	ld1.d	{ v5 }[0], [x10]
	tbz	w9, #3, LBB0_375
LBB0_397:                               ; %cond.load1138
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v5 }[1], [x10]
	shl.2d	v17, v17, #6
	ldr	q21, [sp, #9184]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9120]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbz	w9, #4, LBB0_376
LBB0_398:                               ; %cond.load1144
                                        ;   in Loop: Header=BB0_369 Depth=2
	fmov	x10, d17
	ld1.d	{ v4 }[0], [x10]
	tbz	w9, #5, LBB0_377
LBB0_399:                               ; %cond.load1150
                                        ;   in Loop: Header=BB0_369 Depth=2
	mov.d	x10, v17[1]
	ld1.d	{ v4 }[1], [x10]
	shl.2d	v17, v22, #6
	ldr	q21, [sp, #9168]                ; 16-byte Reload
	orr.16b	v17, v17, v21
	ldr	q21, [sp, #9104]                ; 16-byte Reload
	add.2d	v17, v21, v17
	tbz	w9, #6, LBB0_378
LBB0_400:                               ; %cond.load1156
                                        ;   in Loop: Header=BB0_369 Depth=2
	fmov	x10, d17
	ld1.d	{ v1 }[0], [x10]
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbnz	w9, #7, LBB0_379
	b	LBB0_380
LBB0_401:                               ; %direct.false479
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q24, [sp, #1568]                ; 16-byte Spill
	str	q6, [sp, #1584]                 ; 16-byte Spill
	str	q4, [sp, #1600]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #512]                  ; 16-byte Reload
	ldr	q6, [sp, #1552]                 ; 16-byte Reload
	bit.16b	v6, v3, v14
	ldr	q4, [sp, #3728]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #3728]                 ; 16-byte Spill
	ldr	q2, [sp, #3824]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #3824]                 ; 16-byte Spill
	ldr	q4, [sp, #3744]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #3744]                 ; 16-byte Spill
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v3, v4, v14
	str	q3, [sp, #3760]                 ; 16-byte Spill
	ldr	q3, [sp, #3792]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #3792]                 ; 16-byte Spill
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #3776]                 ; 16-byte Spill
	ldr	q3, [sp, #3808]                 ; 16-byte Reload
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #3808]                 ; 16-byte Spill
	ldr	q3, [sp, #10416]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #10416]                ; 16-byte Spill
	ldr	q3, [sp, #10448]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #10448]                ; 16-byte Spill
	ldr	q3, [sp, #10432]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #10432]                ; 16-byte Spill
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x9, d0
	cmp	x9, #0
	b.le	LBB0_1133
; %bb.402:                              ;   in Loop: Header=BB0_92 Depth=1
	ldr	q21, [sp, #1520]                ; 16-byte Reload
	ldr	q29, [sp, #1488]                ; 16-byte Reload
	ldr	q15, [sp, #1360]                ; 16-byte Reload
	ldr	d23, [sp, #11576]               ; 8-byte Reload
LBB0_403:                               ; %direct.false491
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q0, [sp, #1536]                 ; 16-byte Spill
	str	q5, [sp, #1616]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #496]                  ; 16-byte Reload
	ldr	q4, [sp, #3696]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #3696]                 ; 16-byte Spill
	ldr	q4, [sp, #3600]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #3600]                 ; 16-byte Spill
	ldr	q4, [sp, #3712]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #3712]                 ; 16-byte Spill
	ldr	q4, [sp, #3616]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #3616]                 ; 16-byte Spill
	ldr	q3, [sp, #3632]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v3, v4, v14
	str	q3, [sp, #3632]                 ; 16-byte Spill
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #3664]                 ; 16-byte Spill
	ldr	q3, [sp, #3648]                 ; 16-byte Reload
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #3648]                 ; 16-byte Spill
	ldr	q3, [sp, #3680]                 ; 16-byte Reload
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #3680]                 ; 16-byte Spill
	ldr	q3, [sp, #10352]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #10352]                ; 16-byte Spill
	ldr	q3, [sp, #10384]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #10384]                ; 16-byte Spill
	ldr	q3, [sp, #10368]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #10368]                ; 16-byte Spill
	ldr	q1, [sp, #10400]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10400]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #0
	str	q6, [sp, #1552]                 ; 16-byte Spill
	b.le	LBB0_1151
LBB0_404:                               ; %direct.false499
                                        ;   in Loop: Header=BB0_92 Depth=1
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #480]                  ; 16-byte Reload
	ldr	q4, [sp, #3504]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #3504]                 ; 16-byte Spill
	ldr	q4, [sp, #3536]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #3536]                 ; 16-byte Spill
	ldr	q4, [sp, #3520]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #3520]                 ; 16-byte Spill
	ldr	q4, [sp, #3552]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #3552]                 ; 16-byte Spill
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v3, v4, v14
	str	q3, [sp, #3568]                 ; 16-byte Spill
	ldr	q3, [sp, #3472]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #3472]                 ; 16-byte Spill
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #3584]                 ; 16-byte Spill
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #3488]                 ; 16-byte Spill
	ldr	q3, [sp, #10288]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #10288]                ; 16-byte Spill
	ldr	q3, [sp, #10320]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #10320]                ; 16-byte Spill
	ldr	q3, [sp, #10304]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #10304]                ; 16-byte Spill
	ldr	q1, [sp, #10336]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10336]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #0
	b.le	LBB0_1185
LBB0_405:                               ; %direct.false511
                                        ;   in Loop: Header=BB0_92 Depth=1
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #464]                  ; 16-byte Reload
	ldr	q4, [sp, #6080]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #6080]                 ; 16-byte Spill
	ldr	q4, [sp, #6112]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #6112]                 ; 16-byte Spill
	ldr	q4, [sp, #6096]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #6096]                 ; 16-byte Spill
	ldr	q4, [sp, #6128]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #6128]                 ; 16-byte Spill
	ldr	q3, [sp, #6144]                 ; 16-byte Reload
	ldr	q4, [sp, #2144]                 ; 16-byte Reload
	bit.16b	v3, v4, v14
	str	q3, [sp, #6144]                 ; 16-byte Spill
	ldr	q3, [sp, #6176]                 ; 16-byte Reload
	ldr	q4, [sp, #2128]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #6176]                 ; 16-byte Spill
	ldr	q3, [sp, #6160]                 ; 16-byte Reload
	ldr	q4, [sp, #2112]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #6160]                 ; 16-byte Spill
	ldr	q3, [sp, #6192]                 ; 16-byte Reload
	ldr	q4, [sp, #2096]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #6192]                 ; 16-byte Spill
	ldr	q3, [sp, #10256]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #10256]                ; 16-byte Spill
	ldr	q3, [sp, #10224]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #10224]                ; 16-byte Spill
	ldr	q3, [sp, #10272]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #10272]                ; 16-byte Spill
	ldr	q1, [sp, #10240]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10240]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #0
	b.le	LBB0_1219
LBB0_406:                               ; %direct.false522
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q9, [sp, #1696]                 ; 16-byte Spill
	str	q26, [sp, #1728]                ; 16-byte Spill
	str	q21, [sp, #1520]                ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #448]                  ; 16-byte Reload
	ldr	q4, [sp, #8944]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8944]                 ; 16-byte Spill
	ldr	q4, [sp, #8832]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8832]                 ; 16-byte Spill
	ldr	q4, [sp, #8960]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8960]                 ; 16-byte Spill
	ldr	q4, [sp, #8848]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8848]                 ; 16-byte Spill
	ldr	q3, [sp, #8880]                 ; 16-byte Reload
	ldp	q4, q2, [sp, #960]              ; 32-byte Folded Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8880]                 ; 16-byte Spill
	ldr	q3, [sp, #8912]                 ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #8912]                 ; 16-byte Spill
	ldr	q3, [sp, #8896]                 ; 16-byte Reload
	ldr	q4, [sp, #944]                  ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #8896]                 ; 16-byte Spill
	ldr	q3, [sp, #8928]                 ; 16-byte Reload
	ldr	q4, [sp, #992]                  ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #8928]                 ; 16-byte Spill
	bic.16b	v29, v29, v14
	ldr	q3, [sp, #11216]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	ldr	q21, [sp, #1504]                ; 16-byte Reload
	bic.16b	v21, v21, v1
	ldr	q6, [sp, #8864]                 ; 16-byte Reload
	bic.16b	v6, v6, v0
	fmov	x9, d6
	cmp	x9, #17
	b.le	LBB0_410
LBB0_407:                               ; %direct.false533
                                        ;   in Loop: Header=BB0_92 Depth=1
	mov.16b	v9, v23
	str	q29, [sp, #1488]                ; 16-byte Spill
	str	q15, [sp, #1360]                ; 16-byte Spill
	str	q21, [sp, #1504]                ; 16-byte Spill
	str	q3, [sp, #11216]                ; 16-byte Spill
	str	q6, [sp, #8864]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #432]                  ; 16-byte Reload
	ldr	q4, [sp, #11184]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #11184]                ; 16-byte Spill
	ldr	q4, [sp, #11088]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #11088]                ; 16-byte Spill
	ldr	q2, [sp, #11200]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #11200]                ; 16-byte Spill
	ldr	q4, [sp, #11104]                ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #11104]                ; 16-byte Spill
	ldr	q3, [sp, #11120]                ; 16-byte Reload
	ldp	q4, q2, [sp, #960]              ; 32-byte Folded Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #11120]                ; 16-byte Spill
	ldr	q3, [sp, #11152]                ; 16-byte Reload
	bit.16b	v3, v4, v11
	str	q3, [sp, #11152]                ; 16-byte Spill
	ldr	q3, [sp, #11136]                ; 16-byte Reload
	ldr	q4, [sp, #944]                  ; 16-byte Reload
	bit.16b	v3, v4, v1
	str	q3, [sp, #11136]                ; 16-byte Spill
	ldr	q3, [sp, #11168]                ; 16-byte Reload
	ldr	q4, [sp, #992]                  ; 16-byte Reload
	bit.16b	v3, v4, v0
	str	q3, [sp, #11168]                ; 16-byte Spill
	ldr	q26, [sp, #1424]                ; 16-byte Reload
	bic.16b	v26, v26, v14
	ldr	q21, [sp, #1456]                ; 16-byte Reload
	bic.16b	v21, v21, v11
	ldr	q25, [sp, #1440]                ; 16-byte Reload
	bic.16b	v25, v25, v1
	ldr	q18, [sp, #1472]                ; 16-byte Reload
	bic.16b	v18, v18, v0
	fmov	x9, d18
	cmp	x9, #17
	b.gt	LBB0_508
; %bb.408:                              ; %direct.true550.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q27, [sp, #13296]               ; 16-byte Reload
	b	LBB0_460
LBB0_409:                               ; %else1610
                                        ;   in Loop: Header=BB0_410 Depth=2
	add.2d	v3, v3, v10
	add.2d	v21, v21, v2
	add.2d	v29, v29, v8
	add.2d	v6, v6, v20
	fmov	x9, d6
	cmp	x9, #18
	b.ge	LBB0_407
LBB0_410:                               ; %direct.true532
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v1, v30, #0
	sshll.2d	v0, v31, #0
	str	q6, [sp, #8864]                 ; 16-byte Spill
	and.16b	v6, v0, v6
	str	q3, [sp, #11216]                ; 16-byte Spill
	and.16b	v7, v11, v3
	and.16b	v16, v1, v21
	and.16b	v18, v14, v29
	fmov	x9, d18
	ldr	q3, [sp, #11632]                ; 16-byte Reload
	fmov	x15, d3
	sdiv	x6, x9, x15
	fmov	d3, x6
	mov.d	x9, v18[1]
	sdiv	x7, x9, x27
	mov.d	v3[1], x7
	fmov	x9, d16
	ldr	q4, [sp, #11664]                ; 16-byte Reload
	fmov	x19, d4
	sdiv	x20, x9, x19
	fmov	d4, x20
	mov.d	x9, v16[1]
	sdiv	x23, x9, x26
	mov.d	v4[1], x23
	fmov	x9, d7
	ldr	q5, [sp, #11648]                ; 16-byte Reload
	fmov	x21, d5
	sdiv	x22, x9, x21
	fmov	d5, x22
	mov.d	x9, v7[1]
	sdiv	x24, x9, x25
	mov.d	v5[1], x24
	fmov	x9, d6
	ldr	q17, [sp, #11680]               ; 16-byte Reload
	fmov	x25, d17
	sdiv	x26, x9, x25
	fmov	d19, x26
	mov.d	x9, v6[1]
	ldr	x10, [sp, #11704]               ; 8-byte Reload
	sdiv	x27, x9, x10
	mov.d	v19[1], x27
	and.16b	v3, v14, v3
	mov.d	x9, v3[1]
	and.16b	v1, v1, v4
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d3, x10
	mov.d	v3[1], x9
	mov.d	x9, v1[1]
	and.16b	v4, v11, v5
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d1
	ldr	q1, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d17, x10
	mov.d	v17[1], x9
	mov.d	x9, v4[1]
	and.16b	v0, v0, v19
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d4
	ldr	q1, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d19, x10
	mov.d	v19[1], x9
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	shl.2d	v9, v1, #3
	shl.2d	v5, v19, #3
	shl.2d	v4, v17, #3
	shl.2d	v2, v3, #3
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	str	q2, [sp, #11840]                ; 16-byte Spill
	cmgt.2d	v0, v0, v2
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	str	q4, [sp, #11856]                ; 16-byte Spill
	cmgt.2d	v4, v2, v4
	uzp1.4s	v0, v4, v0
	ldr	q2, [sp, #13248]                ; 16-byte Reload
	mov.16b	v12, v5
	cmgt.2d	v4, v2, v5
	cmgt.2d	v5, v25, v9
	uzp1.4s	v4, v5, v4
	uzp1.8h	v0, v4, v0
	and.16b	v0, v28, v0
	xtn.8b	v0, v0
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #13344]                ; 8-byte Reload
	and.8b	v4, v4, v5
	addv.8b	b2, v4
	str	d2, [sp, #11872]                ; 8-byte Spill
	fmov	w9, s2
	shl.2d	v1, v1, #6
	ldr	q4, [sp, #9088]                 ; 16-byte Reload
	orr.16b	v1, v1, v4
	ldr	q4, [sp, #9024]                 ; 16-byte Reload
	add.2d	v22, v4, v1
	tbz	w9, #0, LBB0_412
; %bb.411:                              ; %cond.load1481
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d22
	ldr	d20, [x10]
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.16b	v2, v15
	mov.16b	v15, v21
	tbnz	w9, #1, LBB0_413
	b	LBB0_414
LBB0_412:                               ;   in Loop: Header=BB0_410 Depth=2
	movi.2d	v20, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v1, #0000000000000000
	mov.16b	v2, v15
	mov.16b	v15, v21
	tbz	w9, #1, LBB0_414
LBB0_413:                               ; %cond.load1487
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x10, v22[1]
	ld1.d	{ v20 }[1], [x10]
LBB0_414:                               ; %else1491
                                        ;   in Loop: Header=BB0_410 Depth=2
	shl.2d	v19, v19, #6
	ldr	q21, [sp, #9072]                ; 16-byte Reload
	orr.16b	v19, v19, v21
	ldr	q21, [sp, #9008]                ; 16-byte Reload
	add.2d	v19, v21, v19
	tbnz	w9, #2, LBB0_424
; %bb.415:                              ; %else1497
                                        ;   in Loop: Header=BB0_410 Depth=2
	tbnz	w9, #3, LBB0_425
LBB0_416:                               ; %else1503
                                        ;   in Loop: Header=BB0_410 Depth=2
	shl.2d	v17, v17, #6
	ldr	q19, [sp, #9056]                ; 16-byte Reload
	orr.16b	v17, v17, v19
	ldr	q19, [sp, #8992]                ; 16-byte Reload
	add.2d	v17, v19, v17
	tbnz	w9, #4, LBB0_426
LBB0_417:                               ; %else1509
                                        ;   in Loop: Header=BB0_410 Depth=2
	tbnz	w9, #5, LBB0_427
LBB0_418:                               ; %else1515
                                        ;   in Loop: Header=BB0_410 Depth=2
	shl.2d	v3, v3, #6
	ldr	q17, [sp, #9040]                ; 16-byte Reload
	orr.16b	v3, v3, v17
	ldr	q17, [sp, #8976]                ; 16-byte Reload
	add.2d	v3, v17, v3
	tbz	w9, #6, LBB0_420
LBB0_419:                               ; %cond.load1517
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d3
	ld1.d	{ v1 }[0], [x10]
LBB0_420:                               ; %else1521
                                        ;   in Loop: Header=BB0_410 Depth=2
	ldr	x10, [sp, #11704]               ; 8-byte Reload
	mul	x10, x27, x10
	mul	x11, x26, x25
	fmov	d19, x11
	mov.d	v19[1], x10
	ldr	x10, [sp, #11560]               ; 8-byte Reload
	mul	x10, x23, x10
	mul	x11, x20, x19
	fmov	d17, x11
	mov.d	v17[1], x10
	ldr	x10, [sp, #11568]               ; 8-byte Reload
	mul	x10, x24, x10
	mul	x11, x22, x21
	fmov	d22, x11
	mov.d	v22[1], x10
	ldr	x27, [sp, #11368]               ; 8-byte Reload
	mul	x10, x7, x27
	mul	x11, x6, x15
	fmov	d23, x11
	mov.d	v23[1], x10
	sub.2d	v18, v18, v23
	sub.2d	v7, v7, v22
	sub.2d	v17, v16, v17
	sub.2d	v16, v6, v19
	tbz	w9, #7, LBB0_422
; %bb.421:                              ; %cond.load1523
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x9, v3[1]
	ld1.d	{ v1 }[1], [x9]
LBB0_422:                               ; %else1527
                                        ;   in Loop: Header=BB0_410 Depth=2
	sshll.2d	v23, v31, #0
	sshll.2d	v25, v30, #0
	and.16b	v3, v14, v18
	and.16b	v6, v11, v7
	and.16b	v7, v25, v17
	and.16b	v16, v23, v16
	mov.d	x9, v16[1]
	ldr	q17, [sp, #12992]               ; 16-byte Reload
	mov.d	x15, v17[1]
	sdiv	x22, x9, x15
	fmov	x9, d16
	fmov	x10, d17
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d17, x9
	mov.d	v17[1], x22
	mov.d	x9, v7[1]
	ldr	q19, [sp, #13008]               ; 16-byte Reload
	mov.d	x11, v19[1]
	sdiv	x9, x9, x11
	fmov	x12, d7
	mov.d	x6, v6[1]
	ldr	q18, [sp, #13024]               ; 16-byte Reload
	mov.d	x19, v18[1]
	fmov	x23, d19
	sdiv	x20, x6, x19
	fmov	x6, d6
	fmov	x24, d18
	mov.d	x7, v3[1]
	sdiv	x21, x6, x24
	ldr	q18, [sp, #13040]               ; 16-byte Reload
	mov.d	x25, v18[1]
	sdiv	x6, x7, x25
	fmov	x7, d3
	fmov	x26, d18
	sdiv	x7, x7, x26
	mul	x25, x6, x25
	mul	x26, x7, x26
	fmov	d22, x26
	mov.d	v22[1], x25
	mul	x19, x20, x19
	mul	x24, x21, x24
	fmov	d19, x24
	mov.d	v19[1], x19
	mul	x11, x9, x11
	sdiv	x19, x12, x23
	mul	x12, x19, x23
	fmov	d18, x12
	mov.d	v18[1], x11
	mul	x11, x22, x15
	fmov	d24, x10
	mov.d	v24[1], x11
	sub.2d	v16, v16, v24
	sub.2d	v18, v7, v18
	sub.2d	v19, v6, v19
	sub.2d	v10, v3, v22
	ldr	q3, [sp, #13088]                ; 16-byte Reload
	cmeq.2d	v3, v3, v10
	ldr	q6, [sp, #13136]                ; 16-byte Reload
	cmeq.2d	v6, v6, v18
	uzp1.4s	v3, v6, v3
	ldr	q6, [sp, #13104]                ; 16-byte Reload
	cmeq.2d	v6, v6, v19
	ldr	q7, [sp, #13120]                ; 16-byte Reload
	cmeq.2d	v7, v7, v16
	uzp1.4s	v6, v7, v6
	uzp1.8h	v26, v6, v3
	and.16b	v3, v28, v26
	xtn.8b	v27, v3
	shl.8b	v3, v27, #7
	cmlt.8b	v3, v3, #0
	ldr	d6, [sp, #13344]                ; 8-byte Reload
	and.8b	v3, v3, v6
	addv.8b	b3, v3
	fmov	w15, s3
	shl.2d	v3, v17, #6
	ldr	q6, [sp, #6192]                 ; 16-byte Reload
	orr.16b	v3, v3, v6
	ldr	q6, [sp, #6128]                 ; 16-byte Reload
	add.2d	v3, v6, v3
	tbz	w15, #0, LBB0_428
; %bb.423:                              ; %cond.load1530
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d3
	ldr	d13, [x10]
	b	LBB0_429
LBB0_424:                               ; %cond.load1493
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d19
	ld1.d	{ v5 }[0], [x10]
	tbz	w9, #3, LBB0_416
LBB0_425:                               ; %cond.load1499
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x10, v19[1]
	ld1.d	{ v5 }[1], [x10]
	shl.2d	v17, v17, #6
	ldr	q19, [sp, #9056]                ; 16-byte Reload
	orr.16b	v17, v17, v19
	ldr	q19, [sp, #8992]                ; 16-byte Reload
	add.2d	v17, v19, v17
	tbz	w9, #4, LBB0_417
LBB0_426:                               ; %cond.load1505
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d17
	ld1.d	{ v4 }[0], [x10]
	tbz	w9, #5, LBB0_418
LBB0_427:                               ; %cond.load1511
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x10, v17[1]
	ld1.d	{ v4 }[1], [x10]
	shl.2d	v3, v3, #6
	ldr	q17, [sp, #9040]                ; 16-byte Reload
	orr.16b	v3, v3, v17
	ldr	q17, [sp, #8976]                ; 16-byte Reload
	add.2d	v3, v17, v3
	tbnz	w9, #6, LBB0_419
	b	LBB0_420
LBB0_428:                               ;   in Loop: Header=BB0_410 Depth=2
	movi.2d	v13, #0000000000000000
LBB0_429:                               ; %else1534
                                        ;   in Loop: Header=BB0_410 Depth=2
	movi.2d	v6, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v22, #0000000000000000
	ldr	q24, [sp, #13248]               ; 16-byte Reload
	ldr	x26, [sp, #11560]               ; 8-byte Reload
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	tbz	w15, #1, LBB0_431
; %bb.430:                              ; %cond.load1536
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x10, v3[1]
	ld1.d	{ v13 }[1], [x10]
LBB0_431:                               ; %else1540
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	d3, x21
	mov.d	v3[1], x20
	shl.2d	v3, v3, #6
	ldr	q17, [sp, #6176]                ; 16-byte Reload
	orr.16b	v3, v3, v17
	ldr	q17, [sp, #6112]                ; 16-byte Reload
	add.2d	v3, v17, v3
	tbz	w15, #2, LBB0_433
; %bb.432:                              ; %cond.load1542
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d3
	ld1.d	{ v6 }[0], [x10]
LBB0_433:                               ; %else1546
                                        ;   in Loop: Header=BB0_410 Depth=2
	tbz	w15, #3, LBB0_435
; %bb.434:                              ; %cond.load1548
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x10, v3[1]
	ld1.d	{ v6 }[1], [x10]
LBB0_435:                               ; %else1552
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	d3, x19
	mov.d	v3[1], x9
	shl.2d	v3, v3, #6
	ldr	q17, [sp, #6160]                ; 16-byte Reload
	orr.16b	v3, v3, v17
	ldr	q17, [sp, #6096]                ; 16-byte Reload
	add.2d	v3, v17, v3
	tbz	w15, #4, LBB0_437
; %bb.436:                              ; %cond.load1554
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x9, d3
	ld1.d	{ v7 }[0], [x9]
LBB0_437:                               ; %else1558
                                        ;   in Loop: Header=BB0_410 Depth=2
	tbz	w15, #5, LBB0_439
; %bb.438:                              ; %cond.load1560
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x9, v3[1]
	ld1.d	{ v7 }[1], [x9]
LBB0_439:                               ; %else1564
                                        ;   in Loop: Header=BB0_410 Depth=2
	ldr	q3, [sp, #13264]                ; 16-byte Reload
	ldr	q17, [sp, #11840]               ; 16-byte Reload
	cmge.2d	v3, v17, v3
	ldr	q17, [sp, #13296]               ; 16-byte Reload
	ldr	q21, [sp, #11856]               ; 16-byte Reload
	cmge.2d	v17, v21, v17
	cmge.2d	v24, v12, v24
	ldr	q28, [sp, #13152]               ; 16-byte Reload
	cmge.2d	v28, v9, v28
	uzp1.4s	v3, v17, v3
	uzp1.4s	v17, v28, v24
	uzp1.8h	v3, v17, v3
	ldr	q17, [sp, #13280]               ; 16-byte Reload
	and.16b	v3, v17, v3
	xtn.8b	v17, v3
	fmov	d3, x7
	mov.d	v3[1], x6
	shl.2d	v3, v3, #6
	ldr	q21, [sp, #6144]                ; 16-byte Reload
	orr.16b	v3, v3, v21
	ldr	q21, [sp, #6080]                ; 16-byte Reload
	add.2d	v3, v21, v3
	tbz	w15, #6, LBB0_441
; %bb.440:                              ; %cond.load1566
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x9, d3
	ld1.d	{ v22 }[0], [x9]
LBB0_441:                               ; %else1570
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.16b	v21, v15
	mov	b24, v0[0]
	mov.b	v24[4], v0[1]
	ushll.2d	v24, v24, #0
	shl.2d	v24, v24, #63
	cmlt.2d	v24, v24, #0
	ldr	q28, [sp, #10800]               ; 16-byte Reload
	bsl.16b	v24, v20, v28
	mov	b28, v0[2]
	mov.b	v28[4], v0[3]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	bif.16b	v5, v2, v28
	mov	b28, v0[4]
	mov.b	v28[4], v0[5]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	ldr	q15, [sp, #10832]               ; 16-byte Reload
	bif.16b	v4, v15, v28
	mov	b28, v0[6]
	mov.b	v28[4], v0[7]
	ushll.2d	v0, v28, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q28, [sp, #10848]               ; 16-byte Reload
	bsl.16b	v0, v1, v28
	mov	b1, v17[6]
	mov.b	v1[4], v17[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #10848]                ; 16-byte Spill
	mov	b0, v17[4]
	mov.b	v0[4], v17[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	mov	b1, v17[2]
	mov.b	v1[4], v17[3]
	and.16b	v0, v0, v4
	str	q0, [sp, #10832]                ; 16-byte Spill
	ushll.2d	v0, v1, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	and.16b	v15, v0, v5
	mov	b0, v17[0]
	mov.b	v0[4], v17[1]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	and.16b	v0, v0, v24
	str	q0, [sp, #10800]                ; 16-byte Spill
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	bit.16b	v0, v10, v14
	str	q0, [sp, #10896]                ; 16-byte Spill
	ldr	q0, [sp, #10864]                ; 16-byte Reload
	bit.16b	v0, v19, v11
	str	q0, [sp, #10864]                ; 16-byte Spill
	ldr	q0, [sp, #10912]                ; 16-byte Reload
	bit.16b	v0, v18, v25
	str	q0, [sp, #10912]                ; 16-byte Spill
	ldr	q0, [sp, #10880]                ; 16-byte Reload
	bit.16b	v0, v16, v23
	str	q0, [sp, #10880]                ; 16-byte Spill
	ldr	q28, [sp, #13280]               ; 16-byte Reload
	bic.16b	v0, v28, v26
	xtn.8b	v0, v0
	tbz	w15, #7, LBB0_443
; %bb.442:                              ; %cond.load1572
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x9, v3[1]
	ld1.d	{ v22 }[1], [x9]
LBB0_443:                               ; %else1576
                                        ;   in Loop: Header=BB0_410 Depth=2
	ldr	q20, [sp, #13312]               ; 16-byte Reload
	ldr	d23, [sp, #11576]               ; 8-byte Reload
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q10, [sp, #13056]               ; 16-byte Reload
	mov	b1, v27[6]
	mov.b	v1[4], v27[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	b3, v27[4]
	mov.b	v3[4], v27[5]
	ldr	q4, [sp, #6992]                 ; 16-byte Reload
	bsl.16b	v1, v22, v4
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q4, [sp, #7104]                 ; 16-byte Reload
	bsl.16b	v3, v7, v4
	mov	b4, v27[2]
	mov.b	v4[4], v27[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q5, [sp, #7328]                 ; 16-byte Reload
	bsl.16b	v4, v6, v5
	mov	b5, v27[0]
	mov.b	v5[4], v27[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q6, [sp, #7504]                 ; 16-byte Reload
	bsl.16b	v5, v13, v6
	mov	b6, v0[0]
	mov.b	v6[4], v0[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmge.2d	v6, v6, #0
	and.16b	v6, v6, v5
	mov	b5, v0[2]
	mov.b	v5[4], v0[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v7, v5, v4
	mov	b4, v0[4]
	mov.b	v4[4], v0[5]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmge.2d	v4, v4, #0
	mov	b5, v0[6]
	mov.b	v5[4], v0[7]
	and.16b	v16, v4, v3
	ushll.2d	v0, v5, #0
	shl.2d	v0, v0, #63
	cmge.2d	v0, v0, #0
	and.16b	v5, v0, v1
	ldr	q0, [sp, #10896]                ; 16-byte Reload
	xtn.2s	v0, v0
	ldr	q1, [sp, #10912]                ; 16-byte Reload
	xtn.2s	v1, v1
	ldr	q3, [sp, #10864]                ; 16-byte Reload
	xtn.2s	v3, v3
	ldr	q4, [sp, #10880]                ; 16-byte Reload
	xtn.2s	v4, v4
	mov.s	w10, v4[1]
	fmov	w9, s4
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w11, lo
	and	x12, x9, #0x7
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #968
	bfxil	x15, x9, #0, #3
	ldr	q4, [sp, #13168]                ; 16-byte Reload
	str	d4, [sp, #17352]
	ldrb	w9, [x15]
	and	w9, w16, w9
	str	q5, [x13, #3920]
	str	q16, [x13, #3904]
	str	q7, [x13, #3888]
	str	q6, [x13, #3872]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #976
	ldr	x12, [x15, x12, lsl #3]
	tst	w11, w9
	csel	x9, x12, xzr, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	and	x12, x10, #0x7
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #968
	bfxil	x15, x10, #0, #3
	ldrb	w10, [x15]
	str	q5, [x13, #3984]
	str	q16, [x13, #3968]
	str	q7, [x13, #3952]
	str	q6, [x13, #3936]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1040
	ldr	x12, [x15, x12, lsl #3]
	and	w10, w17, w10
	tst	w11, w10
	csel	x15, x12, xzr, ne
	mov.s	w10, v3[1]
	fmov	w11, s3
	cmp	w11, #8
	csel	w11, w11, wzr, lo
	cset	w12, lo
	and	x6, x11, #0x7
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #968
	bfxil	x7, x11, #0, #3
	ldrb	w11, [x7]
	and	w11, w0, w11
	str	q5, [x13, #4048]
	str	q16, [x13, #4032]
	str	q7, [x13, #4016]
	str	q6, [x13, #4000]
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #1104
	ldr	x6, [x7, x6, lsl #3]
	tst	w12, w11
	csel	x6, x6, xzr, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	and	x12, x10, #0x7
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #968
	bfxil	x7, x10, #0, #3
	ldrb	w10, [x7]
	and	w10, w1, w10
	str	q5, [x13, #4112]
	str	q16, [x13, #4096]
	str	q7, [x13, #4080]
	str	q6, [x13, #4064]
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #1168
	ldr	x12, [x7, x12, lsl #3]
	tst	w11, w10
	csel	x7, x12, xzr, ne
	mov.s	w10, v1[1]
	fmov	w11, s1
	cmp	w11, #8
	csel	w11, w11, wzr, lo
	cset	w12, lo
	and	x19, x11, #0x7
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #968
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	str	q5, [x13, #4176]
	str	q16, [x13, #4160]
	str	q7, [x13, #4144]
	str	q6, [x13, #4128]
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #1232
	ldr	x19, [x20, x19, lsl #3]
	and	w11, w2, w11
	tst	w12, w11
	csel	x19, x19, xzr, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	and	x12, x10, #0x7
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #968
	bfxil	x20, x10, #0, #3
	ldrb	w10, [x20]
	and	w10, w3, w10
	str	q5, [x13, #4240]
	str	q16, [x13, #4224]
	str	q7, [x13, #4208]
	str	q6, [x13, #4192]
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #1296
	ldr	x12, [x20, x12, lsl #3]
	tst	w11, w10
	csel	x20, x12, xzr, ne
	mov.s	w10, v0[1]
	fmov	w11, s0
	cmp	w11, #8
	csel	w11, w11, wzr, lo
	cset	w12, lo
	and	x21, x11, #0x7
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #968
	bfxil	x22, x11, #0, #3
	ldrb	w11, [x22]
	and	w11, w4, w11
	str	q5, [x13, #4304]
	str	q16, [x13, #4288]
	str	q7, [x13, #4272]
	str	q6, [x13, #4256]
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #1360
	ldr	x21, [x22, x21, lsl #3]
	tst	w12, w11
	csel	x11, x21, xzr, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w12, lo
	and	x21, x10, #0x7
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #968
	bfxil	x22, x10, #0, #3
	ldrb	w10, [x22]
	and	w10, w5, w10
	str	q5, [sp, #6992]                 ; 16-byte Spill
	str	q5, [x13, #4368]
	str	q16, [sp, #7104]                ; 16-byte Spill
	str	q16, [x13, #4352]
	str	q7, [sp, #7328]                 ; 16-byte Spill
	str	q7, [x13, #4336]
	str	q6, [sp, #7504]                 ; 16-byte Spill
	str	q6, [x13, #4320]
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #1424
	ldr	x21, [x22, x21, lsl #3]
	tst	w12, w10
	csel	x10, x21, xzr, ne
	fmov	d0, x9
	mov.d	v0[1], x15
	fmov	d3, x6
	mov.d	v3[1], x7
	fmov	d4, x19
	mov.d	v4[1], x20
	fmov	d5, x11
	mov.d	v5[1], x10
	ldr	d1, [sp, #11872]                ; 8-byte Reload
	fmov	w9, s1
	ldr	q1, [sp, #8928]                 ; 16-byte Reload
	ldr	q6, [sp, #8864]                 ; 16-byte Reload
	add.2d	v1, v6, v1
	ldr	q7, [sp, #8848]                 ; 16-byte Reload
	add.2d	v1, v7, v1
	ldr	q7, [sp, #10848]                ; 16-byte Reload
	cmge.2d	v5, v5, v7
	ldr	q7, [sp, #10832]                ; 16-byte Reload
	cmge.2d	v4, v4, v7
	uzp1.4s	v4, v4, v5
	cmge.2d	v3, v3, v15
	ldr	q5, [sp, #10800]                ; 16-byte Reload
	cmge.2d	v0, v0, v5
	uzp1.4s	v0, v0, v3
	uzp1.8h	v0, v0, v4
	xtn.8b	v0, v0
	movi.8b	v3, #1
	and.8b	v0, v0, v3
	tbnz	w9, #0, LBB0_451
; %bb.444:                              ; %else1582
                                        ;   in Loop: Header=BB0_410 Depth=2
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q3, [sp, #11216]                ; 16-byte Reload
	tbnz	w9, #1, LBB0_452
LBB0_445:                               ; %else1586
                                        ;   in Loop: Header=BB0_410 Depth=2
	ldr	q1, [sp, #8912]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q3, [sp, #8832]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #2, LBB0_453
LBB0_446:                               ; %else1590
                                        ;   in Loop: Header=BB0_410 Depth=2
	tbnz	w9, #3, LBB0_454
LBB0_447:                               ; %else1594
                                        ;   in Loop: Header=BB0_410 Depth=2
	ldr	q1, [sp, #8896]                 ; 16-byte Reload
	add.2d	v1, v21, v1
	ldr	q3, [sp, #8960]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_455
LBB0_448:                               ; %else1598
                                        ;   in Loop: Header=BB0_410 Depth=2
	tbnz	w9, #5, LBB0_456
LBB0_449:                               ; %else1602
                                        ;   in Loop: Header=BB0_410 Depth=2
	ldr	q1, [sp, #8880]                 ; 16-byte Reload
	add.2d	v1, v29, v1
	ldr	q3, [sp, #8944]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_457
LBB0_450:                               ; %else1606
                                        ;   in Loop: Header=BB0_410 Depth=2
	ldr	q3, [sp, #11216]                ; 16-byte Reload
	tbz	w9, #7, LBB0_409
	b	LBB0_458
LBB0_451:                               ; %cond.store1579
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d1
	str	b0, [x10]
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q3, [sp, #11216]                ; 16-byte Reload
	tbz	w9, #1, LBB0_445
LBB0_452:                               ; %cond.store1583
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[1], [x10]
	ldr	q1, [sp, #8912]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q3, [sp, #8832]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #2, LBB0_446
LBB0_453:                               ; %cond.store1587
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[2], [x10]
	tbz	w9, #3, LBB0_447
LBB0_454:                               ; %cond.store1591
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[3], [x10]
	ldr	q1, [sp, #8896]                 ; 16-byte Reload
	add.2d	v1, v21, v1
	ldr	q3, [sp, #8960]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_448
LBB0_455:                               ; %cond.store1595
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[4], [x10]
	tbz	w9, #5, LBB0_449
LBB0_456:                               ; %cond.store1599
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[5], [x10]
	ldr	q1, [sp, #8880]                 ; 16-byte Reload
	add.2d	v1, v29, v1
	ldr	q3, [sp, #8944]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_450
LBB0_457:                               ; %cond.store1603
                                        ;   in Loop: Header=BB0_410 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[6], [x10]
	ldr	q3, [sp, #11216]                ; 16-byte Reload
	tbz	w9, #7, LBB0_409
LBB0_458:                               ; %cond.store1607
                                        ;   in Loop: Header=BB0_410 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[7], [x9]
	b	LBB0_409
LBB0_459:                               ; %else1741
                                        ;   in Loop: Header=BB0_460 Depth=2
	add.2d	v21, v21, v10
	add.2d	v25, v25, v24
	add.2d	v26, v26, v8
	add.2d	v18, v18, v20
	fmov	x9, d18
	cmp	x9, #18
	b.ge	LBB0_509
LBB0_460:                               ; %direct.true550
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v1, v30, #0
	sshll.2d	v23, v31, #0
	mov.16b	v13, v18
	and.16b	v3, v23, v18
	mov.16b	v12, v21
	and.16b	v18, v11, v21
	mov.16b	v15, v25
	and.16b	v4, v1, v25
	and.16b	v0, v14, v26
	fmov	x9, d0
	ldr	q5, [sp, #11632]                ; 16-byte Reload
	fmov	x15, d5
	sdiv	x6, x9, x15
	fmov	d5, x6
	mov.d	x9, v0[1]
	sdiv	x7, x9, x27
	mov.d	v5[1], x7
	fmov	x9, d4
	ldr	q6, [sp, #11664]                ; 16-byte Reload
	fmov	x19, d6
	sdiv	x20, x9, x19
	fmov	d6, x20
	mov.d	x9, v4[1]
	sdiv	x21, x9, x26
	mov.d	v6[1], x21
	fmov	x9, d18
	ldr	q7, [sp, #11648]                ; 16-byte Reload
	fmov	x22, d7
	sdiv	x23, x9, x22
	fmov	d7, x23
	mov.d	x9, v18[1]
	sdiv	x24, x9, x25
	mov.d	v7[1], x24
	fmov	x10, d3
	ldr	q16, [sp, #11680]               ; 16-byte Reload
	fmov	x9, d16
	sdiv	x25, x10, x9
	fmov	d16, x25
	mov.d	x10, v3[1]
	ldr	x11, [sp, #11704]               ; 8-byte Reload
	sdiv	x26, x10, x11
	mov.d	v16[1], x26
	and.16b	v5, v14, v5
	mov.d	x10, v5[1]
	and.16b	v6, v1, v6
	sdiv	x11, x10, x14
	msub	x10, x11, x14, x10
	fmov	x11, d5
	ldr	q5, [sp, #13232]                ; 16-byte Reload
	fmov	x12, d5
	sdiv	x27, x11, x12
	msub	x11, x27, x12, x11
	fmov	d5, x11
	mov.d	v5[1], x10
	mov.d	x10, v6[1]
	and.16b	v7, v11, v7
	sdiv	x11, x10, x8
	msub	x10, x11, x8, x10
	fmov	x11, d6
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x27, x11, x12
	msub	x11, x27, x12, x11
	fmov	d22, x11
	mov.d	v22[1], x10
	mov.d	x10, v7[1]
	and.16b	v6, v23, v16
	sdiv	x11, x10, x30
	msub	x10, x11, x30, x10
	fmov	x11, d7
	ldr	q7, [sp, #13216]                ; 16-byte Reload
	fmov	x12, d7
	sdiv	x27, x11, x12
	msub	x11, x27, x12, x11
	fmov	d25, x11
	mov.d	v25[1], x10
	mov.d	x10, v6[1]
	sdiv	x11, x10, x28
	msub	x10, x11, x28, x10
	fmov	x11, d6
	ldr	q6, [sp, #13184]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x27, x11, x12
	msub	x11, x27, x12, x11
	fmov	d17, x11
	mov.d	v17[1], x10
	shl.2d	v6, v17, #3
	shl.2d	v7, v25, #3
	shl.2d	v16, v22, #3
	shl.2d	v19, v5, #3
	ldr	q29, [sp, #13264]               ; 16-byte Reload
	cmgt.2d	v19, v29, v19
	cmgt.2d	v16, v27, v16
	uzp1.4s	v16, v16, v19
	ldr	q2, [sp, #13248]                ; 16-byte Reload
	cmgt.2d	v7, v2, v7
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	cmgt.2d	v6, v19, v6
	uzp1.4s	v6, v6, v7
	uzp1.8h	v16, v6, v16
	and.16b	v6, v28, v16
	xtn.8b	v6, v6
	shl.8b	v6, v6, #7
	cmlt.8b	v6, v6, #0
	ldr	d7, [sp, #13344]                ; 8-byte Reload
	and.8b	v7, v6, v7
	addv.8b	b7, v7
	fmov	w27, s7
	ldr	q19, [sp, #9296]                ; 16-byte Reload
	ldr	q21, [sp, #9232]                ; 16-byte Reload
	add.2d	v19, v19, v21
	add.2d	v24, v19, v17
	tbz	w27, #0, LBB0_462
; %bb.461:                              ; %cond.load1612
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d24
	ldr	b19, [x10]
	tbnz	w27, #1, LBB0_463
	b	LBB0_464
LBB0_462:                               ;   in Loop: Header=BB0_460 Depth=2
	movi.2d	v19, #0000000000000000
	tbz	w27, #1, LBB0_464
LBB0_463:                               ; %cond.load1618
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v24[1]
	ld1.b	{ v19 }[1], [x10]
LBB0_464:                               ; %else1622
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	q21, [sp, #9280]                ; 16-byte Reload
	ldr	q24, [sp, #9216]                ; 16-byte Reload
	add.2d	v24, v21, v24
	add.2d	v24, v24, v25
	tbnz	w27, #2, LBB0_473
; %bb.465:                              ; %else1628
                                        ;   in Loop: Header=BB0_460 Depth=2
	tbnz	w27, #3, LBB0_474
LBB0_466:                               ; %else1634
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	q21, [sp, #9264]                ; 16-byte Reload
	ldr	q2, [sp, #9328]                 ; 16-byte Reload
	add.2d	v24, v21, v2
	add.2d	v24, v24, v22
	tbnz	w27, #4, LBB0_475
LBB0_467:                               ; %else1640
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	q27, [sp, #13296]               ; 16-byte Reload
	tbnz	w27, #5, LBB0_476
LBB0_468:                               ; %else1646
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	q21, [sp, #9312]                ; 16-byte Reload
	ldr	q24, [sp, #9248]                ; 16-byte Reload
	add.2d	v24, v24, v21
	add.2d	v24, v24, v5
	tbnz	w27, #6, LBB0_477
LBB0_469:                               ; %else1652
                                        ;   in Loop: Header=BB0_460 Depth=2
	tbz	w27, #7, LBB0_471
LBB0_470:                               ; %cond.load1654
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v24[1]
	ld1.b	{ v19 }[7], [x10]
LBB0_471:                               ; %else1658
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	x10, [sp, #11704]               ; 8-byte Reload
	mul	x10, x26, x10
	mul	x9, x25, x9
	fmov	d24, x9
	mov.d	v24[1], x10
	sub.2d	v3, v3, v24
	ldr	q21, [sp, #7456]                ; 16-byte Reload
	bit.16b	v21, v3, v23
	ldr	q3, [sp, #7392]                 ; 16-byte Reload
	bit.16b	v3, v17, v23
	str	q3, [sp, #7392]                 ; 16-byte Spill
	add.2d	v3, v3, v3
	fmov	w9, s7
	ldr	q17, [sp, #8928]                ; 16-byte Reload
	str	q21, [sp, #7456]                ; 16-byte Spill
	add.2d	v17, v21, v17
	ldr	q21, [sp, #8848]                ; 16-byte Reload
	add.2d	v17, v21, v17
	add.2d	v17, v17, v3
	ldr	x27, [sp, #11368]               ; 8-byte Reload
	tbz	w9, #0, LBB0_478
; %bb.472:                              ; %cond.load1661
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d17
	ldr	b3, [x10]
	ldr	x26, [sp, #11560]               ; 8-byte Reload
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	tbnz	w9, #1, LBB0_479
	b	LBB0_480
LBB0_473:                               ; %cond.load1624
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d24
	ld1.b	{ v19 }[2], [x10]
	tbz	w27, #3, LBB0_466
LBB0_474:                               ; %cond.load1630
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v24[1]
	ld1.b	{ v19 }[3], [x10]
	ldr	q21, [sp, #9264]                ; 16-byte Reload
	ldr	q2, [sp, #9328]                 ; 16-byte Reload
	add.2d	v24, v21, v2
	add.2d	v24, v24, v22
	tbz	w27, #4, LBB0_467
LBB0_475:                               ; %cond.load1636
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d24
	ld1.b	{ v19 }[4], [x10]
	ldr	q27, [sp, #13296]               ; 16-byte Reload
	tbz	w27, #5, LBB0_468
LBB0_476:                               ; %cond.load1642
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v24[1]
	ld1.b	{ v19 }[5], [x10]
	ldr	q21, [sp, #9312]                ; 16-byte Reload
	ldr	q24, [sp, #9248]                ; 16-byte Reload
	add.2d	v24, v24, v21
	add.2d	v24, v24, v5
	tbz	w27, #6, LBB0_469
LBB0_477:                               ; %cond.load1648
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d24
	ld1.b	{ v19 }[6], [x10]
	tbnz	w27, #7, LBB0_470
	b	LBB0_471
LBB0_478:                               ;   in Loop: Header=BB0_460 Depth=2
	movi.2d	v3, #0000000000000000
	ldr	x26, [sp, #11560]               ; 8-byte Reload
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	tbz	w9, #1, LBB0_480
LBB0_479:                               ; %cond.load1667
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v17[1]
	ld1.b	{ v3 }[1], [x10]
LBB0_480:                               ; %else1671
                                        ;   in Loop: Header=BB0_460 Depth=2
	mul	x10, x24, x25
	mul	x11, x23, x22
	fmov	d17, x11
	mov.d	v17[1], x10
	sub.2d	v17, v18, v17
	ldr	q21, [sp, #7440]                ; 16-byte Reload
	bit.16b	v21, v17, v11
	ldr	q17, [sp, #7360]                ; 16-byte Reload
	bit.16b	v17, v25, v11
	str	q17, [sp, #7360]                ; 16-byte Spill
	add.2d	v17, v17, v17
	ldr	q18, [sp, #8912]                ; 16-byte Reload
	str	q21, [sp, #7440]                ; 16-byte Spill
	add.2d	v18, v21, v18
	ldr	q21, [sp, #8832]                ; 16-byte Reload
	add.2d	v18, v21, v18
	add.2d	v17, v18, v17
	tbz	w9, #2, LBB0_482
; %bb.481:                              ; %cond.load1673
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d17
	ld1.b	{ v3 }[2], [x10]
LBB0_482:                               ; %else1677
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.16b	v18, v13
	mov.16b	v21, v12
	mov.16b	v25, v15
	ldr	q24, [sp, #13328]               ; 16-byte Reload
	tbz	w9, #3, LBB0_484
; %bb.483:                              ; %cond.load1679
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v17[1]
	ld1.b	{ v3 }[3], [x10]
LBB0_484:                               ; %else1683
                                        ;   in Loop: Header=BB0_460 Depth=2
	mul	x10, x21, x26
	mul	x11, x20, x19
	fmov	d17, x11
	mov.d	v17[1], x10
	sub.2d	v4, v4, v17
	ldr	q17, [sp, #7424]                ; 16-byte Reload
	bit.16b	v17, v4, v1
	ldr	q4, [sp, #7488]                 ; 16-byte Reload
	bit.16b	v4, v22, v1
	str	q4, [sp, #7488]                 ; 16-byte Spill
	add.2d	v1, v4, v4
	ldr	q4, [sp, #8896]                 ; 16-byte Reload
	str	q17, [sp, #7424]                ; 16-byte Spill
	add.2d	v4, v17, v4
	ldr	q17, [sp, #8960]                ; 16-byte Reload
	add.2d	v4, v17, v4
	add.2d	v1, v4, v1
	tbz	w9, #4, LBB0_486
; %bb.485:                              ; %cond.load1685
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d1
	ld1.b	{ v3 }[4], [x10]
LBB0_486:                               ; %else1689
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbz	w9, #5, LBB0_488
; %bb.487:                              ; %cond.load1691
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v1[1]
	ld1.b	{ v3 }[5], [x10]
LBB0_488:                               ; %else1695
                                        ;   in Loop: Header=BB0_460 Depth=2
	mul	x10, x7, x27
	mul	x11, x6, x15
	fmov	d1, x11
	mov.d	v1[1], x10
	sub.2d	v0, v0, v1
	ldr	q4, [sp, #7408]                 ; 16-byte Reload
	bit.16b	v4, v0, v14
	ldr	q0, [sp, #7472]                 ; 16-byte Reload
	bit.16b	v0, v5, v14
	str	q0, [sp, #7472]                 ; 16-byte Spill
	add.2d	v0, v0, v0
	ldr	q1, [sp, #8880]                 ; 16-byte Reload
	str	q4, [sp, #7408]                 ; 16-byte Spill
	add.2d	v1, v4, v1
	ldr	q4, [sp, #8944]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	add.2d	v0, v1, v0
	tbz	w9, #6, LBB0_490
; %bb.489:                              ; %cond.load1697
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d0
	ld1.b	{ v3 }[6], [x10]
LBB0_490:                               ; %else1701
                                        ;   in Loop: Header=BB0_460 Depth=2
	tbz	w9, #7, LBB0_492
; %bb.491:                              ; %cond.load1703
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x9, v0[1]
	ld1.b	{ v3 }[7], [x9]
LBB0_492:                               ; %else1707
                                        ;   in Loop: Header=BB0_460 Depth=2
	xtn.8b	v0, v16
	cmtst.8b	v1, v19, v19
	ldr	q4, [sp, #7376]                 ; 16-byte Reload
	bif.8b	v1, v4, v6
	ldr	d5, [sp, #11552]                ; 8-byte Reload
	orr.8b	v4, v0, v5
	and.8b	v4, v4, v1
	cmtst.8b	v1, v3, v3
	ldr	q3, [sp, #7344]                 ; 16-byte Reload
	bif.8b	v1, v3, v6
	fmov	w9, s7
	orr.8b	v0, v5, v0
	and.8b	v0, v0, v1
	str	q4, [sp, #7376]                 ; 16-byte Spill
	str	q0, [sp, #7344]                 ; 16-byte Spill
	and.8b	v0, v4, v0
	ldr	q1, [sp, #11168]                ; 16-byte Reload
	add.2d	v1, v18, v1
	ldr	q3, [sp, #11104]                ; 16-byte Reload
	add.2d	v1, v3, v1
	movi.8b	v3, #1
	and.8b	v0, v0, v3
	tbnz	w9, #0, LBB0_500
; %bb.493:                              ; %else1713
                                        ;   in Loop: Header=BB0_460 Depth=2
	tbnz	w9, #1, LBB0_501
LBB0_494:                               ; %else1717
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	q1, [sp, #11152]                ; 16-byte Reload
	add.2d	v1, v21, v1
	ldr	q3, [sp, #11088]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #2, LBB0_502
LBB0_495:                               ; %else1721
                                        ;   in Loop: Header=BB0_460 Depth=2
	tbnz	w9, #3, LBB0_503
LBB0_496:                               ; %else1725
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	q1, [sp, #11136]                ; 16-byte Reload
	add.2d	v1, v25, v1
	ldr	q2, [sp, #11200]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_504
LBB0_497:                               ; %else1729
                                        ;   in Loop: Header=BB0_460 Depth=2
	tbnz	w9, #5, LBB0_505
LBB0_498:                               ; %else1733
                                        ;   in Loop: Header=BB0_460 Depth=2
	ldr	q1, [sp, #11120]                ; 16-byte Reload
	add.2d	v1, v26, v1
	ldr	q3, [sp, #11184]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_506
LBB0_499:                               ; %else1737
                                        ;   in Loop: Header=BB0_460 Depth=2
	tbz	w9, #7, LBB0_459
	b	LBB0_507
LBB0_500:                               ; %cond.store1710
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d1
	str	b0, [x10]
	tbz	w9, #1, LBB0_494
LBB0_501:                               ; %cond.store1714
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[1], [x10]
	ldr	q1, [sp, #11152]                ; 16-byte Reload
	add.2d	v1, v21, v1
	ldr	q3, [sp, #11088]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #2, LBB0_495
LBB0_502:                               ; %cond.store1718
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[2], [x10]
	tbz	w9, #3, LBB0_496
LBB0_503:                               ; %cond.store1722
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[3], [x10]
	ldr	q1, [sp, #11136]                ; 16-byte Reload
	add.2d	v1, v25, v1
	ldr	q2, [sp, #11200]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #4, LBB0_497
LBB0_504:                               ; %cond.store1726
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[4], [x10]
	tbz	w9, #5, LBB0_498
LBB0_505:                               ; %cond.store1730
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[5], [x10]
	ldr	q1, [sp, #11120]                ; 16-byte Reload
	add.2d	v1, v26, v1
	ldr	q3, [sp, #11184]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_499
LBB0_506:                               ; %cond.store1734
                                        ;   in Loop: Header=BB0_460 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[6], [x10]
	tbz	w9, #7, LBB0_459
LBB0_507:                               ; %cond.store1738
                                        ;   in Loop: Header=BB0_460 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[7], [x9]
	b	LBB0_459
LBB0_508:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q24, [sp, #13328]               ; 16-byte Reload
	ldr	q27, [sp, #13296]               ; 16-byte Reload
LBB0_509:                               ; %direct.false551
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q26, [sp, #1424]                ; 16-byte Spill
	str	q25, [sp, #1440]                ; 16-byte Spill
	str	q21, [sp, #1456]                ; 16-byte Spill
	str	q18, [sp, #1472]                ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #416]                  ; 16-byte Reload
	ldr	q4, [sp, #12176]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #12176]                ; 16-byte Spill
	ldr	q4, [sp, #12208]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #12208]                ; 16-byte Spill
	ldr	q4, [sp, #12192]                ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #12192]                ; 16-byte Spill
	ldr	q4, [sp, #12224]                ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #12224]                ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #12240]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #12240]                ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #12144]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #12144]                ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q2, [sp, #12256]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #12256]                ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #12160]                ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #12160]                ; 16-byte Spill
	ldr	q3, [sp, #2016]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #2016]                 ; 16-byte Spill
	ldr	q4, [sp, #1392]                 ; 16-byte Reload
	bic.16b	v4, v4, v11
	ldr	q5, [sp, #1376]                 ; 16-byte Reload
	bic.16b	v5, v5, v1
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	bic.16b	v3, v3, v0
	fmov	x9, d3
	cmp	x9, #17
	b.gt	LBB0_560
; %bb.510:                              ; %direct.true567.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
	b	LBB0_512
LBB0_511:                               ; %else1872
                                        ;   in Loop: Header=BB0_512 Depth=2
	add.2d	v4, v4, v10
	add.2d	v5, v21, v24
	add.2d	v1, v12, v8
	add.2d	v3, v3, v20
	fmov	x9, d3
	cmp	x9, #18
	b.ge	LBB0_561
LBB0_512:                               ; %direct.true567
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v16, v31, #0
	sshll.2d	v0, v30, #0
	mov.16b	v12, v1
	and.16b	v1, v14, v1
	mov.16b	v13, v4
	and.16b	v4, v11, v4
	mov.16b	v21, v5
	and.16b	v5, v0, v5
	mov.16b	v29, v3
	and.16b	v3, v16, v3
	fmov	x9, d3
	ldr	q6, [sp, #13184]                ; 16-byte Reload
	fmov	x10, d6
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d17, x9
	mov.d	x9, v3[1]
	sdiv	x11, x9, x28
	mov.d	v17[1], x11
	fmov	x9, d5
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x7, x9, x12
	mov.d	x6, v5[1]
	fmov	x9, d4
	ldr	q6, [sp, #13216]                ; 16-byte Reload
	fmov	x19, d6
	mov.d	x21, v4[1]
	sdiv	x20, x9, x19
	fmov	x9, d1
	ldr	q6, [sp, #13232]                ; 16-byte Reload
	fmov	x22, d6
	sdiv	x9, x9, x22
	mov.d	x15, v1[1]
	sdiv	x15, x15, x14
	mul	x23, x15, x14
	mul	x22, x9, x22
	fmov	d6, x22
	mov.d	v6[1], x23
	sdiv	x21, x21, x30
	mul	x22, x21, x30
	mul	x19, x20, x19
	fmov	d18, x19
	mov.d	v18[1], x22
	sdiv	x19, x6, x8
	mul	x6, x19, x8
	mul	x12, x7, x12
	fmov	d7, x12
	mov.d	v7[1], x6
	mul	x11, x11, x28
	fmov	d19, x10
	mov.d	v19[1], x11
	sub.2d	v3, v3, v19
	sub.2d	v7, v5, v7
	sub.2d	v18, v4, v18
	sub.2d	v6, v1, v6
	shl.2d	v1, v3, #3
	shl.2d	v4, v18, #3
	shl.2d	v5, v7, #3
	shl.2d	v19, v6, #3
	ldr	q22, [sp, #13264]               ; 16-byte Reload
	cmgt.2d	v19, v22, v19
	cmgt.2d	v5, v27, v5
	uzp1.4s	v5, v5, v19
	ldr	q2, [sp, #13248]                ; 16-byte Reload
	cmgt.2d	v4, v2, v4
	cmgt.2d	v1, v25, v1
	uzp1.4s	v1, v1, v4
	uzp1.8h	v19, v1, v5
	and.16b	v1, v28, v19
	xtn.8b	v1, v1
	and.16b	v4, v16, v17
	mov.d	x10, v4[1]
	ldr	x12, [sp, #11704]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	x11, d4
	ldr	q4, [sp, #11680]                ; 16-byte Reload
	fmov	x12, d4
	sdiv	x6, x11, x12
	msub	x11, x6, x12, x11
	fmov	d23, x11
	mov.d	v23[1], x10
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #13344]                ; 8-byte Reload
	and.8b	v5, v4, v5
	addv.8b	b5, v5
	fmov	w6, s5
	add.2d	v5, v3, v3
	ldr	q17, [sp, #11168]               ; 16-byte Reload
	add.2d	v5, v5, v17
	ldr	q17, [sp, #11104]               ; 16-byte Reload
	add.2d	v5, v17, v5
	add.2d	v17, v5, v23
	tbz	w6, #0, LBB0_514
; %bb.513:                              ; %cond.load1743
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d17
	ldr	b5, [x10]
	tbnz	w6, #1, LBB0_515
	b	LBB0_516
LBB0_514:                               ;   in Loop: Header=BB0_512 Depth=2
	movi.2d	v5, #0000000000000000
	tbz	w6, #1, LBB0_516
LBB0_515:                               ; %cond.load1749
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v17[1]
	ld1.b	{ v5 }[1], [x10]
LBB0_516:                               ; %else1753
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	d17, x20
	mov.d	v17[1], x21
	and.16b	v17, v11, v17
	mov.d	x10, v17[1]
	sdiv	x11, x10, x25
	msub	x10, x11, x25, x10
	fmov	x11, d17
	ldr	q17, [sp, #11648]               ; 16-byte Reload
	fmov	x12, d17
	sdiv	x20, x11, x12
	msub	x11, x20, x12, x11
	fmov	d22, x11
	mov.d	v22[1], x10
	add.2d	v17, v18, v18
	ldr	q25, [sp, #11152]               ; 16-byte Reload
	add.2d	v17, v17, v25
	ldr	q25, [sp, #11088]               ; 16-byte Reload
	add.2d	v17, v25, v17
	add.2d	v17, v17, v22
	tbz	w6, #2, LBB0_518
; %bb.517:                              ; %cond.load1755
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d17
	ld1.b	{ v5 }[2], [x10]
LBB0_518:                               ; %else1759
                                        ;   in Loop: Header=BB0_512 Depth=2
	tbz	w6, #3, LBB0_520
; %bb.519:                              ; %cond.load1761
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v17[1]
	ld1.b	{ v5 }[3], [x10]
LBB0_520:                               ; %else1765
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	d17, x7
	mov.d	v17[1], x19
	and.16b	v17, v0, v17
	mov.d	x10, v17[1]
	sdiv	x11, x10, x26
	msub	x10, x11, x26, x10
	fmov	x11, d17
	ldr	q17, [sp, #11664]               ; 16-byte Reload
	fmov	x12, d17
	sdiv	x7, x11, x12
	msub	x11, x7, x12, x11
	fmov	d25, x11
	mov.d	v25[1], x10
	add.2d	v17, v7, v7
	ldr	q26, [sp, #11136]               ; 16-byte Reload
	add.2d	v17, v17, v26
	ldr	q2, [sp, #11200]                ; 16-byte Reload
	add.2d	v17, v2, v17
	add.2d	v17, v17, v25
	tbz	w6, #4, LBB0_522
; %bb.521:                              ; %cond.load1767
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d17
	ld1.b	{ v5 }[4], [x10]
LBB0_522:                               ; %else1771
                                        ;   in Loop: Header=BB0_512 Depth=2
	tbz	w6, #5, LBB0_524
; %bb.523:                              ; %cond.load1773
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v17[1]
	ld1.b	{ v5 }[5], [x10]
LBB0_524:                               ; %else1777
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	d17, x9
	mov.d	v17[1], x15
	and.16b	v17, v14, v17
	mov.d	x9, v17[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d17
	ldr	q17, [sp, #11632]               ; 16-byte Reload
	fmov	x11, d17
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d26, x10
	mov.d	v26[1], x9
	add.2d	v17, v6, v6
	ldr	q27, [sp, #11120]               ; 16-byte Reload
	add.2d	v17, v17, v27
	ldr	q27, [sp, #11184]               ; 16-byte Reload
	add.2d	v17, v27, v17
	add.2d	v17, v17, v26
	tbz	w6, #6, LBB0_526
; %bb.525:                              ; %cond.load1779
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x9, d17
	ld1.b	{ v5 }[6], [x9]
LBB0_526:                               ; %else1783
                                        ;   in Loop: Header=BB0_512 Depth=2
	tbz	w6, #7, LBB0_528
; %bb.527:                              ; %cond.load1785
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x9, v17[1]
	ld1.b	{ v5 }[7], [x9]
LBB0_528:                               ; %else1789
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	q17, [sp, #7216]                ; 16-byte Reload
	bit.16b	v17, v3, v16
	ldr	q27, [sp, #7184]                ; 16-byte Reload
	bit.16b	v27, v23, v16
	xtn.8b	v19, v19
	fmov	x9, d27
	add	x9, x9, x9, lsl #3
	fmov	d3, x9
	str	q27, [sp, #7184]                ; 16-byte Spill
	mov.d	x9, v27[1]
	add	x9, x9, x9, lsl #3
	mov.d	v3[1], x9
	str	q17, [sp, #7216]                ; 16-byte Spill
	add.2d	v3, v3, v17
	ldr	q16, [sp, #13168]               ; 16-byte Reload
	and.8b	v16, v16, v19
	shl.8b	v17, v16, #7
	cmlt.8b	v17, v17, #0
	ldr	d23, [sp, #13344]               ; 8-byte Reload
	and.8b	v17, v17, v23
	addv.8b	b23, v17
	fmov	w9, s23
	shl.2d	v3, v3, #5
	ldr	q17, [sp, #9616]                ; 16-byte Reload
	orr.16b	v3, v3, v17
	ldr	q17, [sp, #9680]                ; 16-byte Reload
	add.2d	v17, v17, v3
	movi.2d	v27, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w9, #0, LBB0_530
; %bb.529:                              ; %cond.load1792
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d17
	ldr	s27, [x10]
LBB0_530:                               ; %else1796
                                        ;   in Loop: Header=BB0_512 Depth=2
	tbz	w9, #1, LBB0_532
; %bb.531:                              ; %cond.load1798
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v27 }[1], [x10]
LBB0_532:                               ; %else1802
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	q15, [sp, #7200]                ; 16-byte Reload
	bit.16b	v15, v18, v11
	ldr	q18, [sp, #7280]                ; 16-byte Reload
	bit.16b	v18, v22, v11
	fmov	x10, d18
	add	x10, x10, x10, lsl #3
	fmov	d17, x10
	str	q18, [sp, #7280]                ; 16-byte Spill
	mov.d	x10, v18[1]
	add	x10, x10, x10, lsl #3
	mov.d	v17[1], x10
	str	q15, [sp, #7200]                ; 16-byte Spill
	add.2d	v17, v17, v15
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #9600]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #9664]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w9, #2, LBB0_534
; %bb.533:                              ; %cond.load1804
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d17
	ld1.s	{ v27 }[2], [x10]
LBB0_534:                               ; %else1808
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q24, [sp, #13328]               ; 16-byte Reload
	tbz	w9, #3, LBB0_536
; %bb.535:                              ; %cond.load1810
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v27 }[3], [x10]
LBB0_536:                               ; %else1814
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	q17, [sp, #7312]                ; 16-byte Reload
	bit.16b	v17, v7, v0
	ldr	q7, [sp, #7264]                 ; 16-byte Reload
	bit.16b	v7, v25, v0
	fmov	x10, d7
	add	x10, x10, x10, lsl #3
	fmov	d0, x10
	str	q7, [sp, #7264]                 ; 16-byte Spill
	mov.d	x10, v7[1]
	add	x10, x10, x10, lsl #3
	mov.d	v0[1], x10
	str	q17, [sp, #7312]                ; 16-byte Spill
	add.2d	v0, v0, v17
	shl.2d	v0, v0, #5
	ldr	q7, [sp, #9712]                 ; 16-byte Reload
	orr.16b	v0, v0, v7
	ldr	q7, [sp, #9648]                 ; 16-byte Reload
	add.2d	v0, v7, v0
	tbz	w9, #4, LBB0_538
; %bb.537:                              ; %cond.load1816
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d0
	ld1.s	{ v3 }[0], [x10]
LBB0_538:                               ; %else1820
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	tbz	w9, #5, LBB0_540
; %bb.539:                              ; %cond.load1822
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v3 }[1], [x10]
LBB0_540:                               ; %else1826
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	q7, [sp, #7296]                 ; 16-byte Reload
	bit.16b	v7, v6, v14
	ldr	q6, [sp, #7248]                 ; 16-byte Reload
	bit.16b	v6, v26, v14
	fmov	x10, d6
	add	x10, x10, x10, lsl #3
	fmov	d0, x10
	str	q6, [sp, #7248]                 ; 16-byte Spill
	mov.d	x10, v6[1]
	add	x10, x10, x10, lsl #3
	mov.d	v0[1], x10
	str	q7, [sp, #7296]                 ; 16-byte Spill
	add.2d	v0, v0, v7
	shl.2d	v0, v0, #5
	ldr	q6, [sp, #9696]                 ; 16-byte Reload
	orr.16b	v0, v0, v6
	ldr	q6, [sp, #9632]                 ; 16-byte Reload
	add.2d	v0, v6, v0
	tbz	w9, #6, LBB0_542
; %bb.541:                              ; %cond.load1828
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d0
	ld1.s	{ v3 }[2], [x10]
LBB0_542:                               ; %else1832
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	d9, [sp, #11576]                ; 8-byte Reload
	tbz	w9, #7, LBB0_544
; %bb.543:                              ; %cond.load1834
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_544:                               ; %else1838
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	q6, [sp, #13168]                ; 16-byte Reload
	ldr	q0, [sp, #7232]                 ; 16-byte Reload
	bic.8b	v0, v0, v6
	orr.8b	v7, v1, v0
	cmtst.8b	v0, v5, v5
	ldr	q1, [sp, #10816]                ; 16-byte Reload
	bif.8b	v0, v1, v4
	ldr	d1, [sp, #11552]                ; 8-byte Reload
	orr.8b	v1, v19, v1
	and.8b	v5, v1, v0
	str	q7, [sp, #7232]                 ; 16-byte Spill
	bic.8b	v0, v6, v7
	fmov	w9, s23
	zip1.8b	v1, v16, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q4, [sp, #7168]                 ; 16-byte Reload
	bsl.16b	v1, v27, v4
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v4, v4, #0
	and.16b	v6, v4, v1
	mov	w10, #62154                     ; =0xf2ca
	movk	w10, #61769, lsl #16
	dup.4s	v1, w10
	str	q5, [sp, #10816]                ; 16-byte Spill
	zip1.8b	v4, v5, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	str	q6, [sp, #7168]                 ; 16-byte Spill
	bsl.16b	v4, v6, v1
	shl.2d	v5, v29, #5
	ldr	q6, [sp, #12160]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #12224]                ; 16-byte Reload
	add.2d	v5, v6, v5
	tbnz	w9, #0, LBB0_553
; %bb.545:                              ; %else1844
                                        ;   in Loop: Header=BB0_512 Depth=2
	ldr	q27, [sp, #13296]               ; 16-byte Reload
	tbnz	w9, #1, LBB0_554
LBB0_546:                               ; %else1848
                                        ;   in Loop: Header=BB0_512 Depth=2
	shl.2d	v5, v13, #5
	ldr	q6, [sp, #12144]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #12208]                ; 16-byte Reload
	add.2d	v5, v6, v5
	tbnz	w9, #2, LBB0_555
LBB0_547:                               ; %else1852
                                        ;   in Loop: Header=BB0_512 Depth=2
	tbz	w9, #3, LBB0_549
LBB0_548:                               ; %cond.store1853
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v4 }[3], [x10]
LBB0_549:                               ; %else1856
                                        ;   in Loop: Header=BB0_512 Depth=2
	zip2.8b	v4, v16, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #7152]                 ; 16-byte Reload
	bif.16b	v3, v5, v4
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v3, v0, v3
	ldr	q0, [sp, #10816]                ; 16-byte Reload
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q3, [sp, #7152]                 ; 16-byte Spill
	bsl.16b	v0, v3, v1
	shl.2d	v1, v21, #5
	ldr	q2, [sp, #12256]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q3, [sp, #12192]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_556
; %bb.550:                              ; %else1860
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.16b	v4, v13
	tbnz	w9, #5, LBB0_557
LBB0_551:                               ; %else1864
                                        ;   in Loop: Header=BB0_512 Depth=2
	shl.2d	v1, v12, #5
	ldr	q3, [sp, #12240]                ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #12176]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_558
LBB0_552:                               ; %else1868
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.16b	v3, v29
	tbz	w9, #7, LBB0_511
	b	LBB0_559
LBB0_553:                               ; %cond.store1841
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d5
	str	s4, [x10]
	ldr	q27, [sp, #13296]               ; 16-byte Reload
	tbz	w9, #1, LBB0_546
LBB0_554:                               ; %cond.store1845
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v4 }[1], [x10]
	shl.2d	v5, v13, #5
	ldr	q6, [sp, #12144]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #12208]                ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #2, LBB0_547
LBB0_555:                               ; %cond.store1849
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d5
	st1.s	{ v4 }[2], [x10]
	tbnz	w9, #3, LBB0_548
	b	LBB0_549
LBB0_556:                               ; %cond.store1857
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	mov.16b	v4, v13
	tbz	w9, #5, LBB0_551
LBB0_557:                               ; %cond.store1861
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v12, #5
	ldr	q3, [sp, #12240]                ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #12176]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_552
LBB0_558:                               ; %cond.store1865
                                        ;   in Loop: Header=BB0_512 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	mov.16b	v3, v29
	tbz	w9, #7, LBB0_511
LBB0_559:                               ; %cond.store1869
                                        ;   in Loop: Header=BB0_512 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_511
LBB0_560:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q1, [sp, #2016]                 ; 16-byte Reload
LBB0_561:                               ; %direct.false568
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q1, [sp, #2016]                 ; 16-byte Spill
	str	q5, [sp, #1376]                 ; 16-byte Spill
	str	q4, [sp, #1392]                 ; 16-byte Spill
	str	q3, [sp, #1408]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #400]                  ; 16-byte Reload
	ldr	q4, [sp, #5984]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #5984]                 ; 16-byte Spill
	ldr	q4, [sp, #6016]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #6016]                 ; 16-byte Spill
	ldr	q4, [sp, #6000]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #6000]                 ; 16-byte Spill
	ldr	q4, [sp, #6032]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #6032]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #6048]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #5952]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #5952]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q2, [sp, #6064]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #6064]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #5968]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #5968]                 ; 16-byte Spill
	ldr	q21, [sp, #8784]                ; 16-byte Reload
	bic.16b	v21, v21, v14
	ldr	q12, [sp, #1344]                ; 16-byte Reload
	bic.16b	v12, v12, v11
	ldr	q5, [sp, #8800]                 ; 16-byte Reload
	bic.16b	v5, v5, v1
	ldr	q4, [sp, #8816]                 ; 16-byte Reload
	bic.16b	v4, v4, v0
	fmov	x9, d4
	cmp	x9, #1
	b.gt	LBB0_600
; %bb.562:                              ; %direct.true587.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q29, [sp, #13248]               ; 16-byte Reload
	b	LBB0_564
LBB0_563:                               ; %else1954
                                        ;   in Loop: Header=BB0_564 Depth=2
	add.2d	v12, v12, v10
	add.2d	v5, v5, v24
	add.2d	v21, v21, v8
	add.2d	v4, v4, v20
	fmov	x9, d4
	cmp	x9, #2
	b.ge	LBB0_601
LBB0_564:                               ; %direct.true587
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_567 Depth 3
	mov.16b	v9, v28
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	str	q21, [sp, #8784]                ; 16-byte Spill
	and.16b	v3, v14, v21
	str	q4, [sp, #8816]                 ; 16-byte Spill
	and.16b	v4, v0, v4
	mov.d	x9, v4[1]
	ldr	x11, [sp, #11704]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d4
	ldr	q4, [sp, #11680]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	str	q5, [sp, #8800]                 ; 16-byte Spill
	and.16b	v5, v1, v5
	mov.d	x9, v5[1]
	sdiv	x10, x9, x26
	msub	x9, x10, x26, x9
	fmov	x10, d5
	ldr	q5, [sp, #11664]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d5, x10
	mov.d	v5[1], x9
	and.16b	v6, v11, v12
	mov.d	x9, v6[1]
	sdiv	x10, x9, x25
	msub	x9, x10, x25, x9
	fmov	x10, d6
	ldr	q6, [sp, #11648]                ; 16-byte Reload
	fmov	x11, d6
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	mov.d	x9, v3[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d3
	ldr	q3, [sp, #11632]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d3, x10
	mov.d	v3[1], x9
	ldr	q7, [sp, #7120]                 ; 16-byte Reload
	bit.16b	v7, v3, v14
	ldr	q17, [sp, #7008]                ; 16-byte Reload
	bit.16b	v17, v6, v11
	ldr	q3, [sp, #7136]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	ldr	q16, [sp, #7024]                ; 16-byte Reload
	bit.16b	v16, v4, v0
	ldr	q26, [sp, #7040]                ; 16-byte Reload
	mov.16b	v4, v11
	mov.16b	v11, v14
	bic.16b	v26, v26, v14
	ldr	q19, [sp, #7072]                ; 16-byte Reload
	mov.16b	v2, v4
	bic.16b	v19, v19, v4
	ldr	q22, [sp, #7056]                ; 16-byte Reload
	bic.16b	v22, v22, v1
	ldr	q18, [sp, #7088]                ; 16-byte Reload
	bic.16b	v18, v18, v0
	ldr	q0, [sp, #12944]                ; 16-byte Reload
	bic.16b	v0, v0, v30
	str	q0, [sp, #12944]                ; 16-byte Spill
	ldr	q0, [sp, #12960]                ; 16-byte Reload
	bic.16b	v0, v0, v31
	str	q0, [sp, #12960]                ; 16-byte Spill
	ldr	d0, [sp, #11552]                ; 8-byte Reload
	ldr	q1, [sp, #12976]                ; 16-byte Reload
	and.8b	v1, v0, v1
	str	q1, [sp, #12976]                ; 16-byte Spill
	fmov	x9, d18
	cmp	x9, #8
	str	q3, [sp, #7136]                 ; 16-byte Spill
	str	q7, [sp, #7120]                 ; 16-byte Spill
	str	q16, [sp, #7024]                ; 16-byte Spill
	str	q17, [sp, #7008]                ; 16-byte Spill
	b.gt	LBB0_583
; %bb.565:                              ; %direct.true592.lr.ph
                                        ;   in Loop: Header=BB0_564 Depth=2
	mov.16b	v13, v29
	fmov	x9, d16
	add	x9, x9, x9, lsl #3
	fmov	d0, x9
	mov.d	x9, v16[1]
	add	x9, x9, x9, lsl #3
	mov.d	v0[1], x9
	fmov	x9, d17
	add	x9, x9, x9, lsl #3
	fmov	d1, x9
	mov.d	x9, v17[1]
	add	x9, x9, x9, lsl #3
	mov.d	v1[1], x9
	fmov	x9, d3
	add	x9, x9, x9, lsl #3
	mov.d	x10, v3[1]
	fmov	d4, x9
	add	x9, x10, x10, lsl #3
	mov.d	v4[1], x9
	fmov	x9, d7
	add	x9, x9, x9, lsl #3
	fmov	d5, x9
	mov.d	x9, v7[1]
	add	x9, x9, x9, lsl #3
	mov.d	v5[1], x9
	mov.16b	v23, v25
	ldr	q29, [sp, #13264]               ; 16-byte Reload
	mov.16b	v8, v9
	mov.16b	v21, v31
	mov.16b	v24, v30
	mov.16b	v10, v27
	b	LBB0_567
LBB0_566:                               ; %else1920
                                        ;   in Loop: Header=BB0_567 Depth=3
	ldr	q29, [sp, #13264]               ; 16-byte Reload
	cmge.2d	v17, v22, v29
	cmge.2d	v19, v19, v10
	uzp1.4s	v17, v19, v17
	ldr	q13, [sp, #13248]               ; 16-byte Reload
	cmge.2d	v18, v18, v13
	cmge.2d	v16, v16, v25
	uzp1.4s	v16, v16, v18
	uzp1.8h	v16, v16, v17
	mov.16b	v8, v9
	and.16b	v16, v9, v16
	xtn.8b	v16, v16
	zip2.8b	v17, v6, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #12544]               ; 16-byte Reload
	bsl.16b	v17, v24, v18
	zip1.8b	v18, v6, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	ldr	q19, [sp, #12560]               ; 16-byte Reload
	bsl.16b	v18, v23, v19
	zip1.8b	v19, v16, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmge.4s	v19, v19, #0
	and.16b	v19, v19, v18
	zip2.8b	v16, v16, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmge.4s	v16, v16, #0
	and.16b	v22, v16, v17
	ldr	q20, [sp, #12944]               ; 16-byte Reload
	fmaxnm.4s	v16, v20, v22
	ldr	q27, [sp, #12960]               ; 16-byte Reload
	fmaxnm.4s	v17, v27, v19
	ldr	q23, [sp, #12976]               ; 16-byte Reload
	zip1.8b	v18, v23, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	str	q19, [sp, #12560]               ; 16-byte Spill
	bif.16b	v17, v19, v18
	zip2.8b	v18, v23, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	str	q22, [sp, #12544]               ; 16-byte Spill
	bif.16b	v16, v22, v18
	ldr	q18, [sp, #13056]               ; 16-byte Reload
	add.2d	v19, v15, v18
	ldr	q18, [sp, #13328]               ; 16-byte Reload
	add.2d	v22, v28, v18
	ldr	q18, [sp, #12880]               ; 16-byte Reload
	add.2d	v26, v14, v18
	mov.16b	v18, v21
	ldr	q21, [sp, #13312]               ; 16-byte Reload
	add.2d	v18, v18, v21
	mov.16b	v21, v31
	and.16b	v7, v31, v7
	mov.16b	v24, v30
	and.16b	v3, v30, v3
	bit.16b	v20, v16, v3
	str	q20, [sp, #12944]               ; 16-byte Spill
	bit.16b	v27, v17, v7
	str	q27, [sp, #12960]               ; 16-byte Spill
	orr.8b	v23, v23, v6
	str	q23, [sp, #12976]               ; 16-byte Spill
	fmov	x9, d18
	cmp	x9, #9
	mov.16b	v23, v25
	b.ge	LBB0_584
LBB0_567:                               ; %direct.true592
                                        ;   Parent Loop BB0_92 Depth=1
                                        ;     Parent Loop BB0_564 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v3, v24, #0
	sshll.2d	v6, v21, #0
	mov.16b	v14, v26
	and.16b	v7, v11, v26
	mov.d	x9, v7[1]
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d7
	ldr	q7, [sp, #13232]                ; 16-byte Reload
	fmov	x11, d7
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d17, x10
	mov.d	v17[1], x9
	mov.16b	v28, v22
	and.16b	v3, v3, v22
	mov.d	x9, v3[1]
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d3
	ldr	q3, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d25, x10
	mov.d	v25[1], x9
	mov.16b	v15, v19
	and.16b	v3, v2, v19
	mov.d	x9, v3[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d3
	ldr	q3, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d26, x10
	mov.d	v26[1], x9
	mov.16b	v21, v18
	and.16b	v3, v6, v18
	mov.d	x9, v3[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d3
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	shl.2d	v16, v6, #3
	shl.2d	v18, v26, #3
	shl.2d	v19, v25, #3
	shl.2d	v22, v17, #3
	cmgt.2d	v3, v29, v22
	cmgt.2d	v7, v10, v19
	uzp1.4s	v3, v7, v3
	cmgt.2d	v7, v13, v18
	cmgt.2d	v23, v23, v16
	uzp1.4s	v7, v23, v7
	uzp1.8h	v23, v7, v3
	add.2d	v24, v6, v0
	and.16b	v6, v8, v23
	xtn.8b	v6, v6
	shl.8b	v23, v6, #7
	cmlt.8b	v23, v23, #0
	ldr	d27, [sp, #13344]               ; 8-byte Reload
	and.8b	v23, v23, v27
	addv.8b	b23, v23
	fmov	w9, s23
	shl.2d	v23, v24, #5
	ldr	q24, [sp, #12160]               ; 16-byte Reload
	orr.16b	v23, v23, v24
	ldr	q24, [sp, #12224]               ; 16-byte Reload
	add.2d	v27, v24, v23
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbz	w9, #0, LBB0_569
; %bb.568:                              ; %cond.load1874
                                        ;   in Loop: Header=BB0_567 Depth=3
	fmov	x10, d27
	ldr	s23, [x10]
LBB0_569:                               ; %else1878
                                        ;   in Loop: Header=BB0_567 Depth=3
	tbz	w9, #1, LBB0_571
; %bb.570:                              ; %cond.load1880
                                        ;   in Loop: Header=BB0_567 Depth=3
	mov.d	x10, v27[1]
	ld1.s	{ v23 }[1], [x10]
LBB0_571:                               ; %else1884
                                        ;   in Loop: Header=BB0_567 Depth=3
	ldr	q10, [sp, #13296]               ; 16-byte Reload
	add.2d	v26, v26, v1
	shl.2d	v26, v26, #5
	ldr	q29, [sp, #12144]               ; 16-byte Reload
	orr.16b	v26, v26, v29
	ldr	q29, [sp, #12208]               ; 16-byte Reload
	add.2d	v26, v29, v26
	tbz	w9, #2, LBB0_573
; %bb.572:                              ; %cond.load1886
                                        ;   in Loop: Header=BB0_567 Depth=3
	fmov	x10, d26
	ld1.s	{ v23 }[2], [x10]
LBB0_573:                               ; %else1890
                                        ;   in Loop: Header=BB0_567 Depth=3
	tbz	w9, #3, LBB0_575
; %bb.574:                              ; %cond.load1892
                                        ;   in Loop: Header=BB0_567 Depth=3
	mov.d	x10, v26[1]
	ld1.s	{ v23 }[3], [x10]
LBB0_575:                               ; %else1896
                                        ;   in Loop: Header=BB0_567 Depth=3
	add.2d	v25, v25, v4
	shl.2d	v25, v25, #5
	ldr	q20, [sp, #12256]               ; 16-byte Reload
	orr.16b	v25, v25, v20
	ldr	q26, [sp, #12192]               ; 16-byte Reload
	add.2d	v25, v26, v25
	tbz	w9, #4, LBB0_577
; %bb.576:                              ; %cond.load1898
                                        ;   in Loop: Header=BB0_567 Depth=3
	fmov	x10, d25
	ld1.s	{ v24 }[0], [x10]
LBB0_577:                               ; %else1902
                                        ;   in Loop: Header=BB0_567 Depth=3
	tbz	w9, #5, LBB0_579
; %bb.578:                              ; %cond.load1904
                                        ;   in Loop: Header=BB0_567 Depth=3
	mov.d	x10, v25[1]
	ld1.s	{ v24 }[1], [x10]
LBB0_579:                               ; %else1908
                                        ;   in Loop: Header=BB0_567 Depth=3
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	add.2d	v17, v17, v5
	shl.2d	v17, v17, #5
	ldr	q26, [sp, #12240]               ; 16-byte Reload
	orr.16b	v17, v17, v26
	ldr	q26, [sp, #12176]               ; 16-byte Reload
	add.2d	v17, v26, v17
	tbz	w9, #6, LBB0_581
; %bb.580:                              ; %cond.load1910
                                        ;   in Loop: Header=BB0_567 Depth=3
	fmov	x10, d17
	ld1.s	{ v24 }[2], [x10]
LBB0_581:                               ; %else1914
                                        ;   in Loop: Header=BB0_567 Depth=3
	tbz	w9, #7, LBB0_566
; %bb.582:                              ; %cond.load1916
                                        ;   in Loop: Header=BB0_567 Depth=3
	mov.d	x9, v17[1]
	ld1.s	{ v24 }[3], [x9]
	b	LBB0_566
LBB0_583:                               ;   in Loop: Header=BB0_564 Depth=2
	mov.16b	v10, v27
LBB0_584:                               ; %direct.false593
                                        ;   in Loop: Header=BB0_564 Depth=2
	mov.16b	v27, v10
	str	q26, [sp, #7040]                ; 16-byte Spill
	str	q22, [sp, #7056]                ; 16-byte Spill
	str	q19, [sp, #7072]                ; 16-byte Spill
	str	q18, [sp, #7088]                ; 16-byte Spill
	ldr	q23, [sp, #12960]               ; 16-byte Reload
	str	q23, [x13, #3824]
	ldr	q24, [sp, #12944]               ; 16-byte Reload
	str	q24, [x13, #3840]
	ldr	x10, [sp, #4456]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #928
	ldr	s0, [x9, x10]
	ldr	w9, [sp, #7868]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q23, [x13, #3792]
	str	q24, [x13, #3808]
	ldr	x11, [sp, #4408]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #896
	ldr	s4, [x9, x11]
	movi.2d	v20, #0000000000000000
	fcsel	s0, s0, s20, ne
	ldr	q21, [sp, #12976]               ; 16-byte Reload
	movi.8b	v1, #1
	and.8b	v1, v21, v1
	ushll.8h	v3, v1, #0
	ushll.4s	v1, v3, #0
	ushll2.4s	v3, v3, #0
	str	q3, [x13, #3360]
	str	q1, [x13, #3344]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #448
	ldr	w9, [x9, x10]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7864]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s4, s4, s20, ne
	str	q23, [x13, #3760]
	str	q24, [x13, #3776]
	ldr	x12, [sp, #4392]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #864
	ldr	s5, [x10, x12]
	str	q3, [x13, #3392]
	str	q1, [x13, #3376]
	fmov	s6, w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #480
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7860]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s7, s5, s20, ne
	str	q23, [x13, #3728]
	str	q24, [x13, #3744]
	ldr	x15, [sp, #4376]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #832
	ldr	s5, [x10, x15]
	str	q3, [x13, #3424]
	str	q1, [x13, #3408]
	mov.s	v6[1], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #512
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7856]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s16, s5, s20, ne
	str	q23, [x13, #3696]
	str	q24, [x13, #3712]
	ldr	x11, [sp, #4448]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #800
	ldr	s5, [x10, x11]
	str	q3, [x13, #3456]
	str	q1, [x13, #3440]
	mov.s	v6[2], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #544
	ldr	w9, [x9, x15]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7852]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s5, s5, s20, ne
	str	q23, [x13, #3664]
	str	q24, [x13, #3680]
	ldr	x12, [sp, #4352]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #768
	ldr	s17, [x10, x12]
	str	q3, [x13, #3488]
	str	q1, [x13, #3472]
	mov.s	v6[3], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #576
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7848]                ; 4-byte Reload
	tst	w10, #0x1
	str	q23, [x13, #3632]
	str	q24, [x13, #3648]
	ldr	x11, [sp, #4336]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #736
	ldr	s18, [x10, x11]
	fcsel	s17, s17, s20, ne
	str	q3, [x13, #3520]
	str	q1, [x13, #3504]
	fmov	s19, w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #608
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7844]                ; 4-byte Reload
	tst	w10, #0x1
	str	q23, [x13, #3600]
	str	q24, [x13, #3616]
	ldr	x12, [sp, #4320]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #704
	ldr	s22, [x10, x12]
	str	q3, [x13, #3552]
	str	q1, [x13, #3536]
	mov.s	v19[1], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #640
	ldr	w9, [x9, x11]
	fcsel	s18, s18, s20, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7840]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s22, s22, s20, ne
	mov.s	v5[1], v17[0]
	mov.s	v5[2], v18[0]
	mov.s	v5[3], v22[0]
	mov.s	v0[1], v4[0]
	mov.s	v0[2], v7[0]
	mov.s	v0[3], v16[0]
	fmaxnm.4s	v4, v23, v0
	str	q3, [x13, #3584]
	str	q1, [x13, #3568]
	mov.s	v19[2], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #672
	ldr	w9, [x9, x12]
	fmaxnm.4s	v1, v24, v5
	csel	w9, w9, wzr, ne
	mov.s	v19[3], w9
	cmtst.4s	v3, v19, v19
	cmtst.4s	v7, v6, v6
	uzp1.8h	v3, v7, v3
	xtn.8b	v7, v3
	cmeq.4s	v3, v6, #0
	cmeq.4s	v6, v19, #0
	bit.16b	v1, v24, v6
	bsl.16b	v3, v23, v4
	zip1.8b	v4, v21, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v0, v3, v4
	zip2.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v1, v5
	orr.8b	v1, v21, v7
	str	q3, [x13, #3328]
	str	q0, [x13, #3312]
	ldr	x10, [sp, #4440]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #416
	ldr	s4, [x9, x10]
	ldr	w9, [sp, #7836]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q3, [x13, #3264]
	str	q0, [x13, #3248]
	ldr	x11, [sp, #4296]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #352
	ldr	s17, [x9, x11]
	zip1.8b	v5, v1, v0
	ushll.4s	v6, v5, #0
	movi.4s	v26, #1
	and.16b	v5, v6, v26
	zip2.8b	v7, v1, v0
	ushll.4s	v16, v7, #0
	and.16b	v7, v16, v26
	str	q7, [x13, #3296]
	str	q5, [x13, #3280]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #384
	ldr	w9, [x9, x10]
	fcsel	s4, s4, s20, ne
	csel	w9, w9, wzr, ne
	str	q3, [x13, #3200]
	str	q0, [x13, #3184]
	ldr	x12, [sp, #4280]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #288
	ldr	s18, [x10, x12]
	ldr	w10, [sp, #7832]                ; 4-byte Reload
	tst	w10, #0x1
	str	q7, [x13, #3232]
	str	q5, [x13, #3216]
	fmov	s19, w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #320
	ldr	w9, [x9, x11]
	fcsel	s17, s17, s20, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7828]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s18, s18, s20, ne
	str	q3, [x13, #3136]
	str	q0, [x13, #3120]
	ldr	x15, [sp, #4264]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #224
	ldr	s22, [x10, x15]
	str	q7, [x13, #3168]
	str	q5, [x13, #3152]
	mov.s	v19[1], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #256
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7824]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s22, s22, s20, ne
	str	q3, [x13, #3072]
	str	q0, [x13, #3056]
	ldr	x11, [sp, #4432]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #160
	ldr	s23, [x10, x11]
	str	q7, [x13, #3104]
	mov.s	v19[2], w9
	str	q5, [x13, #3088]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #192
	ldr	w9, [x9, x15]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7820]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s23, s23, s20, ne
	str	q3, [x13, #3008]
	str	q0, [x13, #2992]
	ldr	x12, [sp, #4240]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #96
	ldr	s24, [x10, x12]
	str	q7, [x13, #3040]
	str	q5, [x13, #3024]
	mov.s	v19[3], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #128
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7816]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s24, s24, s20, ne
	str	q3, [x13, #2944]
	str	q0, [x13, #2928]
	ldr	x11, [sp, #4224]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #32
	ldr	s25, [x10, x11]
	str	q7, [x13, #2976]
	str	q5, [x13, #2960]
	mov.s	v23[1], v24[0]
	fmov	s24, w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #64
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7812]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s25, s25, s20, ne
	str	q3, [x13, #2880]
	mov.s	v23[2], v25[0]
	str	q0, [x13, #2864]
	ldr	x12, [sp, #4184]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #4064
	ldr	s25, [x10, x12]
	str	q7, [x13, #2912]
	mov.s	v24[1], w9
	str	q5, [x13, #2896]
	add	x9, sp, #4, lsl #12             ; =16384
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7808]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s25, s25, s20, ne
	mov.s	v23[3], v25[0]
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v18[0]
	mov.s	v4[3], v22[0]
	fmaxnm.4s	v17, v0, v4
	fmaxnm.4s	v18, v3, v23
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	str	q7, [x13, #2848]
	str	q5, [x13, #2832]
	mov.s	v24[2], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #4032
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	mov.s	v24[3], w9
	cmtst.4s	v5, v24, v24
	cmtst.4s	v7, v19, v19
	uzp1.8h	v5, v7, v5
	xtn.8b	v5, v5
	cmeq.4s	v7, v19, #0
	cmeq.4s	v19, v24, #0
	bif.16b	v3, v18, v19
	bif.16b	v0, v17, v7
	bif.16b	v0, v4, v6
	mov.16b	v6, v16
	bsl.16b	v6, v3, v23
	orr.8b	v5, v1, v5
	str	q6, [x13, #2816]
	str	q0, [x13, #2800]
	ldr	x10, [sp, #4424]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #4000
	ldr	s1, [x9, x10]
	ldr	w9, [sp, #7804]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s1, s1, s20, ne
	str	q6, [x13, #2752]
	str	q0, [x13, #2736]
	ldr	x11, [sp, #4160]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3936
	ldr	s7, [x9, x11]
	zip1.8b	v3, v5, v0
	ushll.4s	v4, v3, #0
	and.16b	v3, v4, v26
	zip2.8b	v5, v5, v0
	ushll.4s	v5, v5, #0
	and.16b	v5, v5, v26
	str	q5, [x13, #2784]
	str	q3, [x13, #2768]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3968
	ldr	w9, [x9, x10]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7800]                ; 4-byte Reload
	tst	w10, #0x1
	str	q6, [x13, #2688]
	str	q0, [x13, #2672]
	ldr	x12, [sp, #4120]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3872
	ldr	s16, [x10, x12]
	fcsel	s7, s7, s20, ne
	str	q5, [x13, #2720]
	str	q3, [x13, #2704]
	fmov	s17, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3904
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7796]                ; 4-byte Reload
	tst	w10, #0x1
	str	q6, [x13, #2624]
	str	q0, [x13, #2608]
	ldr	x11, [sp, #4104]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3808
	ldr	s6, [x10, x11]
	str	q5, [x13, #2656]
	str	q3, [x13, #2640]
	mov.s	v17[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3840
	ldr	w9, [x9, x12]
	fcsel	s16, s16, s20, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7792]                ; 4-byte Reload
	tst	w10, #0x1
	mov.16b	v18, v1
	mov.s	v18[1], v7[0]
	fcsel	s6, s6, s20, ne
	mov.s	v18[2], v16[0]
	mov.s	v18[3], v6[0]
	fmaxnm.4s	v6, v0, v18
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	str	q5, [x13, #2592]
	str	q3, [x13, #2576]
	mov.s	v17[2], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3776
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	mov.s	v17[3], w9
	cmeq.4s	v3, v17, #0
	bif.16b	v0, v6, v3
	bif.16b	v0, v1, v4
	tst	w16, #0x1
	fcsel	s1, s0, s20, ne
	and	w9, w17, w16
	tst	w9, #0x1
	fcsel	s3, s0, s20, ne
	and	w9, w0, w16
	tst	w9, #0x1
	fcsel	s4, s0, s20, ne
	and	w9, w1, w16
	tst	w9, #0x1
	fcsel	s5, s0, s20, ne
	and	w9, w2, w16
	tst	w9, #0x1
	fcsel	s6, s0, s20, ne
	and	w9, w3, w16
	tst	w9, #0x1
	fcsel	s7, s0, s20, ne
	and	w9, w4, w16
	tst	w9, #0x1
	fcsel	s16, s0, s20, ne
	and	w9, w5, w16
	tst	w9, #0x1
	fcsel	s0, s0, s20, ne
	mov.s	v1[1], v3[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v5[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v0[0]
	ldr	q0, [sp, #7936]                 ; 16-byte Reload
	fmov	w9, s0
	str	q6, [x13, #2304]
	str	q1, [x13, #2288]
	ldr	x10, [sp, #4072]                ; 8-byte Reload
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #3488
	ldr	s0, [x11, x10, lsl #2]
	mov	w10, #-8388608                  ; =0xff800000
	fmov	s1, w10
	fmaxnm	s0, s0, s1
	ldr	q4, [sp, #8816]                 ; 16-byte Reload
	shl.2d	v1, v4, #5
	ldr	q3, [sp, #5968]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	dup.4s	v0, v0[0]
	ldr	q3, [sp, #6032]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #0, LBB0_586
; %bb.585:                              ; %cond.store1923
                                        ;   in Loop: Header=BB0_564 Depth=2
	fmov	x10, d1
	str	s0, [x10]
LBB0_586:                               ; %else1926
                                        ;   in Loop: Header=BB0_564 Depth=2
	and	w9, w9, #0xff
	ldr	q24, [sp, #13328]               ; 16-byte Reload
	ldr	q5, [sp, #8800]                 ; 16-byte Reload
	mov.16b	v28, v9
	ldr	q8, [sp, #12880]                ; 16-byte Reload
	mov.16b	v14, v11
	tbz	w9, #1, LBB0_588
; %bb.587:                              ; %cond.store1927
                                        ;   in Loop: Header=BB0_564 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
LBB0_588:                               ; %else1930
                                        ;   in Loop: Header=BB0_564 Depth=2
	shl.2d	v1, v12, #5
	ldr	q3, [sp, #5952]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #6016]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q29, [sp, #13248]               ; 16-byte Reload
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q21, [sp, #8784]                ; 16-byte Reload
	ldr	q10, [sp, #13056]               ; 16-byte Reload
	ldr	q20, [sp, #13312]               ; 16-byte Reload
	mov.16b	v11, v2
	tbnz	w9, #2, LBB0_594
; %bb.589:                              ; %else1934
                                        ;   in Loop: Header=BB0_564 Depth=2
	ldr	d9, [sp, #11576]                ; 8-byte Reload
	tbnz	w9, #3, LBB0_595
LBB0_590:                               ; %else1938
                                        ;   in Loop: Header=BB0_564 Depth=2
	shl.2d	v1, v5, #5
	ldr	q2, [sp, #6064]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q3, [sp, #6000]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_596
LBB0_591:                               ; %else1942
                                        ;   in Loop: Header=BB0_564 Depth=2
	tbnz	w9, #5, LBB0_597
LBB0_592:                               ; %else1946
                                        ;   in Loop: Header=BB0_564 Depth=2
	shl.2d	v1, v21, #5
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q3, [sp, #5984]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_598
LBB0_593:                               ; %else1950
                                        ;   in Loop: Header=BB0_564 Depth=2
	tbz	w9, #7, LBB0_563
	b	LBB0_599
LBB0_594:                               ; %cond.store1931
                                        ;   in Loop: Header=BB0_564 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	ldr	d9, [sp, #11576]                ; 8-byte Reload
	tbz	w9, #3, LBB0_590
LBB0_595:                               ; %cond.store1935
                                        ;   in Loop: Header=BB0_564 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[3], [x10]
	shl.2d	v1, v5, #5
	ldr	q2, [sp, #6064]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q3, [sp, #6000]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_591
LBB0_596:                               ; %cond.store1939
                                        ;   in Loop: Header=BB0_564 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	tbz	w9, #5, LBB0_592
LBB0_597:                               ; %cond.store1943
                                        ;   in Loop: Header=BB0_564 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v21, #5
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q3, [sp, #5984]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_593
LBB0_598:                               ; %cond.store1947
                                        ;   in Loop: Header=BB0_564 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_563
LBB0_599:                               ; %cond.store1951
                                        ;   in Loop: Header=BB0_564 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_563
LBB0_600:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q29, [sp, #13248]               ; 16-byte Reload
LBB0_601:                               ; %direct.false588
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q5, [sp, #8800]                 ; 16-byte Spill
	str	q12, [sp, #1344]                ; 16-byte Spill
	str	q4, [sp, #8816]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	ldr	q2, [sp, #10528]                ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #10528]                ; 16-byte Spill
	ldr	q2, [sp, #10560]                ; 16-byte Reload
	bit.16b	v2, v3, v11
	str	q2, [sp, #10560]                ; 16-byte Spill
	ldr	q2, [sp, #10544]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #10544]                ; 16-byte Spill
	ldr	q2, [sp, #10464]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #10464]                ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q2, [sp, #10576]                ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #10576]                ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q2, [sp, #10496]                ; 16-byte Reload
	bit.16b	v2, v3, v11
	str	q2, [sp, #10496]                ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q2, [sp, #10480]                ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #10480]                ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q2, [sp, #10512]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #10512]                ; 16-byte Spill
	ldr	q17, [sp, #1312]                ; 16-byte Reload
	bic.16b	v17, v17, v14
	ldr	q2, [sp, #10192]                ; 16-byte Reload
	bic.16b	v2, v2, v11
	str	q2, [sp, #10192]                ; 16-byte Spill
	ldr	q16, [sp, #1328]                ; 16-byte Reload
	bic.16b	v16, v16, v1
	ldr	q1, [sp, #10208]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	ldr	q0, [sp, #2960]                 ; 16-byte Reload
	mov.d	x15, v0[1]
	ldr	q0, [sp, #2976]                 ; 16-byte Reload
	mov.d	x7, v0[1]
	str	q1, [sp, #10208]                ; 16-byte Spill
	fmov	x9, d1
	ldr	q0, [sp, #2992]                 ; 16-byte Reload
	mov.d	x6, v0[1]
	ldr	q0, [sp, #3008]                 ; 16-byte Reload
	mov.d	x19, v0[1]
	cmp	x9, #1
	ldr	q19, [sp, #1264]                ; 16-byte Reload
	mov.16b	v12, v9
	b.lt	LBB0_657
LBB0_602:                               ; %direct.false622
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q17, [sp, #1312]                ; 16-byte Spill
	str	q16, [sp, #1328]                ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #368]                  ; 16-byte Reload
	ldr	q4, [sp, #3344]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #3344]                 ; 16-byte Spill
	ldr	q4, [sp, #3376]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #3376]                 ; 16-byte Spill
	ldr	q4, [sp, #3360]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #3360]                 ; 16-byte Spill
	ldr	q4, [sp, #3392]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #3392]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #3408]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #3408]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #3440]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #3440]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #3424]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #3424]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #3456]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #3456]                 ; 16-byte Spill
	ldr	q3, [sp, #10160]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #10160]                ; 16-byte Spill
	ldr	q3, [sp, #10128]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #10128]                ; 16-byte Spill
	ldr	q3, [sp, #10176]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #10176]                ; 16-byte Spill
	ldr	q1, [sp, #10144]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10144]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #0
	b.le	LBB0_1253
; %bb.603:                              ;   in Loop: Header=BB0_92 Depth=1
	mov.16b	v2, v27
	mov.16b	v27, v19
LBB0_604:                               ; %direct.false637
                                        ;   in Loop: Header=BB0_92 Depth=1
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	ldr	q4, [sp, #6320]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #6320]                 ; 16-byte Spill
	ldr	q4, [sp, #6224]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #6224]                 ; 16-byte Spill
	ldr	q4, [sp, #6208]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #6208]                 ; 16-byte Spill
	ldr	q4, [sp, #6240]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #6240]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #6256]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #6256]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #6288]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #6288]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #6272]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #6272]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #6304]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #6304]                 ; 16-byte Spill
	ldr	q3, [sp, #10080]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #10080]                ; 16-byte Spill
	ldr	q3, [sp, #10112]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #10112]                ; 16-byte Spill
	ldr	q3, [sp, #10064]                ; 16-byte Reload
	bic.16b	v3, v3, v0
	str	q3, [sp, #10064]                ; 16-byte Spill
	fmov	x9, d3
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v23, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v0, w10
	str	q0, [sp, #11872]                ; 16-byte Spill
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11856]                ; 16-byte Spill
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11840]                ; 16-byte Spill
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11824]                ; 16-byte Spill
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11344]                ; 16-byte Spill
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11328]                ; 16-byte Spill
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11312]                ; 16-byte Spill
	ldr	q0, [sp, #10096]                ; 16-byte Reload
	bic.16b	v0, v0, v1
	str	q0, [sp, #10096]                ; 16-byte Spill
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11296]                ; 16-byte Spill
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11280]                ; 16-byte Spill
	cmp	x9, #0
	b.le	LBB0_1303
LBB0_605:                               ; %direct.false652
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q23, [sp, #4656]                ; 16-byte Spill
	str	q21, [sp, #8784]                ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #336]                  ; 16-byte Reload
	ldr	q4, [sp, #8672]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8672]                 ; 16-byte Spill
	ldr	q4, [sp, #8704]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8704]                 ; 16-byte Spill
	ldr	q4, [sp, #8688]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8688]                 ; 16-byte Spill
	ldr	q4, [sp, #8720]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8720]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #8736]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8736]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #8768]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8768]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #8752]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8752]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #8656]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8656]                 ; 16-byte Spill
	ldr	q3, [sp, #1296]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	ldr	q4, [sp, #2000]                 ; 16-byte Reload
	bic.16b	v4, v4, v11
	str	q4, [sp, #2000]                 ; 16-byte Spill
	bic.16b	v27, v27, v1
	ldr	q1, [sp, #1280]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x9, d0
	cmp	x9, #17
	b.gt	LBB0_705
; %bb.606:                              ; %direct.true662.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q5, [sp, #2000]                 ; 16-byte Reload
	b	LBB0_608
LBB0_607:                               ; %else2429
                                        ;   in Loop: Header=BB0_608 Depth=2
	add.2d	v5, v12, v10
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	add.2d	v27, v21, v0
	add.2d	v3, v13, v8
	add.2d	v0, v15, v20
	fmov	x9, d0
	cmp	x9, #18
	mov.16b	v12, v26
	b.ge	LBB0_706
LBB0_608:                               ; %direct.true662
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v19, v30, #0
	sshll.2d	v4, v31, #0
	mov.16b	v15, v0
	and.16b	v0, v4, v0
	mov.16b	v21, v27
	and.16b	v1, v19, v27
	mov.16b	v12, v5
	and.16b	v5, v11, v5
	mov.16b	v13, v3
	and.16b	v3, v14, v3
	fmov	x9, d3
	ldr	q6, [sp, #13232]                ; 16-byte Reload
	fmov	x10, d6
	sdiv	x15, x9, x10
	mov.d	x9, v3[1]
	sdiv	x6, x9, x14
	fmov	x9, d5
	ldr	q6, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d6
	sdiv	x22, x9, x11
	mov.d	x9, v5[1]
	sdiv	x23, x9, x30
	fmov	x9, d1
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x20, x9, x12
	mov.d	x9, v1[1]
	sdiv	x21, x9, x8
	fmov	x9, d0
	ldr	q6, [sp, #13184]                ; 16-byte Reload
	fmov	x7, d6
	sdiv	x9, x9, x7
	mov.d	x19, v0[1]
	sdiv	x19, x19, x28
	mul	x7, x9, x7
	fmov	d6, x7
	mul	x7, x19, x28
	mov.d	v6[1], x7
	mul	x7, x23, x30
	mul	x11, x22, x11
	fmov	d7, x11
	mov.d	v7[1], x7
	mul	x11, x21, x8
	mul	x12, x20, x12
	fmov	d16, x12
	mov.d	v16[1], x11
	mul	x11, x6, x14
	mul	x10, x15, x10
	fmov	d17, x10
	mov.d	v17[1], x11
	sub.2d	v3, v3, v17
	sub.2d	v17, v1, v16
	sub.2d	v22, v5, v7
	sub.2d	v6, v0, v6
	shl.2d	v0, v6, #3
	shl.2d	v1, v22, #3
	shl.2d	v5, v17, #3
	shl.2d	v16, v3, #3
	ldr	q7, [sp, #13264]                ; 16-byte Reload
	cmgt.2d	v7, v7, v16
	cmgt.2d	v18, v2, v5
	uzp1.4s	v7, v18, v7
	cmgt.2d	v18, v29, v1
	cmgt.2d	v23, v25, v0
	uzp1.4s	v18, v23, v18
	fmov	d23, x9
	mov.d	v23[1], x19
	uzp1.8h	v7, v18, v7
	and.16b	v4, v4, v23
	mov.d	x9, v4[1]
	ldr	x11, [sp, #11704]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x7, x10, x11, x9
	fmov	x9, d4
	ldr	q4, [sp, #11680]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x19, x11, x10, x9
	add	x9, x19, x19, lsl #3
	fmov	d4, x9
	add	x9, x7, x7, lsl #3
	mov.d	v4[1], x9
	add.2d	v6, v4, v6
	and.16b	v4, v28, v7
	xtn.8b	v4, v4
	shl.8b	v7, v4, #7
	cmlt.8b	v7, v7, #0
	ldr	d18, [sp, #13344]               ; 8-byte Reload
	and.8b	v7, v7, v18
	addv.8b	b7, v7
	fmov	w9, s7
	shl.2d	v6, v6, #5
	ldr	q18, [sp, #12160]               ; 16-byte Reload
	orr.16b	v6, v6, v18
	ldr	q18, [sp, #12224]               ; 16-byte Reload
	add.2d	v23, v18, v6
	movi.2d	v18, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w9, #0, LBB0_610
; %bb.609:                              ; %cond.load2300
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d23
	ldr	s18, [x10]
LBB0_610:                               ; %else2304
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w9, #1, LBB0_612
; %bb.611:                              ; %cond.load2306
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v18 }[1], [x10]
LBB0_612:                               ; %else2310
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	d23, x22
	mov.d	v23[1], x23
	and.16b	v23, v11, v23
	mov.d	x10, v23[1]
	sdiv	x11, x10, x25
	msub	x22, x11, x25, x10
	fmov	x10, d23
	ldr	q23, [sp, #11648]               ; 16-byte Reload
	fmov	x11, d23
	sdiv	x12, x10, x11
	msub	x23, x12, x11, x10
	add	x10, x23, x23, lsl #3
	fmov	d23, x10
	add	x10, x22, x22, lsl #3
	mov.d	v23[1], x10
	add.2d	v22, v23, v22
	shl.2d	v22, v22, #5
	ldr	q23, [sp, #12144]               ; 16-byte Reload
	orr.16b	v22, v22, v23
	ldr	q23, [sp, #12208]               ; 16-byte Reload
	add.2d	v22, v23, v22
	tbz	w9, #2, LBB0_614
; %bb.613:                              ; %cond.load2312
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d22
	ld1.s	{ v18 }[2], [x10]
LBB0_614:                               ; %else2316
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w9, #3, LBB0_616
; %bb.615:                              ; %cond.load2318
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v22[1]
	ld1.s	{ v18 }[3], [x10]
LBB0_616:                               ; %else2322
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	d22, x20
	mov.d	v22[1], x21
	and.16b	v19, v19, v22
	mov.d	x10, v19[1]
	sdiv	x11, x10, x26
	msub	x20, x11, x26, x10
	fmov	x10, d19
	ldr	q19, [sp, #11664]               ; 16-byte Reload
	fmov	x11, d19
	sdiv	x12, x10, x11
	msub	x21, x12, x11, x10
	add	x10, x21, x21, lsl #3
	fmov	d19, x10
	add	x10, x20, x20, lsl #3
	mov.d	v19[1], x10
	add.2d	v17, v19, v17
	shl.2d	v17, v17, #5
	ldr	q2, [sp, #12256]                ; 16-byte Reload
	orr.16b	v17, v17, v2
	ldr	q19, [sp, #12192]               ; 16-byte Reload
	add.2d	v17, v19, v17
	tbz	w9, #4, LBB0_618
; %bb.617:                              ; %cond.load2324
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d17
	ld1.s	{ v6 }[0], [x10]
LBB0_618:                               ; %else2328
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w9, #5, LBB0_620
; %bb.619:                              ; %cond.load2330
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v6 }[1], [x10]
LBB0_620:                               ; %else2334
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	d17, x15
	mov.d	v17[1], x6
	and.16b	v17, v14, v17
	mov.d	x10, v17[1]
	sdiv	x11, x10, x27
	msub	x15, x11, x27, x10
	fmov	x10, d17
	ldr	q17, [sp, #11632]               ; 16-byte Reload
	fmov	x11, d17
	sdiv	x12, x10, x11
	msub	x6, x12, x11, x10
	add	x10, x6, x6, lsl #3
	fmov	d17, x10
	add	x10, x15, x15, lsl #3
	mov.d	v17[1], x10
	add.2d	v3, v17, v3
	shl.2d	v3, v3, #5
	ldr	q17, [sp, #12240]               ; 16-byte Reload
	orr.16b	v3, v3, v17
	ldr	q17, [sp, #12176]               ; 16-byte Reload
	add.2d	v3, v17, v3
	tbz	w9, #6, LBB0_622
; %bb.621:                              ; %cond.load2336
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d3
	ld1.s	{ v6 }[2], [x10]
LBB0_622:                               ; %else2340
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w9, #7, LBB0_624
; %bb.623:                              ; %cond.load2342
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
LBB0_624:                               ; %else2346
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	d3, x6
	mov.d	v3[1], x15
	fmov	d24, x23
	mov.d	v24[1], x22
	fmov	d17, x21
	mov.d	v17[1], x20
	fmov	d23, x19
	mov.d	v23[1], x7
	sshll.2d	v19, v31, #0
	sshll.2d	v22, v30, #0
	and.16b	v3, v14, v3
	and.16b	v17, v22, v17
	and.16b	v23, v19, v23
	mov.d	x10, v23[1]
	ldr	q25, [sp, #12992]               ; 16-byte Reload
	mov.d	x9, v25[1]
	sdiv	x22, x10, x9
	fmov	x10, d23
	fmov	x11, d25
	sdiv	x10, x10, x11
	mul	x11, x10, x11
	fmov	d28, x10
	mov.d	v28[1], x22
	mov.d	x10, v17[1]
	and.16b	v24, v11, v24
	ldr	q25, [sp, #13008]               ; 16-byte Reload
	mov.d	x12, v25[1]
	sdiv	x7, x10, x12
	fmov	x10, d17
	fmov	x23, d25
	mov.d	x15, v24[1]
	ldr	q25, [sp, #13024]               ; 16-byte Reload
	mov.d	x19, v25[1]
	sdiv	x20, x15, x19
	fmov	x15, d24
	fmov	x24, d25
	sdiv	x21, x15, x24
	mov.d	x15, v3[1]
	ldr	q25, [sp, #13040]               ; 16-byte Reload
	mov.d	x25, v25[1]
	sdiv	x15, x15, x25
	fmov	x6, d3
	fmov	x26, d25
	sdiv	x6, x6, x26
	mul	x25, x15, x25
	mul	x26, x6, x26
	fmov	d8, x26
	mov.d	v8[1], x25
	mul	x19, x20, x19
	mul	x24, x21, x24
	fmov	d27, x24
	mov.d	v27[1], x19
	mul	x12, x7, x12
	sdiv	x19, x10, x23
	mul	x10, x19, x23
	fmov	d26, x10
	mov.d	v26[1], x12
	mul	x9, x22, x9
	fmov	d25, x11
	mov.d	v25[1], x9
	sub.2d	v25, v23, v25
	sub.2d	v26, v17, v26
	sub.2d	v27, v24, v27
	sub.2d	v8, v3, v8
	ldr	q3, [sp, #13088]                ; 16-byte Reload
	cmeq.2d	v3, v3, v8
	ldr	q17, [sp, #13136]               ; 16-byte Reload
	cmeq.2d	v17, v17, v26
	uzp1.4s	v3, v17, v3
	ldr	q17, [sp, #13104]               ; 16-byte Reload
	cmeq.2d	v17, v17, v27
	ldr	q23, [sp, #13120]               ; 16-byte Reload
	cmeq.2d	v23, v23, v25
	uzp1.4s	v17, v23, v17
	uzp1.8h	v10, v17, v3
	ldr	q3, [sp, #13280]                ; 16-byte Reload
	and.16b	v3, v3, v10
	xtn.8b	v3, v3
	shl.8b	v17, v3, #7
	cmlt.8b	v17, v17, #0
	ldr	d23, [sp, #13344]               ; 8-byte Reload
	and.8b	v17, v17, v23
	addv.8b	b17, v17
	fmov	w9, s17
	shl.2d	v17, v28, #5
	ldr	q23, [sp, #10512]               ; 16-byte Reload
	orr.16b	v17, v17, v23
	ldr	q23, [sp, #10464]               ; 16-byte Reload
	add.2d	v17, v23, v17
	movi.2d	v23, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbz	w9, #0, LBB0_626
; %bb.625:                              ; %cond.load2349
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d17
	ldr	s23, [x10]
LBB0_626:                               ; %else2353
                                        ;   in Loop: Header=BB0_608 Depth=2
	ldr	q24, [sp, #13264]               ; 16-byte Reload
	tbz	w9, #1, LBB0_628
; %bb.627:                              ; %cond.load2355
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v23 }[1], [x10]
LBB0_628:                               ; %else2359
                                        ;   in Loop: Header=BB0_608 Depth=2
	ldr	x26, [sp, #11560]               ; 8-byte Reload
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	ldr	q28, [sp, #13280]               ; 16-byte Reload
	fmov	d17, x21
	mov.d	v17[1], x20
	shl.2d	v17, v17, #5
	ldr	q29, [sp, #10496]               ; 16-byte Reload
	orr.16b	v17, v17, v29
	ldr	q29, [sp, #10560]               ; 16-byte Reload
	add.2d	v17, v29, v17
	tbz	w9, #2, LBB0_630
; %bb.629:                              ; %cond.load2361
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d17
	ld1.s	{ v23 }[2], [x10]
LBB0_630:                               ; %else2365
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w9, #3, LBB0_632
; %bb.631:                              ; %cond.load2367
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v23 }[3], [x10]
LBB0_632:                               ; %else2371
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	d17, x19
	mov.d	v17[1], x7
	shl.2d	v17, v17, #5
	ldr	q29, [sp, #10480]               ; 16-byte Reload
	orr.16b	v17, v17, v29
	ldr	q29, [sp, #10544]               ; 16-byte Reload
	add.2d	v17, v29, v17
	tbz	w9, #4, LBB0_634
; %bb.633:                              ; %cond.load2373
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d17
	ld1.s	{ v9 }[0], [x10]
LBB0_634:                               ; %else2377
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w9, #5, LBB0_636
; %bb.635:                              ; %cond.load2379
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v9 }[1], [x10]
LBB0_636:                               ; %else2383
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	d17, x6
	mov.d	v17[1], x15
	shl.2d	v17, v17, #5
	ldr	q2, [sp, #10576]                ; 16-byte Reload
	orr.16b	v17, v17, v2
	ldr	q29, [sp, #10528]               ; 16-byte Reload
	add.2d	v17, v29, v17
	tbz	w9, #6, LBB0_638
; %bb.637:                              ; %cond.load2385
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d17
	ld1.s	{ v9 }[2], [x10]
LBB0_638:                               ; %else2389
                                        ;   in Loop: Header=BB0_608 Depth=2
	cmge.2d	v16, v16, v24
	ldr	q24, [sp, #13296]               ; 16-byte Reload
	cmge.2d	v5, v5, v24
	uzp1.4s	v5, v5, v16
	ldr	q2, [sp, #13248]                ; 16-byte Reload
	mov.16b	v29, v2
	cmge.2d	v1, v1, v2
	ldr	q16, [sp, #13152]               ; 16-byte Reload
	cmge.2d	v0, v0, v16
	uzp1.4s	v0, v0, v1
	uzp1.8h	v0, v0, v5
	and.16b	v0, v28, v0
	xtn.8b	v0, v0
	zip1.8b	v1, v4, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q5, [sp, #10768]                ; 16-byte Reload
	bsl.16b	v1, v18, v5
	zip1.8b	v5, v0, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v1, v5, v1
	str	q1, [sp, #10768]                ; 16-byte Spill
	ldr	q1, [sp, #10784]                ; 16-byte Reload
	bit.16b	v1, v8, v14
	str	q1, [sp, #10784]                ; 16-byte Spill
	ldr	q1, [sp, #10752]                ; 16-byte Reload
	bit.16b	v1, v27, v11
	str	q1, [sp, #10752]                ; 16-byte Spill
	ldr	q1, [sp, #6944]                 ; 16-byte Reload
	bsl.16b	v22, v26, v1
	ldr	q18, [sp, #6960]                ; 16-byte Reload
	bit.16b	v18, v25, v19
	bic.16b	v1, v28, v10
	xtn.8b	v1, v1
	tbz	w9, #7, LBB0_640
; %bb.639:                              ; %cond.load2391
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x9, v17[1]
	ld1.s	{ v9 }[3], [x9]
LBB0_640:                               ; %else2395
                                        ;   in Loop: Header=BB0_608 Depth=2
	ldr	q8, [sp, #12880]                ; 16-byte Reload
	ldr	q24, [sp, #13312]               ; 16-byte Reload
	ldr	d26, [sp, #11576]               ; 8-byte Reload
	zip2.8b	v5, v3, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q16, [sp, #6896]                ; 16-byte Reload
	bsl.16b	v5, v9, v16
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q16, [sp, #6928]                ; 16-byte Reload
	bsl.16b	v3, v23, v16
	zip1.8b	v16, v1, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmge.4s	v16, v16, #0
	and.16b	v23, v16, v3
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v25, v1, v5
	ldr	q1, [sp, #10784]                ; 16-byte Reload
	xtn.2s	v1, v1
	str	q22, [sp, #6944]                ; 16-byte Spill
	xtn.2s	v16, v22
	ldr	q3, [sp, #10752]                ; 16-byte Reload
	xtn.2s	v17, v3
	str	q18, [sp, #6960]                ; 16-byte Spill
	xtn.2s	v3, v18
	mov.s	w9, v3[1]
	fmov	w10, s3
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldr	q3, [sp, #13168]                ; 16-byte Reload
	str	d3, [sp, #15512]
	ldrb	w12, [x12]
	and	w12, w16, w12
	str	q25, [x13, #2048]
	str	q23, [x13, #2032]
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3232
	ldr	s3, [x15, x10, lsl #2]
	tst	w11, w12
	movi.2d	v20, #0000000000000000
	fcsel	s3, s3, s20, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w17, w9
	str	q25, [x13, #2080]
	str	q23, [x13, #2064]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3264
	ldr	s5, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s5, s5, s20, ne
	mov.s	w9, v17[1]
	fmov	w10, s17
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	str	q25, [x13, #2112]
	str	q23, [x13, #2096]
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3296
	ldr	s17, [x15, x10, lsl #2]
	and	w10, w0, w12
	tst	w11, w10
	fcsel	s17, s17, s20, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w1, w9
	str	q25, [x13, #2144]
	str	q23, [x13, #2128]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3328
	ldr	s18, [x12, x11, lsl #2]
	tst	w10, w9
	mov.s	w9, v16[1]
	fcsel	s19, s18, s20, ne
	fmov	w10, s16
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	and	w12, w2, w12
	str	q25, [x13, #2176]
	str	q23, [x13, #2160]
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3360
	ldr	s16, [x15, x10, lsl #2]
	tst	w11, w12
	fcsel	s16, s16, s20, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w3, w9
	str	q25, [x13, #2208]
	str	q23, [x13, #2192]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3392
	ldr	s18, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s18, s18, s20, ne
	mov.s	w9, v1[1]
	fmov	w10, s1
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	and	w12, w4, w12
	str	q25, [x13, #2240]
	str	q23, [x13, #2224]
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3424
	ldr	s1, [x15, x10, lsl #2]
	tst	w11, w12
	fcsel	s1, s1, s20, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w5, w9
	str	q25, [sp, #6896]                ; 16-byte Spill
	str	q25, [x13, #2272]
	str	q23, [sp, #6928]                ; 16-byte Spill
	str	q23, [x13, #2256]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3456
	ldr	s22, [x12, x11, lsl #2]
	tst	w10, w9
	mov.s	v3[1], v5[0]
	mov.s	v3[2], v17[0]
	mov.s	v3[3], v19[0]
	fcsel	s5, s22, s20, ne
	ldr	q17, [sp, #10768]               ; 16-byte Reload
	fsub.4s	v3, v17, v3
	fmov	w9, s7
	shl.2d	v7, v15, #5
	ldr	q17, [sp, #8656]                ; 16-byte Reload
	orr.16b	v7, v7, v17
	ldr	q17, [sp, #8720]                ; 16-byte Reload
	add.2d	v7, v17, v7
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	tbz	w9, #0, LBB0_642
; %bb.641:                              ; %cond.store2398
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d7
	str	s3, [x10]
LBB0_642:                               ; %else2401
                                        ;   in Loop: Header=BB0_608 Depth=2
	ldr	q10, [sp, #13056]               ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbz	w9, #1, LBB0_644
; %bb.643:                              ; %cond.store2402
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v7[1]
	st1.s	{ v3 }[1], [x10]
LBB0_644:                               ; %else2405
                                        ;   in Loop: Header=BB0_608 Depth=2
	shl.2d	v7, v12, #5
	ldr	q17, [sp, #8768]                ; 16-byte Reload
	orr.16b	v7, v7, v17
	ldr	q17, [sp, #8704]                ; 16-byte Reload
	add.2d	v7, v17, v7
	mov.16b	v20, v24
	tbz	w9, #2, LBB0_646
; %bb.645:                              ; %cond.store2406
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d7
	st1.s	{ v3 }[2], [x10]
LBB0_646:                               ; %else2409
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w9, #3, LBB0_648
; %bb.647:                              ; %cond.store2410
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v7[1]
	st1.s	{ v3 }[3], [x10]
LBB0_648:                               ; %else2413
                                        ;   in Loop: Header=BB0_608 Depth=2
	zip2.8b	v3, v4, v0
	ushll.4s	v3, v3, #0
	zip2.8b	v0, v0, v0
	shl.4s	v3, v3, #31
	ushll.4s	v0, v0, #0
	cmlt.4s	v3, v3, #0
	shl.4s	v0, v0, #31
	ldr	q4, [sp, #6976]                 ; 16-byte Reload
	bsl.16b	v3, v6, v4
	cmge.4s	v0, v0, #0
	and.16b	v0, v0, v3
	mov.s	v16[1], v18[0]
	mov.s	v16[2], v1[0]
	mov.s	v16[3], v5[0]
	str	q0, [sp, #6976]                 ; 16-byte Spill
	fsub.4s	v0, v0, v16
	shl.2d	v1, v21, #5
	ldr	q3, [sp, #8752]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8688]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_652
; %bb.649:                              ; %else2417
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.16b	v3, v13
	tbnz	w9, #5, LBB0_653
LBB0_650:                               ; %else2421
                                        ;   in Loop: Header=BB0_608 Depth=2
	shl.2d	v1, v3, #5
	ldr	q3, [sp, #8736]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8672]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_654
LBB0_651:                               ; %else2425
                                        ;   in Loop: Header=BB0_608 Depth=2
	tbz	w9, #7, LBB0_607
	b	LBB0_655
LBB0_652:                               ; %cond.store2414
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	mov.16b	v3, v13
	tbz	w9, #5, LBB0_650
LBB0_653:                               ; %cond.store2418
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v3, #5
	ldr	q3, [sp, #8736]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8672]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_651
LBB0_654:                               ; %cond.store2422
                                        ;   in Loop: Header=BB0_608 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_607
LBB0_655:                               ; %cond.store2426
                                        ;   in Loop: Header=BB0_608 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_607
LBB0_656:                               ; %else2085
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q0, [sp, #10192]                ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #10192]                ; 16-byte Spill
	add.2d	v16, v16, v24
	add.2d	v17, v17, v8
	ldr	q0, [sp, #10208]                ; 16-byte Reload
	add.2d	v0, v0, v20
	str	q0, [sp, #10208]                ; 16-byte Spill
	fmov	x9, d0
	cmp	x9, #1
	b.ge	LBB0_602
LBB0_657:                               ; %direct.true621
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s12
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w9, #0, LBB0_694
; %bb.658:                              ; %else1960
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbnz	w9, #1, LBB0_695
LBB0_659:                               ; %else1966
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbnz	w9, #2, LBB0_696
LBB0_660:                               ; %else1972
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbnz	w9, #3, LBB0_697
LBB0_661:                               ; %else1978
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbnz	w9, #4, LBB0_698
LBB0_662:                               ; %else1984
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbnz	w9, #5, LBB0_699
LBB0_663:                               ; %else1990
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbnz	w9, #6, LBB0_700
LBB0_664:                               ; %else1996
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbz	w9, #7, LBB0_666
LBB0_665:                               ; %cond.load1998
                                        ;   in Loop: Header=BB0_657 Depth=2
	ld1.s	{ v0 }[3], [x15]
LBB0_666:                               ; %else2002
                                        ;   in Loop: Header=BB0_657 Depth=2
	sshll.2d	v3, v31, #0
	ldr	q4, [sp, #5680]                 ; 16-byte Reload
	ldr	q5, [sp, #5312]                 ; 16-byte Reload
	bit.16b	v5, v4, v3
	fmov	w9, s12
	str	q5, [sp, #5312]                 ; 16-byte Spill
	shl.2d	v3, v5, #5
	ldr	q4, [sp, #5968]                 ; 16-byte Reload
	orr.16b	v3, v3, v4
	ldr	q4, [sp, #6032]                 ; 16-byte Reload
	add.2d	v5, v4, v3
	movi.2d	v4, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w9, #0, LBB0_668
; %bb.667:                              ; %cond.load2005
                                        ;   in Loop: Header=BB0_657 Depth=2
	fmov	x10, d5
	ldr	s4, [x10]
LBB0_668:                               ; %else2009
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbz	w9, #1, LBB0_670
; %bb.669:                              ; %cond.load2011
                                        ;   in Loop: Header=BB0_657 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v4 }[1], [x10]
LBB0_670:                               ; %else2015
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q5, [sp, #5296]                 ; 16-byte Reload
	bic.16b	v5, v5, v11
	ssubw2.2d	v5, v5, v31
	str	q5, [sp, #5296]                 ; 16-byte Spill
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #5952]                 ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #6016]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #2, LBB0_672
; %bb.671:                              ; %cond.load2017
                                        ;   in Loop: Header=BB0_657 Depth=2
	fmov	x10, d5
	ld1.s	{ v4 }[2], [x10]
LBB0_672:                               ; %else2021
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbz	w9, #3, LBB0_674
; %bb.673:                              ; %cond.load2023
                                        ;   in Loop: Header=BB0_657 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v4 }[3], [x10]
LBB0_674:                               ; %else2027
                                        ;   in Loop: Header=BB0_657 Depth=2
	sshll.2d	v5, v30, #0
	ldr	q6, [sp, #5280]                 ; 16-byte Reload
	bic.16b	v5, v6, v5
	ssubw.2d	v5, v5, v30
	str	q5, [sp, #5280]                 ; 16-byte Spill
	shl.2d	v5, v5, #5
	ldr	q2, [sp, #6064]                 ; 16-byte Reload
	orr.16b	v5, v5, v2
	ldr	q6, [sp, #6000]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #4, LBB0_676
; %bb.675:                              ; %cond.load2029
                                        ;   in Loop: Header=BB0_657 Depth=2
	fmov	x10, d5
	ld1.s	{ v3 }[0], [x10]
LBB0_676:                               ; %else2033
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbz	w9, #5, LBB0_678
; %bb.677:                              ; %cond.load2035
                                        ;   in Loop: Header=BB0_657 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v3 }[1], [x10]
LBB0_678:                               ; %else2039
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q5, [sp, #5264]                 ; 16-byte Reload
	bic.16b	v5, v5, v14
	ssubw2.2d	v5, v5, v30
	str	q5, [sp, #5264]                 ; 16-byte Spill
	shl.2d	v5, v5, #5
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	orr.16b	v5, v5, v2
	ldr	q6, [sp, #5984]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #6, LBB0_680
; %bb.679:                              ; %cond.load2041
                                        ;   in Loop: Header=BB0_657 Depth=2
	fmov	x10, d5
	ld1.s	{ v3 }[2], [x10]
LBB0_680:                               ; %else2045
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbz	w9, #7, LBB0_682
; %bb.681:                              ; %cond.load2047
                                        ;   in Loop: Header=BB0_657 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_682:                               ; %else2051
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q6, [sp, #13168]                ; 16-byte Reload
	ldr	q7, [sp, #5360]                 ; 16-byte Reload
	movi	d5, #0x0000000000ffff
	bit.8b	v7, v5, v6
	ldr	q5, [sp, #2912]                 ; 16-byte Reload
	ldr	q18, [sp, #5344]                ; 16-byte Reload
	bif.16b	v1, v18, v5
	ldr	q5, [sp, #2864]                 ; 16-byte Reload
	and.16b	v18, v5, v1
	str	q7, [sp, #5360]                 ; 16-byte Spill
	bic.8b	v1, v6, v7
	fmov	w9, s12
	ldr	q5, [sp, #2832]                 ; 16-byte Reload
	ldr	q6, [sp, #5248]                 ; 16-byte Reload
	bif.16b	v4, v6, v5
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v4, v5, v4
	str	q18, [sp, #5344]                ; 16-byte Spill
	str	q4, [sp, #5248]                 ; 16-byte Spill
	fmaxnm.4s	v4, v18, v4
	ldr	q5, [sp, #10208]                ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #10512]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #10464]                ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #0, LBB0_684
; %bb.683:                              ; %cond.store2054
                                        ;   in Loop: Header=BB0_657 Depth=2
	fmov	x10, d5
	str	s4, [x10]
LBB0_684:                               ; %else2057
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbz	w9, #1, LBB0_686
; %bb.685:                              ; %cond.store2058
                                        ;   in Loop: Header=BB0_657 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v4 }[1], [x10]
LBB0_686:                               ; %else2061
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q5, [sp, #10192]                ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #10496]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #10560]                ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #2, LBB0_688
; %bb.687:                              ; %cond.store2062
                                        ;   in Loop: Header=BB0_657 Depth=2
	fmov	x10, d5
	st1.s	{ v4 }[2], [x10]
LBB0_688:                               ; %else2065
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbz	w9, #3, LBB0_690
; %bb.689:                              ; %cond.store2066
                                        ;   in Loop: Header=BB0_657 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v4 }[3], [x10]
LBB0_690:                               ; %else2069
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q4, [sp, #2896]                 ; 16-byte Reload
	ldr	q5, [sp, #5328]                 ; 16-byte Reload
	bif.16b	v0, v5, v4
	ldr	q4, [sp, #2880]                 ; 16-byte Reload
	and.16b	v4, v4, v0
	ldr	q0, [sp, #2848]                 ; 16-byte Reload
	ldr	q5, [sp, #5232]                 ; 16-byte Reload
	bsl.16b	v0, v3, v5
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q4, [sp, #5328]                 ; 16-byte Spill
	str	q0, [sp, #5232]                 ; 16-byte Spill
	fmaxnm.4s	v0, v4, v0
	shl.2d	v1, v16, #5
	ldr	q3, [sp, #10480]                ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #10544]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_701
; %bb.691:                              ; %else2073
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbnz	w9, #5, LBB0_702
LBB0_692:                               ; %else2077
                                        ;   in Loop: Header=BB0_657 Depth=2
	shl.2d	v1, v17, #5
	ldr	q2, [sp, #10576]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_703
LBB0_693:                               ; %else2081
                                        ;   in Loop: Header=BB0_657 Depth=2
	tbz	w9, #7, LBB0_656
	b	LBB0_704
LBB0_694:                               ; %cond.load1956
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q0, [sp, #3008]                 ; 16-byte Reload
	fmov	x10, d0
	ldr	s1, [x10]
	movi.2d	v0, #0000000000000000
	tbz	w9, #1, LBB0_659
LBB0_695:                               ; %cond.load1962
                                        ;   in Loop: Header=BB0_657 Depth=2
	ld1.s	{ v1 }[1], [x19]
	tbz	w9, #2, LBB0_660
LBB0_696:                               ; %cond.load1968
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q3, [sp, #2992]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB0_661
LBB0_697:                               ; %cond.load1974
                                        ;   in Loop: Header=BB0_657 Depth=2
	ld1.s	{ v1 }[3], [x6]
	tbz	w9, #4, LBB0_662
LBB0_698:                               ; %cond.load1980
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v0 }[0], [x10]
	tbz	w9, #5, LBB0_663
LBB0_699:                               ; %cond.load1986
                                        ;   in Loop: Header=BB0_657 Depth=2
	ld1.s	{ v0 }[1], [x7]
	tbz	w9, #6, LBB0_664
LBB0_700:                               ; %cond.load1992
                                        ;   in Loop: Header=BB0_657 Depth=2
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_665
	b	LBB0_666
LBB0_701:                               ; %cond.store2070
                                        ;   in Loop: Header=BB0_657 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	tbz	w9, #5, LBB0_692
LBB0_702:                               ; %cond.store2074
                                        ;   in Loop: Header=BB0_657 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v17, #5
	ldr	q2, [sp, #10576]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_693
LBB0_703:                               ; %cond.store2078
                                        ;   in Loop: Header=BB0_657 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_656
LBB0_704:                               ; %cond.store2082
                                        ;   in Loop: Header=BB0_657 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_656
LBB0_705:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q5, [sp, #2000]                 ; 16-byte Reload
LBB0_706:                               ; %direct.false663
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q27, [sp, #1264]                ; 16-byte Spill
	str	q5, [sp, #2000]                 ; 16-byte Spill
	str	q0, [sp, #1280]                 ; 16-byte Spill
	str	q3, [sp, #1296]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #320]                  ; 16-byte Reload
	ldr	q4, [sp, #8592]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8592]                 ; 16-byte Spill
	ldr	q4, [sp, #8624]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8624]                 ; 16-byte Spill
	ldr	q4, [sp, #8608]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8608]                 ; 16-byte Spill
	ldr	q4, [sp, #8528]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8528]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #8640]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8640]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #8560]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8560]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #8544]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8544]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #8576]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8576]                 ; 16-byte Spill
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #1984]                 ; 16-byte Spill
	ldr	q3, [sp, #1232]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	ldr	q4, [sp, #1216]                 ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q5, [sp, #1248]                 ; 16-byte Reload
	bic.16b	v5, v5, v0
	fmov	x9, d5
	cmp	x9, #17
	b.gt	LBB0_741
; %bb.707:                              ; %direct.true683.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	ldr	q15, [sp, #12784]               ; 16-byte Reload
	ldr	q21, [sp, #1152]                ; 16-byte Reload
	ldr	q9, [sp, #1120]                 ; 16-byte Reload
	b	LBB0_709
LBB0_708:                               ; %else2511
                                        ;   in Loop: Header=BB0_709 Depth=2
	add.2d	v3, v3, v10
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	add.2d	v4, v4, v0
	add.2d	v1, v13, v8
	add.2d	v5, v26, v20
	fmov	x9, d5
	cmp	x9, #18
	b.ge	LBB0_742
LBB0_709:                               ; %direct.true683
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v31, #0
	sshll.2d	v19, v30, #0
	mov.16b	v13, v1
	and.16b	v1, v14, v1
	mov.16b	v27, v3
	and.16b	v3, v11, v3
	mov.16b	v29, v4
	and.16b	v4, v19, v4
	mov.16b	v26, v5
	and.16b	v5, v0, v5
	fmov	x9, d5
	ldr	q6, [sp, #13184]                ; 16-byte Reload
	fmov	x10, d6
	sdiv	x11, x9, x10
	mov.d	x9, v5[1]
	sdiv	x12, x9, x28
	fmov	x9, d4
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x6, d6
	sdiv	x7, x9, x6
	mov.d	x9, v4[1]
	sdiv	x19, x9, x8
	fmov	x9, d3
	ldr	q6, [sp, #13216]                ; 16-byte Reload
	fmov	x22, d6
	sdiv	x20, x9, x22
	mov.d	x9, v3[1]
	sdiv	x21, x9, x30
	fmov	x9, d1
	ldr	q6, [sp, #13232]                ; 16-byte Reload
	fmov	x23, d6
	sdiv	x9, x9, x23
	mov.d	x15, v1[1]
	sdiv	x15, x15, x14
	mul	x10, x11, x10
	fmov	d6, x10
	mul	x10, x12, x28
	mov.d	v6[1], x10
	mul	x10, x21, x30
	mul	x22, x20, x22
	fmov	d7, x22
	mov.d	v7[1], x10
	mul	x10, x19, x8
	mul	x6, x7, x6
	fmov	d16, x6
	mov.d	v16[1], x10
	mul	x10, x15, x14
	mul	x6, x9, x23
	fmov	d17, x6
	mov.d	v17[1], x10
	sub.2d	v18, v1, v17
	sub.2d	v17, v4, v16
	sub.2d	v22, v3, v7
	sub.2d	v1, v5, v6
	shl.2d	v3, v1, #3
	shl.2d	v5, v22, #3
	shl.2d	v6, v17, #3
	shl.2d	v7, v18, #3
	ldr	q4, [sp, #13264]                ; 16-byte Reload
	cmgt.2d	v4, v4, v7
	cmgt.2d	v16, v2, v6
	uzp1.4s	v4, v16, v4
	ldr	q16, [sp, #13248]               ; 16-byte Reload
	cmgt.2d	v16, v16, v5
	cmgt.2d	v23, v25, v3
	uzp1.4s	v16, v23, v16
	fmov	d23, x11
	mov.d	v23[1], x12
	uzp1.8h	v4, v16, v4
	and.16b	v0, v0, v23
	mov.d	x10, v0[1]
	ldr	x12, [sp, #11704]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	x11, d0
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fmov	x12, d0
	sdiv	x6, x11, x12
	msub	x11, x6, x12, x11
	add	x11, x11, x11, lsl #3
	fmov	d0, x11
	add	x10, x10, x10, lsl #3
	mov.d	v0[1], x10
	add.2d	v1, v0, v1
	and.16b	v0, v28, v4
	xtn.8b	v0, v0
	shl.8b	v4, v0, #7
	cmlt.8b	v4, v4, #0
	ldr	d16, [sp, #13344]               ; 8-byte Reload
	and.8b	v4, v4, v16
	addv.8b	b4, v4
	fmov	w6, s4
	shl.2d	v1, v1, #5
	ldr	q16, [sp, #8656]                ; 16-byte Reload
	orr.16b	v1, v1, v16
	ldr	q16, [sp, #8720]                ; 16-byte Reload
	add.2d	v23, v16, v1
	movi.2d	v16, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w6, #0, LBB0_711
; %bb.710:                              ; %cond.load2431
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	x10, d23
	ldr	s16, [x10]
LBB0_711:                               ; %else2435
                                        ;   in Loop: Header=BB0_709 Depth=2
	tbz	w6, #1, LBB0_713
; %bb.712:                              ; %cond.load2437
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v16 }[1], [x10]
LBB0_713:                               ; %else2441
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	d23, x20
	mov.d	v23[1], x21
	and.16b	v23, v11, v23
	mov.d	x10, v23[1]
	sdiv	x11, x10, x25
	msub	x10, x11, x25, x10
	fmov	x11, d23
	ldr	q23, [sp, #11648]               ; 16-byte Reload
	fmov	x12, d23
	sdiv	x20, x11, x12
	msub	x11, x20, x12, x11
	add	x11, x11, x11, lsl #3
	fmov	d23, x11
	add	x10, x10, x10, lsl #3
	mov.d	v23[1], x10
	add.2d	v22, v23, v22
	shl.2d	v22, v22, #5
	ldr	q23, [sp, #8768]                ; 16-byte Reload
	orr.16b	v22, v22, v23
	ldr	q23, [sp, #8704]                ; 16-byte Reload
	add.2d	v22, v23, v22
	tbz	w6, #2, LBB0_715
; %bb.714:                              ; %cond.load2443
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	x10, d22
	ld1.s	{ v16 }[2], [x10]
LBB0_715:                               ; %else2447
                                        ;   in Loop: Header=BB0_709 Depth=2
	ldr	q23, [sp, #4656]                ; 16-byte Reload
	tbz	w6, #3, LBB0_717
; %bb.716:                              ; %cond.load2449
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.d	x10, v22[1]
	ld1.s	{ v16 }[3], [x10]
LBB0_717:                               ; %else2453
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	d22, x7
	mov.d	v22[1], x19
	and.16b	v19, v19, v22
	mov.d	x10, v19[1]
	sdiv	x11, x10, x26
	msub	x10, x11, x26, x10
	fmov	x11, d19
	ldr	q19, [sp, #11664]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x7, x11, x12
	msub	x11, x7, x12, x11
	add	x11, x11, x11, lsl #3
	fmov	d19, x11
	add	x10, x10, x10, lsl #3
	mov.d	v19[1], x10
	add.2d	v17, v19, v17
	shl.2d	v17, v17, #5
	ldr	q19, [sp, #8752]                ; 16-byte Reload
	orr.16b	v17, v17, v19
	ldr	q19, [sp, #8688]                ; 16-byte Reload
	add.2d	v17, v19, v17
	tbz	w6, #4, LBB0_719
; %bb.718:                              ; %cond.load2455
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	x10, d17
	ld1.s	{ v1 }[0], [x10]
LBB0_719:                               ; %else2459
                                        ;   in Loop: Header=BB0_709 Depth=2
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	tbz	w6, #5, LBB0_721
; %bb.720:                              ; %cond.load2461
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v1 }[1], [x10]
LBB0_721:                               ; %else2465
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	d17, x9
	mov.d	v17[1], x15
	and.16b	v17, v14, v17
	mov.d	x9, v17[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d17
	ldr	q17, [sp, #11632]               ; 16-byte Reload
	fmov	x11, d17
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	add	x10, x10, x10, lsl #3
	fmov	d17, x10
	add	x9, x9, x9, lsl #3
	mov.d	v17[1], x9
	add.2d	v17, v17, v18
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #8736]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #8672]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w6, #6, LBB0_723
; %bb.722:                              ; %cond.load2467
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	x9, d17
	ld1.s	{ v1 }[2], [x9]
LBB0_723:                               ; %else2471
                                        ;   in Loop: Header=BB0_709 Depth=2
	ldr	q18, [sp, #13264]               ; 16-byte Reload
	cmge.2d	v7, v7, v18
	cmge.2d	v6, v6, v2
	uzp1.4s	v6, v6, v7
	ldr	q7, [sp, #13248]                ; 16-byte Reload
	cmge.2d	v5, v5, v7
	cmge.2d	v3, v3, v25
	uzp1.4s	v3, v3, v5
	uzp1.8h	v3, v3, v6
	and.16b	v3, v28, v3
	xtn.8b	v3, v3
	tbz	w6, #7, LBB0_725
; %bb.724:                              ; %cond.load2473
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.d	x9, v17[1]
	ld1.s	{ v1 }[3], [x9]
LBB0_725:                               ; %else2477
                                        ;   in Loop: Header=BB0_709 Depth=2
	zip1.8b	v5, v0, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	bsl.16b	v5, v16, v21
	zip1.8b	v6, v3, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmge.4s	v6, v6, #0
	and.16b	v21, v6, v5
	and.16b	v5, v31, v21
	fcmge.4s	v6, v5, v23
	ldr	q19, [sp, #11872]               ; 16-byte Reload
	fcmge.4s	v7, v19, v5
	and.16b	v6, v6, v7
	and.16b	v6, v6, v5
	ldr	q7, [sp, #11856]                ; 16-byte Reload
	fmul.4s	v7, v6, v7
	movi.4s	v16, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	bif.16b	v16, v7, v17
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	ldr	q17, [sp, #11840]               ; 16-byte Reload
	fmul.4s	v17, v16, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [sp, #11824]               ; 16-byte Reload
	fmul.4s	v16, v16, v17
	fadd.4s	v6, v6, v16
	ldr	q16, [sp, #11344]               ; 16-byte Reload
	fmul.4s	v16, v6, v16
	ldr	q17, [sp, #11328]               ; 16-byte Reload
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v6, v16
	ldr	q17, [sp, #11312]               ; 16-byte Reload
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v6, v16
	ldr	q17, [sp, #11296]               ; 16-byte Reload
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v6, v16
	ldr	q17, [sp, #11280]               ; 16-byte Reload
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v6, v16
	movi.4s	v17, #63, lsl #24
	fadd.4s	v16, v16, v17
	fmul.4s	v17, v6, v6
	fmul.4s	v16, v17, v16
	fadd.4s	v6, v6, v16
	fmov.4s	v18, #1.00000000
	fadd.4s	v6, v6, v18
	sshr.4s	v16, v7, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v18
	fmul.4s	v6, v6, v17
	sub.4s	v7, v7, v16
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v18
	fmul.4s	v6, v6, v7
	fcmgt.4s	v7, v23, v5
	bic.16b	v6, v6, v7
	fcmgt.4s	v7, v5, v19
	ldr	q16, [sp, #11264]               ; 16-byte Reload
	bit.16b	v6, v16, v7
	fcmeq.4s	v5, v5, v5
	ldr	q7, [sp, #11248]                ; 16-byte Reload
	bsl.16b	v5, v6, v7
	fmov	w9, s4
	shl.2d	v4, v26, #5
	ldr	q6, [sp, #8576]                 ; 16-byte Reload
	orr.16b	v4, v4, v6
	ldr	q6, [sp, #8528]                 ; 16-byte Reload
	add.2d	v4, v6, v4
	tbnz	w9, #0, LBB0_734
; %bb.726:                              ; %else2483
                                        ;   in Loop: Header=BB0_709 Depth=2
	tbnz	w9, #1, LBB0_735
LBB0_727:                               ; %else2487
                                        ;   in Loop: Header=BB0_709 Depth=2
	shl.2d	v4, v27, #5
	ldr	q6, [sp, #8560]                 ; 16-byte Reload
	orr.16b	v4, v4, v6
	ldr	q6, [sp, #8624]                 ; 16-byte Reload
	add.2d	v4, v6, v4
	tbnz	w9, #2, LBB0_736
LBB0_728:                               ; %else2491
                                        ;   in Loop: Header=BB0_709 Depth=2
	tbz	w9, #3, LBB0_730
LBB0_729:                               ; %cond.store2492
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.d	x10, v4[1]
	st1.s	{ v5 }[3], [x10]
LBB0_730:                               ; %else2495
                                        ;   in Loop: Header=BB0_709 Depth=2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q4, [sp, #6912]                 ; 16-byte Reload
	bsl.16b	v0, v1, v4
	zip2.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #6912]                 ; 16-byte Spill
	and.16b	v0, v30, v0
	fcmge.4s	v1, v0, v23
	ldr	q7, [sp, #11872]                ; 16-byte Reload
	fcmge.4s	v3, v7, v0
	and.16b	v1, v1, v3
	and.16b	v1, v1, v0
	ldr	q3, [sp, #11856]                ; 16-byte Reload
	fmul.4s	v3, v1, v3
	movi.4s	v4, #75, lsl #24
	mvni.4s	v5, #128, lsl #24
	bif.16b	v4, v3, v5
	fadd.4s	v3, v3, v4
	fsub.4s	v3, v3, v4
	fcvtzs.4s	v3, v3
	scvtf.4s	v4, v3
	ldr	q5, [sp, #11840]                ; 16-byte Reload
	fmul.4s	v5, v4, v5
	fadd.4s	v1, v1, v5
	ldr	q5, [sp, #11824]                ; 16-byte Reload
	fmul.4s	v4, v4, v5
	fadd.4s	v1, v1, v4
	ldr	q4, [sp, #11344]                ; 16-byte Reload
	fmul.4s	v4, v1, v4
	ldr	q5, [sp, #11328]                ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v1, v4
	ldr	q5, [sp, #11312]                ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v1, v4
	ldr	q5, [sp, #11296]                ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v1, v4
	ldr	q5, [sp, #11280]                ; 16-byte Reload
	fadd.4s	v4, v4, v5
	fmul.4s	v4, v1, v4
	movi.4s	v5, #63, lsl #24
	fadd.4s	v4, v4, v5
	fmul.4s	v5, v1, v1
	fmul.4s	v4, v5, v4
	fadd.4s	v1, v1, v4
	fmov.4s	v6, #1.00000000
	fadd.4s	v1, v1, v6
	sshr.4s	v4, v3, #1
	shl.4s	v5, v4, #23
	add.4s	v5, v5, v6
	fmul.4s	v1, v1, v5
	sub.4s	v3, v3, v4
	shl.4s	v3, v3, #23
	add.4s	v3, v3, v6
	fmul.4s	v1, v1, v3
	fcmgt.4s	v3, v23, v0
	bic.16b	v1, v1, v3
	fcmgt.4s	v3, v0, v7
	ldr	q4, [sp, #11264]                ; 16-byte Reload
	bit.16b	v1, v4, v3
	fcmeq.4s	v0, v0, v0
	ldr	q3, [sp, #11248]                ; 16-byte Reload
	bsl.16b	v0, v1, v3
	mov.16b	v4, v29
	shl.2d	v1, v29, #5
	ldr	q3, [sp, #8544]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8608]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_737
; %bb.731:                              ; %else2499
                                        ;   in Loop: Header=BB0_709 Depth=2
	tbnz	w9, #5, LBB0_738
LBB0_732:                               ; %else2503
                                        ;   in Loop: Header=BB0_709 Depth=2
	shl.2d	v1, v13, #5
	ldr	q3, [sp, #8640]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8592]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_739
LBB0_733:                               ; %else2507
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.16b	v3, v27
	tbz	w9, #7, LBB0_708
	b	LBB0_740
LBB0_734:                               ; %cond.store2480
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	x10, d4
	str	s5, [x10]
	tbz	w9, #1, LBB0_727
LBB0_735:                               ; %cond.store2484
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.d	x10, v4[1]
	st1.s	{ v5 }[1], [x10]
	shl.2d	v4, v27, #5
	ldr	q6, [sp, #8560]                 ; 16-byte Reload
	orr.16b	v4, v4, v6
	ldr	q6, [sp, #8624]                 ; 16-byte Reload
	add.2d	v4, v6, v4
	tbz	w9, #2, LBB0_728
LBB0_736:                               ; %cond.store2488
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	x10, d4
	st1.s	{ v5 }[2], [x10]
	tbnz	w9, #3, LBB0_729
	b	LBB0_730
LBB0_737:                               ; %cond.store2496
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	tbz	w9, #5, LBB0_732
LBB0_738:                               ; %cond.store2500
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v13, #5
	ldr	q3, [sp, #8640]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8592]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_733
LBB0_739:                               ; %cond.store2504
                                        ;   in Loop: Header=BB0_709 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	mov.16b	v3, v27
	tbz	w9, #7, LBB0_708
LBB0_740:                               ; %cond.store2508
                                        ;   in Loop: Header=BB0_709 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_708
LBB0_741:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q1, [sp, #1984]                 ; 16-byte Reload
	ldr	q15, [sp, #12784]               ; 16-byte Reload
	ldr	q21, [sp, #1152]                ; 16-byte Reload
	ldr	q9, [sp, #1120]                 ; 16-byte Reload
LBB0_742:                               ; %direct.false684
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q21, [sp, #1152]                ; 16-byte Spill
	str	q1, [sp, #1984]                 ; 16-byte Spill
	str	q4, [sp, #1216]                 ; 16-byte Spill
	str	q3, [sp, #1232]                 ; 16-byte Spill
	str	q5, [sp, #1248]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #304]                  ; 16-byte Reload
	ldr	q4, [sp, #12864]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #12864]                ; 16-byte Spill
	ldr	q4, [sp, #12768]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #12768]                ; 16-byte Spill
	ldr	q4, [sp, #12752]                ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #12752]                ; 16-byte Spill
	bit.16b	v15, v3, v0
	str	q15, [sp, #12784]               ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #12800]                ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #12800]                ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #12832]                ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #12832]                ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #12816]                ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #12816]                ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #12848]                ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #12848]                ; 16-byte Spill
	ldr	q4, [sp, #1168]                 ; 16-byte Reload
	bic.16b	v4, v4, v14
	ldr	q3, [sp, #1200]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	ldr	q5, [sp, #1184]                 ; 16-byte Reload
	bic.16b	v5, v5, v1
	ldr	q15, [sp, #1136]                ; 16-byte Reload
	bic.16b	v15, v15, v0
	fmov	x9, d15
	cmp	x9, #17
	b.le	LBB0_748
; %bb.743:                              ;   in Loop: Header=BB0_92 Depth=1
	ldr	q19, [sp, #4784]                ; 16-byte Reload
	ldr	q21, [sp, #4768]                ; 16-byte Reload
	ldr	q26, [sp, #11232]               ; 16-byte Reload
	ldr	q13, [sp, #10976]               ; 16-byte Reload
LBB0_744:                               ; %direct.false697
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q4, [sp, #1168]                 ; 16-byte Spill
	str	q5, [sp, #1184]                 ; 16-byte Spill
	str	q3, [sp, #1200]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #288]                  ; 16-byte Reload
	ldr	q4, [sp, #3328]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #3328]                 ; 16-byte Spill
	ldr	q4, [sp, #3232]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #3232]                 ; 16-byte Spill
	ldr	q4, [sp, #3216]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #3216]                 ; 16-byte Spill
	ldr	q4, [sp, #3248]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #3248]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #3264]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #3264]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #3296]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #3296]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #3280]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #3280]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #3312]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #3312]                 ; 16-byte Spill
	ldr	q3, [sp, #10048]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #10048]                ; 16-byte Spill
	bic.16b	v19, v19, v11
	bic.16b	v21, v21, v1
	ldr	q1, [sp, #10032]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10032]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #1
	b.lt	LBB0_1337
LBB0_745:                               ; %direct.false717
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q21, [sp, #4768]                ; 16-byte Spill
	str	q19, [sp, #4784]                ; 16-byte Spill
	str	q15, [sp, #1136]                ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #272]                  ; 16-byte Reload
	ldr	q4, [sp, #5920]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #5920]                 ; 16-byte Spill
	ldr	q4, [sp, #5824]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #5824]                 ; 16-byte Spill
	ldr	q4, [sp, #5936]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #5936]                 ; 16-byte Spill
	ldr	q4, [sp, #5840]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #5840]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #5856]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #5856]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #5888]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #5888]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #5872]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #5872]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #5904]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #5904]                 ; 16-byte Spill
	ldr	q3, [sp, #11536]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #11536]                ; 16-byte Spill
	ldr	q6, [sp, #8496]                 ; 16-byte Reload
	bic.16b	v6, v6, v11
	ldr	q5, [sp, #8480]                 ; 16-byte Reload
	bic.16b	v5, v5, v1
	ldr	q4, [sp, #8512]                 ; 16-byte Reload
	bic.16b	v4, v4, v0
	fmov	x9, d4
	cmp	x9, #1
	str	q9, [sp, #1120]                 ; 16-byte Spill
	b.gt	LBB0_832
; %bb.746:                              ; %direct.true731.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q29, [sp, #11536]               ; 16-byte Reload
	b	LBB0_797
LBB0_747:                               ; %else2642
                                        ;   in Loop: Header=BB0_748 Depth=2
	add.2d	v3, v3, v10
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	add.2d	v5, v5, v0
	add.2d	v4, v4, v8
	add.2d	v15, v15, v20
	fmov	x9, d15
	cmp	x9, #18
	b.ge	LBB0_744
LBB0_748:                               ; %direct.true696
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v16, v31, #0
	sshll.2d	v0, v30, #0
	mov.16b	v21, v4
	and.16b	v1, v14, v4
	mov.16b	v29, v3
	and.16b	v4, v11, v3
	mov.16b	v13, v5
	and.16b	v5, v0, v5
	and.16b	v3, v16, v15
	fmov	x9, d3
	ldr	q6, [sp, #13184]                ; 16-byte Reload
	fmov	x10, d6
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d17, x9
	mov.d	x9, v3[1]
	sdiv	x11, x9, x28
	mov.d	v17[1], x11
	fmov	x9, d5
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x7, x9, x12
	mov.d	x6, v5[1]
	fmov	x9, d4
	ldr	q6, [sp, #13216]                ; 16-byte Reload
	fmov	x19, d6
	mov.d	x21, v4[1]
	sdiv	x20, x9, x19
	fmov	x9, d1
	ldr	q6, [sp, #13232]                ; 16-byte Reload
	fmov	x22, d6
	sdiv	x9, x9, x22
	mov.d	x15, v1[1]
	sdiv	x15, x15, x14
	mul	x23, x15, x14
	mul	x22, x9, x22
	fmov	d6, x22
	mov.d	v6[1], x23
	sdiv	x21, x21, x30
	mul	x22, x21, x30
	mul	x19, x20, x19
	fmov	d18, x19
	mov.d	v18[1], x22
	sdiv	x19, x6, x8
	mul	x6, x19, x8
	mul	x12, x7, x12
	fmov	d7, x12
	mov.d	v7[1], x6
	mul	x11, x11, x28
	fmov	d19, x10
	mov.d	v19[1], x11
	sub.2d	v3, v3, v19
	sub.2d	v7, v5, v7
	sub.2d	v18, v4, v18
	sub.2d	v6, v1, v6
	shl.2d	v1, v3, #3
	shl.2d	v4, v18, #3
	shl.2d	v5, v7, #3
	shl.2d	v19, v6, #3
	ldr	q22, [sp, #13264]               ; 16-byte Reload
	cmgt.2d	v19, v22, v19
	cmgt.2d	v5, v2, v5
	uzp1.4s	v5, v5, v19
	ldr	q2, [sp, #13248]                ; 16-byte Reload
	cmgt.2d	v4, v2, v4
	cmgt.2d	v1, v25, v1
	uzp1.4s	v1, v1, v4
	uzp1.8h	v19, v1, v5
	and.16b	v1, v28, v19
	xtn.8b	v1, v1
	and.16b	v4, v16, v17
	mov.d	x10, v4[1]
	ldr	x12, [sp, #11704]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	x11, d4
	ldr	q4, [sp, #11680]                ; 16-byte Reload
	fmov	x12, d4
	sdiv	x6, x11, x12
	msub	x11, x6, x12, x11
	fmov	d23, x11
	mov.d	v23[1], x10
	shl.8b	v4, v1, #7
	cmlt.8b	v4, v4, #0
	ldr	d5, [sp, #13344]                ; 8-byte Reload
	and.8b	v5, v4, v5
	addv.8b	b5, v5
	fmov	w6, s5
	add.2d	v5, v3, v3
	ldr	q17, [sp, #11168]               ; 16-byte Reload
	add.2d	v5, v5, v17
	ldr	q17, [sp, #11104]               ; 16-byte Reload
	add.2d	v5, v17, v5
	add.2d	v17, v5, v23
	tbz	w6, #0, LBB0_750
; %bb.749:                              ; %cond.load2513
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d17
	ldr	b5, [x10]
	tbnz	w6, #1, LBB0_751
	b	LBB0_752
LBB0_750:                               ;   in Loop: Header=BB0_748 Depth=2
	movi.2d	v5, #0000000000000000
	tbz	w6, #1, LBB0_752
LBB0_751:                               ; %cond.load2519
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v17[1]
	ld1.b	{ v5 }[1], [x10]
LBB0_752:                               ; %else2523
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	d17, x20
	mov.d	v17[1], x21
	and.16b	v17, v11, v17
	mov.d	x10, v17[1]
	sdiv	x11, x10, x25
	msub	x10, x11, x25, x10
	fmov	x11, d17
	ldr	q17, [sp, #11648]               ; 16-byte Reload
	fmov	x12, d17
	sdiv	x20, x11, x12
	msub	x11, x20, x12, x11
	fmov	d22, x11
	mov.d	v22[1], x10
	add.2d	v17, v18, v18
	ldr	q25, [sp, #11152]               ; 16-byte Reload
	add.2d	v17, v17, v25
	ldr	q25, [sp, #11088]               ; 16-byte Reload
	add.2d	v17, v25, v17
	add.2d	v17, v17, v22
	tbz	w6, #2, LBB0_754
; %bb.753:                              ; %cond.load2525
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d17
	ld1.b	{ v5 }[2], [x10]
LBB0_754:                               ; %else2529
                                        ;   in Loop: Header=BB0_748 Depth=2
	tbz	w6, #3, LBB0_756
; %bb.755:                              ; %cond.load2531
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v17[1]
	ld1.b	{ v5 }[3], [x10]
LBB0_756:                               ; %else2535
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	d17, x7
	mov.d	v17[1], x19
	and.16b	v17, v0, v17
	mov.d	x10, v17[1]
	sdiv	x11, x10, x26
	msub	x10, x11, x26, x10
	fmov	x11, d17
	ldr	q17, [sp, #11664]               ; 16-byte Reload
	fmov	x12, d17
	sdiv	x7, x11, x12
	msub	x11, x7, x12, x11
	fmov	d25, x11
	mov.d	v25[1], x10
	add.2d	v17, v7, v7
	ldr	q26, [sp, #11136]               ; 16-byte Reload
	add.2d	v17, v17, v26
	ldr	q2, [sp, #11200]                ; 16-byte Reload
	add.2d	v17, v2, v17
	add.2d	v17, v17, v25
	tbz	w6, #4, LBB0_758
; %bb.757:                              ; %cond.load2537
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d17
	ld1.b	{ v5 }[4], [x10]
LBB0_758:                               ; %else2541
                                        ;   in Loop: Header=BB0_748 Depth=2
	tbz	w6, #5, LBB0_760
; %bb.759:                              ; %cond.load2543
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v17[1]
	ld1.b	{ v5 }[5], [x10]
LBB0_760:                               ; %else2547
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	d17, x9
	mov.d	v17[1], x15
	and.16b	v17, v14, v17
	mov.d	x9, v17[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d17
	ldr	q17, [sp, #11632]               ; 16-byte Reload
	fmov	x11, d17
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d26, x10
	mov.d	v26[1], x9
	add.2d	v17, v6, v6
	ldr	q27, [sp, #11120]               ; 16-byte Reload
	add.2d	v17, v17, v27
	ldr	q27, [sp, #11184]               ; 16-byte Reload
	add.2d	v17, v27, v17
	add.2d	v17, v17, v26
	tbz	w6, #6, LBB0_762
; %bb.761:                              ; %cond.load2549
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x9, d17
	ld1.b	{ v5 }[6], [x9]
LBB0_762:                               ; %else2553
                                        ;   in Loop: Header=BB0_748 Depth=2
	tbz	w6, #7, LBB0_764
; %bb.763:                              ; %cond.load2555
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x9, v17[1]
	ld1.b	{ v5 }[7], [x9]
LBB0_764:                               ; %else2559
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	q17, [sp, #6864]                ; 16-byte Reload
	bit.16b	v17, v3, v16
	ldr	q27, [sp, #6800]                ; 16-byte Reload
	bit.16b	v27, v23, v16
	xtn.8b	v19, v19
	fmov	x9, d27
	add	x9, x9, x9, lsl #3
	fmov	d3, x9
	str	q27, [sp, #6800]                ; 16-byte Spill
	mov.d	x9, v27[1]
	add	x9, x9, x9, lsl #3
	mov.d	v3[1], x9
	str	q17, [sp, #6864]                ; 16-byte Spill
	add.2d	v3, v3, v17
	ldr	q16, [sp, #13168]               ; 16-byte Reload
	and.8b	v16, v16, v19
	shl.8b	v17, v16, #7
	cmlt.8b	v17, v17, #0
	ldr	d23, [sp, #13344]               ; 8-byte Reload
	and.8b	v17, v17, v23
	addv.8b	b23, v17
	fmov	w9, s23
	shl.2d	v3, v3, #5
	ldr	q17, [sp, #8576]                ; 16-byte Reload
	orr.16b	v3, v3, v17
	ldr	q17, [sp, #8528]                ; 16-byte Reload
	add.2d	v17, v17, v3
	movi.2d	v27, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w9, #0, LBB0_766
; %bb.765:                              ; %cond.load2562
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d17
	ldr	s27, [x10]
LBB0_766:                               ; %else2566
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.16b	v24, v9
	mov.16b	v12, v15
	tbz	w9, #1, LBB0_768
; %bb.767:                              ; %cond.load2568
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v27 }[1], [x10]
LBB0_768:                               ; %else2572
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	q15, [sp, #6848]                ; 16-byte Reload
	bit.16b	v15, v18, v11
	ldr	q18, [sp, #6784]                ; 16-byte Reload
	bit.16b	v18, v22, v11
	fmov	x10, d18
	add	x10, x10, x10, lsl #3
	fmov	d17, x10
	str	q18, [sp, #6784]                ; 16-byte Spill
	mov.d	x10, v18[1]
	add	x10, x10, x10, lsl #3
	mov.d	v17[1], x10
	str	q15, [sp, #6848]                ; 16-byte Spill
	add.2d	v17, v17, v15
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #8560]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q2, [sp, #8624]                 ; 16-byte Reload
	add.2d	v17, v2, v17
	tbz	w9, #2, LBB0_770
; %bb.769:                              ; %cond.load2574
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d17
	ld1.s	{ v27 }[2], [x10]
LBB0_770:                               ; %else2578
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	mov.16b	v15, v12
	mov.16b	v18, v24
	ldr	q24, [sp, #11536]               ; 16-byte Reload
	tbz	w9, #3, LBB0_772
; %bb.771:                              ; %cond.load2580
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v17[1]
	ld1.s	{ v27 }[3], [x10]
LBB0_772:                               ; %else2584
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	q17, [sp, #6832]                ; 16-byte Reload
	bit.16b	v17, v7, v0
	ldr	q7, [sp, #6768]                 ; 16-byte Reload
	bit.16b	v7, v25, v0
	fmov	x10, d7
	add	x10, x10, x10, lsl #3
	fmov	d0, x10
	str	q7, [sp, #6768]                 ; 16-byte Spill
	mov.d	x10, v7[1]
	add	x10, x10, x10, lsl #3
	mov.d	v0[1], x10
	str	q17, [sp, #6832]                ; 16-byte Spill
	add.2d	v0, v0, v17
	shl.2d	v0, v0, #5
	ldr	q7, [sp, #8544]                 ; 16-byte Reload
	orr.16b	v0, v0, v7
	ldr	q7, [sp, #8608]                 ; 16-byte Reload
	add.2d	v0, v7, v0
	tbz	w9, #4, LBB0_774
; %bb.773:                              ; %cond.load2586
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d0
	ld1.s	{ v3 }[0], [x10]
LBB0_774:                               ; %else2590
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	tbz	w9, #5, LBB0_776
; %bb.775:                              ; %cond.load2592
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v3 }[1], [x10]
LBB0_776:                               ; %else2596
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	q7, [sp, #6816]                 ; 16-byte Reload
	bit.16b	v7, v6, v14
	ldr	q6, [sp, #6736]                 ; 16-byte Reload
	bit.16b	v6, v26, v14
	fmov	x10, d6
	add	x10, x10, x10, lsl #3
	fmov	d0, x10
	str	q6, [sp, #6736]                 ; 16-byte Spill
	mov.d	x10, v6[1]
	add	x10, x10, x10, lsl #3
	mov.d	v0[1], x10
	str	q7, [sp, #6816]                 ; 16-byte Spill
	add.2d	v0, v0, v7
	shl.2d	v0, v0, #5
	ldr	q2, [sp, #8640]                 ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q6, [sp, #8592]                 ; 16-byte Reload
	add.2d	v0, v6, v0
	tbz	w9, #6, LBB0_778
; %bb.777:                              ; %cond.load2598
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d0
	ld1.s	{ v3 }[2], [x10]
LBB0_778:                               ; %else2602
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	d12, [sp, #11576]               ; 8-byte Reload
	ldr	q26, [sp, #11232]               ; 16-byte Reload
	str	q24, [sp, #11536]               ; 16-byte Spill
	tbz	w9, #7, LBB0_780
; %bb.779:                              ; %cond.load2604
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_780:                               ; %else2608
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	q6, [sp, #13168]                ; 16-byte Reload
	ldr	q0, [sp, #6880]                 ; 16-byte Reload
	bic.8b	v0, v0, v6
	orr.8b	v7, v1, v0
	cmtst.8b	v0, v5, v5
	bif.8b	v0, v18, v4
	ldr	d1, [sp, #11552]                ; 8-byte Reload
	orr.8b	v1, v19, v1
	and.8b	v9, v1, v0
	str	q7, [sp, #6880]                 ; 16-byte Spill
	bic.8b	v0, v6, v7
	fmov	w9, s23
	zip1.8b	v1, v16, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q4, [sp, #6720]                 ; 16-byte Reload
	bsl.16b	v1, v27, v4
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v4, v4, #0
	and.16b	v4, v4, v1
	zip1.8b	v1, v9, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	str	q4, [sp, #6720]                 ; 16-byte Spill
	and.16b	v1, v1, v4
	shl.2d	v4, v15, #5
	ldr	q5, [sp, #12848]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12784]                ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w9, #0, LBB0_793
; %bb.781:                              ; %else2614
                                        ;   in Loop: Header=BB0_748 Depth=2
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	tbnz	w9, #1, LBB0_794
LBB0_782:                               ; %else2618
                                        ;   in Loop: Header=BB0_748 Depth=2
	shl.2d	v4, v29, #5
	ldr	q5, [sp, #12832]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12768]                ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w9, #2, LBB0_795
LBB0_783:                               ; %else2622
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.16b	v5, v13
	tbz	w9, #3, LBB0_785
LBB0_784:                               ; %cond.store2623
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v4[1]
	st1.s	{ v1 }[3], [x10]
LBB0_785:                               ; %else2626
                                        ;   in Loop: Header=BB0_748 Depth=2
	zip2.8b	v1, v16, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q4, [sp, #6752]                 ; 16-byte Reload
	bsl.16b	v1, v3, v4
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	zip2.8b	v0, v9, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q1, [sp, #6752]                 ; 16-byte Spill
	and.16b	v0, v0, v1
	shl.2d	v1, v5, #5
	ldr	q3, [sp, #12816]                ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #12752]                ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q13, [sp, #10976]               ; 16-byte Reload
	tbz	w9, #4, LBB0_787
; %bb.786:                              ; %cond.store2627
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d1
	str	s0, [x10]
LBB0_787:                               ; %else2630
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.16b	v4, v21
	tbz	w9, #5, LBB0_789
; %bb.788:                              ; %cond.store2631
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
LBB0_789:                               ; %else2634
                                        ;   in Loop: Header=BB0_748 Depth=2
	shl.2d	v1, v4, #5
	ldr	q3, [sp, #12800]                ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #12864]                ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q19, [sp, #4784]                ; 16-byte Reload
	ldr	q21, [sp, #4768]                ; 16-byte Reload
	tbz	w9, #6, LBB0_791
; %bb.790:                              ; %cond.store2635
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
LBB0_791:                               ; %else2638
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.16b	v3, v29
	tbz	w9, #7, LBB0_747
; %bb.792:                              ; %cond.store2639
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_747
LBB0_793:                               ; %cond.store2611
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d4
	str	s1, [x10]
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	tbz	w9, #1, LBB0_782
LBB0_794:                               ; %cond.store2615
                                        ;   in Loop: Header=BB0_748 Depth=2
	mov.d	x10, v4[1]
	st1.s	{ v1 }[1], [x10]
	shl.2d	v4, v29, #5
	ldr	q5, [sp, #12832]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12768]                ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w9, #2, LBB0_783
LBB0_795:                               ; %cond.store2619
                                        ;   in Loop: Header=BB0_748 Depth=2
	fmov	x10, d4
	st1.s	{ v1 }[2], [x10]
	mov.16b	v5, v13
	tbnz	w9, #3, LBB0_784
	b	LBB0_785
LBB0_796:                               ; %else2855
                                        ;   in Loop: Header=BB0_797 Depth=2
	add.2d	v6, v6, v10
	add.2d	v5, v5, v15
	add.2d	v29, v29, v8
	add.2d	v4, v4, v20
	fmov	x9, d4
	cmp	x9, #2
	b.ge	LBB0_833
LBB0_797:                               ; %direct.true731
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_800 Depth 3
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	str	q29, [sp, #11536]               ; 16-byte Spill
	and.16b	v3, v14, v29
	str	q4, [sp, #8512]                 ; 16-byte Spill
	and.16b	v4, v0, v4
	mov.d	x9, v4[1]
	ldr	x11, [sp, #11704]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d4
	ldr	q4, [sp, #11680]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	str	q5, [sp, #8480]                 ; 16-byte Spill
	and.16b	v5, v1, v5
	mov.d	x9, v5[1]
	sdiv	x10, x9, x26
	msub	x9, x10, x26, x9
	fmov	x10, d5
	ldr	q5, [sp, #11664]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d5, x10
	mov.d	v5[1], x9
	str	q6, [sp, #8496]                 ; 16-byte Spill
	and.16b	v6, v11, v6
	mov.d	x9, v6[1]
	sdiv	x10, x9, x25
	msub	x9, x10, x25, x9
	fmov	x10, d6
	ldr	q6, [sp, #11648]                ; 16-byte Reload
	fmov	x11, d6
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	mov.d	x9, v3[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d3
	ldr	q3, [sp, #11632]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d3, x10
	mov.d	v3[1], x9
	ldr	q7, [sp, #6624]                 ; 16-byte Reload
	bit.16b	v7, v3, v14
	ldr	q3, [sp, #6656]                 ; 16-byte Reload
	bif.16b	v6, v3, v11
	ldr	q3, [sp, #6640]                 ; 16-byte Reload
	bif.16b	v5, v3, v1
	ldr	q3, [sp, #6672]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	ldr	q18, [sp, #6688]                ; 16-byte Reload
	bic.16b	v18, v18, v14
	bic.16b	v26, v26, v11
	ldr	q19, [sp, #6704]                ; 16-byte Reload
	bic.16b	v19, v19, v1
	ldr	q16, [sp, #6608]                ; 16-byte Reload
	bic.16b	v16, v16, v0
	ldr	q0, [sp, #12896]                ; 16-byte Reload
	bic.16b	v0, v0, v30
	str	q0, [sp, #12896]                ; 16-byte Spill
	ldr	q0, [sp, #12912]                ; 16-byte Reload
	bic.16b	v0, v0, v31
	str	q0, [sp, #12912]                ; 16-byte Spill
	ldr	d0, [sp, #11552]                ; 8-byte Reload
	ldr	q1, [sp, #12928]                ; 16-byte Reload
	and.8b	v1, v0, v1
	str	q1, [sp, #12928]                ; 16-byte Spill
	fmov	x9, d16
	cmp	x9, #8
	str	q3, [sp, #6672]                 ; 16-byte Spill
	str	q6, [sp, #6656]                 ; 16-byte Spill
	str	q5, [sp, #6640]                 ; 16-byte Spill
	str	q7, [sp, #6624]                 ; 16-byte Spill
	b.gt	LBB0_816
; %bb.798:                              ; %direct.true736.lr.ph
                                        ;   in Loop: Header=BB0_797 Depth=2
	fmov	x9, d3
	add	x9, x9, x9, lsl #3
	fmov	d0, x9
	mov.d	x9, v3[1]
	add	x9, x9, x9, lsl #3
	mov.d	v0[1], x9
	fmov	x9, d6
	add	x9, x9, x9, lsl #3
	fmov	d1, x9
	mov.d	x9, v6[1]
	add	x9, x9, x9, lsl #3
	mov.d	v1[1], x9
	fmov	x9, d5
	add	x9, x9, x9, lsl #3
	mov.d	x10, v5[1]
	fmov	d4, x9
	add	x9, x10, x10, lsl #3
	mov.d	v4[1], x9
	fmov	x9, d7
	add	x9, x9, x9, lsl #3
	fmov	d5, x9
	mov.d	x9, v7[1]
	add	x9, x9, x9, lsl #3
	mov.d	v5[1], x9
	ldr	q13, [sp, #13248]               ; 16-byte Reload
	mov.16b	v23, v25
	ldr	q29, [sp, #13264]               ; 16-byte Reload
	b	LBB0_800
LBB0_799:                               ; %else2821
                                        ;   in Loop: Header=BB0_800 Depth=3
	ldr	q29, [sp, #13264]               ; 16-byte Reload
	cmge.2d	v17, v22, v29
	cmge.2d	v19, v19, v2
	uzp1.4s	v17, v19, v17
	ldr	q13, [sp, #13248]               ; 16-byte Reload
	cmge.2d	v18, v18, v13
	cmge.2d	v16, v16, v25
	uzp1.4s	v16, v16, v18
	uzp1.8h	v16, v16, v17
	and.16b	v16, v28, v16
	xtn.8b	v16, v16
	zip2.8b	v17, v6, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	ldr	q18, [sp, #12528]               ; 16-byte Reload
	bsl.16b	v17, v24, v18
	zip1.8b	v18, v6, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	ldr	q19, [sp, #12512]               ; 16-byte Reload
	bsl.16b	v18, v23, v19
	zip1.8b	v19, v16, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmge.4s	v19, v19, #0
	and.16b	v27, v19, v18
	zip2.8b	v16, v16, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmge.4s	v16, v16, #0
	and.16b	v19, v16, v17
	ldr	q24, [sp, #12896]               ; 16-byte Reload
	fadd.4s	v16, v24, v19
	ldr	q23, [sp, #12912]               ; 16-byte Reload
	fadd.4s	v17, v23, v27
	ldr	q22, [sp, #12928]               ; 16-byte Reload
	zip1.8b	v18, v22, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	str	q27, [sp, #12512]               ; 16-byte Spill
	bif.16b	v17, v27, v18
	zip2.8b	v18, v22, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	str	q19, [sp, #12528]               ; 16-byte Spill
	bif.16b	v16, v19, v18
	add.2d	v26, v26, v10
	ldr	q18, [sp, #13328]               ; 16-byte Reload
	add.2d	v19, v12, v18
	add.2d	v18, v21, v8
	add.2d	v15, v15, v20
	and.16b	v7, v31, v7
	and.16b	v3, v30, v3
	bit.16b	v24, v16, v3
	str	q24, [sp, #12896]               ; 16-byte Spill
	bit.16b	v23, v17, v7
	str	q23, [sp, #12912]               ; 16-byte Spill
	orr.8b	v22, v22, v6
	str	q22, [sp, #12928]               ; 16-byte Spill
	mov.16b	v16, v15
	fmov	x9, d16
	cmp	x9, #9
	mov.16b	v23, v25
	b.ge	LBB0_816
LBB0_800:                               ; %direct.true736
                                        ;   Parent Loop BB0_92 Depth=1
                                        ;     Parent Loop BB0_797 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov.16b	v9, v8
	sshll.2d	v3, v30, #0
	sshll.2d	v6, v31, #0
	mov.16b	v21, v18
	and.16b	v7, v14, v18
	mov.d	x9, v7[1]
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d7
	ldr	q7, [sp, #13232]                ; 16-byte Reload
	fmov	x11, d7
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d17, x10
	mov.d	v17[1], x9
	mov.16b	v12, v19
	and.16b	v3, v3, v19
	mov.d	x9, v3[1]
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d3
	ldr	q3, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d25, x10
	mov.d	v25[1], x9
	mov.16b	v8, v26
	and.16b	v3, v11, v26
	mov.d	x9, v3[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d3
	ldr	q3, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d26, x10
	mov.d	v26[1], x9
	mov.16b	v15, v16
	and.16b	v3, v6, v16
	mov.d	x9, v3[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d3
	ldr	q3, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	shl.2d	v16, v6, #3
	shl.2d	v18, v26, #3
	shl.2d	v19, v25, #3
	shl.2d	v22, v17, #3
	cmgt.2d	v3, v29, v22
	cmgt.2d	v7, v2, v19
	uzp1.4s	v3, v7, v3
	cmgt.2d	v7, v13, v18
	cmgt.2d	v23, v23, v16
	uzp1.4s	v7, v23, v7
	uzp1.8h	v23, v7, v3
	add.2d	v24, v6, v0
	and.16b	v6, v28, v23
	xtn.8b	v6, v6
	shl.8b	v23, v6, #7
	cmlt.8b	v23, v23, #0
	ldr	d27, [sp, #13344]               ; 8-byte Reload
	and.8b	v23, v23, v27
	addv.8b	b23, v23
	fmov	w9, s23
	shl.2d	v23, v24, #5
	ldr	q24, [sp, #12848]               ; 16-byte Reload
	orr.16b	v23, v23, v24
	ldr	q2, [sp, #12784]                ; 16-byte Reload
	add.2d	v27, v2, v23
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbz	w9, #0, LBB0_802
; %bb.801:                              ; %cond.load2775
                                        ;   in Loop: Header=BB0_800 Depth=3
	fmov	x10, d27
	ldr	s23, [x10]
LBB0_802:                               ; %else2779
                                        ;   in Loop: Header=BB0_800 Depth=3
	tbz	w9, #1, LBB0_804
; %bb.803:                              ; %cond.load2781
                                        ;   in Loop: Header=BB0_800 Depth=3
	mov.d	x10, v27[1]
	ld1.s	{ v23 }[1], [x10]
LBB0_804:                               ; %else2785
                                        ;   in Loop: Header=BB0_800 Depth=3
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	add.2d	v26, v26, v1
	shl.2d	v26, v26, #5
	ldr	q27, [sp, #12832]               ; 16-byte Reload
	orr.16b	v26, v26, v27
	ldr	q27, [sp, #12768]               ; 16-byte Reload
	add.2d	v26, v27, v26
	tbz	w9, #2, LBB0_806
; %bb.805:                              ; %cond.load2787
                                        ;   in Loop: Header=BB0_800 Depth=3
	fmov	x10, d26
	ld1.s	{ v23 }[2], [x10]
LBB0_806:                               ; %else2791
                                        ;   in Loop: Header=BB0_800 Depth=3
	tbz	w9, #3, LBB0_808
; %bb.807:                              ; %cond.load2793
                                        ;   in Loop: Header=BB0_800 Depth=3
	mov.d	x10, v26[1]
	ld1.s	{ v23 }[3], [x10]
LBB0_808:                               ; %else2797
                                        ;   in Loop: Header=BB0_800 Depth=3
	add.2d	v25, v25, v4
	shl.2d	v25, v25, #5
	ldr	q26, [sp, #12816]               ; 16-byte Reload
	orr.16b	v25, v25, v26
	ldr	q26, [sp, #12752]               ; 16-byte Reload
	add.2d	v25, v26, v25
	tbz	w9, #4, LBB0_810
; %bb.809:                              ; %cond.load2799
                                        ;   in Loop: Header=BB0_800 Depth=3
	fmov	x10, d25
	ld1.s	{ v24 }[0], [x10]
LBB0_810:                               ; %else2803
                                        ;   in Loop: Header=BB0_800 Depth=3
	tbz	w9, #5, LBB0_812
; %bb.811:                              ; %cond.load2805
                                        ;   in Loop: Header=BB0_800 Depth=3
	mov.d	x10, v25[1]
	ld1.s	{ v24 }[1], [x10]
LBB0_812:                               ; %else2809
                                        ;   in Loop: Header=BB0_800 Depth=3
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	add.2d	v17, v17, v5
	shl.2d	v17, v17, #5
	ldr	q26, [sp, #12800]               ; 16-byte Reload
	orr.16b	v17, v17, v26
	ldr	q26, [sp, #12864]               ; 16-byte Reload
	add.2d	v17, v26, v17
	tbz	w9, #6, LBB0_814
; %bb.813:                              ; %cond.load2811
                                        ;   in Loop: Header=BB0_800 Depth=3
	fmov	x10, d17
	ld1.s	{ v24 }[2], [x10]
LBB0_814:                               ; %else2815
                                        ;   in Loop: Header=BB0_800 Depth=3
	mov.16b	v26, v8
	mov.16b	v8, v9
	tbz	w9, #7, LBB0_799
; %bb.815:                              ; %cond.load2817
                                        ;   in Loop: Header=BB0_800 Depth=3
	mov.d	x9, v17[1]
	ld1.s	{ v24 }[3], [x9]
	b	LBB0_799
LBB0_816:                               ; %direct.false737
                                        ;   in Loop: Header=BB0_797 Depth=2
	mov.16b	v27, v26
	str	q16, [sp, #6608]                ; 16-byte Spill
	str	q18, [sp, #6688]                ; 16-byte Spill
	str	q19, [sp, #6704]                ; 16-byte Spill
	ldr	q23, [sp, #12912]               ; 16-byte Reload
	str	q23, [x13, #1984]
	ldr	q24, [sp, #12896]               ; 16-byte Reload
	str	q24, [x13, #2000]
	ldr	x10, [sp, #4416]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3184
	ldr	s0, [x9, x10]
	ldr	w9, [sp, #7868]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q23, [x13, #1952]
	str	q24, [x13, #1968]
	ldr	x11, [sp, #4400]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3152
	ldr	s4, [x9, x11]
	ldr	q21, [sp, #12928]               ; 16-byte Reload
	movi.8b	v1, #1
	and.8b	v1, v21, v1
	ushll.8h	v3, v1, #0
	ushll.4s	v1, v3, #0
	ushll2.4s	v3, v3, #0
	str	q3, [x13, #1520]
	str	q1, [x13, #1504]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2704
	ldr	w9, [x9, x10]
	movi.2d	v20, #0000000000000000
	fcsel	s0, s0, s20, ne
	csel	w9, w9, wzr, ne
	str	q23, [x13, #1920]
	str	q24, [x13, #1936]
	ldr	x12, [sp, #4384]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3120
	ldr	s5, [x10, x12]
	ldr	w10, [sp, #7864]                ; 4-byte Reload
	tst	w10, #0x1
	str	q3, [x13, #1552]
	str	q1, [x13, #1536]
	fmov	s6, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2736
	ldr	w9, [x9, x11]
	fcsel	s7, s4, s20, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7860]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s5, s5, s20, ne
	str	q23, [x13, #1888]
	str	q24, [x13, #1904]
	ldr	x11, [sp, #4368]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3088
	ldr	s4, [x10, x11]
	str	q3, [x13, #1584]
	str	q1, [x13, #1568]
	mov.s	v6[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2768
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7856]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s16, s4, s20, ne
	str	q23, [x13, #1856]
	str	q24, [x13, #1872]
	ldr	x12, [sp, #4360]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3056
	ldr	s4, [x10, x12]
	str	q3, [x13, #1616]
	mov.s	v6[2], w9
	str	q1, [x13, #1600]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2800
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7852]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s4, s4, s20, ne
	str	q23, [x13, #1824]
	str	q24, [x13, #1840]
	ldr	x11, [sp, #4344]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3024
	ldr	s17, [x10, x11]
	str	q3, [x13, #1648]
	str	q1, [x13, #1632]
	mov.s	v6[3], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2832
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7848]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s17, s17, s20, ne
	str	q23, [x13, #1792]
	str	q24, [x13, #1808]
	ldr	x12, [sp, #4328]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2992
	ldr	s18, [x10, x12]
	str	q3, [x13, #1680]
	str	q1, [x13, #1664]
	fmov	s19, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2864
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7844]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s18, s18, s20, ne
	str	q23, [x13, #1760]
	str	q24, [x13, #1776]
	ldr	x11, [sp, #4312]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2960
	ldr	s22, [x10, x11]
	str	q3, [x13, #1712]
	str	q1, [x13, #1696]
	mov.s	v19[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2896
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7840]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s22, s22, s20, ne
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v18[0]
	mov.s	v4[3], v22[0]
	mov.s	v0[1], v7[0]
	mov.s	v0[2], v5[0]
	mov.s	v0[3], v16[0]
	fadd.4s	v5, v23, v0
	str	q3, [x13, #1744]
	mov.s	v19[2], w9
	str	q1, [x13, #1728]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2928
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	mov.s	v19[3], w9
	fadd.4s	v1, v24, v4
	cmtst.4s	v3, v19, v19
	cmtst.4s	v7, v6, v6
	uzp1.8h	v3, v7, v3
	xtn.8b	v7, v3
	cmeq.4s	v3, v6, #0
	cmeq.4s	v6, v19, #0
	bsl.16b	v6, v24, v1
	mov.16b	v1, v3
	bsl.16b	v1, v23, v5
	zip1.8b	v3, v21, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bif.16b	v1, v0, v3
	zip2.8b	v0, v21, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	mov.16b	v3, v0
	bsl.16b	v3, v6, v4
	orr.8b	v0, v21, v7
	str	q3, [x13, #1488]
	str	q1, [x13, #1472]
	ldr	x10, [sp, #4304]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2672
	ldr	s4, [x9, x10]
	ldr	w9, [sp, #7836]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s4, s4, s20, ne
	str	q3, [x13, #1424]
	str	q1, [x13, #1408]
	ldr	x11, [sp, #4288]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2608
	ldr	s17, [x9, x11]
	zip1.8b	v5, v0, v0
	ushll.4s	v6, v5, #0
	movi.4s	v26, #1
	and.16b	v5, v6, v26
	zip2.8b	v7, v0, v0
	ushll.4s	v16, v7, #0
	and.16b	v7, v16, v26
	str	q7, [x13, #1456]
	str	q5, [x13, #1440]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2640
	ldr	w9, [x9, x10]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7832]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s17, s17, s20, ne
	str	q3, [x13, #1360]
	str	q1, [x13, #1344]
	ldr	x12, [sp, #4272]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2544
	ldr	s18, [x10, x12]
	str	q7, [x13, #1392]
	str	q5, [x13, #1376]
	fmov	s19, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2576
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7828]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s18, s18, s20, ne
	str	q3, [x13, #1296]
	str	q1, [x13, #1280]
	ldr	x11, [sp, #4256]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2480
	ldr	s22, [x10, x11]
	str	q7, [x13, #1328]
	str	q5, [x13, #1312]
	mov.s	v19[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2512
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7824]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s22, s22, s20, ne
	str	q3, [x13, #1232]
	str	q1, [x13, #1216]
	ldr	x12, [sp, #4248]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2416
	ldr	s23, [x10, x12]
	str	q7, [x13, #1264]
	str	q5, [x13, #1248]
	mov.s	v19[2], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2448
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7820]                ; 4-byte Reload
	tst	w10, #0x1
	str	q3, [x13, #1168]
	str	q1, [x13, #1152]
	ldr	x11, [sp, #4232]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2352
	ldr	s24, [x10, x11]
	str	q7, [x13, #1200]
	str	q5, [x13, #1184]
	mov.s	v19[3], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2384
	ldr	w9, [x9, x12]
	fcsel	s23, s23, s20, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7816]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s24, s24, s20, ne
	str	q3, [x13, #1104]
	str	q1, [x13, #1088]
	ldr	x12, [sp, #4216]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2288
	ldr	s25, [x10, x12]
	str	q7, [x13, #1136]
	str	q5, [x13, #1120]
	mov.s	v23[1], v24[0]
	fmov	s24, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2320
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7812]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s25, s25, s20, ne
	str	q3, [x13, #1040]
	str	q1, [x13, #1024]
	mov.s	v23[2], v25[0]
	ldr	x11, [sp, #4176]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2224
	ldr	s25, [x10, x11]
	str	q7, [x13, #1072]
	str	q5, [x13, #1056]
	mov.s	v24[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2256
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7808]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s25, s25, s20, ne
	mov.s	v23[3], v25[0]
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v18[0]
	mov.s	v4[3], v22[0]
	fadd.4s	v17, v1, v4
	fadd.4s	v18, v3, v23
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	shl.4s	v6, v6, #31
	stp	q5, q7, [x13, #992]
	mov.s	v24[2], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2192
	ldr	w9, [x9, x11]
	cmlt.4s	v5, v6, #0
	csel	w9, w9, wzr, ne
	mov.s	v24[3], w9
	cmtst.4s	v6, v24, v24
	cmtst.4s	v7, v19, v19
	uzp1.8h	v6, v7, v6
	xtn.8b	v6, v6
	cmeq.4s	v7, v19, #0
	cmeq.4s	v19, v24, #0
	bif.16b	v3, v18, v19
	bif.16b	v1, v17, v7
	bif.16b	v1, v4, v5
	bif.16b	v3, v23, v16
	stp	q1, q3, [x13, #960]
	ldr	x10, [sp, #4168]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2160
	ldr	s3, [x9, x10]
	orr.8b	v0, v0, v6
	ldr	w9, [sp, #7804]                 ; 4-byte Reload
	tst	w9, #0x1
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	and.16b	v5, v4, v26
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	and.16b	v0, v0, v26
	stp	q5, q0, [x13, #928]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2128
	ldr	w9, [x9, x10]
	csel	w9, w9, wzr, ne
	stp	q5, q0, [x13, #896]
	fmov	s6, w9
	ldr	x9, [sp, #4152]                 ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2096
	ldr	w9, [x10, x9, lsl #2]
	fcsel	s3, s3, s20, ne
	ldr	w10, [sp, #7800]                ; 4-byte Reload
	tst	w10, #0x1
	csel	w9, w9, wzr, ne
	mov.s	v6[1], w9
	stp	q5, q0, [x13, #864]
	ldr	x9, [sp, #4112]                 ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2064
	ldr	w9, [x10, x9, lsl #2]
	ldr	w10, [sp, #7796]                ; 4-byte Reload
	tst	w10, #0x1
	csel	w9, w9, wzr, ne
	stp	q5, q0, [x13, #832]
	mov.s	v6[2], w9
	ldr	x9, [sp, #4096]                 ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2032
	ldr	w9, [x10, x9, lsl #2]
	ldr	w10, [sp, #7792]                ; 4-byte Reload
	tst	w10, #0x1
	csel	w9, w9, wzr, ne
	mov.s	v6[3], w9
	ldr	q0, [sp, #7936]                 ; 16-byte Reload
	fmov	w9, s0
	fadd.4s	v0, v1, v3
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	cmeq.4s	v5, v6, #0
	bit.16b	v0, v1, v5
	bif.16b	v0, v3, v4
	tst	w16, #0x1
	fcsel	s1, s0, s20, ne
	and	w10, w17, w16
	tst	w10, #0x1
	fcsel	s3, s0, s20, ne
	and	w10, w0, w16
	tst	w10, #0x1
	fcsel	s4, s0, s20, ne
	and	w10, w1, w16
	tst	w10, #0x1
	fcsel	s5, s0, s20, ne
	and	w10, w2, w16
	tst	w10, #0x1
	fcsel	s6, s0, s20, ne
	and	w10, w3, w16
	tst	w10, #0x1
	fcsel	s7, s0, s20, ne
	and	w10, w4, w16
	tst	w10, #0x1
	fcsel	s16, s0, s20, ne
	and	w10, w5, w16
	tst	w10, #0x1
	fcsel	s0, s0, s20, ne
	mov.s	v1[1], v3[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v5[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v0[0]
	stp	q1, q6, [x13, #672]
	ldr	x10, [sp, #4064]                ; 8-byte Reload
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1872
	ldr	s0, [x11, x10, lsl #2]
	fadd	s0, s0, s20
	ldr	q4, [sp, #8512]                 ; 16-byte Reload
	shl.2d	v1, v4, #5
	ldr	q3, [sp, #5904]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	dup.4s	v0, v0[0]
	ldr	q3, [sp, #5840]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #0, LBB0_818
; %bb.817:                              ; %cond.store2824
                                        ;   in Loop: Header=BB0_797 Depth=2
	fmov	x10, d1
	str	s0, [x10]
LBB0_818:                               ; %else2827
                                        ;   in Loop: Header=BB0_797 Depth=2
	and	w9, w9, #0xff
	ldr	q15, [sp, #13328]               ; 16-byte Reload
	ldr	q6, [sp, #8496]                 ; 16-byte Reload
	ldr	q5, [sp, #8480]                 ; 16-byte Reload
	ldr	q13, [sp, #10976]               ; 16-byte Reload
	tbz	w9, #1, LBB0_820
; %bb.819:                              ; %cond.store2828
                                        ;   in Loop: Header=BB0_797 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
LBB0_820:                               ; %else2831
                                        ;   in Loop: Header=BB0_797 Depth=2
	shl.2d	v1, v6, #5
	ldr	q3, [sp, #5888]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5824]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q29, [sp, #11536]               ; 16-byte Reload
	mov.16b	v26, v27
	ldr	q20, [sp, #13312]               ; 16-byte Reload
	tbnz	w9, #2, LBB0_826
; %bb.821:                              ; %else2835
                                        ;   in Loop: Header=BB0_797 Depth=2
	ldr	d12, [sp, #11576]               ; 8-byte Reload
	ldr	q23, [sp, #4752]                ; 16-byte Reload
	ldr	q24, [sp, #4736]                ; 16-byte Reload
	tbnz	w9, #3, LBB0_827
LBB0_822:                               ; %else2839
                                        ;   in Loop: Header=BB0_797 Depth=2
	shl.2d	v1, v5, #5
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #4, LBB0_828
LBB0_823:                               ; %else2843
                                        ;   in Loop: Header=BB0_797 Depth=2
	tbnz	w9, #5, LBB0_829
LBB0_824:                               ; %else2847
                                        ;   in Loop: Header=BB0_797 Depth=2
	shl.2d	v1, v29, #5
	ldr	q3, [sp, #5856]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5920]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w9, #6, LBB0_830
LBB0_825:                               ; %else2851
                                        ;   in Loop: Header=BB0_797 Depth=2
	tbz	w9, #7, LBB0_796
	b	LBB0_831
LBB0_826:                               ; %cond.store2832
                                        ;   in Loop: Header=BB0_797 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	ldr	d12, [sp, #11576]               ; 8-byte Reload
	ldr	q23, [sp, #4752]                ; 16-byte Reload
	ldr	q24, [sp, #4736]                ; 16-byte Reload
	tbz	w9, #3, LBB0_822
LBB0_827:                               ; %cond.store2836
                                        ;   in Loop: Header=BB0_797 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[3], [x10]
	shl.2d	v1, v5, #5
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_823
LBB0_828:                               ; %cond.store2840
                                        ;   in Loop: Header=BB0_797 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	tbz	w9, #5, LBB0_824
LBB0_829:                               ; %cond.store2844
                                        ;   in Loop: Header=BB0_797 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v29, #5
	ldr	q3, [sp, #5856]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5920]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_825
LBB0_830:                               ; %cond.store2848
                                        ;   in Loop: Header=BB0_797 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_796
LBB0_831:                               ; %cond.store2852
                                        ;   in Loop: Header=BB0_797 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_796
LBB0_832:                               ;   in Loop: Header=BB0_92 Depth=1
	ldr	q23, [sp, #4752]                ; 16-byte Reload
	ldr	q24, [sp, #4736]                ; 16-byte Reload
	ldr	q15, [sp, #13328]               ; 16-byte Reload
	ldr	q29, [sp, #11536]               ; 16-byte Reload
LBB0_833:                               ; %direct.false732
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q5, [sp, #8480]                 ; 16-byte Spill
	str	q6, [sp, #8496]                 ; 16-byte Spill
	str	q4, [sp, #8512]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #256]                  ; 16-byte Reload
	ldr	q4, [sp, #5808]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #5808]                 ; 16-byte Spill
	ldr	q4, [sp, #5712]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #5712]                 ; 16-byte Spill
	ldr	q4, [sp, #5696]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #5696]                 ; 16-byte Spill
	ldr	q4, [sp, #5728]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #5728]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #5744]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #5744]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #5776]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #5776]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #5760]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #5760]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #5792]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #5792]                 ; 16-byte Spill
	ldr	q3, [sp, #10016]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #10016]                ; 16-byte Spill
	bic.16b	v23, v23, v11
	bic.16b	v24, v24, v1
	ldr	q1, [sp, #10000]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10000]                ; 16-byte Spill
	fmov	x8, d1
	cmp	x8, #1
	b.lt	LBB0_1387
; %bb.834:                              ;   in Loop: Header=BB0_92 Depth=1
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #1616
	add	x30, sp, #3, lsl #12            ; =12288
	add	x30, x30, #1648
LBB0_835:                               ; %direct.false766
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q24, [sp, #4736]                ; 16-byte Spill
	str	q23, [sp, #4752]                ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #240]                  ; 16-byte Reload
	ldr	q4, [sp, #8384]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8384]                 ; 16-byte Spill
	ldr	q4, [sp, #8416]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8416]                 ; 16-byte Spill
	ldr	q4, [sp, #8400]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8400]                 ; 16-byte Spill
	ldr	q4, [sp, #8432]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8432]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #8448]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8448]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #8352]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8352]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #8464]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8464]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #8368]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8368]                 ; 16-byte Spill
	ldr	q3, [sp, #11488]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #11488]                ; 16-byte Spill
	ldr	q3, [sp, #11520]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #11520]                ; 16-byte Spill
	ldr	q3, [sp, #11504]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #11504]                ; 16-byte Spill
	ldr	q1, [sp, #1104]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	fmov	x8, d1
	cmp	x8, #1
	str	q26, [sp, #11232]               ; 16-byte Spill
	b.le	LBB0_840
; %bb.836:                              ;   in Loop: Header=BB0_92 Depth=1
	ldr	q6, [sp, #11616]                ; 16-byte Reload
LBB0_837:                               ; %direct.false781
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q29, [sp, #11536]               ; 16-byte Spill
	mov.16b	v9, v8
	str	q1, [sp, #1104]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #224]                  ; 16-byte Reload
	ldr	q4, [sp, #8320]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8320]                 ; 16-byte Spill
	ldr	q4, [sp, #8224]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8224]                 ; 16-byte Spill
	ldr	q4, [sp, #8336]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8336]                 ; 16-byte Spill
	ldr	q4, [sp, #8240]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8240]                 ; 16-byte Spill
	ldr	q3, [sp, #4688]                 ; 16-byte Reload
	ldr	q4, [sp, #8256]                 ; 16-byte Reload
	bit.16b	v4, v3, v14
	str	q4, [sp, #8256]                 ; 16-byte Spill
	ldr	q3, [sp, #4672]                 ; 16-byte Reload
	ldr	q4, [sp, #8288]                 ; 16-byte Reload
	bit.16b	v4, v3, v11
	str	q4, [sp, #8288]                 ; 16-byte Spill
	ldr	q3, [sp, #4720]                 ; 16-byte Reload
	ldr	q4, [sp, #8272]                 ; 16-byte Reload
	bit.16b	v4, v3, v1
	str	q4, [sp, #8272]                 ; 16-byte Spill
	ldr	q3, [sp, #4704]                 ; 16-byte Reload
	ldr	q4, [sp, #8304]                 ; 16-byte Reload
	bit.16b	v4, v3, v0
	str	q4, [sp, #8304]                 ; 16-byte Spill
	ldr	q23, [sp, #8032]                ; 16-byte Reload
	bic.16b	v23, v23, v14
	ldr	q18, [sp, #8064]                ; 16-byte Reload
	mov.16b	v8, v11
	bic.16b	v18, v18, v11
	ldr	q19, [sp, #8048]                ; 16-byte Reload
	bic.16b	v19, v19, v1
	ldr	q17, [sp, #8080]                ; 16-byte Reload
	bic.16b	v17, v17, v0
	fmov	x8, d17
	cmp	x8, #1
	b.gt	LBB0_957
; %bb.838:                              ; %direct.true801.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldp	q27, q24, [sp, #800]            ; 32-byte Folded Reload
	mov.16b	v11, v14
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #1344
	add	x30, sp, #3, lsl #12            ; =12288
	add	x30, x30, #1376
	b	LBB0_889
LBB0_839:                               ; %else3117
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q0, [sp, #11520]                ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #11520]                ; 16-byte Spill
	ldr	q0, [sp, #11504]                ; 16-byte Reload
	add.2d	v0, v0, v15
	str	q0, [sp, #11504]                ; 16-byte Spill
	ldr	q0, [sp, #11488]                ; 16-byte Reload
	add.2d	v0, v0, v8
	str	q0, [sp, #11488]                ; 16-byte Spill
	add.2d	v1, v27, v20
	fmov	x8, d1
	cmp	x8, #2
	b.ge	LBB0_837
LBB0_840:                               ; %direct.true780
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v31, #0
	mov.16b	v27, v1
	and.16b	v0, v0, v1
	mov.d	x8, v0[1]
	ldr	x10, [sp, #11704]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d0
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fmov	x10, d0
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d6, x9
	mov.d	v6[1], x8
	shl.2d	v0, v6, #5
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9728]                 ; 16-byte Reload
	add.2d	v3, v1, v0
	ldr	d0, [sp, #12344]                ; 8-byte Reload
	fmov	w8, s0
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_842
; %bb.841:                              ; %cond.load2988
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x9, d3
	ldr	s1, [x9]
LBB0_842:                               ; %else2992
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w8, #1, LBB0_844
; %bb.843:                              ; %cond.load2994
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x9, v3[1]
	ld1.s	{ v1 }[1], [x9]
LBB0_844:                               ; %else2998
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q3, [sp, #11520]                ; 16-byte Reload
	and.16b	v3, v11, v3
	mov.d	x9, v3[1]
	sdiv	x10, x9, x25
	msub	x9, x10, x25, x9
	fmov	x10, d3
	ldr	q3, [sp, #11648]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d3, x10
	mov.d	v3[1], x9
	shl.2d	v4, v3, #5
	ldr	q5, [sp, #12272]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #9760]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w8, #2, LBB0_846
; %bb.845:                              ; %cond.load3000
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x9, d4
	ld1.s	{ v1 }[2], [x9]
LBB0_846:                               ; %else3004
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w8, #3, LBB0_848
; %bb.847:                              ; %cond.load3006
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v1 }[3], [x9]
LBB0_848:                               ; %else3010
                                        ;   in Loop: Header=BB0_840 Depth=2
	sshll.2d	v4, v30, #0
	ldr	q5, [sp, #11504]                ; 16-byte Reload
	and.16b	v4, v4, v5
	mov.d	x9, v4[1]
	sdiv	x10, x9, x26
	msub	x9, x10, x26, x9
	fmov	x10, d4
	ldr	q4, [sp, #11664]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d7, x10
	mov.d	v7[1], x9
	shl.2d	v4, v7, #5
	ldr	q5, [sp, #12320]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #9744]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w8, #4, LBB0_850
; %bb.849:                              ; %cond.load3012
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x9, d4
	ld1.s	{ v0 }[0], [x9]
LBB0_850:                               ; %else3016
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w8, #5, LBB0_852
; %bb.851:                              ; %cond.load3018
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_852:                               ; %else3022
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q4, [sp, #11488]                ; 16-byte Reload
	and.16b	v4, v14, v4
	mov.d	x9, v4[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d4
	ldr	q4, [sp, #11632]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d16, x10
	mov.d	v16[1], x9
	shl.2d	v4, v16, #5
	ldr	q5, [sp, #12288]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #9776]                 ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w8, #6, LBB0_854
; %bb.853:                              ; %cond.load3024
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x9, d4
	ld1.s	{ v0 }[2], [x9]
LBB0_854:                               ; %else3028
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w8, #7, LBB0_856
; %bb.855:                              ; %cond.load3030
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x8, v4[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_856:                               ; %else3034
                                        ;   in Loop: Header=BB0_840 Depth=2
	sshll.2d	v4, v31, #0
	sshll.2d	v5, v30, #0
	and.16b	v18, v14, v16
	and.16b	v16, v5, v7
	and.16b	v6, v4, v6
	mov.d	x8, v6[1]
	ldr	q7, [sp, #12992]                ; 16-byte Reload
	mov.d	x14, v7[1]
	sdiv	x20, x8, x14
	fmov	x8, d6
	fmov	x9, d7
	sdiv	x8, x8, x9
	mul	x10, x8, x9
	fmov	d19, x8
	mov.d	v19[1], x20
	mov.d	x8, v16[1]
	and.16b	v3, v11, v3
	ldr	q7, [sp, #13008]                ; 16-byte Reload
	mov.d	x11, v7[1]
	sdiv	x15, x8, x11
	fmov	x12, d16
	fmov	x21, d7
	mov.d	x8, v3[1]
	ldr	q7, [sp, #13024]                ; 16-byte Reload
	mov.d	x6, v7[1]
	sdiv	x7, x8, x6
	fmov	x8, d3
	fmov	x22, d7
	sdiv	x19, x8, x22
	mov.d	x8, v18[1]
	ldr	q7, [sp, #13040]                ; 16-byte Reload
	mov.d	x23, v7[1]
	sdiv	x8, x8, x23
	fmov	x9, d18
	fmov	x24, d7
	sdiv	x9, x9, x24
	mul	x23, x8, x23
	mul	x24, x9, x24
	fmov	d22, x24
	mov.d	v22[1], x23
	mul	x6, x7, x6
	mul	x22, x19, x22
	fmov	d17, x22
	mov.d	v17[1], x6
	mul	x11, x15, x11
	sdiv	x6, x12, x21
	mul	x12, x6, x21
	fmov	d23, x12
	mov.d	v23[1], x11
	mul	x11, x20, x14
	fmov	d7, x10
	mov.d	v7[1], x11
	sub.2d	v7, v6, v7
	sub.2d	v16, v16, v23
	sub.2d	v17, v3, v17
	sub.2d	v18, v18, v22
	ldr	q3, [sp, #13088]                ; 16-byte Reload
	cmeq.2d	v3, v3, v18
	ldr	q6, [sp, #13136]                ; 16-byte Reload
	cmeq.2d	v6, v6, v16
	uzp1.4s	v3, v6, v3
	ldr	q6, [sp, #13104]                ; 16-byte Reload
	cmeq.2d	v6, v6, v17
	ldr	q22, [sp, #13120]               ; 16-byte Reload
	cmeq.2d	v22, v22, v7
	uzp1.4s	v6, v22, v6
	uzp1.8h	v22, v6, v3
	and.16b	v3, v28, v22
	xtn.8b	v3, v3
	shl.8b	v6, v3, #7
	cmlt.8b	v6, v6, #0
	ldr	d21, [sp, #13344]               ; 8-byte Reload
	and.8b	v6, v6, v21
	addv.8b	b6, v6
	fmov	w14, s6
	shl.2d	v6, v19, #5
	ldr	q19, [sp, #6304]                ; 16-byte Reload
	orr.16b	v6, v6, v19
	ldr	q19, [sp, #6240]                ; 16-byte Reload
	add.2d	v23, v19, v6
	movi.2d	v6, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbz	w14, #0, LBB0_858
; %bb.857:                              ; %cond.load3037
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x10, d23
	ldr	s6, [x10]
LBB0_858:                               ; %else3041
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w14, #1, LBB0_860
; %bb.859:                              ; %cond.load3043
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v6 }[1], [x10]
LBB0_860:                               ; %else3047
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	d23, x19
	mov.d	v23[1], x7
	shl.2d	v23, v23, #5
	ldr	q26, [sp, #6288]                ; 16-byte Reload
	orr.16b	v23, v23, v26
	ldr	q26, [sp, #6224]                ; 16-byte Reload
	add.2d	v23, v26, v23
	tbz	w14, #2, LBB0_862
; %bb.861:                              ; %cond.load3049
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x10, d23
	ld1.s	{ v6 }[2], [x10]
LBB0_862:                               ; %else3053
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w14, #3, LBB0_864
; %bb.863:                              ; %cond.load3055
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v6 }[3], [x10]
LBB0_864:                               ; %else3059
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	d23, x6
	mov.d	v23[1], x15
	shl.2d	v23, v23, #5
	ldr	q26, [sp, #6272]                ; 16-byte Reload
	orr.16b	v23, v23, v26
	ldr	q26, [sp, #6208]                ; 16-byte Reload
	add.2d	v23, v26, v23
	tbz	w14, #4, LBB0_866
; %bb.865:                              ; %cond.load3061
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x10, d23
	ld1.s	{ v19 }[0], [x10]
LBB0_866:                               ; %else3065
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w14, #5, LBB0_868
; %bb.867:                              ; %cond.load3067
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v19 }[1], [x10]
LBB0_868:                               ; %else3071
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	d23, x9
	mov.d	v23[1], x8
	shl.2d	v23, v23, #5
	ldr	q26, [sp, #6256]                ; 16-byte Reload
	orr.16b	v23, v23, v26
	ldr	q26, [sp, #6320]                ; 16-byte Reload
	add.2d	v23, v26, v23
	tbz	w14, #6, LBB0_870
; %bb.869:                              ; %cond.load3073
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x8, d23
	ld1.s	{ v19 }[2], [x8]
LBB0_870:                               ; %else3077
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q26, [sp, #11232]               ; 16-byte Reload
	ldr	q13, [sp, #4192]                ; 16-byte Reload
	ldr	q24, [sp, #10736]               ; 16-byte Reload
	bif.16b	v1, v24, v13
	ldr	q13, [sp, #4048]                ; 16-byte Reload
	and.16b	v1, v13, v1
	str	q1, [sp, #10736]                ; 16-byte Spill
	ldr	q1, [sp, #10672]                ; 16-byte Reload
	bit.16b	v1, v18, v14
	str	q1, [sp, #10672]                ; 16-byte Spill
	ldr	q1, [sp, #10704]                ; 16-byte Reload
	bit.16b	v1, v17, v11
	str	q1, [sp, #10704]                ; 16-byte Spill
	ldr	q1, [sp, #10688]                ; 16-byte Reload
	bit.16b	v1, v16, v5
	str	q1, [sp, #10688]                ; 16-byte Spill
	ldr	q1, [sp, #10720]                ; 16-byte Reload
	bit.16b	v1, v7, v4
	str	q1, [sp, #10720]                ; 16-byte Spill
	bic.16b	v1, v28, v22
	xtn.8b	v1, v1
	tbz	w14, #7, LBB0_872
; %bb.871:                              ; %cond.load3079
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x8, v23[1]
	ld1.s	{ v19 }[3], [x8]
LBB0_872:                               ; %else3083
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q15, [sp, #13328]               ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q13, [sp, #10976]               ; 16-byte Reload
	zip2.8b	v4, v3, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #6560]                 ; 16-byte Reload
	bsl.16b	v4, v19, v5
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q5, [sp, #6576]                 ; 16-byte Reload
	bsl.16b	v3, v6, v5
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v17, v5, v3
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v18, v1, v4
	ldr	q1, [sp, #10672]                ; 16-byte Reload
	xtn.2s	v1, v1
	ldr	q3, [sp, #10688]                ; 16-byte Reload
	xtn.2s	v5, v3
	ldr	q3, [sp, #10704]                ; 16-byte Reload
	xtn.2s	v6, v3
	ldr	q3, [sp, #10720]                ; 16-byte Reload
	xtn.2s	v3, v3
	mov.s	w8, v3[1]
	fmov	w9, s3
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldr	q3, [sp, #13168]                ; 16-byte Reload
	str	d3, [sp, #13896]
	ldrb	w11, [x11]
	and	w11, w16, w11
	stp	q17, q18, [x13, #416]
	ldr	s3, [x28, x9, lsl #2]
	tst	w10, w11
	movi.2d	v19, #0000000000000000
	fcsel	s3, s3, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w17, w8
	stp	q17, q18, [x13, #448]
	ldr	s4, [x30, x10, lsl #2]
	tst	w9, w8
	fcsel	s4, s4, s19, ne
	mov.s	w8, v6[1]
	fmov	w9, s6
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	stp	q17, q18, [x13, #480]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1680
	ldr	s6, [x12, x9, lsl #2]
	and	w9, w0, w11
	tst	w10, w9
	fcsel	s6, s6, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w1, w8
	stp	q17, q18, [x13, #512]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1712
	ldr	s7, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	w8, v5[1]
	fcsel	s16, s7, s19, ne
	fmov	w9, s5
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w2, w11
	stp	q17, q18, [x13, #544]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1744
	ldr	s5, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s5, s5, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w3, w8
	stp	q17, q18, [x13, #576]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1776
	ldr	s7, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s7, s7, s19, ne
	mov.s	w8, v1[1]
	fmov	w9, s1
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w4, w11
	stp	q17, q18, [x13, #608]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1808
	ldr	s1, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s1, s1, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w5, w8
	str	q18, [sp, #6560]                ; 16-byte Spill
	str	q18, [x13, #656]
	str	q17, [sp, #6576]                ; 16-byte Spill
	str	q17, [x13, #640]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1840
	ldr	s17, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v6[0]
	mov.s	v3[3], v16[0]
	fcsel	s4, s17, s19, ne
	ldr	q6, [sp, #10736]                ; 16-byte Reload
	fmul.4s	v3, v6, v3
	shl.2d	v6, v27, #5
	ldr	q16, [sp, #8368]                ; 16-byte Reload
	orr.16b	v6, v6, v16
	ldr	q16, [sp, #8432]                ; 16-byte Reload
	add.2d	v6, v16, v6
	ldr	d16, [sp, #12344]               ; 8-byte Reload
	fmov	w8, s16
	tbz	w8, #0, LBB0_874
; %bb.873:                              ; %cond.store3086
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x9, d6
	str	s3, [x9]
LBB0_874:                               ; %else3089
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w8, #1, LBB0_876
; %bb.875:                              ; %cond.store3090
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v3 }[1], [x9]
LBB0_876:                               ; %else3093
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q6, [sp, #11520]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q16, [sp, #8352]                ; 16-byte Reload
	orr.16b	v6, v6, v16
	ldr	q16, [sp, #8416]                ; 16-byte Reload
	add.2d	v6, v16, v6
	tbz	w8, #2, LBB0_878
; %bb.877:                              ; %cond.store3094
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x9, d6
	st1.s	{ v3 }[2], [x9]
LBB0_878:                               ; %else3097
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w8, #3, LBB0_880
; %bb.879:                              ; %cond.store3098
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v3 }[3], [x9]
LBB0_880:                               ; %else3101
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q3, [sp, #4128]                 ; 16-byte Reload
	ldr	q6, [sp, #6592]                 ; 16-byte Reload
	bif.16b	v0, v6, v3
	ldr	q3, [sp, #4080]                 ; 16-byte Reload
	and.16b	v0, v3, v0
	mov.s	v5[1], v7[0]
	mov.s	v5[2], v1[0]
	mov.s	v5[3], v4[0]
	str	q0, [sp, #6592]                 ; 16-byte Spill
	fmul.4s	v0, v0, v5
	ldr	q1, [sp, #11504]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8400]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w8, #4, LBB0_882
; %bb.881:                              ; %cond.store3102
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x9, d1
	str	s0, [x9]
LBB0_882:                               ; %else3105
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #5, LBB0_884
; %bb.883:                              ; %cond.store3106
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
LBB0_884:                               ; %else3109
                                        ;   in Loop: Header=BB0_840 Depth=2
	ldr	q1, [sp, #11488]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #8448]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8384]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w8, #6, LBB0_886
; %bb.885:                              ; %cond.store3110
                                        ;   in Loop: Header=BB0_840 Depth=2
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
LBB0_886:                               ; %else3113
                                        ;   in Loop: Header=BB0_840 Depth=2
	tbz	w8, #7, LBB0_839
; %bb.887:                              ; %cond.store3114
                                        ;   in Loop: Header=BB0_840 Depth=2
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
	b	LBB0_839
LBB0_888:                               ; %else3297
                                        ;   in Loop: Header=BB0_889 Depth=2
	add.2d	v18, v18, v10
	add.2d	v19, v19, v15
	add.2d	v23, v23, v9
	add.2d	v17, v17, v20
	fmov	x8, d17
	cmp	x8, #2
	b.ge	LBB0_958
LBB0_889:                               ; %direct.true801
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_908 Depth 3
	shl.2d	v1, v17, #5
	ldr	q0, [sp, #8368]                 ; 16-byte Reload
	str	q1, [sp, #11872]                ; 16-byte Spill
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8432]                 ; 16-byte Reload
	add.2d	v3, v1, v0
	ldr	d0, [sp, #12344]                ; 8-byte Reload
	fmov	w8, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w8, #0, LBB0_891
; %bb.890:                              ; %cond.load3119
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x9, d3
	ldr	s0, [x9]
LBB0_891:                               ; %else3123
                                        ;   in Loop: Header=BB0_889 Depth=2
	ldr	q5, [sp, #13168]                ; 16-byte Reload
	ldr	q6, [sp, #6544]                 ; 16-byte Reload
	ldr	q22, [sp, #6464]                ; 16-byte Reload
	tbz	w8, #1, LBB0_893
; %bb.892:                              ; %cond.load3125
                                        ;   in Loop: Header=BB0_889 Depth=2
	mov.d	x9, v3[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_893:                               ; %else3129
                                        ;   in Loop: Header=BB0_889 Depth=2
	shl.2d	v4, v18, #5
	ldr	q3, [sp, #8352]                 ; 16-byte Reload
	str	q4, [sp, #11856]                ; 16-byte Spill
	orr.16b	v3, v4, v3
	ldr	q4, [sp, #8416]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w8, #2, LBB0_895
; %bb.894:                              ; %cond.load3131
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x9, d3
	ld1.s	{ v0 }[2], [x9]
LBB0_895:                               ; %else3135
                                        ;   in Loop: Header=BB0_889 Depth=2
	tbz	w8, #3, LBB0_897
; %bb.896:                              ; %cond.load3137
                                        ;   in Loop: Header=BB0_889 Depth=2
	mov.d	x9, v3[1]
	ld1.s	{ v0 }[3], [x9]
LBB0_897:                               ; %else3141
                                        ;   in Loop: Header=BB0_889 Depth=2
	shl.2d	v4, v19, #5
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	str	q4, [sp, #11840]                ; 16-byte Spill
	orr.16b	v3, v4, v3
	ldr	q4, [sp, #8400]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w8, #4, LBB0_899
; %bb.898:                              ; %cond.load3143
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x9, d3
	ld1.s	{ v1 }[0], [x9]
LBB0_899:                               ; %else3147
                                        ;   in Loop: Header=BB0_889 Depth=2
	tbz	w8, #5, LBB0_901
; %bb.900:                              ; %cond.load3149
                                        ;   in Loop: Header=BB0_889 Depth=2
	mov.d	x9, v3[1]
	ld1.s	{ v1 }[1], [x9]
LBB0_901:                               ; %else3153
                                        ;   in Loop: Header=BB0_889 Depth=2
	shl.2d	v4, v23, #5
	ldr	q3, [sp, #8448]                 ; 16-byte Reload
	str	q4, [sp, #11824]                ; 16-byte Spill
	orr.16b	v3, v4, v3
	ldr	q4, [sp, #8384]                 ; 16-byte Reload
	add.2d	v3, v4, v3
	tbz	w8, #6, LBB0_903
; %bb.902:                              ; %cond.load3155
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x9, d3
	ld1.s	{ v1 }[2], [x9]
LBB0_903:                               ; %else3159
                                        ;   in Loop: Header=BB0_889 Depth=2
	tbz	w8, #7, LBB0_905
; %bb.904:                              ; %cond.load3161
                                        ;   in Loop: Header=BB0_889 Depth=2
	mov.d	x8, v3[1]
	ld1.s	{ v1 }[3], [x8]
LBB0_905:                               ; %else3165
                                        ;   in Loop: Header=BB0_889 Depth=2
	sshll.2d	v3, v30, #0
	str	q19, [sp, #8048]                ; 16-byte Spill
	and.16b	v4, v3, v19
	mov.d	x8, v4[1]
	sdiv	x9, x8, x26
	msub	x8, x9, x26, x8
	fmov	x9, d4
	ldr	q4, [sp, #11664]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	ldr	q16, [sp, #6512]                ; 16-byte Reload
	bit.16b	v16, v4, v3
	sshll.2d	v3, v31, #0
	str	q17, [sp, #8080]                ; 16-byte Spill
	and.16b	v4, v3, v17
	mov.d	x8, v4[1]
	ldr	x10, [sp, #11704]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d4
	ldr	q4, [sp, #11680]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	bit.16b	v6, v4, v3
	str	q18, [sp, #8064]                ; 16-byte Spill
	and.16b	v3, v8, v18
	mov.d	x8, v3[1]
	fmov	x9, d3
	str	q23, [sp, #8032]                ; 16-byte Spill
	and.16b	v3, v14, v23
	ldr	q4, [sp, #11648]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	mov.d	x10, v3[1]
	fmov	x11, d3
	ldr	q3, [sp, #11632]                ; 16-byte Reload
	fmov	x12, d3
	sdiv	x14, x11, x12
	msub	x11, x14, x12, x11
	sdiv	x12, x8, x25
	msub	x8, x12, x25, x8
	sdiv	x12, x10, x27
	msub	x10, x12, x27, x10
	fmov	d3, x11
	mov.d	v3[1], x10
	ldr	q17, [sp, #6496]                ; 16-byte Reload
	bit.16b	v17, v3, v14
	fmov	d3, x9
	mov.d	v3[1], x8
	ldr	q7, [sp, #6528]                 ; 16-byte Reload
	bit.16b	v7, v3, v8
	ldr	q3, [sp, #4032]                 ; 16-byte Reload
	ldr	q4, [sp, #6432]                 ; 16-byte Reload
	bif.16b	v1, v4, v3
	ldr	q3, [sp, #4016]                 ; 16-byte Reload
	ldr	q4, [sp, #6416]                 ; 16-byte Reload
	bif.16b	v0, v4, v3
	sshll.2d	v3, v30, #0
	bic.16b	v22, v22, v3
	sshll.2d	v3, v31, #0
	bic.16b	v13, v13, v3
	movi	d3, #0xffffffffffffff
	ldr	q19, [sp, #6480]                ; 16-byte Reload
	bit.8b	v19, v3, v5
	ldr	q3, [sp, #4000]                 ; 16-byte Reload
	and.16b	v3, v3, v0
	ldr	q0, [sp, #3984]                 ; 16-byte Reload
	and.16b	v0, v0, v1
	ldr	q23, [sp, #6448]                ; 16-byte Reload
	bic.16b	v23, v23, v14
	bic.16b	v27, v27, v8
	str	q0, [sp, #6432]                 ; 16-byte Spill
	bit.16b	v24, v0, v30
	ldr	q0, [sp, #13072]                ; 16-byte Reload
	str	q3, [sp, #6416]                 ; 16-byte Spill
	bit.16b	v0, v3, v31
	str	q0, [sp, #13072]                ; 16-byte Spill
	fmov	x8, d13
	cmp	x8, #64
	str	q6, [sp, #6544]                 ; 16-byte Spill
	str	q7, [sp, #6528]                 ; 16-byte Spill
	str	q16, [sp, #6512]                ; 16-byte Spill
	str	q17, [sp, #6496]                ; 16-byte Spill
	str	q19, [sp, #6480]                ; 16-byte Spill
	b.gt	LBB0_940
; %bb.906:                              ; %direct.true810.lr.ph
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x8, d6
	add	x8, x8, x8, lsl #3
	fmov	d4, x8
	mov.d	x8, v6[1]
	add	x8, x8, x8, lsl #3
	mov.d	v4[1], x8
	fmov	x8, d7
	add	x8, x8, x8, lsl #3
	mov.d	x9, v7[1]
	fmov	d6, x8
	add	x8, x9, x9, lsl #3
	mov.d	v6[1], x8
	fmov	x8, d16
	add	x8, x8, x8, lsl #3
	fmov	d18, x8
	mov.d	x8, v16[1]
	add	x8, x8, x8, lsl #3
	mov.d	v18[1], x8
	fmov	x8, d17
	add	x8, x8, x8, lsl #3
	fmov	d7, x8
	mov.d	x8, v17[1]
	add	x8, x8, x8, lsl #3
	mov.d	v7[1], x8
	bic.8b	v0, v5, v19
	zip1.8b	v1, v0, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v19, v1, #0
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v16, v0, #0
	b	LBB0_908
LBB0_907:                               ; %else3263
                                        ;   in Loop: Header=BB0_908 Depth=3
	ldr	q29, [sp, #13296]               ; 16-byte Reload
	mov.s	v3[1], v23[0]
	mov.s	v3[2], v17[0]
	mov.s	v3[3], v25[0]
	mov.s	v0[1], v1[0]
	mov.s	v0[2], v5[0]
	mov.s	v0[3], v22[0]
	ldr	q5, [sp, #12416]                ; 16-byte Reload
	bit.16b	v5, v0, v31
	ldr	q17, [sp, #12400]               ; 16-byte Reload
	bit.16b	v17, v3, v30
	ldr	q0, [sp, #11744]                ; 16-byte Reload
	ldr	q1, [sp, #12384]                ; 16-byte Reload
	bsl.16b	v0, v26, v1
	ldr	q1, [sp, #11728]                ; 16-byte Reload
	ldr	q3, [sp, #12432]                ; 16-byte Reload
	bsl.16b	v1, v24, v3
	and.16b	v1, v19, v1
	and.16b	v0, v16, v0
	str	q17, [sp, #12400]               ; 16-byte Spill
	str	q0, [sp, #12384]                ; 16-byte Spill
	fmul.4s	v0, v0, v17
	str	q1, [sp, #12432]                ; 16-byte Spill
	str	q5, [sp, #12416]                ; 16-byte Spill
	fmul.4s	v1, v1, v5
	ldr	q3, [sp, #13072]                ; 16-byte Reload
	fadd.4s	v1, v3, v1
	fadd.4s	v0, v21, v0
	mov.16b	v27, v10
	mov.16b	v10, v20
	add.2d	v27, v27, v20
	mov.16b	v22, v15
	mov.16b	v15, v2
	add.2d	v22, v22, v2
	add.2d	v23, v12, v9
	ldr	q20, [sp, #13312]               ; 16-byte Reload
	add.2d	v13, v13, v20
	mov.16b	v24, v30
	bsl.16b	v24, v0, v21
	bit.16b	v3, v1, v31
	str	q3, [sp, #13072]                ; 16-byte Spill
	fmov	x8, d13
	cmp	x8, #65
	b.ge	LBB0_941
LBB0_908:                               ; %direct.true810
                                        ;   Parent Loop BB0_92 Depth=1
                                        ;     Parent Loop BB0_889 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	mov.16b	v20, v10
	mov.16b	v21, v24
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	mov.16b	v29, v13
	and.16b	v3, v1, v13
	mov.16b	v15, v22
	and.16b	v5, v0, v22
	mov.16b	v12, v23
	and.16b	v17, v14, v23
	mov.d	x8, v17[1]
	mov.16b	v10, v27
	and.16b	v22, v8, v27
	ldr	q23, [sp, #13040]               ; 16-byte Reload
	mov.d	x10, v23[1]
	sdiv	x8, x8, x10
	fmov	x9, d17
	fmov	x11, d23
	sdiv	x9, x9, x11
	mov.d	x12, v22[1]
	ldr	q23, [sp, #13024]               ; 16-byte Reload
	mov.d	x15, v23[1]
	sdiv	x6, x12, x15
	fmov	x12, d22
	fmov	x19, d23
	mov.d	x14, v5[1]
	ldr	q23, [sp, #13008]               ; 16-byte Reload
	mov.d	x20, v23[1]
	sdiv	x7, x12, x19
	sdiv	x14, x14, x20
	fmov	x12, d5
	fmov	x21, d23
	mov.d	x22, v3[1]
	ldr	q23, [sp, #12992]               ; 16-byte Reload
	mov.d	x23, v23[1]
	sdiv	x22, x22, x23
	fmov	x24, d3
	fmov	x25, d23
	sdiv	x24, x24, x25
	mul	x25, x24, x25
	fmov	d23, x24
	mov.d	v23[1], x22
	mul	x10, x8, x10
	mul	x11, x9, x11
	fmov	d24, x11
	mov.d	v24[1], x10
	mul	x10, x6, x15
	mul	x11, x7, x19
	fmov	d25, x11
	mov.d	v25[1], x10
	mul	x10, x14, x20
	sdiv	x19, x12, x21
	mul	x11, x19, x21
	fmov	d26, x11
	mov.d	v26[1], x10
	mul	x10, x22, x23
	fmov	d27, x25
	mov.d	v27[1], x10
	add.2d	v13, v23, v4
	sub.2d	v3, v3, v27
	sub.2d	v5, v5, v26
	sub.2d	v23, v22, v25
	sub.2d	v25, v17, v24
	ldr	q17, [sp, #13088]               ; 16-byte Reload
	cmeq.2d	v17, v17, v25
	ldr	q22, [sp, #13136]               ; 16-byte Reload
	cmeq.2d	v22, v22, v5
	uzp1.4s	v17, v22, v17
	ldr	q22, [sp, #13104]               ; 16-byte Reload
	cmeq.2d	v22, v22, v23
	ldr	q24, [sp, #13120]               ; 16-byte Reload
	cmeq.2d	v24, v24, v3
	uzp1.4s	v22, v24, v22
	uzp1.8h	v17, v22, v17
	and.16b	v22, v28, v17
	xtn.8b	v22, v22
	shl.8b	v24, v22, #7
	cmlt.8b	v24, v24, #0
	ldr	d26, [sp, #13344]               ; 8-byte Reload
	and.8b	v24, v24, v26
	addv.8b	b24, v24
	fmov	w15, s24
	shl.2d	v24, v13, #5
	ldr	q26, [sp, #12848]               ; 16-byte Reload
	orr.16b	v24, v24, v26
	ldr	q2, [sp, #12784]                ; 16-byte Reload
	add.2d	v27, v2, v24
	movi.2d	v24, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w15, #0, LBB0_910
; %bb.909:                              ; %cond.load3168
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	x10, d27
	ldr	s24, [x10]
LBB0_910:                               ; %else3172
                                        ;   in Loop: Header=BB0_908 Depth=3
	tbz	w15, #1, LBB0_912
; %bb.911:                              ; %cond.load3174
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.d	x10, v27[1]
	ld1.s	{ v24 }[1], [x10]
LBB0_912:                               ; %else3178
                                        ;   in Loop: Header=BB0_908 Depth=3
	ldr	q28, [sp, #13280]               ; 16-byte Reload
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	mov.16b	v13, v29
	fmov	d27, x7
	mov.d	v27[1], x6
	add.2d	v27, v27, v6
	shl.2d	v27, v27, #5
	ldr	q29, [sp, #12832]               ; 16-byte Reload
	orr.16b	v27, v27, v29
	ldr	q29, [sp, #12768]               ; 16-byte Reload
	add.2d	v27, v29, v27
	tbz	w15, #2, LBB0_914
; %bb.913:                              ; %cond.load3180
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	x10, d27
	ld1.s	{ v24 }[2], [x10]
LBB0_914:                               ; %else3184
                                        ;   in Loop: Header=BB0_908 Depth=3
	tbz	w15, #3, LBB0_916
; %bb.915:                              ; %cond.load3186
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.d	x10, v27[1]
	ld1.s	{ v24 }[3], [x10]
LBB0_916:                               ; %else3190
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	d27, x19
	mov.d	v27[1], x14
	add.2d	v27, v27, v18
	shl.2d	v27, v27, #5
	ldr	q29, [sp, #12816]               ; 16-byte Reload
	orr.16b	v27, v27, v29
	ldr	q29, [sp, #12752]               ; 16-byte Reload
	add.2d	v27, v29, v27
	tbz	w15, #4, LBB0_918
; %bb.917:                              ; %cond.load3192
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	x10, d27
	ld1.s	{ v26 }[0], [x10]
LBB0_918:                               ; %else3196
                                        ;   in Loop: Header=BB0_908 Depth=3
	tbz	w15, #5, LBB0_920
; %bb.919:                              ; %cond.load3198
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.d	x10, v27[1]
	ld1.s	{ v26 }[1], [x10]
LBB0_920:                               ; %else3202
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	d27, x9
	mov.d	v27[1], x8
	add.2d	v27, v27, v7
	shl.2d	v27, v27, #5
	ldr	q29, [sp, #12800]               ; 16-byte Reload
	orr.16b	v27, v27, v29
	ldr	q29, [sp, #12864]               ; 16-byte Reload
	add.2d	v27, v29, v27
	tbz	w15, #6, LBB0_922
; %bb.921:                              ; %cond.load3204
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	x8, d27
	ld1.s	{ v26 }[2], [x8]
LBB0_922:                               ; %else3208
                                        ;   in Loop: Header=BB0_908 Depth=3
	tbz	w15, #7, LBB0_924
; %bb.923:                              ; %cond.load3210
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.d	x8, v27[1]
	ld1.s	{ v26 }[3], [x8]
LBB0_924:                               ; %else3214
                                        ;   in Loop: Header=BB0_908 Depth=3
	ldr	q14, [sp, #12448]               ; 16-byte Reload
	bit.16b	v14, v25, v11
	ldr	q27, [sp, #12480]               ; 16-byte Reload
	bit.16b	v27, v23, v8
	ldr	q29, [sp, #12464]               ; 16-byte Reload
	bit.16b	v29, v5, v0
	ldr	q23, [sp, #12496]               ; 16-byte Reload
	bit.16b	v23, v3, v1
	bic.16b	v0, v28, v17
	xtn.8b	v0, v0
	zip2.8b	v1, v22, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #12368]                ; 16-byte Reload
	bsl.16b	v1, v26, v3
	zip1.8b	v3, v22, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	ldr	q5, [sp, #12352]                ; 16-byte Reload
	bsl.16b	v3, v24, v5
	zip1.8b	v5, v0, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v26, v5, v3
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v24, v0, v1
	str	q14, [sp, #12448]               ; 16-byte Spill
	xtn.2s	v25, v14
	str	q29, [sp, #12464]               ; 16-byte Spill
	xtn.2s	v3, v29
	str	q27, [sp, #12480]               ; 16-byte Spill
	xtn.2s	v5, v27
	str	q23, [sp, #12496]               ; 16-byte Spill
	xtn.2s	v0, v23
	mov.s	w8, v0[1]
	fmov	w9, s0
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldr	q0, [sp, #13168]                ; 16-byte Reload
	str	d0, [sp, #13624]
	ldrb	w11, [x11]
	and	w11, w16, w11
	stp	q26, q24, [x13, #144]
	ldr	s0, [x28, x9, lsl #2]
	tst	w10, w11
	movi.2d	v27, #0000000000000000
	fcsel	s0, s0, s27, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	stp	q26, q24, [x13, #176]
	ldr	s1, [x30, x10, lsl #2]
	and	w8, w17, w8
	tst	w9, w8
	fcsel	s1, s1, s27, ne
	mov.s	w8, v5[1]
	fmov	w9, s5
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w0, w11
	stp	q26, q24, [x13, #208]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1408
	ldr	s5, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s5, s5, s27, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w1, w8
	stp	q26, q24, [x13, #240]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1440
	ldr	s17, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s22, s17, s27, ne
	mov.s	w8, v3[1]
	fmov	w9, s3
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	stp	q26, q24, [x13, #272]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1472
	ldr	s3, [x12, x9, lsl #2]
	and	w9, w2, w11
	tst	w10, w9
	fcsel	s3, s3, s27, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w3, w8
	stp	q26, q24, [x13, #304]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1504
	ldr	s17, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	w8, v25[1]
	fcsel	s23, s17, s27, ne
	fmov	w9, s25
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w4, w11
	stp	q26, q24, [x13, #336]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1536
	ldr	s17, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s17, s17, s27, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w5, w8
	str	q24, [sp, #12368]               ; 16-byte Spill
	str	q24, [x13, #384]
	str	q26, [sp, #12352]               ; 16-byte Spill
	str	q26, [x13, #368]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1568
	ldr	s24, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s25, s24, s27, ne
	shl.2d	v24, v13, #5
	ldr	q26, [sp, #12064]               ; 16-byte Reload
	orr.16b	v24, v24, v26
	ldr	q26, [sp, #12128]               ; 16-byte Reload
	add.2d	v27, v26, v24
	ldr	d24, [sp, #12344]               ; 8-byte Reload
	fmov	w8, s24
	movi.2d	v24, #0000000000000000
	movi.2d	v26, #0000000000000000
	tbz	w8, #0, LBB0_926
; %bb.925:                              ; %cond.load3217
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	x9, d27
	ldr	s24, [x9]
LBB0_926:                               ; %else3221
                                        ;   in Loop: Header=BB0_908 Depth=3
	tbz	w8, #1, LBB0_928
; %bb.927:                              ; %cond.load3223
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.d	x9, v27[1]
	ld1.s	{ v24 }[1], [x9]
LBB0_928:                               ; %else3227
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.16b	v14, v11
	shl.2d	v27, v10, #5
	ldr	q29, [sp, #12048]               ; 16-byte Reload
	orr.16b	v27, v27, v29
	ldr	q29, [sp, #12112]               ; 16-byte Reload
	add.2d	v27, v29, v27
	tbnz	w8, #2, LBB0_934
; %bb.929:                              ; %else3233
                                        ;   in Loop: Header=BB0_908 Depth=3
	tbnz	w8, #3, LBB0_935
LBB0_930:                               ; %else3239
                                        ;   in Loop: Header=BB0_908 Depth=3
	shl.2d	v27, v15, #5
	ldr	q29, [sp, #12032]               ; 16-byte Reload
	orr.16b	v27, v27, v29
	ldr	q29, [sp, #12096]               ; 16-byte Reload
	add.2d	v27, v29, v27
	tbnz	w8, #4, LBB0_936
LBB0_931:                               ; %else3245
                                        ;   in Loop: Header=BB0_908 Depth=3
	tbnz	w8, #5, LBB0_937
LBB0_932:                               ; %else3251
                                        ;   in Loop: Header=BB0_908 Depth=3
	shl.2d	v27, v12, #5
	ldr	q29, [sp, #12016]               ; 16-byte Reload
	orr.16b	v27, v27, v29
	ldr	q29, [sp, #12080]               ; 16-byte Reload
	add.2d	v27, v29, v27
	tbnz	w8, #6, LBB0_938
LBB0_933:                               ; %else3257
                                        ;   in Loop: Header=BB0_908 Depth=3
	tbz	w8, #7, LBB0_907
	b	LBB0_939
LBB0_934:                               ; %cond.load3229
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	x9, d27
	ld1.s	{ v24 }[2], [x9]
	tbz	w8, #3, LBB0_930
LBB0_935:                               ; %cond.load3235
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.d	x9, v27[1]
	ld1.s	{ v24 }[3], [x9]
	shl.2d	v27, v15, #5
	ldr	q29, [sp, #12032]               ; 16-byte Reload
	orr.16b	v27, v27, v29
	ldr	q29, [sp, #12096]               ; 16-byte Reload
	add.2d	v27, v29, v27
	tbz	w8, #4, LBB0_931
LBB0_936:                               ; %cond.load3241
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	x9, d27
	ld1.s	{ v26 }[0], [x9]
	tbz	w8, #5, LBB0_932
LBB0_937:                               ; %cond.load3247
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.d	x9, v27[1]
	ld1.s	{ v26 }[1], [x9]
	shl.2d	v27, v12, #5
	ldr	q29, [sp, #12016]               ; 16-byte Reload
	orr.16b	v27, v27, v29
	ldr	q29, [sp, #12080]               ; 16-byte Reload
	add.2d	v27, v29, v27
	tbz	w8, #6, LBB0_933
LBB0_938:                               ; %cond.load3253
                                        ;   in Loop: Header=BB0_908 Depth=3
	fmov	x9, d27
	ld1.s	{ v26 }[2], [x9]
	tbz	w8, #7, LBB0_907
LBB0_939:                               ; %cond.load3259
                                        ;   in Loop: Header=BB0_908 Depth=3
	mov.d	x8, v27[1]
	ld1.s	{ v26 }[3], [x8]
	b	LBB0_907
LBB0_940:                               ;   in Loop: Header=BB0_889 Depth=2
	mov.16b	v29, v2
LBB0_941:                               ; %direct.false811
                                        ;   in Loop: Header=BB0_889 Depth=2
	str	q22, [sp, #6464]                ; 16-byte Spill
	ldr	q0, [sp, #8304]                 ; 16-byte Reload
	ldr	q1, [sp, #11872]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8240]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	d1, [sp, #12344]                ; 8-byte Reload
	fmov	w8, s1
	tbz	w8, #0, LBB0_943
; %bb.942:                              ; %cond.store3266
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x9, d0
	ldr	q1, [sp, #13072]                ; 16-byte Reload
	str	s1, [x9]
LBB0_943:                               ; %else3269
                                        ;   in Loop: Header=BB0_889 Depth=2
	ldr	d12, [sp, #11576]               ; 8-byte Reload
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	ldr	q22, [sp, #11712]               ; 16-byte Reload
	ldr	q26, [sp, #11232]               ; 16-byte Reload
	mov.16b	v2, v29
	tbz	w8, #1, LBB0_945
; %bb.944:                              ; %cond.store3270
                                        ;   in Loop: Header=BB0_889 Depth=2
	mov.d	x9, v0[1]
	ldr	q0, [sp, #13072]                ; 16-byte Reload
	st1.s	{ v0 }[1], [x9]
LBB0_945:                               ; %else3273
                                        ;   in Loop: Header=BB0_889 Depth=2
	str	q23, [sp, #6448]                ; 16-byte Spill
	ldr	q0, [sp, #8288]                 ; 16-byte Reload
	ldr	q1, [sp, #11856]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8224]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #2, LBB0_951
; %bb.946:                              ; %else3277
                                        ;   in Loop: Header=BB0_889 Depth=2
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	ldr	q17, [sp, #8080]                ; 16-byte Reload
	ldr	q18, [sp, #8064]                ; 16-byte Reload
	ldr	q19, [sp, #8048]                ; 16-byte Reload
	ldr	q23, [sp, #8032]                ; 16-byte Reload
	tbnz	w8, #3, LBB0_952
LBB0_947:                               ; %else3281
                                        ;   in Loop: Header=BB0_889 Depth=2
	ldr	q0, [sp, #8272]                 ; 16-byte Reload
	ldr	q1, [sp, #11840]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8336]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #4, LBB0_953
LBB0_948:                               ; %else3285
                                        ;   in Loop: Header=BB0_889 Depth=2
	tbnz	w8, #5, LBB0_954
LBB0_949:                               ; %else3289
                                        ;   in Loop: Header=BB0_889 Depth=2
	ldr	q0, [sp, #8256]                 ; 16-byte Reload
	ldr	q1, [sp, #11824]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8320]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #6, LBB0_955
LBB0_950:                               ; %else3293
                                        ;   in Loop: Header=BB0_889 Depth=2
	tbz	w8, #7, LBB0_888
	b	LBB0_956
LBB0_951:                               ; %cond.store3274
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x9, d0
	ldr	q1, [sp, #13072]                ; 16-byte Reload
	st1.s	{ v1 }[2], [x9]
	ldr	x25, [sp, #11568]               ; 8-byte Reload
	ldr	q17, [sp, #8080]                ; 16-byte Reload
	ldr	q18, [sp, #8064]                ; 16-byte Reload
	ldr	q19, [sp, #8048]                ; 16-byte Reload
	ldr	q23, [sp, #8032]                ; 16-byte Reload
	tbz	w8, #3, LBB0_947
LBB0_952:                               ; %cond.store3278
                                        ;   in Loop: Header=BB0_889 Depth=2
	mov.d	x9, v0[1]
	ldr	q0, [sp, #13072]                ; 16-byte Reload
	st1.s	{ v0 }[3], [x9]
	ldr	q0, [sp, #8272]                 ; 16-byte Reload
	ldr	q1, [sp, #11840]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8336]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #4, LBB0_948
LBB0_953:                               ; %cond.store3282
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x9, d0
	str	s24, [x9]
	tbz	w8, #5, LBB0_949
LBB0_954:                               ; %cond.store3286
                                        ;   in Loop: Header=BB0_889 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v24 }[1], [x9]
	ldr	q0, [sp, #8256]                 ; 16-byte Reload
	ldr	q1, [sp, #11824]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8320]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_950
LBB0_955:                               ; %cond.store3290
                                        ;   in Loop: Header=BB0_889 Depth=2
	fmov	x9, d0
	st1.s	{ v24 }[2], [x9]
	tbz	w8, #7, LBB0_888
LBB0_956:                               ; %cond.store3294
                                        ;   in Loop: Header=BB0_889 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v24 }[3], [x8]
	b	LBB0_888
LBB0_957:                               ;   in Loop: Header=BB0_92 Depth=1
	ldp	q27, q24, [sp, #800]            ; 32-byte Folded Reload
LBB0_958:                               ; %direct.false802
                                        ;   in Loop: Header=BB0_92 Depth=1
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #9984]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #9984]                 ; 16-byte Spill
	mov.16b	v11, v8
	ldr	q3, [sp, #9952]                 ; 16-byte Reload
	bic.16b	v3, v3, v8
	str	q3, [sp, #9952]                 ; 16-byte Spill
	ldr	q3, [sp, #9936]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #9936]                 ; 16-byte Spill
	ldr	q1, [sp, #1088]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x8, d0
	cmp	x8, #1
	mov.16b	v8, v9
	ldp	q9, q20, [sp, #768]             ; 32-byte Folded Reload
	b.lt	LBB0_997
LBB0_959:                               ; %direct.false840
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q0, [sp, #1088]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #9968]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #9968]                 ; 16-byte Spill
	ldr	q3, [sp, #9920]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #9920]                 ; 16-byte Spill
	ldr	q3, [sp, #9904]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #9904]                 ; 16-byte Spill
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x8, d0
	cmp	x8, #1
	b.lt	LBB0_1437
; %bb.960:                              ;   in Loop: Header=BB0_92 Depth=1
	ldr	q21, [sp, #1072]                ; 16-byte Reload
LBB0_961:                               ; %direct.false852
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q0, [sp, #1056]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	bic.16b	v21, v21, v14
	ldr	q3, [sp, #11072]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #11072]                ; 16-byte Spill
	ldr	q3, [sp, #11056]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #11056]                ; 16-byte Spill
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x8, d0
	cmp	x8, #1
	b.le	LBB0_964
LBB0_962:                               ; %direct.false864
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q0, [sp, #1040]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #9888]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #9888]                 ; 16-byte Spill
	ldr	q3, [sp, #9856]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #9856]                 ; 16-byte Spill
	ldr	q3, [sp, #9840]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #9840]                 ; 16-byte Spill
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	b	LBB0_1030
LBB0_963:                               ; %else3543
                                        ;   in Loop: Header=BB0_964 Depth=2
	str	q3, [sp, #6400]                 ; 16-byte Spill
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #11072]                ; 16-byte Spill
	ldr	q0, [sp, #11056]                ; 16-byte Reload
	add.2d	v0, v0, v15
	str	q0, [sp, #11056]                ; 16-byte Spill
	add.2d	v21, v21, v8
	ldr	q1, [sp, #13312]                ; 16-byte Reload
	add.2d	v0, v29, v1
	fmov	x8, d0
	cmp	x8, #2
	b.ge	LBB0_962
LBB0_964:                               ; %direct.true863
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v29, v0
	shl.2d	v1, v0, #5
	ldr	q0, [sp, #8304]                 ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q3, [sp, #8240]                 ; 16-byte Reload
	add.2d	v4, v3, v0
	ldr	d0, [sp, #12344]                ; 8-byte Reload
	fmov	w8, s0
	movi.2d	v3, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_966
; %bb.965:                              ; %cond.load3463
                                        ;   in Loop: Header=BB0_964 Depth=2
	fmov	x9, d4
	ldr	s3, [x9]
LBB0_966:                               ; %else3467
                                        ;   in Loop: Header=BB0_964 Depth=2
	tbz	w8, #1, LBB0_968
; %bb.967:                              ; %cond.load3469
                                        ;   in Loop: Header=BB0_964 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[1], [x9]
LBB0_968:                               ; %else3473
                                        ;   in Loop: Header=BB0_964 Depth=2
	ldr	q4, [sp, #11072]                ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #8288]                 ; 16-byte Reload
	orr.16b	v5, v4, v5
	ldr	q6, [sp, #8224]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w8, #2, LBB0_970
; %bb.969:                              ; %cond.load3475
                                        ;   in Loop: Header=BB0_964 Depth=2
	fmov	x9, d5
	ld1.s	{ v3 }[2], [x9]
LBB0_970:                               ; %else3479
                                        ;   in Loop: Header=BB0_964 Depth=2
	tbz	w8, #3, LBB0_972
; %bb.971:                              ; %cond.load3481
                                        ;   in Loop: Header=BB0_964 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_972:                               ; %else3485
                                        ;   in Loop: Header=BB0_964 Depth=2
	ldr	q5, [sp, #11056]                ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #8272]                 ; 16-byte Reload
	orr.16b	v6, v5, v6
	ldr	q7, [sp, #8336]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbnz	w8, #4, LBB0_986
; %bb.973:                              ; %else3491
                                        ;   in Loop: Header=BB0_964 Depth=2
	tbnz	w8, #5, LBB0_987
LBB0_974:                               ; %else3497
                                        ;   in Loop: Header=BB0_964 Depth=2
	shl.2d	v6, v21, #5
	ldr	q7, [sp, #8256]                 ; 16-byte Reload
	orr.16b	v7, v6, v7
	ldr	q16, [sp, #8320]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbnz	w8, #6, LBB0_988
LBB0_975:                               ; %else3503
                                        ;   in Loop: Header=BB0_964 Depth=2
	tbz	w8, #7, LBB0_977
LBB0_976:                               ; %cond.load3505
                                        ;   in Loop: Header=BB0_964 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_977:                               ; %else3509
                                        ;   in Loop: Header=BB0_964 Depth=2
	ldr	d7, [sp, #12344]                ; 8-byte Reload
	fmov	w8, s7
	ldr	q7, [sp, #3968]                 ; 16-byte Reload
	ldr	q16, [sp, #11408]               ; 16-byte Reload
	bif.16b	v3, v16, v7
	ldr	q7, [sp, #3920]                 ; 16-byte Reload
	and.16b	v3, v7, v3
	str	q3, [sp, #11408]                ; 16-byte Spill
	ldr	q3, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #7872]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #0, LBB0_989
; %bb.978:                              ; %else3515
                                        ;   in Loop: Header=BB0_964 Depth=2
	tbnz	w8, #1, LBB0_990
LBB0_979:                               ; %else3519
                                        ;   in Loop: Header=BB0_964 Depth=2
	ldr	q1, [sp, #12272]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q3, [sp, #7904]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #2, LBB0_991
LBB0_980:                               ; %else3523
                                        ;   in Loop: Header=BB0_964 Depth=2
	tbz	w8, #3, LBB0_982
LBB0_981:                               ; %cond.store3524
                                        ;   in Loop: Header=BB0_964 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11408]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_982:                               ; %else3527
                                        ;   in Loop: Header=BB0_964 Depth=2
	ldr	q1, [sp, #3952]                 ; 16-byte Reload
	ldr	q3, [sp, #6400]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	ldr	q1, [sp, #3936]                 ; 16-byte Reload
	and.16b	v3, v1, v0
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	ldr	q1, [sp, #7888]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #4, LBB0_992
; %bb.983:                              ; %else3531
                                        ;   in Loop: Header=BB0_964 Depth=2
	tbnz	w8, #5, LBB0_993
LBB0_984:                               ; %else3535
                                        ;   in Loop: Header=BB0_964 Depth=2
	ldr	q0, [sp, #12288]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #7920]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #6, LBB0_994
LBB0_985:                               ; %else3539
                                        ;   in Loop: Header=BB0_964 Depth=2
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_963
	b	LBB0_995
LBB0_986:                               ; %cond.load3487
                                        ;   in Loop: Header=BB0_964 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
	tbz	w8, #5, LBB0_974
LBB0_987:                               ; %cond.load3493
                                        ;   in Loop: Header=BB0_964 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
	shl.2d	v6, v21, #5
	ldr	q7, [sp, #8256]                 ; 16-byte Reload
	orr.16b	v7, v6, v7
	ldr	q16, [sp, #8320]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbz	w8, #6, LBB0_975
LBB0_988:                               ; %cond.load3499
                                        ;   in Loop: Header=BB0_964 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_976
	b	LBB0_977
LBB0_989:                               ; %cond.store3512
                                        ;   in Loop: Header=BB0_964 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #11408]                ; 16-byte Reload
	str	s3, [x9]
	tbz	w8, #1, LBB0_979
LBB0_990:                               ; %cond.store3516
                                        ;   in Loop: Header=BB0_964 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11408]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #12272]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q3, [sp, #7904]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w8, #2, LBB0_980
LBB0_991:                               ; %cond.store3520
                                        ;   in Loop: Header=BB0_964 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #11408]                ; 16-byte Reload
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #3, LBB0_981
	b	LBB0_982
LBB0_992:                               ; %cond.store3528
                                        ;   in Loop: Header=BB0_964 Depth=2
	fmov	x9, d0
	str	s3, [x9]
	tbz	w8, #5, LBB0_984
LBB0_993:                               ; %cond.store3532
                                        ;   in Loop: Header=BB0_964 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q0, [sp, #12288]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #7920]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_985
LBB0_994:                               ; %cond.store3536
                                        ;   in Loop: Header=BB0_964 Depth=2
	fmov	x9, d0
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_963
LBB0_995:                               ; %cond.store3540
                                        ;   in Loop: Header=BB0_964 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v3 }[3], [x8]
	b	LBB0_963
LBB0_996:                               ; %else3379
                                        ;   in Loop: Header=BB0_997 Depth=2
	str	q3, [sp, #4880]                 ; 16-byte Spill
	ldr	q0, [sp, #9952]                 ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #9952]                 ; 16-byte Spill
	ldr	q0, [sp, #9936]                 ; 16-byte Reload
	add.2d	v0, v0, v15
	str	q0, [sp, #9936]                 ; 16-byte Spill
	ldr	q0, [sp, #9984]                 ; 16-byte Reload
	add.2d	v0, v0, v8
	str	q0, [sp, #9984]                 ; 16-byte Spill
	ldr	q1, [sp, #13312]                ; 16-byte Reload
	add.2d	v0, v21, v1
	fmov	x8, d0
	cmp	x8, #1
	b.ge	LBB0_959
LBB0_997:                               ; %direct.true839
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v21, v0
	shl.2d	v1, v0, #5
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q3, [sp, #10464]                ; 16-byte Reload
	add.2d	v4, v3, v0
	fmov	w8, s12
	movi.2d	v3, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_999
; %bb.998:                              ; %cond.load3299
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	x9, d4
	ldr	s3, [x9]
LBB0_999:                               ; %else3303
                                        ;   in Loop: Header=BB0_997 Depth=2
	tbz	w8, #1, LBB0_1001
; %bb.1000:                             ; %cond.load3305
                                        ;   in Loop: Header=BB0_997 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[1], [x9]
LBB0_1001:                              ; %else3309
                                        ;   in Loop: Header=BB0_997 Depth=2
	ldr	q4, [sp, #9952]                 ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #10496]                ; 16-byte Reload
	orr.16b	v5, v4, v5
	ldr	q6, [sp, #10560]                ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w8, #2, LBB0_1003
; %bb.1002:                             ; %cond.load3311
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	x9, d5
	ld1.s	{ v3 }[2], [x9]
LBB0_1003:                              ; %else3315
                                        ;   in Loop: Header=BB0_997 Depth=2
	tbz	w8, #3, LBB0_1005
; %bb.1004:                             ; %cond.load3317
                                        ;   in Loop: Header=BB0_997 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_1005:                              ; %else3321
                                        ;   in Loop: Header=BB0_997 Depth=2
	ldr	q5, [sp, #9936]                 ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #10480]                ; 16-byte Reload
	orr.16b	v6, v5, v6
	ldr	q7, [sp, #10544]                ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w8, #4, LBB0_1007
; %bb.1006:                             ; %cond.load3323
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
LBB0_1007:                              ; %else3327
                                        ;   in Loop: Header=BB0_997 Depth=2
	tbz	w8, #5, LBB0_1009
; %bb.1008:                             ; %cond.load3329
                                        ;   in Loop: Header=BB0_997 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1009:                              ; %else3333
                                        ;   in Loop: Header=BB0_997 Depth=2
	ldr	q6, [sp, #9984]                 ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #10576]                ; 16-byte Reload
	orr.16b	v7, v6, v7
	ldr	q16, [sp, #10528]               ; 16-byte Reload
	add.2d	v7, v16, v7
	tbz	w8, #6, LBB0_1011
; %bb.1010:                             ; %cond.load3335
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1011:                              ; %else3339
                                        ;   in Loop: Header=BB0_997 Depth=2
	tbz	w8, #7, LBB0_1013
; %bb.1012:                             ; %cond.load3341
                                        ;   in Loop: Header=BB0_997 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1013:                              ; %else3345
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	w8, s12
	ldr	q7, [sp, #2464]                 ; 16-byte Reload
	ldr	q16, [sp, #10656]               ; 16-byte Reload
	bif.16b	v3, v16, v7
	ldr	q7, [sp, #2416]                 ; 16-byte Reload
	and.16b	v3, v7, v3
	str	q3, [sp, #10656]                ; 16-byte Spill
	ldr	q3, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5616]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #0, LBB0_1022
; %bb.1014:                             ; %else3351
                                        ;   in Loop: Header=BB0_997 Depth=2
	tbnz	w8, #1, LBB0_1023
LBB0_1015:                              ; %else3355
                                        ;   in Loop: Header=BB0_997 Depth=2
	ldr	q1, [sp, #12272]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #2, LBB0_1024
LBB0_1016:                              ; %else3359
                                        ;   in Loop: Header=BB0_997 Depth=2
	tbz	w8, #3, LBB0_1018
LBB0_1017:                              ; %cond.store3360
                                        ;   in Loop: Header=BB0_997 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10656]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1018:                              ; %else3363
                                        ;   in Loop: Header=BB0_997 Depth=2
	ldr	q1, [sp, #2448]                 ; 16-byte Reload
	ldr	q3, [sp, #4880]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	ldr	q1, [sp, #2432]                 ; 16-byte Reload
	and.16b	v3, v1, v0
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	ldr	q1, [sp, #5632]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #4, LBB0_1025
; %bb.1019:                             ; %else3367
                                        ;   in Loop: Header=BB0_997 Depth=2
	tbnz	w8, #5, LBB0_1026
LBB0_1020:                              ; %else3371
                                        ;   in Loop: Header=BB0_997 Depth=2
	ldr	q0, [sp, #12288]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #5664]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #6, LBB0_1027
LBB0_1021:                              ; %else3375
                                        ;   in Loop: Header=BB0_997 Depth=2
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_996
	b	LBB0_1028
LBB0_1022:                              ; %cond.store3348
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #10656]                ; 16-byte Reload
	str	s3, [x9]
	tbz	w8, #1, LBB0_1015
LBB0_1023:                              ; %cond.store3352
                                        ;   in Loop: Header=BB0_997 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10656]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #12272]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w8, #2, LBB0_1016
LBB0_1024:                              ; %cond.store3356
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #10656]                ; 16-byte Reload
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #3, LBB0_1017
	b	LBB0_1018
LBB0_1025:                              ; %cond.store3364
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	x9, d0
	str	s3, [x9]
	tbz	w8, #5, LBB0_1020
LBB0_1026:                              ; %cond.store3368
                                        ;   in Loop: Header=BB0_997 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v3 }[1], [x9]
	ldr	q0, [sp, #12288]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #5664]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_1021
LBB0_1027:                              ; %cond.store3372
                                        ;   in Loop: Header=BB0_997 Depth=2
	fmov	x9, d0
	st1.s	{ v3 }[2], [x9]
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_996
LBB0_1028:                              ; %cond.store3376
                                        ;   in Loop: Header=BB0_997 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v3 }[3], [x8]
	b	LBB0_996
LBB0_1029:                              ; %else3625
                                        ;   in Loop: Header=BB0_1030 Depth=2
	str	q1, [sp, #4864]                 ; 16-byte Spill
	ldr	q0, [sp, #9856]                 ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #9856]                 ; 16-byte Spill
	ldr	q0, [sp, #9840]                 ; 16-byte Reload
	add.2d	v0, v0, v15
	str	q0, [sp, #9840]                 ; 16-byte Spill
	ldr	q0, [sp, #9888]                 ; 16-byte Reload
	add.2d	v0, v0, v8
	str	q0, [sp, #9888]                 ; 16-byte Spill
	ldr	q1, [sp, #13312]                ; 16-byte Reload
	add.2d	v0, v29, v1
LBB0_1030:                              ; %direct.false864
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	x8, d0
	cmp	x8, #1
	b.ge	LBB0_1063
; %bb.1031:                             ; %direct.true875
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.16b	v29, v0
	shl.2d	v0, v0, #5
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v0, v1
	ldr	q0, [sp, #5616]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	fmov	w8, s12
	movi.2d	v3, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_1033
; %bb.1032:                             ; %cond.load3545
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	x9, d4
	ldr	s3, [x9]
LBB0_1033:                              ; %else3549
                                        ;   in Loop: Header=BB0_1030 Depth=2
	tbz	w8, #1, LBB0_1035
; %bb.1034:                             ; %cond.load3551
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[1], [x9]
LBB0_1035:                              ; %else3555
                                        ;   in Loop: Header=BB0_1030 Depth=2
	ldr	q4, [sp, #9856]                 ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #12272]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #5648]                 ; 16-byte Reload
	add.2d	v5, v5, v4
	tbz	w8, #2, LBB0_1037
; %bb.1036:                             ; %cond.load3557
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	x9, d5
	ld1.s	{ v3 }[2], [x9]
LBB0_1037:                              ; %else3561
                                        ;   in Loop: Header=BB0_1030 Depth=2
	tbz	w8, #3, LBB0_1039
; %bb.1038:                             ; %cond.load3563
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_1039:                              ; %else3567
                                        ;   in Loop: Header=BB0_1030 Depth=2
	ldr	q5, [sp, #9840]                 ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #12320]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #5632]                 ; 16-byte Reload
	add.2d	v6, v6, v5
	tbz	w8, #4, LBB0_1041
; %bb.1040:                             ; %cond.load3569
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
LBB0_1041:                              ; %else3573
                                        ;   in Loop: Header=BB0_1030 Depth=2
	tbz	w8, #5, LBB0_1043
; %bb.1042:                             ; %cond.load3575
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1043:                              ; %else3579
                                        ;   in Loop: Header=BB0_1030 Depth=2
	ldr	q6, [sp, #9888]                 ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #12288]                ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #5664]                 ; 16-byte Reload
	add.2d	v7, v7, v6
	tbz	w8, #6, LBB0_1045
; %bb.1044:                             ; %cond.load3581
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1045:                              ; %else3585
                                        ;   in Loop: Header=BB0_1030 Depth=2
	tbz	w8, #7, LBB0_1047
; %bb.1046:                             ; %cond.load3587
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1047:                              ; %else3591
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	w8, s12
	ldr	q7, [sp, #2336]                 ; 16-byte Reload
	ldr	q16, [sp, #10608]               ; 16-byte Reload
	bif.16b	v3, v16, v7
	ldr	q7, [sp, #2288]                 ; 16-byte Reload
	and.16b	v3, v7, v3
	str	q3, [sp, #10608]                ; 16-byte Spill
	ldr	q3, [sp, #3024]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #0, LBB0_1056
; %bb.1048:                             ; %else3597
                                        ;   in Loop: Header=BB0_1030 Depth=2
	tbnz	w8, #1, LBB0_1057
LBB0_1049:                              ; %else3601
                                        ;   in Loop: Header=BB0_1030 Depth=2
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbnz	w8, #2, LBB0_1058
LBB0_1050:                              ; %else3605
                                        ;   in Loop: Header=BB0_1030 Depth=2
	tbz	w8, #3, LBB0_1052
LBB0_1051:                              ; %cond.store3606
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10608]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1052:                              ; %else3609
                                        ;   in Loop: Header=BB0_1030 Depth=2
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	ldr	q3, [sp, #4864]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	and.16b	v1, v1, v0
	ldr	q0, [sp, #3040]                 ; 16-byte Reload
	add.2d	v0, v0, v5
	tbnz	w8, #4, LBB0_1059
; %bb.1053:                             ; %else3613
                                        ;   in Loop: Header=BB0_1030 Depth=2
	tbnz	w8, #5, LBB0_1060
LBB0_1054:                              ; %else3617
                                        ;   in Loop: Header=BB0_1030 Depth=2
	ldr	q0, [sp, #3072]                 ; 16-byte Reload
	add.2d	v0, v0, v6
	tbnz	w8, #6, LBB0_1061
LBB0_1055:                              ; %else3621
                                        ;   in Loop: Header=BB0_1030 Depth=2
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_1029
	b	LBB0_1062
LBB0_1056:                              ; %cond.store3594
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #10608]                ; 16-byte Reload
	str	s3, [x9]
	tbz	w8, #1, LBB0_1049
LBB0_1057:                              ; %cond.store3598
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10608]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbz	w8, #2, LBB0_1050
LBB0_1058:                              ; %cond.store3602
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #10608]                ; 16-byte Reload
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #3, LBB0_1051
	b	LBB0_1052
LBB0_1059:                              ; %cond.store3610
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	x9, d0
	str	s1, [x9]
	tbz	w8, #5, LBB0_1054
LBB0_1060:                              ; %cond.store3614
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[1], [x9]
	ldr	q0, [sp, #3072]                 ; 16-byte Reload
	add.2d	v0, v0, v6
	tbz	w8, #6, LBB0_1055
LBB0_1061:                              ; %cond.store3618
                                        ;   in Loop: Header=BB0_1030 Depth=2
	fmov	x9, d0
	st1.s	{ v1 }[2], [x9]
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_1029
LBB0_1062:                              ; %cond.store3622
                                        ;   in Loop: Header=BB0_1030 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v1 }[3], [x8]
	b	LBB0_1029
LBB0_1063:                              ; %direct.false876
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q0, [sp, #1024]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #9872]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #9872]                 ; 16-byte Spill
	ldr	q3, [sp, #9824]                 ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #9824]                 ; 16-byte Spill
	ldr	q3, [sp, #9808]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #9808]                 ; 16-byte Spill
	ldr	q1, [sp, #1008]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	b	LBB0_1065
LBB0_1064:                              ; %else3707
                                        ;   in Loop: Header=BB0_1065 Depth=2
	str	q1, [sp, #4848]                 ; 16-byte Spill
	ldr	q0, [sp, #9824]                 ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #9824]                 ; 16-byte Spill
	ldr	q0, [sp, #9808]                 ; 16-byte Reload
	add.2d	v0, v0, v15
	str	q0, [sp, #9808]                 ; 16-byte Spill
	ldr	q0, [sp, #9872]                 ; 16-byte Reload
	add.2d	v0, v0, v8
	str	q0, [sp, #9872]                 ; 16-byte Spill
	ldr	q1, [sp, #13312]                ; 16-byte Reload
	add.2d	v0, v29, v1
LBB0_1065:                              ; %direct.false876
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	x8, d0
	cmp	x8, #1
	b.ge	LBB0_1098
; %bb.1066:                             ; %direct.true887
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.16b	v29, v0
	shl.2d	v0, v0, #5
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v0, v1
	ldr	q0, [sp, #5552]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	fmov	w8, s12
	movi.2d	v3, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_1068
; %bb.1067:                             ; %cond.load3627
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	x9, d4
	ldr	s3, [x9]
LBB0_1068:                              ; %else3631
                                        ;   in Loop: Header=BB0_1065 Depth=2
	tbz	w8, #1, LBB0_1070
; %bb.1069:                             ; %cond.load3633
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[1], [x9]
LBB0_1070:                              ; %else3637
                                        ;   in Loop: Header=BB0_1065 Depth=2
	ldr	q4, [sp, #9824]                 ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #12272]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #5584]                 ; 16-byte Reload
	add.2d	v5, v5, v4
	tbz	w8, #2, LBB0_1072
; %bb.1071:                             ; %cond.load3639
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	x9, d5
	ld1.s	{ v3 }[2], [x9]
LBB0_1072:                              ; %else3643
                                        ;   in Loop: Header=BB0_1065 Depth=2
	tbz	w8, #3, LBB0_1074
; %bb.1073:                             ; %cond.load3645
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_1074:                              ; %else3649
                                        ;   in Loop: Header=BB0_1065 Depth=2
	ldr	q5, [sp, #9808]                 ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #12320]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #5568]                 ; 16-byte Reload
	add.2d	v6, v6, v5
	tbz	w8, #4, LBB0_1076
; %bb.1075:                             ; %cond.load3651
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
LBB0_1076:                              ; %else3655
                                        ;   in Loop: Header=BB0_1065 Depth=2
	tbz	w8, #5, LBB0_1078
; %bb.1077:                             ; %cond.load3657
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1078:                              ; %else3661
                                        ;   in Loop: Header=BB0_1065 Depth=2
	ldr	q6, [sp, #9872]                 ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #12288]                ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #5600]                 ; 16-byte Reload
	add.2d	v7, v7, v6
	tbz	w8, #6, LBB0_1080
; %bb.1079:                             ; %cond.load3663
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1080:                              ; %else3667
                                        ;   in Loop: Header=BB0_1065 Depth=2
	tbz	w8, #7, LBB0_1082
; %bb.1081:                             ; %cond.load3669
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1082:                              ; %else3673
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	w8, s12
	ldr	q7, [sp, #2272]                 ; 16-byte Reload
	ldr	q16, [sp, #10592]               ; 16-byte Reload
	bif.16b	v3, v16, v7
	ldr	q7, [sp, #2224]                 ; 16-byte Reload
	and.16b	v3, v7, v3
	str	q3, [sp, #10592]                ; 16-byte Spill
	ldr	q3, [sp, #3152]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #0, LBB0_1091
; %bb.1083:                             ; %else3679
                                        ;   in Loop: Header=BB0_1065 Depth=2
	tbnz	w8, #1, LBB0_1092
LBB0_1084:                              ; %else3683
                                        ;   in Loop: Header=BB0_1065 Depth=2
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbnz	w8, #2, LBB0_1093
LBB0_1085:                              ; %else3687
                                        ;   in Loop: Header=BB0_1065 Depth=2
	tbz	w8, #3, LBB0_1087
LBB0_1086:                              ; %cond.store3688
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10592]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1087:                              ; %else3691
                                        ;   in Loop: Header=BB0_1065 Depth=2
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	ldr	q3, [sp, #4848]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	and.16b	v1, v1, v0
	ldr	q0, [sp, #3168]                 ; 16-byte Reload
	add.2d	v0, v0, v5
	tbnz	w8, #4, LBB0_1094
; %bb.1088:                             ; %else3695
                                        ;   in Loop: Header=BB0_1065 Depth=2
	tbnz	w8, #5, LBB0_1095
LBB0_1089:                              ; %else3699
                                        ;   in Loop: Header=BB0_1065 Depth=2
	ldr	q0, [sp, #3200]                 ; 16-byte Reload
	add.2d	v0, v0, v6
	tbnz	w8, #6, LBB0_1096
LBB0_1090:                              ; %else3703
                                        ;   in Loop: Header=BB0_1065 Depth=2
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_1064
	b	LBB0_1097
LBB0_1091:                              ; %cond.store3676
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #10592]                ; 16-byte Reload
	str	s3, [x9]
	tbz	w8, #1, LBB0_1084
LBB0_1092:                              ; %cond.store3680
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10592]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #3184]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbz	w8, #2, LBB0_1085
LBB0_1093:                              ; %cond.store3684
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #10592]                ; 16-byte Reload
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #3, LBB0_1086
	b	LBB0_1087
LBB0_1094:                              ; %cond.store3692
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	x9, d0
	str	s1, [x9]
	tbz	w8, #5, LBB0_1089
LBB0_1095:                              ; %cond.store3696
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[1], [x9]
	ldr	q0, [sp, #3200]                 ; 16-byte Reload
	add.2d	v0, v0, v6
	tbz	w8, #6, LBB0_1090
LBB0_1096:                              ; %cond.store3700
                                        ;   in Loop: Header=BB0_1065 Depth=2
	fmov	x9, d0
	st1.s	{ v1 }[2], [x9]
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_1064
LBB0_1097:                              ; %cond.store3704
                                        ;   in Loop: Header=BB0_1065 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v1 }[3], [x8]
	b	LBB0_1064
LBB0_1098:                              ; %direct.false888
                                        ;   in Loop: Header=BB0_92 Depth=1
	str	q21, [sp, #1072]                ; 16-byte Spill
	str	q0, [sp, #1008]                 ; 16-byte Spill
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q3, [sp, #11040]                ; 16-byte Reload
	bic.16b	v3, v3, v14
	str	q3, [sp, #11040]                ; 16-byte Spill
	ldr	q3, [sp, #11024]                ; 16-byte Reload
	bic.16b	v3, v3, v11
	str	q3, [sp, #11024]                ; 16-byte Spill
	ldr	q3, [sp, #11008]                ; 16-byte Reload
	bic.16b	v3, v3, v1
	str	q3, [sp, #11008]                ; 16-byte Spill
	bic.16b	v20, v20, v0
	fmov	x8, d20
	cmp	x8, #1
	b.gt	LBB0_90
; %bb.1099:                             ; %direct.true899.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldp	q29, q21, [sp, #736]            ; 32-byte Folded Reload
	b	LBB0_1101
LBB0_1100:                              ; %else3789
                                        ;   in Loop: Header=BB0_1101 Depth=2
	str	q1, [sp, #6384]                 ; 16-byte Spill
	ldr	q0, [sp, #11024]                ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #11024]                ; 16-byte Spill
	ldr	q0, [sp, #11008]                ; 16-byte Reload
	add.2d	v0, v0, v15
	str	q0, [sp, #11008]                ; 16-byte Spill
	ldr	q0, [sp, #11040]                ; 16-byte Reload
	add.2d	v0, v0, v8
	str	q0, [sp, #11040]                ; 16-byte Spill
	ldr	q0, [sp, #13312]                ; 16-byte Reload
	add.2d	v20, v20, v0
	fmov	x8, d20
	cmp	x8, #2
	b.ge	LBB0_91
LBB0_1101:                              ; %direct.true899
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v0, v20, #5
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v0, v1
	ldr	q0, [sp, #7872]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	ldr	d0, [sp, #12344]                ; 8-byte Reload
	fmov	w8, s0
	movi.2d	v3, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_1103
; %bb.1102:                             ; %cond.load3709
                                        ;   in Loop: Header=BB0_1101 Depth=2
	fmov	x9, d4
	ldr	s3, [x9]
LBB0_1103:                              ; %else3713
                                        ;   in Loop: Header=BB0_1101 Depth=2
	tbz	w8, #1, LBB0_1105
; %bb.1104:                             ; %cond.load3715
                                        ;   in Loop: Header=BB0_1101 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[1], [x9]
LBB0_1105:                              ; %else3719
                                        ;   in Loop: Header=BB0_1101 Depth=2
	ldr	q4, [sp, #11024]                ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #12272]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #7904]                 ; 16-byte Reload
	add.2d	v5, v5, v4
	tbz	w8, #2, LBB0_1107
; %bb.1106:                             ; %cond.load3721
                                        ;   in Loop: Header=BB0_1101 Depth=2
	fmov	x9, d5
	ld1.s	{ v3 }[2], [x9]
LBB0_1107:                              ; %else3725
                                        ;   in Loop: Header=BB0_1101 Depth=2
	tbz	w8, #3, LBB0_1109
; %bb.1108:                             ; %cond.load3727
                                        ;   in Loop: Header=BB0_1101 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_1109:                              ; %else3731
                                        ;   in Loop: Header=BB0_1101 Depth=2
	ldr	q5, [sp, #11008]                ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #12320]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #7888]                 ; 16-byte Reload
	add.2d	v6, v6, v5
	tbz	w8, #4, LBB0_1111
; %bb.1110:                             ; %cond.load3733
                                        ;   in Loop: Header=BB0_1101 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
LBB0_1111:                              ; %else3737
                                        ;   in Loop: Header=BB0_1101 Depth=2
	tbz	w8, #5, LBB0_1113
; %bb.1112:                             ; %cond.load3739
                                        ;   in Loop: Header=BB0_1101 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1113:                              ; %else3743
                                        ;   in Loop: Header=BB0_1101 Depth=2
	ldr	q6, [sp, #11040]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #12288]                ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #7920]                 ; 16-byte Reload
	add.2d	v7, v7, v6
	tbz	w8, #6, LBB0_1115
; %bb.1114:                             ; %cond.load3745
                                        ;   in Loop: Header=BB0_1101 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1115:                              ; %else3749
                                        ;   in Loop: Header=BB0_1101 Depth=2
	tbz	w8, #7, LBB0_1117
; %bb.1116:                             ; %cond.load3751
                                        ;   in Loop: Header=BB0_1101 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1117:                              ; %else3755
                                        ;   in Loop: Header=BB0_1101 Depth=2
	ldr	d7, [sp, #12344]                ; 8-byte Reload
	fmov	w8, s7
	ldr	q7, [sp, #3904]                 ; 16-byte Reload
	ldr	q16, [sp, #11392]               ; 16-byte Reload
	bif.16b	v3, v16, v7
	ldr	q7, [sp, #3856]                 ; 16-byte Reload
	and.16b	v3, v7, v3
	str	q3, [sp, #11392]                ; 16-byte Spill
	ldr	q3, [sp, #9728]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #0, LBB0_1126
; %bb.1118:                             ; %else3761
                                        ;   in Loop: Header=BB0_1101 Depth=2
	tbnz	w8, #1, LBB0_1127
LBB0_1119:                              ; %else3765
                                        ;   in Loop: Header=BB0_1101 Depth=2
	ldr	q1, [sp, #9760]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbnz	w8, #2, LBB0_1128
LBB0_1120:                              ; %else3769
                                        ;   in Loop: Header=BB0_1101 Depth=2
	tbz	w8, #3, LBB0_1122
LBB0_1121:                              ; %cond.store3770
                                        ;   in Loop: Header=BB0_1101 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11392]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1122:                              ; %else3773
                                        ;   in Loop: Header=BB0_1101 Depth=2
	ldr	q1, [sp, #3888]                 ; 16-byte Reload
	ldr	q3, [sp, #6384]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	ldr	q1, [sp, #3872]                 ; 16-byte Reload
	and.16b	v1, v1, v0
	ldr	q0, [sp, #9744]                 ; 16-byte Reload
	add.2d	v0, v0, v5
	tbnz	w8, #4, LBB0_1129
; %bb.1123:                             ; %else3777
                                        ;   in Loop: Header=BB0_1101 Depth=2
	tbnz	w8, #5, LBB0_1130
LBB0_1124:                              ; %else3781
                                        ;   in Loop: Header=BB0_1101 Depth=2
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	add.2d	v0, v0, v6
	tbnz	w8, #6, LBB0_1131
LBB0_1125:                              ; %else3785
                                        ;   in Loop: Header=BB0_1101 Depth=2
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_1100
	b	LBB0_1132
LBB0_1126:                              ; %cond.store3758
                                        ;   in Loop: Header=BB0_1101 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #11392]                ; 16-byte Reload
	str	s3, [x9]
	tbz	w8, #1, LBB0_1119
LBB0_1127:                              ; %cond.store3762
                                        ;   in Loop: Header=BB0_1101 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11392]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #9760]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbz	w8, #2, LBB0_1120
LBB0_1128:                              ; %cond.store3766
                                        ;   in Loop: Header=BB0_1101 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #11392]                ; 16-byte Reload
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #3, LBB0_1121
	b	LBB0_1122
LBB0_1129:                              ; %cond.store3774
                                        ;   in Loop: Header=BB0_1101 Depth=2
	fmov	x9, d0
	str	s1, [x9]
	tbz	w8, #5, LBB0_1124
LBB0_1130:                              ; %cond.store3778
                                        ;   in Loop: Header=BB0_1101 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[1], [x9]
	ldr	q0, [sp, #9776]                 ; 16-byte Reload
	add.2d	v0, v0, v6
	tbz	w8, #6, LBB0_1125
LBB0_1131:                              ; %cond.store3782
                                        ;   in Loop: Header=BB0_1101 Depth=2
	fmov	x9, d0
	st1.s	{ v1 }[2], [x9]
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_1100
LBB0_1132:                              ; %cond.store3786
                                        ;   in Loop: Header=BB0_1101 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v1 }[3], [x8]
	b	LBB0_1100
LBB0_1133:                              ; %direct.true490.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldp	q3, q1, [sp, #64]               ; 32-byte Folded Reload
	ldr	q21, [sp, #1520]                ; 16-byte Reload
	ldr	q29, [sp, #1488]                ; 16-byte Reload
	ldr	q15, [sp, #1360]                ; 16-byte Reload
	ldr	d23, [sp, #11576]               ; 8-byte Reload
	b	LBB0_1135
LBB0_1134:                              ; %else1233
                                        ;   in Loop: Header=BB0_1135 Depth=2
	ldr	q0, [sp, #10448]                ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #10448]                ; 16-byte Spill
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	add.2d	v0, v0, v27
	str	q0, [sp, #10432]                ; 16-byte Spill
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	add.2d	v0, v0, v8
	str	q0, [sp, #10416]                ; 16-byte Spill
	add.2d	v0, v7, v20
	fmov	x9, d0
	cmp	x9, #1
	b.ge	LBB0_403
LBB0_1135:                              ; %direct.true490
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v7, v0
	shl.2d	v0, v0, #6
	ldr	q4, [sp, #3808]                 ; 16-byte Reload
	orr.16b	v0, v0, v4
	ldr	q4, [sp, #3744]                 ; 16-byte Reload
	add.2d	v0, v4, v0
	fmov	w9, s23
	tbz	w9, #0, LBB0_1137
; %bb.1136:                             ; %cond.store1202
                                        ;   in Loop: Header=BB0_1135 Depth=2
	fmov	x10, d0
	ldr	q4, [sp, #2928]                 ; 16-byte Reload
	str	d4, [x10]
LBB0_1137:                              ; %else1205
                                        ;   in Loop: Header=BB0_1135 Depth=2
	tbz	w9, #1, LBB0_1139
; %bb.1138:                             ; %cond.store1206
                                        ;   in Loop: Header=BB0_1135 Depth=2
	mov.d	x10, v0[1]
	ldr	q0, [sp, #2928]                 ; 16-byte Reload
	st1.d	{ v0 }[1], [x10]
LBB0_1139:                              ; %else1209
                                        ;   in Loop: Header=BB0_1135 Depth=2
	ldr	q0, [sp, #10448]                ; 16-byte Reload
	shl.2d	v0, v0, #6
	ldr	q4, [sp, #3792]                 ; 16-byte Reload
	orr.16b	v0, v0, v4
	ldr	q4, [sp, #3728]                 ; 16-byte Reload
	add.2d	v0, v4, v0
	tbz	w9, #2, LBB0_1141
; %bb.1140:                             ; %cond.store1210
                                        ;   in Loop: Header=BB0_1135 Depth=2
	fmov	x10, d0
	ldr	q4, [sp, #2944]                 ; 16-byte Reload
	str	d4, [x10]
LBB0_1141:                              ; %else1213
                                        ;   in Loop: Header=BB0_1135 Depth=2
	tbz	w9, #3, LBB0_1143
; %bb.1142:                             ; %cond.store1214
                                        ;   in Loop: Header=BB0_1135 Depth=2
	mov.d	x10, v0[1]
	ldr	q0, [sp, #2944]                 ; 16-byte Reload
	st1.d	{ v0 }[1], [x10]
LBB0_1143:                              ; %else1217
                                        ;   in Loop: Header=BB0_1135 Depth=2
	ldr	q0, [sp, #10432]                ; 16-byte Reload
	shl.2d	v0, v0, #6
	ldr	q4, [sp, #3776]                 ; 16-byte Reload
	orr.16b	v0, v0, v4
	ldr	q2, [sp, #3824]                 ; 16-byte Reload
	add.2d	v0, v2, v0
	tbnz	w9, #4, LBB0_1147
; %bb.1144:                             ; %else1221
                                        ;   in Loop: Header=BB0_1135 Depth=2
	tbnz	w9, #5, LBB0_1148
LBB0_1145:                              ; %else1225
                                        ;   in Loop: Header=BB0_1135 Depth=2
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	shl.2d	v0, v0, #6
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	orr.16b	v0, v0, v4
	add.2d	v0, v6, v0
	tbnz	w9, #6, LBB0_1149
LBB0_1146:                              ; %else1229
                                        ;   in Loop: Header=BB0_1135 Depth=2
	tbz	w9, #7, LBB0_1134
	b	LBB0_1150
LBB0_1147:                              ; %cond.store1218
                                        ;   in Loop: Header=BB0_1135 Depth=2
	fmov	x10, d0
	str	d1, [x10]
	tbz	w9, #5, LBB0_1145
LBB0_1148:                              ; %cond.store1222
                                        ;   in Loop: Header=BB0_1135 Depth=2
	mov.d	x10, v0[1]
	st1.d	{ v1 }[1], [x10]
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	shl.2d	v0, v0, #6
	ldr	q4, [sp, #3760]                 ; 16-byte Reload
	orr.16b	v0, v0, v4
	add.2d	v0, v6, v0
	tbz	w9, #6, LBB0_1146
LBB0_1149:                              ; %cond.store1226
                                        ;   in Loop: Header=BB0_1135 Depth=2
	fmov	x10, d0
	str	d3, [x10]
	tbz	w9, #7, LBB0_1134
LBB0_1150:                              ; %cond.store1230
                                        ;   in Loop: Header=BB0_1135 Depth=2
	mov.d	x9, v0[1]
	st1.d	{ v3 }[1], [x9]
	b	LBB0_1134
LBB0_1151:                              ; %direct.true498.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q0, [sp, #3808]                 ; 16-byte Reload
	ldr	q1, [sp, #3744]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	q1, [sp, #3792]                 ; 16-byte Reload
	ldr	q3, [sp, #3728]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q3, [sp, #3776]                 ; 16-byte Reload
	ldr	q2, [sp, #3824]                 ; 16-byte Reload
	add.2d	v4, v2, v3
	ldr	q3, [sp, #3760]                 ; 16-byte Reload
	add.2d	v5, v6, v3
	b	LBB0_1153
LBB0_1152:                              ; %else1315
                                        ;   in Loop: Header=BB0_1153 Depth=2
	ldr	q3, [sp, #10384]                ; 16-byte Reload
	add.2d	v3, v3, v10
	str	q3, [sp, #10384]                ; 16-byte Spill
	ldr	q3, [sp, #10368]                ; 16-byte Reload
	add.2d	v3, v3, v27
	str	q3, [sp, #10368]                ; 16-byte Spill
	ldr	q3, [sp, #10352]                ; 16-byte Reload
	add.2d	v3, v3, v8
	str	q3, [sp, #10352]                ; 16-byte Spill
	ldr	q3, [sp, #10400]                ; 16-byte Reload
	add.2d	v3, v3, v20
	str	q3, [sp, #10400]                ; 16-byte Spill
	fmov	x9, d3
	cmp	x9, #1
	b.ge	LBB0_404
LBB0_1153:                              ; %direct.true498
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s23
	tbz	w9, #0, LBB0_1155
; %bb.1154:                             ; %cond.load1235
                                        ;   in Loop: Header=BB0_1153 Depth=2
	fmov	x10, d0
	ldr	d3, [x10]
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #1, LBB0_1156
	b	LBB0_1157
LBB0_1155:                              ;   in Loop: Header=BB0_1153 Depth=2
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w9, #1, LBB0_1157
LBB0_1156:                              ; %cond.load1241
                                        ;   in Loop: Header=BB0_1153 Depth=2
	mov.d	x10, v0[1]
	ld1.d	{ v3 }[1], [x10]
LBB0_1157:                              ; %else1245
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbnz	w9, #2, LBB0_1180
; %bb.1158:                             ; %else1251
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbnz	w9, #3, LBB0_1181
LBB0_1159:                              ; %else1257
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbnz	w9, #4, LBB0_1182
LBB0_1160:                              ; %else1263
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbnz	w9, #5, LBB0_1183
LBB0_1161:                              ; %else1269
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbnz	w9, #6, LBB0_1184
LBB0_1162:                              ; %else1275
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbz	w9, #7, LBB0_1164
LBB0_1163:                              ; %cond.load1277
                                        ;   in Loop: Header=BB0_1153 Depth=2
	mov.d	x9, v5[1]
	ld1.d	{ v6 }[1], [x9]
LBB0_1164:                              ; %else1281
                                        ;   in Loop: Header=BB0_1153 Depth=2
	ldr	q18, [sp, #11600]               ; 16-byte Reload
	mov	b17, v18[0]
	mov.b	v17[4], v18[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q18, [sp, #5520]                ; 16-byte Reload
	bif.16b	v3, v18, v17
	fmov	w9, s23
	ldr	q18, [sp, #11584]               ; 16-byte Reload
	mov	b17, v18[0]
	mov.b	v17[4], v18[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmge.2d	v17, v17, #0
	and.16b	v17, v17, v3
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	str	q17, [sp, #5520]                ; 16-byte Spill
	add.2d	v3, v17, v3
	ldr	q17, [sp, #10400]               ; 16-byte Reload
	shl.2d	v17, v17, #6
	ldr	q18, [sp, #3680]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #3616]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w9, #0, LBB0_1166
; %bb.1165:                             ; %cond.store1284
                                        ;   in Loop: Header=BB0_1153 Depth=2
	fmov	x10, d17
	str	d3, [x10]
LBB0_1166:                              ; %else1287
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbz	w9, #1, LBB0_1168
; %bb.1167:                             ; %cond.store1288
                                        ;   in Loop: Header=BB0_1153 Depth=2
	mov.d	x10, v17[1]
	st1.d	{ v3 }[1], [x10]
LBB0_1168:                              ; %else1291
                                        ;   in Loop: Header=BB0_1153 Depth=2
	ldr	q17, [sp, #11600]               ; 16-byte Reload
	mov	b3, v17[2]
	mov.b	v3[4], v17[3]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q17, [sp, #5536]                ; 16-byte Reload
	bsl.16b	v3, v16, v17
	ldr	q17, [sp, #11584]               ; 16-byte Reload
	mov	b16, v17[2]
	mov.b	v16[4], v17[3]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmge.2d	v16, v16, #0
	and.16b	v16, v16, v3
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	str	q16, [sp, #5536]                ; 16-byte Spill
	add.2d	v3, v16, v3
	ldr	q16, [sp, #10384]               ; 16-byte Reload
	shl.2d	v16, v16, #6
	ldr	q17, [sp, #3664]                ; 16-byte Reload
	orr.16b	v16, v16, v17
	ldr	q17, [sp, #3600]                ; 16-byte Reload
	add.2d	v16, v17, v16
	tbz	w9, #2, LBB0_1170
; %bb.1169:                             ; %cond.store1292
                                        ;   in Loop: Header=BB0_1153 Depth=2
	fmov	x10, d16
	str	d3, [x10]
LBB0_1170:                              ; %else1295
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbz	w9, #3, LBB0_1172
; %bb.1171:                             ; %cond.store1296
                                        ;   in Loop: Header=BB0_1153 Depth=2
	mov.d	x10, v16[1]
	st1.d	{ v3 }[1], [x10]
LBB0_1172:                              ; %else1299
                                        ;   in Loop: Header=BB0_1153 Depth=2
	ldr	q16, [sp, #11600]               ; 16-byte Reload
	mov	b3, v16[4]
	mov.b	v3[4], v16[5]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q16, [sp, #5504]                ; 16-byte Reload
	bsl.16b	v3, v7, v16
	ldr	q16, [sp, #11584]               ; 16-byte Reload
	mov	b7, v16[4]
	mov.b	v7[4], v16[5]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmge.2d	v7, v7, #0
	and.16b	v7, v7, v3
	ldr	q3, [sp, #3120]                 ; 16-byte Reload
	str	q7, [sp, #5504]                 ; 16-byte Spill
	add.2d	v3, v7, v3
	ldr	q7, [sp, #10368]                ; 16-byte Reload
	shl.2d	v7, v7, #6
	ldr	q16, [sp, #3648]                ; 16-byte Reload
	orr.16b	v7, v7, v16
	ldr	q16, [sp, #3712]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbz	w9, #4, LBB0_1174
; %bb.1173:                             ; %cond.store1300
                                        ;   in Loop: Header=BB0_1153 Depth=2
	fmov	x10, d7
	str	d3, [x10]
LBB0_1174:                              ; %else1303
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbz	w9, #5, LBB0_1176
; %bb.1175:                             ; %cond.store1304
                                        ;   in Loop: Header=BB0_1153 Depth=2
	mov.d	x10, v7[1]
	st1.d	{ v3 }[1], [x10]
LBB0_1176:                              ; %else1307
                                        ;   in Loop: Header=BB0_1153 Depth=2
	ldr	q7, [sp, #11600]                ; 16-byte Reload
	mov	b3, v7[6]
	mov.b	v3[4], v7[7]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q7, [sp, #5488]                 ; 16-byte Reload
	bsl.16b	v3, v6, v7
	ldr	q7, [sp, #11584]                ; 16-byte Reload
	mov	b6, v7[6]
	mov.b	v6[4], v7[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmge.2d	v6, v6, #0
	and.16b	v6, v6, v3
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	str	q6, [sp, #5488]                 ; 16-byte Spill
	add.2d	v3, v6, v3
	ldr	q6, [sp, #10352]                ; 16-byte Reload
	shl.2d	v6, v6, #6
	ldr	q7, [sp, #3632]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #3696]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #6, LBB0_1178
; %bb.1177:                             ; %cond.store1308
                                        ;   in Loop: Header=BB0_1153 Depth=2
	fmov	x10, d6
	str	d3, [x10]
LBB0_1178:                              ; %else1311
                                        ;   in Loop: Header=BB0_1153 Depth=2
	tbz	w9, #7, LBB0_1152
; %bb.1179:                             ; %cond.store1312
                                        ;   in Loop: Header=BB0_1153 Depth=2
	mov.d	x9, v6[1]
	st1.d	{ v3 }[1], [x9]
	b	LBB0_1152
LBB0_1180:                              ; %cond.load1247
                                        ;   in Loop: Header=BB0_1153 Depth=2
	fmov	x10, d1
	ld1.d	{ v16 }[0], [x10]
	tbz	w9, #3, LBB0_1159
LBB0_1181:                              ; %cond.load1253
                                        ;   in Loop: Header=BB0_1153 Depth=2
	mov.d	x10, v1[1]
	ld1.d	{ v16 }[1], [x10]
	tbz	w9, #4, LBB0_1160
LBB0_1182:                              ; %cond.load1259
                                        ;   in Loop: Header=BB0_1153 Depth=2
	fmov	x10, d4
	ld1.d	{ v7 }[0], [x10]
	tbz	w9, #5, LBB0_1161
LBB0_1183:                              ; %cond.load1265
                                        ;   in Loop: Header=BB0_1153 Depth=2
	mov.d	x10, v4[1]
	ld1.d	{ v7 }[1], [x10]
	tbz	w9, #6, LBB0_1162
LBB0_1184:                              ; %cond.load1271
                                        ;   in Loop: Header=BB0_1153 Depth=2
	fmov	x10, d5
	ld1.d	{ v6 }[0], [x10]
	tbnz	w9, #7, LBB0_1163
	b	LBB0_1164
LBB0_1185:                              ; %direct.true510.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q0, [sp, #3680]                 ; 16-byte Reload
	ldr	q1, [sp, #3616]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	q1, [sp, #3664]                 ; 16-byte Reload
	ldr	q3, [sp, #3600]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q3, [sp, #3712]                 ; 16-byte Reload
	ldr	q4, [sp, #3648]                 ; 16-byte Reload
	add.2d	v4, v3, v4
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	ldr	q5, [sp, #3632]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	b	LBB0_1187
LBB0_1186:                              ; %else1397
                                        ;   in Loop: Header=BB0_1187 Depth=2
	ldr	q3, [sp, #10320]                ; 16-byte Reload
	add.2d	v3, v3, v10
	str	q3, [sp, #10320]                ; 16-byte Spill
	ldr	q3, [sp, #10304]                ; 16-byte Reload
	add.2d	v3, v3, v27
	str	q3, [sp, #10304]                ; 16-byte Spill
	ldr	q3, [sp, #10288]                ; 16-byte Reload
	add.2d	v3, v3, v8
	str	q3, [sp, #10288]                ; 16-byte Spill
	ldr	q3, [sp, #10336]                ; 16-byte Reload
	add.2d	v3, v3, v20
	str	q3, [sp, #10336]                ; 16-byte Spill
	fmov	x9, d3
	cmp	x9, #1
	b.ge	LBB0_405
LBB0_1187:                              ; %direct.true510
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s23
	tbz	w9, #0, LBB0_1189
; %bb.1188:                             ; %cond.load1317
                                        ;   in Loop: Header=BB0_1187 Depth=2
	fmov	x10, d0
	ldr	d3, [x10]
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #1, LBB0_1190
	b	LBB0_1191
LBB0_1189:                              ;   in Loop: Header=BB0_1187 Depth=2
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w9, #1, LBB0_1191
LBB0_1190:                              ; %cond.load1323
                                        ;   in Loop: Header=BB0_1187 Depth=2
	mov.d	x10, v0[1]
	ld1.d	{ v3 }[1], [x10]
LBB0_1191:                              ; %else1327
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbnz	w9, #2, LBB0_1214
; %bb.1192:                             ; %else1333
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbnz	w9, #3, LBB0_1215
LBB0_1193:                              ; %else1339
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbnz	w9, #4, LBB0_1216
LBB0_1194:                              ; %else1345
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbnz	w9, #5, LBB0_1217
LBB0_1195:                              ; %else1351
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbnz	w9, #6, LBB0_1218
LBB0_1196:                              ; %else1357
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbz	w9, #7, LBB0_1198
LBB0_1197:                              ; %cond.load1359
                                        ;   in Loop: Header=BB0_1187 Depth=2
	mov.d	x9, v5[1]
	ld1.d	{ v6 }[1], [x9]
LBB0_1198:                              ; %else1363
                                        ;   in Loop: Header=BB0_1187 Depth=2
	ldr	q18, [sp, #11600]               ; 16-byte Reload
	mov	b17, v18[0]
	mov.b	v17[4], v18[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q18, [sp, #5424]                ; 16-byte Reload
	bif.16b	v3, v18, v17
	fmov	w9, s23
	ldr	q18, [sp, #11584]               ; 16-byte Reload
	mov	b17, v18[0]
	mov.b	v17[4], v18[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmge.2d	v17, v17, #0
	and.16b	v17, v17, v3
	mov	w10, #67                        ; =0x43
	dup.2d	v3, x10
	str	q17, [sp, #5424]                ; 16-byte Spill
	add.2d	v17, v17, v3
	ldr	q18, [sp, #10336]               ; 16-byte Reload
	shl.2d	v18, v18, #6
	ldr	q19, [sp, #3488]                ; 16-byte Reload
	orr.16b	v18, v18, v19
	ldr	q19, [sp, #3552]                ; 16-byte Reload
	add.2d	v18, v19, v18
	tbz	w9, #0, LBB0_1200
; %bb.1199:                             ; %cond.store1366
                                        ;   in Loop: Header=BB0_1187 Depth=2
	fmov	x10, d18
	str	d17, [x10]
LBB0_1200:                              ; %else1369
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbz	w9, #1, LBB0_1202
; %bb.1201:                             ; %cond.store1370
                                        ;   in Loop: Header=BB0_1187 Depth=2
	mov.d	x10, v18[1]
	st1.d	{ v17 }[1], [x10]
LBB0_1202:                              ; %else1373
                                        ;   in Loop: Header=BB0_1187 Depth=2
	ldr	q18, [sp, #11600]               ; 16-byte Reload
	mov	b17, v18[2]
	mov.b	v17[4], v18[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q18, [sp, #5440]                ; 16-byte Reload
	bif.16b	v16, v18, v17
	ldr	q18, [sp, #11584]               ; 16-byte Reload
	mov	b17, v18[2]
	mov.b	v17[4], v18[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmge.2d	v17, v17, #0
	and.16b	v16, v17, v16
	str	q16, [sp, #5440]                ; 16-byte Spill
	add.2d	v16, v16, v3
	ldr	q17, [sp, #10320]               ; 16-byte Reload
	shl.2d	v17, v17, #6
	ldr	q18, [sp, #3472]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #3536]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w9, #2, LBB0_1204
; %bb.1203:                             ; %cond.store1374
                                        ;   in Loop: Header=BB0_1187 Depth=2
	fmov	x10, d17
	str	d16, [x10]
LBB0_1204:                              ; %else1377
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbz	w9, #3, LBB0_1206
; %bb.1205:                             ; %cond.store1378
                                        ;   in Loop: Header=BB0_1187 Depth=2
	mov.d	x10, v17[1]
	st1.d	{ v16 }[1], [x10]
LBB0_1206:                              ; %else1381
                                        ;   in Loop: Header=BB0_1187 Depth=2
	ldr	q17, [sp, #11600]               ; 16-byte Reload
	mov	b16, v17[4]
	mov.b	v16[4], v17[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	ldr	q17, [sp, #5472]                ; 16-byte Reload
	bif.16b	v7, v17, v16
	ldr	q17, [sp, #11584]               ; 16-byte Reload
	mov	b16, v17[4]
	mov.b	v16[4], v17[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmge.2d	v16, v16, #0
	and.16b	v7, v16, v7
	str	q7, [sp, #5472]                 ; 16-byte Spill
	add.2d	v7, v7, v3
	ldr	q16, [sp, #10304]               ; 16-byte Reload
	shl.2d	v16, v16, #6
	ldr	q17, [sp, #3584]                ; 16-byte Reload
	orr.16b	v16, v16, v17
	ldr	q17, [sp, #3520]                ; 16-byte Reload
	add.2d	v16, v17, v16
	tbz	w9, #4, LBB0_1208
; %bb.1207:                             ; %cond.store1382
                                        ;   in Loop: Header=BB0_1187 Depth=2
	fmov	x10, d16
	str	d7, [x10]
LBB0_1208:                              ; %else1385
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbz	w9, #5, LBB0_1210
; %bb.1209:                             ; %cond.store1386
                                        ;   in Loop: Header=BB0_1187 Depth=2
	mov.d	x10, v16[1]
	st1.d	{ v7 }[1], [x10]
LBB0_1210:                              ; %else1389
                                        ;   in Loop: Header=BB0_1187 Depth=2
	ldr	q16, [sp, #11600]               ; 16-byte Reload
	mov	b7, v16[6]
	mov.b	v7[4], v16[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	ldr	q16, [sp, #5456]                ; 16-byte Reload
	bif.16b	v6, v16, v7
	ldr	q16, [sp, #11584]               ; 16-byte Reload
	mov	b7, v16[6]
	mov.b	v7[4], v16[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmge.2d	v7, v7, #0
	and.16b	v6, v7, v6
	str	q6, [sp, #5456]                 ; 16-byte Spill
	add.2d	v3, v6, v3
	ldr	q6, [sp, #10288]                ; 16-byte Reload
	shl.2d	v6, v6, #6
	ldr	q7, [sp, #3568]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #3504]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #6, LBB0_1212
; %bb.1211:                             ; %cond.store1390
                                        ;   in Loop: Header=BB0_1187 Depth=2
	fmov	x10, d6
	str	d3, [x10]
LBB0_1212:                              ; %else1393
                                        ;   in Loop: Header=BB0_1187 Depth=2
	tbz	w9, #7, LBB0_1186
; %bb.1213:                             ; %cond.store1394
                                        ;   in Loop: Header=BB0_1187 Depth=2
	mov.d	x9, v6[1]
	st1.d	{ v3 }[1], [x9]
	b	LBB0_1186
LBB0_1214:                              ; %cond.load1329
                                        ;   in Loop: Header=BB0_1187 Depth=2
	fmov	x10, d1
	ld1.d	{ v16 }[0], [x10]
	tbz	w9, #3, LBB0_1193
LBB0_1215:                              ; %cond.load1335
                                        ;   in Loop: Header=BB0_1187 Depth=2
	mov.d	x10, v1[1]
	ld1.d	{ v16 }[1], [x10]
	tbz	w9, #4, LBB0_1194
LBB0_1216:                              ; %cond.load1341
                                        ;   in Loop: Header=BB0_1187 Depth=2
	fmov	x10, d4
	ld1.d	{ v7 }[0], [x10]
	tbz	w9, #5, LBB0_1195
LBB0_1217:                              ; %cond.load1347
                                        ;   in Loop: Header=BB0_1187 Depth=2
	mov.d	x10, v4[1]
	ld1.d	{ v7 }[1], [x10]
	tbz	w9, #6, LBB0_1196
LBB0_1218:                              ; %cond.load1353
                                        ;   in Loop: Header=BB0_1187 Depth=2
	fmov	x10, d5
	ld1.d	{ v6 }[0], [x10]
	tbnz	w9, #7, LBB0_1197
	b	LBB0_1198
LBB0_1219:                              ; %direct.true521.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q0, [sp, #3552]                 ; 16-byte Reload
	ldr	q1, [sp, #3488]                 ; 16-byte Reload
	add.2d	v0, v0, v1
	ldr	q1, [sp, #3536]                 ; 16-byte Reload
	ldr	q3, [sp, #3472]                 ; 16-byte Reload
	add.2d	v1, v1, v3
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	ldr	q4, [sp, #3520]                 ; 16-byte Reload
	add.2d	v4, v4, v3
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	ldr	q5, [sp, #3504]                 ; 16-byte Reload
	add.2d	v5, v5, v3
	b	LBB0_1221
LBB0_1220:                              ; %else1479
                                        ;   in Loop: Header=BB0_1221 Depth=2
	ldr	q3, [sp, #10224]                ; 16-byte Reload
	add.2d	v3, v3, v10
	str	q3, [sp, #10224]                ; 16-byte Spill
	ldr	q3, [sp, #10272]                ; 16-byte Reload
	add.2d	v3, v3, v27
	str	q3, [sp, #10272]                ; 16-byte Spill
	ldr	q3, [sp, #10256]                ; 16-byte Reload
	add.2d	v3, v3, v8
	str	q3, [sp, #10256]                ; 16-byte Spill
	ldr	q3, [sp, #10240]                ; 16-byte Reload
	add.2d	v3, v3, v20
	str	q3, [sp, #10240]                ; 16-byte Spill
	fmov	x9, d3
	cmp	x9, #1
	b.ge	LBB0_406
LBB0_1221:                              ; %direct.true521
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s23
	tbz	w9, #0, LBB0_1223
; %bb.1222:                             ; %cond.load1399
                                        ;   in Loop: Header=BB0_1221 Depth=2
	fmov	x10, d0
	ldr	d3, [x10]
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #1, LBB0_1224
	b	LBB0_1225
LBB0_1223:                              ;   in Loop: Header=BB0_1221 Depth=2
	movi.2d	v3, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w9, #1, LBB0_1225
LBB0_1224:                              ; %cond.load1405
                                        ;   in Loop: Header=BB0_1221 Depth=2
	mov.d	x10, v0[1]
	ld1.d	{ v3 }[1], [x10]
LBB0_1225:                              ; %else1409
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbnz	w9, #2, LBB0_1248
; %bb.1226:                             ; %else1415
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbnz	w9, #3, LBB0_1249
LBB0_1227:                              ; %else1421
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbnz	w9, #4, LBB0_1250
LBB0_1228:                              ; %else1427
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbnz	w9, #5, LBB0_1251
LBB0_1229:                              ; %else1433
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbnz	w9, #6, LBB0_1252
LBB0_1230:                              ; %else1439
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbz	w9, #7, LBB0_1232
LBB0_1231:                              ; %cond.load1441
                                        ;   in Loop: Header=BB0_1221 Depth=2
	mov.d	x9, v5[1]
	ld1.d	{ v6 }[1], [x9]
LBB0_1232:                              ; %else1445
                                        ;   in Loop: Header=BB0_1221 Depth=2
	ldr	q18, [sp, #11600]               ; 16-byte Reload
	mov	b17, v18[0]
	mov.b	v17[4], v18[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q18, [sp, #5392]                ; 16-byte Reload
	bif.16b	v3, v18, v17
	fmov	w9, s23
	ldr	q18, [sp, #11584]               ; 16-byte Reload
	mov	b17, v18[0]
	mov.b	v17[4], v18[1]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmge.2d	v17, v17, #0
	and.16b	v17, v17, v3
	mov	x10, #-3                        ; =0xfffffffffffffffd
	dup.2d	v3, x10
	str	q17, [sp, #5392]                ; 16-byte Spill
	add.2d	v17, v17, v3
	ldr	q18, [sp, #10240]               ; 16-byte Reload
	shl.2d	v18, v18, #6
	ldr	q19, [sp, #6192]                ; 16-byte Reload
	orr.16b	v18, v18, v19
	ldr	q19, [sp, #6128]                ; 16-byte Reload
	add.2d	v18, v19, v18
	tbz	w9, #0, LBB0_1234
; %bb.1233:                             ; %cond.store1448
                                        ;   in Loop: Header=BB0_1221 Depth=2
	fmov	x10, d18
	str	d17, [x10]
LBB0_1234:                              ; %else1451
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbz	w9, #1, LBB0_1236
; %bb.1235:                             ; %cond.store1452
                                        ;   in Loop: Header=BB0_1221 Depth=2
	mov.d	x10, v18[1]
	st1.d	{ v17 }[1], [x10]
LBB0_1236:                              ; %else1455
                                        ;   in Loop: Header=BB0_1221 Depth=2
	ldr	q18, [sp, #11600]               ; 16-byte Reload
	mov	b17, v18[2]
	mov.b	v17[4], v18[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmlt.2d	v17, v17, #0
	ldr	q18, [sp, #5408]                ; 16-byte Reload
	bif.16b	v16, v18, v17
	ldr	q18, [sp, #11584]               ; 16-byte Reload
	mov	b17, v18[2]
	mov.b	v17[4], v18[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmge.2d	v17, v17, #0
	and.16b	v16, v17, v16
	str	q16, [sp, #5408]                ; 16-byte Spill
	add.2d	v16, v16, v3
	ldr	q17, [sp, #10224]               ; 16-byte Reload
	shl.2d	v17, v17, #6
	ldr	q18, [sp, #6176]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #6112]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w9, #2, LBB0_1238
; %bb.1237:                             ; %cond.store1456
                                        ;   in Loop: Header=BB0_1221 Depth=2
	fmov	x10, d17
	str	d16, [x10]
LBB0_1238:                              ; %else1459
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbz	w9, #3, LBB0_1240
; %bb.1239:                             ; %cond.store1460
                                        ;   in Loop: Header=BB0_1221 Depth=2
	mov.d	x10, v17[1]
	st1.d	{ v16 }[1], [x10]
LBB0_1240:                              ; %else1463
                                        ;   in Loop: Header=BB0_1221 Depth=2
	ldr	q17, [sp, #11600]               ; 16-byte Reload
	mov	b16, v17[4]
	mov.b	v16[4], v17[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	ldr	q17, [sp, #5376]                ; 16-byte Reload
	bif.16b	v7, v17, v16
	ldr	q17, [sp, #11584]               ; 16-byte Reload
	mov	b16, v17[4]
	mov.b	v16[4], v17[5]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmge.2d	v16, v16, #0
	and.16b	v7, v16, v7
	str	q7, [sp, #5376]                 ; 16-byte Spill
	add.2d	v7, v7, v3
	ldr	q16, [sp, #10272]               ; 16-byte Reload
	shl.2d	v16, v16, #6
	ldr	q17, [sp, #6160]                ; 16-byte Reload
	orr.16b	v16, v16, v17
	ldr	q17, [sp, #6096]                ; 16-byte Reload
	add.2d	v16, v17, v16
	tbz	w9, #4, LBB0_1242
; %bb.1241:                             ; %cond.store1464
                                        ;   in Loop: Header=BB0_1221 Depth=2
	fmov	x10, d16
	str	d7, [x10]
LBB0_1242:                              ; %else1467
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbz	w9, #5, LBB0_1244
; %bb.1243:                             ; %cond.store1468
                                        ;   in Loop: Header=BB0_1221 Depth=2
	mov.d	x10, v16[1]
	st1.d	{ v7 }[1], [x10]
LBB0_1244:                              ; %else1471
                                        ;   in Loop: Header=BB0_1221 Depth=2
	ldr	q16, [sp, #11600]               ; 16-byte Reload
	mov	b7, v16[6]
	mov.b	v7[4], v16[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	bif.16b	v6, v21, v7
	ldr	q16, [sp, #11584]               ; 16-byte Reload
	mov	b7, v16[6]
	mov.b	v7[4], v16[7]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmge.2d	v7, v7, #0
	and.16b	v21, v7, v6
	add.2d	v3, v21, v3
	ldr	q6, [sp, #10256]                ; 16-byte Reload
	shl.2d	v6, v6, #6
	ldr	q7, [sp, #6144]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #6080]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #6, LBB0_1246
; %bb.1245:                             ; %cond.store1472
                                        ;   in Loop: Header=BB0_1221 Depth=2
	fmov	x10, d6
	str	d3, [x10]
LBB0_1246:                              ; %else1475
                                        ;   in Loop: Header=BB0_1221 Depth=2
	tbz	w9, #7, LBB0_1220
; %bb.1247:                             ; %cond.store1476
                                        ;   in Loop: Header=BB0_1221 Depth=2
	mov.d	x9, v6[1]
	st1.d	{ v3 }[1], [x9]
	b	LBB0_1220
LBB0_1248:                              ; %cond.load1411
                                        ;   in Loop: Header=BB0_1221 Depth=2
	fmov	x10, d1
	ld1.d	{ v16 }[0], [x10]
	tbz	w9, #3, LBB0_1227
LBB0_1249:                              ; %cond.load1417
                                        ;   in Loop: Header=BB0_1221 Depth=2
	mov.d	x10, v1[1]
	ld1.d	{ v16 }[1], [x10]
	tbz	w9, #4, LBB0_1228
LBB0_1250:                              ; %cond.load1423
                                        ;   in Loop: Header=BB0_1221 Depth=2
	fmov	x10, d4
	ld1.d	{ v7 }[0], [x10]
	tbz	w9, #5, LBB0_1229
LBB0_1251:                              ; %cond.load1429
                                        ;   in Loop: Header=BB0_1221 Depth=2
	mov.d	x10, v4[1]
	ld1.d	{ v7 }[1], [x10]
	tbz	w9, #6, LBB0_1230
LBB0_1252:                              ; %cond.load1435
                                        ;   in Loop: Header=BB0_1221 Depth=2
	fmov	x10, d5
	ld1.d	{ v6 }[0], [x10]
	tbnz	w9, #7, LBB0_1231
	b	LBB0_1232
LBB0_1253:                              ; %direct.true636.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	ldr	q1, [sp, #10464]                ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	q1, [sp, #10560]                ; 16-byte Reload
	ldr	q3, [sp, #10496]                ; 16-byte Reload
	add.2d	v1, v1, v3
	ldr	q3, [sp, #10544]                ; 16-byte Reload
	ldr	q4, [sp, #10480]                ; 16-byte Reload
	add.2d	v4, v3, v4
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	ldr	q2, [sp, #10576]                ; 16-byte Reload
	add.2d	v5, v3, v2
	mov.16b	v2, v27
	mov.16b	v27, v19
	b	LBB0_1255
LBB0_1254:                              ; %else2216
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q3, [sp, #10128]                ; 16-byte Reload
	add.2d	v3, v3, v10
	str	q3, [sp, #10128]                ; 16-byte Spill
	ldr	q3, [sp, #10176]                ; 16-byte Reload
	add.2d	v3, v3, v24
	str	q3, [sp, #10176]                ; 16-byte Spill
	ldr	q3, [sp, #10160]                ; 16-byte Reload
	add.2d	v3, v3, v8
	str	q3, [sp, #10160]                ; 16-byte Spill
	ldr	q3, [sp, #10144]                ; 16-byte Reload
	add.2d	v3, v3, v20
	str	q3, [sp, #10144]                ; 16-byte Spill
	fmov	x9, d3
	cmp	x9, #1
	b.ge	LBB0_604
LBB0_1255:                              ; %direct.true636
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s12
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB0_1288
; %bb.1256:                             ; %else2091
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #1, LBB0_1289
LBB0_1257:                              ; %else2097
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #2, LBB0_1290
LBB0_1258:                              ; %else2103
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #3, LBB0_1291
LBB0_1259:                              ; %else2109
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #4, LBB0_1292
LBB0_1260:                              ; %else2115
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #5, LBB0_1293
LBB0_1261:                              ; %else2121
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #6, LBB0_1294
LBB0_1262:                              ; %else2127
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #7, LBB0_1295
LBB0_1263:                              ; %else2133
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	w9, s12
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB0_1296
LBB0_1264:                              ; %else2140
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #1, LBB0_1297
LBB0_1265:                              ; %else2146
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #2, LBB0_1298
LBB0_1266:                              ; %else2152
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #3, LBB0_1299
LBB0_1267:                              ; %else2158
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #4, LBB0_1300
LBB0_1268:                              ; %else2164
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #5, LBB0_1301
LBB0_1269:                              ; %else2170
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbnz	w9, #6, LBB0_1302
LBB0_1270:                              ; %else2176
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbz	w9, #7, LBB0_1272
LBB0_1271:                              ; %cond.load2178
                                        ;   in Loop: Header=BB0_1255 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_1272:                              ; %else2182
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q18, [sp, #13168]               ; 16-byte Reload
	ldr	q23, [sp, #5184]                ; 16-byte Reload
	movi	d17, #0x0000000000ffff
	bit.8b	v23, v17, v18
	ldr	q17, [sp, #2816]                ; 16-byte Reload
	ldr	q19, [sp, #5216]                ; 16-byte Reload
	bif.16b	v7, v19, v17
	ldr	q17, [sp, #2768]                ; 16-byte Reload
	and.16b	v19, v17, v7
	str	q23, [sp, #5184]                ; 16-byte Spill
	bic.8b	v7, v18, v23
	fmov	w9, s12
	ldr	q17, [sp, #2736]                ; 16-byte Reload
	ldr	q18, [sp, #5152]                ; 16-byte Reload
	bif.16b	v16, v18, v17
	zip1.8b	v17, v7, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmge.4s	v17, v17, #0
	and.16b	v16, v17, v16
	str	q19, [sp, #5216]                ; 16-byte Spill
	str	q16, [sp, #5152]                ; 16-byte Spill
	fsub.4s	v16, v19, v16
	ldr	q17, [sp, #10144]               ; 16-byte Reload
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #3456]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #3392]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w9, #0, LBB0_1274
; %bb.1273:                             ; %cond.store2185
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	x10, d17
	str	s16, [x10]
LBB0_1274:                              ; %else2188
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbz	w9, #1, LBB0_1276
; %bb.1275:                             ; %cond.store2189
                                        ;   in Loop: Header=BB0_1255 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[1], [x10]
LBB0_1276:                              ; %else2192
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q17, [sp, #10128]               ; 16-byte Reload
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #3440]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #3376]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w9, #2, LBB0_1278
; %bb.1277:                             ; %cond.store2193
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	x10, d17
	st1.s	{ v16 }[2], [x10]
LBB0_1278:                              ; %else2196
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbz	w9, #3, LBB0_1280
; %bb.1279:                             ; %cond.store2197
                                        ;   in Loop: Header=BB0_1255 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[3], [x10]
LBB0_1280:                              ; %else2200
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q16, [sp, #2800]                ; 16-byte Reload
	ldr	q17, [sp, #5200]                ; 16-byte Reload
	bif.16b	v6, v17, v16
	ldr	q16, [sp, #2784]                ; 16-byte Reload
	and.16b	v16, v16, v6
	ldr	q6, [sp, #2752]                 ; 16-byte Reload
	ldr	q17, [sp, #5168]                ; 16-byte Reload
	bif.16b	v3, v17, v6
	zip2.8b	v6, v7, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmge.4s	v6, v6, #0
	and.16b	v3, v6, v3
	str	q16, [sp, #5200]                ; 16-byte Spill
	str	q3, [sp, #5168]                 ; 16-byte Spill
	fsub.4s	v3, v16, v3
	ldr	q6, [sp, #10176]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #3424]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #3360]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #4, LBB0_1282
; %bb.1281:                             ; %cond.store2201
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	x10, d6
	str	s3, [x10]
LBB0_1282:                              ; %else2204
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbz	w9, #5, LBB0_1284
; %bb.1283:                             ; %cond.store2205
                                        ;   in Loop: Header=BB0_1255 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v3 }[1], [x10]
LBB0_1284:                              ; %else2208
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q6, [sp, #10160]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #3408]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #3344]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #6, LBB0_1286
; %bb.1285:                             ; %cond.store2209
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	x10, d6
	st1.s	{ v3 }[2], [x10]
LBB0_1286:                              ; %else2212
                                        ;   in Loop: Header=BB0_1255 Depth=2
	tbz	w9, #7, LBB0_1254
; %bb.1287:                             ; %cond.store2213
                                        ;   in Loop: Header=BB0_1255 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v3 }[3], [x9]
	b	LBB0_1254
LBB0_1288:                              ; %cond.load2087
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q3, [sp, #3008]                 ; 16-byte Reload
	fmov	x10, d3
	ldr	s7, [x10]
	tbz	w9, #1, LBB0_1257
LBB0_1289:                              ; %cond.load2093
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ld1.s	{ v7 }[1], [x19]
	tbz	w9, #2, LBB0_1258
LBB0_1290:                              ; %cond.load2099
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q3, [sp, #2992]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v7 }[2], [x10]
	tbz	w9, #3, LBB0_1259
LBB0_1291:                              ; %cond.load2105
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ld1.s	{ v7 }[3], [x6]
	tbz	w9, #4, LBB0_1260
LBB0_1292:                              ; %cond.load2111
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q3, [sp, #2976]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v6 }[0], [x10]
	tbz	w9, #5, LBB0_1261
LBB0_1293:                              ; %cond.load2117
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ld1.s	{ v6 }[1], [x7]
	tbz	w9, #6, LBB0_1262
LBB0_1294:                              ; %cond.load2123
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ldr	q3, [sp, #2960]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v6 }[2], [x10]
	tbz	w9, #7, LBB0_1263
LBB0_1295:                              ; %cond.load2129
                                        ;   in Loop: Header=BB0_1255 Depth=2
	ld1.s	{ v6 }[3], [x15]
	fmov	w9, s12
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w9, #0, LBB0_1264
LBB0_1296:                              ; %cond.load2136
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	x10, d0
	ldr	s16, [x10]
	tbz	w9, #1, LBB0_1265
LBB0_1297:                              ; %cond.load2142
                                        ;   in Loop: Header=BB0_1255 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w9, #2, LBB0_1266
LBB0_1298:                              ; %cond.load2148
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	x10, d1
	ld1.s	{ v16 }[2], [x10]
	tbz	w9, #3, LBB0_1267
LBB0_1299:                              ; %cond.load2154
                                        ;   in Loop: Header=BB0_1255 Depth=2
	mov.d	x10, v1[1]
	ld1.s	{ v16 }[3], [x10]
	tbz	w9, #4, LBB0_1268
LBB0_1300:                              ; %cond.load2160
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	x10, d4
	ld1.s	{ v3 }[0], [x10]
	tbz	w9, #5, LBB0_1269
LBB0_1301:                              ; %cond.load2166
                                        ;   in Loop: Header=BB0_1255 Depth=2
	mov.d	x10, v4[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w9, #6, LBB0_1270
LBB0_1302:                              ; %cond.load2172
                                        ;   in Loop: Header=BB0_1255 Depth=2
	fmov	x10, d5
	ld1.s	{ v3 }[2], [x10]
	tbnz	w9, #7, LBB0_1271
	b	LBB0_1272
LBB0_1303:                              ; %direct.true651.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q0, [sp, #3456]                 ; 16-byte Reload
	ldr	q1, [sp, #3392]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	q1, [sp, #3440]                 ; 16-byte Reload
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	ldr	q4, [sp, #3360]                 ; 16-byte Reload
	add.2d	v4, v4, v3
	ldr	q3, [sp, #3408]                 ; 16-byte Reload
	ldr	q5, [sp, #3344]                 ; 16-byte Reload
	add.2d	v5, v5, v3
	b	LBB0_1305
LBB0_1304:                              ; %else2298
                                        ;   in Loop: Header=BB0_1305 Depth=2
	ldr	q3, [sp, #10112]                ; 16-byte Reload
	add.2d	v3, v3, v10
	str	q3, [sp, #10112]                ; 16-byte Spill
	ldr	q3, [sp, #10096]                ; 16-byte Reload
	add.2d	v3, v3, v24
	str	q3, [sp, #10096]                ; 16-byte Spill
	ldr	q3, [sp, #10080]                ; 16-byte Reload
	add.2d	v3, v3, v8
	str	q3, [sp, #10080]                ; 16-byte Spill
	ldr	q3, [sp, #10064]                ; 16-byte Reload
	add.2d	v3, v3, v20
	str	q3, [sp, #10064]                ; 16-byte Spill
	fmov	x9, d3
	cmp	x9, #1
	b.ge	LBB0_605
LBB0_1305:                              ; %direct.true651
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s12
	movi.2d	v6, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB0_1330
; %bb.1306:                             ; %else2222
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbnz	w9, #1, LBB0_1331
LBB0_1307:                              ; %else2228
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbnz	w9, #2, LBB0_1332
LBB0_1308:                              ; %else2234
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbnz	w9, #3, LBB0_1333
LBB0_1309:                              ; %else2240
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbnz	w9, #4, LBB0_1334
LBB0_1310:                              ; %else2246
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbnz	w9, #5, LBB0_1335
LBB0_1311:                              ; %else2252
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbnz	w9, #6, LBB0_1336
LBB0_1312:                              ; %else2258
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbz	w9, #7, LBB0_1314
LBB0_1313:                              ; %cond.load2260
                                        ;   in Loop: Header=BB0_1305 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_1314:                              ; %else2264
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	w9, s12
	ldr	q7, [sp, #2704]                 ; 16-byte Reload
	ldr	q16, [sp, #5136]                ; 16-byte Reload
	bif.16b	v6, v16, v7
	ldr	q7, [sp, #2688]                 ; 16-byte Reload
	and.16b	v6, v7, v6
	str	q6, [sp, #5136]                 ; 16-byte Spill
	and.16b	v6, v31, v6
	fcmge.4s	v7, v6, v23
	ldr	q26, [sp, #11872]               ; 16-byte Reload
	fcmge.4s	v16, v26, v6
	and.16b	v7, v7, v16
	and.16b	v7, v7, v6
	ldr	q16, [sp, #11856]               ; 16-byte Reload
	fmul.4s	v16, v7, v16
	movi.4s	v17, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	bif.16b	v17, v16, v18
	fadd.4s	v16, v16, v17
	fsub.4s	v16, v16, v17
	fcvtzs.4s	v16, v16
	scvtf.4s	v17, v16
	ldr	q18, [sp, #11840]               ; 16-byte Reload
	fmul.4s	v18, v17, v18
	fadd.4s	v7, v7, v18
	ldr	q18, [sp, #11824]               ; 16-byte Reload
	fmul.4s	v17, v17, v18
	fadd.4s	v7, v7, v17
	ldr	q17, [sp, #11344]               ; 16-byte Reload
	fmul.4s	v17, v7, v17
	ldr	q18, [sp, #11328]               ; 16-byte Reload
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v7, v17
	ldr	q18, [sp, #11312]               ; 16-byte Reload
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v7, v17
	ldr	q18, [sp, #11296]               ; 16-byte Reload
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v7, v17
	ldr	q18, [sp, #11280]               ; 16-byte Reload
	fadd.4s	v17, v17, v18
	fmul.4s	v17, v7, v17
	movi.4s	v18, #63, lsl #24
	fadd.4s	v17, v17, v18
	fmul.4s	v18, v7, v7
	fmul.4s	v17, v18, v17
	fadd.4s	v7, v7, v17
	fmov.4s	v19, #1.00000000
	fadd.4s	v7, v7, v19
	sshr.4s	v17, v16, #1
	shl.4s	v18, v17, #23
	add.4s	v18, v18, v19
	fmul.4s	v7, v7, v18
	sub.4s	v16, v16, v17
	shl.4s	v16, v16, #23
	add.4s	v16, v16, v19
	fmul.4s	v7, v7, v16
	fcmgt.4s	v16, v23, v6
	bic.16b	v7, v7, v16
	fcmgt.4s	v16, v6, v26
	ldr	q17, [sp, #11264]               ; 16-byte Reload
	bit.16b	v7, v17, v16
	fcmeq.4s	v6, v6, v6
	ldr	q16, [sp, #11248]               ; 16-byte Reload
	bsl.16b	v6, v7, v16
	ldr	q7, [sp, #10064]                ; 16-byte Reload
	shl.2d	v7, v7, #5
	ldr	q16, [sp, #6304]                ; 16-byte Reload
	orr.16b	v7, v7, v16
	ldr	q16, [sp, #6240]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbz	w9, #0, LBB0_1316
; %bb.1315:                             ; %cond.store2267
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	x10, d7
	str	s6, [x10]
LBB0_1316:                              ; %else2270
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbz	w9, #1, LBB0_1318
; %bb.1317:                             ; %cond.store2271
                                        ;   in Loop: Header=BB0_1305 Depth=2
	mov.d	x10, v7[1]
	st1.s	{ v6 }[1], [x10]
LBB0_1318:                              ; %else2274
                                        ;   in Loop: Header=BB0_1305 Depth=2
	ldr	q7, [sp, #10112]                ; 16-byte Reload
	shl.2d	v7, v7, #5
	ldr	q16, [sp, #6288]                ; 16-byte Reload
	orr.16b	v7, v7, v16
	ldr	q16, [sp, #6224]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbz	w9, #2, LBB0_1320
; %bb.1319:                             ; %cond.store2275
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	x10, d7
	st1.s	{ v6 }[2], [x10]
LBB0_1320:                              ; %else2278
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbz	w9, #3, LBB0_1322
; %bb.1321:                             ; %cond.store2279
                                        ;   in Loop: Header=BB0_1305 Depth=2
	mov.d	x10, v7[1]
	st1.s	{ v6 }[3], [x10]
LBB0_1322:                              ; %else2282
                                        ;   in Loop: Header=BB0_1305 Depth=2
	ldr	q6, [sp, #2720]                 ; 16-byte Reload
	ldr	q7, [sp, #5120]                 ; 16-byte Reload
	bif.16b	v3, v7, v6
	ldr	q6, [sp, #2672]                 ; 16-byte Reload
	and.16b	v3, v6, v3
	str	q3, [sp, #5120]                 ; 16-byte Spill
	and.16b	v3, v30, v3
	fcmge.4s	v6, v3, v23
	ldr	q19, [sp, #11872]               ; 16-byte Reload
	fcmge.4s	v7, v19, v3
	and.16b	v6, v6, v7
	and.16b	v6, v6, v3
	ldr	q7, [sp, #11856]                ; 16-byte Reload
	fmul.4s	v7, v6, v7
	movi.4s	v16, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	bif.16b	v16, v7, v17
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v7, v7
	scvtf.4s	v16, v7
	ldr	q17, [sp, #11840]               ; 16-byte Reload
	fmul.4s	v17, v16, v17
	fadd.4s	v6, v6, v17
	ldr	q17, [sp, #11824]               ; 16-byte Reload
	fmul.4s	v16, v16, v17
	fadd.4s	v6, v6, v16
	ldr	q16, [sp, #11344]               ; 16-byte Reload
	fmul.4s	v16, v6, v16
	ldr	q17, [sp, #11328]               ; 16-byte Reload
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v6, v16
	ldr	q17, [sp, #11312]               ; 16-byte Reload
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v6, v16
	ldr	q17, [sp, #11296]               ; 16-byte Reload
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v6, v16
	ldr	q17, [sp, #11280]               ; 16-byte Reload
	fadd.4s	v16, v16, v17
	fmul.4s	v16, v6, v16
	movi.4s	v17, #63, lsl #24
	fadd.4s	v16, v16, v17
	fmul.4s	v17, v6, v6
	fmul.4s	v16, v17, v16
	fadd.4s	v6, v6, v16
	fmov.4s	v18, #1.00000000
	fadd.4s	v6, v6, v18
	sshr.4s	v16, v7, #1
	shl.4s	v17, v16, #23
	add.4s	v17, v17, v18
	fmul.4s	v6, v6, v17
	sub.4s	v7, v7, v16
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v18
	fmul.4s	v6, v6, v7
	fcmgt.4s	v7, v23, v3
	bic.16b	v6, v6, v7
	fcmgt.4s	v7, v3, v19
	ldr	q16, [sp, #11264]               ; 16-byte Reload
	bit.16b	v6, v16, v7
	fcmeq.4s	v3, v3, v3
	ldr	q7, [sp, #11248]                ; 16-byte Reload
	bsl.16b	v3, v6, v7
	ldr	q6, [sp, #10096]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #6272]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #6208]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #4, LBB0_1324
; %bb.1323:                             ; %cond.store2283
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	x10, d6
	str	s3, [x10]
LBB0_1324:                              ; %else2286
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbz	w9, #5, LBB0_1326
; %bb.1325:                             ; %cond.store2287
                                        ;   in Loop: Header=BB0_1305 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v3 }[1], [x10]
LBB0_1326:                              ; %else2290
                                        ;   in Loop: Header=BB0_1305 Depth=2
	ldr	q6, [sp, #10080]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #6256]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #6320]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #6, LBB0_1328
; %bb.1327:                             ; %cond.store2291
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	x10, d6
	st1.s	{ v3 }[2], [x10]
LBB0_1328:                              ; %else2294
                                        ;   in Loop: Header=BB0_1305 Depth=2
	tbz	w9, #7, LBB0_1304
; %bb.1329:                             ; %cond.store2295
                                        ;   in Loop: Header=BB0_1305 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v3 }[3], [x9]
	b	LBB0_1304
LBB0_1330:                              ; %cond.load2218
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	x10, d0
	ldr	s6, [x10]
	tbz	w9, #1, LBB0_1307
LBB0_1331:                              ; %cond.load2224
                                        ;   in Loop: Header=BB0_1305 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v6 }[1], [x10]
	tbz	w9, #2, LBB0_1308
LBB0_1332:                              ; %cond.load2230
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	x10, d1
	ld1.s	{ v6 }[2], [x10]
	tbz	w9, #3, LBB0_1309
LBB0_1333:                              ; %cond.load2236
                                        ;   in Loop: Header=BB0_1305 Depth=2
	mov.d	x10, v1[1]
	ld1.s	{ v6 }[3], [x10]
	tbz	w9, #4, LBB0_1310
LBB0_1334:                              ; %cond.load2242
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	x10, d4
	ld1.s	{ v3 }[0], [x10]
	tbz	w9, #5, LBB0_1311
LBB0_1335:                              ; %cond.load2248
                                        ;   in Loop: Header=BB0_1305 Depth=2
	mov.d	x10, v4[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w9, #6, LBB0_1312
LBB0_1336:                              ; %cond.load2254
                                        ;   in Loop: Header=BB0_1305 Depth=2
	fmov	x10, d5
	ld1.s	{ v3 }[2], [x10]
	tbnz	w9, #7, LBB0_1313
	b	LBB0_1314
LBB0_1337:                              ; %direct.true716.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q0, [sp, #6304]                 ; 16-byte Reload
	ldr	q1, [sp, #6240]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	q1, [sp, #6288]                 ; 16-byte Reload
	ldr	q3, [sp, #6224]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q3, [sp, #6272]                 ; 16-byte Reload
	ldr	q4, [sp, #6208]                 ; 16-byte Reload
	add.2d	v4, v4, v3
	ldr	q3, [sp, #6320]                 ; 16-byte Reload
	ldr	q5, [sp, #6256]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	b	LBB0_1339
LBB0_1338:                              ; %else2773
                                        ;   in Loop: Header=BB0_1339 Depth=2
	add.2d	v19, v19, v10
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	add.2d	v21, v21, v2
	ldr	q3, [sp, #10048]                ; 16-byte Reload
	add.2d	v3, v3, v8
	str	q3, [sp, #10048]                ; 16-byte Spill
	ldr	q3, [sp, #10032]                ; 16-byte Reload
	add.2d	v3, v3, v20
	str	q3, [sp, #10032]                ; 16-byte Spill
	fmov	x9, d3
	cmp	x9, #1
	mov.16b	v2, v7
	b.ge	LBB0_745
LBB0_1339:                              ; %direct.true716
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s12
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w9, #0, LBB0_1369
; %bb.1340:                             ; %else2648
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #1, LBB0_1370
LBB0_1341:                              ; %else2654
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #2, LBB0_1371
LBB0_1342:                              ; %else2660
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #3, LBB0_1372
LBB0_1343:                              ; %else2666
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #4, LBB0_1373
LBB0_1344:                              ; %else2672
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #5, LBB0_1374
LBB0_1345:                              ; %else2678
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #6, LBB0_1375
LBB0_1346:                              ; %else2684
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #7, LBB0_1376
LBB0_1347:                              ; %else2690
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	w9, s12
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w9, #0, LBB0_1377
LBB0_1348:                              ; %else2697
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #1, LBB0_1378
LBB0_1349:                              ; %else2703
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #2, LBB0_1379
LBB0_1350:                              ; %else2709
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #3, LBB0_1380
LBB0_1351:                              ; %else2715
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #4, LBB0_1381
LBB0_1352:                              ; %else2721
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #5, LBB0_1382
LBB0_1353:                              ; %else2727
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #6, LBB0_1383
LBB0_1354:                              ; %else2733
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbz	w9, #7, LBB0_1356
LBB0_1355:                              ; %cond.load2735
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_1356:                              ; %else2739
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q18, [sp, #13168]               ; 16-byte Reload
	ldr	q24, [sp, #5072]                ; 16-byte Reload
	movi	d17, #0x0000000000ffff
	bit.8b	v24, v17, v18
	ldr	q17, [sp, #2656]                ; 16-byte Reload
	ldr	q23, [sp, #5104]                ; 16-byte Reload
	bif.16b	v7, v23, v17
	ldr	q17, [sp, #2608]                ; 16-byte Reload
	and.16b	v23, v17, v7
	str	q24, [sp, #5072]                ; 16-byte Spill
	bic.8b	v7, v18, v24
	fmov	w9, s12
	ldr	q17, [sp, #2576]                ; 16-byte Reload
	ldr	q18, [sp, #5056]                ; 16-byte Reload
	bif.16b	v16, v18, v17
	zip1.8b	v17, v7, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmge.4s	v17, v17, #0
	and.16b	v16, v17, v16
	str	q23, [sp, #5104]                ; 16-byte Spill
	str	q16, [sp, #5056]                ; 16-byte Spill
	fmul.4s	v16, v23, v16
	ldr	q17, [sp, #10032]               ; 16-byte Reload
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #3312]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #3248]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbnz	w9, #0, LBB0_1384
; %bb.1357:                             ; %else2745
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbnz	w9, #1, LBB0_1385
LBB0_1358:                              ; %else2749
                                        ;   in Loop: Header=BB0_1339 Depth=2
	shl.2d	v17, v19, #5
	ldr	q18, [sp, #3296]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #3232]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbnz	w9, #2, LBB0_1386
LBB0_1359:                              ; %else2753
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbz	w9, #3, LBB0_1361
LBB0_1360:                              ; %cond.store2754
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[3], [x10]
LBB0_1361:                              ; %else2757
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q16, [sp, #2640]                ; 16-byte Reload
	ldr	q17, [sp, #5088]                ; 16-byte Reload
	bif.16b	v6, v17, v16
	ldr	q16, [sp, #2624]                ; 16-byte Reload
	and.16b	v16, v16, v6
	ldr	q6, [sp, #2592]                 ; 16-byte Reload
	ldr	q17, [sp, #5040]                ; 16-byte Reload
	bif.16b	v3, v17, v6
	zip2.8b	v6, v7, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmge.4s	v6, v6, #0
	and.16b	v3, v6, v3
	str	q16, [sp, #5088]                ; 16-byte Spill
	str	q3, [sp, #5040]                 ; 16-byte Spill
	fmul.4s	v3, v16, v3
	shl.2d	v6, v21, #5
	ldr	q7, [sp, #3280]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #3216]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #4, LBB0_1363
; %bb.1362:                             ; %cond.store2758
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	x10, d6
	str	s3, [x10]
LBB0_1363:                              ; %else2761
                                        ;   in Loop: Header=BB0_1339 Depth=2
	tbz	w9, #5, LBB0_1365
; %bb.1364:                             ; %cond.store2762
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v3 }[1], [x10]
LBB0_1365:                              ; %else2765
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q6, [sp, #10048]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #3264]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #3328]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #6, LBB0_1367
; %bb.1366:                             ; %cond.store2766
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	x10, d6
	st1.s	{ v3 }[2], [x10]
LBB0_1367:                              ; %else2769
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.16b	v7, v2
	tbz	w9, #7, LBB0_1338
; %bb.1368:                             ; %cond.store2770
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v3 }[3], [x9]
	b	LBB0_1338
LBB0_1369:                              ; %cond.load2644
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	fmov	x10, d3
	ldr	s7, [x10]
	tbz	w9, #1, LBB0_1341
LBB0_1370:                              ; %cond.load2650
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q3, [sp, #2208]                 ; 16-byte Reload
	mov.d	x10, v3[1]
	ld1.s	{ v7 }[1], [x10]
	tbz	w9, #2, LBB0_1342
LBB0_1371:                              ; %cond.load2656
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v7 }[2], [x10]
	tbz	w9, #3, LBB0_1343
LBB0_1372:                              ; %cond.load2662
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q3, [sp, #2192]                 ; 16-byte Reload
	mov.d	x10, v3[1]
	ld1.s	{ v7 }[3], [x10]
	tbz	w9, #4, LBB0_1344
LBB0_1373:                              ; %cond.load2668
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v6 }[0], [x10]
	tbz	w9, #5, LBB0_1345
LBB0_1374:                              ; %cond.load2674
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q3, [sp, #2176]                 ; 16-byte Reload
	mov.d	x10, v3[1]
	ld1.s	{ v6 }[1], [x10]
	tbz	w9, #6, LBB0_1346
LBB0_1375:                              ; %cond.load2680
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v6 }[2], [x10]
	tbz	w9, #7, LBB0_1347
LBB0_1376:                              ; %cond.load2686
                                        ;   in Loop: Header=BB0_1339 Depth=2
	ldr	q3, [sp, #2160]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	ld1.s	{ v6 }[3], [x9]
	fmov	w9, s12
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w9, #0, LBB0_1348
LBB0_1377:                              ; %cond.load2693
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	x10, d0
	ldr	s16, [x10]
	tbz	w9, #1, LBB0_1349
LBB0_1378:                              ; %cond.load2699
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v16 }[1], [x10]
	tbz	w9, #2, LBB0_1350
LBB0_1379:                              ; %cond.load2705
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	x10, d1
	ld1.s	{ v16 }[2], [x10]
	tbz	w9, #3, LBB0_1351
LBB0_1380:                              ; %cond.load2711
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.d	x10, v1[1]
	ld1.s	{ v16 }[3], [x10]
	tbz	w9, #4, LBB0_1352
LBB0_1381:                              ; %cond.load2717
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	x10, d4
	ld1.s	{ v3 }[0], [x10]
	tbz	w9, #5, LBB0_1353
LBB0_1382:                              ; %cond.load2723
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.d	x10, v4[1]
	ld1.s	{ v3 }[1], [x10]
	tbz	w9, #6, LBB0_1354
LBB0_1383:                              ; %cond.load2729
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	x10, d5
	ld1.s	{ v3 }[2], [x10]
	tbnz	w9, #7, LBB0_1355
	b	LBB0_1356
LBB0_1384:                              ; %cond.store2742
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	x10, d17
	str	s16, [x10]
	tbz	w9, #1, LBB0_1358
LBB0_1385:                              ; %cond.store2746
                                        ;   in Loop: Header=BB0_1339 Depth=2
	mov.d	x10, v17[1]
	st1.s	{ v16 }[1], [x10]
	shl.2d	v17, v19, #5
	ldr	q18, [sp, #3296]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #3232]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w9, #2, LBB0_1359
LBB0_1386:                              ; %cond.store2750
                                        ;   in Loop: Header=BB0_1339 Depth=2
	fmov	x10, d17
	st1.s	{ v16 }[2], [x10]
	tbnz	w9, #3, LBB0_1360
	b	LBB0_1361
LBB0_1387:                              ; %direct.true765.lr.ph
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q0, [sp, #3312]                 ; 16-byte Reload
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	q1, [sp, #3296]                 ; 16-byte Reload
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	ldr	q4, [sp, #3216]                 ; 16-byte Reload
	add.2d	v4, v4, v3
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	ldr	q5, [sp, #3264]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #1616
	add	x30, sp, #3, lsl #12            ; =12288
	add	x30, x30, #1648
	b	LBB0_1389
LBB0_1388:                              ; %else2986
                                        ;   in Loop: Header=BB0_1389 Depth=2
	add.2d	v23, v23, v10
	add.2d	v24, v24, v15
	ldr	q3, [sp, #10016]                ; 16-byte Reload
	add.2d	v3, v3, v8
	str	q3, [sp, #10016]                ; 16-byte Spill
	ldr	q3, [sp, #10000]                ; 16-byte Reload
	add.2d	v3, v3, v20
	str	q3, [sp, #10000]                ; 16-byte Spill
	fmov	x8, d3
	cmp	x8, #1
	b.ge	LBB0_835
LBB0_1389:                              ; %direct.true765
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s12
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbnz	w8, #0, LBB0_1427
; %bb.1390:                             ; %else2861
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbnz	w8, #1, LBB0_1428
LBB0_1391:                              ; %else2867
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbnz	w8, #2, LBB0_1429
LBB0_1392:                              ; %else2873
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbnz	w8, #3, LBB0_1430
LBB0_1393:                              ; %else2879
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbnz	w8, #4, LBB0_1431
LBB0_1394:                              ; %else2885
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbnz	w8, #5, LBB0_1432
LBB0_1395:                              ; %else2891
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbnz	w8, #6, LBB0_1433
LBB0_1396:                              ; %else2897
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbz	w8, #7, LBB0_1398
LBB0_1397:                              ; %cond.load2899
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x8, v5[1]
	ld1.s	{ v6 }[3], [x8]
LBB0_1398:                              ; %else2903
                                        ;   in Loop: Header=BB0_1389 Depth=2
	sshll.2d	v3, v31, #0
	ldr	q16, [sp, #5680]                ; 16-byte Reload
	ldr	q17, [sp, #5024]                ; 16-byte Reload
	bit.16b	v17, v16, v3
	fmov	w8, s12
	str	q17, [sp, #5024]                ; 16-byte Spill
	shl.2d	v3, v17, #5
	ldr	q16, [sp, #5904]                ; 16-byte Reload
	orr.16b	v3, v3, v16
	ldr	q16, [sp, #5840]                ; 16-byte Reload
	add.2d	v17, v16, v3
	movi.2d	v16, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbz	w8, #0, LBB0_1400
; %bb.1399:                             ; %cond.load2906
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d17
	ldr	s16, [x9]
LBB0_1400:                              ; %else2910
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbz	w8, #1, LBB0_1402
; %bb.1401:                             ; %cond.load2912
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v17[1]
	ld1.s	{ v16 }[1], [x9]
LBB0_1402:                              ; %else2916
                                        ;   in Loop: Header=BB0_1389 Depth=2
	ldr	q17, [sp, #5008]                ; 16-byte Reload
	bic.16b	v17, v17, v11
	ssubw2.2d	v17, v17, v31
	str	q17, [sp, #5008]                ; 16-byte Spill
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #5888]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #5824]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w8, #2, LBB0_1404
; %bb.1403:                             ; %cond.load2918
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d17
	ld1.s	{ v16 }[2], [x9]
LBB0_1404:                              ; %else2922
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbz	w8, #3, LBB0_1406
; %bb.1405:                             ; %cond.load2924
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v17[1]
	ld1.s	{ v16 }[3], [x9]
LBB0_1406:                              ; %else2928
                                        ;   in Loop: Header=BB0_1389 Depth=2
	sshll.2d	v17, v30, #0
	ldr	q18, [sp, #4992]                ; 16-byte Reload
	bic.16b	v17, v18, v17
	ssubw.2d	v17, v17, v30
	str	q17, [sp, #4992]                ; 16-byte Spill
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #5872]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #5936]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w8, #4, LBB0_1408
; %bb.1407:                             ; %cond.load2930
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d17
	ld1.s	{ v3 }[0], [x9]
LBB0_1408:                              ; %else2934
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbz	w8, #5, LBB0_1410
; %bb.1409:                             ; %cond.load2936
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v17[1]
	ld1.s	{ v3 }[1], [x9]
LBB0_1410:                              ; %else2940
                                        ;   in Loop: Header=BB0_1389 Depth=2
	ldr	q17, [sp, #4976]                ; 16-byte Reload
	bic.16b	v17, v17, v14
	ssubw2.2d	v17, v17, v30
	str	q17, [sp, #4976]                ; 16-byte Spill
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #5856]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #5920]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w8, #6, LBB0_1412
; %bb.1411:                             ; %cond.load2942
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d17
	ld1.s	{ v3 }[2], [x9]
LBB0_1412:                              ; %else2946
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbz	w8, #7, LBB0_1414
; %bb.1413:                             ; %cond.load2948
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x8, v17[1]
	ld1.s	{ v3 }[3], [x8]
LBB0_1414:                              ; %else2952
                                        ;   in Loop: Header=BB0_1389 Depth=2
	ldr	q18, [sp, #13168]               ; 16-byte Reload
	ldr	q19, [sp, #4960]                ; 16-byte Reload
	movi	d17, #0x0000000000ffff
	bit.8b	v19, v17, v18
	ldr	q17, [sp, #2560]                ; 16-byte Reload
	ldr	q21, [sp, #4944]                ; 16-byte Reload
	bif.16b	v7, v21, v17
	ldr	q17, [sp, #2512]                ; 16-byte Reload
	and.16b	v21, v17, v7
	str	q19, [sp, #4960]                ; 16-byte Spill
	bic.8b	v7, v18, v19
	fmov	w8, s12
	ldr	q17, [sp, #2480]                ; 16-byte Reload
	ldr	q18, [sp, #4912]                ; 16-byte Reload
	bif.16b	v16, v18, v17
	zip1.8b	v17, v7, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmge.4s	v17, v17, #0
	and.16b	v16, v17, v16
	str	q21, [sp, #4944]                ; 16-byte Spill
	str	q16, [sp, #4912]                ; 16-byte Spill
	fadd.4s	v16, v21, v16
	ldr	q17, [sp, #10000]               ; 16-byte Reload
	shl.2d	v17, v17, #5
	ldr	q18, [sp, #5792]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #5728]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbnz	w8, #0, LBB0_1434
; %bb.1415:                             ; %else2958
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbnz	w8, #1, LBB0_1435
LBB0_1416:                              ; %else2962
                                        ;   in Loop: Header=BB0_1389 Depth=2
	shl.2d	v17, v23, #5
	ldr	q18, [sp, #5776]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #5712]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbnz	w8, #2, LBB0_1436
LBB0_1417:                              ; %else2966
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbz	w8, #3, LBB0_1419
LBB0_1418:                              ; %cond.store2967
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v17[1]
	st1.s	{ v16 }[3], [x9]
LBB0_1419:                              ; %else2970
                                        ;   in Loop: Header=BB0_1389 Depth=2
	ldr	q16, [sp, #2544]                ; 16-byte Reload
	ldr	q17, [sp, #4928]                ; 16-byte Reload
	bif.16b	v6, v17, v16
	ldr	q16, [sp, #2528]                ; 16-byte Reload
	and.16b	v16, v16, v6
	ldr	q6, [sp, #2496]                 ; 16-byte Reload
	ldr	q17, [sp, #4896]                ; 16-byte Reload
	bif.16b	v3, v17, v6
	zip2.8b	v6, v7, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmge.4s	v6, v6, #0
	and.16b	v3, v6, v3
	str	q16, [sp, #4928]                ; 16-byte Spill
	str	q3, [sp, #4896]                 ; 16-byte Spill
	fadd.4s	v3, v16, v3
	shl.2d	v6, v24, #5
	ldr	q7, [sp, #5760]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #5696]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w8, #4, LBB0_1421
; %bb.1420:                             ; %cond.store2971
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d6
	str	s3, [x9]
LBB0_1421:                              ; %else2974
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbz	w8, #5, LBB0_1423
; %bb.1422:                             ; %cond.store2975
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v3 }[1], [x9]
LBB0_1423:                              ; %else2978
                                        ;   in Loop: Header=BB0_1389 Depth=2
	ldr	q6, [sp, #10016]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #5744]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #5808]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w8, #6, LBB0_1425
; %bb.1424:                             ; %cond.store2979
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d6
	st1.s	{ v3 }[2], [x9]
LBB0_1425:                              ; %else2982
                                        ;   in Loop: Header=BB0_1389 Depth=2
	tbz	w8, #7, LBB0_1388
; %bb.1426:                             ; %cond.store2983
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x8, v6[1]
	st1.s	{ v3 }[3], [x8]
	b	LBB0_1388
LBB0_1427:                              ; %cond.load2857
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d0
	ldr	s7, [x9]
	tbz	w8, #1, LBB0_1391
LBB0_1428:                              ; %cond.load2863
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v7 }[1], [x9]
	tbz	w8, #2, LBB0_1392
LBB0_1429:                              ; %cond.load2869
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d1
	ld1.s	{ v7 }[2], [x9]
	tbz	w8, #3, LBB0_1393
LBB0_1430:                              ; %cond.load2875
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[3], [x9]
	tbz	w8, #4, LBB0_1394
LBB0_1431:                              ; %cond.load2881
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d4
	ld1.s	{ v6 }[0], [x9]
	tbz	w8, #5, LBB0_1395
LBB0_1432:                              ; %cond.load2887
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v6 }[1], [x9]
	tbz	w8, #6, LBB0_1396
LBB0_1433:                              ; %cond.load2893
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d5
	ld1.s	{ v6 }[2], [x9]
	tbnz	w8, #7, LBB0_1397
	b	LBB0_1398
LBB0_1434:                              ; %cond.store2955
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d17
	str	s16, [x9]
	tbz	w8, #1, LBB0_1416
LBB0_1435:                              ; %cond.store2959
                                        ;   in Loop: Header=BB0_1389 Depth=2
	mov.d	x9, v17[1]
	st1.s	{ v16 }[1], [x9]
	shl.2d	v17, v23, #5
	ldr	q18, [sp, #5776]                ; 16-byte Reload
	orr.16b	v17, v17, v18
	ldr	q18, [sp, #5712]                ; 16-byte Reload
	add.2d	v17, v18, v17
	tbz	w8, #2, LBB0_1417
LBB0_1436:                              ; %cond.store2963
                                        ;   in Loop: Header=BB0_1389 Depth=2
	fmov	x9, d17
	st1.s	{ v16 }[2], [x9]
	tbnz	w8, #3, LBB0_1418
	b	LBB0_1419
LBB0_1437:                              ; %direct.true851.preheader
                                        ;   in Loop: Header=BB0_92 Depth=1
	ldr	q21, [sp, #1072]                ; 16-byte Reload
	b	LBB0_1439
LBB0_1438:                              ; %else3461
                                        ;   in Loop: Header=BB0_1439 Depth=2
	ldr	q0, [sp, #9920]                 ; 16-byte Reload
	add.2d	v0, v0, v10
	str	q0, [sp, #9920]                 ; 16-byte Spill
	ldr	q0, [sp, #9904]                 ; 16-byte Reload
	add.2d	v0, v0, v15
	str	q0, [sp, #9904]                 ; 16-byte Spill
	ldr	q0, [sp, #9968]                 ; 16-byte Reload
	add.2d	v0, v0, v8
	str	q0, [sp, #9968]                 ; 16-byte Spill
	ldr	q1, [sp, #13312]                ; 16-byte Reload
	add.2d	v0, v29, v1
	fmov	x8, d0
	cmp	x8, #1
	b.ge	LBB0_961
LBB0_1439:                              ; %direct.true851
                                        ;   Parent Loop BB0_92 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v29, v0
	shl.2d	v1, v0, #5
	ldr	q0, [sp, #5792]                 ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q3, [sp, #5728]                 ; 16-byte Reload
	add.2d	v4, v3, v0
	fmov	w8, s12
	movi.2d	v3, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_1441
; %bb.1440:                             ; %cond.load3381
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	x9, d4
	ldr	s3, [x9]
LBB0_1441:                              ; %else3385
                                        ;   in Loop: Header=BB0_1439 Depth=2
	tbz	w8, #1, LBB0_1443
; %bb.1442:                             ; %cond.load3387
                                        ;   in Loop: Header=BB0_1439 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v3 }[1], [x9]
LBB0_1443:                              ; %else3391
                                        ;   in Loop: Header=BB0_1439 Depth=2
	ldr	q4, [sp, #9920]                 ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #5776]                 ; 16-byte Reload
	orr.16b	v5, v4, v5
	ldr	q6, [sp, #5712]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w8, #2, LBB0_1445
; %bb.1444:                             ; %cond.load3393
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	x9, d5
	ld1.s	{ v3 }[2], [x9]
LBB0_1445:                              ; %else3397
                                        ;   in Loop: Header=BB0_1439 Depth=2
	tbz	w8, #3, LBB0_1447
; %bb.1446:                             ; %cond.load3399
                                        ;   in Loop: Header=BB0_1439 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v3 }[3], [x9]
LBB0_1447:                              ; %else3403
                                        ;   in Loop: Header=BB0_1439 Depth=2
	ldr	q5, [sp, #9904]                 ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #5760]                 ; 16-byte Reload
	orr.16b	v6, v5, v6
	ldr	q7, [sp, #5696]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w8, #4, LBB0_1449
; %bb.1448:                             ; %cond.load3405
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
LBB0_1449:                              ; %else3409
                                        ;   in Loop: Header=BB0_1439 Depth=2
	tbz	w8, #5, LBB0_1451
; %bb.1450:                             ; %cond.load3411
                                        ;   in Loop: Header=BB0_1439 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1451:                              ; %else3415
                                        ;   in Loop: Header=BB0_1439 Depth=2
	ldr	q6, [sp, #9968]                 ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #5744]                 ; 16-byte Reload
	orr.16b	v7, v6, v7
	ldr	q16, [sp, #5808]                ; 16-byte Reload
	add.2d	v7, v16, v7
	tbz	w8, #6, LBB0_1453
; %bb.1452:                             ; %cond.load3417
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1453:                              ; %else3421
                                        ;   in Loop: Header=BB0_1439 Depth=2
	tbz	w8, #7, LBB0_1455
; %bb.1454:                             ; %cond.load3423
                                        ;   in Loop: Header=BB0_1439 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1455:                              ; %else3427
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	w8, s12
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	ldr	q16, [sp, #10640]               ; 16-byte Reload
	bif.16b	v3, v16, v7
	ldr	q7, [sp, #2352]                 ; 16-byte Reload
	and.16b	v3, v7, v3
	str	q3, [sp, #10640]                ; 16-byte Spill
	ldr	q3, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5552]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #0, LBB0_1464
; %bb.1456:                             ; %else3433
                                        ;   in Loop: Header=BB0_1439 Depth=2
	tbnz	w8, #1, LBB0_1465
LBB0_1457:                              ; %else3437
                                        ;   in Loop: Header=BB0_1439 Depth=2
	ldr	q1, [sp, #12272]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q3, [sp, #5584]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbnz	w8, #2, LBB0_1466
LBB0_1458:                              ; %else3441
                                        ;   in Loop: Header=BB0_1439 Depth=2
	tbz	w8, #3, LBB0_1460
LBB0_1459:                              ; %cond.store3442
                                        ;   in Loop: Header=BB0_1439 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10640]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1460:                              ; %else3445
                                        ;   in Loop: Header=BB0_1439 Depth=2
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	ldr	q3, [sp, #10624]                ; 16-byte Reload
	bif.16b	v0, v3, v1
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	and.16b	v0, v1, v0
	str	q0, [sp, #10624]                ; 16-byte Spill
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	ldr	q1, [sp, #5568]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #4, LBB0_1467
; %bb.1461:                             ; %else3449
                                        ;   in Loop: Header=BB0_1439 Depth=2
	tbnz	w8, #5, LBB0_1468
LBB0_1462:                              ; %else3453
                                        ;   in Loop: Header=BB0_1439 Depth=2
	ldr	q0, [sp, #12288]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #5600]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #6, LBB0_1469
LBB0_1463:                              ; %else3457
                                        ;   in Loop: Header=BB0_1439 Depth=2
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_1438
	b	LBB0_1470
LBB0_1464:                              ; %cond.store3430
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #10640]                ; 16-byte Reload
	str	s3, [x9]
	tbz	w8, #1, LBB0_1457
LBB0_1465:                              ; %cond.store3434
                                        ;   in Loop: Header=BB0_1439 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10640]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #12272]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q3, [sp, #5584]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w8, #2, LBB0_1458
LBB0_1466:                              ; %cond.store3438
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	x9, d1
	ldr	q3, [sp, #10640]                ; 16-byte Reload
	st1.s	{ v3 }[2], [x9]
	tbnz	w8, #3, LBB0_1459
	b	LBB0_1460
LBB0_1467:                              ; %cond.store3446
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	x9, d0
	ldr	q1, [sp, #10624]                ; 16-byte Reload
	str	s1, [x9]
	tbz	w8, #5, LBB0_1462
LBB0_1468:                              ; %cond.store3450
                                        ;   in Loop: Header=BB0_1439 Depth=2
	mov.d	x9, v0[1]
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	st1.s	{ v0 }[1], [x9]
	ldr	q0, [sp, #12288]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #5600]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_1463
LBB0_1469:                              ; %cond.store3454
                                        ;   in Loop: Header=BB0_1439 Depth=2
	fmov	x9, d0
	ldr	q1, [sp, #10624]                ; 16-byte Reload
	st1.s	{ v1 }[2], [x9]
	ldr	q6, [sp, #11616]                ; 16-byte Reload
	tbz	w8, #7, LBB0_1438
LBB0_1470:                              ; %cond.store3458
                                        ;   in Loop: Header=BB0_1439 Depth=2
	mov.d	x8, v0[1]
	ldr	q0, [sp, #10624]                ; 16-byte Reload
	st1.s	{ v0 }[3], [x8]
	b	LBB0_1438
LBB0_1471:                              ; %direct.false363
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v3, v14, v2
	str	q3, [sp, #13296]                ; 16-byte Spill
	and.16b	v3, v11, v2
	str	q3, [sp, #13264]                ; 16-byte Spill
	and.16b	v4, v1, v2
	and.16b	v5, v0, v2
	movi.2d	v6, #0000000000000000
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fmov	x8, d0
	str	x8, [sp, #13248]                ; 8-byte Spill
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	fmov	x8, d0
	str	x8, [sp, #13232]                ; 8-byte Spill
	ldr	q0, [sp, #11648]                ; 16-byte Reload
	fmov	x15, d0
	ldr	q0, [sp, #11632]                ; 16-byte Reload
	fmov	x6, d0
	ldr	q1, [sp, #4640]                 ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #13216]                ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #13200]                ; 16-byte Spill
	ldr	q1, [sp, #48]                   ; 16-byte Reload
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #13184]                ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	ldr	q1, [sp, #12992]                ; 16-byte Reload
	mov.d	x7, v1[1]
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #13152]                ; 16-byte Spill
	fmov	x19, d1
	ldr	q0, [sp, #13008]                ; 16-byte Reload
	mov.d	x20, v0[1]
	fmov	x21, d0
	ldr	q0, [sp, #13024]                ; 16-byte Reload
	mov.d	x22, v0[1]
	fmov	x23, d0
	ldr	q0, [sp, #13040]                ; 16-byte Reload
	mov.d	x24, v0[1]
	fmov	x25, d0
	movi.2d	v19, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	b	LBB0_1473
LBB0_1472:                              ; %else3920
                                        ;   in Loop: Header=BB0_1473 Depth=1
	ldr	q0, [sp, #13056]                ; 16-byte Reload
	add.2d	v27, v27, v0
	add.2d	v28, v28, v3
	add.2d	v29, v29, v2
	add.2d	v6, v6, v7
	fmov	x8, d6
	cmp	x8, #2
	b.ge	LBB0_1521
LBB0_1473:                              ; %direct.true912
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v0, v31, #0
	and.16b	v0, v0, v6
	mov.d	x8, v0[1]
	ldr	x10, [sp, #11704]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d0
	ldr	x11, [sp, #13248]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	d11, x9
	mov.d	v11[1], x8
	shl.2d	v0, v11, #5
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9728]                 ; 16-byte Reload
	add.2d	v7, v1, v0
	ldr	d0, [sp, #12344]                ; 8-byte Reload
	fmov	w9, s0
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w9, #0, LBB0_1475
; %bb.1474:                             ; %cond.load3791
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x8, d7
	ldr	s1, [x8]
LBB0_1475:                              ; %else3795
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w9, #1, LBB0_1477
; %bb.1476:                             ; %cond.load3797
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x8, v7[1]
	ld1.s	{ v1 }[1], [x8]
LBB0_1477:                              ; %else3801
                                        ;   in Loop: Header=BB0_1473 Depth=1
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	and.16b	v7, v2, v27
	mov.d	x8, v7[1]
	ldr	x11, [sp, #11568]               ; 8-byte Reload
	sdiv	x10, x8, x11
	msub	x8, x10, x11, x8
	fmov	x10, d7
	sdiv	x11, x10, x15
	msub	x10, x11, x15, x10
	fmov	d7, x10
	mov.d	v7[1], x8
	shl.2d	v16, v7, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #9760]                 ; 16-byte Reload
	add.2d	v16, v2, v16
	tbz	w9, #2, LBB0_1479
; %bb.1478:                             ; %cond.load3803
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x8, d16
	ld1.s	{ v1 }[2], [x8]
LBB0_1479:                              ; %else3807
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w9, #3, LBB0_1481
; %bb.1480:                             ; %cond.load3809
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x8, v16[1]
	ld1.s	{ v1 }[3], [x8]
LBB0_1481:                              ; %else3813
                                        ;   in Loop: Header=BB0_1473 Depth=1
	sshll.2d	v16, v30, #0
	and.16b	v16, v16, v28
	mov.d	x8, v16[1]
	sdiv	x10, x8, x26
	msub	x8, x10, x26, x8
	fmov	x10, d16
	ldr	x12, [sp, #13232]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	d16, x10
	mov.d	v16[1], x8
	shl.2d	v17, v16, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v17, v17, v2
	ldr	q2, [sp, #9744]                 ; 16-byte Reload
	add.2d	v17, v2, v17
	tbz	w9, #4, LBB0_1483
; %bb.1482:                             ; %cond.load3815
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x8, d17
	ld1.s	{ v0 }[0], [x8]
LBB0_1483:                              ; %else3819
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w9, #5, LBB0_1485
; %bb.1484:                             ; %cond.load3821
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x8, v17[1]
	ld1.s	{ v0 }[1], [x8]
LBB0_1485:                              ; %else3825
                                        ;   in Loop: Header=BB0_1473 Depth=1
	and.16b	v17, v14, v29
	mov.d	x8, v17[1]
	sdiv	x10, x8, x27
	msub	x8, x10, x27, x8
	fmov	x10, d17
	sdiv	x11, x10, x6
	msub	x10, x11, x6, x10
	fmov	d17, x10
	mov.d	v17[1], x8
	shl.2d	v18, v17, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v18, v18, v2
	ldr	q2, [sp, #9776]                 ; 16-byte Reload
	add.2d	v18, v2, v18
	tbz	w9, #6, LBB0_1487
; %bb.1486:                             ; %cond.load3827
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x8, d18
	ld1.s	{ v0 }[2], [x8]
LBB0_1487:                              ; %else3831
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w9, #7, LBB0_1489
; %bb.1488:                             ; %cond.load3833
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1489:                              ; %else3837
                                        ;   in Loop: Header=BB0_1473 Depth=1
	sshll.2d	v8, v31, #0
	sshll.2d	v10, v30, #0
	and.16b	v17, v14, v17
	ldr	q2, [sp, #12736]                ; 16-byte Reload
	and.16b	v7, v2, v7
	and.16b	v11, v8, v11
	mov.d	x8, v11[1]
	and.16b	v16, v10, v16
	sdiv	x27, x8, x7
	fmov	x8, d11
	sdiv	x8, x8, x19
	mul	x10, x8, x19
	fmov	d18, x8
	mov.d	v18[1], x27
	mov.d	x8, v16[1]
	sdiv	x28, x8, x20
	fmov	x11, d16
	mov.d	x8, v7[1]
	sdiv	x8, x8, x22
	fmov	x9, d7
	mov.d	x12, v17[1]
	sdiv	x14, x9, x23
	sdiv	x9, x12, x24
	fmov	x12, d17
	sdiv	x26, x12, x25
	mul	x12, x9, x24
	mul	x30, x26, x25
	fmov	d12, x30
	mov.d	v12[1], x12
	mul	x12, x8, x22
	mul	x30, x14, x23
	fmov	d15, x30
	mov.d	v15[1], x12
	mul	x12, x28, x20
	sdiv	x30, x11, x21
	mul	x11, x30, x21
	fmov	d14, x11
	mov.d	v14[1], x12
	mul	x11, x27, x7
	fmov	d13, x10
	mov.d	v13[1], x11
	sub.2d	v13, v11, v13
	sub.2d	v14, v16, v14
	sub.2d	v15, v7, v15
	sub.2d	v7, v17, v12
	ldr	q2, [sp, #13088]                ; 16-byte Reload
	cmeq.2d	v16, v2, v7
	ldr	q2, [sp, #13136]                ; 16-byte Reload
	cmeq.2d	v17, v2, v14
	uzp1.4s	v16, v17, v16
	ldr	q2, [sp, #13104]                ; 16-byte Reload
	cmeq.2d	v17, v2, v15
	ldr	q2, [sp, #13120]                ; 16-byte Reload
	cmeq.2d	v11, v2, v13
	uzp1.4s	v17, v11, v17
	uzp1.8h	v17, v17, v16
	ldr	q2, [sp, #13280]                ; 16-byte Reload
	and.16b	v16, v2, v17
	xtn.8b	v11, v16
	shl.8b	v16, v11, #7
	cmlt.8b	v16, v16, #0
	ldr	d2, [sp, #13344]                ; 8-byte Reload
	and.8b	v16, v16, v2
	addv.8b	b16, v16
	fmov	w27, s16
	shl.2d	v16, v18, #5
	ldr	q2, [sp, #12304]                ; 16-byte Reload
	orr.16b	v16, v16, v2
	ldr	q2, [sp, #3152]                 ; 16-byte Reload
	add.2d	v18, v2, v16
	movi.2d	v12, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbz	w27, #0, LBB0_1491
; %bb.1490:                             ; %cond.load3840
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x10, d18
	ldr	s12, [x10]
LBB0_1491:                              ; %else3844
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w27, #1, LBB0_1493
; %bb.1492:                             ; %cond.load3846
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x10, v18[1]
	ld1.s	{ v12 }[1], [x10]
LBB0_1493:                              ; %else3850
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	d18, x14
	mov.d	v18[1], x8
	shl.2d	v18, v18, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v18, v18, v2
	ldr	q2, [sp, #3184]                 ; 16-byte Reload
	add.2d	v18, v2, v18
	tbz	w27, #2, LBB0_1495
; %bb.1494:                             ; %cond.load3852
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x8, d18
	ld1.s	{ v12 }[2], [x8]
LBB0_1495:                              ; %else3856
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w27, #3, LBB0_1497
; %bb.1496:                             ; %cond.load3858
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v12 }[3], [x8]
LBB0_1497:                              ; %else3862
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	d18, x30
	mov.d	v18[1], x28
	shl.2d	v18, v18, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v18, v18, v2
	ldr	q2, [sp, #3168]                 ; 16-byte Reload
	add.2d	v18, v2, v18
	tbz	w27, #4, LBB0_1499
; %bb.1498:                             ; %cond.load3864
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x8, d18
	ld1.s	{ v16 }[0], [x8]
LBB0_1499:                              ; %else3868
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w27, #5, LBB0_1501
; %bb.1500:                             ; %cond.load3870
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v16 }[1], [x8]
LBB0_1501:                              ; %else3874
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	d18, x26
	mov.d	v18[1], x9
	shl.2d	v18, v18, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v18, v18, v2
	ldr	q2, [sp, #3200]                 ; 16-byte Reload
	add.2d	v18, v2, v18
	tbz	w27, #6, LBB0_1503
; %bb.1502:                             ; %cond.load3876
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x8, d18
	ld1.s	{ v16 }[2], [x8]
LBB0_1503:                              ; %else3880
                                        ;   in Loop: Header=BB0_1473 Depth=1
	ldr	x26, [sp, #11560]               ; 8-byte Reload
	ldr	q2, [sp, #13216]                ; 16-byte Reload
	bif.16b	v1, v25, v2
	ldr	q2, [sp, #13152]                ; 16-byte Reload
	and.16b	v25, v2, v1
	ldr	q1, [sp, #12720]                ; 16-byte Reload
	bit.16b	v24, v7, v1
	ldr	q1, [sp, #12736]                ; 16-byte Reload
	bit.16b	v21, v15, v1
	bit.16b	v22, v14, v10
	bit.16b	v20, v13, v8
	ldr	q1, [sp, #13280]                ; 16-byte Reload
	bic.16b	v1, v1, v17
	xtn.8b	v1, v1
	tbz	w27, #7, LBB0_1505
; %bb.1504:                             ; %cond.load3882
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v16 }[3], [x8]
LBB0_1505:                              ; %else3886
                                        ;   in Loop: Header=BB0_1473 Depth=1
	ldr	q3, [sp, #13328]                ; 16-byte Reload
	ldr	q2, [sp, #13168]                ; 16-byte Reload
	zip2.8b	v7, v11, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bsl.16b	v7, v16, v9
	zip1.8b	v16, v11, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	bsl.16b	v16, v12, v23
	zip1.8b	v17, v1, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmge.4s	v17, v17, #0
	and.16b	v23, v17, v16
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v9, v1, v7
	xtn.2s	v1, v24
	xtn.2s	v16, v22
	xtn.2s	v17, v21
	xtn.2s	v7, v20
	mov.s	w8, v7[1]
	fmov	w9, s7
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	str	d2, [sp, #13352]
	ldrb	w11, [x11]
	and	w11, w16, w11
	str	q9, [sp, #13376]
	str	q23, [sp, #13360]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1072
	ldr	s7, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s8, s7, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w17, w8
	str	q9, [sp, #13408]
	str	q23, [sp, #13392]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1104
	ldr	s7, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s7, s7, s19, ne
	mov.s	w8, v17[1]
	fmov	w9, s17
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	str	q9, [sp, #13440]
	str	q23, [sp, #13424]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1136
	ldr	s17, [x12, x9, lsl #2]
	and	w9, w0, w11
	tst	w10, w9
	fcsel	s17, s17, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w1, w8
	str	q9, [sp, #13472]
	str	q23, [sp, #13456]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1168
	ldr	s18, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	w8, v16[1]
	fcsel	s11, s18, s19, ne
	fmov	w9, s16
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w2, w11
	stp	q23, q9, [x13]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1200
	ldr	s16, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s16, s16, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w3, w8
	stp	q23, q9, [x13, #32]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1232
	ldr	s18, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s10, s18, s19, ne
	mov.s	w8, v1[1]
	fmov	w9, s1
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w4, w11
	stp	q23, q9, [x13, #64]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1264
	ldr	s1, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s1, s1, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w5, w8
	stp	q23, q9, [x13, #96]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1296
	ldr	s18, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	v8[1], v7[0]
	mov.s	v8[2], v17[0]
	mov.s	v8[3], v11[0]
	fcsel	s7, s18, s19, ne
	fdiv.4s	v17, v25, v8
	shl.2d	v18, v6, #5
	ldr	q2, [sp, #12304]                ; 16-byte Reload
	orr.16b	v18, v18, v2
	add.2d	v18, v5, v18
	ldr	d2, [sp, #12344]                ; 8-byte Reload
	fmov	w8, s2
	ldr	q14, [sp, #12720]               ; 16-byte Reload
	ldr	x27, [sp, #11368]               ; 8-byte Reload
	tbnz	w8, #0, LBB0_1514
; %bb.1506:                             ; %else3892
                                        ;   in Loop: Header=BB0_1473 Depth=1
	ldr	q2, [sp, #12880]                ; 16-byte Reload
	tbnz	w8, #1, LBB0_1515
LBB0_1507:                              ; %else3896
                                        ;   in Loop: Header=BB0_1473 Depth=1
	shl.2d	v18, v27, #5
	ldr	q8, [sp, #12272]                ; 16-byte Reload
	orr.16b	v18, v18, v8
	ldr	q8, [sp, #13264]                ; 16-byte Reload
	add.2d	v18, v8, v18
	tbnz	w8, #2, LBB0_1516
LBB0_1508:                              ; %else3900
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w8, #3, LBB0_1510
LBB0_1509:                              ; %cond.store3901
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x9, v18[1]
	st1.s	{ v17 }[3], [x9]
LBB0_1510:                              ; %else3904
                                        ;   in Loop: Header=BB0_1473 Depth=1
	ldr	q17, [sp, #13200]               ; 16-byte Reload
	bif.16b	v0, v26, v17
	ldr	q17, [sp, #13184]               ; 16-byte Reload
	and.16b	v26, v17, v0
	mov.s	v16[1], v10[0]
	mov.s	v16[2], v1[0]
	mov.s	v16[3], v7[0]
	fdiv.4s	v0, v26, v16
	shl.2d	v1, v28, #5
	ldr	q7, [sp, #12320]                ; 16-byte Reload
	orr.16b	v1, v1, v7
	add.2d	v1, v4, v1
	tbnz	w8, #4, LBB0_1517
; %bb.1511:                             ; %else3908
                                        ;   in Loop: Header=BB0_1473 Depth=1
	ldr	q7, [sp, #13312]                ; 16-byte Reload
	tbnz	w8, #5, LBB0_1518
LBB0_1512:                              ; %else3912
                                        ;   in Loop: Header=BB0_1473 Depth=1
	shl.2d	v1, v29, #5
	ldr	q16, [sp, #12288]               ; 16-byte Reload
	orr.16b	v1, v1, v16
	ldr	q16, [sp, #13296]               ; 16-byte Reload
	add.2d	v1, v16, v1
	tbnz	w8, #6, LBB0_1519
LBB0_1513:                              ; %else3916
                                        ;   in Loop: Header=BB0_1473 Depth=1
	tbz	w8, #7, LBB0_1472
	b	LBB0_1520
LBB0_1514:                              ; %cond.store3889
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x9, d18
	str	s17, [x9]
	ldr	q2, [sp, #12880]                ; 16-byte Reload
	tbz	w8, #1, LBB0_1507
LBB0_1515:                              ; %cond.store3893
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x9, v18[1]
	st1.s	{ v17 }[1], [x9]
	shl.2d	v18, v27, #5
	ldr	q8, [sp, #12272]                ; 16-byte Reload
	orr.16b	v18, v18, v8
	ldr	q8, [sp, #13264]                ; 16-byte Reload
	add.2d	v18, v8, v18
	tbz	w8, #2, LBB0_1508
LBB0_1516:                              ; %cond.store3897
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x9, d18
	st1.s	{ v17 }[2], [x9]
	tbnz	w8, #3, LBB0_1509
	b	LBB0_1510
LBB0_1517:                              ; %cond.store3905
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x9, d1
	str	s0, [x9]
	ldr	q7, [sp, #13312]                ; 16-byte Reload
	tbz	w8, #5, LBB0_1512
LBB0_1518:                              ; %cond.store3909
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	shl.2d	v1, v29, #5
	ldr	q16, [sp, #12288]               ; 16-byte Reload
	orr.16b	v1, v1, v16
	ldr	q16, [sp, #13296]               ; 16-byte Reload
	add.2d	v1, v16, v1
	tbz	w8, #6, LBB0_1513
LBB0_1519:                              ; %cond.store3913
                                        ;   in Loop: Header=BB0_1473 Depth=1
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbz	w8, #7, LBB0_1472
LBB0_1520:                              ; %cond.store3917
                                        ;   in Loop: Header=BB0_1473 Depth=1
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
	b	LBB0_1472
LBB0_1521:                              ; %direct.true933.preheader
	movi.2d	v0, #0000000000000000
	sshll.2d	v1, v31, #0
	sshll.2d	v6, v30, #0
	mov	w8, #6                          ; =0x6
	dup.2d	v7, x8
	ldr	q2, [sp, #11680]                ; 16-byte Reload
	fmov	x8, d2
	ldr	q2, [sp, #11664]                ; 16-byte Reload
	fmov	x13, d2
	ldr	q2, [sp, #11648]                ; 16-byte Reload
	fmov	x14, d2
	ldr	q3, [sp, #4640]                 ; 16-byte Reload
	zip1.8b	v17, v3, v0
	ldr	q2, [sp, #11632]                ; 16-byte Reload
	fmov	x15, d2
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmlt.4s	v17, v17, #0
	zip2.8b	v18, v3, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	ldr	q2, [sp, #48]                   ; 16-byte Reload
	zip2.8b	v19, v2, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmge.4s	v19, v19, #0
	zip1.8b	v20, v2, v0
	ushll.4s	v20, v20, #0
	shl.4s	v20, v20, #31
	cmge.4s	v20, v20, #0
	mov	w16, #3                         ; =0x3
	movi.2d	v21, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	ldr	x17, [sp, #40]                  ; 8-byte Reload
	ldr	x0, [sp, #11568]                ; 8-byte Reload
	b	LBB0_1523
LBB0_1522:                              ; %else4002
                                        ;   in Loop: Header=BB0_1523 Depth=1
	ldr	q2, [sp, #13056]                ; 16-byte Reload
	add.2d	v8, v8, v2
	add.2d	v9, v9, v3
	ldr	q2, [sp, #12880]                ; 16-byte Reload
	add.2d	v10, v10, v2
	ldr	q2, [sp, #13312]                ; 16-byte Reload
	add.2d	v0, v0, v2
	fmov	x9, d0
	cmp	x9, #2
	b.ge	LBB0_1555
LBB0_1523:                              ; %direct.true933
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v11, v0, #5
	ldr	q2, [sp, #12304]                ; 16-byte Reload
	orr.16b	v11, v11, v2
	add.2d	v13, v5, v11
	ldr	d2, [sp, #12344]                ; 8-byte Reload
	fmov	w9, s2
	movi.2d	v12, #0000000000000000
	movi.2d	v11, #0000000000000000
	tbnz	w9, #0, LBB0_1548
; %bb.1524:                             ; %else3926
                                        ;   in Loop: Header=BB0_1523 Depth=1
	tbnz	w9, #1, LBB0_1549
LBB0_1525:                              ; %else3932
                                        ;   in Loop: Header=BB0_1523 Depth=1
	shl.2d	v13, v8, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v13, v13, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	add.2d	v13, v2, v13
	tbnz	w9, #2, LBB0_1550
LBB0_1526:                              ; %else3938
                                        ;   in Loop: Header=BB0_1523 Depth=1
	tbnz	w9, #3, LBB0_1551
LBB0_1527:                              ; %else3944
                                        ;   in Loop: Header=BB0_1523 Depth=1
	shl.2d	v13, v9, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v13, v13, v2
	add.2d	v13, v4, v13
	tbnz	w9, #4, LBB0_1552
LBB0_1528:                              ; %else3950
                                        ;   in Loop: Header=BB0_1523 Depth=1
	tbnz	w9, #5, LBB0_1553
LBB0_1529:                              ; %else3956
                                        ;   in Loop: Header=BB0_1523 Depth=1
	shl.2d	v13, v10, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v13, v13, v2
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	add.2d	v13, v2, v13
	tbnz	w9, #6, LBB0_1554
LBB0_1530:                              ; %else3962
                                        ;   in Loop: Header=BB0_1523 Depth=1
	tbz	w9, #7, LBB0_1532
LBB0_1531:                              ; %cond.load3964
                                        ;   in Loop: Header=BB0_1523 Depth=1
	mov.d	x9, v13[1]
	ld1.s	{ v11 }[3], [x9]
LBB0_1532:                              ; %else3968
                                        ;   in Loop: Header=BB0_1523 Depth=1
	and.16b	v13, v14, v10
	mov.16b	v2, v14
	ldr	q3, [sp, #12736]                ; 16-byte Reload
	and.16b	v14, v3, v8
	and.16b	v15, v6, v9
	and.16b	v16, v1, v0
	mov.d	x9, v16[1]
	ldr	x11, [sp, #11704]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d16
	sdiv	x11, x10, x8
	msub	x10, x11, x8, x10
	fmov	d16, x10
	mov.d	v16[1], x9
	mov.d	x9, v15[1]
	sdiv	x10, x9, x26
	msub	x9, x10, x26, x9
	fmov	x10, d15
	sdiv	x11, x10, x13
	msub	x10, x11, x13, x10
	fmov	d15, x10
	mov.d	v15[1], x9
	mov.d	x9, v14[1]
	sdiv	x10, x9, x0
	msub	x9, x10, x0, x9
	fmov	x10, d14
	sdiv	x11, x10, x14
	msub	x10, x11, x14, x10
	fmov	d14, x10
	mov.d	v14[1], x9
	mov.d	x9, v13[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d13
	sdiv	x11, x10, x15
	msub	x10, x11, x15, x10
	fmov	d13, x10
	mov.d	v13[1], x9
	bit.16b	v26, v13, v2
	bit.16b	v23, v14, v3
	bit.16b	v24, v15, v6
	bit.16b	v22, v16, v1
	ldr	q3, [sp, #13168]                ; 16-byte Reload
	movi	d2, #0xffffffffffffff
	bit.8b	v31, v2, v3
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	bit.16b	v27, v2, v1
	mov.16b	v16, v17
	bsl.16b	v16, v12, v21
	and.16b	v21, v20, v16
	ldr	q2, [sp, #3088]                 ; 16-byte Reload
	add.2d	v16, v26, v2
	ldr	q2, [sp, #3120]                 ; 16-byte Reload
	add.2d	v12, v24, v2
	ldr	q2, [sp, #3136]                 ; 16-byte Reload
	add.2d	v13, v22, v2
	ldr	q2, [sp, #3104]                 ; 16-byte Reload
	add.2d	v14, v23, v2
	ldr	q2, [sp, #1904]                 ; 16-byte Reload
	add.2d	v15, v22, v2
	dup.2d	v2, x16
	cmhi.2d	v14, v2, v14
	cmhi.2d	v13, v2, v13
	uzp1.4s	v13, v13, v14
	cmhi.2d	v12, v2, v12
	cmhi.2d	v2, v2, v16
	uzp1.4s	v2, v12, v2
	uzp1.8h	v2, v13, v2
	xtn.8b	v2, v2
	mov.d	x9, v15[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d15
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d16, x10
	mov.d	v16[1], x9
	add.2d	v16, v16, v27
	and.8b	v12, v3, v31
	and.8b	v2, v12, v2
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	ldr	d3, [sp, #13344]                ; 8-byte Reload
	and.8b	v2, v2, v3
	addv.8b	b2, v2
	fmov	w9, s2
	shl.2d	v2, v16, #2
	dup.2d	v12, x17
	add.2d	v13, v12, v2
	tbz	w9, #0, LBB0_1534
; %bb.1533:                             ; %cond.store3971
                                        ;   in Loop: Header=BB0_1523 Depth=1
	fmov	x10, d13
	str	s21, [x10]
LBB0_1534:                              ; %else3974
                                        ;   in Loop: Header=BB0_1523 Depth=1
	tbz	w9, #1, LBB0_1536
; %bb.1535:                             ; %cond.store3975
                                        ;   in Loop: Header=BB0_1523 Depth=1
	mov.d	x10, v13[1]
	st1.s	{ v21 }[1], [x10]
LBB0_1536:                              ; %else3978
                                        ;   in Loop: Header=BB0_1523 Depth=1
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	add.2d	v2, v23, v2
	mov.d	x10, v2[1]
	ldr	q16, [sp, #12736]               ; 16-byte Reload
	ldr	q3, [sp, #672]                  ; 16-byte Reload
	bit.16b	v28, v3, v16
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	x11, d2
	lsl	x12, x11, #3
	sub	x11, x12, x11
	fmov	d2, x11
	mov.d	v2[1], x10
	add.2d	v2, v2, v28
	shl.2d	v2, v2, #2
	add.2d	v13, v12, v2
	ldr	q14, [sp, #12720]               ; 16-byte Reload
	tbz	w9, #2, LBB0_1538
; %bb.1537:                             ; %cond.store3979
                                        ;   in Loop: Header=BB0_1523 Depth=1
	fmov	x10, d13
	st1.s	{ v21 }[2], [x10]
LBB0_1538:                              ; %else3982
                                        ;   in Loop: Header=BB0_1523 Depth=1
	tbz	w9, #3, LBB0_1540
; %bb.1539:                             ; %cond.store3983
                                        ;   in Loop: Header=BB0_1523 Depth=1
	mov.d	x10, v13[1]
	st1.s	{ v21 }[3], [x10]
LBB0_1540:                              ; %else3986
                                        ;   in Loop: Header=BB0_1523 Depth=1
	ldr	q2, [sp, #688]                  ; 16-byte Reload
	bit.16b	v29, v2, v6
	mov.16b	v2, v18
	bsl.16b	v2, v11, v25
	ldr	q3, [sp, #1920]                 ; 16-byte Reload
	add.2d	v16, v24, v3
	mov.d	x10, v16[1]
	and.16b	v25, v19, v2
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	x11, d16
	lsl	x12, x11, #3
	sub	x11, x12, x11
	fmov	d2, x11
	mov.d	v2[1], x10
	add.2d	v2, v2, v29
	shl.2d	v2, v2, #2
	add.2d	v11, v12, v2
	tbz	w9, #4, LBB0_1542
; %bb.1541:                             ; %cond.store3987
                                        ;   in Loop: Header=BB0_1523 Depth=1
	fmov	x10, d11
	str	s25, [x10]
LBB0_1542:                              ; %else3990
                                        ;   in Loop: Header=BB0_1523 Depth=1
	ldr	q3, [sp, #13328]                ; 16-byte Reload
	tbz	w9, #5, LBB0_1544
; %bb.1543:                             ; %cond.store3991
                                        ;   in Loop: Header=BB0_1523 Depth=1
	mov.d	x10, v11[1]
	st1.s	{ v25 }[1], [x10]
LBB0_1544:                              ; %else3994
                                        ;   in Loop: Header=BB0_1523 Depth=1
	ldr	q2, [sp, #1952]                 ; 16-byte Reload
	add.2d	v2, v26, v2
	mov.d	x10, v2[1]
	bit.16b	v30, v7, v14
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	x11, d2
	lsl	x12, x11, #3
	sub	x11, x12, x11
	fmov	d2, x11
	mov.d	v2[1], x10
	add.2d	v2, v2, v30
	shl.2d	v2, v2, #2
	add.2d	v11, v12, v2
	tbz	w9, #6, LBB0_1546
; %bb.1545:                             ; %cond.store3995
                                        ;   in Loop: Header=BB0_1523 Depth=1
	fmov	x10, d11
	st1.s	{ v25 }[2], [x10]
LBB0_1546:                              ; %else3998
                                        ;   in Loop: Header=BB0_1523 Depth=1
	tbz	w9, #7, LBB0_1522
; %bb.1547:                             ; %cond.store3999
                                        ;   in Loop: Header=BB0_1523 Depth=1
	mov.d	x9, v11[1]
	st1.s	{ v25 }[3], [x9]
	b	LBB0_1522
LBB0_1548:                              ; %cond.load3922
                                        ;   in Loop: Header=BB0_1523 Depth=1
	fmov	x10, d13
	ldr	s12, [x10]
	tbz	w9, #1, LBB0_1525
LBB0_1549:                              ; %cond.load3928
                                        ;   in Loop: Header=BB0_1523 Depth=1
	mov.d	x10, v13[1]
	ld1.s	{ v12 }[1], [x10]
	shl.2d	v13, v8, #5
	ldr	q2, [sp, #12272]                ; 16-byte Reload
	orr.16b	v13, v13, v2
	ldr	q2, [sp, #13264]                ; 16-byte Reload
	add.2d	v13, v2, v13
	tbz	w9, #2, LBB0_1526
LBB0_1550:                              ; %cond.load3934
                                        ;   in Loop: Header=BB0_1523 Depth=1
	fmov	x10, d13
	ld1.s	{ v12 }[2], [x10]
	tbz	w9, #3, LBB0_1527
LBB0_1551:                              ; %cond.load3940
                                        ;   in Loop: Header=BB0_1523 Depth=1
	mov.d	x10, v13[1]
	ld1.s	{ v12 }[3], [x10]
	shl.2d	v13, v9, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v13, v13, v2
	add.2d	v13, v4, v13
	tbz	w9, #4, LBB0_1528
LBB0_1552:                              ; %cond.load3946
                                        ;   in Loop: Header=BB0_1523 Depth=1
	fmov	x10, d13
	ld1.s	{ v11 }[0], [x10]
	tbz	w9, #5, LBB0_1529
LBB0_1553:                              ; %cond.load3952
                                        ;   in Loop: Header=BB0_1523 Depth=1
	mov.d	x10, v13[1]
	ld1.s	{ v11 }[1], [x10]
	shl.2d	v13, v10, #5
	ldr	q2, [sp, #12288]                ; 16-byte Reload
	orr.16b	v13, v13, v2
	ldr	q2, [sp, #13296]                ; 16-byte Reload
	add.2d	v13, v2, v13
	tbz	w9, #6, LBB0_1530
LBB0_1554:                              ; %cond.load3958
                                        ;   in Loop: Header=BB0_1523 Depth=1
	fmov	x10, d13
	ld1.s	{ v11 }[2], [x10]
	tbnz	w9, #7, LBB0_1531
	b	LBB0_1532
LBB0_1555:
	add	sp, sp, #9, lsl #12             ; =36864
	add	sp, sp, #320
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_1556:                              ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh21, Lloh22
	.loh AdrpAdrp	Lloh19, Lloh21
	.loh AdrpLdr	Lloh19, Lloh20
	.loh AdrpAdrp	Lloh17, Lloh19
	.loh AdrpLdr	Lloh17, Lloh18
	.loh AdrpLdr	Lloh16, Lloh23
	.loh AdrpLdr	Lloh13, Lloh14
	.loh AdrpLdr	Lloh12, Lloh15
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh35, Lloh36
	.loh AdrpLdr	Lloh34, Lloh40
	.loh AdrpLdr	Lloh33, Lloh45
	.loh AdrpLdr	Lloh32, Lloh44
	.loh AdrpLdr	Lloh31, Lloh43
	.loh AdrpLdr	Lloh30, Lloh47
	.loh AdrpLdr	Lloh29, Lloh46
	.loh AdrpLdr	Lloh28, Lloh42
	.loh AdrpLdr	Lloh27, Lloh41
	.loh AdrpLdr	Lloh26, Lloh39
	.loh AdrpLdr	Lloh25, Lloh38
	.loh AdrpLdr	Lloh24, Lloh37
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

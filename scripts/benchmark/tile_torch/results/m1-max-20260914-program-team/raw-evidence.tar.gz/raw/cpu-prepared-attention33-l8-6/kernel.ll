; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [64 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [32 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [32 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [32 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [32 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local13 = alloca [64 x i8], align 4
  %.splatinsert14 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local13, i64 0
  %.splat15 = shufflevector <8 x ptr> %.splatinsert14, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat15, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local16 = alloca [64 x i8], align 4
  %.splatinsert17 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local16, i64 0
  %.splat18 = shufflevector <8 x ptr> %.splatinsert17, <8 x ptr> poison, <8 x i32> zeroinitializer
  %12 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat18, 0
  %13 = insertvalue { <8 x ptr>, <8 x i64> } %12, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local19 = alloca [1120 x i8], align 4
  %.splatinsert20 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local19, i64 0
  %.splat21 = shufflevector <8 x ptr> %.splatinsert20, <8 x ptr> poison, <8 x i32> zeroinitializer
  %14 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat21, 0
  %15 = insertvalue { <8 x ptr>, <8 x i64> } %14, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local22 = alloca [1056 x i8], align 4
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local25 = alloca [320 x i8], align 4
  %.splatinsert26 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local25, i64 0
  %.splat27 = shufflevector <8 x ptr> %.splatinsert26, <8 x ptr> poison, <8 x i32> zeroinitializer
  %18 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat27, 0
  %19 = insertvalue { <8 x ptr>, <8 x i64> } %18, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local28 = alloca [320 x i8], align 4
  %.splatinsert29 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local28, i64 0
  %.splat30 = shufflevector <8 x ptr> %.splatinsert29, <8 x ptr> poison, <8 x i32> zeroinitializer
  %20 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat30, 0
  %21 = insertvalue { <8 x ptr>, <8 x i64> } %20, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local31 = alloca [320 x i8], align 8
  %.splatinsert32 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local31, i64 0
  %.splat33 = shufflevector <8 x ptr> %.splatinsert32, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat33, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local34 = alloca [320 x i8], align 8
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %24 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %25 = insertvalue { <8 x ptr>, <8 x i64> } %24, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local37 = alloca [40 x i8], align 1
  %.splatinsert38 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local37, i64 0
  %.splat39 = shufflevector <8 x ptr> %.splatinsert38, <8 x ptr> poison, <8 x i32> zeroinitializer
  %26 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat39, 0
  %27 = insertvalue { <8 x ptr>, <8 x i64> } %26, <8 x i64> <i64 0, i64 5, i64 10, i64 15, i64 20, i64 25, i64 30, i64 35>, 1
  %tile_snapshot.local40 = alloca [320 x i8], align 8
  %.splatinsert41 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local40, i64 0
  %.splat42 = shufflevector <8 x ptr> %.splatinsert41, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat42, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local43 = alloca [320 x i8], align 8
  %.splatinsert44 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local43, i64 0
  %.splat45 = shufflevector <8 x ptr> %.splatinsert44, <8 x ptr> poison, <8 x i32> zeroinitializer
  %30 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat45, 0
  %31 = insertvalue { <8 x ptr>, <8 x i64> } %30, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local46 = alloca [64 x i8], align 8
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %32 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %33 = insertvalue { <8 x ptr>, <8 x i64> } %32, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local49 = alloca [64 x i8], align 8
  %.splatinsert50 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local49, i64 0
  %.splat51 = shufflevector <8 x ptr> %.splatinsert50, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat51, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local52 = alloca [64 x i8], align 8
  %.splatinsert53 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local52, i64 0
  %.splat54 = shufflevector <8 x ptr> %.splatinsert53, <8 x ptr> poison, <8 x i32> zeroinitializer
  %36 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat54, 0
  %37 = insertvalue { <8 x ptr>, <8 x i64> } %36, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local55 = alloca [64 x i8], align 8
  %.splatinsert56 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local55, i64 0
  %.splat57 = shufflevector <8 x ptr> %.splatinsert56, <8 x ptr> poison, <8 x i32> zeroinitializer
  %38 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat57, 0
  %39 = insertvalue { <8 x ptr>, <8 x i64> } %38, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local58 = alloca [80 x i8], align 1
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 10, i64 20, i64 30, i64 40, i64 50, i64 60, i64 70>, 1
  %tile_snapshot.local61 = alloca [80 x i8], align 1
  %.splatinsert62 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local61, i64 0
  %.splat63 = shufflevector <8 x ptr> %.splatinsert62, <8 x ptr> poison, <8 x i32> zeroinitializer
  %42 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat63, 0
  %43 = insertvalue { <8 x ptr>, <8 x i64> } %42, <8 x i64> <i64 0, i64 10, i64 20, i64 30, i64 40, i64 50, i64 60, i64 70>, 1
  %tile_snapshot.local64 = alloca [320 x i8], align 4
  %.splatinsert65 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local64, i64 0
  %.splat66 = shufflevector <8 x ptr> %.splatinsert65, <8 x ptr> poison, <8 x i32> zeroinitializer
  %44 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat66, 0
  %45 = insertvalue { <8 x ptr>, <8 x i64> } %44, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local67 = alloca [64 x i8], align 4
  %.splatinsert68 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local67, i64 0
  %.splat69 = shufflevector <8 x ptr> %.splatinsert68, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat69, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local70 = alloca [32 x i8], align 4
  %.splatinsert71 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local70, i64 0
  %.splat72 = shufflevector <8 x ptr> %.splatinsert71, <8 x ptr> poison, <8 x i32> zeroinitializer
  %48 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat72, 0
  %49 = insertvalue { <8 x ptr>, <8 x i64> } %48, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local73 = alloca [32 x i8], align 4
  %.splatinsert74 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local73, i64 0
  %.splat75 = shufflevector <8 x ptr> %.splatinsert74, <8 x ptr> poison, <8 x i32> zeroinitializer
  %50 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat75, 0
  %51 = insertvalue { <8 x ptr>, <8 x i64> } %50, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local76 = alloca [32 x i8], align 4
  %.splatinsert77 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local76, i64 0
  %.splat78 = shufflevector <8 x ptr> %.splatinsert77, <8 x ptr> poison, <8 x i32> zeroinitializer
  %52 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat78, 0
  %53 = insertvalue { <8 x ptr>, <8 x i64> } %52, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local79 = alloca [320 x i8], align 4
  %.splatinsert80 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local79, i64 0
  %.splat81 = shufflevector <8 x ptr> %.splatinsert80, <8 x ptr> poison, <8 x i32> zeroinitializer
  %54 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat81, 0
  %55 = insertvalue { <8 x ptr>, <8 x i64> } %54, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local82 = alloca [320 x i8], align 4
  %.splatinsert83 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local82, i64 0
  %.splat84 = shufflevector <8 x ptr> %.splatinsert83, <8 x ptr> poison, <8 x i32> zeroinitializer
  %56 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat84, 0
  %57 = insertvalue { <8 x ptr>, <8 x i64> } %56, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local85 = alloca [320 x i8], align 4
  %.splatinsert86 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local85, i64 0
  %.splat87 = shufflevector <8 x ptr> %.splatinsert86, <8 x ptr> poison, <8 x i32> zeroinitializer
  %58 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat87, 0
  %59 = insertvalue { <8 x ptr>, <8 x i64> } %58, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local88 = alloca [32 x i8], align 4
  %.splatinsert89 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local88, i64 0
  %.splat90 = shufflevector <8 x ptr> %.splatinsert89, <8 x ptr> poison, <8 x i32> zeroinitializer
  %60 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat90, 0
  %61 = insertvalue { <8 x ptr>, <8 x i64> } %60, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local91 = alloca [64 x i8], align 4
  %.splatinsert92 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local91, i64 0
  %.splat93 = shufflevector <8 x ptr> %.splatinsert92, <8 x ptr> poison, <8 x i32> zeroinitializer
  %62 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat93, 0
  %63 = insertvalue { <8 x ptr>, <8 x i64> } %62, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local94 = alloca [32 x i8], align 4
  %.splatinsert95 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local94, i64 0
  %.splat96 = shufflevector <8 x ptr> %.splatinsert95, <8 x ptr> poison, <8 x i32> zeroinitializer
  %64 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat96, 0
  %65 = insertvalue { <8 x ptr>, <8 x i64> } %64, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local97 = alloca [64 x i8], align 4
  %.splatinsert98 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local97, i64 0
  %.splat99 = shufflevector <8 x ptr> %.splatinsert98, <8 x ptr> poison, <8 x i32> zeroinitializer
  %66 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat99, 0
  %67 = insertvalue { <8 x ptr>, <8 x i64> } %66, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local100 = alloca [64 x i8], align 4
  %.splatinsert101 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local100, i64 0
  %.splat102 = shufflevector <8 x ptr> %.splatinsert101, <8 x ptr> poison, <8 x i32> zeroinitializer
  %68 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat102, 0
  %69 = insertvalue { <8 x ptr>, <8 x i64> } %68, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local103 = alloca [64 x i8], align 4
  %.splatinsert104 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local103, i64 0
  %.splat105 = shufflevector <8 x ptr> %.splatinsert104, <8 x ptr> poison, <8 x i32> zeroinitializer
  %70 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat105, 0
  %71 = insertvalue { <8 x ptr>, <8 x i64> } %70, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill106 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill106, align 64
  %.spill107 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill107, align 64
  %.spill108 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill108, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill109 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill109, align 1
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %tile_snapshot.spill112 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill112, align 64
  %.slot113 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot113, align 64
  %tile_snapshot.spill114 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill114, align 64
  %tile_snapshot.spill115 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill115, align 64
  %.slot116 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot116, align 64
  %tile_snapshot.spill117 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill117, align 64
  %tile_snapshot.spill118 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill118, align 64
  %.slot119 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot119, align 64
  %.slot120 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot120, align 64
  %.spill121 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill121, align 64
  %tile_snapshot.spill122 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill122, align 64
  %.slot123 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot123, align 64
  %.spill124 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill124, align 1
  %.slot125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot125, align 32
  %tile_snapshot.spill126 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill126, align 64
  %.slot127 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot127, align 64
  %.spill128 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill128, align 1
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %tile_snapshot.spill130 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill130, align 64
  %.slot131 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot131, align 64
  %.spill132 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill132, align 64
  %.spill133 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill133, align 1
  %.spill134 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill134, align 64
  %.spill135 = alloca i64, align 8
  store i64 0, ptr %.spill135, align 4
  %.slot136 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot136, align 64
  %.slot137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot137, align 32
  %.spill138 = alloca i64, align 8
  store i64 0, ptr %.spill138, align 4
  %.spill139 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill139, align 64
  %.slot140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.slot142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot142, align 32
  %tile_snapshot.spill143 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill143, align 64
  %.slot144 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot144, align 64
  %.spill145 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill145, align 1
  %.slot146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot146, align 32
  %tile_snapshot.spill147 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill147, align 64
  %.slot148 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot148, align 64
  %tile_snapshot.spill149 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill149, align 64
  %.slot150 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot150, align 64
  %.spill151 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill151, align 1
  %.slot152 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot152, align 64
  %tile_snapshot.spill153 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill153, align 64
  %.slot154 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot154, align 64
  %.spill155 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill155, align 1
  %.slot156 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot156, align 64
  %tile_snapshot.spill157 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill157, align 64
  %.slot158 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot158, align 64
  %tile_snapshot.spill159 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill159, align 64
  %.slot160 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot160, align 64
  %.spill161 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill161, align 1
  %.slot162 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot162, align 64
  %tile_snapshot.spill163 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill163, align 64
  %.slot164 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot164, align 64
  %tile_snapshot.spill165 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill165, align 64
  %.slot166 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot166, align 64
  %.spill167 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill167, align 1
  %.slot168 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot168, align 64
  %tile_snapshot.spill169 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill169, align 64
  %.slot170 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot170, align 64
  %.spill171 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill171, align 1
  %.slot172 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot172, align 64
  %tile_snapshot.spill173 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill173, align 64
  %.slot174 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot174, align 64
  %.spill175 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill175, align 1
  %.slot176 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot176, align 64
  %tile_snapshot.spill177 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill177, align 64
  %.slot178 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot178, align 64
  %.spill179 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill179, align 64
  %.spill180 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill180, align 1
  %.slot181 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot181, align 64
  %.spill182 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill182, align 64
  %.slot183 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot183, align 64
  %tile_snapshot.spill184 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill184, align 64
  %.slot185 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot185, align 64
  %.spill186 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill186, align 64
  %.spill187 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill187, align 1
  %.spill188 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill188, align 64
  %.slot189 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot189, align 1
  %.slot190 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot190, align 1
  %tile_snapshot.spill191 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill191, align 64
  %.slot192 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot192, align 64
  %.spill193 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill193, align 64
  %.spill194 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill194, align 1
  %.spill195 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill195, align 64
  %.spill196 = alloca i64, align 8
  store i64 0, ptr %.spill196, align 4
  %.slot197 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot197, align 1
  %.slot198 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot198, align 32
  %tile_snapshot.spill199 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill199, align 64
  %.slot200 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot200, align 64
  %.spill201 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill201, align 64
  %.slot202 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot202, align 64
  %.slot203 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot203, align 32
  %.slot204 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot204, align 1
  %.spill205 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill205, align 1
  %.slot206 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot206, align 32
  %tile_snapshot.spill207 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill207, align 64
  %.slot208 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot208, align 64
  %.spill209 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill209, align 1
  %.spill210 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill210, align 64
  %.slot211 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot211, align 32
  %.slot212 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot212, align 32
  %tile_snapshot.spill213 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill213, align 64
  %.slot214 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot214, align 64
  %.spill215 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill215, align 1
  %.spill216 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill216, align 64
  %.slot217 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot217, align 32
  %.slot218 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot218, align 32
  %tile_snapshot.spill219 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill219, align 64
  %.slot220 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot220, align 64
  %.spill221 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill221, align 1
  %.slot222 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot222, align 32
  %tile_snapshot.spill223 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill223, align 64
  %.slot224 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot224, align 64
  %.spill225 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill225, align 1
  %.spill226 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill226, align 64
  %.spill227 = alloca i64, align 8
  store i64 0, ptr %.spill227, align 4
  %.slot228 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot228, align 32
  %.spill229 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill229, align 64
  %.slot230 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot230, align 32
  %tile_snapshot.spill231 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill231, align 64
  %.slot232 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot232, align 64
  %.spill233 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill233, align 1
  %.slot234 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot234, align 32
  %tile_snapshot.spill235 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill235, align 64
  %.slot236 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot236, align 64
  %.spill237 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill237, align 64
  %.spill238 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill238, align 1
  %.spill239 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill239, align 64
  %.spill240 = alloca i64, align 8
  store i64 0, ptr %.spill240, align 4
  %.slot241 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot241, align 1
  %.slot242 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot242, align 32
  %tile_snapshot.spill243 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill243, align 64
  %.slot244 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot244, align 64
  %.spill245 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill245, align 1
  %.spill246 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill246, align 64
  %.slot247 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot247, align 32
  %.slot248 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot248, align 32
  %tile_snapshot.spill249 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill249, align 64
  %.slot250 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot250, align 64
  %.spill251 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill251, align 64
  %.slot252 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot252, align 64
  %.slot253 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot253, align 32
  %.slot254 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot254, align 1
  %.spill255 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill255, align 1
  %.slot256 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot256, align 32
  %tile_snapshot.spill257 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill257, align 64
  %.slot258 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot258, align 64
  %.spill259 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill259, align 1
  %.spill260 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill260, align 64
  %.slot261 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot261, align 32
  %.slot262 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot262, align 32
  %tile_snapshot.spill263 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill263, align 64
  %.slot264 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot264, align 64
  %.spill265 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill265, align 1
  %.spill266 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill266, align 64
  %.spill267 = alloca i64, align 8
  store i64 0, ptr %.spill267, align 4
  %.slot268 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot268, align 32
  %.spill269 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill269, align 64
  %.slot270 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot270, align 32
  %tile_snapshot.spill271 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill271, align 64
  %.slot272 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot272, align 64
  %.spill273 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill273, align 64
  %.spill274 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill274, align 1
  %.spill275 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill275, align 64
  %.spill276 = alloca i64, align 8
  store i64 0, ptr %.spill276, align 4
  %.slot277 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot277, align 32
  %.slot278 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot278, align 64
  %.slot279 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot279, align 32
  %.spill280 = alloca i64, align 8
  store i64 0, ptr %.spill280, align 4
  %.spill281 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill281, align 64
  %.slot282 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot282, align 32
  %.spill283 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill283, align 32
  %.slot284 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot284, align 32
  %.slot285 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot285, align 64
  %.spill286 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill286, align 1
  %.slot287 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot287, align 32
  %.slot288 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot288, align 64
  %.spill289 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill289, align 1
  %.slot290 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot290, align 32
  %.slot291 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot291, align 64
  %.spill292 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill292, align 1
  %.slot293 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot293, align 32
  %.slot294 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot294, align 64
  %.spill295 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill295, align 1
  %.slot296 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot296, align 32
  %.slot297 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot297, align 64
  %.spill298 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill298, align 1
  %.slot299 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot299, align 32
  %.slot300 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot300, align 64
  %.spill301 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill301, align 1
  %.slot302 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot302, align 32
  %tile_snapshot.spill303 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill303, align 64
  %.slot304 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot304, align 64
  %.spill305 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill305, align 1
  %.spill306 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill306, align 64
  %.spill307 = alloca i64, align 8
  store i64 0, ptr %.spill307, align 4
  %.slot308 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot308, align 32
  %.spill309 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill309, align 64
  %.slot310 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot310, align 32
  %.slot311 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot311, align 64
  %.spill312 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill312, align 1
  %.spill313 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill313, align 64
  %.spill314 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill314, align 64
  %.spill315 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill315, align 64
  %.spill316 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill316, align 64
  %.spill317 = alloca i64, align 8
  store i64 0, ptr %.spill317, align 4
  %.slot318 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot318, align 32
  %72 = getelementptr i8, ptr %argument_buffer, i64 0
  %73 = load ptr, ptr %72, align 16
  %74 = getelementptr i8, ptr %72, i64 8
  %75 = load i64, ptr %74, align 8
  %76 = insertvalue { ptr, i64 } poison, ptr %73, 0
  %77 = insertvalue { ptr, i64 } %76, i64 %75, 1
  %78 = getelementptr i8, ptr %argument_buffer, i64 16
  %79 = load ptr, ptr %78, align 16
  %80 = getelementptr i8, ptr %78, i64 8
  %81 = load i64, ptr %80, align 8
  %82 = insertvalue { ptr, i64 } poison, ptr %79, 0
  %83 = insertvalue { ptr, i64 } %82, i64 %81, 1
  %84 = getelementptr i8, ptr %argument_buffer, i64 32
  %85 = load ptr, ptr %84, align 16
  %86 = getelementptr i8, ptr %84, i64 8
  %87 = load i64, ptr %86, align 8
  %88 = insertvalue { ptr, i64 } poison, ptr %85, 0
  %89 = insertvalue { ptr, i64 } %88, i64 %87, 1
  %90 = getelementptr i8, ptr %argument_buffer, i64 48
  %91 = load ptr, ptr %90, align 16
  %92 = getelementptr i8, ptr %90, i64 8
  %93 = load i64, ptr %92, align 8
  %94 = insertvalue { ptr, i64 } poison, ptr %91, 0
  %95 = insertvalue { ptr, i64 } %94, i64 %93, 1
  %96 = load i32, ptr %launch_config, align 4
  %97 = getelementptr i8, ptr %launch_config, i64 12
  %98 = load i32, ptr %97, align 4
  %99 = getelementptr i8, ptr %launch_config, i64 4
  %100 = load i32, ptr %99, align 4
  %101 = getelementptr i8, ptr %launch_config, i64 16
  %102 = load i32, ptr %101, align 4
  %103 = getelementptr i8, ptr %launch_config, i64 8
  %104 = load i32, ptr %103, align 4
  %105 = getelementptr i8, ptr %launch_config, i64 20
  %106 = load i32, ptr %105, align 4
  %107 = getelementptr i8, ptr %launch_config, i64 36
  %108 = load i32, ptr %107, align 4
  %.splatinsert319 = insertelement <8 x i32> poison, i32 %108, i64 0
  %.splat320 = shufflevector <8 x i32> %.splatinsert319, <8 x i32> poison, <8 x i32> zeroinitializer
  %109 = add <8 x i32> %.splat320, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %110 = mul i32 %96, 32
  %.splatinsert321 = insertelement <8 x i32> poison, i32 %110, i64 0
  %.splat322 = shufflevector <8 x i32> %.splatinsert321, <8 x i32> poison, <8 x i32> zeroinitializer
  %111 = add <8 x i32> %.splat322, %109
  %112 = mul i32 %100, 1
  %.splatinsert323 = insertelement <8 x i32> poison, i32 %112, i64 0
  %.splat324 = shufflevector <8 x i32> %.splatinsert323, <8 x i32> poison, <8 x i32> zeroinitializer
  %113 = add <8 x i32> %.splat324, zeroinitializer
  %114 = mul i32 %104, 1
  %.splatinsert325 = insertelement <8 x i32> poison, i32 %114, i64 0
  %.splat326 = shufflevector <8 x i32> %.splatinsert325, <8 x i32> poison, <8 x i32> zeroinitializer
  %115 = add <8 x i32> %.splat326, zeroinitializer
  %116 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %111, 0
  %117 = insertvalue [3 x <8 x i32>] %116, <8 x i32> %113, 1
  %118 = insertvalue [3 x <8 x i32>] %117, <8 x i32> %115, 2
  %.splatinsert327 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat328 = shufflevector <8 x i32> %.splatinsert327, <8 x i32> poison, <8 x i32> zeroinitializer
  %119 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat328
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  br i1 %120, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %121 = extractvalue [3 x <8 x i32>] %118, 0
  %122 = load <8 x i64>, ptr %.spill, align 64
  %123 = select <8 x i1> %119, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill, align 64
  %124 = sub <8 x i32> %121, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %125 = select <8 x i1> %119, <8 x i32> %124, <8 x i32> zeroinitializer
  %126 = select <8 x i1> %119, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %127 = lshr <8 x i32> %125, %126
  %128 = zext <8 x i32> %127 to <8 x i64>
  %129 = select <8 x i1> %119, <8 x i64> %128, <8 x i64> zeroinitializer
  %130 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %131 = sdiv <8 x i64> %129, %130
  %132 = load <8 x i64>, ptr %.spill106, align 64
  %133 = select <8 x i1> %119, <8 x i64> %131, <8 x i64> %132
  store <8 x i64> %133, ptr %.spill106, align 64
  %134 = select <8 x i1> %119, <8 x i64> %128, <8 x i64> zeroinitializer
  %135 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %136 = sdiv <8 x i64> %134, %135
  %137 = select <8 x i1> %119, <8 x i64> %136, <8 x i64> zeroinitializer
  %138 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %139 = srem <8 x i64> %137, %138
  %140 = mul <8 x i64> %139, splat (i64 2)
  %141 = load <8 x i64>, ptr %.spill107, align 64
  %142 = select <8 x i1> %119, <8 x i64> %140, <8 x i64> %141
  store <8 x i64> %142, ptr %.spill107, align 64
  %143 = select <8 x i1> %119, <8 x i64> %131, <8 x i64> zeroinitializer
  %144 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %145 = sdiv <8 x i64> %143, %144
  %146 = load <8 x i64>, ptr %.spill108, align 64
  %147 = select <8 x i1> %119, <8 x i64> %145, <8 x i64> %146
  store <8 x i64> %147, ptr %.spill108, align 64
  %148 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 0
  %151 = select <8 x i1> %119, <8 x ptr> %149, <8 x ptr> %150
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %154 = select <8 x i1> %119, <8 x i64> %152, <8 x i64> %153
  %155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %151, 0
  %156 = insertvalue { <8 x ptr>, <8 x i64> } %155, <8 x i64> %154, 1
  store { <8 x ptr>, <8 x i64> } %156, ptr %tile_snapshot.spill, align 64
  %157 = load <8 x i64>, ptr %.slot, align 64
  %158 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %157
  store <8 x i64> %158, ptr %.slot, align 64
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.6, %direct.schedule.0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %159 = icmp slt <8 x i64> %.state, splat (i64 2)
  %160 = extractelement <8 x i1> %159, i32 0
  br i1 %160, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state329 = load <8 x i64>, ptr %.slot, align 64
  %161 = select <8 x i1> %119, <8 x i64> %.state329, <8 x i64> zeroinitializer
  %162 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %163 = srem <8 x i64> %161, %162
  %.state330 = load <8 x i64>, ptr %.slot, align 64
  %164 = select <8 x i1> %119, <8 x i64> %.state330, <8 x i64> zeroinitializer
  %165 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %166 = sdiv <8 x i64> %164, %165
  %167 = mul <8 x i64> %163, splat (i64 8)
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %168 = add <8 x i64> %167, %.spill.load
  %169 = icmp slt <8 x i64> %168, splat (i64 7)
  %170 = load <8 x i1>, ptr %.spill109, align 1
  %171 = select <8 x i1> %119, <8 x i1> %169, <8 x i1> %170
  store <8 x i1> %171, ptr %.spill109, align 1
  %172 = select <8 x i1> %169, <8 x i64> %168, <8 x i64> splat (i64 6)
  %173 = select <8 x i1> %119, <8 x i64> %166, <8 x i64> zeroinitializer
  %174 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %175 = srem <8 x i64> %173, %174
  %176 = select <8 x i1> %119, <8 x i64> %166, <8 x i64> zeroinitializer
  %177 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %178 = sdiv <8 x i64> %176, %177
  %179 = select <8 x i1> %119, <8 x i64> %178, <8 x i64> zeroinitializer
  %180 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %181 = srem <8 x i64> %179, %180
  %182 = select <8 x i1> %119, <8 x i64> %178, <8 x i64> zeroinitializer
  %183 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %184 = sdiv <8 x i64> %182, %183
  %185 = select <8 x i1> %119, <8 x i64> %184, <8 x i64> zeroinitializer
  %186 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %187 = srem <8 x i64> %185, %186
  %188 = add <8 x i64> zeroinitializer, %187
  %189 = add <8 x i64> zeroinitializer, %188
  %.spill.load331 = load <8 x i64>, ptr %.spill106, align 64
  %190 = add <8 x i64> %.spill.load331, %181
  %191 = mul <8 x i64> %189, splat (i64 2)
  %192 = add <8 x i64> %191, %190
  %.spill.load332 = load <8 x i64>, ptr %.spill107, align 64
  %193 = add <8 x i64> %.spill.load332, %175
  %194 = mul <8 x i64> %192, splat (i64 3)
  %195 = add <8 x i64> %194, %193
  %196 = icmp sge <8 x i64> %193, zeroinitializer
  %197 = and <8 x i1> splat (i1 true), %196
  %198 = icmp slt <8 x i64> %193, splat (i64 3)
  %199 = and <8 x i1> %197, %198
  %200 = add <8 x i64> zeroinitializer, %172
  %201 = mul <8 x i64> %195, splat (i64 7)
  %202 = add <8 x i64> %201, %200
  %203 = and <8 x i1> %199, %169
  %204 = and <8 x i1> %119, %203
  %205 = xor <8 x i1> %203, splat (i1 true)
  %206 = and <8 x i1> %119, %205
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %204)
  %208 = bitcast <8 x i1> %204 to i8
  %209 = call i8 @llvm.cttz.i8(i8 %208, i1 false)
  %210 = zext i8 %209 to i32
  %211 = select i1 %207, i32 %210, i32 0
  %212 = extractvalue { ptr, i64 } %77, 0
  %213 = select <8 x i1> %204, <8 x i64> %202, <8 x i64> zeroinitializer
  %214 = mul <8 x i64> %213, splat (i64 4)
  %215 = getelementptr i8, ptr %212, <8 x i64> %214
  %216 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %215, <8 x i1> %204, <8 x float> zeroinitializer)
  %217 = load <8 x float>, ptr %.slot110, align 32
  %218 = select <8 x i1> %204, <8 x float> %216, <8 x float> %217
  store <8 x float> %218, ptr %.slot110, align 32
  %219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  %220 = bitcast <8 x i1> %206 to i8
  %221 = call i8 @llvm.cttz.i8(i8 %220, i1 false)
  %222 = zext i8 %221 to i32
  %223 = select i1 %219, i32 %222, i32 0
  %224 = load <8 x float>, ptr %.slot110, align 32
  %225 = select <8 x i1> %206, <8 x float> zeroinitializer, <8 x float> %224
  store <8 x float> %225, ptr %.slot110, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.2
  %.spill.load333 = load <8 x i1>, ptr %.spill109, align 1
  %226 = and <8 x i1> %119, %.spill.load333
  %227 = xor <8 x i1> %.spill.load333, splat (i1 true)
  %228 = and <8 x i1> %119, %227
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %226)
  %230 = bitcast <8 x i1> %226 to i8
  %231 = call i8 @llvm.cttz.i8(i8 %230, i1 false)
  %232 = zext i8 %231 to i32
  %233 = select i1 %229, i32 %232, i32 0
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state334 = load <8 x i64>, ptr %.slot, align 64
  %236 = mul <8 x i64> %.state334, splat (i64 32)
  %237 = add <8 x i64> %235, %236
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %234, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %.state335 = load <8 x float>, ptr %.slot110, align 32
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %239, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = getelementptr i8, <8 x ptr> %240, <8 x i64> %241
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state335, <8 x ptr> align 1 %242, <8 x i1> %226)
  %243 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %244 = bitcast <8 x i1> %228 to i8
  %245 = call i8 @llvm.cttz.i8(i8 %244, i1 false)
  %246 = zext i8 %245 to i32
  %247 = select i1 %243, i32 %246, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.4
  %.state336 = load <8 x i64>, ptr %.slot, align 64
  %248 = add <8 x i64> %.state336, splat (i64 1)
  %249 = load <8 x i64>, ptr %.slot, align 64
  %250 = select <8 x i1> %119, <8 x i64> %248, <8 x i64> %249
  store <8 x i64> %250, ptr %.slot, align 64
  br label %direct.schedule.1

direct.schedule.7:                                ; preds = %direct.false
  %251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %252 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %251, 0
  %254 = select <8 x i1> %119, <8 x ptr> %252, <8 x ptr> %253
  %255 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %251, 1
  %257 = select <8 x i1> %119, <8 x i64> %255, <8 x i64> %256
  %258 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %254, 0
  %259 = insertvalue { <8 x ptr>, <8 x i64> } %258, <8 x i64> %257, 1
  store { <8 x ptr>, <8 x i64> } %259, ptr %tile_snapshot.spill111, align 64
  %260 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 0
  %263 = select <8 x i1> %119, <8 x ptr> %261, <8 x ptr> %262
  %264 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %265 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %266 = select <8 x i1> %119, <8 x i64> %264, <8 x i64> %265
  %267 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %263, 0
  %268 = insertvalue { <8 x ptr>, <8 x i64> } %267, <8 x i64> %266, 1
  store { <8 x ptr>, <8 x i64> } %268, ptr %tile_snapshot.spill112, align 64
  %269 = load <8 x i64>, ptr %.slot113, align 64
  %270 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %269
  store <8 x i64> %270, ptr %.slot113, align 64
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.11, %direct.schedule.7
  %.state337 = load <8 x i64>, ptr %.slot113, align 64
  %271 = icmp slt <8 x i64> %.state337, splat (i64 1)
  %272 = extractelement <8 x i1> %271, i32 0
  br i1 %272, label %direct.true338, label %direct.false339

direct.schedule.9:                                ; preds = %direct.true338
  %.state340 = load <8 x i64>, ptr %.slot113, align 64
  %273 = select <8 x i1> %119, <8 x i64> %.state340, <8 x i64> zeroinitializer
  %274 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %275 = srem <8 x i64> %273, %274
  %276 = mul <8 x i64> %275, splat (i64 8)
  %.spill.load341 = load <8 x i64>, ptr %.spill, align 64
  %277 = add <8 x i64> %276, %.spill.load341
  %278 = icmp slt <8 x i64> %277, splat (i64 2)
  %279 = and <8 x i1> %119, %278
  %280 = xor <8 x i1> %278, splat (i1 true)
  %281 = and <8 x i1> %119, %280
  %282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %279)
  %283 = bitcast <8 x i1> %279 to i8
  %284 = call i8 @llvm.cttz.i8(i8 %283, i1 false)
  %285 = zext i8 %284 to i32
  %286 = select i1 %282, i32 %285, i32 0
  %tile_snapshot.spill.load342 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load342, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load342, 1
  %.state343 = load <8 x i64>, ptr %.slot113, align 64
  %289 = mul <8 x i64> %.state343, splat (i64 32)
  %290 = add <8 x i64> %288, %289
  %291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %287, 0
  %292 = insertvalue { <8 x ptr>, <8 x i64> } %291, <8 x i64> %290, 1
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %292, 0
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %292, 1
  %295 = getelementptr i8, <8 x ptr> %293, <8 x i64> %294
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> splat (float 0xC6293E5940000000), <8 x ptr> align 1 %295, <8 x i1> %279)
  %296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %281)
  %297 = bitcast <8 x i1> %281 to i8
  %298 = call i8 @llvm.cttz.i8(i8 %297, i1 false)
  %299 = zext i8 %298 to i32
  %300 = select i1 %296, i32 %299, i32 0
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.9
  %.state344 = load <8 x i64>, ptr %.slot113, align 64
  %301 = add <8 x i64> %.state344, splat (i64 1)
  %302 = load <8 x i64>, ptr %.slot113, align 64
  %303 = select <8 x i1> %119, <8 x i64> %301, <8 x i64> %302
  store <8 x i64> %303, ptr %.slot113, align 64
  br label %direct.schedule.8

direct.schedule.12:                               ; preds = %direct.false339
  %304 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %304, 0
  %307 = select <8 x i1> %119, <8 x ptr> %305, <8 x ptr> %306
  %308 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %304, 1
  %310 = select <8 x i1> %119, <8 x i64> %308, <8 x i64> %309
  %311 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %307, 0
  %312 = insertvalue { <8 x ptr>, <8 x i64> } %311, <8 x i64> %310, 1
  store { <8 x ptr>, <8 x i64> } %312, ptr %tile_snapshot.spill114, align 64
  %313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %314 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %313, 0
  %316 = select <8 x i1> %119, <8 x ptr> %314, <8 x ptr> %315
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %313, 1
  %319 = select <8 x i1> %119, <8 x i64> %317, <8 x i64> %318
  %320 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %316, 0
  %321 = insertvalue { <8 x ptr>, <8 x i64> } %320, <8 x i64> %319, 1
  store { <8 x ptr>, <8 x i64> } %321, ptr %tile_snapshot.spill115, align 64
  %322 = load <8 x i64>, ptr %.slot116, align 64
  %323 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %322
  store <8 x i64> %323, ptr %.slot116, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.16, %direct.schedule.12
  %.state345 = load <8 x i64>, ptr %.slot116, align 64
  %324 = icmp slt <8 x i64> %.state345, splat (i64 1)
  %325 = extractelement <8 x i1> %324, i32 0
  br i1 %325, label %direct.true346, label %direct.false347

direct.schedule.14:                               ; preds = %direct.true346
  %.state348 = load <8 x i64>, ptr %.slot116, align 64
  %326 = select <8 x i1> %119, <8 x i64> %.state348, <8 x i64> zeroinitializer
  %327 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %328 = srem <8 x i64> %326, %327
  %329 = mul <8 x i64> %328, splat (i64 8)
  %.spill.load349 = load <8 x i64>, ptr %.spill, align 64
  %330 = add <8 x i64> %329, %.spill.load349
  %331 = icmp slt <8 x i64> %330, splat (i64 2)
  %332 = and <8 x i1> %119, %331
  %333 = xor <8 x i1> %331, splat (i1 true)
  %334 = and <8 x i1> %119, %333
  %335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %332)
  %336 = bitcast <8 x i1> %332 to i8
  %337 = call i8 @llvm.cttz.i8(i8 %336, i1 false)
  %338 = zext i8 %337 to i32
  %339 = select i1 %335, i32 %338, i32 0
  %tile_snapshot.spill.load350 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load350, 1
  %.state351 = load <8 x i64>, ptr %.slot116, align 64
  %342 = mul <8 x i64> %.state351, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %345, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = getelementptr i8, <8 x ptr> %346, <8 x i64> %347
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %348, <8 x i1> %332)
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %334)
  %350 = bitcast <8 x i1> %334 to i8
  %351 = call i8 @llvm.cttz.i8(i8 %350, i1 false)
  %352 = zext i8 %351 to i32
  %353 = select i1 %349, i32 %352, i32 0
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.14
  %.state352 = load <8 x i64>, ptr %.slot116, align 64
  %354 = add <8 x i64> %.state352, splat (i64 1)
  %355 = load <8 x i64>, ptr %.slot116, align 64
  %356 = select <8 x i1> %119, <8 x i64> %354, <8 x i64> %355
  store <8 x i64> %356, ptr %.slot116, align 64
  br label %direct.schedule.13

direct.schedule.17:                               ; preds = %direct.false347
  %357 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %358 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %359 = extractvalue { <8 x ptr>, <8 x i64> } %357, 0
  %360 = select <8 x i1> %119, <8 x ptr> %358, <8 x ptr> %359
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %362 = extractvalue { <8 x ptr>, <8 x i64> } %357, 1
  %363 = select <8 x i1> %119, <8 x i64> %361, <8 x i64> %362
  %364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %360, 0
  %365 = insertvalue { <8 x ptr>, <8 x i64> } %364, <8 x i64> %363, 1
  store { <8 x ptr>, <8 x i64> } %365, ptr %tile_snapshot.spill117, align 64
  %366 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill118, align 64
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %368 = extractvalue { <8 x ptr>, <8 x i64> } %366, 0
  %369 = select <8 x i1> %119, <8 x ptr> %367, <8 x ptr> %368
  %370 = extractvalue { <8 x ptr>, <8 x i64> } %13, 1
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %366, 1
  %372 = select <8 x i1> %119, <8 x i64> %370, <8 x i64> %371
  %373 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %369, 0
  %374 = insertvalue { <8 x ptr>, <8 x i64> } %373, <8 x i64> %372, 1
  store { <8 x ptr>, <8 x i64> } %374, ptr %tile_snapshot.spill118, align 64
  %375 = load <8 x i64>, ptr %.slot119, align 64
  %376 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %375
  store <8 x i64> %376, ptr %.slot119, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.21, %direct.schedule.17
  %.state353 = load <8 x i64>, ptr %.slot119, align 64
  %377 = icmp slt <8 x i64> %.state353, splat (i64 2)
  %378 = extractelement <8 x i1> %377, i32 0
  br i1 %378, label %direct.true354, label %direct.false355

direct.schedule.19:                               ; preds = %direct.true354
  %.state356 = load <8 x i64>, ptr %.slot119, align 64
  %379 = select <8 x i1> %119, <8 x i64> %.state356, <8 x i64> zeroinitializer
  %380 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %381 = srem <8 x i64> %379, %380
  %382 = mul <8 x i64> %381, splat (i64 8)
  %.spill.load357 = load <8 x i64>, ptr %.spill, align 64
  %383 = add <8 x i64> %382, %.spill.load357
  %384 = icmp slt <8 x i64> %383, splat (i64 3)
  %385 = and <8 x i1> %119, %384
  %386 = xor <8 x i1> %384, splat (i1 true)
  %387 = and <8 x i1> %119, %386
  %388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %385)
  %389 = bitcast <8 x i1> %385 to i8
  %390 = call i8 @llvm.cttz.i8(i8 %389, i1 false)
  %391 = zext i8 %390 to i32
  %392 = select i1 %388, i32 %391, i32 0
  %tile_snapshot.spill.load358 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load358, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load358, 1
  %.state359 = load <8 x i64>, ptr %.slot119, align 64
  %395 = mul <8 x i64> %.state359, splat (i64 32)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %398, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = getelementptr i8, <8 x ptr> %399, <8 x i64> %400
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> zeroinitializer, <8 x ptr> align 1 %401, <8 x i1> %385)
  %402 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %387)
  %403 = bitcast <8 x i1> %387 to i8
  %404 = call i8 @llvm.cttz.i8(i8 %403, i1 false)
  %405 = zext i8 %404 to i32
  %406 = select i1 %402, i32 %405, i32 0
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.19
  %.state360 = load <8 x i64>, ptr %.slot119, align 64
  %407 = add <8 x i64> %.state360, splat (i64 1)
  %408 = load <8 x i64>, ptr %.slot119, align 64
  %409 = select <8 x i1> %119, <8 x i64> %407, <8 x i64> %408
  store <8 x i64> %409, ptr %.slot119, align 64
  br label %direct.schedule.18

direct.schedule.22:                               ; preds = %direct.false355
  %410 = load <8 x i64>, ptr %.slot120, align 64
  %411 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %410
  store <8 x i64> %411, ptr %.slot120, align 64
  br label %direct.schedule.23

direct.schedule.23:                               ; preds = %direct.schedule.290, %direct.schedule.22
  %.state361 = load <8 x i64>, ptr %.slot120, align 64
  %412 = icmp slt <8 x i64> %.state361, splat (i64 2)
  %413 = extractelement <8 x i1> %412, i32 0
  br i1 %413, label %direct.true362, label %direct.false363

direct.schedule.24:                               ; preds = %direct.true362
  %.state364 = load <8 x i64>, ptr %.slot120, align 64
  %414 = select <8 x i1> %119, <8 x i64> %.state364, <8 x i64> zeroinitializer
  %415 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %416 = sdiv <8 x i64> %414, %415
  %417 = mul <8 x i64> %416, splat (i64 33)
  %418 = load <8 x i64>, ptr %.spill121, align 64
  %419 = select <8 x i1> %119, <8 x i64> %417, <8 x i64> %418
  store <8 x i64> %419, ptr %.spill121, align 64
  %420 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill122, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %15, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %420, 0
  %423 = select <8 x i1> %119, <8 x ptr> %421, <8 x ptr> %422
  %424 = extractvalue { <8 x ptr>, <8 x i64> } %15, 1
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %420, 1
  %426 = select <8 x i1> %119, <8 x i64> %424, <8 x i64> %425
  %427 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %423, 0
  %428 = insertvalue { <8 x ptr>, <8 x i64> } %427, <8 x i64> %426, 1
  store { <8 x ptr>, <8 x i64> } %428, ptr %tile_snapshot.spill122, align 64
  %429 = load <8 x i64>, ptr %.slot123, align 64
  %430 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %429
  store <8 x i64> %430, ptr %.slot123, align 64
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.30, %direct.schedule.24
  %.state365 = load <8 x i64>, ptr %.slot123, align 64
  %431 = icmp slt <8 x i64> %.state365, splat (i64 35)
  %432 = extractelement <8 x i1> %431, i32 0
  br i1 %432, label %direct.true366, label %direct.false367

direct.schedule.26:                               ; preds = %direct.true366
  %.state368 = load <8 x i64>, ptr %.slot123, align 64
  %433 = select <8 x i1> %119, <8 x i64> %.state368, <8 x i64> zeroinitializer
  %434 = select <8 x i1> %119, <8 x i64> splat (i64 7), <8 x i64> splat (i64 1)
  %435 = srem <8 x i64> %433, %434
  %.state369 = load <8 x i64>, ptr %.slot123, align 64
  %436 = select <8 x i1> %119, <8 x i64> %.state369, <8 x i64> zeroinitializer
  %437 = select <8 x i1> %119, <8 x i64> splat (i64 7), <8 x i64> splat (i64 1)
  %438 = sdiv <8 x i64> %436, %437
  %439 = select <8 x i1> %119, <8 x i64> %438, <8 x i64> zeroinitializer
  %440 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %441 = srem <8 x i64> %439, %440
  %442 = select <8 x i1> %119, <8 x i64> %438, <8 x i64> zeroinitializer
  %443 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %444 = sdiv <8 x i64> %442, %443
  %445 = mul <8 x i64> %441, splat (i64 8)
  %.spill.load370 = load <8 x i64>, ptr %.spill, align 64
  %446 = add <8 x i64> %445, %.spill.load370
  %447 = icmp slt <8 x i64> %446, splat (i64 33)
  %448 = load <8 x i1>, ptr %.spill124, align 1
  %449 = select <8 x i1> %119, <8 x i1> %447, <8 x i1> %448
  store <8 x i1> %449, ptr %.spill124, align 1
  %450 = select <8 x i1> %447, <8 x i64> %446, <8 x i64> splat (i64 32)
  %451 = select <8 x i1> %119, <8 x i64> %444, <8 x i64> zeroinitializer
  %452 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %453 = srem <8 x i64> %451, %452
  %454 = select <8 x i1> %119, <8 x i64> %444, <8 x i64> zeroinitializer
  %455 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %456 = sdiv <8 x i64> %454, %455
  %457 = select <8 x i1> %119, <8 x i64> %456, <8 x i64> zeroinitializer
  %458 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %459 = srem <8 x i64> %457, %458
  %460 = add <8 x i64> zeroinitializer, %459
  %461 = add <8 x i64> zeroinitializer, %460
  %.spill.load371 = load <8 x i64>, ptr %.spill108, align 64
  %462 = add <8 x i64> %.spill.load371, %453
  %463 = mul <8 x i64> %461, splat (i64 1)
  %464 = add <8 x i64> %463, %462
  %.spill.load372 = load <8 x i64>, ptr %.spill121, align 64
  %465 = add <8 x i64> %.spill.load372, %450
  %466 = mul <8 x i64> %464, splat (i64 35)
  %467 = add <8 x i64> %466, %465
  %468 = icmp sge <8 x i64> %465, zeroinitializer
  %469 = and <8 x i1> splat (i1 true), %468
  %470 = icmp slt <8 x i64> %465, splat (i64 35)
  %471 = and <8 x i1> %469, %470
  %472 = add <8 x i64> zeroinitializer, %435
  %473 = mul <8 x i64> %467, splat (i64 7)
  %474 = add <8 x i64> %473, %472
  %475 = and <8 x i1> %471, %447
  %476 = and <8 x i1> %119, %475
  %477 = xor <8 x i1> %475, splat (i1 true)
  %478 = and <8 x i1> %119, %477
  %479 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %476)
  %480 = bitcast <8 x i1> %476 to i8
  %481 = call i8 @llvm.cttz.i8(i8 %480, i1 false)
  %482 = zext i8 %481 to i32
  %483 = select i1 %479, i32 %482, i32 0
  %484 = extractvalue { ptr, i64 } %83, 0
  %485 = select <8 x i1> %476, <8 x i64> %474, <8 x i64> zeroinitializer
  %486 = mul <8 x i64> %485, splat (i64 4)
  %487 = getelementptr i8, ptr %484, <8 x i64> %486
  %488 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %487, <8 x i1> %476, <8 x float> zeroinitializer)
  %489 = load <8 x float>, ptr %.slot125, align 32
  %490 = select <8 x i1> %476, <8 x float> %488, <8 x float> %489
  store <8 x float> %490, ptr %.slot125, align 32
  %491 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %478)
  %492 = bitcast <8 x i1> %478 to i8
  %493 = call i8 @llvm.cttz.i8(i8 %492, i1 false)
  %494 = zext i8 %493 to i32
  %495 = select i1 %491, i32 %494, i32 0
  %496 = load <8 x float>, ptr %.slot125, align 32
  %497 = select <8 x i1> %478, <8 x float> zeroinitializer, <8 x float> %496
  store <8 x float> %497, ptr %.slot125, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.26
  %.spill.load373 = load <8 x i1>, ptr %.spill124, align 1
  %498 = and <8 x i1> %119, %.spill.load373
  %499 = xor <8 x i1> %.spill.load373, splat (i1 true)
  %500 = and <8 x i1> %119, %499
  %501 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %498)
  %502 = bitcast <8 x i1> %498 to i8
  %503 = call i8 @llvm.cttz.i8(i8 %502, i1 false)
  %504 = zext i8 %503 to i32
  %505 = select i1 %501, i32 %504, i32 0
  %tile_snapshot.spill.load374 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill122, align 64
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load374, 0
  %507 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load374, 1
  %.state375 = load <8 x i64>, ptr %.slot123, align 64
  %508 = mul <8 x i64> %.state375, splat (i64 32)
  %509 = add <8 x i64> %507, %508
  %510 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %506, 0
  %511 = insertvalue { <8 x ptr>, <8 x i64> } %510, <8 x i64> %509, 1
  %.state376 = load <8 x float>, ptr %.slot125, align 32
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %511, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %511, 1
  %514 = getelementptr i8, <8 x ptr> %512, <8 x i64> %513
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state376, <8 x ptr> align 1 %514, <8 x i1> %498)
  %515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %500)
  %516 = bitcast <8 x i1> %500 to i8
  %517 = call i8 @llvm.cttz.i8(i8 %516, i1 false)
  %518 = zext i8 %517 to i32
  %519 = select i1 %515, i32 %518, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  %.state377 = load <8 x i64>, ptr %.slot123, align 64
  %520 = add <8 x i64> %.state377, splat (i64 1)
  %521 = load <8 x i64>, ptr %.slot123, align 64
  %522 = select <8 x i1> %119, <8 x i64> %520, <8 x i64> %521
  store <8 x i64> %522, ptr %.slot123, align 64
  br label %direct.schedule.25

direct.schedule.31:                               ; preds = %direct.false367
  %523 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill126, align 64
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %525 = extractvalue { <8 x ptr>, <8 x i64> } %523, 0
  %526 = select <8 x i1> %119, <8 x ptr> %524, <8 x ptr> %525
  %527 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %523, 1
  %529 = select <8 x i1> %119, <8 x i64> %527, <8 x i64> %528
  %530 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %526, 0
  %531 = insertvalue { <8 x ptr>, <8 x i64> } %530, <8 x i64> %529, 1
  store { <8 x ptr>, <8 x i64> } %531, ptr %tile_snapshot.spill126, align 64
  %532 = load <8 x i64>, ptr %.slot127, align 64
  %533 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %532
  store <8 x i64> %533, ptr %.slot127, align 64
  br label %direct.schedule.32

direct.schedule.32:                               ; preds = %direct.schedule.37, %direct.schedule.31
  %.state378 = load <8 x i64>, ptr %.slot127, align 64
  %534 = icmp slt <8 x i64> %.state378, splat (i64 33)
  %535 = extractelement <8 x i1> %534, i32 0
  br i1 %535, label %direct.true379, label %direct.false380

direct.schedule.33:                               ; preds = %direct.true379
  %.state381 = load <8 x i64>, ptr %.slot127, align 64
  %536 = select <8 x i1> %119, <8 x i64> %.state381, <8 x i64> zeroinitializer
  %537 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %538 = srem <8 x i64> %536, %537
  %.state382 = load <8 x i64>, ptr %.slot127, align 64
  %539 = select <8 x i1> %119, <8 x i64> %.state382, <8 x i64> zeroinitializer
  %540 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %541 = sdiv <8 x i64> %539, %540
  %542 = mul <8 x i64> %538, splat (i64 8)
  %.spill.load383 = load <8 x i64>, ptr %.spill, align 64
  %543 = add <8 x i64> %542, %.spill.load383
  %544 = icmp slt <8 x i64> %543, splat (i64 3)
  %545 = load <8 x i1>, ptr %.spill128, align 1
  %546 = select <8 x i1> %119, <8 x i1> %544, <8 x i1> %545
  store <8 x i1> %546, ptr %.spill128, align 1
  %547 = select <8 x i1> %544, <8 x i64> %543, <8 x i64> splat (i64 2)
  %548 = select <8 x i1> %119, <8 x i64> %541, <8 x i64> zeroinitializer
  %549 = select <8 x i1> %119, <8 x i64> splat (i64 33), <8 x i64> splat (i64 1)
  %550 = srem <8 x i64> %548, %549
  %551 = select <8 x i1> %119, <8 x i64> %541, <8 x i64> zeroinitializer
  %552 = select <8 x i1> %119, <8 x i64> splat (i64 33), <8 x i64> splat (i64 1)
  %553 = sdiv <8 x i64> %551, %552
  %554 = select <8 x i1> %119, <8 x i64> %553, <8 x i64> zeroinitializer
  %555 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %556 = srem <8 x i64> %554, %555
  %557 = select <8 x i1> %119, <8 x i64> %553, <8 x i64> zeroinitializer
  %558 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %559 = sdiv <8 x i64> %557, %558
  %560 = select <8 x i1> %119, <8 x i64> %559, <8 x i64> zeroinitializer
  %561 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %562 = srem <8 x i64> %560, %561
  %563 = add <8 x i64> zeroinitializer, %562
  %564 = add <8 x i64> zeroinitializer, %563
  %.spill.load384 = load <8 x i64>, ptr %.spill108, align 64
  %565 = add <8 x i64> %.spill.load384, %556
  %566 = mul <8 x i64> %564, splat (i64 1)
  %567 = add <8 x i64> %566, %565
  %.spill.load385 = load <8 x i64>, ptr %.spill121, align 64
  %568 = add <8 x i64> %.spill.load385, %550
  %569 = mul <8 x i64> %567, splat (i64 35)
  %570 = add <8 x i64> %569, %568
  %571 = icmp sge <8 x i64> %568, zeroinitializer
  %572 = and <8 x i1> splat (i1 true), %571
  %573 = icmp slt <8 x i64> %568, splat (i64 35)
  %574 = and <8 x i1> %572, %573
  %575 = add <8 x i64> zeroinitializer, %547
  %576 = mul <8 x i64> %570, splat (i64 3)
  %577 = add <8 x i64> %576, %575
  %578 = and <8 x i1> %574, %544
  %579 = and <8 x i1> %119, %578
  %580 = xor <8 x i1> %578, splat (i1 true)
  %581 = and <8 x i1> %119, %580
  %582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %579)
  %583 = bitcast <8 x i1> %579 to i8
  %584 = call i8 @llvm.cttz.i8(i8 %583, i1 false)
  %585 = zext i8 %584 to i32
  %586 = select i1 %582, i32 %585, i32 0
  %587 = extractvalue { ptr, i64 } %89, 0
  %588 = select <8 x i1> %579, <8 x i64> %577, <8 x i64> zeroinitializer
  %589 = mul <8 x i64> %588, splat (i64 4)
  %590 = getelementptr i8, ptr %587, <8 x i64> %589
  %591 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %590, <8 x i1> %579, <8 x float> zeroinitializer)
  %592 = load <8 x float>, ptr %.slot129, align 32
  %593 = select <8 x i1> %579, <8 x float> %591, <8 x float> %592
  store <8 x float> %593, ptr %.slot129, align 32
  %594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %581)
  %595 = bitcast <8 x i1> %581 to i8
  %596 = call i8 @llvm.cttz.i8(i8 %595, i1 false)
  %597 = zext i8 %596 to i32
  %598 = select i1 %594, i32 %597, i32 0
  %599 = load <8 x float>, ptr %.slot129, align 32
  %600 = select <8 x i1> %581, <8 x float> zeroinitializer, <8 x float> %599
  store <8 x float> %600, ptr %.slot129, align 32
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.33
  %.spill.load386 = load <8 x i1>, ptr %.spill128, align 1
  %601 = and <8 x i1> %119, %.spill.load386
  %602 = xor <8 x i1> %.spill.load386, splat (i1 true)
  %603 = and <8 x i1> %119, %602
  %604 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %601)
  %605 = bitcast <8 x i1> %601 to i8
  %606 = call i8 @llvm.cttz.i8(i8 %605, i1 false)
  %607 = zext i8 %606 to i32
  %608 = select i1 %604, i32 %607, i32 0
  %tile_snapshot.spill.load387 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill126, align 64
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load387, 0
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load387, 1
  %.state388 = load <8 x i64>, ptr %.slot127, align 64
  %611 = mul <8 x i64> %.state388, splat (i64 32)
  %612 = add <8 x i64> %610, %611
  %613 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %609, 0
  %614 = insertvalue { <8 x ptr>, <8 x i64> } %613, <8 x i64> %612, 1
  %.state389 = load <8 x float>, ptr %.slot129, align 32
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %614, 0
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %614, 1
  %617 = getelementptr i8, <8 x ptr> %615, <8 x i64> %616
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state389, <8 x ptr> align 1 %617, <8 x i1> %601)
  %618 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %603)
  %619 = bitcast <8 x i1> %603 to i8
  %620 = call i8 @llvm.cttz.i8(i8 %619, i1 false)
  %621 = zext i8 %620 to i32
  %622 = select i1 %618, i32 %621, i32 0
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.35
  %.state390 = load <8 x i64>, ptr %.slot127, align 64
  %623 = add <8 x i64> %.state390, splat (i64 1)
  %624 = load <8 x i64>, ptr %.slot127, align 64
  %625 = select <8 x i1> %119, <8 x i64> %623, <8 x i64> %624
  store <8 x i64> %625, ptr %.slot127, align 64
  br label %direct.schedule.32

direct.schedule.38:                               ; preds = %direct.false380
  %626 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill130, align 64
  %627 = extractvalue { <8 x ptr>, <8 x i64> } %19, 0
  %628 = extractvalue { <8 x ptr>, <8 x i64> } %626, 0
  %629 = select <8 x i1> %119, <8 x ptr> %627, <8 x ptr> %628
  %630 = extractvalue { <8 x ptr>, <8 x i64> } %19, 1
  %631 = extractvalue { <8 x ptr>, <8 x i64> } %626, 1
  %632 = select <8 x i1> %119, <8 x i64> %630, <8 x i64> %631
  %633 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %629, 0
  %634 = insertvalue { <8 x ptr>, <8 x i64> } %633, <8 x i64> %632, 1
  store { <8 x ptr>, <8 x i64> } %634, ptr %tile_snapshot.spill130, align 64
  %635 = load <8 x i64>, ptr %.slot131, align 64
  %636 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %635
  store <8 x i64> %636, ptr %.slot131, align 64
  br label %direct.schedule.39

direct.schedule.39:                               ; preds = %direct.schedule.49, %direct.schedule.38
  %.state391 = load <8 x i64>, ptr %.slot131, align 64
  %637 = icmp slt <8 x i64> %.state391, splat (i64 10)
  %638 = extractelement <8 x i1> %637, i32 0
  br i1 %638, label %direct.true392, label %direct.false393

direct.schedule.40:                               ; preds = %direct.true392
  %.state394 = load <8 x i64>, ptr %.slot131, align 64
  %639 = select <8 x i1> %119, <8 x i64> %.state394, <8 x i64> zeroinitializer
  %640 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %641 = srem <8 x i64> %639, %640
  %642 = load <8 x i64>, ptr %.spill132, align 64
  %643 = select <8 x i1> %119, <8 x i64> %641, <8 x i64> %642
  store <8 x i64> %643, ptr %.spill132, align 64
  %.state395 = load <8 x i64>, ptr %.slot131, align 64
  %644 = select <8 x i1> %119, <8 x i64> %.state395, <8 x i64> zeroinitializer
  %645 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %646 = sdiv <8 x i64> %644, %645
  %647 = mul <8 x i64> %641, splat (i64 8)
  %.spill.load396 = load <8 x i64>, ptr %.spill, align 64
  %648 = add <8 x i64> %647, %.spill.load396
  %649 = icmp slt <8 x i64> %648, splat (i64 33)
  %650 = load <8 x i1>, ptr %.spill133, align 1
  %651 = select <8 x i1> %119, <8 x i1> %649, <8 x i1> %650
  store <8 x i1> %651, ptr %.spill133, align 1
  %652 = select <8 x i1> %119, <8 x i64> %646, <8 x i64> zeroinitializer
  %653 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %654 = srem <8 x i64> %652, %653
  %655 = load <8 x i64>, ptr %.spill134, align 64
  %656 = select <8 x i1> %119, <8 x i64> %654, <8 x i64> %655
  store <8 x i64> %656, ptr %.spill134, align 64
  store i64 0, ptr %.spill135, align 4
  %657 = load <8 x i64>, ptr %.slot136, align 64
  %658 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %657
  store <8 x i64> %658, ptr %.slot136, align 64
  %659 = load <8 x float>, ptr %.slot137, align 32
  %660 = select <8 x i1> %119, <8 x float> zeroinitializer, <8 x float> %659
  store <8 x float> %660, ptr %.slot137, align 32
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.46, %direct.schedule.40
  %.state397 = load <8 x i64>, ptr %.slot136, align 64
  %661 = icmp slt <8 x i64> %.state397, splat (i64 7)
  %662 = extractelement <8 x i1> %661, i32 0
  br i1 %662, label %direct.true398, label %direct.false399

direct.schedule.42:                               ; preds = %direct.true398
  %.spill.load400 = load i64, ptr %.spill135, align 4
  %663 = add i64 %.spill.load400, 0
  %664 = mul i64 %663, 1
  %665 = add i64 %664, 0
  store i64 %665, ptr %.spill138, align 4
  %666 = mul i64 %665, 2
  %.splatinsert401 = insertelement <8 x i64> poison, i64 %666, i64 0
  %.splat402 = shufflevector <8 x i64> %.splatinsert401, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load403 = load <8 x i64>, ptr %.spill134, align 64
  %667 = add <8 x i64> %.splat402, %.spill.load403
  %.state404 = load <8 x i64>, ptr %.slot136, align 64
  %668 = select <8 x i1> %119, <8 x i64> %.state404, <8 x i64> zeroinitializer
  %669 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %670 = sdiv <8 x i64> %668, %669
  %671 = mul <8 x i64> %667, splat (i64 1)
  %672 = add <8 x i64> %671, %670
  %.state405 = load <8 x i64>, ptr %.slot136, align 64
  %673 = select <8 x i1> %119, <8 x i64> %.state405, <8 x i64> zeroinitializer
  %674 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %675 = srem <8 x i64> %673, %674
  %676 = load <8 x i64>, ptr %.spill139, align 64
  %677 = select <8 x i1> %119, <8 x i64> %675, <8 x i64> %676
  store <8 x i64> %677, ptr %.spill139, align 64
  %.spill.load406 = load <8 x i64>, ptr %.spill, align 64
  %678 = icmp eq <8 x i64> %.spill.load406, %675
  %679 = and <8 x i1> %119, %678
  %680 = xor <8 x i1> %678, splat (i1 true)
  %681 = and <8 x i1> %119, %680
  %682 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %679)
  %683 = bitcast <8 x i1> %679 to i8
  %684 = call i8 @llvm.cttz.i8(i8 %683, i1 false)
  %685 = zext i8 %684 to i32
  %686 = select i1 %682, i32 %685, i32 0
  %tile_snapshot.spill.load407 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %688 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %689 = mul <8 x i64> %672, splat (i64 32)
  %690 = add <8 x i64> %688, %689
  %691 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %687, 0
  %692 = insertvalue { <8 x ptr>, <8 x i64> } %691, <8 x i64> %690, 1
  %693 = extractvalue { <8 x ptr>, <8 x i64> } %692, 0
  %694 = extractvalue { <8 x ptr>, <8 x i64> } %692, 1
  %695 = getelementptr i8, <8 x ptr> %693, <8 x i64> %694
  %696 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %695, <8 x i1> %679, <8 x float> zeroinitializer)
  %697 = load <8 x float>, ptr %.slot140, align 32
  %698 = select <8 x i1> %679, <8 x float> %696, <8 x float> %697
  store <8 x float> %698, ptr %.slot140, align 32
  %699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %681)
  %700 = bitcast <8 x i1> %681 to i8
  %701 = call i8 @llvm.cttz.i8(i8 %700, i1 false)
  %702 = zext i8 %701 to i32
  %703 = select i1 %699, i32 %702, i32 0
  %704 = load <8 x float>, ptr %.slot140, align 32
  %705 = select <8 x i1> %681, <8 x float> zeroinitializer, <8 x float> %704
  store <8 x float> %705, ptr %.slot140, align 32
  br label %direct.schedule.44

direct.schedule.44:                               ; preds = %direct.schedule.42
  %.spill.load408 = load <8 x i64>, ptr %.spill139, align 64
  %706 = trunc <8 x i64> %.spill.load408 to <8 x i32>
  %.state409 = load <8 x float>, ptr %.slot140, align 32
  %707 = extractelement <8 x i32> %706, i64 0
  %708 = icmp ult i32 %707, 8
  %709 = select i1 %708, i32 %707, i32 0
  %710 = extractelement <8 x i1> %119, i32 %709
  %711 = extractelement <8 x i1> %119, i64 0
  %712 = and i1 %708, %710
  %713 = and i1 %711, %712
  %714 = extractelement <8 x float> %.state409, i32 %709
  %715 = select i1 %713, float %714, float 0.000000e+00
  %716 = insertelement <8 x float> poison, float %715, i64 0
  %717 = xor i1 %713, true
  %718 = and i1 %711, %717
  %719 = insertelement <8 x i1> poison, i1 %718, i64 0
  %720 = extractelement <8 x i32> %706, i64 1
  %721 = icmp ult i32 %720, 8
  %722 = select i1 %721, i32 %720, i32 0
  %723 = extractelement <8 x i1> %119, i32 %722
  %724 = extractelement <8 x i1> %119, i64 1
  %725 = and i1 %721, %723
  %726 = and i1 %724, %725
  %727 = extractelement <8 x float> %.state409, i32 %722
  %728 = select i1 %726, float %727, float 0.000000e+00
  %729 = insertelement <8 x float> %716, float %728, i64 1
  %730 = xor i1 %726, true
  %731 = and i1 %724, %730
  %732 = insertelement <8 x i1> %719, i1 %731, i64 1
  %733 = extractelement <8 x i32> %706, i64 2
  %734 = icmp ult i32 %733, 8
  %735 = select i1 %734, i32 %733, i32 0
  %736 = extractelement <8 x i1> %119, i32 %735
  %737 = extractelement <8 x i1> %119, i64 2
  %738 = and i1 %734, %736
  %739 = and i1 %737, %738
  %740 = extractelement <8 x float> %.state409, i32 %735
  %741 = select i1 %739, float %740, float 0.000000e+00
  %742 = insertelement <8 x float> %729, float %741, i64 2
  %743 = xor i1 %739, true
  %744 = and i1 %737, %743
  %745 = insertelement <8 x i1> %732, i1 %744, i64 2
  %746 = extractelement <8 x i32> %706, i64 3
  %747 = icmp ult i32 %746, 8
  %748 = select i1 %747, i32 %746, i32 0
  %749 = extractelement <8 x i1> %119, i32 %748
  %750 = extractelement <8 x i1> %119, i64 3
  %751 = and i1 %747, %749
  %752 = and i1 %750, %751
  %753 = extractelement <8 x float> %.state409, i32 %748
  %754 = select i1 %752, float %753, float 0.000000e+00
  %755 = insertelement <8 x float> %742, float %754, i64 3
  %756 = xor i1 %752, true
  %757 = and i1 %750, %756
  %758 = insertelement <8 x i1> %745, i1 %757, i64 3
  %759 = extractelement <8 x i32> %706, i64 4
  %760 = icmp ult i32 %759, 8
  %761 = select i1 %760, i32 %759, i32 0
  %762 = extractelement <8 x i1> %119, i32 %761
  %763 = extractelement <8 x i1> %119, i64 4
  %764 = and i1 %760, %762
  %765 = and i1 %763, %764
  %766 = extractelement <8 x float> %.state409, i32 %761
  %767 = select i1 %765, float %766, float 0.000000e+00
  %768 = insertelement <8 x float> %755, float %767, i64 4
  %769 = xor i1 %765, true
  %770 = and i1 %763, %769
  %771 = insertelement <8 x i1> %758, i1 %770, i64 4
  %772 = extractelement <8 x i32> %706, i64 5
  %773 = icmp ult i32 %772, 8
  %774 = select i1 %773, i32 %772, i32 0
  %775 = extractelement <8 x i1> %119, i32 %774
  %776 = extractelement <8 x i1> %119, i64 5
  %777 = and i1 %773, %775
  %778 = and i1 %776, %777
  %779 = extractelement <8 x float> %.state409, i32 %774
  %780 = select i1 %778, float %779, float 0.000000e+00
  %781 = insertelement <8 x float> %768, float %780, i64 5
  %782 = xor i1 %778, true
  %783 = and i1 %776, %782
  %784 = insertelement <8 x i1> %771, i1 %783, i64 5
  %785 = extractelement <8 x i32> %706, i64 6
  %786 = icmp ult i32 %785, 8
  %787 = select i1 %786, i32 %785, i32 0
  %788 = extractelement <8 x i1> %119, i32 %787
  %789 = extractelement <8 x i1> %119, i64 6
  %790 = and i1 %786, %788
  %791 = and i1 %789, %790
  %792 = extractelement <8 x float> %.state409, i32 %787
  %793 = select i1 %791, float %792, float 0.000000e+00
  %794 = insertelement <8 x float> %781, float %793, i64 6
  %795 = xor i1 %791, true
  %796 = and i1 %789, %795
  %797 = insertelement <8 x i1> %784, i1 %796, i64 6
  %798 = extractelement <8 x i32> %706, i64 7
  %799 = icmp ult i32 %798, 8
  %800 = select i1 %799, i32 %798, i32 0
  %801 = extractelement <8 x i1> %119, i32 %800
  %802 = extractelement <8 x i1> %119, i64 7
  %803 = and i1 %799, %801
  %804 = and i1 %802, %803
  %805 = extractelement <8 x float> %.state409, i32 %800
  %806 = select i1 %804, float %805, float 0.000000e+00
  %807 = insertelement <8 x float> %794, float %806, i64 7
  %808 = xor i1 %804, true
  %809 = and i1 %802, %808
  %810 = insertelement <8 x i1> %797, i1 %809, i64 7
  %811 = load <8 x float>, ptr %.spill141, align 32
  %812 = select <8 x i1> %119, <8 x float> %807, <8 x float> %811
  store <8 x float> %812, ptr %.spill141, align 32
  %.spill.load410 = load i64, ptr %.spill138, align 4
  %813 = mul i64 %.spill.load410, 5
  %.splatinsert411 = insertelement <8 x i64> poison, i64 %813, i64 0
  %.splat412 = shufflevector <8 x i64> %.splatinsert411, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load413 = load <8 x i64>, ptr %.spill132, align 64
  %814 = add <8 x i64> %.splat412, %.spill.load413
  %815 = mul <8 x i64> %814, splat (i64 7)
  %.state414 = load <8 x i64>, ptr %.slot136, align 64
  %816 = add <8 x i64> %815, %.state414
  %.spill.load415 = load <8 x i1>, ptr %.spill133, align 1
  %817 = and <8 x i1> %119, %.spill.load415
  %818 = xor <8 x i1> %.spill.load415, splat (i1 true)
  %819 = and <8 x i1> %119, %818
  %820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %817)
  %821 = bitcast <8 x i1> %817 to i8
  %822 = call i8 @llvm.cttz.i8(i8 %821, i1 false)
  %823 = zext i8 %822 to i32
  %824 = select i1 %820, i32 %823, i32 0
  %tile_snapshot.spill.load416 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill122, align 64
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load416, 0
  %826 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load416, 1
  %827 = mul <8 x i64> %816, splat (i64 32)
  %828 = add <8 x i64> %826, %827
  %829 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %825, 0
  %830 = insertvalue { <8 x ptr>, <8 x i64> } %829, <8 x i64> %828, 1
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %830, 0
  %832 = extractvalue { <8 x ptr>, <8 x i64> } %830, 1
  %833 = getelementptr i8, <8 x ptr> %831, <8 x i64> %832
  %834 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %833, <8 x i1> %817, <8 x float> zeroinitializer)
  %835 = load <8 x float>, ptr %.slot142, align 32
  %836 = select <8 x i1> %817, <8 x float> %834, <8 x float> %835
  store <8 x float> %836, ptr %.slot142, align 32
  %837 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %819)
  %838 = bitcast <8 x i1> %819 to i8
  %839 = call i8 @llvm.cttz.i8(i8 %838, i1 false)
  %840 = zext i8 %839 to i32
  %841 = select i1 %837, i32 %840, i32 0
  %842 = load <8 x float>, ptr %.slot142, align 32
  %843 = select <8 x i1> %819, <8 x float> zeroinitializer, <8 x float> %842
  store <8 x float> %843, ptr %.slot142, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.44
  %.spill.load417 = load <8 x float>, ptr %.spill141, align 32
  %.state418 = load <8 x float>, ptr %.slot142, align 32
  %844 = fmul <8 x float> %.spill.load417, %.state418
  %.state419 = load <8 x float>, ptr %.slot137, align 32
  %845 = fadd <8 x float> %.state419, %844
  %.state420 = load <8 x i64>, ptr %.slot136, align 64
  %846 = add <8 x i64> %.state420, splat (i64 1)
  %847 = load <8 x i64>, ptr %.slot136, align 64
  %848 = select <8 x i1> %119, <8 x i64> %846, <8 x i64> %847
  store <8 x i64> %848, ptr %.slot136, align 64
  %849 = load <8 x float>, ptr %.slot137, align 32
  %850 = select <8 x i1> %119, <8 x float> %845, <8 x float> %849
  store <8 x float> %850, ptr %.slot137, align 32
  br label %direct.schedule.41

direct.schedule.47:                               ; preds = %direct.false399
  %.spill.load421 = load <8 x i1>, ptr %.spill133, align 1
  %851 = and <8 x i1> %119, %.spill.load421
  %852 = xor <8 x i1> %.spill.load421, splat (i1 true)
  %853 = and <8 x i1> %119, %852
  %854 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %851)
  %855 = bitcast <8 x i1> %851 to i8
  %856 = call i8 @llvm.cttz.i8(i8 %855, i1 false)
  %857 = zext i8 %856 to i32
  %858 = select i1 %854, i32 %857, i32 0
  %tile_snapshot.spill.load422 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill130, align 64
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load422, 0
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load422, 1
  %.state423 = load <8 x i64>, ptr %.slot131, align 64
  %861 = mul <8 x i64> %.state423, splat (i64 32)
  %862 = add <8 x i64> %860, %861
  %863 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %859, 0
  %864 = insertvalue { <8 x ptr>, <8 x i64> } %863, <8 x i64> %862, 1
  %.state424 = load <8 x float>, ptr %.slot137, align 32
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %864, 0
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %864, 1
  %867 = getelementptr i8, <8 x ptr> %865, <8 x i64> %866
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state424, <8 x ptr> align 1 %867, <8 x i1> %851)
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %853)
  %869 = bitcast <8 x i1> %853 to i8
  %870 = call i8 @llvm.cttz.i8(i8 %869, i1 false)
  %871 = zext i8 %870 to i32
  %872 = select i1 %868, i32 %871, i32 0
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.47
  %.state425 = load <8 x i64>, ptr %.slot131, align 64
  %873 = add <8 x i64> %.state425, splat (i64 1)
  %874 = load <8 x i64>, ptr %.slot131, align 64
  %875 = select <8 x i1> %119, <8 x i64> %873, <8 x i64> %874
  store <8 x i64> %875, ptr %.slot131, align 64
  br label %direct.schedule.39

direct.schedule.50:                               ; preds = %direct.false393
  %876 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %877 = extractvalue { <8 x ptr>, <8 x i64> } %21, 0
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %876, 0
  %879 = select <8 x i1> %119, <8 x ptr> %877, <8 x ptr> %878
  %880 = extractvalue { <8 x ptr>, <8 x i64> } %21, 1
  %881 = extractvalue { <8 x ptr>, <8 x i64> } %876, 1
  %882 = select <8 x i1> %119, <8 x i64> %880, <8 x i64> %881
  %883 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %879, 0
  %884 = insertvalue { <8 x ptr>, <8 x i64> } %883, <8 x i64> %882, 1
  store { <8 x ptr>, <8 x i64> } %884, ptr %tile_snapshot.spill143, align 64
  %885 = load <8 x i64>, ptr %.slot144, align 64
  %886 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %885
  store <8 x i64> %886, ptr %.slot144, align 64
  br label %direct.schedule.51

direct.schedule.51:                               ; preds = %direct.schedule.56, %direct.schedule.50
  %.state426 = load <8 x i64>, ptr %.slot144, align 64
  %887 = icmp slt <8 x i64> %.state426, splat (i64 10)
  %888 = extractelement <8 x i1> %887, i32 0
  br i1 %888, label %direct.true427, label %direct.false428

direct.schedule.52:                               ; preds = %direct.true427
  %.state429 = load <8 x i64>, ptr %.slot144, align 64
  %889 = select <8 x i1> %119, <8 x i64> %.state429, <8 x i64> zeroinitializer
  %890 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %891 = srem <8 x i64> %889, %890
  %.state430 = load <8 x i64>, ptr %.slot144, align 64
  %892 = select <8 x i1> %119, <8 x i64> %.state430, <8 x i64> zeroinitializer
  %893 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %894 = sdiv <8 x i64> %892, %893
  %895 = mul <8 x i64> %891, splat (i64 8)
  %.spill.load431 = load <8 x i64>, ptr %.spill, align 64
  %896 = add <8 x i64> %895, %.spill.load431
  %897 = icmp slt <8 x i64> %896, splat (i64 33)
  %898 = load <8 x i1>, ptr %.spill145, align 1
  %899 = select <8 x i1> %119, <8 x i1> %897, <8 x i1> %898
  store <8 x i1> %899, ptr %.spill145, align 1
  %900 = select <8 x i1> %119, <8 x i64> %894, <8 x i64> zeroinitializer
  %901 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %902 = srem <8 x i64> %900, %901
  %903 = add <8 x i64> zeroinitializer, %902
  %904 = mul <8 x i64> %903, splat (i64 5)
  %905 = add <8 x i64> %904, %891
  %906 = and <8 x i1> %119, %897
  %907 = xor <8 x i1> %897, splat (i1 true)
  %908 = and <8 x i1> %119, %907
  %909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %906)
  %910 = bitcast <8 x i1> %906 to i8
  %911 = call i8 @llvm.cttz.i8(i8 %910, i1 false)
  %912 = zext i8 %911 to i32
  %913 = select i1 %909, i32 %912, i32 0
  %tile_snapshot.spill.load432 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill130, align 64
  %914 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load432, 0
  %915 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load432, 1
  %916 = mul <8 x i64> %905, splat (i64 32)
  %917 = add <8 x i64> %915, %916
  %918 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %914, 0
  %919 = insertvalue { <8 x ptr>, <8 x i64> } %918, <8 x i64> %917, 1
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %919, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %919, 1
  %922 = getelementptr i8, <8 x ptr> %920, <8 x i64> %921
  %923 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %922, <8 x i1> %906, <8 x float> zeroinitializer)
  %924 = load <8 x float>, ptr %.slot146, align 32
  %925 = select <8 x i1> %906, <8 x float> %923, <8 x float> %924
  store <8 x float> %925, ptr %.slot146, align 32
  %926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %908)
  %927 = bitcast <8 x i1> %908 to i8
  %928 = call i8 @llvm.cttz.i8(i8 %927, i1 false)
  %929 = zext i8 %928 to i32
  %930 = select i1 %926, i32 %929, i32 0
  %931 = load <8 x float>, ptr %.slot146, align 32
  %932 = select <8 x i1> %908, <8 x float> zeroinitializer, <8 x float> %931
  store <8 x float> %932, ptr %.slot146, align 32
  br label %direct.schedule.54

direct.schedule.54:                               ; preds = %direct.schedule.52
  %.state433 = load <8 x float>, ptr %.slot146, align 32
  %933 = fmul <8 x float> %.state433, splat (float 0x3FD8309200000000)
  %.spill.load434 = load <8 x i1>, ptr %.spill145, align 1
  %934 = and <8 x i1> %119, %.spill.load434
  %935 = xor <8 x i1> %.spill.load434, splat (i1 true)
  %936 = and <8 x i1> %119, %935
  %937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %934)
  %938 = bitcast <8 x i1> %934 to i8
  %939 = call i8 @llvm.cttz.i8(i8 %938, i1 false)
  %940 = zext i8 %939 to i32
  %941 = select i1 %937, i32 %940, i32 0
  %tile_snapshot.spill.load435 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 0
  %943 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 1
  %.state436 = load <8 x i64>, ptr %.slot144, align 64
  %944 = mul <8 x i64> %.state436, splat (i64 32)
  %945 = add <8 x i64> %943, %944
  %946 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %942, 0
  %947 = insertvalue { <8 x ptr>, <8 x i64> } %946, <8 x i64> %945, 1
  %948 = extractvalue { <8 x ptr>, <8 x i64> } %947, 0
  %949 = extractvalue { <8 x ptr>, <8 x i64> } %947, 1
  %950 = getelementptr i8, <8 x ptr> %948, <8 x i64> %949
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %933, <8 x ptr> align 1 %950, <8 x i1> %934)
  %951 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %936)
  %952 = bitcast <8 x i1> %936 to i8
  %953 = call i8 @llvm.cttz.i8(i8 %952, i1 false)
  %954 = zext i8 %953 to i32
  %955 = select i1 %951, i32 %954, i32 0
  br label %direct.schedule.56

direct.schedule.56:                               ; preds = %direct.schedule.54
  %.state437 = load <8 x i64>, ptr %.slot144, align 64
  %956 = add <8 x i64> %.state437, splat (i64 1)
  %957 = load <8 x i64>, ptr %.slot144, align 64
  %958 = select <8 x i1> %119, <8 x i64> %956, <8 x i64> %957
  store <8 x i64> %958, ptr %.slot144, align 64
  br label %direct.schedule.51

direct.schedule.57:                               ; preds = %direct.false428
  %959 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill147, align 64
  %960 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %959, 0
  %962 = select <8 x i1> %119, <8 x ptr> %960, <8 x ptr> %961
  %963 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %964 = extractvalue { <8 x ptr>, <8 x i64> } %959, 1
  %965 = select <8 x i1> %119, <8 x i64> %963, <8 x i64> %964
  %966 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %962, 0
  %967 = insertvalue { <8 x ptr>, <8 x i64> } %966, <8 x i64> %965, 1
  store { <8 x ptr>, <8 x i64> } %967, ptr %tile_snapshot.spill147, align 64
  %968 = load <8 x i64>, ptr %.slot148, align 64
  %969 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %968
  store <8 x i64> %969, ptr %.slot148, align 64
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.61, %direct.schedule.57
  %.state438 = load <8 x i64>, ptr %.slot148, align 64
  %970 = icmp slt <8 x i64> %.state438, splat (i64 5)
  %971 = extractelement <8 x i1> %970, i32 0
  br i1 %971, label %direct.true439, label %direct.false440

direct.schedule.59:                               ; preds = %direct.true439
  %.state441 = load <8 x i64>, ptr %.slot148, align 64
  %972 = select <8 x i1> %119, <8 x i64> %.state441, <8 x i64> zeroinitializer
  %973 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %974 = srem <8 x i64> %972, %973
  %975 = mul <8 x i64> %974, splat (i64 8)
  %.spill.load442 = load <8 x i64>, ptr %.spill, align 64
  %976 = add <8 x i64> %975, %.spill.load442
  %977 = icmp slt <8 x i64> %976, splat (i64 33)
  %978 = select <8 x i1> %977, <8 x i64> %976, <8 x i64> splat (i64 32)
  %979 = and <8 x i1> %119, %977
  %980 = xor <8 x i1> %977, splat (i1 true)
  %981 = and <8 x i1> %119, %980
  %982 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %979)
  %983 = bitcast <8 x i1> %979 to i8
  %984 = call i8 @llvm.cttz.i8(i8 %983, i1 false)
  %985 = zext i8 %984 to i32
  %986 = select i1 %982, i32 %985, i32 0
  %tile_snapshot.spill.load443 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill147, align 64
  %987 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 0
  %988 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 1
  %.state444 = load <8 x i64>, ptr %.slot148, align 64
  %989 = mul <8 x i64> %.state444, splat (i64 64)
  %990 = add <8 x i64> %988, %989
  %991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %987, 0
  %992 = insertvalue { <8 x ptr>, <8 x i64> } %991, <8 x i64> %990, 1
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %992, 0
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %992, 1
  %995 = getelementptr i8, <8 x ptr> %993, <8 x i64> %994
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %978, <8 x ptr> align 1 %995, <8 x i1> %979)
  %996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %981)
  %997 = bitcast <8 x i1> %981 to i8
  %998 = call i8 @llvm.cttz.i8(i8 %997, i1 false)
  %999 = zext i8 %998 to i32
  %1000 = select i1 %996, i32 %999, i32 0
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.59
  %.state445 = load <8 x i64>, ptr %.slot148, align 64
  %1001 = add <8 x i64> %.state445, splat (i64 1)
  %1002 = load <8 x i64>, ptr %.slot148, align 64
  %1003 = select <8 x i1> %119, <8 x i64> %1001, <8 x i64> %1002
  store <8 x i64> %1003, ptr %.slot148, align 64
  br label %direct.schedule.58

direct.schedule.62:                               ; preds = %direct.false440
  %1004 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill149, align 64
  %1005 = extractvalue { <8 x ptr>, <8 x i64> } %25, 0
  %1006 = extractvalue { <8 x ptr>, <8 x i64> } %1004, 0
  %1007 = select <8 x i1> %119, <8 x ptr> %1005, <8 x ptr> %1006
  %1008 = extractvalue { <8 x ptr>, <8 x i64> } %25, 1
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %1004, 1
  %1010 = select <8 x i1> %119, <8 x i64> %1008, <8 x i64> %1009
  %1011 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1007, 0
  %1012 = insertvalue { <8 x ptr>, <8 x i64> } %1011, <8 x i64> %1010, 1
  store { <8 x ptr>, <8 x i64> } %1012, ptr %tile_snapshot.spill149, align 64
  %1013 = load <8 x i64>, ptr %.slot150, align 64
  %1014 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1013
  store <8 x i64> %1014, ptr %.slot150, align 64
  br label %direct.schedule.63

direct.schedule.63:                               ; preds = %direct.schedule.68, %direct.schedule.62
  %.state446 = load <8 x i64>, ptr %.slot150, align 64
  %1015 = icmp slt <8 x i64> %.state446, splat (i64 5)
  %1016 = extractelement <8 x i1> %1015, i32 0
  br i1 %1016, label %direct.true447, label %direct.false448

direct.schedule.64:                               ; preds = %direct.true447
  %.state449 = load <8 x i64>, ptr %.slot150, align 64
  %1017 = select <8 x i1> %119, <8 x i64> %.state449, <8 x i64> zeroinitializer
  %1018 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1019 = srem <8 x i64> %1017, %1018
  %1020 = mul <8 x i64> %1019, splat (i64 8)
  %.spill.load450 = load <8 x i64>, ptr %.spill, align 64
  %1021 = add <8 x i64> %1020, %.spill.load450
  %1022 = icmp slt <8 x i64> %1021, splat (i64 33)
  %1023 = load <8 x i1>, ptr %.spill151, align 1
  %1024 = select <8 x i1> %119, <8 x i1> %1022, <8 x i1> %1023
  store <8 x i1> %1024, ptr %.spill151, align 1
  %1025 = add <8 x i64> zeroinitializer, %1019
  %1026 = and <8 x i1> %119, %1022
  %1027 = xor <8 x i1> %1022, splat (i1 true)
  %1028 = and <8 x i1> %119, %1027
  %1029 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1026)
  %1030 = bitcast <8 x i1> %1026 to i8
  %1031 = call i8 @llvm.cttz.i8(i8 %1030, i1 false)
  %1032 = zext i8 %1031 to i32
  %1033 = select i1 %1029, i32 %1032, i32 0
  %tile_snapshot.spill.load451 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill147, align 64
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 0
  %1035 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load451, 1
  %1036 = mul <8 x i64> %1025, splat (i64 64)
  %1037 = add <8 x i64> %1035, %1036
  %1038 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1034, 0
  %1039 = insertvalue { <8 x ptr>, <8 x i64> } %1038, <8 x i64> %1037, 1
  %1040 = extractvalue { <8 x ptr>, <8 x i64> } %1039, 0
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %1039, 1
  %1042 = getelementptr i8, <8 x ptr> %1040, <8 x i64> %1041
  %1043 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1042, <8 x i1> %1026, <8 x i64> zeroinitializer)
  %1044 = load <8 x i64>, ptr %.slot152, align 64
  %1045 = select <8 x i1> %1026, <8 x i64> %1043, <8 x i64> %1044
  store <8 x i64> %1045, ptr %.slot152, align 64
  %1046 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1028)
  %1047 = bitcast <8 x i1> %1028 to i8
  %1048 = call i8 @llvm.cttz.i8(i8 %1047, i1 false)
  %1049 = zext i8 %1048 to i32
  %1050 = select i1 %1046, i32 %1049, i32 0
  %1051 = load <8 x i64>, ptr %.slot152, align 64
  %1052 = select <8 x i1> %1028, <8 x i64> zeroinitializer, <8 x i64> %1051
  store <8 x i64> %1052, ptr %.slot152, align 64
  br label %direct.schedule.66

direct.schedule.66:                               ; preds = %direct.schedule.64
  %.state452 = load <8 x i64>, ptr %.slot152, align 64
  %.spill.load453 = load <8 x i64>, ptr %.spill121, align 64
  %1053 = add <8 x i64> %.state452, %.spill.load453
  %.spill.load454 = load <8 x i1>, ptr %.spill151, align 1
  %1054 = and <8 x i1> %119, %.spill.load454
  %1055 = xor <8 x i1> %.spill.load454, splat (i1 true)
  %1056 = and <8 x i1> %119, %1055
  %1057 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1054)
  %1058 = bitcast <8 x i1> %1054 to i8
  %1059 = call i8 @llvm.cttz.i8(i8 %1058, i1 false)
  %1060 = zext i8 %1059 to i32
  %1061 = select i1 %1057, i32 %1060, i32 0
  %tile_snapshot.spill.load455 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill149, align 64
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 0
  %1063 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load455, 1
  %.state456 = load <8 x i64>, ptr %.slot150, align 64
  %1064 = mul <8 x i64> %.state456, splat (i64 64)
  %1065 = add <8 x i64> %1063, %1064
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1062, 0
  %1067 = insertvalue { <8 x ptr>, <8 x i64> } %1066, <8 x i64> %1065, 1
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1067, 0
  %1069 = extractvalue { <8 x ptr>, <8 x i64> } %1067, 1
  %1070 = getelementptr i8, <8 x ptr> %1068, <8 x i64> %1069
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %1053, <8 x ptr> align 1 %1070, <8 x i1> %1054)
  %1071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1056)
  %1072 = bitcast <8 x i1> %1056 to i8
  %1073 = call i8 @llvm.cttz.i8(i8 %1072, i1 false)
  %1074 = zext i8 %1073 to i32
  %1075 = select i1 %1071, i32 %1074, i32 0
  br label %direct.schedule.68

direct.schedule.68:                               ; preds = %direct.schedule.66
  %.state457 = load <8 x i64>, ptr %.slot150, align 64
  %1076 = add <8 x i64> %.state457, splat (i64 1)
  %1077 = load <8 x i64>, ptr %.slot150, align 64
  %1078 = select <8 x i1> %119, <8 x i64> %1076, <8 x i64> %1077
  store <8 x i64> %1078, ptr %.slot150, align 64
  br label %direct.schedule.63

direct.schedule.69:                               ; preds = %direct.false448
  %1079 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %27, 0
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 0
  %1082 = select <8 x i1> %119, <8 x ptr> %1080, <8 x ptr> %1081
  %1083 = extractvalue { <8 x ptr>, <8 x i64> } %27, 1
  %1084 = extractvalue { <8 x ptr>, <8 x i64> } %1079, 1
  %1085 = select <8 x i1> %119, <8 x i64> %1083, <8 x i64> %1084
  %1086 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1082, 0
  %1087 = insertvalue { <8 x ptr>, <8 x i64> } %1086, <8 x i64> %1085, 1
  store { <8 x ptr>, <8 x i64> } %1087, ptr %tile_snapshot.spill153, align 64
  %1088 = load <8 x i64>, ptr %.slot154, align 64
  %1089 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1088
  store <8 x i64> %1089, ptr %.slot154, align 64
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.75, %direct.schedule.69
  %.state458 = load <8 x i64>, ptr %.slot154, align 64
  %1090 = icmp slt <8 x i64> %.state458, splat (i64 5)
  %1091 = extractelement <8 x i1> %1090, i32 0
  br i1 %1091, label %direct.true459, label %direct.false460

direct.schedule.71:                               ; preds = %direct.true459
  %.state461 = load <8 x i64>, ptr %.slot154, align 64
  %1092 = select <8 x i1> %119, <8 x i64> %.state461, <8 x i64> zeroinitializer
  %1093 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1094 = srem <8 x i64> %1092, %1093
  %1095 = mul <8 x i64> %1094, splat (i64 8)
  %.spill.load462 = load <8 x i64>, ptr %.spill, align 64
  %1096 = add <8 x i64> %1095, %.spill.load462
  %1097 = icmp slt <8 x i64> %1096, splat (i64 33)
  %1098 = load <8 x i1>, ptr %.spill155, align 1
  %1099 = select <8 x i1> %119, <8 x i1> %1097, <8 x i1> %1098
  store <8 x i1> %1099, ptr %.spill155, align 1
  %1100 = add <8 x i64> zeroinitializer, %1094
  %1101 = and <8 x i1> %119, %1097
  %1102 = xor <8 x i1> %1097, splat (i1 true)
  %1103 = and <8 x i1> %119, %1102
  %1104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1101)
  %1105 = bitcast <8 x i1> %1101 to i8
  %1106 = call i8 @llvm.cttz.i8(i8 %1105, i1 false)
  %1107 = zext i8 %1106 to i32
  %1108 = select i1 %1104, i32 %1107, i32 0
  %tile_snapshot.spill.load463 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill149, align 64
  %1109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 0
  %1110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load463, 1
  %1111 = mul <8 x i64> %1100, splat (i64 64)
  %1112 = add <8 x i64> %1110, %1111
  %1113 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1109, 0
  %1114 = insertvalue { <8 x ptr>, <8 x i64> } %1113, <8 x i64> %1112, 1
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %1114, 0
  %1116 = extractvalue { <8 x ptr>, <8 x i64> } %1114, 1
  %1117 = getelementptr i8, <8 x ptr> %1115, <8 x i64> %1116
  %1118 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1117, <8 x i1> %1101, <8 x i64> zeroinitializer)
  %1119 = load <8 x i64>, ptr %.slot156, align 64
  %1120 = select <8 x i1> %1101, <8 x i64> %1118, <8 x i64> %1119
  store <8 x i64> %1120, ptr %.slot156, align 64
  %1121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1103)
  %1122 = bitcast <8 x i1> %1103 to i8
  %1123 = call i8 @llvm.cttz.i8(i8 %1122, i1 false)
  %1124 = zext i8 %1123 to i32
  %1125 = select i1 %1121, i32 %1124, i32 0
  %1126 = load <8 x i64>, ptr %.slot156, align 64
  %1127 = select <8 x i1> %1103, <8 x i64> zeroinitializer, <8 x i64> %1126
  store <8 x i64> %1127, ptr %.slot156, align 64
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.71
  %.state464 = load <8 x i64>, ptr %.slot156, align 64
  %1128 = icmp slt <8 x i64> %.state464, splat (i64 35)
  %.spill.load465 = load <8 x i1>, ptr %.spill155, align 1
  %1129 = and <8 x i1> %119, %.spill.load465
  %1130 = xor <8 x i1> %.spill.load465, splat (i1 true)
  %1131 = and <8 x i1> %119, %1130
  %1132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1129)
  %1133 = bitcast <8 x i1> %1129 to i8
  %1134 = call i8 @llvm.cttz.i8(i8 %1133, i1 false)
  %1135 = zext i8 %1134 to i32
  %1136 = select i1 %1132, i32 %1135, i32 0
  %tile_snapshot.spill.load466 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load466, 0
  %1138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load466, 1
  %.state467 = load <8 x i64>, ptr %.slot154, align 64
  %1139 = add <8 x i64> %1138, %.state467
  %1140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1137, 0
  %1141 = insertvalue { <8 x ptr>, <8 x i64> } %1140, <8 x i64> %1139, 1
  %1142 = extractvalue { <8 x ptr>, <8 x i64> } %1141, 0
  %1143 = extractvalue { <8 x ptr>, <8 x i64> } %1141, 1
  %1144 = getelementptr i8, <8 x ptr> %1142, <8 x i64> %1143
  %1145 = zext <8 x i1> %1128 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1145, <8 x ptr> align 1 %1144, <8 x i1> %1129)
  %1146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1131)
  %1147 = bitcast <8 x i1> %1131 to i8
  %1148 = call i8 @llvm.cttz.i8(i8 %1147, i1 false)
  %1149 = zext i8 %1148 to i32
  %1150 = select i1 %1146, i32 %1149, i32 0
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.73
  %.state468 = load <8 x i64>, ptr %.slot154, align 64
  %1151 = add <8 x i64> %.state468, splat (i64 1)
  %1152 = load <8 x i64>, ptr %.slot154, align 64
  %1153 = select <8 x i1> %119, <8 x i64> %1151, <8 x i64> %1152
  store <8 x i64> %1153, ptr %.slot154, align 64
  br label %direct.schedule.70

direct.schedule.76:                               ; preds = %direct.false460
  %1154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill157, align 64
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1156 = extractvalue { <8 x ptr>, <8 x i64> } %1154, 0
  %1157 = select <8 x i1> %119, <8 x ptr> %1155, <8 x ptr> %1156
  %1158 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %1154, 1
  %1160 = select <8 x i1> %119, <8 x i64> %1158, <8 x i64> %1159
  %1161 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1157, 0
  %1162 = insertvalue { <8 x ptr>, <8 x i64> } %1161, <8 x i64> %1160, 1
  store { <8 x ptr>, <8 x i64> } %1162, ptr %tile_snapshot.spill157, align 64
  %1163 = load <8 x i64>, ptr %.slot158, align 64
  %1164 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1163
  store <8 x i64> %1164, ptr %.slot158, align 64
  br label %direct.schedule.77

direct.schedule.77:                               ; preds = %direct.schedule.80, %direct.schedule.76
  %.state469 = load <8 x i64>, ptr %.slot158, align 64
  %1165 = icmp slt <8 x i64> %.state469, splat (i64 5)
  %1166 = extractelement <8 x i1> %1165, i32 0
  br i1 %1166, label %direct.true470, label %direct.false471

direct.schedule.78:                               ; preds = %direct.true470
  %.state472 = load <8 x i64>, ptr %.slot158, align 64
  %1167 = select <8 x i1> %119, <8 x i64> %.state472, <8 x i64> zeroinitializer
  %1168 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1169 = srem <8 x i64> %1167, %1168
  %1170 = mul <8 x i64> %1169, splat (i64 8)
  %.spill.load473 = load <8 x i64>, ptr %.spill, align 64
  %1171 = add <8 x i64> %1170, %.spill.load473
  %1172 = icmp slt <8 x i64> %1171, splat (i64 33)
  %1173 = select <8 x i1> %1172, <8 x i64> %1171, <8 x i64> splat (i64 32)
  %1174 = and <8 x i1> %119, %1172
  %1175 = xor <8 x i1> %1172, splat (i1 true)
  %1176 = and <8 x i1> %119, %1175
  %1177 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1174)
  %1178 = bitcast <8 x i1> %1174 to i8
  %1179 = call i8 @llvm.cttz.i8(i8 %1178, i1 false)
  %1180 = zext i8 %1179 to i32
  %1181 = select i1 %1177, i32 %1180, i32 0
  %tile_snapshot.spill.load474 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill157, align 64
  %1182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 0
  %1183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 1
  %.state475 = load <8 x i64>, ptr %.slot158, align 64
  %1184 = mul <8 x i64> %.state475, splat (i64 64)
  %1185 = add <8 x i64> %1183, %1184
  %1186 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1182, 0
  %1187 = insertvalue { <8 x ptr>, <8 x i64> } %1186, <8 x i64> %1185, 1
  %1188 = extractvalue { <8 x ptr>, <8 x i64> } %1187, 0
  %1189 = extractvalue { <8 x ptr>, <8 x i64> } %1187, 1
  %1190 = getelementptr i8, <8 x ptr> %1188, <8 x i64> %1189
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %1173, <8 x ptr> align 1 %1190, <8 x i1> %1174)
  %1191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1176)
  %1192 = bitcast <8 x i1> %1176 to i8
  %1193 = call i8 @llvm.cttz.i8(i8 %1192, i1 false)
  %1194 = zext i8 %1193 to i32
  %1195 = select i1 %1191, i32 %1194, i32 0
  br label %direct.schedule.80

direct.schedule.80:                               ; preds = %direct.schedule.78
  %.state476 = load <8 x i64>, ptr %.slot158, align 64
  %1196 = add <8 x i64> %.state476, splat (i64 1)
  %1197 = load <8 x i64>, ptr %.slot158, align 64
  %1198 = select <8 x i1> %119, <8 x i64> %1196, <8 x i64> %1197
  store <8 x i64> %1198, ptr %.slot158, align 64
  br label %direct.schedule.77

direct.schedule.81:                               ; preds = %direct.false471
  %1199 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill159, align 64
  %1200 = extractvalue { <8 x ptr>, <8 x i64> } %31, 0
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %1199, 0
  %1202 = select <8 x i1> %119, <8 x ptr> %1200, <8 x ptr> %1201
  %1203 = extractvalue { <8 x ptr>, <8 x i64> } %31, 1
  %1204 = extractvalue { <8 x ptr>, <8 x i64> } %1199, 1
  %1205 = select <8 x i1> %119, <8 x i64> %1203, <8 x i64> %1204
  %1206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1202, 0
  %1207 = insertvalue { <8 x ptr>, <8 x i64> } %1206, <8 x i64> %1205, 1
  store { <8 x ptr>, <8 x i64> } %1207, ptr %tile_snapshot.spill159, align 64
  %1208 = load <8 x i64>, ptr %.slot160, align 64
  %1209 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1208
  store <8 x i64> %1209, ptr %.slot160, align 64
  br label %direct.schedule.82

direct.schedule.82:                               ; preds = %direct.schedule.87, %direct.schedule.81
  %.state477 = load <8 x i64>, ptr %.slot160, align 64
  %1210 = icmp slt <8 x i64> %.state477, splat (i64 5)
  %1211 = extractelement <8 x i1> %1210, i32 0
  br i1 %1211, label %direct.true478, label %direct.false479

direct.schedule.83:                               ; preds = %direct.true478
  %.state480 = load <8 x i64>, ptr %.slot160, align 64
  %1212 = select <8 x i1> %119, <8 x i64> %.state480, <8 x i64> zeroinitializer
  %1213 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1214 = srem <8 x i64> %1212, %1213
  %1215 = mul <8 x i64> %1214, splat (i64 8)
  %.spill.load481 = load <8 x i64>, ptr %.spill, align 64
  %1216 = add <8 x i64> %1215, %.spill.load481
  %1217 = icmp slt <8 x i64> %1216, splat (i64 33)
  %1218 = load <8 x i1>, ptr %.spill161, align 1
  %1219 = select <8 x i1> %119, <8 x i1> %1217, <8 x i1> %1218
  store <8 x i1> %1219, ptr %.spill161, align 1
  %1220 = add <8 x i64> zeroinitializer, %1214
  %1221 = and <8 x i1> %119, %1217
  %1222 = xor <8 x i1> %1217, splat (i1 true)
  %1223 = and <8 x i1> %119, %1222
  %1224 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1221)
  %1225 = bitcast <8 x i1> %1221 to i8
  %1226 = call i8 @llvm.cttz.i8(i8 %1225, i1 false)
  %1227 = zext i8 %1226 to i32
  %1228 = select i1 %1224, i32 %1227, i32 0
  %tile_snapshot.spill.load482 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill157, align 64
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load482, 0
  %1230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load482, 1
  %1231 = mul <8 x i64> %1220, splat (i64 64)
  %1232 = add <8 x i64> %1230, %1231
  %1233 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1229, 0
  %1234 = insertvalue { <8 x ptr>, <8 x i64> } %1233, <8 x i64> %1232, 1
  %1235 = extractvalue { <8 x ptr>, <8 x i64> } %1234, 0
  %1236 = extractvalue { <8 x ptr>, <8 x i64> } %1234, 1
  %1237 = getelementptr i8, <8 x ptr> %1235, <8 x i64> %1236
  %1238 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1237, <8 x i1> %1221, <8 x i64> zeroinitializer)
  %1239 = load <8 x i64>, ptr %.slot162, align 64
  %1240 = select <8 x i1> %1221, <8 x i64> %1238, <8 x i64> %1239
  store <8 x i64> %1240, ptr %.slot162, align 64
  %1241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1223)
  %1242 = bitcast <8 x i1> %1223 to i8
  %1243 = call i8 @llvm.cttz.i8(i8 %1242, i1 false)
  %1244 = zext i8 %1243 to i32
  %1245 = select i1 %1241, i32 %1244, i32 0
  %1246 = load <8 x i64>, ptr %.slot162, align 64
  %1247 = select <8 x i1> %1223, <8 x i64> zeroinitializer, <8 x i64> %1246
  store <8 x i64> %1247, ptr %.slot162, align 64
  br label %direct.schedule.85

direct.schedule.85:                               ; preds = %direct.schedule.83
  %.state483 = load <8 x i64>, ptr %.slot162, align 64
  %.spill.load484 = load <8 x i64>, ptr %.spill121, align 64
  %1248 = add <8 x i64> %.state483, %.spill.load484
  %.spill.load485 = load <8 x i1>, ptr %.spill161, align 1
  %1249 = and <8 x i1> %119, %.spill.load485
  %1250 = xor <8 x i1> %.spill.load485, splat (i1 true)
  %1251 = and <8 x i1> %119, %1250
  %1252 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1249)
  %1253 = bitcast <8 x i1> %1249 to i8
  %1254 = call i8 @llvm.cttz.i8(i8 %1253, i1 false)
  %1255 = zext i8 %1254 to i32
  %1256 = select i1 %1252, i32 %1255, i32 0
  %tile_snapshot.spill.load486 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill159, align 64
  %1257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load486, 0
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load486, 1
  %.state487 = load <8 x i64>, ptr %.slot160, align 64
  %1259 = mul <8 x i64> %.state487, splat (i64 64)
  %1260 = add <8 x i64> %1258, %1259
  %1261 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1257, 0
  %1262 = insertvalue { <8 x ptr>, <8 x i64> } %1261, <8 x i64> %1260, 1
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 0
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 1
  %1265 = getelementptr i8, <8 x ptr> %1263, <8 x i64> %1264
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %1248, <8 x ptr> align 1 %1265, <8 x i1> %1249)
  %1266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1251)
  %1267 = bitcast <8 x i1> %1251 to i8
  %1268 = call i8 @llvm.cttz.i8(i8 %1267, i1 false)
  %1269 = zext i8 %1268 to i32
  %1270 = select i1 %1266, i32 %1269, i32 0
  br label %direct.schedule.87

direct.schedule.87:                               ; preds = %direct.schedule.85
  %.state488 = load <8 x i64>, ptr %.slot160, align 64
  %1271 = add <8 x i64> %.state488, splat (i64 1)
  %1272 = load <8 x i64>, ptr %.slot160, align 64
  %1273 = select <8 x i1> %119, <8 x i64> %1271, <8 x i64> %1272
  store <8 x i64> %1273, ptr %.slot160, align 64
  br label %direct.schedule.82

direct.schedule.88:                               ; preds = %direct.false479
  %1274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill163, align 64
  %1275 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %1276 = extractvalue { <8 x ptr>, <8 x i64> } %1274, 0
  %1277 = select <8 x i1> %119, <8 x ptr> %1275, <8 x ptr> %1276
  %1278 = extractvalue { <8 x ptr>, <8 x i64> } %33, 1
  %1279 = extractvalue { <8 x ptr>, <8 x i64> } %1274, 1
  %1280 = select <8 x i1> %119, <8 x i64> %1278, <8 x i64> %1279
  %1281 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1277, 0
  %1282 = insertvalue { <8 x ptr>, <8 x i64> } %1281, <8 x i64> %1280, 1
  store { <8 x ptr>, <8 x i64> } %1282, ptr %tile_snapshot.spill163, align 64
  %1283 = load <8 x i64>, ptr %.slot164, align 64
  %1284 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1283
  store <8 x i64> %1284, ptr %.slot164, align 64
  br label %direct.schedule.89

direct.schedule.89:                               ; preds = %direct.schedule.92, %direct.schedule.88
  %.state489 = load <8 x i64>, ptr %.slot164, align 64
  %1285 = icmp slt <8 x i64> %.state489, splat (i64 1)
  %1286 = extractelement <8 x i1> %1285, i32 0
  br i1 %1286, label %direct.true490, label %direct.false491

direct.schedule.90:                               ; preds = %direct.true490
  %.state492 = load <8 x i64>, ptr %.slot164, align 64
  %1287 = select <8 x i1> %119, <8 x i64> %.state492, <8 x i64> zeroinitializer
  %1288 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1289 = srem <8 x i64> %1287, %1288
  %1290 = mul <8 x i64> %1289, splat (i64 8)
  %.spill.load493 = load <8 x i64>, ptr %.spill, align 64
  %1291 = add <8 x i64> %1290, %.spill.load493
  %1292 = icmp slt <8 x i64> %1291, splat (i64 2)
  %1293 = select <8 x i1> %1292, <8 x i64> %1291, <8 x i64> splat (i64 1)
  %1294 = and <8 x i1> %119, %1292
  %1295 = xor <8 x i1> %1292, splat (i1 true)
  %1296 = and <8 x i1> %119, %1295
  %1297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1294)
  %1298 = bitcast <8 x i1> %1294 to i8
  %1299 = call i8 @llvm.cttz.i8(i8 %1298, i1 false)
  %1300 = zext i8 %1299 to i32
  %1301 = select i1 %1297, i32 %1300, i32 0
  %tile_snapshot.spill.load494 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill163, align 64
  %1302 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load494, 0
  %1303 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load494, 1
  %.state495 = load <8 x i64>, ptr %.slot164, align 64
  %1304 = mul <8 x i64> %.state495, splat (i64 64)
  %1305 = add <8 x i64> %1303, %1304
  %1306 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1302, 0
  %1307 = insertvalue { <8 x ptr>, <8 x i64> } %1306, <8 x i64> %1305, 1
  %1308 = extractvalue { <8 x ptr>, <8 x i64> } %1307, 0
  %1309 = extractvalue { <8 x ptr>, <8 x i64> } %1307, 1
  %1310 = getelementptr i8, <8 x ptr> %1308, <8 x i64> %1309
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %1293, <8 x ptr> align 1 %1310, <8 x i1> %1294)
  %1311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1296)
  %1312 = bitcast <8 x i1> %1296 to i8
  %1313 = call i8 @llvm.cttz.i8(i8 %1312, i1 false)
  %1314 = zext i8 %1313 to i32
  %1315 = select i1 %1311, i32 %1314, i32 0
  br label %direct.schedule.92

direct.schedule.92:                               ; preds = %direct.schedule.90
  %.state496 = load <8 x i64>, ptr %.slot164, align 64
  %1316 = add <8 x i64> %.state496, splat (i64 1)
  %1317 = load <8 x i64>, ptr %.slot164, align 64
  %1318 = select <8 x i1> %119, <8 x i64> %1316, <8 x i64> %1317
  store <8 x i64> %1318, ptr %.slot164, align 64
  br label %direct.schedule.89

direct.schedule.93:                               ; preds = %direct.false491
  %1319 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill165, align 64
  %1320 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %1321 = extractvalue { <8 x ptr>, <8 x i64> } %1319, 0
  %1322 = select <8 x i1> %119, <8 x ptr> %1320, <8 x ptr> %1321
  %1323 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %1319, 1
  %1325 = select <8 x i1> %119, <8 x i64> %1323, <8 x i64> %1324
  %1326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1322, 0
  %1327 = insertvalue { <8 x ptr>, <8 x i64> } %1326, <8 x i64> %1325, 1
  store { <8 x ptr>, <8 x i64> } %1327, ptr %tile_snapshot.spill165, align 64
  %1328 = load <8 x i64>, ptr %.slot166, align 64
  %1329 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1328
  store <8 x i64> %1329, ptr %.slot166, align 64
  br label %direct.schedule.94

direct.schedule.94:                               ; preds = %direct.schedule.99, %direct.schedule.93
  %.state497 = load <8 x i64>, ptr %.slot166, align 64
  %1330 = icmp slt <8 x i64> %.state497, splat (i64 1)
  %1331 = extractelement <8 x i1> %1330, i32 0
  br i1 %1331, label %direct.true498, label %direct.false499

direct.schedule.95:                               ; preds = %direct.true498
  %.state500 = load <8 x i64>, ptr %.slot166, align 64
  %1332 = select <8 x i1> %119, <8 x i64> %.state500, <8 x i64> zeroinitializer
  %1333 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1334 = srem <8 x i64> %1332, %1333
  %1335 = mul <8 x i64> %1334, splat (i64 8)
  %.spill.load501 = load <8 x i64>, ptr %.spill, align 64
  %1336 = add <8 x i64> %1335, %.spill.load501
  %1337 = icmp slt <8 x i64> %1336, splat (i64 2)
  %1338 = load <8 x i1>, ptr %.spill167, align 1
  %1339 = select <8 x i1> %119, <8 x i1> %1337, <8 x i1> %1338
  store <8 x i1> %1339, ptr %.spill167, align 1
  %1340 = add <8 x i64> zeroinitializer, %1334
  %1341 = and <8 x i1> %119, %1337
  %1342 = xor <8 x i1> %1337, splat (i1 true)
  %1343 = and <8 x i1> %119, %1342
  %1344 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1341)
  %1345 = bitcast <8 x i1> %1341 to i8
  %1346 = call i8 @llvm.cttz.i8(i8 %1345, i1 false)
  %1347 = zext i8 %1346 to i32
  %1348 = select i1 %1344, i32 %1347, i32 0
  %tile_snapshot.spill.load502 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill163, align 64
  %1349 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 0
  %1350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load502, 1
  %1351 = mul <8 x i64> %1340, splat (i64 64)
  %1352 = add <8 x i64> %1350, %1351
  %1353 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1349, 0
  %1354 = insertvalue { <8 x ptr>, <8 x i64> } %1353, <8 x i64> %1352, 1
  %1355 = extractvalue { <8 x ptr>, <8 x i64> } %1354, 0
  %1356 = extractvalue { <8 x ptr>, <8 x i64> } %1354, 1
  %1357 = getelementptr i8, <8 x ptr> %1355, <8 x i64> %1356
  %1358 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1357, <8 x i1> %1341, <8 x i64> zeroinitializer)
  %1359 = load <8 x i64>, ptr %.slot168, align 64
  %1360 = select <8 x i1> %1341, <8 x i64> %1358, <8 x i64> %1359
  store <8 x i64> %1360, ptr %.slot168, align 64
  %1361 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1343)
  %1362 = bitcast <8 x i1> %1343 to i8
  %1363 = call i8 @llvm.cttz.i8(i8 %1362, i1 false)
  %1364 = zext i8 %1363 to i32
  %1365 = select i1 %1361, i32 %1364, i32 0
  %1366 = load <8 x i64>, ptr %.slot168, align 64
  %1367 = select <8 x i1> %1343, <8 x i64> zeroinitializer, <8 x i64> %1366
  store <8 x i64> %1367, ptr %.slot168, align 64
  br label %direct.schedule.97

direct.schedule.97:                               ; preds = %direct.schedule.95
  %.state503 = load <8 x i64>, ptr %.slot168, align 64
  %.spill.load504 = load <8 x i64>, ptr %.spill107, align 64
  %1368 = add <8 x i64> %.state503, %.spill.load504
  %.spill.load505 = load <8 x i1>, ptr %.spill167, align 1
  %1369 = and <8 x i1> %119, %.spill.load505
  %1370 = xor <8 x i1> %.spill.load505, splat (i1 true)
  %1371 = and <8 x i1> %119, %1370
  %1372 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1369)
  %1373 = bitcast <8 x i1> %1369 to i8
  %1374 = call i8 @llvm.cttz.i8(i8 %1373, i1 false)
  %1375 = zext i8 %1374 to i32
  %1376 = select i1 %1372, i32 %1375, i32 0
  %tile_snapshot.spill.load506 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill165, align 64
  %1377 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load506, 0
  %1378 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load506, 1
  %.state507 = load <8 x i64>, ptr %.slot166, align 64
  %1379 = mul <8 x i64> %.state507, splat (i64 64)
  %1380 = add <8 x i64> %1378, %1379
  %1381 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1377, 0
  %1382 = insertvalue { <8 x ptr>, <8 x i64> } %1381, <8 x i64> %1380, 1
  %1383 = extractvalue { <8 x ptr>, <8 x i64> } %1382, 0
  %1384 = extractvalue { <8 x ptr>, <8 x i64> } %1382, 1
  %1385 = getelementptr i8, <8 x ptr> %1383, <8 x i64> %1384
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %1368, <8 x ptr> align 1 %1385, <8 x i1> %1369)
  %1386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1371)
  %1387 = bitcast <8 x i1> %1371 to i8
  %1388 = call i8 @llvm.cttz.i8(i8 %1387, i1 false)
  %1389 = zext i8 %1388 to i32
  %1390 = select i1 %1386, i32 %1389, i32 0
  br label %direct.schedule.99

direct.schedule.99:                               ; preds = %direct.schedule.97
  %.state508 = load <8 x i64>, ptr %.slot166, align 64
  %1391 = add <8 x i64> %.state508, splat (i64 1)
  %1392 = load <8 x i64>, ptr %.slot166, align 64
  %1393 = select <8 x i1> %119, <8 x i64> %1391, <8 x i64> %1392
  store <8 x i64> %1393, ptr %.slot166, align 64
  br label %direct.schedule.94

direct.schedule.100:                              ; preds = %direct.false499
  %1394 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill169, align 64
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %37, 0
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %1394, 0
  %1397 = select <8 x i1> %119, <8 x ptr> %1395, <8 x ptr> %1396
  %1398 = extractvalue { <8 x ptr>, <8 x i64> } %37, 1
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %1394, 1
  %1400 = select <8 x i1> %119, <8 x i64> %1398, <8 x i64> %1399
  %1401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1397, 0
  %1402 = insertvalue { <8 x ptr>, <8 x i64> } %1401, <8 x i64> %1400, 1
  store { <8 x ptr>, <8 x i64> } %1402, ptr %tile_snapshot.spill169, align 64
  %1403 = load <8 x i64>, ptr %.slot170, align 64
  %1404 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1403
  store <8 x i64> %1404, ptr %.slot170, align 64
  br label %direct.schedule.101

direct.schedule.101:                              ; preds = %direct.schedule.106, %direct.schedule.100
  %.state509 = load <8 x i64>, ptr %.slot170, align 64
  %1405 = icmp slt <8 x i64> %.state509, splat (i64 1)
  %1406 = extractelement <8 x i1> %1405, i32 0
  br i1 %1406, label %direct.true510, label %direct.false511

direct.schedule.102:                              ; preds = %direct.true510
  %.state512 = load <8 x i64>, ptr %.slot170, align 64
  %1407 = select <8 x i1> %119, <8 x i64> %.state512, <8 x i64> zeroinitializer
  %1408 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1409 = srem <8 x i64> %1407, %1408
  %1410 = mul <8 x i64> %1409, splat (i64 8)
  %.spill.load513 = load <8 x i64>, ptr %.spill, align 64
  %1411 = add <8 x i64> %1410, %.spill.load513
  %1412 = icmp slt <8 x i64> %1411, splat (i64 2)
  %1413 = load <8 x i1>, ptr %.spill171, align 1
  %1414 = select <8 x i1> %119, <8 x i1> %1412, <8 x i1> %1413
  store <8 x i1> %1414, ptr %.spill171, align 1
  %1415 = add <8 x i64> zeroinitializer, %1409
  %1416 = and <8 x i1> %119, %1412
  %1417 = xor <8 x i1> %1412, splat (i1 true)
  %1418 = and <8 x i1> %119, %1417
  %1419 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1416)
  %1420 = bitcast <8 x i1> %1416 to i8
  %1421 = call i8 @llvm.cttz.i8(i8 %1420, i1 false)
  %1422 = zext i8 %1421 to i32
  %1423 = select i1 %1419, i32 %1422, i32 0
  %tile_snapshot.spill.load514 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill165, align 64
  %1424 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load514, 0
  %1425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load514, 1
  %1426 = mul <8 x i64> %1415, splat (i64 64)
  %1427 = add <8 x i64> %1425, %1426
  %1428 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1424, 0
  %1429 = insertvalue { <8 x ptr>, <8 x i64> } %1428, <8 x i64> %1427, 1
  %1430 = extractvalue { <8 x ptr>, <8 x i64> } %1429, 0
  %1431 = extractvalue { <8 x ptr>, <8 x i64> } %1429, 1
  %1432 = getelementptr i8, <8 x ptr> %1430, <8 x i64> %1431
  %1433 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1432, <8 x i1> %1416, <8 x i64> zeroinitializer)
  %1434 = load <8 x i64>, ptr %.slot172, align 64
  %1435 = select <8 x i1> %1416, <8 x i64> %1433, <8 x i64> %1434
  store <8 x i64> %1435, ptr %.slot172, align 64
  %1436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1418)
  %1437 = bitcast <8 x i1> %1418 to i8
  %1438 = call i8 @llvm.cttz.i8(i8 %1437, i1 false)
  %1439 = zext i8 %1438 to i32
  %1440 = select i1 %1436, i32 %1439, i32 0
  %1441 = load <8 x i64>, ptr %.slot172, align 64
  %1442 = select <8 x i1> %1418, <8 x i64> zeroinitializer, <8 x i64> %1441
  store <8 x i64> %1442, ptr %.slot172, align 64
  br label %direct.schedule.104

direct.schedule.104:                              ; preds = %direct.schedule.102
  %.state515 = load <8 x i64>, ptr %.slot172, align 64
  %1443 = add <8 x i64> %.state515, splat (i64 35)
  %.spill.load516 = load <8 x i1>, ptr %.spill171, align 1
  %1444 = and <8 x i1> %119, %.spill.load516
  %1445 = xor <8 x i1> %.spill.load516, splat (i1 true)
  %1446 = and <8 x i1> %119, %1445
  %1447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1444)
  %1448 = bitcast <8 x i1> %1444 to i8
  %1449 = call i8 @llvm.cttz.i8(i8 %1448, i1 false)
  %1450 = zext i8 %1449 to i32
  %1451 = select i1 %1447, i32 %1450, i32 0
  %tile_snapshot.spill.load517 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill169, align 64
  %1452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load517, 0
  %1453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load517, 1
  %.state518 = load <8 x i64>, ptr %.slot170, align 64
  %1454 = mul <8 x i64> %.state518, splat (i64 64)
  %1455 = add <8 x i64> %1453, %1454
  %1456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1452, 0
  %1457 = insertvalue { <8 x ptr>, <8 x i64> } %1456, <8 x i64> %1455, 1
  %1458 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 0
  %1459 = extractvalue { <8 x ptr>, <8 x i64> } %1457, 1
  %1460 = getelementptr i8, <8 x ptr> %1458, <8 x i64> %1459
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %1443, <8 x ptr> align 1 %1460, <8 x i1> %1444)
  %1461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1446)
  %1462 = bitcast <8 x i1> %1446 to i8
  %1463 = call i8 @llvm.cttz.i8(i8 %1462, i1 false)
  %1464 = zext i8 %1463 to i32
  %1465 = select i1 %1461, i32 %1464, i32 0
  br label %direct.schedule.106

direct.schedule.106:                              ; preds = %direct.schedule.104
  %.state519 = load <8 x i64>, ptr %.slot170, align 64
  %1466 = add <8 x i64> %.state519, splat (i64 1)
  %1467 = load <8 x i64>, ptr %.slot170, align 64
  %1468 = select <8 x i1> %119, <8 x i64> %1466, <8 x i64> %1467
  store <8 x i64> %1468, ptr %.slot170, align 64
  br label %direct.schedule.101

direct.schedule.107:                              ; preds = %direct.false511
  %1469 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill173, align 64
  %1470 = extractvalue { <8 x ptr>, <8 x i64> } %39, 0
  %1471 = extractvalue { <8 x ptr>, <8 x i64> } %1469, 0
  %1472 = select <8 x i1> %119, <8 x ptr> %1470, <8 x ptr> %1471
  %1473 = extractvalue { <8 x ptr>, <8 x i64> } %39, 1
  %1474 = extractvalue { <8 x ptr>, <8 x i64> } %1469, 1
  %1475 = select <8 x i1> %119, <8 x i64> %1473, <8 x i64> %1474
  %1476 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1472, 0
  %1477 = insertvalue { <8 x ptr>, <8 x i64> } %1476, <8 x i64> %1475, 1
  store { <8 x ptr>, <8 x i64> } %1477, ptr %tile_snapshot.spill173, align 64
  %1478 = load <8 x i64>, ptr %.slot174, align 64
  %1479 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1478
  store <8 x i64> %1479, ptr %.slot174, align 64
  br label %direct.schedule.108

direct.schedule.108:                              ; preds = %direct.schedule.113, %direct.schedule.107
  %.state520 = load <8 x i64>, ptr %.slot174, align 64
  %1480 = icmp slt <8 x i64> %.state520, splat (i64 1)
  %1481 = extractelement <8 x i1> %1480, i32 0
  br i1 %1481, label %direct.true521, label %direct.false522

direct.schedule.109:                              ; preds = %direct.true521
  %.state523 = load <8 x i64>, ptr %.slot174, align 64
  %1482 = select <8 x i1> %119, <8 x i64> %.state523, <8 x i64> zeroinitializer
  %1483 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1484 = srem <8 x i64> %1482, %1483
  %1485 = mul <8 x i64> %1484, splat (i64 8)
  %.spill.load524 = load <8 x i64>, ptr %.spill, align 64
  %1486 = add <8 x i64> %1485, %.spill.load524
  %1487 = icmp slt <8 x i64> %1486, splat (i64 2)
  %1488 = load <8 x i1>, ptr %.spill175, align 1
  %1489 = select <8 x i1> %119, <8 x i1> %1487, <8 x i1> %1488
  store <8 x i1> %1489, ptr %.spill175, align 1
  %1490 = add <8 x i64> zeroinitializer, %1484
  %1491 = and <8 x i1> %119, %1487
  %1492 = xor <8 x i1> %1487, splat (i1 true)
  %1493 = and <8 x i1> %119, %1492
  %1494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1491)
  %1495 = bitcast <8 x i1> %1491 to i8
  %1496 = call i8 @llvm.cttz.i8(i8 %1495, i1 false)
  %1497 = zext i8 %1496 to i32
  %1498 = select i1 %1494, i32 %1497, i32 0
  %tile_snapshot.spill.load525 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill169, align 64
  %1499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load525, 0
  %1500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load525, 1
  %1501 = mul <8 x i64> %1490, splat (i64 64)
  %1502 = add <8 x i64> %1500, %1501
  %1503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1499, 0
  %1504 = insertvalue { <8 x ptr>, <8 x i64> } %1503, <8 x i64> %1502, 1
  %1505 = extractvalue { <8 x ptr>, <8 x i64> } %1504, 0
  %1506 = extractvalue { <8 x ptr>, <8 x i64> } %1504, 1
  %1507 = getelementptr i8, <8 x ptr> %1505, <8 x i64> %1506
  %1508 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1507, <8 x i1> %1491, <8 x i64> zeroinitializer)
  %1509 = load <8 x i64>, ptr %.slot176, align 64
  %1510 = select <8 x i1> %1491, <8 x i64> %1508, <8 x i64> %1509
  store <8 x i64> %1510, ptr %.slot176, align 64
  %1511 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1493)
  %1512 = bitcast <8 x i1> %1493 to i8
  %1513 = call i8 @llvm.cttz.i8(i8 %1512, i1 false)
  %1514 = zext i8 %1513 to i32
  %1515 = select i1 %1511, i32 %1514, i32 0
  %1516 = load <8 x i64>, ptr %.slot176, align 64
  %1517 = select <8 x i1> %1493, <8 x i64> zeroinitializer, <8 x i64> %1516
  store <8 x i64> %1517, ptr %.slot176, align 64
  br label %direct.schedule.111

direct.schedule.111:                              ; preds = %direct.schedule.109
  %.state526 = load <8 x i64>, ptr %.slot176, align 64
  %1518 = sub <8 x i64> %.state526, splat (i64 3)
  %.spill.load527 = load <8 x i1>, ptr %.spill175, align 1
  %1519 = and <8 x i1> %119, %.spill.load527
  %1520 = xor <8 x i1> %.spill.load527, splat (i1 true)
  %1521 = and <8 x i1> %119, %1520
  %1522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1519)
  %1523 = bitcast <8 x i1> %1519 to i8
  %1524 = call i8 @llvm.cttz.i8(i8 %1523, i1 false)
  %1525 = zext i8 %1524 to i32
  %1526 = select i1 %1522, i32 %1525, i32 0
  %tile_snapshot.spill.load528 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill173, align 64
  %1527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load528, 0
  %1528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load528, 1
  %.state529 = load <8 x i64>, ptr %.slot174, align 64
  %1529 = mul <8 x i64> %.state529, splat (i64 64)
  %1530 = add <8 x i64> %1528, %1529
  %1531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1527, 0
  %1532 = insertvalue { <8 x ptr>, <8 x i64> } %1531, <8 x i64> %1530, 1
  %1533 = extractvalue { <8 x ptr>, <8 x i64> } %1532, 0
  %1534 = extractvalue { <8 x ptr>, <8 x i64> } %1532, 1
  %1535 = getelementptr i8, <8 x ptr> %1533, <8 x i64> %1534
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %1518, <8 x ptr> align 1 %1535, <8 x i1> %1519)
  %1536 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1521)
  %1537 = bitcast <8 x i1> %1521 to i8
  %1538 = call i8 @llvm.cttz.i8(i8 %1537, i1 false)
  %1539 = zext i8 %1538 to i32
  %1540 = select i1 %1536, i32 %1539, i32 0
  br label %direct.schedule.113

direct.schedule.113:                              ; preds = %direct.schedule.111
  %.state530 = load <8 x i64>, ptr %.slot174, align 64
  %1541 = add <8 x i64> %.state530, splat (i64 1)
  %1542 = load <8 x i64>, ptr %.slot174, align 64
  %1543 = select <8 x i1> %119, <8 x i64> %1541, <8 x i64> %1542
  store <8 x i64> %1543, ptr %.slot174, align 64
  br label %direct.schedule.108

direct.schedule.114:                              ; preds = %direct.false522
  %1544 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill177, align 64
  %1545 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %1546 = extractvalue { <8 x ptr>, <8 x i64> } %1544, 0
  %1547 = select <8 x i1> %119, <8 x ptr> %1545, <8 x ptr> %1546
  %1548 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %1549 = extractvalue { <8 x ptr>, <8 x i64> } %1544, 1
  %1550 = select <8 x i1> %119, <8 x i64> %1548, <8 x i64> %1549
  %1551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1547, 0
  %1552 = insertvalue { <8 x ptr>, <8 x i64> } %1551, <8 x i64> %1550, 1
  store { <8 x ptr>, <8 x i64> } %1552, ptr %tile_snapshot.spill177, align 64
  %1553 = load <8 x i64>, ptr %.slot178, align 64
  %1554 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1553
  store <8 x i64> %1554, ptr %.slot178, align 64
  br label %direct.schedule.115

direct.schedule.115:                              ; preds = %direct.schedule.122, %direct.schedule.114
  %.state531 = load <8 x i64>, ptr %.slot178, align 64
  %1555 = icmp slt <8 x i64> %.state531, splat (i64 10)
  %1556 = extractelement <8 x i1> %1555, i32 0
  br i1 %1556, label %direct.true532, label %direct.false533

direct.schedule.116:                              ; preds = %direct.true532
  %.state534 = load <8 x i64>, ptr %.slot178, align 64
  %1557 = select <8 x i1> %119, <8 x i64> %.state534, <8 x i64> zeroinitializer
  %1558 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1559 = srem <8 x i64> %1557, %1558
  %1560 = load <8 x i64>, ptr %.spill179, align 64
  %1561 = select <8 x i1> %119, <8 x i64> %1559, <8 x i64> %1560
  store <8 x i64> %1561, ptr %.spill179, align 64
  %.state535 = load <8 x i64>, ptr %.slot178, align 64
  %1562 = select <8 x i1> %119, <8 x i64> %.state535, <8 x i64> zeroinitializer
  %1563 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1564 = sdiv <8 x i64> %1562, %1563
  %1565 = select <8 x i1> %119, <8 x i64> %1564, <8 x i64> zeroinitializer
  %1566 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1567 = srem <8 x i64> %1565, %1566
  %1568 = mul <8 x i64> %1567, splat (i64 8)
  %.spill.load536 = load <8 x i64>, ptr %.spill, align 64
  %1569 = add <8 x i64> %1568, %.spill.load536
  %1570 = icmp slt <8 x i64> %1569, splat (i64 33)
  %1571 = load <8 x i1>, ptr %.spill180, align 1
  %1572 = select <8 x i1> %119, <8 x i1> %1570, <8 x i1> %1571
  store <8 x i1> %1572, ptr %.spill180, align 1
  %1573 = add <8 x i64> zeroinitializer, %1567
  %1574 = and <8 x i1> %119, %1570
  %1575 = xor <8 x i1> %1570, splat (i1 true)
  %1576 = and <8 x i1> %119, %1575
  %1577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1574)
  %1578 = bitcast <8 x i1> %1574 to i8
  %1579 = call i8 @llvm.cttz.i8(i8 %1578, i1 false)
  %1580 = zext i8 %1579 to i32
  %1581 = select i1 %1577, i32 %1580, i32 0
  %tile_snapshot.spill.load537 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill159, align 64
  %1582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load537, 0
  %1583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load537, 1
  %1584 = mul <8 x i64> %1573, splat (i64 64)
  %1585 = add <8 x i64> %1583, %1584
  %1586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1582, 0
  %1587 = insertvalue { <8 x ptr>, <8 x i64> } %1586, <8 x i64> %1585, 1
  %1588 = extractvalue { <8 x ptr>, <8 x i64> } %1587, 0
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %1587, 1
  %1590 = getelementptr i8, <8 x ptr> %1588, <8 x i64> %1589
  %1591 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1590, <8 x i1> %1574, <8 x i64> zeroinitializer)
  %1592 = load <8 x i64>, ptr %.slot181, align 64
  %1593 = select <8 x i1> %1574, <8 x i64> %1591, <8 x i64> %1592
  store <8 x i64> %1593, ptr %.slot181, align 64
  %1594 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1576)
  %1595 = bitcast <8 x i1> %1576 to i8
  %1596 = call i8 @llvm.cttz.i8(i8 %1595, i1 false)
  %1597 = zext i8 %1596 to i32
  %1598 = select i1 %1594, i32 %1597, i32 0
  %1599 = load <8 x i64>, ptr %.slot181, align 64
  %1600 = select <8 x i1> %1576, <8 x i64> zeroinitializer, <8 x i64> %1599
  store <8 x i64> %1600, ptr %.slot181, align 64
  br label %direct.schedule.118

direct.schedule.118:                              ; preds = %direct.schedule.116
  %.spill.load538 = load <8 x i64>, ptr %.spill179, align 64
  %1601 = select <8 x i1> %119, <8 x i64> %.spill.load538, <8 x i64> zeroinitializer
  %1602 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %1603 = sdiv <8 x i64> %1601, %1602
  %1604 = add <8 x i64> zeroinitializer, %1603
  %.spill.load539 = load <8 x i64>, ptr %.spill179, align 64
  %1605 = select <8 x i1> %119, <8 x i64> %.spill.load539, <8 x i64> zeroinitializer
  %1606 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %1607 = srem <8 x i64> %1605, %1606
  %1608 = load <8 x i64>, ptr %.spill182, align 64
  %1609 = select <8 x i1> %119, <8 x i64> %1607, <8 x i64> %1608
  store <8 x i64> %1609, ptr %.spill182, align 64
  %.spill.load540 = load <8 x i64>, ptr %.spill, align 64
  %1610 = icmp eq <8 x i64> %.spill.load540, %1607
  %1611 = and <8 x i1> %119, %1610
  %1612 = xor <8 x i1> %1610, splat (i1 true)
  %1613 = and <8 x i1> %119, %1612
  %1614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1611)
  %1615 = bitcast <8 x i1> %1611 to i8
  %1616 = call i8 @llvm.cttz.i8(i8 %1615, i1 false)
  %1617 = zext i8 %1616 to i32
  %1618 = select i1 %1614, i32 %1617, i32 0
  %tile_snapshot.spill.load541 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill173, align 64
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load541, 0
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load541, 1
  %1621 = mul <8 x i64> %1604, splat (i64 64)
  %1622 = add <8 x i64> %1620, %1621
  %1623 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1619, 0
  %1624 = insertvalue { <8 x ptr>, <8 x i64> } %1623, <8 x i64> %1622, 1
  %1625 = extractvalue { <8 x ptr>, <8 x i64> } %1624, 0
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %1624, 1
  %1627 = getelementptr i8, <8 x ptr> %1625, <8 x i64> %1626
  %1628 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1627, <8 x i1> %1611, <8 x i64> zeroinitializer)
  %1629 = load <8 x i64>, ptr %.slot183, align 64
  %1630 = select <8 x i1> %1611, <8 x i64> %1628, <8 x i64> %1629
  store <8 x i64> %1630, ptr %.slot183, align 64
  %1631 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1613)
  %1632 = bitcast <8 x i1> %1613 to i8
  %1633 = call i8 @llvm.cttz.i8(i8 %1632, i1 false)
  %1634 = zext i8 %1633 to i32
  %1635 = select i1 %1631, i32 %1634, i32 0
  %1636 = load <8 x i64>, ptr %.slot183, align 64
  %1637 = select <8 x i1> %1613, <8 x i64> zeroinitializer, <8 x i64> %1636
  store <8 x i64> %1637, ptr %.slot183, align 64
  br label %direct.schedule.120

direct.schedule.120:                              ; preds = %direct.schedule.118
  %.spill.load542 = load <8 x i64>, ptr %.spill182, align 64
  %1638 = trunc <8 x i64> %.spill.load542 to <8 x i32>
  %.state543 = load <8 x i64>, ptr %.slot183, align 64
  %1639 = extractelement <8 x i32> %1638, i64 0
  %1640 = icmp ult i32 %1639, 8
  %1641 = select i1 %1640, i32 %1639, i32 0
  %1642 = extractelement <8 x i1> %119, i32 %1641
  %1643 = extractelement <8 x i1> %119, i64 0
  %1644 = and i1 %1640, %1642
  %1645 = and i1 %1643, %1644
  %1646 = extractelement <8 x i64> %.state543, i32 %1641
  %1647 = select i1 %1645, i64 %1646, i64 0
  %1648 = insertelement <8 x i64> poison, i64 %1647, i64 0
  %1649 = xor i1 %1645, true
  %1650 = and i1 %1643, %1649
  %1651 = insertelement <8 x i1> poison, i1 %1650, i64 0
  %1652 = extractelement <8 x i32> %1638, i64 1
  %1653 = icmp ult i32 %1652, 8
  %1654 = select i1 %1653, i32 %1652, i32 0
  %1655 = extractelement <8 x i1> %119, i32 %1654
  %1656 = extractelement <8 x i1> %119, i64 1
  %1657 = and i1 %1653, %1655
  %1658 = and i1 %1656, %1657
  %1659 = extractelement <8 x i64> %.state543, i32 %1654
  %1660 = select i1 %1658, i64 %1659, i64 0
  %1661 = insertelement <8 x i64> %1648, i64 %1660, i64 1
  %1662 = xor i1 %1658, true
  %1663 = and i1 %1656, %1662
  %1664 = insertelement <8 x i1> %1651, i1 %1663, i64 1
  %1665 = extractelement <8 x i32> %1638, i64 2
  %1666 = icmp ult i32 %1665, 8
  %1667 = select i1 %1666, i32 %1665, i32 0
  %1668 = extractelement <8 x i1> %119, i32 %1667
  %1669 = extractelement <8 x i1> %119, i64 2
  %1670 = and i1 %1666, %1668
  %1671 = and i1 %1669, %1670
  %1672 = extractelement <8 x i64> %.state543, i32 %1667
  %1673 = select i1 %1671, i64 %1672, i64 0
  %1674 = insertelement <8 x i64> %1661, i64 %1673, i64 2
  %1675 = xor i1 %1671, true
  %1676 = and i1 %1669, %1675
  %1677 = insertelement <8 x i1> %1664, i1 %1676, i64 2
  %1678 = extractelement <8 x i32> %1638, i64 3
  %1679 = icmp ult i32 %1678, 8
  %1680 = select i1 %1679, i32 %1678, i32 0
  %1681 = extractelement <8 x i1> %119, i32 %1680
  %1682 = extractelement <8 x i1> %119, i64 3
  %1683 = and i1 %1679, %1681
  %1684 = and i1 %1682, %1683
  %1685 = extractelement <8 x i64> %.state543, i32 %1680
  %1686 = select i1 %1684, i64 %1685, i64 0
  %1687 = insertelement <8 x i64> %1674, i64 %1686, i64 3
  %1688 = xor i1 %1684, true
  %1689 = and i1 %1682, %1688
  %1690 = insertelement <8 x i1> %1677, i1 %1689, i64 3
  %1691 = extractelement <8 x i32> %1638, i64 4
  %1692 = icmp ult i32 %1691, 8
  %1693 = select i1 %1692, i32 %1691, i32 0
  %1694 = extractelement <8 x i1> %119, i32 %1693
  %1695 = extractelement <8 x i1> %119, i64 4
  %1696 = and i1 %1692, %1694
  %1697 = and i1 %1695, %1696
  %1698 = extractelement <8 x i64> %.state543, i32 %1693
  %1699 = select i1 %1697, i64 %1698, i64 0
  %1700 = insertelement <8 x i64> %1687, i64 %1699, i64 4
  %1701 = xor i1 %1697, true
  %1702 = and i1 %1695, %1701
  %1703 = insertelement <8 x i1> %1690, i1 %1702, i64 4
  %1704 = extractelement <8 x i32> %1638, i64 5
  %1705 = icmp ult i32 %1704, 8
  %1706 = select i1 %1705, i32 %1704, i32 0
  %1707 = extractelement <8 x i1> %119, i32 %1706
  %1708 = extractelement <8 x i1> %119, i64 5
  %1709 = and i1 %1705, %1707
  %1710 = and i1 %1708, %1709
  %1711 = extractelement <8 x i64> %.state543, i32 %1706
  %1712 = select i1 %1710, i64 %1711, i64 0
  %1713 = insertelement <8 x i64> %1700, i64 %1712, i64 5
  %1714 = xor i1 %1710, true
  %1715 = and i1 %1708, %1714
  %1716 = insertelement <8 x i1> %1703, i1 %1715, i64 5
  %1717 = extractelement <8 x i32> %1638, i64 6
  %1718 = icmp ult i32 %1717, 8
  %1719 = select i1 %1718, i32 %1717, i32 0
  %1720 = extractelement <8 x i1> %119, i32 %1719
  %1721 = extractelement <8 x i1> %119, i64 6
  %1722 = and i1 %1718, %1720
  %1723 = and i1 %1721, %1722
  %1724 = extractelement <8 x i64> %.state543, i32 %1719
  %1725 = select i1 %1723, i64 %1724, i64 0
  %1726 = insertelement <8 x i64> %1713, i64 %1725, i64 6
  %1727 = xor i1 %1723, true
  %1728 = and i1 %1721, %1727
  %1729 = insertelement <8 x i1> %1716, i1 %1728, i64 6
  %1730 = extractelement <8 x i32> %1638, i64 7
  %1731 = icmp ult i32 %1730, 8
  %1732 = select i1 %1731, i32 %1730, i32 0
  %1733 = extractelement <8 x i1> %119, i32 %1732
  %1734 = extractelement <8 x i1> %119, i64 7
  %1735 = and i1 %1731, %1733
  %1736 = and i1 %1734, %1735
  %1737 = extractelement <8 x i64> %.state543, i32 %1732
  %1738 = select i1 %1736, i64 %1737, i64 0
  %1739 = insertelement <8 x i64> %1726, i64 %1738, i64 7
  %1740 = xor i1 %1736, true
  %1741 = and i1 %1734, %1740
  %1742 = insertelement <8 x i1> %1729, i1 %1741, i64 7
  %.state544 = load <8 x i64>, ptr %.slot181, align 64
  %1743 = icmp sle <8 x i64> %.state544, %1739
  %.spill.load545 = load <8 x i1>, ptr %.spill180, align 1
  %1744 = and <8 x i1> %119, %.spill.load545
  %1745 = xor <8 x i1> %.spill.load545, splat (i1 true)
  %1746 = and <8 x i1> %119, %1745
  %1747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1744)
  %1748 = bitcast <8 x i1> %1744 to i8
  %1749 = call i8 @llvm.cttz.i8(i8 %1748, i1 false)
  %1750 = zext i8 %1749 to i32
  %1751 = select i1 %1747, i32 %1750, i32 0
  %tile_snapshot.spill.load546 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill177, align 64
  %1752 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load546, 0
  %1753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load546, 1
  %.state547 = load <8 x i64>, ptr %.slot178, align 64
  %1754 = add <8 x i64> %1753, %.state547
  %1755 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1752, 0
  %1756 = insertvalue { <8 x ptr>, <8 x i64> } %1755, <8 x i64> %1754, 1
  %1757 = extractvalue { <8 x ptr>, <8 x i64> } %1756, 0
  %1758 = extractvalue { <8 x ptr>, <8 x i64> } %1756, 1
  %1759 = getelementptr i8, <8 x ptr> %1757, <8 x i64> %1758
  %1760 = zext <8 x i1> %1743 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1760, <8 x ptr> align 1 %1759, <8 x i1> %1744)
  %1761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1746)
  %1762 = bitcast <8 x i1> %1746 to i8
  %1763 = call i8 @llvm.cttz.i8(i8 %1762, i1 false)
  %1764 = zext i8 %1763 to i32
  %1765 = select i1 %1761, i32 %1764, i32 0
  br label %direct.schedule.122

direct.schedule.122:                              ; preds = %direct.schedule.120
  %.state548 = load <8 x i64>, ptr %.slot178, align 64
  %1766 = add <8 x i64> %.state548, splat (i64 1)
  %1767 = load <8 x i64>, ptr %.slot178, align 64
  %1768 = select <8 x i1> %119, <8 x i64> %1766, <8 x i64> %1767
  store <8 x i64> %1768, ptr %.slot178, align 64
  br label %direct.schedule.115

direct.schedule.123:                              ; preds = %direct.false533
  %1769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill184, align 64
  %1770 = extractvalue { <8 x ptr>, <8 x i64> } %43, 0
  %1771 = extractvalue { <8 x ptr>, <8 x i64> } %1769, 0
  %1772 = select <8 x i1> %119, <8 x ptr> %1770, <8 x ptr> %1771
  %1773 = extractvalue { <8 x ptr>, <8 x i64> } %43, 1
  %1774 = extractvalue { <8 x ptr>, <8 x i64> } %1769, 1
  %1775 = select <8 x i1> %119, <8 x i64> %1773, <8 x i64> %1774
  %1776 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1772, 0
  %1777 = insertvalue { <8 x ptr>, <8 x i64> } %1776, <8 x i64> %1775, 1
  store { <8 x ptr>, <8 x i64> } %1777, ptr %tile_snapshot.spill184, align 64
  %1778 = load <8 x i64>, ptr %.slot185, align 64
  %1779 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1778
  store <8 x i64> %1779, ptr %.slot185, align 64
  br label %direct.schedule.124

direct.schedule.124:                              ; preds = %direct.schedule.131, %direct.schedule.123
  %.state549 = load <8 x i64>, ptr %.slot185, align 64
  %1780 = icmp slt <8 x i64> %.state549, splat (i64 10)
  %1781 = extractelement <8 x i1> %1780, i32 0
  br i1 %1781, label %direct.true550, label %direct.false551

direct.schedule.125:                              ; preds = %direct.true550
  %.state552 = load <8 x i64>, ptr %.slot185, align 64
  %1782 = select <8 x i1> %119, <8 x i64> %.state552, <8 x i64> zeroinitializer
  %1783 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1784 = srem <8 x i64> %1782, %1783
  %1785 = load <8 x i64>, ptr %.spill186, align 64
  %1786 = select <8 x i1> %119, <8 x i64> %1784, <8 x i64> %1785
  store <8 x i64> %1786, ptr %.spill186, align 64
  %.state553 = load <8 x i64>, ptr %.slot185, align 64
  %1787 = select <8 x i1> %119, <8 x i64> %.state553, <8 x i64> zeroinitializer
  %1788 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1789 = sdiv <8 x i64> %1787, %1788
  %1790 = select <8 x i1> %119, <8 x i64> %1789, <8 x i64> zeroinitializer
  %1791 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1792 = srem <8 x i64> %1790, %1791
  %1793 = mul <8 x i64> %1792, splat (i64 8)
  %.spill.load554 = load <8 x i64>, ptr %.spill, align 64
  %1794 = add <8 x i64> %1793, %.spill.load554
  %1795 = icmp slt <8 x i64> %1794, splat (i64 33)
  %1796 = load <8 x i1>, ptr %.spill187, align 1
  %1797 = select <8 x i1> %119, <8 x i1> %1795, <8 x i1> %1796
  store <8 x i1> %1797, ptr %.spill187, align 1
  %1798 = add <8 x i64> zeroinitializer, %1792
  %1799 = load <8 x i64>, ptr %.spill188, align 64
  %1800 = select <8 x i1> %119, <8 x i64> %1798, <8 x i64> %1799
  store <8 x i64> %1800, ptr %.spill188, align 64
  %1801 = and <8 x i1> %119, %1795
  %1802 = xor <8 x i1> %1795, splat (i1 true)
  %1803 = and <8 x i1> %119, %1802
  %1804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1801)
  %1805 = bitcast <8 x i1> %1801 to i8
  %1806 = call i8 @llvm.cttz.i8(i8 %1805, i1 false)
  %1807 = zext i8 %1806 to i32
  %1808 = select i1 %1804, i32 %1807, i32 0
  %tile_snapshot.spill.load555 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1809 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load555, 0
  %1810 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load555, 1
  %1811 = add <8 x i64> %1810, %1798
  %1812 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1809, 0
  %1813 = insertvalue { <8 x ptr>, <8 x i64> } %1812, <8 x i64> %1811, 1
  %1814 = extractvalue { <8 x ptr>, <8 x i64> } %1813, 0
  %1815 = extractvalue { <8 x ptr>, <8 x i64> } %1813, 1
  %1816 = getelementptr i8, <8 x ptr> %1814, <8 x i64> %1815
  %1817 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1816, <8 x i1> %1801, <8 x i8> zeroinitializer)
  %1818 = icmp ne <8 x i8> %1817, zeroinitializer
  %1819 = load <8 x i1>, ptr %.slot189, align 1
  %1820 = select <8 x i1> %1801, <8 x i1> %1818, <8 x i1> %1819
  store <8 x i1> %1820, ptr %.slot189, align 1
  %1821 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1803)
  %1822 = bitcast <8 x i1> %1803 to i8
  %1823 = call i8 @llvm.cttz.i8(i8 %1822, i1 false)
  %1824 = zext i8 %1823 to i32
  %1825 = select i1 %1821, i32 %1824, i32 0
  %1826 = load <8 x i1>, ptr %.slot189, align 1
  %1827 = select <8 x i1> %1803, <8 x i1> zeroinitializer, <8 x i1> %1826
  store <8 x i1> %1827, ptr %.slot189, align 1
  br label %direct.schedule.127

direct.schedule.127:                              ; preds = %direct.schedule.125
  %.spill.load556 = load <8 x i64>, ptr %.spill188, align 64
  %1828 = mul <8 x i64> %.spill.load556, splat (i64 2)
  %.spill.load557 = load <8 x i64>, ptr %.spill186, align 64
  %1829 = add <8 x i64> %1828, %.spill.load557
  %.spill.load558 = load <8 x i1>, ptr %.spill187, align 1
  %1830 = and <8 x i1> %119, %.spill.load558
  %1831 = xor <8 x i1> %.spill.load558, splat (i1 true)
  %1832 = and <8 x i1> %119, %1831
  %1833 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1830)
  %1834 = bitcast <8 x i1> %1830 to i8
  %1835 = call i8 @llvm.cttz.i8(i8 %1834, i1 false)
  %1836 = zext i8 %1835 to i32
  %1837 = select i1 %1833, i32 %1836, i32 0
  %tile_snapshot.spill.load559 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill177, align 64
  %1838 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load559, 0
  %1839 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load559, 1
  %1840 = add <8 x i64> %1839, %1829
  %1841 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1838, 0
  %1842 = insertvalue { <8 x ptr>, <8 x i64> } %1841, <8 x i64> %1840, 1
  %1843 = extractvalue { <8 x ptr>, <8 x i64> } %1842, 0
  %1844 = extractvalue { <8 x ptr>, <8 x i64> } %1842, 1
  %1845 = getelementptr i8, <8 x ptr> %1843, <8 x i64> %1844
  %1846 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1845, <8 x i1> %1830, <8 x i8> zeroinitializer)
  %1847 = icmp ne <8 x i8> %1846, zeroinitializer
  %1848 = load <8 x i1>, ptr %.slot190, align 1
  %1849 = select <8 x i1> %1830, <8 x i1> %1847, <8 x i1> %1848
  store <8 x i1> %1849, ptr %.slot190, align 1
  %1850 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1832)
  %1851 = bitcast <8 x i1> %1832 to i8
  %1852 = call i8 @llvm.cttz.i8(i8 %1851, i1 false)
  %1853 = zext i8 %1852 to i32
  %1854 = select i1 %1850, i32 %1853, i32 0
  %1855 = load <8 x i1>, ptr %.slot190, align 1
  %1856 = select <8 x i1> %1832, <8 x i1> zeroinitializer, <8 x i1> %1855
  store <8 x i1> %1856, ptr %.slot190, align 1
  br label %direct.schedule.129

direct.schedule.129:                              ; preds = %direct.schedule.127
  %.state560 = load <8 x i1>, ptr %.slot189, align 1
  %.state561 = load <8 x i1>, ptr %.slot190, align 1
  %1857 = and <8 x i1> %.state560, %.state561
  %.spill.load562 = load <8 x i1>, ptr %.spill187, align 1
  %1858 = and <8 x i1> %119, %.spill.load562
  %1859 = xor <8 x i1> %.spill.load562, splat (i1 true)
  %1860 = and <8 x i1> %119, %1859
  %1861 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1858)
  %1862 = bitcast <8 x i1> %1858 to i8
  %1863 = call i8 @llvm.cttz.i8(i8 %1862, i1 false)
  %1864 = zext i8 %1863 to i32
  %1865 = select i1 %1861, i32 %1864, i32 0
  %tile_snapshot.spill.load563 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill184, align 64
  %1866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load563, 0
  %1867 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load563, 1
  %.state564 = load <8 x i64>, ptr %.slot185, align 64
  %1868 = add <8 x i64> %1867, %.state564
  %1869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1866, 0
  %1870 = insertvalue { <8 x ptr>, <8 x i64> } %1869, <8 x i64> %1868, 1
  %1871 = extractvalue { <8 x ptr>, <8 x i64> } %1870, 0
  %1872 = extractvalue { <8 x ptr>, <8 x i64> } %1870, 1
  %1873 = getelementptr i8, <8 x ptr> %1871, <8 x i64> %1872
  %1874 = zext <8 x i1> %1857 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1874, <8 x ptr> align 1 %1873, <8 x i1> %1858)
  %1875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1860)
  %1876 = bitcast <8 x i1> %1860 to i8
  %1877 = call i8 @llvm.cttz.i8(i8 %1876, i1 false)
  %1878 = zext i8 %1877 to i32
  %1879 = select i1 %1875, i32 %1878, i32 0
  br label %direct.schedule.131

direct.schedule.131:                              ; preds = %direct.schedule.129
  %.state565 = load <8 x i64>, ptr %.slot185, align 64
  %1880 = add <8 x i64> %.state565, splat (i64 1)
  %1881 = load <8 x i64>, ptr %.slot185, align 64
  %1882 = select <8 x i1> %119, <8 x i64> %1880, <8 x i64> %1881
  store <8 x i64> %1882, ptr %.slot185, align 64
  br label %direct.schedule.124

direct.schedule.132:                              ; preds = %direct.false551
  %1883 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill191, align 64
  %1884 = extractvalue { <8 x ptr>, <8 x i64> } %45, 0
  %1885 = extractvalue { <8 x ptr>, <8 x i64> } %1883, 0
  %1886 = select <8 x i1> %119, <8 x ptr> %1884, <8 x ptr> %1885
  %1887 = extractvalue { <8 x ptr>, <8 x i64> } %45, 1
  %1888 = extractvalue { <8 x ptr>, <8 x i64> } %1883, 1
  %1889 = select <8 x i1> %119, <8 x i64> %1887, <8 x i64> %1888
  %1890 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1886, 0
  %1891 = insertvalue { <8 x ptr>, <8 x i64> } %1890, <8 x i64> %1889, 1
  store { <8 x ptr>, <8 x i64> } %1891, ptr %tile_snapshot.spill191, align 64
  %1892 = load <8 x i64>, ptr %.slot192, align 64
  %1893 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1892
  store <8 x i64> %1893, ptr %.slot192, align 64
  br label %direct.schedule.133

direct.schedule.133:                              ; preds = %direct.schedule.140, %direct.schedule.132
  %.state566 = load <8 x i64>, ptr %.slot192, align 64
  %1894 = icmp slt <8 x i64> %.state566, splat (i64 10)
  %1895 = extractelement <8 x i1> %1894, i32 0
  br i1 %1895, label %direct.true567, label %direct.false568

direct.schedule.134:                              ; preds = %direct.true567
  %.state569 = load <8 x i64>, ptr %.slot192, align 64
  %1896 = select <8 x i1> %119, <8 x i64> %.state569, <8 x i64> zeroinitializer
  %1897 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1898 = srem <8 x i64> %1896, %1897
  %1899 = load <8 x i64>, ptr %.spill193, align 64
  %1900 = select <8 x i1> %119, <8 x i64> %1898, <8 x i64> %1899
  store <8 x i64> %1900, ptr %.spill193, align 64
  %.state570 = load <8 x i64>, ptr %.slot192, align 64
  %1901 = select <8 x i1> %119, <8 x i64> %.state570, <8 x i64> zeroinitializer
  %1902 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1903 = sdiv <8 x i64> %1901, %1902
  %1904 = mul <8 x i64> %1898, splat (i64 8)
  %.spill.load571 = load <8 x i64>, ptr %.spill, align 64
  %1905 = add <8 x i64> %1904, %.spill.load571
  %1906 = icmp slt <8 x i64> %1905, splat (i64 33)
  %1907 = load <8 x i1>, ptr %.spill194, align 1
  %1908 = select <8 x i1> %119, <8 x i1> %1906, <8 x i1> %1907
  store <8 x i1> %1908, ptr %.spill194, align 1
  %1909 = select <8 x i1> %119, <8 x i64> %1903, <8 x i64> zeroinitializer
  %1910 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1911 = srem <8 x i64> %1909, %1910
  %1912 = load <8 x i64>, ptr %.spill195, align 64
  %1913 = select <8 x i1> %119, <8 x i64> %1911, <8 x i64> %1912
  store <8 x i64> %1913, ptr %.spill195, align 64
  store i64 0, ptr %.spill196, align 4
  %1914 = add <8 x i64> zeroinitializer, %1898
  %1915 = mul <8 x i64> %1914, splat (i64 2)
  %1916 = add <8 x i64> %1915, %1911
  %1917 = and <8 x i1> %119, %1906
  %1918 = xor <8 x i1> %1906, splat (i1 true)
  %1919 = and <8 x i1> %119, %1918
  %1920 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1917)
  %1921 = bitcast <8 x i1> %1917 to i8
  %1922 = call i8 @llvm.cttz.i8(i8 %1921, i1 false)
  %1923 = zext i8 %1922 to i32
  %1924 = select i1 %1920, i32 %1923, i32 0
  %tile_snapshot.spill.load572 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill184, align 64
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load572, 0
  %1926 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load572, 1
  %1927 = add <8 x i64> %1926, %1916
  %1928 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1925, 0
  %1929 = insertvalue { <8 x ptr>, <8 x i64> } %1928, <8 x i64> %1927, 1
  %1930 = extractvalue { <8 x ptr>, <8 x i64> } %1929, 0
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %1929, 1
  %1932 = getelementptr i8, <8 x ptr> %1930, <8 x i64> %1931
  %1933 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1932, <8 x i1> %1917, <8 x i8> zeroinitializer)
  %1934 = icmp ne <8 x i8> %1933, zeroinitializer
  %1935 = load <8 x i1>, ptr %.slot197, align 1
  %1936 = select <8 x i1> %1917, <8 x i1> %1934, <8 x i1> %1935
  store <8 x i1> %1936, ptr %.slot197, align 1
  %1937 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1919)
  %1938 = bitcast <8 x i1> %1919 to i8
  %1939 = call i8 @llvm.cttz.i8(i8 %1938, i1 false)
  %1940 = zext i8 %1939 to i32
  %1941 = select i1 %1937, i32 %1940, i32 0
  %1942 = load <8 x i1>, ptr %.slot197, align 1
  %1943 = select <8 x i1> %1919, <8 x i1> zeroinitializer, <8 x i1> %1942
  store <8 x i1> %1943, ptr %.slot197, align 1
  br label %direct.schedule.136

direct.schedule.136:                              ; preds = %direct.schedule.134
  %.spill.load573 = load i64, ptr %.spill196, align 4
  %1944 = add i64 %.spill.load573, 0
  %1945 = mul i64 %1944, 1
  %1946 = add i64 %1945, 0
  %1947 = mul i64 %1946, 2
  %.splatinsert574 = insertelement <8 x i64> poison, i64 %1947, i64 0
  %.splat575 = shufflevector <8 x i64> %.splatinsert574, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load576 = load <8 x i64>, ptr %.spill195, align 64
  %1948 = add <8 x i64> %.splat575, %.spill.load576
  %1949 = mul <8 x i64> %1948, splat (i64 5)
  %.spill.load577 = load <8 x i64>, ptr %.spill193, align 64
  %1950 = add <8 x i64> %1949, %.spill.load577
  %.spill.load578 = load <8 x i1>, ptr %.spill194, align 1
  %1951 = and <8 x i1> %119, %.spill.load578
  %1952 = xor <8 x i1> %.spill.load578, splat (i1 true)
  %1953 = and <8 x i1> %119, %1952
  %1954 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1951)
  %1955 = bitcast <8 x i1> %1951 to i8
  %1956 = call i8 @llvm.cttz.i8(i8 %1955, i1 false)
  %1957 = zext i8 %1956 to i32
  %1958 = select i1 %1954, i32 %1957, i32 0
  %tile_snapshot.spill.load579 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %1959 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load579, 0
  %1960 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load579, 1
  %1961 = mul <8 x i64> %1950, splat (i64 32)
  %1962 = add <8 x i64> %1960, %1961
  %1963 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1959, 0
  %1964 = insertvalue { <8 x ptr>, <8 x i64> } %1963, <8 x i64> %1962, 1
  %1965 = extractvalue { <8 x ptr>, <8 x i64> } %1964, 0
  %1966 = extractvalue { <8 x ptr>, <8 x i64> } %1964, 1
  %1967 = getelementptr i8, <8 x ptr> %1965, <8 x i64> %1966
  %1968 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1967, <8 x i1> %1951, <8 x float> zeroinitializer)
  %1969 = load <8 x float>, ptr %.slot198, align 32
  %1970 = select <8 x i1> %1951, <8 x float> %1968, <8 x float> %1969
  store <8 x float> %1970, ptr %.slot198, align 32
  %1971 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1953)
  %1972 = bitcast <8 x i1> %1953 to i8
  %1973 = call i8 @llvm.cttz.i8(i8 %1972, i1 false)
  %1974 = zext i8 %1973 to i32
  %1975 = select i1 %1971, i32 %1974, i32 0
  %1976 = load <8 x float>, ptr %.slot198, align 32
  %1977 = select <8 x i1> %1953, <8 x float> zeroinitializer, <8 x float> %1976
  store <8 x float> %1977, ptr %.slot198, align 32
  br label %direct.schedule.138

direct.schedule.138:                              ; preds = %direct.schedule.136
  %.state580 = load <8 x float>, ptr %.slot198, align 32
  %.state581 = load <8 x i1>, ptr %.slot197, align 1
  %1978 = select <8 x i1> %.state581, <8 x float> %.state580, <8 x float> splat (float 0xC6293E5940000000)
  %.spill.load582 = load <8 x i1>, ptr %.spill194, align 1
  %1979 = and <8 x i1> %119, %.spill.load582
  %1980 = xor <8 x i1> %.spill.load582, splat (i1 true)
  %1981 = and <8 x i1> %119, %1980
  %1982 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1979)
  %1983 = bitcast <8 x i1> %1979 to i8
  %1984 = call i8 @llvm.cttz.i8(i8 %1983, i1 false)
  %1985 = zext i8 %1984 to i32
  %1986 = select i1 %1982, i32 %1985, i32 0
  %tile_snapshot.spill.load583 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill191, align 64
  %1987 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load583, 0
  %1988 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load583, 1
  %.state584 = load <8 x i64>, ptr %.slot192, align 64
  %1989 = mul <8 x i64> %.state584, splat (i64 32)
  %1990 = add <8 x i64> %1988, %1989
  %1991 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1987, 0
  %1992 = insertvalue { <8 x ptr>, <8 x i64> } %1991, <8 x i64> %1990, 1
  %1993 = extractvalue { <8 x ptr>, <8 x i64> } %1992, 0
  %1994 = extractvalue { <8 x ptr>, <8 x i64> } %1992, 1
  %1995 = getelementptr i8, <8 x ptr> %1993, <8 x i64> %1994
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1978, <8 x ptr> align 1 %1995, <8 x i1> %1979)
  %1996 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1981)
  %1997 = bitcast <8 x i1> %1981 to i8
  %1998 = call i8 @llvm.cttz.i8(i8 %1997, i1 false)
  %1999 = zext i8 %1998 to i32
  %2000 = select i1 %1996, i32 %1999, i32 0
  br label %direct.schedule.140

direct.schedule.140:                              ; preds = %direct.schedule.138
  %.state585 = load <8 x i64>, ptr %.slot192, align 64
  %2001 = add <8 x i64> %.state585, splat (i64 1)
  %2002 = load <8 x i64>, ptr %.slot192, align 64
  %2003 = select <8 x i1> %119, <8 x i64> %2001, <8 x i64> %2002
  store <8 x i64> %2003, ptr %.slot192, align 64
  br label %direct.schedule.133

direct.schedule.141:                              ; preds = %direct.false568
  %2004 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill199, align 64
  %2005 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %2006 = extractvalue { <8 x ptr>, <8 x i64> } %2004, 0
  %2007 = select <8 x i1> %119, <8 x ptr> %2005, <8 x ptr> %2006
  %2008 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %2009 = extractvalue { <8 x ptr>, <8 x i64> } %2004, 1
  %2010 = select <8 x i1> %119, <8 x i64> %2008, <8 x i64> %2009
  %2011 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2007, 0
  %2012 = insertvalue { <8 x ptr>, <8 x i64> } %2011, <8 x i64> %2010, 1
  store { <8 x ptr>, <8 x i64> } %2012, ptr %tile_snapshot.spill199, align 64
  %2013 = load <8 x i64>, ptr %.slot200, align 64
  %2014 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %2013
  store <8 x i64> %2014, ptr %.slot200, align 64
  br label %direct.schedule.142

direct.schedule.142:                              ; preds = %direct.schedule.148, %direct.schedule.141
  %.state586 = load <8 x i64>, ptr %.slot200, align 64
  %2015 = icmp slt <8 x i64> %.state586, splat (i64 2)
  %2016 = extractelement <8 x i1> %2015, i32 0
  br i1 %2016, label %direct.true587, label %direct.false588

direct.schedule.143:                              ; preds = %direct.true587
  %.state589 = load <8 x i64>, ptr %.slot200, align 64
  %2017 = select <8 x i1> %119, <8 x i64> %.state589, <8 x i64> zeroinitializer
  %2018 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %2019 = srem <8 x i64> %2017, %2018
  %.state590 = load <8 x i64>, ptr %.slot200, align 64
  %2020 = select <8 x i1> %119, <8 x i64> %.state590, <8 x i64> zeroinitializer
  %2021 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %2022 = sdiv <8 x i64> %2020, %2021
  %2023 = select <8 x i1> %119, <8 x i64> %2022, <8 x i64> zeroinitializer
  %2024 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2025 = srem <8 x i64> %2023, %2024
  %2026 = select <8 x i1> %119, <8 x i64> %2022, <8 x i64> zeroinitializer
  %2027 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2028 = sdiv <8 x i64> %2026, %2027
  %2029 = select <8 x i1> %119, <8 x i64> %2028, <8 x i64> zeroinitializer
  %2030 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2031 = srem <8 x i64> %2029, %2030
  %2032 = add <8 x i64> zeroinitializer, %2031
  %2033 = mul <8 x i64> %2032, splat (i64 1)
  %2034 = add <8 x i64> %2033, %2025
  %2035 = mul <8 x i64> %2034, splat (i64 2)
  %2036 = add <8 x i64> %2035, %2019
  %2037 = load <8 x i64>, ptr %.spill201, align 64
  %2038 = select <8 x i1> %119, <8 x i64> %2036, <8 x i64> %2037
  store <8 x i64> %2038, ptr %.spill201, align 64
  %2039 = load <8 x i64>, ptr %.slot202, align 64
  %2040 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %2039
  store <8 x i64> %2040, ptr %.slot202, align 64
  %2041 = load <8 x float>, ptr %.slot203, align 32
  %2042 = select <8 x i1> %119, <8 x float> zeroinitializer, <8 x float> %2041
  store <8 x float> %2042, ptr %.slot203, align 32
  %2043 = load <8 x i1>, ptr %.slot204, align 1
  %2044 = select <8 x i1> %119, <8 x i1> zeroinitializer, <8 x i1> %2043
  store <8 x i1> %2044, ptr %.slot204, align 1
  br label %direct.schedule.144

direct.schedule.144:                              ; preds = %direct.schedule.147, %direct.schedule.143
  %.state591 = load <8 x i64>, ptr %.slot202, align 64
  %2045 = icmp slt <8 x i64> %.state591, splat (i64 5)
  %2046 = extractelement <8 x i1> %2045, i32 0
  br i1 %2046, label %direct.true592, label %direct.false593

direct.schedule.145:                              ; preds = %direct.true592
  %.state594 = load <8 x i64>, ptr %.slot202, align 64
  %2047 = select <8 x i1> %119, <8 x i64> %.state594, <8 x i64> zeroinitializer
  %2048 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %2049 = srem <8 x i64> %2047, %2048
  %2050 = mul <8 x i64> %2049, splat (i64 8)
  %.spill.load595 = load <8 x i64>, ptr %.spill, align 64
  %2051 = add <8 x i64> %2050, %.spill.load595
  %2052 = icmp slt <8 x i64> %2051, splat (i64 33)
  %2053 = load <8 x i1>, ptr %.spill205, align 1
  %2054 = select <8 x i1> %119, <8 x i1> %2052, <8 x i1> %2053
  store <8 x i1> %2054, ptr %.spill205, align 1
  %.spill.load596 = load <8 x i64>, ptr %.spill201, align 64
  %2055 = mul <8 x i64> %.spill.load596, splat (i64 5)
  %2056 = add <8 x i64> %2055, %2049
  %2057 = and <8 x i1> %119, %2052
  %2058 = xor <8 x i1> %2052, splat (i1 true)
  %2059 = and <8 x i1> %119, %2058
  %2060 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2057)
  %2061 = bitcast <8 x i1> %2057 to i8
  %2062 = call i8 @llvm.cttz.i8(i8 %2061, i1 false)
  %2063 = zext i8 %2062 to i32
  %2064 = select i1 %2060, i32 %2063, i32 0
  %tile_snapshot.spill.load597 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill191, align 64
  %2065 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load597, 0
  %2066 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load597, 1
  %2067 = mul <8 x i64> %2056, splat (i64 32)
  %2068 = add <8 x i64> %2066, %2067
  %2069 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2065, 0
  %2070 = insertvalue { <8 x ptr>, <8 x i64> } %2069, <8 x i64> %2068, 1
  %2071 = extractvalue { <8 x ptr>, <8 x i64> } %2070, 0
  %2072 = extractvalue { <8 x ptr>, <8 x i64> } %2070, 1
  %2073 = getelementptr i8, <8 x ptr> %2071, <8 x i64> %2072
  %2074 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2073, <8 x i1> %2057, <8 x float> zeroinitializer)
  %2075 = load <8 x float>, ptr %.slot206, align 32
  %2076 = select <8 x i1> %2057, <8 x float> %2074, <8 x float> %2075
  store <8 x float> %2076, ptr %.slot206, align 32
  %2077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2059)
  %2078 = bitcast <8 x i1> %2059 to i8
  %2079 = call i8 @llvm.cttz.i8(i8 %2078, i1 false)
  %2080 = zext i8 %2079 to i32
  %2081 = select i1 %2077, i32 %2080, i32 0
  %2082 = load <8 x float>, ptr %.slot206, align 32
  %2083 = select <8 x i1> %2059, <8 x float> zeroinitializer, <8 x float> %2082
  store <8 x float> %2083, ptr %.slot206, align 32
  br label %direct.schedule.147

direct.schedule.147:                              ; preds = %direct.schedule.145
  %.state598 = load <8 x float>, ptr %.slot203, align 32
  %.state599 = load <8 x float>, ptr %.slot206, align 32
  %2084 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state598, <8 x float> %.state599)
  %.state600 = load <8 x float>, ptr %.slot206, align 32
  %.state601 = load <8 x i1>, ptr %.slot204, align 1
  %2085 = select <8 x i1> %.state601, <8 x float> %2084, <8 x float> %.state600
  %.state602 = load <8 x float>, ptr %.slot203, align 32
  %.spill.load603 = load <8 x i1>, ptr %.spill205, align 1
  %2086 = select <8 x i1> %.spill.load603, <8 x float> %2085, <8 x float> %.state602
  %.state604 = load <8 x i1>, ptr %.slot204, align 1
  %.spill.load605 = load <8 x i1>, ptr %.spill205, align 1
  %2087 = or <8 x i1> %.state604, %.spill.load605
  %.state606 = load <8 x i64>, ptr %.slot202, align 64
  %2088 = add <8 x i64> %.state606, splat (i64 1)
  %2089 = load <8 x i64>, ptr %.slot202, align 64
  %2090 = select <8 x i1> %119, <8 x i64> %2088, <8 x i64> %2089
  store <8 x i64> %2090, ptr %.slot202, align 64
  %2091 = load <8 x float>, ptr %.slot203, align 32
  %2092 = select <8 x i1> %119, <8 x float> %2086, <8 x float> %2091
  store <8 x float> %2092, ptr %.slot203, align 32
  %2093 = load <8 x i1>, ptr %.slot204, align 1
  %2094 = select <8 x i1> %119, <8 x i1> %2087, <8 x i1> %2093
  store <8 x i1> %2094, ptr %.slot204, align 1
  br label %direct.schedule.144

direct.schedule.148:                              ; preds = %direct.false593
  %.spill.load607 = load <8 x i64>, ptr %.spill, align 64
  %2095 = trunc <8 x i64> %.spill.load607 to <8 x i32>
  %2096 = xor <8 x i32> %2095, splat (i32 1)
  %.state608 = load <8 x float>, ptr %.slot203, align 32
  %2097 = extractelement <8 x i32> %2096, i64 0
  %2098 = icmp ult i32 %2097, 8
  %2099 = select i1 %2098, i32 %2097, i32 0
  %2100 = extractelement <8 x i1> %119, i32 %2099
  %2101 = extractelement <8 x i1> %119, i64 0
  %2102 = and i1 %2098, %2100
  %2103 = and i1 %2101, %2102
  %2104 = extractelement <8 x float> %.state608, i32 %2099
  %2105 = select i1 %2103, float %2104, float 0.000000e+00
  %2106 = insertelement <8 x float> poison, float %2105, i64 0
  %2107 = xor i1 %2103, true
  %2108 = and i1 %2101, %2107
  %2109 = insertelement <8 x i1> poison, i1 %2108, i64 0
  %2110 = extractelement <8 x i32> %2096, i64 1
  %2111 = icmp ult i32 %2110, 8
  %2112 = select i1 %2111, i32 %2110, i32 0
  %2113 = extractelement <8 x i1> %119, i32 %2112
  %2114 = extractelement <8 x i1> %119, i64 1
  %2115 = and i1 %2111, %2113
  %2116 = and i1 %2114, %2115
  %2117 = extractelement <8 x float> %.state608, i32 %2112
  %2118 = select i1 %2116, float %2117, float 0.000000e+00
  %2119 = insertelement <8 x float> %2106, float %2118, i64 1
  %2120 = xor i1 %2116, true
  %2121 = and i1 %2114, %2120
  %2122 = insertelement <8 x i1> %2109, i1 %2121, i64 1
  %2123 = extractelement <8 x i32> %2096, i64 2
  %2124 = icmp ult i32 %2123, 8
  %2125 = select i1 %2124, i32 %2123, i32 0
  %2126 = extractelement <8 x i1> %119, i32 %2125
  %2127 = extractelement <8 x i1> %119, i64 2
  %2128 = and i1 %2124, %2126
  %2129 = and i1 %2127, %2128
  %2130 = extractelement <8 x float> %.state608, i32 %2125
  %2131 = select i1 %2129, float %2130, float 0.000000e+00
  %2132 = insertelement <8 x float> %2119, float %2131, i64 2
  %2133 = xor i1 %2129, true
  %2134 = and i1 %2127, %2133
  %2135 = insertelement <8 x i1> %2122, i1 %2134, i64 2
  %2136 = extractelement <8 x i32> %2096, i64 3
  %2137 = icmp ult i32 %2136, 8
  %2138 = select i1 %2137, i32 %2136, i32 0
  %2139 = extractelement <8 x i1> %119, i32 %2138
  %2140 = extractelement <8 x i1> %119, i64 3
  %2141 = and i1 %2137, %2139
  %2142 = and i1 %2140, %2141
  %2143 = extractelement <8 x float> %.state608, i32 %2138
  %2144 = select i1 %2142, float %2143, float 0.000000e+00
  %2145 = insertelement <8 x float> %2132, float %2144, i64 3
  %2146 = xor i1 %2142, true
  %2147 = and i1 %2140, %2146
  %2148 = insertelement <8 x i1> %2135, i1 %2147, i64 3
  %2149 = extractelement <8 x i32> %2096, i64 4
  %2150 = icmp ult i32 %2149, 8
  %2151 = select i1 %2150, i32 %2149, i32 0
  %2152 = extractelement <8 x i1> %119, i32 %2151
  %2153 = extractelement <8 x i1> %119, i64 4
  %2154 = and i1 %2150, %2152
  %2155 = and i1 %2153, %2154
  %2156 = extractelement <8 x float> %.state608, i32 %2151
  %2157 = select i1 %2155, float %2156, float 0.000000e+00
  %2158 = insertelement <8 x float> %2145, float %2157, i64 4
  %2159 = xor i1 %2155, true
  %2160 = and i1 %2153, %2159
  %2161 = insertelement <8 x i1> %2148, i1 %2160, i64 4
  %2162 = extractelement <8 x i32> %2096, i64 5
  %2163 = icmp ult i32 %2162, 8
  %2164 = select i1 %2163, i32 %2162, i32 0
  %2165 = extractelement <8 x i1> %119, i32 %2164
  %2166 = extractelement <8 x i1> %119, i64 5
  %2167 = and i1 %2163, %2165
  %2168 = and i1 %2166, %2167
  %2169 = extractelement <8 x float> %.state608, i32 %2164
  %2170 = select i1 %2168, float %2169, float 0.000000e+00
  %2171 = insertelement <8 x float> %2158, float %2170, i64 5
  %2172 = xor i1 %2168, true
  %2173 = and i1 %2166, %2172
  %2174 = insertelement <8 x i1> %2161, i1 %2173, i64 5
  %2175 = extractelement <8 x i32> %2096, i64 6
  %2176 = icmp ult i32 %2175, 8
  %2177 = select i1 %2176, i32 %2175, i32 0
  %2178 = extractelement <8 x i1> %119, i32 %2177
  %2179 = extractelement <8 x i1> %119, i64 6
  %2180 = and i1 %2176, %2178
  %2181 = and i1 %2179, %2180
  %2182 = extractelement <8 x float> %.state608, i32 %2177
  %2183 = select i1 %2181, float %2182, float 0.000000e+00
  %2184 = insertelement <8 x float> %2171, float %2183, i64 6
  %2185 = xor i1 %2181, true
  %2186 = and i1 %2179, %2185
  %2187 = insertelement <8 x i1> %2174, i1 %2186, i64 6
  %2188 = extractelement <8 x i32> %2096, i64 7
  %2189 = icmp ult i32 %2188, 8
  %2190 = select i1 %2189, i32 %2188, i32 0
  %2191 = extractelement <8 x i1> %119, i32 %2190
  %2192 = extractelement <8 x i1> %119, i64 7
  %2193 = and i1 %2189, %2191
  %2194 = and i1 %2192, %2193
  %2195 = extractelement <8 x float> %.state608, i32 %2190
  %2196 = select i1 %2194, float %2195, float 0.000000e+00
  %2197 = insertelement <8 x float> %2184, float %2196, i64 7
  %2198 = xor i1 %2194, true
  %2199 = and i1 %2192, %2198
  %2200 = insertelement <8 x i1> %2187, i1 %2199, i64 7
  %.state609 = load <8 x float>, ptr %.slot203, align 32
  %2201 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state609, <8 x float> %2197)
  %.state610 = load <8 x i1>, ptr %.slot204, align 1
  %2202 = zext <8 x i1> %.state610 to <8 x i32>
  %2203 = extractelement <8 x i32> %2096, i64 0
  %2204 = icmp ult i32 %2203, 8
  %2205 = select i1 %2204, i32 %2203, i32 0
  %2206 = extractelement <8 x i1> %119, i32 %2205
  %2207 = extractelement <8 x i1> %119, i64 0
  %2208 = and i1 %2204, %2206
  %2209 = and i1 %2207, %2208
  %2210 = extractelement <8 x i32> %2202, i32 %2205
  %2211 = select i1 %2209, i32 %2210, i32 0
  %2212 = insertelement <8 x i32> poison, i32 %2211, i64 0
  %2213 = xor i1 %2209, true
  %2214 = and i1 %2207, %2213
  %2215 = insertelement <8 x i1> poison, i1 %2214, i64 0
  %2216 = extractelement <8 x i32> %2096, i64 1
  %2217 = icmp ult i32 %2216, 8
  %2218 = select i1 %2217, i32 %2216, i32 0
  %2219 = extractelement <8 x i1> %119, i32 %2218
  %2220 = extractelement <8 x i1> %119, i64 1
  %2221 = and i1 %2217, %2219
  %2222 = and i1 %2220, %2221
  %2223 = extractelement <8 x i32> %2202, i32 %2218
  %2224 = select i1 %2222, i32 %2223, i32 0
  %2225 = insertelement <8 x i32> %2212, i32 %2224, i64 1
  %2226 = xor i1 %2222, true
  %2227 = and i1 %2220, %2226
  %2228 = insertelement <8 x i1> %2215, i1 %2227, i64 1
  %2229 = extractelement <8 x i32> %2096, i64 2
  %2230 = icmp ult i32 %2229, 8
  %2231 = select i1 %2230, i32 %2229, i32 0
  %2232 = extractelement <8 x i1> %119, i32 %2231
  %2233 = extractelement <8 x i1> %119, i64 2
  %2234 = and i1 %2230, %2232
  %2235 = and i1 %2233, %2234
  %2236 = extractelement <8 x i32> %2202, i32 %2231
  %2237 = select i1 %2235, i32 %2236, i32 0
  %2238 = insertelement <8 x i32> %2225, i32 %2237, i64 2
  %2239 = xor i1 %2235, true
  %2240 = and i1 %2233, %2239
  %2241 = insertelement <8 x i1> %2228, i1 %2240, i64 2
  %2242 = extractelement <8 x i32> %2096, i64 3
  %2243 = icmp ult i32 %2242, 8
  %2244 = select i1 %2243, i32 %2242, i32 0
  %2245 = extractelement <8 x i1> %119, i32 %2244
  %2246 = extractelement <8 x i1> %119, i64 3
  %2247 = and i1 %2243, %2245
  %2248 = and i1 %2246, %2247
  %2249 = extractelement <8 x i32> %2202, i32 %2244
  %2250 = select i1 %2248, i32 %2249, i32 0
  %2251 = insertelement <8 x i32> %2238, i32 %2250, i64 3
  %2252 = xor i1 %2248, true
  %2253 = and i1 %2246, %2252
  %2254 = insertelement <8 x i1> %2241, i1 %2253, i64 3
  %2255 = extractelement <8 x i32> %2096, i64 4
  %2256 = icmp ult i32 %2255, 8
  %2257 = select i1 %2256, i32 %2255, i32 0
  %2258 = extractelement <8 x i1> %119, i32 %2257
  %2259 = extractelement <8 x i1> %119, i64 4
  %2260 = and i1 %2256, %2258
  %2261 = and i1 %2259, %2260
  %2262 = extractelement <8 x i32> %2202, i32 %2257
  %2263 = select i1 %2261, i32 %2262, i32 0
  %2264 = insertelement <8 x i32> %2251, i32 %2263, i64 4
  %2265 = xor i1 %2261, true
  %2266 = and i1 %2259, %2265
  %2267 = insertelement <8 x i1> %2254, i1 %2266, i64 4
  %2268 = extractelement <8 x i32> %2096, i64 5
  %2269 = icmp ult i32 %2268, 8
  %2270 = select i1 %2269, i32 %2268, i32 0
  %2271 = extractelement <8 x i1> %119, i32 %2270
  %2272 = extractelement <8 x i1> %119, i64 5
  %2273 = and i1 %2269, %2271
  %2274 = and i1 %2272, %2273
  %2275 = extractelement <8 x i32> %2202, i32 %2270
  %2276 = select i1 %2274, i32 %2275, i32 0
  %2277 = insertelement <8 x i32> %2264, i32 %2276, i64 5
  %2278 = xor i1 %2274, true
  %2279 = and i1 %2272, %2278
  %2280 = insertelement <8 x i1> %2267, i1 %2279, i64 5
  %2281 = extractelement <8 x i32> %2096, i64 6
  %2282 = icmp ult i32 %2281, 8
  %2283 = select i1 %2282, i32 %2281, i32 0
  %2284 = extractelement <8 x i1> %119, i32 %2283
  %2285 = extractelement <8 x i1> %119, i64 6
  %2286 = and i1 %2282, %2284
  %2287 = and i1 %2285, %2286
  %2288 = extractelement <8 x i32> %2202, i32 %2283
  %2289 = select i1 %2287, i32 %2288, i32 0
  %2290 = insertelement <8 x i32> %2277, i32 %2289, i64 6
  %2291 = xor i1 %2287, true
  %2292 = and i1 %2285, %2291
  %2293 = insertelement <8 x i1> %2280, i1 %2292, i64 6
  %2294 = extractelement <8 x i32> %2096, i64 7
  %2295 = icmp ult i32 %2294, 8
  %2296 = select i1 %2295, i32 %2294, i32 0
  %2297 = extractelement <8 x i1> %119, i32 %2296
  %2298 = extractelement <8 x i1> %119, i64 7
  %2299 = and i1 %2295, %2297
  %2300 = and i1 %2298, %2299
  %2301 = extractelement <8 x i32> %2202, i32 %2296
  %2302 = select i1 %2300, i32 %2301, i32 0
  %2303 = insertelement <8 x i32> %2290, i32 %2302, i64 7
  %2304 = xor i1 %2300, true
  %2305 = and i1 %2298, %2304
  %2306 = insertelement <8 x i1> %2293, i1 %2305, i64 7
  %2307 = icmp ne <8 x i32> %2303, zeroinitializer
  %.state611 = load <8 x float>, ptr %.slot203, align 32
  %.state612 = load <8 x i1>, ptr %.slot204, align 1
  %2308 = select <8 x i1> %.state612, <8 x float> %.state611, <8 x float> %2197
  %.state613 = load <8 x i1>, ptr %.slot204, align 1
  %2309 = and <8 x i1> %.state613, %2307
  %2310 = select <8 x i1> %2309, <8 x float> %2201, <8 x float> %2308
  %.state614 = load <8 x i1>, ptr %.slot204, align 1
  %2311 = or <8 x i1> %.state614, %2307
  %2312 = xor <8 x i32> %2095, splat (i32 2)
  %2313 = extractelement <8 x i32> %2312, i64 0
  %2314 = icmp ult i32 %2313, 8
  %2315 = select i1 %2314, i32 %2313, i32 0
  %2316 = extractelement <8 x i1> %119, i32 %2315
  %2317 = extractelement <8 x i1> %119, i64 0
  %2318 = and i1 %2314, %2316
  %2319 = and i1 %2317, %2318
  %2320 = extractelement <8 x float> %2310, i32 %2315
  %2321 = select i1 %2319, float %2320, float 0.000000e+00
  %2322 = insertelement <8 x float> poison, float %2321, i64 0
  %2323 = xor i1 %2319, true
  %2324 = and i1 %2317, %2323
  %2325 = insertelement <8 x i1> poison, i1 %2324, i64 0
  %2326 = extractelement <8 x i32> %2312, i64 1
  %2327 = icmp ult i32 %2326, 8
  %2328 = select i1 %2327, i32 %2326, i32 0
  %2329 = extractelement <8 x i1> %119, i32 %2328
  %2330 = extractelement <8 x i1> %119, i64 1
  %2331 = and i1 %2327, %2329
  %2332 = and i1 %2330, %2331
  %2333 = extractelement <8 x float> %2310, i32 %2328
  %2334 = select i1 %2332, float %2333, float 0.000000e+00
  %2335 = insertelement <8 x float> %2322, float %2334, i64 1
  %2336 = xor i1 %2332, true
  %2337 = and i1 %2330, %2336
  %2338 = insertelement <8 x i1> %2325, i1 %2337, i64 1
  %2339 = extractelement <8 x i32> %2312, i64 2
  %2340 = icmp ult i32 %2339, 8
  %2341 = select i1 %2340, i32 %2339, i32 0
  %2342 = extractelement <8 x i1> %119, i32 %2341
  %2343 = extractelement <8 x i1> %119, i64 2
  %2344 = and i1 %2340, %2342
  %2345 = and i1 %2343, %2344
  %2346 = extractelement <8 x float> %2310, i32 %2341
  %2347 = select i1 %2345, float %2346, float 0.000000e+00
  %2348 = insertelement <8 x float> %2335, float %2347, i64 2
  %2349 = xor i1 %2345, true
  %2350 = and i1 %2343, %2349
  %2351 = insertelement <8 x i1> %2338, i1 %2350, i64 2
  %2352 = extractelement <8 x i32> %2312, i64 3
  %2353 = icmp ult i32 %2352, 8
  %2354 = select i1 %2353, i32 %2352, i32 0
  %2355 = extractelement <8 x i1> %119, i32 %2354
  %2356 = extractelement <8 x i1> %119, i64 3
  %2357 = and i1 %2353, %2355
  %2358 = and i1 %2356, %2357
  %2359 = extractelement <8 x float> %2310, i32 %2354
  %2360 = select i1 %2358, float %2359, float 0.000000e+00
  %2361 = insertelement <8 x float> %2348, float %2360, i64 3
  %2362 = xor i1 %2358, true
  %2363 = and i1 %2356, %2362
  %2364 = insertelement <8 x i1> %2351, i1 %2363, i64 3
  %2365 = extractelement <8 x i32> %2312, i64 4
  %2366 = icmp ult i32 %2365, 8
  %2367 = select i1 %2366, i32 %2365, i32 0
  %2368 = extractelement <8 x i1> %119, i32 %2367
  %2369 = extractelement <8 x i1> %119, i64 4
  %2370 = and i1 %2366, %2368
  %2371 = and i1 %2369, %2370
  %2372 = extractelement <8 x float> %2310, i32 %2367
  %2373 = select i1 %2371, float %2372, float 0.000000e+00
  %2374 = insertelement <8 x float> %2361, float %2373, i64 4
  %2375 = xor i1 %2371, true
  %2376 = and i1 %2369, %2375
  %2377 = insertelement <8 x i1> %2364, i1 %2376, i64 4
  %2378 = extractelement <8 x i32> %2312, i64 5
  %2379 = icmp ult i32 %2378, 8
  %2380 = select i1 %2379, i32 %2378, i32 0
  %2381 = extractelement <8 x i1> %119, i32 %2380
  %2382 = extractelement <8 x i1> %119, i64 5
  %2383 = and i1 %2379, %2381
  %2384 = and i1 %2382, %2383
  %2385 = extractelement <8 x float> %2310, i32 %2380
  %2386 = select i1 %2384, float %2385, float 0.000000e+00
  %2387 = insertelement <8 x float> %2374, float %2386, i64 5
  %2388 = xor i1 %2384, true
  %2389 = and i1 %2382, %2388
  %2390 = insertelement <8 x i1> %2377, i1 %2389, i64 5
  %2391 = extractelement <8 x i32> %2312, i64 6
  %2392 = icmp ult i32 %2391, 8
  %2393 = select i1 %2392, i32 %2391, i32 0
  %2394 = extractelement <8 x i1> %119, i32 %2393
  %2395 = extractelement <8 x i1> %119, i64 6
  %2396 = and i1 %2392, %2394
  %2397 = and i1 %2395, %2396
  %2398 = extractelement <8 x float> %2310, i32 %2393
  %2399 = select i1 %2397, float %2398, float 0.000000e+00
  %2400 = insertelement <8 x float> %2387, float %2399, i64 6
  %2401 = xor i1 %2397, true
  %2402 = and i1 %2395, %2401
  %2403 = insertelement <8 x i1> %2390, i1 %2402, i64 6
  %2404 = extractelement <8 x i32> %2312, i64 7
  %2405 = icmp ult i32 %2404, 8
  %2406 = select i1 %2405, i32 %2404, i32 0
  %2407 = extractelement <8 x i1> %119, i32 %2406
  %2408 = extractelement <8 x i1> %119, i64 7
  %2409 = and i1 %2405, %2407
  %2410 = and i1 %2408, %2409
  %2411 = extractelement <8 x float> %2310, i32 %2406
  %2412 = select i1 %2410, float %2411, float 0.000000e+00
  %2413 = insertelement <8 x float> %2400, float %2412, i64 7
  %2414 = xor i1 %2410, true
  %2415 = and i1 %2408, %2414
  %2416 = insertelement <8 x i1> %2403, i1 %2415, i64 7
  %2417 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2310, <8 x float> %2413)
  %2418 = zext <8 x i1> %2311 to <8 x i32>
  %2419 = extractelement <8 x i32> %2312, i64 0
  %2420 = icmp ult i32 %2419, 8
  %2421 = select i1 %2420, i32 %2419, i32 0
  %2422 = extractelement <8 x i1> %119, i32 %2421
  %2423 = extractelement <8 x i1> %119, i64 0
  %2424 = and i1 %2420, %2422
  %2425 = and i1 %2423, %2424
  %2426 = extractelement <8 x i32> %2418, i32 %2421
  %2427 = select i1 %2425, i32 %2426, i32 0
  %2428 = insertelement <8 x i32> poison, i32 %2427, i64 0
  %2429 = xor i1 %2425, true
  %2430 = and i1 %2423, %2429
  %2431 = insertelement <8 x i1> poison, i1 %2430, i64 0
  %2432 = extractelement <8 x i32> %2312, i64 1
  %2433 = icmp ult i32 %2432, 8
  %2434 = select i1 %2433, i32 %2432, i32 0
  %2435 = extractelement <8 x i1> %119, i32 %2434
  %2436 = extractelement <8 x i1> %119, i64 1
  %2437 = and i1 %2433, %2435
  %2438 = and i1 %2436, %2437
  %2439 = extractelement <8 x i32> %2418, i32 %2434
  %2440 = select i1 %2438, i32 %2439, i32 0
  %2441 = insertelement <8 x i32> %2428, i32 %2440, i64 1
  %2442 = xor i1 %2438, true
  %2443 = and i1 %2436, %2442
  %2444 = insertelement <8 x i1> %2431, i1 %2443, i64 1
  %2445 = extractelement <8 x i32> %2312, i64 2
  %2446 = icmp ult i32 %2445, 8
  %2447 = select i1 %2446, i32 %2445, i32 0
  %2448 = extractelement <8 x i1> %119, i32 %2447
  %2449 = extractelement <8 x i1> %119, i64 2
  %2450 = and i1 %2446, %2448
  %2451 = and i1 %2449, %2450
  %2452 = extractelement <8 x i32> %2418, i32 %2447
  %2453 = select i1 %2451, i32 %2452, i32 0
  %2454 = insertelement <8 x i32> %2441, i32 %2453, i64 2
  %2455 = xor i1 %2451, true
  %2456 = and i1 %2449, %2455
  %2457 = insertelement <8 x i1> %2444, i1 %2456, i64 2
  %2458 = extractelement <8 x i32> %2312, i64 3
  %2459 = icmp ult i32 %2458, 8
  %2460 = select i1 %2459, i32 %2458, i32 0
  %2461 = extractelement <8 x i1> %119, i32 %2460
  %2462 = extractelement <8 x i1> %119, i64 3
  %2463 = and i1 %2459, %2461
  %2464 = and i1 %2462, %2463
  %2465 = extractelement <8 x i32> %2418, i32 %2460
  %2466 = select i1 %2464, i32 %2465, i32 0
  %2467 = insertelement <8 x i32> %2454, i32 %2466, i64 3
  %2468 = xor i1 %2464, true
  %2469 = and i1 %2462, %2468
  %2470 = insertelement <8 x i1> %2457, i1 %2469, i64 3
  %2471 = extractelement <8 x i32> %2312, i64 4
  %2472 = icmp ult i32 %2471, 8
  %2473 = select i1 %2472, i32 %2471, i32 0
  %2474 = extractelement <8 x i1> %119, i32 %2473
  %2475 = extractelement <8 x i1> %119, i64 4
  %2476 = and i1 %2472, %2474
  %2477 = and i1 %2475, %2476
  %2478 = extractelement <8 x i32> %2418, i32 %2473
  %2479 = select i1 %2477, i32 %2478, i32 0
  %2480 = insertelement <8 x i32> %2467, i32 %2479, i64 4
  %2481 = xor i1 %2477, true
  %2482 = and i1 %2475, %2481
  %2483 = insertelement <8 x i1> %2470, i1 %2482, i64 4
  %2484 = extractelement <8 x i32> %2312, i64 5
  %2485 = icmp ult i32 %2484, 8
  %2486 = select i1 %2485, i32 %2484, i32 0
  %2487 = extractelement <8 x i1> %119, i32 %2486
  %2488 = extractelement <8 x i1> %119, i64 5
  %2489 = and i1 %2485, %2487
  %2490 = and i1 %2488, %2489
  %2491 = extractelement <8 x i32> %2418, i32 %2486
  %2492 = select i1 %2490, i32 %2491, i32 0
  %2493 = insertelement <8 x i32> %2480, i32 %2492, i64 5
  %2494 = xor i1 %2490, true
  %2495 = and i1 %2488, %2494
  %2496 = insertelement <8 x i1> %2483, i1 %2495, i64 5
  %2497 = extractelement <8 x i32> %2312, i64 6
  %2498 = icmp ult i32 %2497, 8
  %2499 = select i1 %2498, i32 %2497, i32 0
  %2500 = extractelement <8 x i1> %119, i32 %2499
  %2501 = extractelement <8 x i1> %119, i64 6
  %2502 = and i1 %2498, %2500
  %2503 = and i1 %2501, %2502
  %2504 = extractelement <8 x i32> %2418, i32 %2499
  %2505 = select i1 %2503, i32 %2504, i32 0
  %2506 = insertelement <8 x i32> %2493, i32 %2505, i64 6
  %2507 = xor i1 %2503, true
  %2508 = and i1 %2501, %2507
  %2509 = insertelement <8 x i1> %2496, i1 %2508, i64 6
  %2510 = extractelement <8 x i32> %2312, i64 7
  %2511 = icmp ult i32 %2510, 8
  %2512 = select i1 %2511, i32 %2510, i32 0
  %2513 = extractelement <8 x i1> %119, i32 %2512
  %2514 = extractelement <8 x i1> %119, i64 7
  %2515 = and i1 %2511, %2513
  %2516 = and i1 %2514, %2515
  %2517 = extractelement <8 x i32> %2418, i32 %2512
  %2518 = select i1 %2516, i32 %2517, i32 0
  %2519 = insertelement <8 x i32> %2506, i32 %2518, i64 7
  %2520 = xor i1 %2516, true
  %2521 = and i1 %2514, %2520
  %2522 = insertelement <8 x i1> %2509, i1 %2521, i64 7
  %2523 = icmp ne <8 x i32> %2519, zeroinitializer
  %2524 = select <8 x i1> %2311, <8 x float> %2310, <8 x float> %2413
  %2525 = and <8 x i1> %2311, %2523
  %2526 = select <8 x i1> %2525, <8 x float> %2417, <8 x float> %2524
  %2527 = or <8 x i1> %2311, %2523
  %2528 = xor <8 x i32> %2095, splat (i32 4)
  %2529 = extractelement <8 x i32> %2528, i64 0
  %2530 = icmp ult i32 %2529, 8
  %2531 = select i1 %2530, i32 %2529, i32 0
  %2532 = extractelement <8 x i1> %119, i32 %2531
  %2533 = extractelement <8 x i1> %119, i64 0
  %2534 = and i1 %2530, %2532
  %2535 = and i1 %2533, %2534
  %2536 = extractelement <8 x float> %2526, i32 %2531
  %2537 = select i1 %2535, float %2536, float 0.000000e+00
  %2538 = insertelement <8 x float> poison, float %2537, i64 0
  %2539 = xor i1 %2535, true
  %2540 = and i1 %2533, %2539
  %2541 = insertelement <8 x i1> poison, i1 %2540, i64 0
  %2542 = extractelement <8 x i32> %2528, i64 1
  %2543 = icmp ult i32 %2542, 8
  %2544 = select i1 %2543, i32 %2542, i32 0
  %2545 = extractelement <8 x i1> %119, i32 %2544
  %2546 = extractelement <8 x i1> %119, i64 1
  %2547 = and i1 %2543, %2545
  %2548 = and i1 %2546, %2547
  %2549 = extractelement <8 x float> %2526, i32 %2544
  %2550 = select i1 %2548, float %2549, float 0.000000e+00
  %2551 = insertelement <8 x float> %2538, float %2550, i64 1
  %2552 = xor i1 %2548, true
  %2553 = and i1 %2546, %2552
  %2554 = insertelement <8 x i1> %2541, i1 %2553, i64 1
  %2555 = extractelement <8 x i32> %2528, i64 2
  %2556 = icmp ult i32 %2555, 8
  %2557 = select i1 %2556, i32 %2555, i32 0
  %2558 = extractelement <8 x i1> %119, i32 %2557
  %2559 = extractelement <8 x i1> %119, i64 2
  %2560 = and i1 %2556, %2558
  %2561 = and i1 %2559, %2560
  %2562 = extractelement <8 x float> %2526, i32 %2557
  %2563 = select i1 %2561, float %2562, float 0.000000e+00
  %2564 = insertelement <8 x float> %2551, float %2563, i64 2
  %2565 = xor i1 %2561, true
  %2566 = and i1 %2559, %2565
  %2567 = insertelement <8 x i1> %2554, i1 %2566, i64 2
  %2568 = extractelement <8 x i32> %2528, i64 3
  %2569 = icmp ult i32 %2568, 8
  %2570 = select i1 %2569, i32 %2568, i32 0
  %2571 = extractelement <8 x i1> %119, i32 %2570
  %2572 = extractelement <8 x i1> %119, i64 3
  %2573 = and i1 %2569, %2571
  %2574 = and i1 %2572, %2573
  %2575 = extractelement <8 x float> %2526, i32 %2570
  %2576 = select i1 %2574, float %2575, float 0.000000e+00
  %2577 = insertelement <8 x float> %2564, float %2576, i64 3
  %2578 = xor i1 %2574, true
  %2579 = and i1 %2572, %2578
  %2580 = insertelement <8 x i1> %2567, i1 %2579, i64 3
  %2581 = extractelement <8 x i32> %2528, i64 4
  %2582 = icmp ult i32 %2581, 8
  %2583 = select i1 %2582, i32 %2581, i32 0
  %2584 = extractelement <8 x i1> %119, i32 %2583
  %2585 = extractelement <8 x i1> %119, i64 4
  %2586 = and i1 %2582, %2584
  %2587 = and i1 %2585, %2586
  %2588 = extractelement <8 x float> %2526, i32 %2583
  %2589 = select i1 %2587, float %2588, float 0.000000e+00
  %2590 = insertelement <8 x float> %2577, float %2589, i64 4
  %2591 = xor i1 %2587, true
  %2592 = and i1 %2585, %2591
  %2593 = insertelement <8 x i1> %2580, i1 %2592, i64 4
  %2594 = extractelement <8 x i32> %2528, i64 5
  %2595 = icmp ult i32 %2594, 8
  %2596 = select i1 %2595, i32 %2594, i32 0
  %2597 = extractelement <8 x i1> %119, i32 %2596
  %2598 = extractelement <8 x i1> %119, i64 5
  %2599 = and i1 %2595, %2597
  %2600 = and i1 %2598, %2599
  %2601 = extractelement <8 x float> %2526, i32 %2596
  %2602 = select i1 %2600, float %2601, float 0.000000e+00
  %2603 = insertelement <8 x float> %2590, float %2602, i64 5
  %2604 = xor i1 %2600, true
  %2605 = and i1 %2598, %2604
  %2606 = insertelement <8 x i1> %2593, i1 %2605, i64 5
  %2607 = extractelement <8 x i32> %2528, i64 6
  %2608 = icmp ult i32 %2607, 8
  %2609 = select i1 %2608, i32 %2607, i32 0
  %2610 = extractelement <8 x i1> %119, i32 %2609
  %2611 = extractelement <8 x i1> %119, i64 6
  %2612 = and i1 %2608, %2610
  %2613 = and i1 %2611, %2612
  %2614 = extractelement <8 x float> %2526, i32 %2609
  %2615 = select i1 %2613, float %2614, float 0.000000e+00
  %2616 = insertelement <8 x float> %2603, float %2615, i64 6
  %2617 = xor i1 %2613, true
  %2618 = and i1 %2611, %2617
  %2619 = insertelement <8 x i1> %2606, i1 %2618, i64 6
  %2620 = extractelement <8 x i32> %2528, i64 7
  %2621 = icmp ult i32 %2620, 8
  %2622 = select i1 %2621, i32 %2620, i32 0
  %2623 = extractelement <8 x i1> %119, i32 %2622
  %2624 = extractelement <8 x i1> %119, i64 7
  %2625 = and i1 %2621, %2623
  %2626 = and i1 %2624, %2625
  %2627 = extractelement <8 x float> %2526, i32 %2622
  %2628 = select i1 %2626, float %2627, float 0.000000e+00
  %2629 = insertelement <8 x float> %2616, float %2628, i64 7
  %2630 = xor i1 %2626, true
  %2631 = and i1 %2624, %2630
  %2632 = insertelement <8 x i1> %2619, i1 %2631, i64 7
  %2633 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2526, <8 x float> %2629)
  %2634 = zext <8 x i1> %2527 to <8 x i32>
  %2635 = extractelement <8 x i32> %2528, i64 0
  %2636 = icmp ult i32 %2635, 8
  %2637 = select i1 %2636, i32 %2635, i32 0
  %2638 = extractelement <8 x i1> %119, i32 %2637
  %2639 = extractelement <8 x i1> %119, i64 0
  %2640 = and i1 %2636, %2638
  %2641 = and i1 %2639, %2640
  %2642 = extractelement <8 x i32> %2634, i32 %2637
  %2643 = select i1 %2641, i32 %2642, i32 0
  %2644 = insertelement <8 x i32> poison, i32 %2643, i64 0
  %2645 = xor i1 %2641, true
  %2646 = and i1 %2639, %2645
  %2647 = insertelement <8 x i1> poison, i1 %2646, i64 0
  %2648 = extractelement <8 x i32> %2528, i64 1
  %2649 = icmp ult i32 %2648, 8
  %2650 = select i1 %2649, i32 %2648, i32 0
  %2651 = extractelement <8 x i1> %119, i32 %2650
  %2652 = extractelement <8 x i1> %119, i64 1
  %2653 = and i1 %2649, %2651
  %2654 = and i1 %2652, %2653
  %2655 = extractelement <8 x i32> %2634, i32 %2650
  %2656 = select i1 %2654, i32 %2655, i32 0
  %2657 = insertelement <8 x i32> %2644, i32 %2656, i64 1
  %2658 = xor i1 %2654, true
  %2659 = and i1 %2652, %2658
  %2660 = insertelement <8 x i1> %2647, i1 %2659, i64 1
  %2661 = extractelement <8 x i32> %2528, i64 2
  %2662 = icmp ult i32 %2661, 8
  %2663 = select i1 %2662, i32 %2661, i32 0
  %2664 = extractelement <8 x i1> %119, i32 %2663
  %2665 = extractelement <8 x i1> %119, i64 2
  %2666 = and i1 %2662, %2664
  %2667 = and i1 %2665, %2666
  %2668 = extractelement <8 x i32> %2634, i32 %2663
  %2669 = select i1 %2667, i32 %2668, i32 0
  %2670 = insertelement <8 x i32> %2657, i32 %2669, i64 2
  %2671 = xor i1 %2667, true
  %2672 = and i1 %2665, %2671
  %2673 = insertelement <8 x i1> %2660, i1 %2672, i64 2
  %2674 = extractelement <8 x i32> %2528, i64 3
  %2675 = icmp ult i32 %2674, 8
  %2676 = select i1 %2675, i32 %2674, i32 0
  %2677 = extractelement <8 x i1> %119, i32 %2676
  %2678 = extractelement <8 x i1> %119, i64 3
  %2679 = and i1 %2675, %2677
  %2680 = and i1 %2678, %2679
  %2681 = extractelement <8 x i32> %2634, i32 %2676
  %2682 = select i1 %2680, i32 %2681, i32 0
  %2683 = insertelement <8 x i32> %2670, i32 %2682, i64 3
  %2684 = xor i1 %2680, true
  %2685 = and i1 %2678, %2684
  %2686 = insertelement <8 x i1> %2673, i1 %2685, i64 3
  %2687 = extractelement <8 x i32> %2528, i64 4
  %2688 = icmp ult i32 %2687, 8
  %2689 = select i1 %2688, i32 %2687, i32 0
  %2690 = extractelement <8 x i1> %119, i32 %2689
  %2691 = extractelement <8 x i1> %119, i64 4
  %2692 = and i1 %2688, %2690
  %2693 = and i1 %2691, %2692
  %2694 = extractelement <8 x i32> %2634, i32 %2689
  %2695 = select i1 %2693, i32 %2694, i32 0
  %2696 = insertelement <8 x i32> %2683, i32 %2695, i64 4
  %2697 = xor i1 %2693, true
  %2698 = and i1 %2691, %2697
  %2699 = insertelement <8 x i1> %2686, i1 %2698, i64 4
  %2700 = extractelement <8 x i32> %2528, i64 5
  %2701 = icmp ult i32 %2700, 8
  %2702 = select i1 %2701, i32 %2700, i32 0
  %2703 = extractelement <8 x i1> %119, i32 %2702
  %2704 = extractelement <8 x i1> %119, i64 5
  %2705 = and i1 %2701, %2703
  %2706 = and i1 %2704, %2705
  %2707 = extractelement <8 x i32> %2634, i32 %2702
  %2708 = select i1 %2706, i32 %2707, i32 0
  %2709 = insertelement <8 x i32> %2696, i32 %2708, i64 5
  %2710 = xor i1 %2706, true
  %2711 = and i1 %2704, %2710
  %2712 = insertelement <8 x i1> %2699, i1 %2711, i64 5
  %2713 = extractelement <8 x i32> %2528, i64 6
  %2714 = icmp ult i32 %2713, 8
  %2715 = select i1 %2714, i32 %2713, i32 0
  %2716 = extractelement <8 x i1> %119, i32 %2715
  %2717 = extractelement <8 x i1> %119, i64 6
  %2718 = and i1 %2714, %2716
  %2719 = and i1 %2717, %2718
  %2720 = extractelement <8 x i32> %2634, i32 %2715
  %2721 = select i1 %2719, i32 %2720, i32 0
  %2722 = insertelement <8 x i32> %2709, i32 %2721, i64 6
  %2723 = xor i1 %2719, true
  %2724 = and i1 %2717, %2723
  %2725 = insertelement <8 x i1> %2712, i1 %2724, i64 6
  %2726 = extractelement <8 x i32> %2528, i64 7
  %2727 = icmp ult i32 %2726, 8
  %2728 = select i1 %2727, i32 %2726, i32 0
  %2729 = extractelement <8 x i1> %119, i32 %2728
  %2730 = extractelement <8 x i1> %119, i64 7
  %2731 = and i1 %2727, %2729
  %2732 = and i1 %2730, %2731
  %2733 = extractelement <8 x i32> %2634, i32 %2728
  %2734 = select i1 %2732, i32 %2733, i32 0
  %2735 = insertelement <8 x i32> %2722, i32 %2734, i64 7
  %2736 = xor i1 %2732, true
  %2737 = and i1 %2730, %2736
  %2738 = insertelement <8 x i1> %2725, i1 %2737, i64 7
  %2739 = icmp ne <8 x i32> %2735, zeroinitializer
  %2740 = select <8 x i1> %2527, <8 x float> %2526, <8 x float> %2629
  %2741 = and <8 x i1> %2527, %2739
  %2742 = select <8 x i1> %2741, <8 x float> %2633, <8 x float> %2740
  %2743 = extractelement <8 x i1> %119, i32 0
  %2744 = extractelement <8 x i1> %119, i64 0
  %2745 = and i1 true, %2743
  %2746 = and i1 %2744, %2745
  %2747 = extractelement <8 x float> %2742, i32 0
  %2748 = select i1 %2746, float %2747, float 0.000000e+00
  %2749 = insertelement <8 x float> poison, float %2748, i64 0
  %2750 = xor i1 %2746, true
  %2751 = and i1 %2744, %2750
  %2752 = insertelement <8 x i1> poison, i1 %2751, i64 0
  %2753 = extractelement <8 x i1> %119, i32 0
  %2754 = extractelement <8 x i1> %119, i64 1
  %2755 = and i1 true, %2753
  %2756 = and i1 %2754, %2755
  %2757 = extractelement <8 x float> %2742, i32 0
  %2758 = select i1 %2756, float %2757, float 0.000000e+00
  %2759 = insertelement <8 x float> %2749, float %2758, i64 1
  %2760 = xor i1 %2756, true
  %2761 = and i1 %2754, %2760
  %2762 = insertelement <8 x i1> %2752, i1 %2761, i64 1
  %2763 = extractelement <8 x i1> %119, i32 0
  %2764 = extractelement <8 x i1> %119, i64 2
  %2765 = and i1 true, %2763
  %2766 = and i1 %2764, %2765
  %2767 = extractelement <8 x float> %2742, i32 0
  %2768 = select i1 %2766, float %2767, float 0.000000e+00
  %2769 = insertelement <8 x float> %2759, float %2768, i64 2
  %2770 = xor i1 %2766, true
  %2771 = and i1 %2764, %2770
  %2772 = insertelement <8 x i1> %2762, i1 %2771, i64 2
  %2773 = extractelement <8 x i1> %119, i32 0
  %2774 = extractelement <8 x i1> %119, i64 3
  %2775 = and i1 true, %2773
  %2776 = and i1 %2774, %2775
  %2777 = extractelement <8 x float> %2742, i32 0
  %2778 = select i1 %2776, float %2777, float 0.000000e+00
  %2779 = insertelement <8 x float> %2769, float %2778, i64 3
  %2780 = xor i1 %2776, true
  %2781 = and i1 %2774, %2780
  %2782 = insertelement <8 x i1> %2772, i1 %2781, i64 3
  %2783 = extractelement <8 x i1> %119, i32 0
  %2784 = extractelement <8 x i1> %119, i64 4
  %2785 = and i1 true, %2783
  %2786 = and i1 %2784, %2785
  %2787 = extractelement <8 x float> %2742, i32 0
  %2788 = select i1 %2786, float %2787, float 0.000000e+00
  %2789 = insertelement <8 x float> %2779, float %2788, i64 4
  %2790 = xor i1 %2786, true
  %2791 = and i1 %2784, %2790
  %2792 = insertelement <8 x i1> %2782, i1 %2791, i64 4
  %2793 = extractelement <8 x i1> %119, i32 0
  %2794 = extractelement <8 x i1> %119, i64 5
  %2795 = and i1 true, %2793
  %2796 = and i1 %2794, %2795
  %2797 = extractelement <8 x float> %2742, i32 0
  %2798 = select i1 %2796, float %2797, float 0.000000e+00
  %2799 = insertelement <8 x float> %2789, float %2798, i64 5
  %2800 = xor i1 %2796, true
  %2801 = and i1 %2794, %2800
  %2802 = insertelement <8 x i1> %2792, i1 %2801, i64 5
  %2803 = extractelement <8 x i1> %119, i32 0
  %2804 = extractelement <8 x i1> %119, i64 6
  %2805 = and i1 true, %2803
  %2806 = and i1 %2804, %2805
  %2807 = extractelement <8 x float> %2742, i32 0
  %2808 = select i1 %2806, float %2807, float 0.000000e+00
  %2809 = insertelement <8 x float> %2799, float %2808, i64 6
  %2810 = xor i1 %2806, true
  %2811 = and i1 %2804, %2810
  %2812 = insertelement <8 x i1> %2802, i1 %2811, i64 6
  %2813 = extractelement <8 x i1> %119, i32 0
  %2814 = extractelement <8 x i1> %119, i64 7
  %2815 = and i1 true, %2813
  %2816 = and i1 %2814, %2815
  %2817 = extractelement <8 x float> %2742, i32 0
  %2818 = select i1 %2816, float %2817, float 0.000000e+00
  %2819 = insertelement <8 x float> %2809, float %2818, i64 7
  %2820 = xor i1 %2816, true
  %2821 = and i1 %2814, %2820
  %2822 = insertelement <8 x i1> %2812, i1 %2821, i64 7
  %2823 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  %2824 = bitcast <8 x i1> %119 to i8
  %2825 = call i8 @llvm.cttz.i8(i8 %2824, i1 false)
  %2826 = zext i8 %2825 to i32
  %2827 = select i1 %2823, i32 %2826, i32 0
  %2828 = extractelement <8 x float> %2819, i32 %2827
  %2829 = call float @llvm.maxnum.f32(float 0xFFF0000000000000, float %2828)
  %tile_snapshot.spill.load615 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill199, align 64
  %2830 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load615, 0
  %2831 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load615, 1
  %.state616 = load <8 x i64>, ptr %.slot200, align 64
  %2832 = mul <8 x i64> %.state616, splat (i64 32)
  %2833 = add <8 x i64> %2831, %2832
  %2834 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2830, 0
  %2835 = insertvalue { <8 x ptr>, <8 x i64> } %2834, <8 x i64> %2833, 1
  %.splatinsert617 = insertelement <8 x float> poison, float %2829, i64 0
  %.splat618 = shufflevector <8 x float> %.splatinsert617, <8 x float> poison, <8 x i32> zeroinitializer
  %2836 = extractvalue { <8 x ptr>, <8 x i64> } %2835, 0
  %2837 = extractvalue { <8 x ptr>, <8 x i64> } %2835, 1
  %2838 = getelementptr i8, <8 x ptr> %2836, <8 x i64> %2837
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.splat618, <8 x ptr> align 1 %2838, <8 x i1> %119)
  %.state619 = load <8 x i64>, ptr %.slot200, align 64
  %2839 = add <8 x i64> %.state619, splat (i64 1)
  %2840 = load <8 x i64>, ptr %.slot200, align 64
  %2841 = select <8 x i1> %119, <8 x i64> %2839, <8 x i64> %2840
  store <8 x i64> %2841, ptr %.slot200, align 64
  br label %direct.schedule.142

direct.schedule.149:                              ; preds = %direct.false588
  %2842 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %2843 = extractvalue { <8 x ptr>, <8 x i64> } %49, 0
  %2844 = extractvalue { <8 x ptr>, <8 x i64> } %2842, 0
  %2845 = select <8 x i1> %119, <8 x ptr> %2843, <8 x ptr> %2844
  %2846 = extractvalue { <8 x ptr>, <8 x i64> } %49, 1
  %2847 = extractvalue { <8 x ptr>, <8 x i64> } %2842, 1
  %2848 = select <8 x i1> %119, <8 x i64> %2846, <8 x i64> %2847
  %2849 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2845, 0
  %2850 = insertvalue { <8 x ptr>, <8 x i64> } %2849, <8 x i64> %2848, 1
  store { <8 x ptr>, <8 x i64> } %2850, ptr %tile_snapshot.spill207, align 64
  %2851 = load <8 x i64>, ptr %.slot208, align 64
  %2852 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %2851
  store <8 x i64> %2852, ptr %.slot208, align 64
  br label %direct.schedule.150

direct.schedule.150:                              ; preds = %direct.schedule.157, %direct.schedule.149
  %.state620 = load <8 x i64>, ptr %.slot208, align 64
  %2853 = icmp slt <8 x i64> %.state620, splat (i64 1)
  %2854 = extractelement <8 x i1> %2853, i32 0
  br i1 %2854, label %direct.true621, label %direct.false622

direct.schedule.151:                              ; preds = %direct.true621
  %.state623 = load <8 x i64>, ptr %.slot208, align 64
  %2855 = select <8 x i1> %119, <8 x i64> %.state623, <8 x i64> zeroinitializer
  %2856 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2857 = srem <8 x i64> %2855, %2856
  %2858 = mul <8 x i64> %2857, splat (i64 8)
  %.spill.load624 = load <8 x i64>, ptr %.spill, align 64
  %2859 = add <8 x i64> %2858, %.spill.load624
  %2860 = icmp slt <8 x i64> %2859, splat (i64 2)
  %2861 = load <8 x i1>, ptr %.spill209, align 1
  %2862 = select <8 x i1> %119, <8 x i1> %2860, <8 x i1> %2861
  store <8 x i1> %2862, ptr %.spill209, align 1
  %2863 = select <8 x i1> %2860, <8 x i64> %2859, <8 x i64> splat (i64 1)
  %2864 = add <8 x i64> zeroinitializer, %2863
  %2865 = load <8 x i64>, ptr %.spill210, align 64
  %2866 = select <8 x i1> %119, <8 x i64> %2864, <8 x i64> %2865
  store <8 x i64> %2866, ptr %.spill210, align 64
  %2867 = add <8 x i64> zeroinitializer, %2857
  %2868 = and <8 x i1> %119, %2860
  %2869 = xor <8 x i1> %2860, splat (i1 true)
  %2870 = and <8 x i1> %119, %2869
  %2871 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2868)
  %2872 = bitcast <8 x i1> %2868 to i8
  %2873 = call i8 @llvm.cttz.i8(i8 %2872, i1 false)
  %2874 = zext i8 %2873 to i32
  %2875 = select i1 %2871, i32 %2874, i32 0
  %tile_snapshot.spill.load625 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %2876 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load625, 0
  %2877 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load625, 1
  %2878 = mul <8 x i64> %2867, splat (i64 32)
  %2879 = add <8 x i64> %2877, %2878
  %2880 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2876, 0
  %2881 = insertvalue { <8 x ptr>, <8 x i64> } %2880, <8 x i64> %2879, 1
  %2882 = extractvalue { <8 x ptr>, <8 x i64> } %2881, 0
  %2883 = extractvalue { <8 x ptr>, <8 x i64> } %2881, 1
  %2884 = getelementptr i8, <8 x ptr> %2882, <8 x i64> %2883
  %2885 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2884, <8 x i1> %2868, <8 x float> zeroinitializer)
  %2886 = load <8 x float>, ptr %.slot211, align 32
  %2887 = select <8 x i1> %2868, <8 x float> %2885, <8 x float> %2886
  store <8 x float> %2887, ptr %.slot211, align 32
  %2888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2870)
  %2889 = bitcast <8 x i1> %2870 to i8
  %2890 = call i8 @llvm.cttz.i8(i8 %2889, i1 false)
  %2891 = zext i8 %2890 to i32
  %2892 = select i1 %2888, i32 %2891, i32 0
  %2893 = load <8 x float>, ptr %.slot211, align 32
  %2894 = select <8 x i1> %2870, <8 x float> zeroinitializer, <8 x float> %2893
  store <8 x float> %2894, ptr %.slot211, align 32
  br label %direct.schedule.153

direct.schedule.153:                              ; preds = %direct.schedule.151
  %.spill.load626 = load <8 x i1>, ptr %.spill209, align 1
  %2895 = and <8 x i1> %119, %.spill.load626
  %2896 = xor <8 x i1> %.spill.load626, splat (i1 true)
  %2897 = and <8 x i1> %119, %2896
  %2898 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2895)
  %2899 = bitcast <8 x i1> %2895 to i8
  %2900 = call i8 @llvm.cttz.i8(i8 %2899, i1 false)
  %2901 = zext i8 %2900 to i32
  %2902 = select i1 %2898, i32 %2901, i32 0
  %tile_snapshot.spill.load627 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill199, align 64
  %2903 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 0
  %2904 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load627, 1
  %.spill.load628 = load <8 x i64>, ptr %.spill210, align 64
  %2905 = mul <8 x i64> %.spill.load628, splat (i64 32)
  %2906 = add <8 x i64> %2904, %2905
  %2907 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2903, 0
  %2908 = insertvalue { <8 x ptr>, <8 x i64> } %2907, <8 x i64> %2906, 1
  %2909 = extractvalue { <8 x ptr>, <8 x i64> } %2908, 0
  %2910 = extractvalue { <8 x ptr>, <8 x i64> } %2908, 1
  %2911 = getelementptr i8, <8 x ptr> %2909, <8 x i64> %2910
  %2912 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2911, <8 x i1> %2895, <8 x float> zeroinitializer)
  %2913 = load <8 x float>, ptr %.slot212, align 32
  %2914 = select <8 x i1> %2895, <8 x float> %2912, <8 x float> %2913
  store <8 x float> %2914, ptr %.slot212, align 32
  %2915 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2897)
  %2916 = bitcast <8 x i1> %2897 to i8
  %2917 = call i8 @llvm.cttz.i8(i8 %2916, i1 false)
  %2918 = zext i8 %2917 to i32
  %2919 = select i1 %2915, i32 %2918, i32 0
  %2920 = load <8 x float>, ptr %.slot212, align 32
  %2921 = select <8 x i1> %2897, <8 x float> zeroinitializer, <8 x float> %2920
  store <8 x float> %2921, ptr %.slot212, align 32
  br label %direct.schedule.155

direct.schedule.155:                              ; preds = %direct.schedule.153
  %.state629 = load <8 x float>, ptr %.slot211, align 32
  %.state630 = load <8 x float>, ptr %.slot212, align 32
  %2922 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state629, <8 x float> %.state630)
  %.spill.load631 = load <8 x i1>, ptr %.spill209, align 1
  %2923 = and <8 x i1> %119, %.spill.load631
  %2924 = xor <8 x i1> %.spill.load631, splat (i1 true)
  %2925 = and <8 x i1> %119, %2924
  %2926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2923)
  %2927 = bitcast <8 x i1> %2923 to i8
  %2928 = call i8 @llvm.cttz.i8(i8 %2927, i1 false)
  %2929 = zext i8 %2928 to i32
  %2930 = select i1 %2926, i32 %2929, i32 0
  %tile_snapshot.spill.load632 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %2931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load632, 0
  %2932 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load632, 1
  %.state633 = load <8 x i64>, ptr %.slot208, align 64
  %2933 = mul <8 x i64> %.state633, splat (i64 32)
  %2934 = add <8 x i64> %2932, %2933
  %2935 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2931, 0
  %2936 = insertvalue { <8 x ptr>, <8 x i64> } %2935, <8 x i64> %2934, 1
  %2937 = extractvalue { <8 x ptr>, <8 x i64> } %2936, 0
  %2938 = extractvalue { <8 x ptr>, <8 x i64> } %2936, 1
  %2939 = getelementptr i8, <8 x ptr> %2937, <8 x i64> %2938
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2922, <8 x ptr> align 1 %2939, <8 x i1> %2923)
  %2940 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2925)
  %2941 = bitcast <8 x i1> %2925 to i8
  %2942 = call i8 @llvm.cttz.i8(i8 %2941, i1 false)
  %2943 = zext i8 %2942 to i32
  %2944 = select i1 %2940, i32 %2943, i32 0
  br label %direct.schedule.157

direct.schedule.157:                              ; preds = %direct.schedule.155
  %.state634 = load <8 x i64>, ptr %.slot208, align 64
  %2945 = add <8 x i64> %.state634, splat (i64 1)
  %2946 = load <8 x i64>, ptr %.slot208, align 64
  %2947 = select <8 x i1> %119, <8 x i64> %2945, <8 x i64> %2946
  store <8 x i64> %2947, ptr %.slot208, align 64
  br label %direct.schedule.150

direct.schedule.158:                              ; preds = %direct.false622
  %2948 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill213, align 64
  %2949 = extractvalue { <8 x ptr>, <8 x i64> } %51, 0
  %2950 = extractvalue { <8 x ptr>, <8 x i64> } %2948, 0
  %2951 = select <8 x i1> %119, <8 x ptr> %2949, <8 x ptr> %2950
  %2952 = extractvalue { <8 x ptr>, <8 x i64> } %51, 1
  %2953 = extractvalue { <8 x ptr>, <8 x i64> } %2948, 1
  %2954 = select <8 x i1> %119, <8 x i64> %2952, <8 x i64> %2953
  %2955 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2951, 0
  %2956 = insertvalue { <8 x ptr>, <8 x i64> } %2955, <8 x i64> %2954, 1
  store { <8 x ptr>, <8 x i64> } %2956, ptr %tile_snapshot.spill213, align 64
  %2957 = load <8 x i64>, ptr %.slot214, align 64
  %2958 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %2957
  store <8 x i64> %2958, ptr %.slot214, align 64
  br label %direct.schedule.159

direct.schedule.159:                              ; preds = %direct.schedule.166, %direct.schedule.158
  %.state635 = load <8 x i64>, ptr %.slot214, align 64
  %2959 = icmp slt <8 x i64> %.state635, splat (i64 1)
  %2960 = extractelement <8 x i1> %2959, i32 0
  br i1 %2960, label %direct.true636, label %direct.false637

direct.schedule.160:                              ; preds = %direct.true636
  %.state638 = load <8 x i64>, ptr %.slot214, align 64
  %2961 = select <8 x i1> %119, <8 x i64> %.state638, <8 x i64> zeroinitializer
  %2962 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2963 = srem <8 x i64> %2961, %2962
  %2964 = mul <8 x i64> %2963, splat (i64 8)
  %.spill.load639 = load <8 x i64>, ptr %.spill, align 64
  %2965 = add <8 x i64> %2964, %.spill.load639
  %2966 = icmp slt <8 x i64> %2965, splat (i64 2)
  %2967 = load <8 x i1>, ptr %.spill215, align 1
  %2968 = select <8 x i1> %119, <8 x i1> %2966, <8 x i1> %2967
  store <8 x i1> %2968, ptr %.spill215, align 1
  %2969 = add <8 x i64> zeroinitializer, %2963
  %2970 = load <8 x i64>, ptr %.spill216, align 64
  %2971 = select <8 x i1> %119, <8 x i64> %2969, <8 x i64> %2970
  store <8 x i64> %2971, ptr %.spill216, align 64
  %2972 = and <8 x i1> %119, %2966
  %2973 = xor <8 x i1> %2966, splat (i1 true)
  %2974 = and <8 x i1> %119, %2973
  %2975 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2972)
  %2976 = bitcast <8 x i1> %2972 to i8
  %2977 = call i8 @llvm.cttz.i8(i8 %2976, i1 false)
  %2978 = zext i8 %2977 to i32
  %2979 = select i1 %2975, i32 %2978, i32 0
  %tile_snapshot.spill.load640 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %2980 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load640, 0
  %2981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load640, 1
  %2982 = mul <8 x i64> %2969, splat (i64 32)
  %2983 = add <8 x i64> %2981, %2982
  %2984 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2980, 0
  %2985 = insertvalue { <8 x ptr>, <8 x i64> } %2984, <8 x i64> %2983, 1
  %2986 = extractvalue { <8 x ptr>, <8 x i64> } %2985, 0
  %2987 = extractvalue { <8 x ptr>, <8 x i64> } %2985, 1
  %2988 = getelementptr i8, <8 x ptr> %2986, <8 x i64> %2987
  %2989 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2988, <8 x i1> %2972, <8 x float> zeroinitializer)
  %2990 = load <8 x float>, ptr %.slot217, align 32
  %2991 = select <8 x i1> %2972, <8 x float> %2989, <8 x float> %2990
  store <8 x float> %2991, ptr %.slot217, align 32
  %2992 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2974)
  %2993 = bitcast <8 x i1> %2974 to i8
  %2994 = call i8 @llvm.cttz.i8(i8 %2993, i1 false)
  %2995 = zext i8 %2994 to i32
  %2996 = select i1 %2992, i32 %2995, i32 0
  %2997 = load <8 x float>, ptr %.slot217, align 32
  %2998 = select <8 x i1> %2974, <8 x float> zeroinitializer, <8 x float> %2997
  store <8 x float> %2998, ptr %.slot217, align 32
  br label %direct.schedule.162

direct.schedule.162:                              ; preds = %direct.schedule.160
  %.spill.load641 = load <8 x i1>, ptr %.spill215, align 1
  %2999 = and <8 x i1> %119, %.spill.load641
  %3000 = xor <8 x i1> %.spill.load641, splat (i1 true)
  %3001 = and <8 x i1> %119, %3000
  %3002 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2999)
  %3003 = bitcast <8 x i1> %2999 to i8
  %3004 = call i8 @llvm.cttz.i8(i8 %3003, i1 false)
  %3005 = zext i8 %3004 to i32
  %3006 = select i1 %3002, i32 %3005, i32 0
  %tile_snapshot.spill.load642 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %3007 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load642, 0
  %3008 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load642, 1
  %.spill.load643 = load <8 x i64>, ptr %.spill216, align 64
  %3009 = mul <8 x i64> %.spill.load643, splat (i64 32)
  %3010 = add <8 x i64> %3008, %3009
  %3011 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3007, 0
  %3012 = insertvalue { <8 x ptr>, <8 x i64> } %3011, <8 x i64> %3010, 1
  %3013 = extractvalue { <8 x ptr>, <8 x i64> } %3012, 0
  %3014 = extractvalue { <8 x ptr>, <8 x i64> } %3012, 1
  %3015 = getelementptr i8, <8 x ptr> %3013, <8 x i64> %3014
  %3016 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3015, <8 x i1> %2999, <8 x float> zeroinitializer)
  %3017 = load <8 x float>, ptr %.slot218, align 32
  %3018 = select <8 x i1> %2999, <8 x float> %3016, <8 x float> %3017
  store <8 x float> %3018, ptr %.slot218, align 32
  %3019 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3001)
  %3020 = bitcast <8 x i1> %3001 to i8
  %3021 = call i8 @llvm.cttz.i8(i8 %3020, i1 false)
  %3022 = zext i8 %3021 to i32
  %3023 = select i1 %3019, i32 %3022, i32 0
  %3024 = load <8 x float>, ptr %.slot218, align 32
  %3025 = select <8 x i1> %3001, <8 x float> zeroinitializer, <8 x float> %3024
  store <8 x float> %3025, ptr %.slot218, align 32
  br label %direct.schedule.164

direct.schedule.164:                              ; preds = %direct.schedule.162
  %.state644 = load <8 x float>, ptr %.slot217, align 32
  %.state645 = load <8 x float>, ptr %.slot218, align 32
  %3026 = fsub <8 x float> %.state644, %.state645
  %.spill.load646 = load <8 x i1>, ptr %.spill215, align 1
  %3027 = and <8 x i1> %119, %.spill.load646
  %3028 = xor <8 x i1> %.spill.load646, splat (i1 true)
  %3029 = and <8 x i1> %119, %3028
  %3030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3027)
  %3031 = bitcast <8 x i1> %3027 to i8
  %3032 = call i8 @llvm.cttz.i8(i8 %3031, i1 false)
  %3033 = zext i8 %3032 to i32
  %3034 = select i1 %3030, i32 %3033, i32 0
  %tile_snapshot.spill.load647 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill213, align 64
  %3035 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load647, 0
  %3036 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load647, 1
  %.state648 = load <8 x i64>, ptr %.slot214, align 64
  %3037 = mul <8 x i64> %.state648, splat (i64 32)
  %3038 = add <8 x i64> %3036, %3037
  %3039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3035, 0
  %3040 = insertvalue { <8 x ptr>, <8 x i64> } %3039, <8 x i64> %3038, 1
  %3041 = extractvalue { <8 x ptr>, <8 x i64> } %3040, 0
  %3042 = extractvalue { <8 x ptr>, <8 x i64> } %3040, 1
  %3043 = getelementptr i8, <8 x ptr> %3041, <8 x i64> %3042
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3026, <8 x ptr> align 1 %3043, <8 x i1> %3027)
  %3044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3029)
  %3045 = bitcast <8 x i1> %3029 to i8
  %3046 = call i8 @llvm.cttz.i8(i8 %3045, i1 false)
  %3047 = zext i8 %3046 to i32
  %3048 = select i1 %3044, i32 %3047, i32 0
  br label %direct.schedule.166

direct.schedule.166:                              ; preds = %direct.schedule.164
  %.state649 = load <8 x i64>, ptr %.slot214, align 64
  %3049 = add <8 x i64> %.state649, splat (i64 1)
  %3050 = load <8 x i64>, ptr %.slot214, align 64
  %3051 = select <8 x i1> %119, <8 x i64> %3049, <8 x i64> %3050
  store <8 x i64> %3051, ptr %.slot214, align 64
  br label %direct.schedule.159

direct.schedule.167:                              ; preds = %direct.false637
  %3052 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill219, align 64
  %3053 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %3054 = extractvalue { <8 x ptr>, <8 x i64> } %3052, 0
  %3055 = select <8 x i1> %119, <8 x ptr> %3053, <8 x ptr> %3054
  %3056 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %3057 = extractvalue { <8 x ptr>, <8 x i64> } %3052, 1
  %3058 = select <8 x i1> %119, <8 x i64> %3056, <8 x i64> %3057
  %3059 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3055, 0
  %3060 = insertvalue { <8 x ptr>, <8 x i64> } %3059, <8 x i64> %3058, 1
  store { <8 x ptr>, <8 x i64> } %3060, ptr %tile_snapshot.spill219, align 64
  %3061 = load <8 x i64>, ptr %.slot220, align 64
  %3062 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3061
  store <8 x i64> %3062, ptr %.slot220, align 64
  br label %direct.schedule.168

direct.schedule.168:                              ; preds = %direct.schedule.173, %direct.schedule.167
  %.state650 = load <8 x i64>, ptr %.slot220, align 64
  %3063 = icmp slt <8 x i64> %.state650, splat (i64 1)
  %3064 = extractelement <8 x i1> %3063, i32 0
  br i1 %3064, label %direct.true651, label %direct.false652

direct.schedule.169:                              ; preds = %direct.true651
  %.state653 = load <8 x i64>, ptr %.slot220, align 64
  %3065 = select <8 x i1> %119, <8 x i64> %.state653, <8 x i64> zeroinitializer
  %3066 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3067 = srem <8 x i64> %3065, %3066
  %3068 = mul <8 x i64> %3067, splat (i64 8)
  %.spill.load654 = load <8 x i64>, ptr %.spill, align 64
  %3069 = add <8 x i64> %3068, %.spill.load654
  %3070 = icmp slt <8 x i64> %3069, splat (i64 2)
  %3071 = load <8 x i1>, ptr %.spill221, align 1
  %3072 = select <8 x i1> %119, <8 x i1> %3070, <8 x i1> %3071
  store <8 x i1> %3072, ptr %.spill221, align 1
  %3073 = add <8 x i64> zeroinitializer, %3067
  %3074 = and <8 x i1> %119, %3070
  %3075 = xor <8 x i1> %3070, splat (i1 true)
  %3076 = and <8 x i1> %119, %3075
  %3077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3074)
  %3078 = bitcast <8 x i1> %3074 to i8
  %3079 = call i8 @llvm.cttz.i8(i8 %3078, i1 false)
  %3080 = zext i8 %3079 to i32
  %3081 = select i1 %3077, i32 %3080, i32 0
  %tile_snapshot.spill.load655 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill213, align 64
  %3082 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 0
  %3083 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load655, 1
  %3084 = mul <8 x i64> %3073, splat (i64 32)
  %3085 = add <8 x i64> %3083, %3084
  %3086 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3082, 0
  %3087 = insertvalue { <8 x ptr>, <8 x i64> } %3086, <8 x i64> %3085, 1
  %3088 = extractvalue { <8 x ptr>, <8 x i64> } %3087, 0
  %3089 = extractvalue { <8 x ptr>, <8 x i64> } %3087, 1
  %3090 = getelementptr i8, <8 x ptr> %3088, <8 x i64> %3089
  %3091 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3090, <8 x i1> %3074, <8 x float> zeroinitializer)
  %3092 = load <8 x float>, ptr %.slot222, align 32
  %3093 = select <8 x i1> %3074, <8 x float> %3091, <8 x float> %3092
  store <8 x float> %3093, ptr %.slot222, align 32
  %3094 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3076)
  %3095 = bitcast <8 x i1> %3076 to i8
  %3096 = call i8 @llvm.cttz.i8(i8 %3095, i1 false)
  %3097 = zext i8 %3096 to i32
  %3098 = select i1 %3094, i32 %3097, i32 0
  %3099 = load <8 x float>, ptr %.slot222, align 32
  %3100 = select <8 x i1> %3076, <8 x float> zeroinitializer, <8 x float> %3099
  store <8 x float> %3100, ptr %.slot222, align 32
  br label %direct.schedule.171

direct.schedule.171:                              ; preds = %direct.schedule.169
  %.state656 = load <8 x float>, ptr %.slot222, align 32
  %3101 = select <8 x i1> %119, <8 x float> %.state656, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3101)
  %.spill.load657 = load <8 x i1>, ptr %.spill221, align 1
  %3102 = and <8 x i1> %119, %.spill.load657
  %3103 = xor <8 x i1> %.spill.load657, splat (i1 true)
  %3104 = and <8 x i1> %119, %3103
  %3105 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3102)
  %3106 = bitcast <8 x i1> %3102 to i8
  %3107 = call i8 @llvm.cttz.i8(i8 %3106, i1 false)
  %3108 = zext i8 %3107 to i32
  %3109 = select i1 %3105, i32 %3108, i32 0
  %tile_snapshot.spill.load658 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill219, align 64
  %3110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 0
  %3111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load658, 1
  %.state659 = load <8 x i64>, ptr %.slot220, align 64
  %3112 = mul <8 x i64> %.state659, splat (i64 32)
  %3113 = add <8 x i64> %3111, %3112
  %3114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3110, 0
  %3115 = insertvalue { <8 x ptr>, <8 x i64> } %3114, <8 x i64> %3113, 1
  %3116 = extractvalue { <8 x ptr>, <8 x i64> } %3115, 0
  %3117 = extractvalue { <8 x ptr>, <8 x i64> } %3115, 1
  %3118 = getelementptr i8, <8 x ptr> %3116, <8 x i64> %3117
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %native.exp, <8 x ptr> align 1 %3118, <8 x i1> %3102)
  %3119 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3104)
  %3120 = bitcast <8 x i1> %3104 to i8
  %3121 = call i8 @llvm.cttz.i8(i8 %3120, i1 false)
  %3122 = zext i8 %3121 to i32
  %3123 = select i1 %3119, i32 %3122, i32 0
  br label %direct.schedule.173

direct.schedule.173:                              ; preds = %direct.schedule.171
  %.state660 = load <8 x i64>, ptr %.slot220, align 64
  %3124 = add <8 x i64> %.state660, splat (i64 1)
  %3125 = load <8 x i64>, ptr %.slot220, align 64
  %3126 = select <8 x i1> %119, <8 x i64> %3124, <8 x i64> %3125
  store <8 x i64> %3126, ptr %.slot220, align 64
  br label %direct.schedule.168

direct.schedule.174:                              ; preds = %direct.false652
  %3127 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill223, align 64
  %3128 = extractvalue { <8 x ptr>, <8 x i64> } %55, 0
  %3129 = extractvalue { <8 x ptr>, <8 x i64> } %3127, 0
  %3130 = select <8 x i1> %119, <8 x ptr> %3128, <8 x ptr> %3129
  %3131 = extractvalue { <8 x ptr>, <8 x i64> } %55, 1
  %3132 = extractvalue { <8 x ptr>, <8 x i64> } %3127, 1
  %3133 = select <8 x i1> %119, <8 x i64> %3131, <8 x i64> %3132
  %3134 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3130, 0
  %3135 = insertvalue { <8 x ptr>, <8 x i64> } %3134, <8 x i64> %3133, 1
  store { <8 x ptr>, <8 x i64> } %3135, ptr %tile_snapshot.spill223, align 64
  %3136 = load <8 x i64>, ptr %.slot224, align 64
  %3137 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3136
  store <8 x i64> %3137, ptr %.slot224, align 64
  br label %direct.schedule.175

direct.schedule.175:                              ; preds = %direct.schedule.182, %direct.schedule.174
  %.state661 = load <8 x i64>, ptr %.slot224, align 64
  %3138 = icmp slt <8 x i64> %.state661, splat (i64 10)
  %3139 = extractelement <8 x i1> %3138, i32 0
  br i1 %3139, label %direct.true662, label %direct.false663

direct.schedule.176:                              ; preds = %direct.true662
  %.state664 = load <8 x i64>, ptr %.slot224, align 64
  %3140 = select <8 x i1> %119, <8 x i64> %.state664, <8 x i64> zeroinitializer
  %3141 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3142 = srem <8 x i64> %3140, %3141
  %.state665 = load <8 x i64>, ptr %.slot224, align 64
  %3143 = select <8 x i1> %119, <8 x i64> %.state665, <8 x i64> zeroinitializer
  %3144 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3145 = sdiv <8 x i64> %3143, %3144
  %3146 = mul <8 x i64> %3142, splat (i64 8)
  %.spill.load666 = load <8 x i64>, ptr %.spill, align 64
  %3147 = add <8 x i64> %3146, %.spill.load666
  %3148 = icmp slt <8 x i64> %3147, splat (i64 33)
  %3149 = load <8 x i1>, ptr %.spill225, align 1
  %3150 = select <8 x i1> %119, <8 x i1> %3148, <8 x i1> %3149
  store <8 x i1> %3150, ptr %.spill225, align 1
  %3151 = select <8 x i1> %119, <8 x i64> %3145, <8 x i64> zeroinitializer
  %3152 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3153 = srem <8 x i64> %3151, %3152
  %3154 = load <8 x i64>, ptr %.spill226, align 64
  %3155 = select <8 x i1> %119, <8 x i64> %3153, <8 x i64> %3154
  store <8 x i64> %3155, ptr %.spill226, align 64
  store i64 0, ptr %.spill227, align 4
  %3156 = add <8 x i64> zeroinitializer, %3153
  %3157 = mul <8 x i64> %3156, splat (i64 5)
  %3158 = add <8 x i64> %3157, %3142
  %3159 = and <8 x i1> %119, %3148
  %3160 = xor <8 x i1> %3148, splat (i1 true)
  %3161 = and <8 x i1> %119, %3160
  %3162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3159)
  %3163 = bitcast <8 x i1> %3159 to i8
  %3164 = call i8 @llvm.cttz.i8(i8 %3163, i1 false)
  %3165 = zext i8 %3164 to i32
  %3166 = select i1 %3162, i32 %3165, i32 0
  %tile_snapshot.spill.load667 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill191, align 64
  %3167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load667, 0
  %3168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load667, 1
  %3169 = mul <8 x i64> %3158, splat (i64 32)
  %3170 = add <8 x i64> %3168, %3169
  %3171 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3167, 0
  %3172 = insertvalue { <8 x ptr>, <8 x i64> } %3171, <8 x i64> %3170, 1
  %3173 = extractvalue { <8 x ptr>, <8 x i64> } %3172, 0
  %3174 = extractvalue { <8 x ptr>, <8 x i64> } %3172, 1
  %3175 = getelementptr i8, <8 x ptr> %3173, <8 x i64> %3174
  %3176 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3175, <8 x i1> %3159, <8 x float> zeroinitializer)
  %3177 = load <8 x float>, ptr %.slot228, align 32
  %3178 = select <8 x i1> %3159, <8 x float> %3176, <8 x float> %3177
  store <8 x float> %3178, ptr %.slot228, align 32
  %3179 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3161)
  %3180 = bitcast <8 x i1> %3161 to i8
  %3181 = call i8 @llvm.cttz.i8(i8 %3180, i1 false)
  %3182 = zext i8 %3181 to i32
  %3183 = select i1 %3179, i32 %3182, i32 0
  %3184 = load <8 x float>, ptr %.slot228, align 32
  %3185 = select <8 x i1> %3161, <8 x float> zeroinitializer, <8 x float> %3184
  store <8 x float> %3185, ptr %.slot228, align 32
  br label %direct.schedule.178

direct.schedule.178:                              ; preds = %direct.schedule.176
  %.spill.load668 = load <8 x i64>, ptr %.spill226, align 64
  %3186 = select <8 x i1> %119, <8 x i64> %.spill.load668, <8 x i64> zeroinitializer
  %3187 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %3188 = sdiv <8 x i64> %3186, %3187
  %.spill.load669 = load i64, ptr %.spill227, align 4
  %3189 = mul i64 %.spill.load669, 1
  %.splatinsert670 = insertelement <8 x i64> poison, i64 %3189, i64 0
  %.splat671 = shufflevector <8 x i64> %.splatinsert670, <8 x i64> poison, <8 x i32> zeroinitializer
  %3190 = add <8 x i64> %.splat671, %3188
  %.spill.load672 = load <8 x i64>, ptr %.spill226, align 64
  %3191 = select <8 x i1> %119, <8 x i64> %.spill.load672, <8 x i64> zeroinitializer
  %3192 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %3193 = srem <8 x i64> %3191, %3192
  %3194 = load <8 x i64>, ptr %.spill229, align 64
  %3195 = select <8 x i1> %119, <8 x i64> %3193, <8 x i64> %3194
  store <8 x i64> %3195, ptr %.spill229, align 64
  %.spill.load673 = load <8 x i64>, ptr %.spill, align 64
  %3196 = icmp eq <8 x i64> %.spill.load673, %3193
  %3197 = and <8 x i1> %119, %3196
  %3198 = xor <8 x i1> %3196, splat (i1 true)
  %3199 = and <8 x i1> %119, %3198
  %3200 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3197)
  %3201 = bitcast <8 x i1> %3197 to i8
  %3202 = call i8 @llvm.cttz.i8(i8 %3201, i1 false)
  %3203 = zext i8 %3202 to i32
  %3204 = select i1 %3200, i32 %3203, i32 0
  %tile_snapshot.spill.load674 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %3205 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load674, 0
  %3206 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load674, 1
  %3207 = mul <8 x i64> %3190, splat (i64 32)
  %3208 = add <8 x i64> %3206, %3207
  %3209 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3205, 0
  %3210 = insertvalue { <8 x ptr>, <8 x i64> } %3209, <8 x i64> %3208, 1
  %3211 = extractvalue { <8 x ptr>, <8 x i64> } %3210, 0
  %3212 = extractvalue { <8 x ptr>, <8 x i64> } %3210, 1
  %3213 = getelementptr i8, <8 x ptr> %3211, <8 x i64> %3212
  %3214 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3213, <8 x i1> %3197, <8 x float> zeroinitializer)
  %3215 = load <8 x float>, ptr %.slot230, align 32
  %3216 = select <8 x i1> %3197, <8 x float> %3214, <8 x float> %3215
  store <8 x float> %3216, ptr %.slot230, align 32
  %3217 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3199)
  %3218 = bitcast <8 x i1> %3199 to i8
  %3219 = call i8 @llvm.cttz.i8(i8 %3218, i1 false)
  %3220 = zext i8 %3219 to i32
  %3221 = select i1 %3217, i32 %3220, i32 0
  %3222 = load <8 x float>, ptr %.slot230, align 32
  %3223 = select <8 x i1> %3199, <8 x float> zeroinitializer, <8 x float> %3222
  store <8 x float> %3223, ptr %.slot230, align 32
  br label %direct.schedule.180

direct.schedule.180:                              ; preds = %direct.schedule.178
  %.spill.load675 = load <8 x i64>, ptr %.spill229, align 64
  %3224 = trunc <8 x i64> %.spill.load675 to <8 x i32>
  %.state676 = load <8 x float>, ptr %.slot230, align 32
  %3225 = extractelement <8 x i32> %3224, i64 0
  %3226 = icmp ult i32 %3225, 8
  %3227 = select i1 %3226, i32 %3225, i32 0
  %3228 = extractelement <8 x i1> %119, i32 %3227
  %3229 = extractelement <8 x i1> %119, i64 0
  %3230 = and i1 %3226, %3228
  %3231 = and i1 %3229, %3230
  %3232 = extractelement <8 x float> %.state676, i32 %3227
  %3233 = select i1 %3231, float %3232, float 0.000000e+00
  %3234 = insertelement <8 x float> poison, float %3233, i64 0
  %3235 = xor i1 %3231, true
  %3236 = and i1 %3229, %3235
  %3237 = insertelement <8 x i1> poison, i1 %3236, i64 0
  %3238 = extractelement <8 x i32> %3224, i64 1
  %3239 = icmp ult i32 %3238, 8
  %3240 = select i1 %3239, i32 %3238, i32 0
  %3241 = extractelement <8 x i1> %119, i32 %3240
  %3242 = extractelement <8 x i1> %119, i64 1
  %3243 = and i1 %3239, %3241
  %3244 = and i1 %3242, %3243
  %3245 = extractelement <8 x float> %.state676, i32 %3240
  %3246 = select i1 %3244, float %3245, float 0.000000e+00
  %3247 = insertelement <8 x float> %3234, float %3246, i64 1
  %3248 = xor i1 %3244, true
  %3249 = and i1 %3242, %3248
  %3250 = insertelement <8 x i1> %3237, i1 %3249, i64 1
  %3251 = extractelement <8 x i32> %3224, i64 2
  %3252 = icmp ult i32 %3251, 8
  %3253 = select i1 %3252, i32 %3251, i32 0
  %3254 = extractelement <8 x i1> %119, i32 %3253
  %3255 = extractelement <8 x i1> %119, i64 2
  %3256 = and i1 %3252, %3254
  %3257 = and i1 %3255, %3256
  %3258 = extractelement <8 x float> %.state676, i32 %3253
  %3259 = select i1 %3257, float %3258, float 0.000000e+00
  %3260 = insertelement <8 x float> %3247, float %3259, i64 2
  %3261 = xor i1 %3257, true
  %3262 = and i1 %3255, %3261
  %3263 = insertelement <8 x i1> %3250, i1 %3262, i64 2
  %3264 = extractelement <8 x i32> %3224, i64 3
  %3265 = icmp ult i32 %3264, 8
  %3266 = select i1 %3265, i32 %3264, i32 0
  %3267 = extractelement <8 x i1> %119, i32 %3266
  %3268 = extractelement <8 x i1> %119, i64 3
  %3269 = and i1 %3265, %3267
  %3270 = and i1 %3268, %3269
  %3271 = extractelement <8 x float> %.state676, i32 %3266
  %3272 = select i1 %3270, float %3271, float 0.000000e+00
  %3273 = insertelement <8 x float> %3260, float %3272, i64 3
  %3274 = xor i1 %3270, true
  %3275 = and i1 %3268, %3274
  %3276 = insertelement <8 x i1> %3263, i1 %3275, i64 3
  %3277 = extractelement <8 x i32> %3224, i64 4
  %3278 = icmp ult i32 %3277, 8
  %3279 = select i1 %3278, i32 %3277, i32 0
  %3280 = extractelement <8 x i1> %119, i32 %3279
  %3281 = extractelement <8 x i1> %119, i64 4
  %3282 = and i1 %3278, %3280
  %3283 = and i1 %3281, %3282
  %3284 = extractelement <8 x float> %.state676, i32 %3279
  %3285 = select i1 %3283, float %3284, float 0.000000e+00
  %3286 = insertelement <8 x float> %3273, float %3285, i64 4
  %3287 = xor i1 %3283, true
  %3288 = and i1 %3281, %3287
  %3289 = insertelement <8 x i1> %3276, i1 %3288, i64 4
  %3290 = extractelement <8 x i32> %3224, i64 5
  %3291 = icmp ult i32 %3290, 8
  %3292 = select i1 %3291, i32 %3290, i32 0
  %3293 = extractelement <8 x i1> %119, i32 %3292
  %3294 = extractelement <8 x i1> %119, i64 5
  %3295 = and i1 %3291, %3293
  %3296 = and i1 %3294, %3295
  %3297 = extractelement <8 x float> %.state676, i32 %3292
  %3298 = select i1 %3296, float %3297, float 0.000000e+00
  %3299 = insertelement <8 x float> %3286, float %3298, i64 5
  %3300 = xor i1 %3296, true
  %3301 = and i1 %3294, %3300
  %3302 = insertelement <8 x i1> %3289, i1 %3301, i64 5
  %3303 = extractelement <8 x i32> %3224, i64 6
  %3304 = icmp ult i32 %3303, 8
  %3305 = select i1 %3304, i32 %3303, i32 0
  %3306 = extractelement <8 x i1> %119, i32 %3305
  %3307 = extractelement <8 x i1> %119, i64 6
  %3308 = and i1 %3304, %3306
  %3309 = and i1 %3307, %3308
  %3310 = extractelement <8 x float> %.state676, i32 %3305
  %3311 = select i1 %3309, float %3310, float 0.000000e+00
  %3312 = insertelement <8 x float> %3299, float %3311, i64 6
  %3313 = xor i1 %3309, true
  %3314 = and i1 %3307, %3313
  %3315 = insertelement <8 x i1> %3302, i1 %3314, i64 6
  %3316 = extractelement <8 x i32> %3224, i64 7
  %3317 = icmp ult i32 %3316, 8
  %3318 = select i1 %3317, i32 %3316, i32 0
  %3319 = extractelement <8 x i1> %119, i32 %3318
  %3320 = extractelement <8 x i1> %119, i64 7
  %3321 = and i1 %3317, %3319
  %3322 = and i1 %3320, %3321
  %3323 = extractelement <8 x float> %.state676, i32 %3318
  %3324 = select i1 %3322, float %3323, float 0.000000e+00
  %3325 = insertelement <8 x float> %3312, float %3324, i64 7
  %3326 = xor i1 %3322, true
  %3327 = and i1 %3320, %3326
  %3328 = insertelement <8 x i1> %3315, i1 %3327, i64 7
  %.state677 = load <8 x float>, ptr %.slot228, align 32
  %3329 = fsub <8 x float> %.state677, %3325
  %.spill.load678 = load <8 x i1>, ptr %.spill225, align 1
  %3330 = and <8 x i1> %119, %.spill.load678
  %3331 = xor <8 x i1> %.spill.load678, splat (i1 true)
  %3332 = and <8 x i1> %119, %3331
  %3333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3330)
  %3334 = bitcast <8 x i1> %3330 to i8
  %3335 = call i8 @llvm.cttz.i8(i8 %3334, i1 false)
  %3336 = zext i8 %3335 to i32
  %3337 = select i1 %3333, i32 %3336, i32 0
  %tile_snapshot.spill.load679 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill223, align 64
  %3338 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 0
  %3339 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 1
  %.state680 = load <8 x i64>, ptr %.slot224, align 64
  %3340 = mul <8 x i64> %.state680, splat (i64 32)
  %3341 = add <8 x i64> %3339, %3340
  %3342 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3338, 0
  %3343 = insertvalue { <8 x ptr>, <8 x i64> } %3342, <8 x i64> %3341, 1
  %3344 = extractvalue { <8 x ptr>, <8 x i64> } %3343, 0
  %3345 = extractvalue { <8 x ptr>, <8 x i64> } %3343, 1
  %3346 = getelementptr i8, <8 x ptr> %3344, <8 x i64> %3345
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3329, <8 x ptr> align 1 %3346, <8 x i1> %3330)
  %3347 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3332)
  %3348 = bitcast <8 x i1> %3332 to i8
  %3349 = call i8 @llvm.cttz.i8(i8 %3348, i1 false)
  %3350 = zext i8 %3349 to i32
  %3351 = select i1 %3347, i32 %3350, i32 0
  br label %direct.schedule.182

direct.schedule.182:                              ; preds = %direct.schedule.180
  %.state681 = load <8 x i64>, ptr %.slot224, align 64
  %3352 = add <8 x i64> %.state681, splat (i64 1)
  %3353 = load <8 x i64>, ptr %.slot224, align 64
  %3354 = select <8 x i1> %119, <8 x i64> %3352, <8 x i64> %3353
  store <8 x i64> %3354, ptr %.slot224, align 64
  br label %direct.schedule.175

direct.schedule.183:                              ; preds = %direct.false663
  %3355 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill231, align 64
  %3356 = extractvalue { <8 x ptr>, <8 x i64> } %57, 0
  %3357 = extractvalue { <8 x ptr>, <8 x i64> } %3355, 0
  %3358 = select <8 x i1> %119, <8 x ptr> %3356, <8 x ptr> %3357
  %3359 = extractvalue { <8 x ptr>, <8 x i64> } %57, 1
  %3360 = extractvalue { <8 x ptr>, <8 x i64> } %3355, 1
  %3361 = select <8 x i1> %119, <8 x i64> %3359, <8 x i64> %3360
  %3362 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3358, 0
  %3363 = insertvalue { <8 x ptr>, <8 x i64> } %3362, <8 x i64> %3361, 1
  store { <8 x ptr>, <8 x i64> } %3363, ptr %tile_snapshot.spill231, align 64
  %3364 = load <8 x i64>, ptr %.slot232, align 64
  %3365 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3364
  store <8 x i64> %3365, ptr %.slot232, align 64
  br label %direct.schedule.184

direct.schedule.184:                              ; preds = %direct.schedule.189, %direct.schedule.183
  %.state682 = load <8 x i64>, ptr %.slot232, align 64
  %3366 = icmp slt <8 x i64> %.state682, splat (i64 10)
  %3367 = extractelement <8 x i1> %3366, i32 0
  br i1 %3367, label %direct.true683, label %direct.false684

direct.schedule.185:                              ; preds = %direct.true683
  %.state685 = load <8 x i64>, ptr %.slot232, align 64
  %3368 = select <8 x i1> %119, <8 x i64> %.state685, <8 x i64> zeroinitializer
  %3369 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3370 = srem <8 x i64> %3368, %3369
  %.state686 = load <8 x i64>, ptr %.slot232, align 64
  %3371 = select <8 x i1> %119, <8 x i64> %.state686, <8 x i64> zeroinitializer
  %3372 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3373 = sdiv <8 x i64> %3371, %3372
  %3374 = mul <8 x i64> %3370, splat (i64 8)
  %.spill.load687 = load <8 x i64>, ptr %.spill, align 64
  %3375 = add <8 x i64> %3374, %.spill.load687
  %3376 = icmp slt <8 x i64> %3375, splat (i64 33)
  %3377 = load <8 x i1>, ptr %.spill233, align 1
  %3378 = select <8 x i1> %119, <8 x i1> %3376, <8 x i1> %3377
  store <8 x i1> %3378, ptr %.spill233, align 1
  %3379 = select <8 x i1> %119, <8 x i64> %3373, <8 x i64> zeroinitializer
  %3380 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3381 = srem <8 x i64> %3379, %3380
  %3382 = add <8 x i64> zeroinitializer, %3381
  %3383 = mul <8 x i64> %3382, splat (i64 5)
  %3384 = add <8 x i64> %3383, %3370
  %3385 = and <8 x i1> %119, %3376
  %3386 = xor <8 x i1> %3376, splat (i1 true)
  %3387 = and <8 x i1> %119, %3386
  %3388 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3385)
  %3389 = bitcast <8 x i1> %3385 to i8
  %3390 = call i8 @llvm.cttz.i8(i8 %3389, i1 false)
  %3391 = zext i8 %3390 to i32
  %3392 = select i1 %3388, i32 %3391, i32 0
  %tile_snapshot.spill.load688 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill223, align 64
  %3393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load688, 0
  %3394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load688, 1
  %3395 = mul <8 x i64> %3384, splat (i64 32)
  %3396 = add <8 x i64> %3394, %3395
  %3397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3393, 0
  %3398 = insertvalue { <8 x ptr>, <8 x i64> } %3397, <8 x i64> %3396, 1
  %3399 = extractvalue { <8 x ptr>, <8 x i64> } %3398, 0
  %3400 = extractvalue { <8 x ptr>, <8 x i64> } %3398, 1
  %3401 = getelementptr i8, <8 x ptr> %3399, <8 x i64> %3400
  %3402 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3401, <8 x i1> %3385, <8 x float> zeroinitializer)
  %3403 = load <8 x float>, ptr %.slot234, align 32
  %3404 = select <8 x i1> %3385, <8 x float> %3402, <8 x float> %3403
  store <8 x float> %3404, ptr %.slot234, align 32
  %3405 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3387)
  %3406 = bitcast <8 x i1> %3387 to i8
  %3407 = call i8 @llvm.cttz.i8(i8 %3406, i1 false)
  %3408 = zext i8 %3407 to i32
  %3409 = select i1 %3405, i32 %3408, i32 0
  %3410 = load <8 x float>, ptr %.slot234, align 32
  %3411 = select <8 x i1> %3387, <8 x float> zeroinitializer, <8 x float> %3410
  store <8 x float> %3411, ptr %.slot234, align 32
  br label %direct.schedule.187

direct.schedule.187:                              ; preds = %direct.schedule.185
  %.state689 = load <8 x float>, ptr %.slot234, align 32
  %3412 = select <8 x i1> %119, <8 x float> %.state689, <8 x float> zeroinitializer
  %native.exp690 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3412)
  %.spill.load691 = load <8 x i1>, ptr %.spill233, align 1
  %3413 = and <8 x i1> %119, %.spill.load691
  %3414 = xor <8 x i1> %.spill.load691, splat (i1 true)
  %3415 = and <8 x i1> %119, %3414
  %3416 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3413)
  %3417 = bitcast <8 x i1> %3413 to i8
  %3418 = call i8 @llvm.cttz.i8(i8 %3417, i1 false)
  %3419 = zext i8 %3418 to i32
  %3420 = select i1 %3416, i32 %3419, i32 0
  %tile_snapshot.spill.load692 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill231, align 64
  %3421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load692, 0
  %3422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load692, 1
  %.state693 = load <8 x i64>, ptr %.slot232, align 64
  %3423 = mul <8 x i64> %.state693, splat (i64 32)
  %3424 = add <8 x i64> %3422, %3423
  %3425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3421, 0
  %3426 = insertvalue { <8 x ptr>, <8 x i64> } %3425, <8 x i64> %3424, 1
  %3427 = extractvalue { <8 x ptr>, <8 x i64> } %3426, 0
  %3428 = extractvalue { <8 x ptr>, <8 x i64> } %3426, 1
  %3429 = getelementptr i8, <8 x ptr> %3427, <8 x i64> %3428
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %native.exp690, <8 x ptr> align 1 %3429, <8 x i1> %3413)
  %3430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3415)
  %3431 = bitcast <8 x i1> %3415 to i8
  %3432 = call i8 @llvm.cttz.i8(i8 %3431, i1 false)
  %3433 = zext i8 %3432 to i32
  %3434 = select i1 %3430, i32 %3433, i32 0
  br label %direct.schedule.189

direct.schedule.189:                              ; preds = %direct.schedule.187
  %.state694 = load <8 x i64>, ptr %.slot232, align 64
  %3435 = add <8 x i64> %.state694, splat (i64 1)
  %3436 = load <8 x i64>, ptr %.slot232, align 64
  %3437 = select <8 x i1> %119, <8 x i64> %3435, <8 x i64> %3436
  store <8 x i64> %3437, ptr %.slot232, align 64
  br label %direct.schedule.184

direct.schedule.190:                              ; preds = %direct.false684
  %3438 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill235, align 64
  %3439 = extractvalue { <8 x ptr>, <8 x i64> } %59, 0
  %3440 = extractvalue { <8 x ptr>, <8 x i64> } %3438, 0
  %3441 = select <8 x i1> %119, <8 x ptr> %3439, <8 x ptr> %3440
  %3442 = extractvalue { <8 x ptr>, <8 x i64> } %59, 1
  %3443 = extractvalue { <8 x ptr>, <8 x i64> } %3438, 1
  %3444 = select <8 x i1> %119, <8 x i64> %3442, <8 x i64> %3443
  %3445 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3441, 0
  %3446 = insertvalue { <8 x ptr>, <8 x i64> } %3445, <8 x i64> %3444, 1
  store { <8 x ptr>, <8 x i64> } %3446, ptr %tile_snapshot.spill235, align 64
  %3447 = load <8 x i64>, ptr %.slot236, align 64
  %3448 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3447
  store <8 x i64> %3448, ptr %.slot236, align 64
  br label %direct.schedule.191

direct.schedule.191:                              ; preds = %direct.schedule.198, %direct.schedule.190
  %.state695 = load <8 x i64>, ptr %.slot236, align 64
  %3449 = icmp slt <8 x i64> %.state695, splat (i64 10)
  %3450 = extractelement <8 x i1> %3449, i32 0
  br i1 %3450, label %direct.true696, label %direct.false697

direct.schedule.192:                              ; preds = %direct.true696
  %.state698 = load <8 x i64>, ptr %.slot236, align 64
  %3451 = select <8 x i1> %119, <8 x i64> %.state698, <8 x i64> zeroinitializer
  %3452 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3453 = srem <8 x i64> %3451, %3452
  %3454 = load <8 x i64>, ptr %.spill237, align 64
  %3455 = select <8 x i1> %119, <8 x i64> %3453, <8 x i64> %3454
  store <8 x i64> %3455, ptr %.spill237, align 64
  %.state699 = load <8 x i64>, ptr %.slot236, align 64
  %3456 = select <8 x i1> %119, <8 x i64> %.state699, <8 x i64> zeroinitializer
  %3457 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3458 = sdiv <8 x i64> %3456, %3457
  %3459 = mul <8 x i64> %3453, splat (i64 8)
  %.spill.load700 = load <8 x i64>, ptr %.spill, align 64
  %3460 = add <8 x i64> %3459, %.spill.load700
  %3461 = icmp slt <8 x i64> %3460, splat (i64 33)
  %3462 = load <8 x i1>, ptr %.spill238, align 1
  %3463 = select <8 x i1> %119, <8 x i1> %3461, <8 x i1> %3462
  store <8 x i1> %3463, ptr %.spill238, align 1
  %3464 = select <8 x i1> %119, <8 x i64> %3458, <8 x i64> zeroinitializer
  %3465 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3466 = srem <8 x i64> %3464, %3465
  %3467 = load <8 x i64>, ptr %.spill239, align 64
  %3468 = select <8 x i1> %119, <8 x i64> %3466, <8 x i64> %3467
  store <8 x i64> %3468, ptr %.spill239, align 64
  store i64 0, ptr %.spill240, align 4
  %3469 = add <8 x i64> zeroinitializer, %3453
  %3470 = mul <8 x i64> %3469, splat (i64 2)
  %3471 = add <8 x i64> %3470, %3466
  %3472 = and <8 x i1> %119, %3461
  %3473 = xor <8 x i1> %3461, splat (i1 true)
  %3474 = and <8 x i1> %119, %3473
  %3475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3472)
  %3476 = bitcast <8 x i1> %3472 to i8
  %3477 = call i8 @llvm.cttz.i8(i8 %3476, i1 false)
  %3478 = zext i8 %3477 to i32
  %3479 = select i1 %3475, i32 %3478, i32 0
  %tile_snapshot.spill.load701 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill184, align 64
  %3480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load701, 0
  %3481 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load701, 1
  %3482 = add <8 x i64> %3481, %3471
  %3483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3480, 0
  %3484 = insertvalue { <8 x ptr>, <8 x i64> } %3483, <8 x i64> %3482, 1
  %3485 = extractvalue { <8 x ptr>, <8 x i64> } %3484, 0
  %3486 = extractvalue { <8 x ptr>, <8 x i64> } %3484, 1
  %3487 = getelementptr i8, <8 x ptr> %3485, <8 x i64> %3486
  %3488 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %3487, <8 x i1> %3472, <8 x i8> zeroinitializer)
  %3489 = icmp ne <8 x i8> %3488, zeroinitializer
  %3490 = load <8 x i1>, ptr %.slot241, align 1
  %3491 = select <8 x i1> %3472, <8 x i1> %3489, <8 x i1> %3490
  store <8 x i1> %3491, ptr %.slot241, align 1
  %3492 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3474)
  %3493 = bitcast <8 x i1> %3474 to i8
  %3494 = call i8 @llvm.cttz.i8(i8 %3493, i1 false)
  %3495 = zext i8 %3494 to i32
  %3496 = select i1 %3492, i32 %3495, i32 0
  %3497 = load <8 x i1>, ptr %.slot241, align 1
  %3498 = select <8 x i1> %3474, <8 x i1> zeroinitializer, <8 x i1> %3497
  store <8 x i1> %3498, ptr %.slot241, align 1
  br label %direct.schedule.194

direct.schedule.194:                              ; preds = %direct.schedule.192
  %.spill.load702 = load i64, ptr %.spill240, align 4
  %3499 = add i64 %.spill.load702, 0
  %3500 = mul i64 %3499, 1
  %3501 = add i64 %3500, 0
  %3502 = mul i64 %3501, 2
  %.splatinsert703 = insertelement <8 x i64> poison, i64 %3502, i64 0
  %.splat704 = shufflevector <8 x i64> %.splatinsert703, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load705 = load <8 x i64>, ptr %.spill239, align 64
  %3503 = add <8 x i64> %.splat704, %.spill.load705
  %3504 = mul <8 x i64> %3503, splat (i64 5)
  %.spill.load706 = load <8 x i64>, ptr %.spill237, align 64
  %3505 = add <8 x i64> %3504, %.spill.load706
  %.spill.load707 = load <8 x i1>, ptr %.spill238, align 1
  %3506 = and <8 x i1> %119, %.spill.load707
  %3507 = xor <8 x i1> %.spill.load707, splat (i1 true)
  %3508 = and <8 x i1> %119, %3507
  %3509 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3506)
  %3510 = bitcast <8 x i1> %3506 to i8
  %3511 = call i8 @llvm.cttz.i8(i8 %3510, i1 false)
  %3512 = zext i8 %3511 to i32
  %3513 = select i1 %3509, i32 %3512, i32 0
  %tile_snapshot.spill.load708 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill231, align 64
  %3514 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load708, 0
  %3515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load708, 1
  %3516 = mul <8 x i64> %3505, splat (i64 32)
  %3517 = add <8 x i64> %3515, %3516
  %3518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3514, 0
  %3519 = insertvalue { <8 x ptr>, <8 x i64> } %3518, <8 x i64> %3517, 1
  %3520 = extractvalue { <8 x ptr>, <8 x i64> } %3519, 0
  %3521 = extractvalue { <8 x ptr>, <8 x i64> } %3519, 1
  %3522 = getelementptr i8, <8 x ptr> %3520, <8 x i64> %3521
  %3523 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3522, <8 x i1> %3506, <8 x float> zeroinitializer)
  %3524 = load <8 x float>, ptr %.slot242, align 32
  %3525 = select <8 x i1> %3506, <8 x float> %3523, <8 x float> %3524
  store <8 x float> %3525, ptr %.slot242, align 32
  %3526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3508)
  %3527 = bitcast <8 x i1> %3508 to i8
  %3528 = call i8 @llvm.cttz.i8(i8 %3527, i1 false)
  %3529 = zext i8 %3528 to i32
  %3530 = select i1 %3526, i32 %3529, i32 0
  %3531 = load <8 x float>, ptr %.slot242, align 32
  %3532 = select <8 x i1> %3508, <8 x float> zeroinitializer, <8 x float> %3531
  store <8 x float> %3532, ptr %.slot242, align 32
  br label %direct.schedule.196

direct.schedule.196:                              ; preds = %direct.schedule.194
  %.state709 = load <8 x float>, ptr %.slot242, align 32
  %.state710 = load <8 x i1>, ptr %.slot241, align 1
  %3533 = select <8 x i1> %.state710, <8 x float> %.state709, <8 x float> zeroinitializer
  %.spill.load711 = load <8 x i1>, ptr %.spill238, align 1
  %3534 = and <8 x i1> %119, %.spill.load711
  %3535 = xor <8 x i1> %.spill.load711, splat (i1 true)
  %3536 = and <8 x i1> %119, %3535
  %3537 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3534)
  %3538 = bitcast <8 x i1> %3534 to i8
  %3539 = call i8 @llvm.cttz.i8(i8 %3538, i1 false)
  %3540 = zext i8 %3539 to i32
  %3541 = select i1 %3537, i32 %3540, i32 0
  %tile_snapshot.spill.load712 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill235, align 64
  %3542 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 0
  %3543 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load712, 1
  %.state713 = load <8 x i64>, ptr %.slot236, align 64
  %3544 = mul <8 x i64> %.state713, splat (i64 32)
  %3545 = add <8 x i64> %3543, %3544
  %3546 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3542, 0
  %3547 = insertvalue { <8 x ptr>, <8 x i64> } %3546, <8 x i64> %3545, 1
  %3548 = extractvalue { <8 x ptr>, <8 x i64> } %3547, 0
  %3549 = extractvalue { <8 x ptr>, <8 x i64> } %3547, 1
  %3550 = getelementptr i8, <8 x ptr> %3548, <8 x i64> %3549
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3533, <8 x ptr> align 1 %3550, <8 x i1> %3534)
  %3551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3536)
  %3552 = bitcast <8 x i1> %3536 to i8
  %3553 = call i8 @llvm.cttz.i8(i8 %3552, i1 false)
  %3554 = zext i8 %3553 to i32
  %3555 = select i1 %3551, i32 %3554, i32 0
  br label %direct.schedule.198

direct.schedule.198:                              ; preds = %direct.schedule.196
  %.state714 = load <8 x i64>, ptr %.slot236, align 64
  %3556 = add <8 x i64> %.state714, splat (i64 1)
  %3557 = load <8 x i64>, ptr %.slot236, align 64
  %3558 = select <8 x i1> %119, <8 x i64> %3556, <8 x i64> %3557
  store <8 x i64> %3558, ptr %.slot236, align 64
  br label %direct.schedule.191

direct.schedule.199:                              ; preds = %direct.false697
  %3559 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill243, align 64
  %3560 = extractvalue { <8 x ptr>, <8 x i64> } %61, 0
  %3561 = extractvalue { <8 x ptr>, <8 x i64> } %3559, 0
  %3562 = select <8 x i1> %119, <8 x ptr> %3560, <8 x ptr> %3561
  %3563 = extractvalue { <8 x ptr>, <8 x i64> } %61, 1
  %3564 = extractvalue { <8 x ptr>, <8 x i64> } %3559, 1
  %3565 = select <8 x i1> %119, <8 x i64> %3563, <8 x i64> %3564
  %3566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3562, 0
  %3567 = insertvalue { <8 x ptr>, <8 x i64> } %3566, <8 x i64> %3565, 1
  store { <8 x ptr>, <8 x i64> } %3567, ptr %tile_snapshot.spill243, align 64
  %3568 = load <8 x i64>, ptr %.slot244, align 64
  %3569 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3568
  store <8 x i64> %3569, ptr %.slot244, align 64
  br label %direct.schedule.200

direct.schedule.200:                              ; preds = %direct.schedule.207, %direct.schedule.199
  %.state715 = load <8 x i64>, ptr %.slot244, align 64
  %3570 = icmp slt <8 x i64> %.state715, splat (i64 1)
  %3571 = extractelement <8 x i1> %3570, i32 0
  br i1 %3571, label %direct.true716, label %direct.false717

direct.schedule.201:                              ; preds = %direct.true716
  %.state718 = load <8 x i64>, ptr %.slot244, align 64
  %3572 = select <8 x i1> %119, <8 x i64> %.state718, <8 x i64> zeroinitializer
  %3573 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3574 = srem <8 x i64> %3572, %3573
  %3575 = mul <8 x i64> %3574, splat (i64 8)
  %.spill.load719 = load <8 x i64>, ptr %.spill, align 64
  %3576 = add <8 x i64> %3575, %.spill.load719
  %3577 = icmp slt <8 x i64> %3576, splat (i64 2)
  %3578 = load <8 x i1>, ptr %.spill245, align 1
  %3579 = select <8 x i1> %119, <8 x i1> %3577, <8 x i1> %3578
  store <8 x i1> %3579, ptr %.spill245, align 1
  %3580 = add <8 x i64> zeroinitializer, %3574
  %3581 = load <8 x i64>, ptr %.spill246, align 64
  %3582 = select <8 x i1> %119, <8 x i64> %3580, <8 x i64> %3581
  store <8 x i64> %3582, ptr %.spill246, align 64
  %3583 = and <8 x i1> %119, %3577
  %3584 = xor <8 x i1> %3577, splat (i1 true)
  %3585 = and <8 x i1> %119, %3584
  %3586 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3583)
  %3587 = bitcast <8 x i1> %3583 to i8
  %3588 = call i8 @llvm.cttz.i8(i8 %3587, i1 false)
  %3589 = zext i8 %3588 to i32
  %3590 = select i1 %3586, i32 %3589, i32 0
  %tile_snapshot.spill.load720 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %3591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load720, 0
  %3592 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load720, 1
  %3593 = mul <8 x i64> %3580, splat (i64 32)
  %3594 = add <8 x i64> %3592, %3593
  %3595 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3591, 0
  %3596 = insertvalue { <8 x ptr>, <8 x i64> } %3595, <8 x i64> %3594, 1
  %3597 = extractvalue { <8 x ptr>, <8 x i64> } %3596, 0
  %3598 = extractvalue { <8 x ptr>, <8 x i64> } %3596, 1
  %3599 = getelementptr i8, <8 x ptr> %3597, <8 x i64> %3598
  %3600 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3599, <8 x i1> %3583, <8 x float> zeroinitializer)
  %3601 = load <8 x float>, ptr %.slot247, align 32
  %3602 = select <8 x i1> %3583, <8 x float> %3600, <8 x float> %3601
  store <8 x float> %3602, ptr %.slot247, align 32
  %3603 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3585)
  %3604 = bitcast <8 x i1> %3585 to i8
  %3605 = call i8 @llvm.cttz.i8(i8 %3604, i1 false)
  %3606 = zext i8 %3605 to i32
  %3607 = select i1 %3603, i32 %3606, i32 0
  %3608 = load <8 x float>, ptr %.slot247, align 32
  %3609 = select <8 x i1> %3585, <8 x float> zeroinitializer, <8 x float> %3608
  store <8 x float> %3609, ptr %.slot247, align 32
  br label %direct.schedule.203

direct.schedule.203:                              ; preds = %direct.schedule.201
  %.spill.load721 = load <8 x i1>, ptr %.spill245, align 1
  %3610 = and <8 x i1> %119, %.spill.load721
  %3611 = xor <8 x i1> %.spill.load721, splat (i1 true)
  %3612 = and <8 x i1> %119, %3611
  %3613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3610)
  %3614 = bitcast <8 x i1> %3610 to i8
  %3615 = call i8 @llvm.cttz.i8(i8 %3614, i1 false)
  %3616 = zext i8 %3615 to i32
  %3617 = select i1 %3613, i32 %3616, i32 0
  %tile_snapshot.spill.load722 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill219, align 64
  %3618 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load722, 0
  %3619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load722, 1
  %.spill.load723 = load <8 x i64>, ptr %.spill246, align 64
  %3620 = mul <8 x i64> %.spill.load723, splat (i64 32)
  %3621 = add <8 x i64> %3619, %3620
  %3622 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3618, 0
  %3623 = insertvalue { <8 x ptr>, <8 x i64> } %3622, <8 x i64> %3621, 1
  %3624 = extractvalue { <8 x ptr>, <8 x i64> } %3623, 0
  %3625 = extractvalue { <8 x ptr>, <8 x i64> } %3623, 1
  %3626 = getelementptr i8, <8 x ptr> %3624, <8 x i64> %3625
  %3627 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3626, <8 x i1> %3610, <8 x float> zeroinitializer)
  %3628 = load <8 x float>, ptr %.slot248, align 32
  %3629 = select <8 x i1> %3610, <8 x float> %3627, <8 x float> %3628
  store <8 x float> %3629, ptr %.slot248, align 32
  %3630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3612)
  %3631 = bitcast <8 x i1> %3612 to i8
  %3632 = call i8 @llvm.cttz.i8(i8 %3631, i1 false)
  %3633 = zext i8 %3632 to i32
  %3634 = select i1 %3630, i32 %3633, i32 0
  %3635 = load <8 x float>, ptr %.slot248, align 32
  %3636 = select <8 x i1> %3612, <8 x float> zeroinitializer, <8 x float> %3635
  store <8 x float> %3636, ptr %.slot248, align 32
  br label %direct.schedule.205

direct.schedule.205:                              ; preds = %direct.schedule.203
  %.state724 = load <8 x float>, ptr %.slot247, align 32
  %.state725 = load <8 x float>, ptr %.slot248, align 32
  %3637 = fmul <8 x float> %.state724, %.state725
  %.spill.load726 = load <8 x i1>, ptr %.spill245, align 1
  %3638 = and <8 x i1> %119, %.spill.load726
  %3639 = xor <8 x i1> %.spill.load726, splat (i1 true)
  %3640 = and <8 x i1> %119, %3639
  %3641 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3638)
  %3642 = bitcast <8 x i1> %3638 to i8
  %3643 = call i8 @llvm.cttz.i8(i8 %3642, i1 false)
  %3644 = zext i8 %3643 to i32
  %3645 = select i1 %3641, i32 %3644, i32 0
  %tile_snapshot.spill.load727 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill243, align 64
  %3646 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load727, 0
  %3647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load727, 1
  %.state728 = load <8 x i64>, ptr %.slot244, align 64
  %3648 = mul <8 x i64> %.state728, splat (i64 32)
  %3649 = add <8 x i64> %3647, %3648
  %3650 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3646, 0
  %3651 = insertvalue { <8 x ptr>, <8 x i64> } %3650, <8 x i64> %3649, 1
  %3652 = extractvalue { <8 x ptr>, <8 x i64> } %3651, 0
  %3653 = extractvalue { <8 x ptr>, <8 x i64> } %3651, 1
  %3654 = getelementptr i8, <8 x ptr> %3652, <8 x i64> %3653
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %3637, <8 x ptr> align 1 %3654, <8 x i1> %3638)
  %3655 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3640)
  %3656 = bitcast <8 x i1> %3640 to i8
  %3657 = call i8 @llvm.cttz.i8(i8 %3656, i1 false)
  %3658 = zext i8 %3657 to i32
  %3659 = select i1 %3655, i32 %3658, i32 0
  br label %direct.schedule.207

direct.schedule.207:                              ; preds = %direct.schedule.205
  %.state729 = load <8 x i64>, ptr %.slot244, align 64
  %3660 = add <8 x i64> %.state729, splat (i64 1)
  %3661 = load <8 x i64>, ptr %.slot244, align 64
  %3662 = select <8 x i1> %119, <8 x i64> %3660, <8 x i64> %3661
  store <8 x i64> %3662, ptr %.slot244, align 64
  br label %direct.schedule.200

direct.schedule.208:                              ; preds = %direct.false717
  %3663 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill249, align 64
  %3664 = extractvalue { <8 x ptr>, <8 x i64> } %63, 0
  %3665 = extractvalue { <8 x ptr>, <8 x i64> } %3663, 0
  %3666 = select <8 x i1> %119, <8 x ptr> %3664, <8 x ptr> %3665
  %3667 = extractvalue { <8 x ptr>, <8 x i64> } %63, 1
  %3668 = extractvalue { <8 x ptr>, <8 x i64> } %3663, 1
  %3669 = select <8 x i1> %119, <8 x i64> %3667, <8 x i64> %3668
  %3670 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3666, 0
  %3671 = insertvalue { <8 x ptr>, <8 x i64> } %3670, <8 x i64> %3669, 1
  store { <8 x ptr>, <8 x i64> } %3671, ptr %tile_snapshot.spill249, align 64
  %3672 = load <8 x i64>, ptr %.slot250, align 64
  %3673 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3672
  store <8 x i64> %3673, ptr %.slot250, align 64
  br label %direct.schedule.209

direct.schedule.209:                              ; preds = %direct.schedule.215, %direct.schedule.208
  %.state730 = load <8 x i64>, ptr %.slot250, align 64
  %3674 = icmp slt <8 x i64> %.state730, splat (i64 2)
  %3675 = extractelement <8 x i1> %3674, i32 0
  br i1 %3675, label %direct.true731, label %direct.false732

direct.schedule.210:                              ; preds = %direct.true731
  %.state733 = load <8 x i64>, ptr %.slot250, align 64
  %3676 = select <8 x i1> %119, <8 x i64> %.state733, <8 x i64> zeroinitializer
  %3677 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3678 = srem <8 x i64> %3676, %3677
  %.state734 = load <8 x i64>, ptr %.slot250, align 64
  %3679 = select <8 x i1> %119, <8 x i64> %.state734, <8 x i64> zeroinitializer
  %3680 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3681 = sdiv <8 x i64> %3679, %3680
  %3682 = select <8 x i1> %119, <8 x i64> %3681, <8 x i64> zeroinitializer
  %3683 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3684 = srem <8 x i64> %3682, %3683
  %3685 = select <8 x i1> %119, <8 x i64> %3681, <8 x i64> zeroinitializer
  %3686 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3687 = sdiv <8 x i64> %3685, %3686
  %3688 = select <8 x i1> %119, <8 x i64> %3687, <8 x i64> zeroinitializer
  %3689 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3690 = srem <8 x i64> %3688, %3689
  %3691 = add <8 x i64> zeroinitializer, %3690
  %3692 = mul <8 x i64> %3691, splat (i64 1)
  %3693 = add <8 x i64> %3692, %3684
  %3694 = mul <8 x i64> %3693, splat (i64 2)
  %3695 = add <8 x i64> %3694, %3678
  %3696 = load <8 x i64>, ptr %.spill251, align 64
  %3697 = select <8 x i1> %119, <8 x i64> %3695, <8 x i64> %3696
  store <8 x i64> %3697, ptr %.spill251, align 64
  %3698 = load <8 x i64>, ptr %.slot252, align 64
  %3699 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3698
  store <8 x i64> %3699, ptr %.slot252, align 64
  %3700 = load <8 x float>, ptr %.slot253, align 32
  %3701 = select <8 x i1> %119, <8 x float> zeroinitializer, <8 x float> %3700
  store <8 x float> %3701, ptr %.slot253, align 32
  %3702 = load <8 x i1>, ptr %.slot254, align 1
  %3703 = select <8 x i1> %119, <8 x i1> zeroinitializer, <8 x i1> %3702
  store <8 x i1> %3703, ptr %.slot254, align 1
  br label %direct.schedule.211

direct.schedule.211:                              ; preds = %direct.schedule.214, %direct.schedule.210
  %.state735 = load <8 x i64>, ptr %.slot252, align 64
  %3704 = icmp slt <8 x i64> %.state735, splat (i64 5)
  %3705 = extractelement <8 x i1> %3704, i32 0
  br i1 %3705, label %direct.true736, label %direct.false737

direct.schedule.212:                              ; preds = %direct.true736
  %.state738 = load <8 x i64>, ptr %.slot252, align 64
  %3706 = select <8 x i1> %119, <8 x i64> %.state738, <8 x i64> zeroinitializer
  %3707 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3708 = srem <8 x i64> %3706, %3707
  %3709 = mul <8 x i64> %3708, splat (i64 8)
  %.spill.load739 = load <8 x i64>, ptr %.spill, align 64
  %3710 = add <8 x i64> %3709, %.spill.load739
  %3711 = icmp slt <8 x i64> %3710, splat (i64 33)
  %3712 = load <8 x i1>, ptr %.spill255, align 1
  %3713 = select <8 x i1> %119, <8 x i1> %3711, <8 x i1> %3712
  store <8 x i1> %3713, ptr %.spill255, align 1
  %.spill.load740 = load <8 x i64>, ptr %.spill251, align 64
  %3714 = mul <8 x i64> %.spill.load740, splat (i64 5)
  %3715 = add <8 x i64> %3714, %3708
  %3716 = and <8 x i1> %119, %3711
  %3717 = xor <8 x i1> %3711, splat (i1 true)
  %3718 = and <8 x i1> %119, %3717
  %3719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3716)
  %3720 = bitcast <8 x i1> %3716 to i8
  %3721 = call i8 @llvm.cttz.i8(i8 %3720, i1 false)
  %3722 = zext i8 %3721 to i32
  %3723 = select i1 %3719, i32 %3722, i32 0
  %tile_snapshot.spill.load741 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill235, align 64
  %3724 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 0
  %3725 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load741, 1
  %3726 = mul <8 x i64> %3715, splat (i64 32)
  %3727 = add <8 x i64> %3725, %3726
  %3728 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3724, 0
  %3729 = insertvalue { <8 x ptr>, <8 x i64> } %3728, <8 x i64> %3727, 1
  %3730 = extractvalue { <8 x ptr>, <8 x i64> } %3729, 0
  %3731 = extractvalue { <8 x ptr>, <8 x i64> } %3729, 1
  %3732 = getelementptr i8, <8 x ptr> %3730, <8 x i64> %3731
  %3733 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3732, <8 x i1> %3716, <8 x float> zeroinitializer)
  %3734 = load <8 x float>, ptr %.slot256, align 32
  %3735 = select <8 x i1> %3716, <8 x float> %3733, <8 x float> %3734
  store <8 x float> %3735, ptr %.slot256, align 32
  %3736 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3718)
  %3737 = bitcast <8 x i1> %3718 to i8
  %3738 = call i8 @llvm.cttz.i8(i8 %3737, i1 false)
  %3739 = zext i8 %3738 to i32
  %3740 = select i1 %3736, i32 %3739, i32 0
  %3741 = load <8 x float>, ptr %.slot256, align 32
  %3742 = select <8 x i1> %3718, <8 x float> zeroinitializer, <8 x float> %3741
  store <8 x float> %3742, ptr %.slot256, align 32
  br label %direct.schedule.214

direct.schedule.214:                              ; preds = %direct.schedule.212
  %.state742 = load <8 x float>, ptr %.slot253, align 32
  %.state743 = load <8 x float>, ptr %.slot256, align 32
  %3743 = fadd <8 x float> %.state742, %.state743
  %.state744 = load <8 x float>, ptr %.slot256, align 32
  %.state745 = load <8 x i1>, ptr %.slot254, align 1
  %3744 = select <8 x i1> %.state745, <8 x float> %3743, <8 x float> %.state744
  %.state746 = load <8 x float>, ptr %.slot253, align 32
  %.spill.load747 = load <8 x i1>, ptr %.spill255, align 1
  %3745 = select <8 x i1> %.spill.load747, <8 x float> %3744, <8 x float> %.state746
  %.state748 = load <8 x i1>, ptr %.slot254, align 1
  %.spill.load749 = load <8 x i1>, ptr %.spill255, align 1
  %3746 = or <8 x i1> %.state748, %.spill.load749
  %.state750 = load <8 x i64>, ptr %.slot252, align 64
  %3747 = add <8 x i64> %.state750, splat (i64 1)
  %3748 = load <8 x i64>, ptr %.slot252, align 64
  %3749 = select <8 x i1> %119, <8 x i64> %3747, <8 x i64> %3748
  store <8 x i64> %3749, ptr %.slot252, align 64
  %3750 = load <8 x float>, ptr %.slot253, align 32
  %3751 = select <8 x i1> %119, <8 x float> %3745, <8 x float> %3750
  store <8 x float> %3751, ptr %.slot253, align 32
  %3752 = load <8 x i1>, ptr %.slot254, align 1
  %3753 = select <8 x i1> %119, <8 x i1> %3746, <8 x i1> %3752
  store <8 x i1> %3753, ptr %.slot254, align 1
  br label %direct.schedule.211

direct.schedule.215:                              ; preds = %direct.false737
  %.spill.load751 = load <8 x i64>, ptr %.spill, align 64
  %3754 = trunc <8 x i64> %.spill.load751 to <8 x i32>
  %3755 = xor <8 x i32> %3754, splat (i32 1)
  %.state752 = load <8 x float>, ptr %.slot253, align 32
  %3756 = extractelement <8 x i32> %3755, i64 0
  %3757 = icmp ult i32 %3756, 8
  %3758 = select i1 %3757, i32 %3756, i32 0
  %3759 = extractelement <8 x i1> %119, i32 %3758
  %3760 = extractelement <8 x i1> %119, i64 0
  %3761 = and i1 %3757, %3759
  %3762 = and i1 %3760, %3761
  %3763 = extractelement <8 x float> %.state752, i32 %3758
  %3764 = select i1 %3762, float %3763, float 0.000000e+00
  %3765 = insertelement <8 x float> poison, float %3764, i64 0
  %3766 = xor i1 %3762, true
  %3767 = and i1 %3760, %3766
  %3768 = insertelement <8 x i1> poison, i1 %3767, i64 0
  %3769 = extractelement <8 x i32> %3755, i64 1
  %3770 = icmp ult i32 %3769, 8
  %3771 = select i1 %3770, i32 %3769, i32 0
  %3772 = extractelement <8 x i1> %119, i32 %3771
  %3773 = extractelement <8 x i1> %119, i64 1
  %3774 = and i1 %3770, %3772
  %3775 = and i1 %3773, %3774
  %3776 = extractelement <8 x float> %.state752, i32 %3771
  %3777 = select i1 %3775, float %3776, float 0.000000e+00
  %3778 = insertelement <8 x float> %3765, float %3777, i64 1
  %3779 = xor i1 %3775, true
  %3780 = and i1 %3773, %3779
  %3781 = insertelement <8 x i1> %3768, i1 %3780, i64 1
  %3782 = extractelement <8 x i32> %3755, i64 2
  %3783 = icmp ult i32 %3782, 8
  %3784 = select i1 %3783, i32 %3782, i32 0
  %3785 = extractelement <8 x i1> %119, i32 %3784
  %3786 = extractelement <8 x i1> %119, i64 2
  %3787 = and i1 %3783, %3785
  %3788 = and i1 %3786, %3787
  %3789 = extractelement <8 x float> %.state752, i32 %3784
  %3790 = select i1 %3788, float %3789, float 0.000000e+00
  %3791 = insertelement <8 x float> %3778, float %3790, i64 2
  %3792 = xor i1 %3788, true
  %3793 = and i1 %3786, %3792
  %3794 = insertelement <8 x i1> %3781, i1 %3793, i64 2
  %3795 = extractelement <8 x i32> %3755, i64 3
  %3796 = icmp ult i32 %3795, 8
  %3797 = select i1 %3796, i32 %3795, i32 0
  %3798 = extractelement <8 x i1> %119, i32 %3797
  %3799 = extractelement <8 x i1> %119, i64 3
  %3800 = and i1 %3796, %3798
  %3801 = and i1 %3799, %3800
  %3802 = extractelement <8 x float> %.state752, i32 %3797
  %3803 = select i1 %3801, float %3802, float 0.000000e+00
  %3804 = insertelement <8 x float> %3791, float %3803, i64 3
  %3805 = xor i1 %3801, true
  %3806 = and i1 %3799, %3805
  %3807 = insertelement <8 x i1> %3794, i1 %3806, i64 3
  %3808 = extractelement <8 x i32> %3755, i64 4
  %3809 = icmp ult i32 %3808, 8
  %3810 = select i1 %3809, i32 %3808, i32 0
  %3811 = extractelement <8 x i1> %119, i32 %3810
  %3812 = extractelement <8 x i1> %119, i64 4
  %3813 = and i1 %3809, %3811
  %3814 = and i1 %3812, %3813
  %3815 = extractelement <8 x float> %.state752, i32 %3810
  %3816 = select i1 %3814, float %3815, float 0.000000e+00
  %3817 = insertelement <8 x float> %3804, float %3816, i64 4
  %3818 = xor i1 %3814, true
  %3819 = and i1 %3812, %3818
  %3820 = insertelement <8 x i1> %3807, i1 %3819, i64 4
  %3821 = extractelement <8 x i32> %3755, i64 5
  %3822 = icmp ult i32 %3821, 8
  %3823 = select i1 %3822, i32 %3821, i32 0
  %3824 = extractelement <8 x i1> %119, i32 %3823
  %3825 = extractelement <8 x i1> %119, i64 5
  %3826 = and i1 %3822, %3824
  %3827 = and i1 %3825, %3826
  %3828 = extractelement <8 x float> %.state752, i32 %3823
  %3829 = select i1 %3827, float %3828, float 0.000000e+00
  %3830 = insertelement <8 x float> %3817, float %3829, i64 5
  %3831 = xor i1 %3827, true
  %3832 = and i1 %3825, %3831
  %3833 = insertelement <8 x i1> %3820, i1 %3832, i64 5
  %3834 = extractelement <8 x i32> %3755, i64 6
  %3835 = icmp ult i32 %3834, 8
  %3836 = select i1 %3835, i32 %3834, i32 0
  %3837 = extractelement <8 x i1> %119, i32 %3836
  %3838 = extractelement <8 x i1> %119, i64 6
  %3839 = and i1 %3835, %3837
  %3840 = and i1 %3838, %3839
  %3841 = extractelement <8 x float> %.state752, i32 %3836
  %3842 = select i1 %3840, float %3841, float 0.000000e+00
  %3843 = insertelement <8 x float> %3830, float %3842, i64 6
  %3844 = xor i1 %3840, true
  %3845 = and i1 %3838, %3844
  %3846 = insertelement <8 x i1> %3833, i1 %3845, i64 6
  %3847 = extractelement <8 x i32> %3755, i64 7
  %3848 = icmp ult i32 %3847, 8
  %3849 = select i1 %3848, i32 %3847, i32 0
  %3850 = extractelement <8 x i1> %119, i32 %3849
  %3851 = extractelement <8 x i1> %119, i64 7
  %3852 = and i1 %3848, %3850
  %3853 = and i1 %3851, %3852
  %3854 = extractelement <8 x float> %.state752, i32 %3849
  %3855 = select i1 %3853, float %3854, float 0.000000e+00
  %3856 = insertelement <8 x float> %3843, float %3855, i64 7
  %3857 = xor i1 %3853, true
  %3858 = and i1 %3851, %3857
  %3859 = insertelement <8 x i1> %3846, i1 %3858, i64 7
  %.state753 = load <8 x float>, ptr %.slot253, align 32
  %3860 = fadd <8 x float> %.state753, %3856
  %.state754 = load <8 x i1>, ptr %.slot254, align 1
  %3861 = zext <8 x i1> %.state754 to <8 x i32>
  %3862 = extractelement <8 x i32> %3755, i64 0
  %3863 = icmp ult i32 %3862, 8
  %3864 = select i1 %3863, i32 %3862, i32 0
  %3865 = extractelement <8 x i1> %119, i32 %3864
  %3866 = extractelement <8 x i1> %119, i64 0
  %3867 = and i1 %3863, %3865
  %3868 = and i1 %3866, %3867
  %3869 = extractelement <8 x i32> %3861, i32 %3864
  %3870 = select i1 %3868, i32 %3869, i32 0
  %3871 = insertelement <8 x i32> poison, i32 %3870, i64 0
  %3872 = xor i1 %3868, true
  %3873 = and i1 %3866, %3872
  %3874 = insertelement <8 x i1> poison, i1 %3873, i64 0
  %3875 = extractelement <8 x i32> %3755, i64 1
  %3876 = icmp ult i32 %3875, 8
  %3877 = select i1 %3876, i32 %3875, i32 0
  %3878 = extractelement <8 x i1> %119, i32 %3877
  %3879 = extractelement <8 x i1> %119, i64 1
  %3880 = and i1 %3876, %3878
  %3881 = and i1 %3879, %3880
  %3882 = extractelement <8 x i32> %3861, i32 %3877
  %3883 = select i1 %3881, i32 %3882, i32 0
  %3884 = insertelement <8 x i32> %3871, i32 %3883, i64 1
  %3885 = xor i1 %3881, true
  %3886 = and i1 %3879, %3885
  %3887 = insertelement <8 x i1> %3874, i1 %3886, i64 1
  %3888 = extractelement <8 x i32> %3755, i64 2
  %3889 = icmp ult i32 %3888, 8
  %3890 = select i1 %3889, i32 %3888, i32 0
  %3891 = extractelement <8 x i1> %119, i32 %3890
  %3892 = extractelement <8 x i1> %119, i64 2
  %3893 = and i1 %3889, %3891
  %3894 = and i1 %3892, %3893
  %3895 = extractelement <8 x i32> %3861, i32 %3890
  %3896 = select i1 %3894, i32 %3895, i32 0
  %3897 = insertelement <8 x i32> %3884, i32 %3896, i64 2
  %3898 = xor i1 %3894, true
  %3899 = and i1 %3892, %3898
  %3900 = insertelement <8 x i1> %3887, i1 %3899, i64 2
  %3901 = extractelement <8 x i32> %3755, i64 3
  %3902 = icmp ult i32 %3901, 8
  %3903 = select i1 %3902, i32 %3901, i32 0
  %3904 = extractelement <8 x i1> %119, i32 %3903
  %3905 = extractelement <8 x i1> %119, i64 3
  %3906 = and i1 %3902, %3904
  %3907 = and i1 %3905, %3906
  %3908 = extractelement <8 x i32> %3861, i32 %3903
  %3909 = select i1 %3907, i32 %3908, i32 0
  %3910 = insertelement <8 x i32> %3897, i32 %3909, i64 3
  %3911 = xor i1 %3907, true
  %3912 = and i1 %3905, %3911
  %3913 = insertelement <8 x i1> %3900, i1 %3912, i64 3
  %3914 = extractelement <8 x i32> %3755, i64 4
  %3915 = icmp ult i32 %3914, 8
  %3916 = select i1 %3915, i32 %3914, i32 0
  %3917 = extractelement <8 x i1> %119, i32 %3916
  %3918 = extractelement <8 x i1> %119, i64 4
  %3919 = and i1 %3915, %3917
  %3920 = and i1 %3918, %3919
  %3921 = extractelement <8 x i32> %3861, i32 %3916
  %3922 = select i1 %3920, i32 %3921, i32 0
  %3923 = insertelement <8 x i32> %3910, i32 %3922, i64 4
  %3924 = xor i1 %3920, true
  %3925 = and i1 %3918, %3924
  %3926 = insertelement <8 x i1> %3913, i1 %3925, i64 4
  %3927 = extractelement <8 x i32> %3755, i64 5
  %3928 = icmp ult i32 %3927, 8
  %3929 = select i1 %3928, i32 %3927, i32 0
  %3930 = extractelement <8 x i1> %119, i32 %3929
  %3931 = extractelement <8 x i1> %119, i64 5
  %3932 = and i1 %3928, %3930
  %3933 = and i1 %3931, %3932
  %3934 = extractelement <8 x i32> %3861, i32 %3929
  %3935 = select i1 %3933, i32 %3934, i32 0
  %3936 = insertelement <8 x i32> %3923, i32 %3935, i64 5
  %3937 = xor i1 %3933, true
  %3938 = and i1 %3931, %3937
  %3939 = insertelement <8 x i1> %3926, i1 %3938, i64 5
  %3940 = extractelement <8 x i32> %3755, i64 6
  %3941 = icmp ult i32 %3940, 8
  %3942 = select i1 %3941, i32 %3940, i32 0
  %3943 = extractelement <8 x i1> %119, i32 %3942
  %3944 = extractelement <8 x i1> %119, i64 6
  %3945 = and i1 %3941, %3943
  %3946 = and i1 %3944, %3945
  %3947 = extractelement <8 x i32> %3861, i32 %3942
  %3948 = select i1 %3946, i32 %3947, i32 0
  %3949 = insertelement <8 x i32> %3936, i32 %3948, i64 6
  %3950 = xor i1 %3946, true
  %3951 = and i1 %3944, %3950
  %3952 = insertelement <8 x i1> %3939, i1 %3951, i64 6
  %3953 = extractelement <8 x i32> %3755, i64 7
  %3954 = icmp ult i32 %3953, 8
  %3955 = select i1 %3954, i32 %3953, i32 0
  %3956 = extractelement <8 x i1> %119, i32 %3955
  %3957 = extractelement <8 x i1> %119, i64 7
  %3958 = and i1 %3954, %3956
  %3959 = and i1 %3957, %3958
  %3960 = extractelement <8 x i32> %3861, i32 %3955
  %3961 = select i1 %3959, i32 %3960, i32 0
  %3962 = insertelement <8 x i32> %3949, i32 %3961, i64 7
  %3963 = xor i1 %3959, true
  %3964 = and i1 %3957, %3963
  %3965 = insertelement <8 x i1> %3952, i1 %3964, i64 7
  %3966 = icmp ne <8 x i32> %3962, zeroinitializer
  %.state755 = load <8 x float>, ptr %.slot253, align 32
  %.state756 = load <8 x i1>, ptr %.slot254, align 1
  %3967 = select <8 x i1> %.state756, <8 x float> %.state755, <8 x float> %3856
  %.state757 = load <8 x i1>, ptr %.slot254, align 1
  %3968 = and <8 x i1> %.state757, %3966
  %3969 = select <8 x i1> %3968, <8 x float> %3860, <8 x float> %3967
  %.state758 = load <8 x i1>, ptr %.slot254, align 1
  %3970 = or <8 x i1> %.state758, %3966
  %3971 = xor <8 x i32> %3754, splat (i32 2)
  %3972 = extractelement <8 x i32> %3971, i64 0
  %3973 = icmp ult i32 %3972, 8
  %3974 = select i1 %3973, i32 %3972, i32 0
  %3975 = extractelement <8 x i1> %119, i32 %3974
  %3976 = extractelement <8 x i1> %119, i64 0
  %3977 = and i1 %3973, %3975
  %3978 = and i1 %3976, %3977
  %3979 = extractelement <8 x float> %3969, i32 %3974
  %3980 = select i1 %3978, float %3979, float 0.000000e+00
  %3981 = insertelement <8 x float> poison, float %3980, i64 0
  %3982 = xor i1 %3978, true
  %3983 = and i1 %3976, %3982
  %3984 = insertelement <8 x i1> poison, i1 %3983, i64 0
  %3985 = extractelement <8 x i32> %3971, i64 1
  %3986 = icmp ult i32 %3985, 8
  %3987 = select i1 %3986, i32 %3985, i32 0
  %3988 = extractelement <8 x i1> %119, i32 %3987
  %3989 = extractelement <8 x i1> %119, i64 1
  %3990 = and i1 %3986, %3988
  %3991 = and i1 %3989, %3990
  %3992 = extractelement <8 x float> %3969, i32 %3987
  %3993 = select i1 %3991, float %3992, float 0.000000e+00
  %3994 = insertelement <8 x float> %3981, float %3993, i64 1
  %3995 = xor i1 %3991, true
  %3996 = and i1 %3989, %3995
  %3997 = insertelement <8 x i1> %3984, i1 %3996, i64 1
  %3998 = extractelement <8 x i32> %3971, i64 2
  %3999 = icmp ult i32 %3998, 8
  %4000 = select i1 %3999, i32 %3998, i32 0
  %4001 = extractelement <8 x i1> %119, i32 %4000
  %4002 = extractelement <8 x i1> %119, i64 2
  %4003 = and i1 %3999, %4001
  %4004 = and i1 %4002, %4003
  %4005 = extractelement <8 x float> %3969, i32 %4000
  %4006 = select i1 %4004, float %4005, float 0.000000e+00
  %4007 = insertelement <8 x float> %3994, float %4006, i64 2
  %4008 = xor i1 %4004, true
  %4009 = and i1 %4002, %4008
  %4010 = insertelement <8 x i1> %3997, i1 %4009, i64 2
  %4011 = extractelement <8 x i32> %3971, i64 3
  %4012 = icmp ult i32 %4011, 8
  %4013 = select i1 %4012, i32 %4011, i32 0
  %4014 = extractelement <8 x i1> %119, i32 %4013
  %4015 = extractelement <8 x i1> %119, i64 3
  %4016 = and i1 %4012, %4014
  %4017 = and i1 %4015, %4016
  %4018 = extractelement <8 x float> %3969, i32 %4013
  %4019 = select i1 %4017, float %4018, float 0.000000e+00
  %4020 = insertelement <8 x float> %4007, float %4019, i64 3
  %4021 = xor i1 %4017, true
  %4022 = and i1 %4015, %4021
  %4023 = insertelement <8 x i1> %4010, i1 %4022, i64 3
  %4024 = extractelement <8 x i32> %3971, i64 4
  %4025 = icmp ult i32 %4024, 8
  %4026 = select i1 %4025, i32 %4024, i32 0
  %4027 = extractelement <8 x i1> %119, i32 %4026
  %4028 = extractelement <8 x i1> %119, i64 4
  %4029 = and i1 %4025, %4027
  %4030 = and i1 %4028, %4029
  %4031 = extractelement <8 x float> %3969, i32 %4026
  %4032 = select i1 %4030, float %4031, float 0.000000e+00
  %4033 = insertelement <8 x float> %4020, float %4032, i64 4
  %4034 = xor i1 %4030, true
  %4035 = and i1 %4028, %4034
  %4036 = insertelement <8 x i1> %4023, i1 %4035, i64 4
  %4037 = extractelement <8 x i32> %3971, i64 5
  %4038 = icmp ult i32 %4037, 8
  %4039 = select i1 %4038, i32 %4037, i32 0
  %4040 = extractelement <8 x i1> %119, i32 %4039
  %4041 = extractelement <8 x i1> %119, i64 5
  %4042 = and i1 %4038, %4040
  %4043 = and i1 %4041, %4042
  %4044 = extractelement <8 x float> %3969, i32 %4039
  %4045 = select i1 %4043, float %4044, float 0.000000e+00
  %4046 = insertelement <8 x float> %4033, float %4045, i64 5
  %4047 = xor i1 %4043, true
  %4048 = and i1 %4041, %4047
  %4049 = insertelement <8 x i1> %4036, i1 %4048, i64 5
  %4050 = extractelement <8 x i32> %3971, i64 6
  %4051 = icmp ult i32 %4050, 8
  %4052 = select i1 %4051, i32 %4050, i32 0
  %4053 = extractelement <8 x i1> %119, i32 %4052
  %4054 = extractelement <8 x i1> %119, i64 6
  %4055 = and i1 %4051, %4053
  %4056 = and i1 %4054, %4055
  %4057 = extractelement <8 x float> %3969, i32 %4052
  %4058 = select i1 %4056, float %4057, float 0.000000e+00
  %4059 = insertelement <8 x float> %4046, float %4058, i64 6
  %4060 = xor i1 %4056, true
  %4061 = and i1 %4054, %4060
  %4062 = insertelement <8 x i1> %4049, i1 %4061, i64 6
  %4063 = extractelement <8 x i32> %3971, i64 7
  %4064 = icmp ult i32 %4063, 8
  %4065 = select i1 %4064, i32 %4063, i32 0
  %4066 = extractelement <8 x i1> %119, i32 %4065
  %4067 = extractelement <8 x i1> %119, i64 7
  %4068 = and i1 %4064, %4066
  %4069 = and i1 %4067, %4068
  %4070 = extractelement <8 x float> %3969, i32 %4065
  %4071 = select i1 %4069, float %4070, float 0.000000e+00
  %4072 = insertelement <8 x float> %4059, float %4071, i64 7
  %4073 = xor i1 %4069, true
  %4074 = and i1 %4067, %4073
  %4075 = insertelement <8 x i1> %4062, i1 %4074, i64 7
  %4076 = fadd <8 x float> %3969, %4072
  %4077 = zext <8 x i1> %3970 to <8 x i32>
  %4078 = extractelement <8 x i32> %3971, i64 0
  %4079 = icmp ult i32 %4078, 8
  %4080 = select i1 %4079, i32 %4078, i32 0
  %4081 = extractelement <8 x i1> %119, i32 %4080
  %4082 = extractelement <8 x i1> %119, i64 0
  %4083 = and i1 %4079, %4081
  %4084 = and i1 %4082, %4083
  %4085 = extractelement <8 x i32> %4077, i32 %4080
  %4086 = select i1 %4084, i32 %4085, i32 0
  %4087 = insertelement <8 x i32> poison, i32 %4086, i64 0
  %4088 = xor i1 %4084, true
  %4089 = and i1 %4082, %4088
  %4090 = insertelement <8 x i1> poison, i1 %4089, i64 0
  %4091 = extractelement <8 x i32> %3971, i64 1
  %4092 = icmp ult i32 %4091, 8
  %4093 = select i1 %4092, i32 %4091, i32 0
  %4094 = extractelement <8 x i1> %119, i32 %4093
  %4095 = extractelement <8 x i1> %119, i64 1
  %4096 = and i1 %4092, %4094
  %4097 = and i1 %4095, %4096
  %4098 = extractelement <8 x i32> %4077, i32 %4093
  %4099 = select i1 %4097, i32 %4098, i32 0
  %4100 = insertelement <8 x i32> %4087, i32 %4099, i64 1
  %4101 = xor i1 %4097, true
  %4102 = and i1 %4095, %4101
  %4103 = insertelement <8 x i1> %4090, i1 %4102, i64 1
  %4104 = extractelement <8 x i32> %3971, i64 2
  %4105 = icmp ult i32 %4104, 8
  %4106 = select i1 %4105, i32 %4104, i32 0
  %4107 = extractelement <8 x i1> %119, i32 %4106
  %4108 = extractelement <8 x i1> %119, i64 2
  %4109 = and i1 %4105, %4107
  %4110 = and i1 %4108, %4109
  %4111 = extractelement <8 x i32> %4077, i32 %4106
  %4112 = select i1 %4110, i32 %4111, i32 0
  %4113 = insertelement <8 x i32> %4100, i32 %4112, i64 2
  %4114 = xor i1 %4110, true
  %4115 = and i1 %4108, %4114
  %4116 = insertelement <8 x i1> %4103, i1 %4115, i64 2
  %4117 = extractelement <8 x i32> %3971, i64 3
  %4118 = icmp ult i32 %4117, 8
  %4119 = select i1 %4118, i32 %4117, i32 0
  %4120 = extractelement <8 x i1> %119, i32 %4119
  %4121 = extractelement <8 x i1> %119, i64 3
  %4122 = and i1 %4118, %4120
  %4123 = and i1 %4121, %4122
  %4124 = extractelement <8 x i32> %4077, i32 %4119
  %4125 = select i1 %4123, i32 %4124, i32 0
  %4126 = insertelement <8 x i32> %4113, i32 %4125, i64 3
  %4127 = xor i1 %4123, true
  %4128 = and i1 %4121, %4127
  %4129 = insertelement <8 x i1> %4116, i1 %4128, i64 3
  %4130 = extractelement <8 x i32> %3971, i64 4
  %4131 = icmp ult i32 %4130, 8
  %4132 = select i1 %4131, i32 %4130, i32 0
  %4133 = extractelement <8 x i1> %119, i32 %4132
  %4134 = extractelement <8 x i1> %119, i64 4
  %4135 = and i1 %4131, %4133
  %4136 = and i1 %4134, %4135
  %4137 = extractelement <8 x i32> %4077, i32 %4132
  %4138 = select i1 %4136, i32 %4137, i32 0
  %4139 = insertelement <8 x i32> %4126, i32 %4138, i64 4
  %4140 = xor i1 %4136, true
  %4141 = and i1 %4134, %4140
  %4142 = insertelement <8 x i1> %4129, i1 %4141, i64 4
  %4143 = extractelement <8 x i32> %3971, i64 5
  %4144 = icmp ult i32 %4143, 8
  %4145 = select i1 %4144, i32 %4143, i32 0
  %4146 = extractelement <8 x i1> %119, i32 %4145
  %4147 = extractelement <8 x i1> %119, i64 5
  %4148 = and i1 %4144, %4146
  %4149 = and i1 %4147, %4148
  %4150 = extractelement <8 x i32> %4077, i32 %4145
  %4151 = select i1 %4149, i32 %4150, i32 0
  %4152 = insertelement <8 x i32> %4139, i32 %4151, i64 5
  %4153 = xor i1 %4149, true
  %4154 = and i1 %4147, %4153
  %4155 = insertelement <8 x i1> %4142, i1 %4154, i64 5
  %4156 = extractelement <8 x i32> %3971, i64 6
  %4157 = icmp ult i32 %4156, 8
  %4158 = select i1 %4157, i32 %4156, i32 0
  %4159 = extractelement <8 x i1> %119, i32 %4158
  %4160 = extractelement <8 x i1> %119, i64 6
  %4161 = and i1 %4157, %4159
  %4162 = and i1 %4160, %4161
  %4163 = extractelement <8 x i32> %4077, i32 %4158
  %4164 = select i1 %4162, i32 %4163, i32 0
  %4165 = insertelement <8 x i32> %4152, i32 %4164, i64 6
  %4166 = xor i1 %4162, true
  %4167 = and i1 %4160, %4166
  %4168 = insertelement <8 x i1> %4155, i1 %4167, i64 6
  %4169 = extractelement <8 x i32> %3971, i64 7
  %4170 = icmp ult i32 %4169, 8
  %4171 = select i1 %4170, i32 %4169, i32 0
  %4172 = extractelement <8 x i1> %119, i32 %4171
  %4173 = extractelement <8 x i1> %119, i64 7
  %4174 = and i1 %4170, %4172
  %4175 = and i1 %4173, %4174
  %4176 = extractelement <8 x i32> %4077, i32 %4171
  %4177 = select i1 %4175, i32 %4176, i32 0
  %4178 = insertelement <8 x i32> %4165, i32 %4177, i64 7
  %4179 = xor i1 %4175, true
  %4180 = and i1 %4173, %4179
  %4181 = insertelement <8 x i1> %4168, i1 %4180, i64 7
  %4182 = icmp ne <8 x i32> %4178, zeroinitializer
  %4183 = select <8 x i1> %3970, <8 x float> %3969, <8 x float> %4072
  %4184 = and <8 x i1> %3970, %4182
  %4185 = select <8 x i1> %4184, <8 x float> %4076, <8 x float> %4183
  %4186 = or <8 x i1> %3970, %4182
  %4187 = xor <8 x i32> %3754, splat (i32 4)
  %4188 = extractelement <8 x i32> %4187, i64 0
  %4189 = icmp ult i32 %4188, 8
  %4190 = select i1 %4189, i32 %4188, i32 0
  %4191 = extractelement <8 x i1> %119, i32 %4190
  %4192 = extractelement <8 x i1> %119, i64 0
  %4193 = and i1 %4189, %4191
  %4194 = and i1 %4192, %4193
  %4195 = extractelement <8 x float> %4185, i32 %4190
  %4196 = select i1 %4194, float %4195, float 0.000000e+00
  %4197 = insertelement <8 x float> poison, float %4196, i64 0
  %4198 = xor i1 %4194, true
  %4199 = and i1 %4192, %4198
  %4200 = insertelement <8 x i1> poison, i1 %4199, i64 0
  %4201 = extractelement <8 x i32> %4187, i64 1
  %4202 = icmp ult i32 %4201, 8
  %4203 = select i1 %4202, i32 %4201, i32 0
  %4204 = extractelement <8 x i1> %119, i32 %4203
  %4205 = extractelement <8 x i1> %119, i64 1
  %4206 = and i1 %4202, %4204
  %4207 = and i1 %4205, %4206
  %4208 = extractelement <8 x float> %4185, i32 %4203
  %4209 = select i1 %4207, float %4208, float 0.000000e+00
  %4210 = insertelement <8 x float> %4197, float %4209, i64 1
  %4211 = xor i1 %4207, true
  %4212 = and i1 %4205, %4211
  %4213 = insertelement <8 x i1> %4200, i1 %4212, i64 1
  %4214 = extractelement <8 x i32> %4187, i64 2
  %4215 = icmp ult i32 %4214, 8
  %4216 = select i1 %4215, i32 %4214, i32 0
  %4217 = extractelement <8 x i1> %119, i32 %4216
  %4218 = extractelement <8 x i1> %119, i64 2
  %4219 = and i1 %4215, %4217
  %4220 = and i1 %4218, %4219
  %4221 = extractelement <8 x float> %4185, i32 %4216
  %4222 = select i1 %4220, float %4221, float 0.000000e+00
  %4223 = insertelement <8 x float> %4210, float %4222, i64 2
  %4224 = xor i1 %4220, true
  %4225 = and i1 %4218, %4224
  %4226 = insertelement <8 x i1> %4213, i1 %4225, i64 2
  %4227 = extractelement <8 x i32> %4187, i64 3
  %4228 = icmp ult i32 %4227, 8
  %4229 = select i1 %4228, i32 %4227, i32 0
  %4230 = extractelement <8 x i1> %119, i32 %4229
  %4231 = extractelement <8 x i1> %119, i64 3
  %4232 = and i1 %4228, %4230
  %4233 = and i1 %4231, %4232
  %4234 = extractelement <8 x float> %4185, i32 %4229
  %4235 = select i1 %4233, float %4234, float 0.000000e+00
  %4236 = insertelement <8 x float> %4223, float %4235, i64 3
  %4237 = xor i1 %4233, true
  %4238 = and i1 %4231, %4237
  %4239 = insertelement <8 x i1> %4226, i1 %4238, i64 3
  %4240 = extractelement <8 x i32> %4187, i64 4
  %4241 = icmp ult i32 %4240, 8
  %4242 = select i1 %4241, i32 %4240, i32 0
  %4243 = extractelement <8 x i1> %119, i32 %4242
  %4244 = extractelement <8 x i1> %119, i64 4
  %4245 = and i1 %4241, %4243
  %4246 = and i1 %4244, %4245
  %4247 = extractelement <8 x float> %4185, i32 %4242
  %4248 = select i1 %4246, float %4247, float 0.000000e+00
  %4249 = insertelement <8 x float> %4236, float %4248, i64 4
  %4250 = xor i1 %4246, true
  %4251 = and i1 %4244, %4250
  %4252 = insertelement <8 x i1> %4239, i1 %4251, i64 4
  %4253 = extractelement <8 x i32> %4187, i64 5
  %4254 = icmp ult i32 %4253, 8
  %4255 = select i1 %4254, i32 %4253, i32 0
  %4256 = extractelement <8 x i1> %119, i32 %4255
  %4257 = extractelement <8 x i1> %119, i64 5
  %4258 = and i1 %4254, %4256
  %4259 = and i1 %4257, %4258
  %4260 = extractelement <8 x float> %4185, i32 %4255
  %4261 = select i1 %4259, float %4260, float 0.000000e+00
  %4262 = insertelement <8 x float> %4249, float %4261, i64 5
  %4263 = xor i1 %4259, true
  %4264 = and i1 %4257, %4263
  %4265 = insertelement <8 x i1> %4252, i1 %4264, i64 5
  %4266 = extractelement <8 x i32> %4187, i64 6
  %4267 = icmp ult i32 %4266, 8
  %4268 = select i1 %4267, i32 %4266, i32 0
  %4269 = extractelement <8 x i1> %119, i32 %4268
  %4270 = extractelement <8 x i1> %119, i64 6
  %4271 = and i1 %4267, %4269
  %4272 = and i1 %4270, %4271
  %4273 = extractelement <8 x float> %4185, i32 %4268
  %4274 = select i1 %4272, float %4273, float 0.000000e+00
  %4275 = insertelement <8 x float> %4262, float %4274, i64 6
  %4276 = xor i1 %4272, true
  %4277 = and i1 %4270, %4276
  %4278 = insertelement <8 x i1> %4265, i1 %4277, i64 6
  %4279 = extractelement <8 x i32> %4187, i64 7
  %4280 = icmp ult i32 %4279, 8
  %4281 = select i1 %4280, i32 %4279, i32 0
  %4282 = extractelement <8 x i1> %119, i32 %4281
  %4283 = extractelement <8 x i1> %119, i64 7
  %4284 = and i1 %4280, %4282
  %4285 = and i1 %4283, %4284
  %4286 = extractelement <8 x float> %4185, i32 %4281
  %4287 = select i1 %4285, float %4286, float 0.000000e+00
  %4288 = insertelement <8 x float> %4275, float %4287, i64 7
  %4289 = xor i1 %4285, true
  %4290 = and i1 %4283, %4289
  %4291 = insertelement <8 x i1> %4278, i1 %4290, i64 7
  %4292 = fadd <8 x float> %4185, %4288
  %4293 = zext <8 x i1> %4186 to <8 x i32>
  %4294 = extractelement <8 x i32> %4187, i64 0
  %4295 = icmp ult i32 %4294, 8
  %4296 = select i1 %4295, i32 %4294, i32 0
  %4297 = extractelement <8 x i1> %119, i32 %4296
  %4298 = extractelement <8 x i1> %119, i64 0
  %4299 = and i1 %4295, %4297
  %4300 = and i1 %4298, %4299
  %4301 = extractelement <8 x i32> %4293, i32 %4296
  %4302 = select i1 %4300, i32 %4301, i32 0
  %4303 = insertelement <8 x i32> poison, i32 %4302, i64 0
  %4304 = xor i1 %4300, true
  %4305 = and i1 %4298, %4304
  %4306 = insertelement <8 x i1> poison, i1 %4305, i64 0
  %4307 = extractelement <8 x i32> %4187, i64 1
  %4308 = icmp ult i32 %4307, 8
  %4309 = select i1 %4308, i32 %4307, i32 0
  %4310 = extractelement <8 x i1> %119, i32 %4309
  %4311 = extractelement <8 x i1> %119, i64 1
  %4312 = and i1 %4308, %4310
  %4313 = and i1 %4311, %4312
  %4314 = extractelement <8 x i32> %4293, i32 %4309
  %4315 = select i1 %4313, i32 %4314, i32 0
  %4316 = insertelement <8 x i32> %4303, i32 %4315, i64 1
  %4317 = xor i1 %4313, true
  %4318 = and i1 %4311, %4317
  %4319 = insertelement <8 x i1> %4306, i1 %4318, i64 1
  %4320 = extractelement <8 x i32> %4187, i64 2
  %4321 = icmp ult i32 %4320, 8
  %4322 = select i1 %4321, i32 %4320, i32 0
  %4323 = extractelement <8 x i1> %119, i32 %4322
  %4324 = extractelement <8 x i1> %119, i64 2
  %4325 = and i1 %4321, %4323
  %4326 = and i1 %4324, %4325
  %4327 = extractelement <8 x i32> %4293, i32 %4322
  %4328 = select i1 %4326, i32 %4327, i32 0
  %4329 = insertelement <8 x i32> %4316, i32 %4328, i64 2
  %4330 = xor i1 %4326, true
  %4331 = and i1 %4324, %4330
  %4332 = insertelement <8 x i1> %4319, i1 %4331, i64 2
  %4333 = extractelement <8 x i32> %4187, i64 3
  %4334 = icmp ult i32 %4333, 8
  %4335 = select i1 %4334, i32 %4333, i32 0
  %4336 = extractelement <8 x i1> %119, i32 %4335
  %4337 = extractelement <8 x i1> %119, i64 3
  %4338 = and i1 %4334, %4336
  %4339 = and i1 %4337, %4338
  %4340 = extractelement <8 x i32> %4293, i32 %4335
  %4341 = select i1 %4339, i32 %4340, i32 0
  %4342 = insertelement <8 x i32> %4329, i32 %4341, i64 3
  %4343 = xor i1 %4339, true
  %4344 = and i1 %4337, %4343
  %4345 = insertelement <8 x i1> %4332, i1 %4344, i64 3
  %4346 = extractelement <8 x i32> %4187, i64 4
  %4347 = icmp ult i32 %4346, 8
  %4348 = select i1 %4347, i32 %4346, i32 0
  %4349 = extractelement <8 x i1> %119, i32 %4348
  %4350 = extractelement <8 x i1> %119, i64 4
  %4351 = and i1 %4347, %4349
  %4352 = and i1 %4350, %4351
  %4353 = extractelement <8 x i32> %4293, i32 %4348
  %4354 = select i1 %4352, i32 %4353, i32 0
  %4355 = insertelement <8 x i32> %4342, i32 %4354, i64 4
  %4356 = xor i1 %4352, true
  %4357 = and i1 %4350, %4356
  %4358 = insertelement <8 x i1> %4345, i1 %4357, i64 4
  %4359 = extractelement <8 x i32> %4187, i64 5
  %4360 = icmp ult i32 %4359, 8
  %4361 = select i1 %4360, i32 %4359, i32 0
  %4362 = extractelement <8 x i1> %119, i32 %4361
  %4363 = extractelement <8 x i1> %119, i64 5
  %4364 = and i1 %4360, %4362
  %4365 = and i1 %4363, %4364
  %4366 = extractelement <8 x i32> %4293, i32 %4361
  %4367 = select i1 %4365, i32 %4366, i32 0
  %4368 = insertelement <8 x i32> %4355, i32 %4367, i64 5
  %4369 = xor i1 %4365, true
  %4370 = and i1 %4363, %4369
  %4371 = insertelement <8 x i1> %4358, i1 %4370, i64 5
  %4372 = extractelement <8 x i32> %4187, i64 6
  %4373 = icmp ult i32 %4372, 8
  %4374 = select i1 %4373, i32 %4372, i32 0
  %4375 = extractelement <8 x i1> %119, i32 %4374
  %4376 = extractelement <8 x i1> %119, i64 6
  %4377 = and i1 %4373, %4375
  %4378 = and i1 %4376, %4377
  %4379 = extractelement <8 x i32> %4293, i32 %4374
  %4380 = select i1 %4378, i32 %4379, i32 0
  %4381 = insertelement <8 x i32> %4368, i32 %4380, i64 6
  %4382 = xor i1 %4378, true
  %4383 = and i1 %4376, %4382
  %4384 = insertelement <8 x i1> %4371, i1 %4383, i64 6
  %4385 = extractelement <8 x i32> %4187, i64 7
  %4386 = icmp ult i32 %4385, 8
  %4387 = select i1 %4386, i32 %4385, i32 0
  %4388 = extractelement <8 x i1> %119, i32 %4387
  %4389 = extractelement <8 x i1> %119, i64 7
  %4390 = and i1 %4386, %4388
  %4391 = and i1 %4389, %4390
  %4392 = extractelement <8 x i32> %4293, i32 %4387
  %4393 = select i1 %4391, i32 %4392, i32 0
  %4394 = insertelement <8 x i32> %4381, i32 %4393, i64 7
  %4395 = xor i1 %4391, true
  %4396 = and i1 %4389, %4395
  %4397 = insertelement <8 x i1> %4384, i1 %4396, i64 7
  %4398 = icmp ne <8 x i32> %4394, zeroinitializer
  %4399 = select <8 x i1> %4186, <8 x float> %4185, <8 x float> %4288
  %4400 = and <8 x i1> %4186, %4398
  %4401 = select <8 x i1> %4400, <8 x float> %4292, <8 x float> %4399
  %4402 = extractelement <8 x i1> %119, i32 0
  %4403 = extractelement <8 x i1> %119, i64 0
  %4404 = and i1 true, %4402
  %4405 = and i1 %4403, %4404
  %4406 = extractelement <8 x float> %4401, i32 0
  %4407 = select i1 %4405, float %4406, float 0.000000e+00
  %4408 = insertelement <8 x float> poison, float %4407, i64 0
  %4409 = xor i1 %4405, true
  %4410 = and i1 %4403, %4409
  %4411 = insertelement <8 x i1> poison, i1 %4410, i64 0
  %4412 = extractelement <8 x i1> %119, i32 0
  %4413 = extractelement <8 x i1> %119, i64 1
  %4414 = and i1 true, %4412
  %4415 = and i1 %4413, %4414
  %4416 = extractelement <8 x float> %4401, i32 0
  %4417 = select i1 %4415, float %4416, float 0.000000e+00
  %4418 = insertelement <8 x float> %4408, float %4417, i64 1
  %4419 = xor i1 %4415, true
  %4420 = and i1 %4413, %4419
  %4421 = insertelement <8 x i1> %4411, i1 %4420, i64 1
  %4422 = extractelement <8 x i1> %119, i32 0
  %4423 = extractelement <8 x i1> %119, i64 2
  %4424 = and i1 true, %4422
  %4425 = and i1 %4423, %4424
  %4426 = extractelement <8 x float> %4401, i32 0
  %4427 = select i1 %4425, float %4426, float 0.000000e+00
  %4428 = insertelement <8 x float> %4418, float %4427, i64 2
  %4429 = xor i1 %4425, true
  %4430 = and i1 %4423, %4429
  %4431 = insertelement <8 x i1> %4421, i1 %4430, i64 2
  %4432 = extractelement <8 x i1> %119, i32 0
  %4433 = extractelement <8 x i1> %119, i64 3
  %4434 = and i1 true, %4432
  %4435 = and i1 %4433, %4434
  %4436 = extractelement <8 x float> %4401, i32 0
  %4437 = select i1 %4435, float %4436, float 0.000000e+00
  %4438 = insertelement <8 x float> %4428, float %4437, i64 3
  %4439 = xor i1 %4435, true
  %4440 = and i1 %4433, %4439
  %4441 = insertelement <8 x i1> %4431, i1 %4440, i64 3
  %4442 = extractelement <8 x i1> %119, i32 0
  %4443 = extractelement <8 x i1> %119, i64 4
  %4444 = and i1 true, %4442
  %4445 = and i1 %4443, %4444
  %4446 = extractelement <8 x float> %4401, i32 0
  %4447 = select i1 %4445, float %4446, float 0.000000e+00
  %4448 = insertelement <8 x float> %4438, float %4447, i64 4
  %4449 = xor i1 %4445, true
  %4450 = and i1 %4443, %4449
  %4451 = insertelement <8 x i1> %4441, i1 %4450, i64 4
  %4452 = extractelement <8 x i1> %119, i32 0
  %4453 = extractelement <8 x i1> %119, i64 5
  %4454 = and i1 true, %4452
  %4455 = and i1 %4453, %4454
  %4456 = extractelement <8 x float> %4401, i32 0
  %4457 = select i1 %4455, float %4456, float 0.000000e+00
  %4458 = insertelement <8 x float> %4448, float %4457, i64 5
  %4459 = xor i1 %4455, true
  %4460 = and i1 %4453, %4459
  %4461 = insertelement <8 x i1> %4451, i1 %4460, i64 5
  %4462 = extractelement <8 x i1> %119, i32 0
  %4463 = extractelement <8 x i1> %119, i64 6
  %4464 = and i1 true, %4462
  %4465 = and i1 %4463, %4464
  %4466 = extractelement <8 x float> %4401, i32 0
  %4467 = select i1 %4465, float %4466, float 0.000000e+00
  %4468 = insertelement <8 x float> %4458, float %4467, i64 6
  %4469 = xor i1 %4465, true
  %4470 = and i1 %4463, %4469
  %4471 = insertelement <8 x i1> %4461, i1 %4470, i64 6
  %4472 = extractelement <8 x i1> %119, i32 0
  %4473 = extractelement <8 x i1> %119, i64 7
  %4474 = and i1 true, %4472
  %4475 = and i1 %4473, %4474
  %4476 = extractelement <8 x float> %4401, i32 0
  %4477 = select i1 %4475, float %4476, float 0.000000e+00
  %4478 = insertelement <8 x float> %4468, float %4477, i64 7
  %4479 = xor i1 %4475, true
  %4480 = and i1 %4473, %4479
  %4481 = insertelement <8 x i1> %4471, i1 %4480, i64 7
  %4482 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  %4483 = bitcast <8 x i1> %119 to i8
  %4484 = call i8 @llvm.cttz.i8(i8 %4483, i1 false)
  %4485 = zext i8 %4484 to i32
  %4486 = select i1 %4482, i32 %4485, i32 0
  %4487 = extractelement <8 x float> %4478, i32 %4486
  %4488 = fadd float 0.000000e+00, %4487
  %tile_snapshot.spill.load759 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill249, align 64
  %4489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load759, 0
  %4490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load759, 1
  %.state760 = load <8 x i64>, ptr %.slot250, align 64
  %4491 = mul <8 x i64> %.state760, splat (i64 32)
  %4492 = add <8 x i64> %4490, %4491
  %4493 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4489, 0
  %4494 = insertvalue { <8 x ptr>, <8 x i64> } %4493, <8 x i64> %4492, 1
  %.splatinsert761 = insertelement <8 x float> poison, float %4488, i64 0
  %.splat762 = shufflevector <8 x float> %.splatinsert761, <8 x float> poison, <8 x i32> zeroinitializer
  %4495 = extractvalue { <8 x ptr>, <8 x i64> } %4494, 0
  %4496 = extractvalue { <8 x ptr>, <8 x i64> } %4494, 1
  %4497 = getelementptr i8, <8 x ptr> %4495, <8 x i64> %4496
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.splat762, <8 x ptr> align 1 %4497, <8 x i1> %119)
  %.state763 = load <8 x i64>, ptr %.slot250, align 64
  %4498 = add <8 x i64> %.state763, splat (i64 1)
  %4499 = load <8 x i64>, ptr %.slot250, align 64
  %4500 = select <8 x i1> %119, <8 x i64> %4498, <8 x i64> %4499
  store <8 x i64> %4500, ptr %.slot250, align 64
  br label %direct.schedule.209

direct.schedule.216:                              ; preds = %direct.false732
  %4501 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill257, align 64
  %4502 = extractvalue { <8 x ptr>, <8 x i64> } %65, 0
  %4503 = extractvalue { <8 x ptr>, <8 x i64> } %4501, 0
  %4504 = select <8 x i1> %119, <8 x ptr> %4502, <8 x ptr> %4503
  %4505 = extractvalue { <8 x ptr>, <8 x i64> } %65, 1
  %4506 = extractvalue { <8 x ptr>, <8 x i64> } %4501, 1
  %4507 = select <8 x i1> %119, <8 x i64> %4505, <8 x i64> %4506
  %4508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4504, 0
  %4509 = insertvalue { <8 x ptr>, <8 x i64> } %4508, <8 x i64> %4507, 1
  store { <8 x ptr>, <8 x i64> } %4509, ptr %tile_snapshot.spill257, align 64
  %4510 = load <8 x i64>, ptr %.slot258, align 64
  %4511 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %4510
  store <8 x i64> %4511, ptr %.slot258, align 64
  br label %direct.schedule.217

direct.schedule.217:                              ; preds = %direct.schedule.224, %direct.schedule.216
  %.state764 = load <8 x i64>, ptr %.slot258, align 64
  %4512 = icmp slt <8 x i64> %.state764, splat (i64 1)
  %4513 = extractelement <8 x i1> %4512, i32 0
  br i1 %4513, label %direct.true765, label %direct.false766

direct.schedule.218:                              ; preds = %direct.true765
  %.state767 = load <8 x i64>, ptr %.slot258, align 64
  %4514 = select <8 x i1> %119, <8 x i64> %.state767, <8 x i64> zeroinitializer
  %4515 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4516 = srem <8 x i64> %4514, %4515
  %4517 = mul <8 x i64> %4516, splat (i64 8)
  %.spill.load768 = load <8 x i64>, ptr %.spill, align 64
  %4518 = add <8 x i64> %4517, %.spill.load768
  %4519 = icmp slt <8 x i64> %4518, splat (i64 2)
  %4520 = load <8 x i1>, ptr %.spill259, align 1
  %4521 = select <8 x i1> %119, <8 x i1> %4519, <8 x i1> %4520
  store <8 x i1> %4521, ptr %.spill259, align 1
  %4522 = select <8 x i1> %4519, <8 x i64> %4518, <8 x i64> splat (i64 1)
  %4523 = add <8 x i64> zeroinitializer, %4522
  %4524 = load <8 x i64>, ptr %.spill260, align 64
  %4525 = select <8 x i1> %119, <8 x i64> %4523, <8 x i64> %4524
  store <8 x i64> %4525, ptr %.spill260, align 64
  %4526 = add <8 x i64> zeroinitializer, %4516
  %4527 = and <8 x i1> %119, %4519
  %4528 = xor <8 x i1> %4519, splat (i1 true)
  %4529 = and <8 x i1> %119, %4528
  %4530 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4527)
  %4531 = bitcast <8 x i1> %4527 to i8
  %4532 = call i8 @llvm.cttz.i8(i8 %4531, i1 false)
  %4533 = zext i8 %4532 to i32
  %4534 = select i1 %4530, i32 %4533, i32 0
  %tile_snapshot.spill.load769 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill243, align 64
  %4535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 0
  %4536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load769, 1
  %4537 = mul <8 x i64> %4526, splat (i64 32)
  %4538 = add <8 x i64> %4536, %4537
  %4539 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4535, 0
  %4540 = insertvalue { <8 x ptr>, <8 x i64> } %4539, <8 x i64> %4538, 1
  %4541 = extractvalue { <8 x ptr>, <8 x i64> } %4540, 0
  %4542 = extractvalue { <8 x ptr>, <8 x i64> } %4540, 1
  %4543 = getelementptr i8, <8 x ptr> %4541, <8 x i64> %4542
  %4544 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4543, <8 x i1> %4527, <8 x float> zeroinitializer)
  %4545 = load <8 x float>, ptr %.slot261, align 32
  %4546 = select <8 x i1> %4527, <8 x float> %4544, <8 x float> %4545
  store <8 x float> %4546, ptr %.slot261, align 32
  %4547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4529)
  %4548 = bitcast <8 x i1> %4529 to i8
  %4549 = call i8 @llvm.cttz.i8(i8 %4548, i1 false)
  %4550 = zext i8 %4549 to i32
  %4551 = select i1 %4547, i32 %4550, i32 0
  %4552 = load <8 x float>, ptr %.slot261, align 32
  %4553 = select <8 x i1> %4529, <8 x float> zeroinitializer, <8 x float> %4552
  store <8 x float> %4553, ptr %.slot261, align 32
  br label %direct.schedule.220

direct.schedule.220:                              ; preds = %direct.schedule.218
  %.spill.load770 = load <8 x i1>, ptr %.spill259, align 1
  %4554 = and <8 x i1> %119, %.spill.load770
  %4555 = xor <8 x i1> %.spill.load770, splat (i1 true)
  %4556 = and <8 x i1> %119, %4555
  %4557 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4554)
  %4558 = bitcast <8 x i1> %4554 to i8
  %4559 = call i8 @llvm.cttz.i8(i8 %4558, i1 false)
  %4560 = zext i8 %4559 to i32
  %4561 = select i1 %4557, i32 %4560, i32 0
  %tile_snapshot.spill.load771 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill249, align 64
  %4562 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load771, 0
  %4563 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load771, 1
  %.spill.load772 = load <8 x i64>, ptr %.spill260, align 64
  %4564 = mul <8 x i64> %.spill.load772, splat (i64 32)
  %4565 = add <8 x i64> %4563, %4564
  %4566 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4562, 0
  %4567 = insertvalue { <8 x ptr>, <8 x i64> } %4566, <8 x i64> %4565, 1
  %4568 = extractvalue { <8 x ptr>, <8 x i64> } %4567, 0
  %4569 = extractvalue { <8 x ptr>, <8 x i64> } %4567, 1
  %4570 = getelementptr i8, <8 x ptr> %4568, <8 x i64> %4569
  %4571 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4570, <8 x i1> %4554, <8 x float> zeroinitializer)
  %4572 = load <8 x float>, ptr %.slot262, align 32
  %4573 = select <8 x i1> %4554, <8 x float> %4571, <8 x float> %4572
  store <8 x float> %4573, ptr %.slot262, align 32
  %4574 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4556)
  %4575 = bitcast <8 x i1> %4556 to i8
  %4576 = call i8 @llvm.cttz.i8(i8 %4575, i1 false)
  %4577 = zext i8 %4576 to i32
  %4578 = select i1 %4574, i32 %4577, i32 0
  %4579 = load <8 x float>, ptr %.slot262, align 32
  %4580 = select <8 x i1> %4556, <8 x float> zeroinitializer, <8 x float> %4579
  store <8 x float> %4580, ptr %.slot262, align 32
  br label %direct.schedule.222

direct.schedule.222:                              ; preds = %direct.schedule.220
  %.state773 = load <8 x float>, ptr %.slot261, align 32
  %.state774 = load <8 x float>, ptr %.slot262, align 32
  %4581 = fadd <8 x float> %.state773, %.state774
  %.spill.load775 = load <8 x i1>, ptr %.spill259, align 1
  %4582 = and <8 x i1> %119, %.spill.load775
  %4583 = xor <8 x i1> %.spill.load775, splat (i1 true)
  %4584 = and <8 x i1> %119, %4583
  %4585 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4582)
  %4586 = bitcast <8 x i1> %4582 to i8
  %4587 = call i8 @llvm.cttz.i8(i8 %4586, i1 false)
  %4588 = zext i8 %4587 to i32
  %4589 = select i1 %4585, i32 %4588, i32 0
  %tile_snapshot.spill.load776 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill257, align 64
  %4590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 0
  %4591 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load776, 1
  %.state777 = load <8 x i64>, ptr %.slot258, align 64
  %4592 = mul <8 x i64> %.state777, splat (i64 32)
  %4593 = add <8 x i64> %4591, %4592
  %4594 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4590, 0
  %4595 = insertvalue { <8 x ptr>, <8 x i64> } %4594, <8 x i64> %4593, 1
  %4596 = extractvalue { <8 x ptr>, <8 x i64> } %4595, 0
  %4597 = extractvalue { <8 x ptr>, <8 x i64> } %4595, 1
  %4598 = getelementptr i8, <8 x ptr> %4596, <8 x i64> %4597
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %4581, <8 x ptr> align 1 %4598, <8 x i1> %4582)
  %4599 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4584)
  %4600 = bitcast <8 x i1> %4584 to i8
  %4601 = call i8 @llvm.cttz.i8(i8 %4600, i1 false)
  %4602 = zext i8 %4601 to i32
  %4603 = select i1 %4599, i32 %4602, i32 0
  br label %direct.schedule.224

direct.schedule.224:                              ; preds = %direct.schedule.222
  %.state778 = load <8 x i64>, ptr %.slot258, align 64
  %4604 = add <8 x i64> %.state778, splat (i64 1)
  %4605 = load <8 x i64>, ptr %.slot258, align 64
  %4606 = select <8 x i1> %119, <8 x i64> %4604, <8 x i64> %4605
  store <8 x i64> %4606, ptr %.slot258, align 64
  br label %direct.schedule.217

direct.schedule.225:                              ; preds = %direct.false766
  %4607 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %4608 = extractvalue { <8 x ptr>, <8 x i64> } %67, 0
  %4609 = extractvalue { <8 x ptr>, <8 x i64> } %4607, 0
  %4610 = select <8 x i1> %119, <8 x ptr> %4608, <8 x ptr> %4609
  %4611 = extractvalue { <8 x ptr>, <8 x i64> } %67, 1
  %4612 = extractvalue { <8 x ptr>, <8 x i64> } %4607, 1
  %4613 = select <8 x i1> %119, <8 x i64> %4611, <8 x i64> %4612
  %4614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4610, 0
  %4615 = insertvalue { <8 x ptr>, <8 x i64> } %4614, <8 x i64> %4613, 1
  store { <8 x ptr>, <8 x i64> } %4615, ptr %tile_snapshot.spill263, align 64
  %4616 = load <8 x i64>, ptr %.slot264, align 64
  %4617 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %4616
  store <8 x i64> %4617, ptr %.slot264, align 64
  br label %direct.schedule.226

direct.schedule.226:                              ; preds = %direct.schedule.233, %direct.schedule.225
  %.state779 = load <8 x i64>, ptr %.slot264, align 64
  %4618 = icmp slt <8 x i64> %.state779, splat (i64 2)
  %4619 = extractelement <8 x i1> %4618, i32 0
  br i1 %4619, label %direct.true780, label %direct.false781

direct.schedule.227:                              ; preds = %direct.true780
  %.state782 = load <8 x i64>, ptr %.slot264, align 64
  %4620 = select <8 x i1> %119, <8 x i64> %.state782, <8 x i64> zeroinitializer
  %4621 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4622 = srem <8 x i64> %4620, %4621
  %.state783 = load <8 x i64>, ptr %.slot264, align 64
  %4623 = select <8 x i1> %119, <8 x i64> %.state783, <8 x i64> zeroinitializer
  %4624 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4625 = sdiv <8 x i64> %4623, %4624
  %4626 = mul <8 x i64> %4622, splat (i64 8)
  %.spill.load784 = load <8 x i64>, ptr %.spill, align 64
  %4627 = add <8 x i64> %4626, %.spill.load784
  %4628 = icmp slt <8 x i64> %4627, splat (i64 3)
  %4629 = load <8 x i1>, ptr %.spill265, align 1
  %4630 = select <8 x i1> %119, <8 x i1> %4628, <8 x i1> %4629
  store <8 x i1> %4630, ptr %.spill265, align 1
  %4631 = select <8 x i1> %119, <8 x i64> %4625, <8 x i64> zeroinitializer
  %4632 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %4633 = srem <8 x i64> %4631, %4632
  %4634 = load <8 x i64>, ptr %.spill266, align 64
  %4635 = select <8 x i1> %119, <8 x i64> %4633, <8 x i64> %4634
  store <8 x i64> %4635, ptr %.spill266, align 64
  store i64 0, ptr %.spill267, align 4
  %4636 = add <8 x i64> zeroinitializer, %4633
  %4637 = mul <8 x i64> %4636, splat (i64 1)
  %4638 = add <8 x i64> %4637, %4622
  %4639 = and <8 x i1> %119, %4628
  %4640 = xor <8 x i1> %4628, splat (i1 true)
  %4641 = and <8 x i1> %119, %4640
  %4642 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4639)
  %4643 = bitcast <8 x i1> %4639 to i8
  %4644 = call i8 @llvm.cttz.i8(i8 %4643, i1 false)
  %4645 = zext i8 %4644 to i32
  %4646 = select i1 %4642, i32 %4645, i32 0
  %tile_snapshot.spill.load785 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %4647 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load785, 0
  %4648 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load785, 1
  %4649 = mul <8 x i64> %4638, splat (i64 32)
  %4650 = add <8 x i64> %4648, %4649
  %4651 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4647, 0
  %4652 = insertvalue { <8 x ptr>, <8 x i64> } %4651, <8 x i64> %4650, 1
  %4653 = extractvalue { <8 x ptr>, <8 x i64> } %4652, 0
  %4654 = extractvalue { <8 x ptr>, <8 x i64> } %4652, 1
  %4655 = getelementptr i8, <8 x ptr> %4653, <8 x i64> %4654
  %4656 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4655, <8 x i1> %4639, <8 x float> zeroinitializer)
  %4657 = load <8 x float>, ptr %.slot268, align 32
  %4658 = select <8 x i1> %4639, <8 x float> %4656, <8 x float> %4657
  store <8 x float> %4658, ptr %.slot268, align 32
  %4659 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4641)
  %4660 = bitcast <8 x i1> %4641 to i8
  %4661 = call i8 @llvm.cttz.i8(i8 %4660, i1 false)
  %4662 = zext i8 %4661 to i32
  %4663 = select i1 %4659, i32 %4662, i32 0
  %4664 = load <8 x float>, ptr %.slot268, align 32
  %4665 = select <8 x i1> %4641, <8 x float> zeroinitializer, <8 x float> %4664
  store <8 x float> %4665, ptr %.slot268, align 32
  br label %direct.schedule.229

direct.schedule.229:                              ; preds = %direct.schedule.227
  %.spill.load786 = load <8 x i64>, ptr %.spill266, align 64
  %4666 = select <8 x i1> %119, <8 x i64> %.spill.load786, <8 x i64> zeroinitializer
  %4667 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %4668 = sdiv <8 x i64> %4666, %4667
  %.spill.load787 = load i64, ptr %.spill267, align 4
  %4669 = mul i64 %.spill.load787, 1
  %.splatinsert788 = insertelement <8 x i64> poison, i64 %4669, i64 0
  %.splat789 = shufflevector <8 x i64> %.splatinsert788, <8 x i64> poison, <8 x i32> zeroinitializer
  %4670 = add <8 x i64> %.splat789, %4668
  %.spill.load790 = load <8 x i64>, ptr %.spill266, align 64
  %4671 = select <8 x i1> %119, <8 x i64> %.spill.load790, <8 x i64> zeroinitializer
  %4672 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %4673 = srem <8 x i64> %4671, %4672
  %4674 = load <8 x i64>, ptr %.spill269, align 64
  %4675 = select <8 x i1> %119, <8 x i64> %4673, <8 x i64> %4674
  store <8 x i64> %4675, ptr %.spill269, align 64
  %.spill.load791 = load <8 x i64>, ptr %.spill, align 64
  %4676 = icmp eq <8 x i64> %.spill.load791, %4673
  %4677 = and <8 x i1> %119, %4676
  %4678 = xor <8 x i1> %4676, splat (i1 true)
  %4679 = and <8 x i1> %119, %4678
  %4680 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4677)
  %4681 = bitcast <8 x i1> %4677 to i8
  %4682 = call i8 @llvm.cttz.i8(i8 %4681, i1 false)
  %4683 = zext i8 %4682 to i32
  %4684 = select i1 %4680, i32 %4683, i32 0
  %tile_snapshot.spill.load792 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill219, align 64
  %4685 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load792, 0
  %4686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load792, 1
  %4687 = mul <8 x i64> %4670, splat (i64 32)
  %4688 = add <8 x i64> %4686, %4687
  %4689 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4685, 0
  %4690 = insertvalue { <8 x ptr>, <8 x i64> } %4689, <8 x i64> %4688, 1
  %4691 = extractvalue { <8 x ptr>, <8 x i64> } %4690, 0
  %4692 = extractvalue { <8 x ptr>, <8 x i64> } %4690, 1
  %4693 = getelementptr i8, <8 x ptr> %4691, <8 x i64> %4692
  %4694 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4693, <8 x i1> %4677, <8 x float> zeroinitializer)
  %4695 = load <8 x float>, ptr %.slot270, align 32
  %4696 = select <8 x i1> %4677, <8 x float> %4694, <8 x float> %4695
  store <8 x float> %4696, ptr %.slot270, align 32
  %4697 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4679)
  %4698 = bitcast <8 x i1> %4679 to i8
  %4699 = call i8 @llvm.cttz.i8(i8 %4698, i1 false)
  %4700 = zext i8 %4699 to i32
  %4701 = select i1 %4697, i32 %4700, i32 0
  %4702 = load <8 x float>, ptr %.slot270, align 32
  %4703 = select <8 x i1> %4679, <8 x float> zeroinitializer, <8 x float> %4702
  store <8 x float> %4703, ptr %.slot270, align 32
  br label %direct.schedule.231

direct.schedule.231:                              ; preds = %direct.schedule.229
  %.spill.load793 = load <8 x i64>, ptr %.spill269, align 64
  %4704 = trunc <8 x i64> %.spill.load793 to <8 x i32>
  %.state794 = load <8 x float>, ptr %.slot270, align 32
  %4705 = extractelement <8 x i32> %4704, i64 0
  %4706 = icmp ult i32 %4705, 8
  %4707 = select i1 %4706, i32 %4705, i32 0
  %4708 = extractelement <8 x i1> %119, i32 %4707
  %4709 = extractelement <8 x i1> %119, i64 0
  %4710 = and i1 %4706, %4708
  %4711 = and i1 %4709, %4710
  %4712 = extractelement <8 x float> %.state794, i32 %4707
  %4713 = select i1 %4711, float %4712, float 0.000000e+00
  %4714 = insertelement <8 x float> poison, float %4713, i64 0
  %4715 = xor i1 %4711, true
  %4716 = and i1 %4709, %4715
  %4717 = insertelement <8 x i1> poison, i1 %4716, i64 0
  %4718 = extractelement <8 x i32> %4704, i64 1
  %4719 = icmp ult i32 %4718, 8
  %4720 = select i1 %4719, i32 %4718, i32 0
  %4721 = extractelement <8 x i1> %119, i32 %4720
  %4722 = extractelement <8 x i1> %119, i64 1
  %4723 = and i1 %4719, %4721
  %4724 = and i1 %4722, %4723
  %4725 = extractelement <8 x float> %.state794, i32 %4720
  %4726 = select i1 %4724, float %4725, float 0.000000e+00
  %4727 = insertelement <8 x float> %4714, float %4726, i64 1
  %4728 = xor i1 %4724, true
  %4729 = and i1 %4722, %4728
  %4730 = insertelement <8 x i1> %4717, i1 %4729, i64 1
  %4731 = extractelement <8 x i32> %4704, i64 2
  %4732 = icmp ult i32 %4731, 8
  %4733 = select i1 %4732, i32 %4731, i32 0
  %4734 = extractelement <8 x i1> %119, i32 %4733
  %4735 = extractelement <8 x i1> %119, i64 2
  %4736 = and i1 %4732, %4734
  %4737 = and i1 %4735, %4736
  %4738 = extractelement <8 x float> %.state794, i32 %4733
  %4739 = select i1 %4737, float %4738, float 0.000000e+00
  %4740 = insertelement <8 x float> %4727, float %4739, i64 2
  %4741 = xor i1 %4737, true
  %4742 = and i1 %4735, %4741
  %4743 = insertelement <8 x i1> %4730, i1 %4742, i64 2
  %4744 = extractelement <8 x i32> %4704, i64 3
  %4745 = icmp ult i32 %4744, 8
  %4746 = select i1 %4745, i32 %4744, i32 0
  %4747 = extractelement <8 x i1> %119, i32 %4746
  %4748 = extractelement <8 x i1> %119, i64 3
  %4749 = and i1 %4745, %4747
  %4750 = and i1 %4748, %4749
  %4751 = extractelement <8 x float> %.state794, i32 %4746
  %4752 = select i1 %4750, float %4751, float 0.000000e+00
  %4753 = insertelement <8 x float> %4740, float %4752, i64 3
  %4754 = xor i1 %4750, true
  %4755 = and i1 %4748, %4754
  %4756 = insertelement <8 x i1> %4743, i1 %4755, i64 3
  %4757 = extractelement <8 x i32> %4704, i64 4
  %4758 = icmp ult i32 %4757, 8
  %4759 = select i1 %4758, i32 %4757, i32 0
  %4760 = extractelement <8 x i1> %119, i32 %4759
  %4761 = extractelement <8 x i1> %119, i64 4
  %4762 = and i1 %4758, %4760
  %4763 = and i1 %4761, %4762
  %4764 = extractelement <8 x float> %.state794, i32 %4759
  %4765 = select i1 %4763, float %4764, float 0.000000e+00
  %4766 = insertelement <8 x float> %4753, float %4765, i64 4
  %4767 = xor i1 %4763, true
  %4768 = and i1 %4761, %4767
  %4769 = insertelement <8 x i1> %4756, i1 %4768, i64 4
  %4770 = extractelement <8 x i32> %4704, i64 5
  %4771 = icmp ult i32 %4770, 8
  %4772 = select i1 %4771, i32 %4770, i32 0
  %4773 = extractelement <8 x i1> %119, i32 %4772
  %4774 = extractelement <8 x i1> %119, i64 5
  %4775 = and i1 %4771, %4773
  %4776 = and i1 %4774, %4775
  %4777 = extractelement <8 x float> %.state794, i32 %4772
  %4778 = select i1 %4776, float %4777, float 0.000000e+00
  %4779 = insertelement <8 x float> %4766, float %4778, i64 5
  %4780 = xor i1 %4776, true
  %4781 = and i1 %4774, %4780
  %4782 = insertelement <8 x i1> %4769, i1 %4781, i64 5
  %4783 = extractelement <8 x i32> %4704, i64 6
  %4784 = icmp ult i32 %4783, 8
  %4785 = select i1 %4784, i32 %4783, i32 0
  %4786 = extractelement <8 x i1> %119, i32 %4785
  %4787 = extractelement <8 x i1> %119, i64 6
  %4788 = and i1 %4784, %4786
  %4789 = and i1 %4787, %4788
  %4790 = extractelement <8 x float> %.state794, i32 %4785
  %4791 = select i1 %4789, float %4790, float 0.000000e+00
  %4792 = insertelement <8 x float> %4779, float %4791, i64 6
  %4793 = xor i1 %4789, true
  %4794 = and i1 %4787, %4793
  %4795 = insertelement <8 x i1> %4782, i1 %4794, i64 6
  %4796 = extractelement <8 x i32> %4704, i64 7
  %4797 = icmp ult i32 %4796, 8
  %4798 = select i1 %4797, i32 %4796, i32 0
  %4799 = extractelement <8 x i1> %119, i32 %4798
  %4800 = extractelement <8 x i1> %119, i64 7
  %4801 = and i1 %4797, %4799
  %4802 = and i1 %4800, %4801
  %4803 = extractelement <8 x float> %.state794, i32 %4798
  %4804 = select i1 %4802, float %4803, float 0.000000e+00
  %4805 = insertelement <8 x float> %4792, float %4804, i64 7
  %4806 = xor i1 %4802, true
  %4807 = and i1 %4800, %4806
  %4808 = insertelement <8 x i1> %4795, i1 %4807, i64 7
  %.state795 = load <8 x float>, ptr %.slot268, align 32
  %4809 = fmul <8 x float> %.state795, %4805
  %.spill.load796 = load <8 x i1>, ptr %.spill265, align 1
  %4810 = and <8 x i1> %119, %.spill.load796
  %4811 = xor <8 x i1> %.spill.load796, splat (i1 true)
  %4812 = and <8 x i1> %119, %4811
  %4813 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4810)
  %4814 = bitcast <8 x i1> %4810 to i8
  %4815 = call i8 @llvm.cttz.i8(i8 %4814, i1 false)
  %4816 = zext i8 %4815 to i32
  %4817 = select i1 %4813, i32 %4816, i32 0
  %tile_snapshot.spill.load797 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %4818 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 0
  %4819 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 1
  %.state798 = load <8 x i64>, ptr %.slot264, align 64
  %4820 = mul <8 x i64> %.state798, splat (i64 32)
  %4821 = add <8 x i64> %4819, %4820
  %4822 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4818, 0
  %4823 = insertvalue { <8 x ptr>, <8 x i64> } %4822, <8 x i64> %4821, 1
  %4824 = extractvalue { <8 x ptr>, <8 x i64> } %4823, 0
  %4825 = extractvalue { <8 x ptr>, <8 x i64> } %4823, 1
  %4826 = getelementptr i8, <8 x ptr> %4824, <8 x i64> %4825
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %4809, <8 x ptr> align 1 %4826, <8 x i1> %4810)
  %4827 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4812)
  %4828 = bitcast <8 x i1> %4812 to i8
  %4829 = call i8 @llvm.cttz.i8(i8 %4828, i1 false)
  %4830 = zext i8 %4829 to i32
  %4831 = select i1 %4827, i32 %4830, i32 0
  br label %direct.schedule.233

direct.schedule.233:                              ; preds = %direct.schedule.231
  %.state799 = load <8 x i64>, ptr %.slot264, align 64
  %4832 = add <8 x i64> %.state799, splat (i64 1)
  %4833 = load <8 x i64>, ptr %.slot264, align 64
  %4834 = select <8 x i1> %119, <8 x i64> %4832, <8 x i64> %4833
  store <8 x i64> %4834, ptr %.slot264, align 64
  br label %direct.schedule.226

direct.schedule.234:                              ; preds = %direct.false781
  %4835 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %4836 = extractvalue { <8 x ptr>, <8 x i64> } %69, 0
  %4837 = extractvalue { <8 x ptr>, <8 x i64> } %4835, 0
  %4838 = select <8 x i1> %119, <8 x ptr> %4836, <8 x ptr> %4837
  %4839 = extractvalue { <8 x ptr>, <8 x i64> } %69, 1
  %4840 = extractvalue { <8 x ptr>, <8 x i64> } %4835, 1
  %4841 = select <8 x i1> %119, <8 x i64> %4839, <8 x i64> %4840
  %4842 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4838, 0
  %4843 = insertvalue { <8 x ptr>, <8 x i64> } %4842, <8 x i64> %4841, 1
  store { <8 x ptr>, <8 x i64> } %4843, ptr %tile_snapshot.spill271, align 64
  %4844 = load <8 x i64>, ptr %.slot272, align 64
  %4845 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %4844
  store <8 x i64> %4845, ptr %.slot272, align 64
  br label %direct.schedule.235

direct.schedule.235:                              ; preds = %direct.schedule.247, %direct.schedule.234
  %.state800 = load <8 x i64>, ptr %.slot272, align 64
  %4846 = icmp slt <8 x i64> %.state800, splat (i64 2)
  %4847 = extractelement <8 x i1> %4846, i32 0
  br i1 %4847, label %direct.true801, label %direct.false802

direct.schedule.236:                              ; preds = %direct.true801
  %.state803 = load <8 x i64>, ptr %.slot272, align 64
  %4848 = select <8 x i1> %119, <8 x i64> %.state803, <8 x i64> zeroinitializer
  %4849 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4850 = srem <8 x i64> %4848, %4849
  %4851 = load <8 x i64>, ptr %.spill273, align 64
  %4852 = select <8 x i1> %119, <8 x i64> %4850, <8 x i64> %4851
  store <8 x i64> %4852, ptr %.spill273, align 64
  %.state804 = load <8 x i64>, ptr %.slot272, align 64
  %4853 = select <8 x i1> %119, <8 x i64> %.state804, <8 x i64> zeroinitializer
  %4854 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4855 = sdiv <8 x i64> %4853, %4854
  %4856 = mul <8 x i64> %4850, splat (i64 8)
  %.spill.load805 = load <8 x i64>, ptr %.spill, align 64
  %4857 = add <8 x i64> %4856, %.spill.load805
  %4858 = icmp slt <8 x i64> %4857, splat (i64 3)
  %4859 = load <8 x i1>, ptr %.spill274, align 1
  %4860 = select <8 x i1> %119, <8 x i1> %4858, <8 x i1> %4859
  store <8 x i1> %4860, ptr %.spill274, align 1
  %4861 = select <8 x i1> %119, <8 x i64> %4855, <8 x i64> zeroinitializer
  %4862 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %4863 = srem <8 x i64> %4861, %4862
  %4864 = load <8 x i64>, ptr %.spill275, align 64
  %4865 = select <8 x i1> %119, <8 x i64> %4863, <8 x i64> %4864
  store <8 x i64> %4865, ptr %.spill275, align 64
  store i64 0, ptr %.spill276, align 4
  %4866 = and <8 x i1> %119, %4858
  %4867 = xor <8 x i1> %4858, splat (i1 true)
  %4868 = and <8 x i1> %119, %4867
  %4869 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4866)
  %4870 = bitcast <8 x i1> %4866 to i8
  %4871 = call i8 @llvm.cttz.i8(i8 %4870, i1 false)
  %4872 = zext i8 %4871 to i32
  %4873 = select i1 %4869, i32 %4872, i32 0
  %tile_snapshot.spill.load806 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %4874 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load806, 0
  %4875 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load806, 1
  %.state807 = load <8 x i64>, ptr %.slot272, align 64
  %4876 = mul <8 x i64> %.state807, splat (i64 32)
  %4877 = add <8 x i64> %4875, %4876
  %4878 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4874, 0
  %4879 = insertvalue { <8 x ptr>, <8 x i64> } %4878, <8 x i64> %4877, 1
  %4880 = extractvalue { <8 x ptr>, <8 x i64> } %4879, 0
  %4881 = extractvalue { <8 x ptr>, <8 x i64> } %4879, 1
  %4882 = getelementptr i8, <8 x ptr> %4880, <8 x i64> %4881
  %4883 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4882, <8 x i1> %4866, <8 x float> zeroinitializer)
  %4884 = load <8 x float>, ptr %.slot277, align 32
  %4885 = select <8 x i1> %4866, <8 x float> %4883, <8 x float> %4884
  store <8 x float> %4885, ptr %.slot277, align 32
  %4886 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4868)
  %4887 = bitcast <8 x i1> %4868 to i8
  %4888 = call i8 @llvm.cttz.i8(i8 %4887, i1 false)
  %4889 = zext i8 %4888 to i32
  %4890 = select i1 %4886, i32 %4889, i32 0
  %4891 = load <8 x float>, ptr %.slot277, align 32
  %4892 = select <8 x i1> %4868, <8 x float> zeroinitializer, <8 x float> %4891
  store <8 x float> %4892, ptr %.slot277, align 32
  br label %direct.schedule.238

direct.schedule.238:                              ; preds = %direct.schedule.236
  %.state808 = load <8 x float>, ptr %.slot277, align 32
  %4893 = load <8 x i64>, ptr %.slot278, align 64
  %4894 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %4893
  store <8 x i64> %4894, ptr %.slot278, align 64
  %4895 = load <8 x float>, ptr %.slot279, align 32
  %4896 = select <8 x i1> %119, <8 x float> %.state808, <8 x float> %4895
  store <8 x float> %4896, ptr %.slot279, align 32
  br label %direct.schedule.239

direct.schedule.239:                              ; preds = %direct.schedule.244, %direct.schedule.238
  %.state809 = load <8 x i64>, ptr %.slot278, align 64
  %4897 = icmp slt <8 x i64> %.state809, splat (i64 33)
  %4898 = extractelement <8 x i1> %4897, i32 0
  br i1 %4898, label %direct.true810, label %direct.false811

direct.schedule.240:                              ; preds = %direct.true810
  %.spill.load812 = load i64, ptr %.spill276, align 4
  %4899 = add i64 %.spill.load812, 0
  %4900 = mul i64 %4899, 1
  %4901 = add i64 %4900, 0
  store i64 %4901, ptr %.spill280, align 4
  %4902 = mul i64 %4901, 2
  %.splatinsert813 = insertelement <8 x i64> poison, i64 %4902, i64 0
  %.splat814 = shufflevector <8 x i64> %.splatinsert813, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load815 = load <8 x i64>, ptr %.spill275, align 64
  %4903 = add <8 x i64> %.splat814, %.spill.load815
  %.state816 = load <8 x i64>, ptr %.slot278, align 64
  %4904 = select <8 x i1> %119, <8 x i64> %.state816, <8 x i64> zeroinitializer
  %4905 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %4906 = sdiv <8 x i64> %4904, %4905
  %4907 = mul <8 x i64> %4903, splat (i64 5)
  %4908 = add <8 x i64> %4907, %4906
  %.state817 = load <8 x i64>, ptr %.slot278, align 64
  %4909 = select <8 x i1> %119, <8 x i64> %.state817, <8 x i64> zeroinitializer
  %4910 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %4911 = srem <8 x i64> %4909, %4910
  %4912 = load <8 x i64>, ptr %.spill281, align 64
  %4913 = select <8 x i1> %119, <8 x i64> %4911, <8 x i64> %4912
  store <8 x i64> %4913, ptr %.spill281, align 64
  %.spill.load818 = load <8 x i64>, ptr %.spill, align 64
  %4914 = icmp eq <8 x i64> %.spill.load818, %4911
  %4915 = and <8 x i1> %119, %4914
  %4916 = xor <8 x i1> %4914, splat (i1 true)
  %4917 = and <8 x i1> %119, %4916
  %4918 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4915)
  %4919 = bitcast <8 x i1> %4915 to i8
  %4920 = call i8 @llvm.cttz.i8(i8 %4919, i1 false)
  %4921 = zext i8 %4920 to i32
  %4922 = select i1 %4918, i32 %4921, i32 0
  %tile_snapshot.spill.load819 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill235, align 64
  %4923 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load819, 0
  %4924 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load819, 1
  %4925 = mul <8 x i64> %4908, splat (i64 32)
  %4926 = add <8 x i64> %4924, %4925
  %4927 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4923, 0
  %4928 = insertvalue { <8 x ptr>, <8 x i64> } %4927, <8 x i64> %4926, 1
  %4929 = extractvalue { <8 x ptr>, <8 x i64> } %4928, 0
  %4930 = extractvalue { <8 x ptr>, <8 x i64> } %4928, 1
  %4931 = getelementptr i8, <8 x ptr> %4929, <8 x i64> %4930
  %4932 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4931, <8 x i1> %4915, <8 x float> zeroinitializer)
  %4933 = load <8 x float>, ptr %.slot282, align 32
  %4934 = select <8 x i1> %4915, <8 x float> %4932, <8 x float> %4933
  store <8 x float> %4934, ptr %.slot282, align 32
  %4935 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4917)
  %4936 = bitcast <8 x i1> %4917 to i8
  %4937 = call i8 @llvm.cttz.i8(i8 %4936, i1 false)
  %4938 = zext i8 %4937 to i32
  %4939 = select i1 %4935, i32 %4938, i32 0
  %4940 = load <8 x float>, ptr %.slot282, align 32
  %4941 = select <8 x i1> %4917, <8 x float> zeroinitializer, <8 x float> %4940
  store <8 x float> %4941, ptr %.slot282, align 32
  br label %direct.schedule.242

direct.schedule.242:                              ; preds = %direct.schedule.240
  %.spill.load820 = load <8 x i64>, ptr %.spill281, align 64
  %4942 = trunc <8 x i64> %.spill.load820 to <8 x i32>
  %.state821 = load <8 x float>, ptr %.slot282, align 32
  %4943 = extractelement <8 x i32> %4942, i64 0
  %4944 = icmp ult i32 %4943, 8
  %4945 = select i1 %4944, i32 %4943, i32 0
  %4946 = extractelement <8 x i1> %119, i32 %4945
  %4947 = extractelement <8 x i1> %119, i64 0
  %4948 = and i1 %4944, %4946
  %4949 = and i1 %4947, %4948
  %4950 = extractelement <8 x float> %.state821, i32 %4945
  %4951 = select i1 %4949, float %4950, float 0.000000e+00
  %4952 = insertelement <8 x float> poison, float %4951, i64 0
  %4953 = xor i1 %4949, true
  %4954 = and i1 %4947, %4953
  %4955 = insertelement <8 x i1> poison, i1 %4954, i64 0
  %4956 = extractelement <8 x i32> %4942, i64 1
  %4957 = icmp ult i32 %4956, 8
  %4958 = select i1 %4957, i32 %4956, i32 0
  %4959 = extractelement <8 x i1> %119, i32 %4958
  %4960 = extractelement <8 x i1> %119, i64 1
  %4961 = and i1 %4957, %4959
  %4962 = and i1 %4960, %4961
  %4963 = extractelement <8 x float> %.state821, i32 %4958
  %4964 = select i1 %4962, float %4963, float 0.000000e+00
  %4965 = insertelement <8 x float> %4952, float %4964, i64 1
  %4966 = xor i1 %4962, true
  %4967 = and i1 %4960, %4966
  %4968 = insertelement <8 x i1> %4955, i1 %4967, i64 1
  %4969 = extractelement <8 x i32> %4942, i64 2
  %4970 = icmp ult i32 %4969, 8
  %4971 = select i1 %4970, i32 %4969, i32 0
  %4972 = extractelement <8 x i1> %119, i32 %4971
  %4973 = extractelement <8 x i1> %119, i64 2
  %4974 = and i1 %4970, %4972
  %4975 = and i1 %4973, %4974
  %4976 = extractelement <8 x float> %.state821, i32 %4971
  %4977 = select i1 %4975, float %4976, float 0.000000e+00
  %4978 = insertelement <8 x float> %4965, float %4977, i64 2
  %4979 = xor i1 %4975, true
  %4980 = and i1 %4973, %4979
  %4981 = insertelement <8 x i1> %4968, i1 %4980, i64 2
  %4982 = extractelement <8 x i32> %4942, i64 3
  %4983 = icmp ult i32 %4982, 8
  %4984 = select i1 %4983, i32 %4982, i32 0
  %4985 = extractelement <8 x i1> %119, i32 %4984
  %4986 = extractelement <8 x i1> %119, i64 3
  %4987 = and i1 %4983, %4985
  %4988 = and i1 %4986, %4987
  %4989 = extractelement <8 x float> %.state821, i32 %4984
  %4990 = select i1 %4988, float %4989, float 0.000000e+00
  %4991 = insertelement <8 x float> %4978, float %4990, i64 3
  %4992 = xor i1 %4988, true
  %4993 = and i1 %4986, %4992
  %4994 = insertelement <8 x i1> %4981, i1 %4993, i64 3
  %4995 = extractelement <8 x i32> %4942, i64 4
  %4996 = icmp ult i32 %4995, 8
  %4997 = select i1 %4996, i32 %4995, i32 0
  %4998 = extractelement <8 x i1> %119, i32 %4997
  %4999 = extractelement <8 x i1> %119, i64 4
  %5000 = and i1 %4996, %4998
  %5001 = and i1 %4999, %5000
  %5002 = extractelement <8 x float> %.state821, i32 %4997
  %5003 = select i1 %5001, float %5002, float 0.000000e+00
  %5004 = insertelement <8 x float> %4991, float %5003, i64 4
  %5005 = xor i1 %5001, true
  %5006 = and i1 %4999, %5005
  %5007 = insertelement <8 x i1> %4994, i1 %5006, i64 4
  %5008 = extractelement <8 x i32> %4942, i64 5
  %5009 = icmp ult i32 %5008, 8
  %5010 = select i1 %5009, i32 %5008, i32 0
  %5011 = extractelement <8 x i1> %119, i32 %5010
  %5012 = extractelement <8 x i1> %119, i64 5
  %5013 = and i1 %5009, %5011
  %5014 = and i1 %5012, %5013
  %5015 = extractelement <8 x float> %.state821, i32 %5010
  %5016 = select i1 %5014, float %5015, float 0.000000e+00
  %5017 = insertelement <8 x float> %5004, float %5016, i64 5
  %5018 = xor i1 %5014, true
  %5019 = and i1 %5012, %5018
  %5020 = insertelement <8 x i1> %5007, i1 %5019, i64 5
  %5021 = extractelement <8 x i32> %4942, i64 6
  %5022 = icmp ult i32 %5021, 8
  %5023 = select i1 %5022, i32 %5021, i32 0
  %5024 = extractelement <8 x i1> %119, i32 %5023
  %5025 = extractelement <8 x i1> %119, i64 6
  %5026 = and i1 %5022, %5024
  %5027 = and i1 %5025, %5026
  %5028 = extractelement <8 x float> %.state821, i32 %5023
  %5029 = select i1 %5027, float %5028, float 0.000000e+00
  %5030 = insertelement <8 x float> %5017, float %5029, i64 6
  %5031 = xor i1 %5027, true
  %5032 = and i1 %5025, %5031
  %5033 = insertelement <8 x i1> %5020, i1 %5032, i64 6
  %5034 = extractelement <8 x i32> %4942, i64 7
  %5035 = icmp ult i32 %5034, 8
  %5036 = select i1 %5035, i32 %5034, i32 0
  %5037 = extractelement <8 x i1> %119, i32 %5036
  %5038 = extractelement <8 x i1> %119, i64 7
  %5039 = and i1 %5035, %5037
  %5040 = and i1 %5038, %5039
  %5041 = extractelement <8 x float> %.state821, i32 %5036
  %5042 = select i1 %5040, float %5041, float 0.000000e+00
  %5043 = insertelement <8 x float> %5030, float %5042, i64 7
  %5044 = xor i1 %5040, true
  %5045 = and i1 %5038, %5044
  %5046 = insertelement <8 x i1> %5033, i1 %5045, i64 7
  %5047 = load <8 x float>, ptr %.spill283, align 32
  %5048 = select <8 x i1> %119, <8 x float> %5043, <8 x float> %5047
  store <8 x float> %5048, ptr %.spill283, align 32
  %.spill.load822 = load i64, ptr %.spill280, align 4
  %5049 = mul i64 %.spill.load822, 33
  %.splatinsert823 = insertelement <8 x i64> poison, i64 %5049, i64 0
  %.splat824 = shufflevector <8 x i64> %.splatinsert823, <8 x i64> poison, <8 x i32> zeroinitializer
  %.state825 = load <8 x i64>, ptr %.slot278, align 64
  %5050 = add <8 x i64> %.splat824, %.state825
  %5051 = mul <8 x i64> %5050, splat (i64 1)
  %.spill.load826 = load <8 x i64>, ptr %.spill273, align 64
  %5052 = add <8 x i64> %5051, %.spill.load826
  %.spill.load827 = load <8 x i1>, ptr %.spill274, align 1
  %5053 = and <8 x i1> %119, %.spill.load827
  %5054 = xor <8 x i1> %.spill.load827, splat (i1 true)
  %5055 = and <8 x i1> %119, %5054
  %5056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5053)
  %5057 = bitcast <8 x i1> %5053 to i8
  %5058 = call i8 @llvm.cttz.i8(i8 %5057, i1 false)
  %5059 = zext i8 %5058 to i32
  %5060 = select i1 %5056, i32 %5059, i32 0
  %tile_snapshot.spill.load828 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill126, align 64
  %5061 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load828, 0
  %5062 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load828, 1
  %5063 = mul <8 x i64> %5052, splat (i64 32)
  %5064 = add <8 x i64> %5062, %5063
  %5065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5061, 0
  %5066 = insertvalue { <8 x ptr>, <8 x i64> } %5065, <8 x i64> %5064, 1
  %5067 = extractvalue { <8 x ptr>, <8 x i64> } %5066, 0
  %5068 = extractvalue { <8 x ptr>, <8 x i64> } %5066, 1
  %5069 = getelementptr i8, <8 x ptr> %5067, <8 x i64> %5068
  %5070 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5069, <8 x i1> %5053, <8 x float> zeroinitializer)
  %5071 = load <8 x float>, ptr %.slot284, align 32
  %5072 = select <8 x i1> %5053, <8 x float> %5070, <8 x float> %5071
  store <8 x float> %5072, ptr %.slot284, align 32
  %5073 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5055)
  %5074 = bitcast <8 x i1> %5055 to i8
  %5075 = call i8 @llvm.cttz.i8(i8 %5074, i1 false)
  %5076 = zext i8 %5075 to i32
  %5077 = select i1 %5073, i32 %5076, i32 0
  %5078 = load <8 x float>, ptr %.slot284, align 32
  %5079 = select <8 x i1> %5055, <8 x float> zeroinitializer, <8 x float> %5078
  store <8 x float> %5079, ptr %.slot284, align 32
  br label %direct.schedule.244

direct.schedule.244:                              ; preds = %direct.schedule.242
  %.spill.load829 = load <8 x float>, ptr %.spill283, align 32
  %.state830 = load <8 x float>, ptr %.slot284, align 32
  %5080 = fmul <8 x float> %.spill.load829, %.state830
  %.state831 = load <8 x float>, ptr %.slot279, align 32
  %5081 = fadd <8 x float> %.state831, %5080
  %.state832 = load <8 x i64>, ptr %.slot278, align 64
  %5082 = add <8 x i64> %.state832, splat (i64 1)
  %5083 = load <8 x i64>, ptr %.slot278, align 64
  %5084 = select <8 x i1> %119, <8 x i64> %5082, <8 x i64> %5083
  store <8 x i64> %5084, ptr %.slot278, align 64
  %5085 = load <8 x float>, ptr %.slot279, align 32
  %5086 = select <8 x i1> %119, <8 x float> %5081, <8 x float> %5085
  store <8 x float> %5086, ptr %.slot279, align 32
  br label %direct.schedule.239

direct.schedule.245:                              ; preds = %direct.false811
  %.spill.load833 = load <8 x i1>, ptr %.spill274, align 1
  %5087 = and <8 x i1> %119, %.spill.load833
  %5088 = xor <8 x i1> %.spill.load833, splat (i1 true)
  %5089 = and <8 x i1> %119, %5088
  %5090 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5087)
  %5091 = bitcast <8 x i1> %5087 to i8
  %5092 = call i8 @llvm.cttz.i8(i8 %5091, i1 false)
  %5093 = zext i8 %5092 to i32
  %5094 = select i1 %5090, i32 %5093, i32 0
  %tile_snapshot.spill.load834 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %5095 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load834, 0
  %5096 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load834, 1
  %.state835 = load <8 x i64>, ptr %.slot272, align 64
  %5097 = mul <8 x i64> %.state835, splat (i64 32)
  %5098 = add <8 x i64> %5096, %5097
  %5099 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5095, 0
  %5100 = insertvalue { <8 x ptr>, <8 x i64> } %5099, <8 x i64> %5098, 1
  %.state836 = load <8 x float>, ptr %.slot279, align 32
  %5101 = extractvalue { <8 x ptr>, <8 x i64> } %5100, 0
  %5102 = extractvalue { <8 x ptr>, <8 x i64> } %5100, 1
  %5103 = getelementptr i8, <8 x ptr> %5101, <8 x i64> %5102
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state836, <8 x ptr> align 1 %5103, <8 x i1> %5087)
  %5104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5089)
  %5105 = bitcast <8 x i1> %5089 to i8
  %5106 = call i8 @llvm.cttz.i8(i8 %5105, i1 false)
  %5107 = zext i8 %5106 to i32
  %5108 = select i1 %5104, i32 %5107, i32 0
  br label %direct.schedule.247

direct.schedule.247:                              ; preds = %direct.schedule.245
  %.state837 = load <8 x i64>, ptr %.slot272, align 64
  %5109 = add <8 x i64> %.state837, splat (i64 1)
  %5110 = load <8 x i64>, ptr %.slot272, align 64
  %5111 = select <8 x i1> %119, <8 x i64> %5109, <8 x i64> %5110
  store <8 x i64> %5111, ptr %.slot272, align 64
  br label %direct.schedule.235

direct.schedule.248:                              ; preds = %direct.false802
  %5112 = load <8 x i64>, ptr %.slot285, align 64
  %5113 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5112
  store <8 x i64> %5113, ptr %.slot285, align 64
  br label %direct.schedule.249

direct.schedule.249:                              ; preds = %direct.schedule.254, %direct.schedule.248
  %.state838 = load <8 x i64>, ptr %.slot285, align 64
  %5114 = icmp slt <8 x i64> %.state838, splat (i64 1)
  %5115 = extractelement <8 x i1> %5114, i32 0
  br i1 %5115, label %direct.true839, label %direct.false840

direct.schedule.250:                              ; preds = %direct.true839
  %.state841 = load <8 x i64>, ptr %.slot285, align 64
  %5116 = select <8 x i1> %119, <8 x i64> %.state841, <8 x i64> zeroinitializer
  %5117 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5118 = srem <8 x i64> %5116, %5117
  %5119 = mul <8 x i64> %5118, splat (i64 8)
  %.spill.load842 = load <8 x i64>, ptr %.spill, align 64
  %5120 = add <8 x i64> %5119, %.spill.load842
  %5121 = icmp slt <8 x i64> %5120, splat (i64 2)
  %5122 = load <8 x i1>, ptr %.spill286, align 1
  %5123 = select <8 x i1> %119, <8 x i1> %5121, <8 x i1> %5122
  store <8 x i1> %5123, ptr %.spill286, align 1
  %5124 = and <8 x i1> %119, %5121
  %5125 = xor <8 x i1> %5121, splat (i1 true)
  %5126 = and <8 x i1> %119, %5125
  %5127 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5124)
  %5128 = bitcast <8 x i1> %5124 to i8
  %5129 = call i8 @llvm.cttz.i8(i8 %5128, i1 false)
  %5130 = zext i8 %5129 to i32
  %5131 = select i1 %5127, i32 %5130, i32 0
  %tile_snapshot.spill.load843 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %5132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load843, 0
  %5133 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load843, 1
  %.state844 = load <8 x i64>, ptr %.slot285, align 64
  %5134 = mul <8 x i64> %.state844, splat (i64 32)
  %5135 = add <8 x i64> %5133, %5134
  %5136 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5132, 0
  %5137 = insertvalue { <8 x ptr>, <8 x i64> } %5136, <8 x i64> %5135, 1
  %5138 = extractvalue { <8 x ptr>, <8 x i64> } %5137, 0
  %5139 = extractvalue { <8 x ptr>, <8 x i64> } %5137, 1
  %5140 = getelementptr i8, <8 x ptr> %5138, <8 x i64> %5139
  %5141 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5140, <8 x i1> %5124, <8 x float> zeroinitializer)
  %5142 = load <8 x float>, ptr %.slot287, align 32
  %5143 = select <8 x i1> %5124, <8 x float> %5141, <8 x float> %5142
  store <8 x float> %5143, ptr %.slot287, align 32
  %5144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5126)
  %5145 = bitcast <8 x i1> %5126 to i8
  %5146 = call i8 @llvm.cttz.i8(i8 %5145, i1 false)
  %5147 = zext i8 %5146 to i32
  %5148 = select i1 %5144, i32 %5147, i32 0
  %5149 = load <8 x float>, ptr %.slot287, align 32
  %5150 = select <8 x i1> %5126, <8 x float> zeroinitializer, <8 x float> %5149
  store <8 x float> %5150, ptr %.slot287, align 32
  br label %direct.schedule.252

direct.schedule.252:                              ; preds = %direct.schedule.250
  %.spill.load845 = load <8 x i1>, ptr %.spill286, align 1
  %5151 = and <8 x i1> %119, %.spill.load845
  %5152 = xor <8 x i1> %.spill.load845, splat (i1 true)
  %5153 = and <8 x i1> %119, %5152
  %5154 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5151)
  %5155 = bitcast <8 x i1> %5151 to i8
  %5156 = call i8 @llvm.cttz.i8(i8 %5155, i1 false)
  %5157 = zext i8 %5156 to i32
  %5158 = select i1 %5154, i32 %5157, i32 0
  %tile_snapshot.spill.load846 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %5159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load846, 0
  %5160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load846, 1
  %.state847 = load <8 x i64>, ptr %.slot285, align 64
  %5161 = mul <8 x i64> %.state847, splat (i64 32)
  %5162 = add <8 x i64> %5160, %5161
  %5163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5159, 0
  %5164 = insertvalue { <8 x ptr>, <8 x i64> } %5163, <8 x i64> %5162, 1
  %.state848 = load <8 x float>, ptr %.slot287, align 32
  %5165 = extractvalue { <8 x ptr>, <8 x i64> } %5164, 0
  %5166 = extractvalue { <8 x ptr>, <8 x i64> } %5164, 1
  %5167 = getelementptr i8, <8 x ptr> %5165, <8 x i64> %5166
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state848, <8 x ptr> align 1 %5167, <8 x i1> %5151)
  %5168 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5153)
  %5169 = bitcast <8 x i1> %5153 to i8
  %5170 = call i8 @llvm.cttz.i8(i8 %5169, i1 false)
  %5171 = zext i8 %5170 to i32
  %5172 = select i1 %5168, i32 %5171, i32 0
  br label %direct.schedule.254

direct.schedule.254:                              ; preds = %direct.schedule.252
  %.state849 = load <8 x i64>, ptr %.slot285, align 64
  %5173 = add <8 x i64> %.state849, splat (i64 1)
  %5174 = load <8 x i64>, ptr %.slot285, align 64
  %5175 = select <8 x i1> %119, <8 x i64> %5173, <8 x i64> %5174
  store <8 x i64> %5175, ptr %.slot285, align 64
  br label %direct.schedule.249

direct.schedule.255:                              ; preds = %direct.false840
  %5176 = load <8 x i64>, ptr %.slot288, align 64
  %5177 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5176
  store <8 x i64> %5177, ptr %.slot288, align 64
  br label %direct.schedule.256

direct.schedule.256:                              ; preds = %direct.schedule.261, %direct.schedule.255
  %.state850 = load <8 x i64>, ptr %.slot288, align 64
  %5178 = icmp slt <8 x i64> %.state850, splat (i64 1)
  %5179 = extractelement <8 x i1> %5178, i32 0
  br i1 %5179, label %direct.true851, label %direct.false852

direct.schedule.257:                              ; preds = %direct.true851
  %.state853 = load <8 x i64>, ptr %.slot288, align 64
  %5180 = select <8 x i1> %119, <8 x i64> %.state853, <8 x i64> zeroinitializer
  %5181 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5182 = srem <8 x i64> %5180, %5181
  %5183 = mul <8 x i64> %5182, splat (i64 8)
  %.spill.load854 = load <8 x i64>, ptr %.spill, align 64
  %5184 = add <8 x i64> %5183, %.spill.load854
  %5185 = icmp slt <8 x i64> %5184, splat (i64 2)
  %5186 = load <8 x i1>, ptr %.spill289, align 1
  %5187 = select <8 x i1> %119, <8 x i1> %5185, <8 x i1> %5186
  store <8 x i1> %5187, ptr %.spill289, align 1
  %5188 = and <8 x i1> %119, %5185
  %5189 = xor <8 x i1> %5185, splat (i1 true)
  %5190 = and <8 x i1> %119, %5189
  %5191 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5188)
  %5192 = bitcast <8 x i1> %5188 to i8
  %5193 = call i8 @llvm.cttz.i8(i8 %5192, i1 false)
  %5194 = zext i8 %5193 to i32
  %5195 = select i1 %5191, i32 %5194, i32 0
  %tile_snapshot.spill.load855 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill257, align 64
  %5196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load855, 0
  %5197 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load855, 1
  %.state856 = load <8 x i64>, ptr %.slot288, align 64
  %5198 = mul <8 x i64> %.state856, splat (i64 32)
  %5199 = add <8 x i64> %5197, %5198
  %5200 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5196, 0
  %5201 = insertvalue { <8 x ptr>, <8 x i64> } %5200, <8 x i64> %5199, 1
  %5202 = extractvalue { <8 x ptr>, <8 x i64> } %5201, 0
  %5203 = extractvalue { <8 x ptr>, <8 x i64> } %5201, 1
  %5204 = getelementptr i8, <8 x ptr> %5202, <8 x i64> %5203
  %5205 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5204, <8 x i1> %5188, <8 x float> zeroinitializer)
  %5206 = load <8 x float>, ptr %.slot290, align 32
  %5207 = select <8 x i1> %5188, <8 x float> %5205, <8 x float> %5206
  store <8 x float> %5207, ptr %.slot290, align 32
  %5208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5190)
  %5209 = bitcast <8 x i1> %5190 to i8
  %5210 = call i8 @llvm.cttz.i8(i8 %5209, i1 false)
  %5211 = zext i8 %5210 to i32
  %5212 = select i1 %5208, i32 %5211, i32 0
  %5213 = load <8 x float>, ptr %.slot290, align 32
  %5214 = select <8 x i1> %5190, <8 x float> zeroinitializer, <8 x float> %5213
  store <8 x float> %5214, ptr %.slot290, align 32
  br label %direct.schedule.259

direct.schedule.259:                              ; preds = %direct.schedule.257
  %.spill.load857 = load <8 x i1>, ptr %.spill289, align 1
  %5215 = and <8 x i1> %119, %.spill.load857
  %5216 = xor <8 x i1> %.spill.load857, splat (i1 true)
  %5217 = and <8 x i1> %119, %5216
  %5218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5215)
  %5219 = bitcast <8 x i1> %5215 to i8
  %5220 = call i8 @llvm.cttz.i8(i8 %5219, i1 false)
  %5221 = zext i8 %5220 to i32
  %5222 = select i1 %5218, i32 %5221, i32 0
  %tile_snapshot.spill.load858 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %5223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load858, 0
  %5224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load858, 1
  %.state859 = load <8 x i64>, ptr %.slot288, align 64
  %5225 = mul <8 x i64> %.state859, splat (i64 32)
  %5226 = add <8 x i64> %5224, %5225
  %5227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5223, 0
  %5228 = insertvalue { <8 x ptr>, <8 x i64> } %5227, <8 x i64> %5226, 1
  %.state860 = load <8 x float>, ptr %.slot290, align 32
  %5229 = extractvalue { <8 x ptr>, <8 x i64> } %5228, 0
  %5230 = extractvalue { <8 x ptr>, <8 x i64> } %5228, 1
  %5231 = getelementptr i8, <8 x ptr> %5229, <8 x i64> %5230
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state860, <8 x ptr> align 1 %5231, <8 x i1> %5215)
  %5232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5217)
  %5233 = bitcast <8 x i1> %5217 to i8
  %5234 = call i8 @llvm.cttz.i8(i8 %5233, i1 false)
  %5235 = zext i8 %5234 to i32
  %5236 = select i1 %5232, i32 %5235, i32 0
  br label %direct.schedule.261

direct.schedule.261:                              ; preds = %direct.schedule.259
  %.state861 = load <8 x i64>, ptr %.slot288, align 64
  %5237 = add <8 x i64> %.state861, splat (i64 1)
  %5238 = load <8 x i64>, ptr %.slot288, align 64
  %5239 = select <8 x i1> %119, <8 x i64> %5237, <8 x i64> %5238
  store <8 x i64> %5239, ptr %.slot288, align 64
  br label %direct.schedule.256

direct.schedule.262:                              ; preds = %direct.false852
  %5240 = load <8 x i64>, ptr %.slot291, align 64
  %5241 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5240
  store <8 x i64> %5241, ptr %.slot291, align 64
  br label %direct.schedule.263

direct.schedule.263:                              ; preds = %direct.schedule.268, %direct.schedule.262
  %.state862 = load <8 x i64>, ptr %.slot291, align 64
  %5242 = icmp slt <8 x i64> %.state862, splat (i64 2)
  %5243 = extractelement <8 x i1> %5242, i32 0
  br i1 %5243, label %direct.true863, label %direct.false864

direct.schedule.264:                              ; preds = %direct.true863
  %.state865 = load <8 x i64>, ptr %.slot291, align 64
  %5244 = select <8 x i1> %119, <8 x i64> %.state865, <8 x i64> zeroinitializer
  %5245 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5246 = srem <8 x i64> %5244, %5245
  %5247 = mul <8 x i64> %5246, splat (i64 8)
  %.spill.load866 = load <8 x i64>, ptr %.spill, align 64
  %5248 = add <8 x i64> %5247, %.spill.load866
  %5249 = icmp slt <8 x i64> %5248, splat (i64 3)
  %5250 = load <8 x i1>, ptr %.spill292, align 1
  %5251 = select <8 x i1> %119, <8 x i1> %5249, <8 x i1> %5250
  store <8 x i1> %5251, ptr %.spill292, align 1
  %5252 = and <8 x i1> %119, %5249
  %5253 = xor <8 x i1> %5249, splat (i1 true)
  %5254 = and <8 x i1> %119, %5253
  %5255 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5252)
  %5256 = bitcast <8 x i1> %5252 to i8
  %5257 = call i8 @llvm.cttz.i8(i8 %5256, i1 false)
  %5258 = zext i8 %5257 to i32
  %5259 = select i1 %5255, i32 %5258, i32 0
  %tile_snapshot.spill.load867 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %5260 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load867, 0
  %5261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load867, 1
  %.state868 = load <8 x i64>, ptr %.slot291, align 64
  %5262 = mul <8 x i64> %.state868, splat (i64 32)
  %5263 = add <8 x i64> %5261, %5262
  %5264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5260, 0
  %5265 = insertvalue { <8 x ptr>, <8 x i64> } %5264, <8 x i64> %5263, 1
  %5266 = extractvalue { <8 x ptr>, <8 x i64> } %5265, 0
  %5267 = extractvalue { <8 x ptr>, <8 x i64> } %5265, 1
  %5268 = getelementptr i8, <8 x ptr> %5266, <8 x i64> %5267
  %5269 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5268, <8 x i1> %5252, <8 x float> zeroinitializer)
  %5270 = load <8 x float>, ptr %.slot293, align 32
  %5271 = select <8 x i1> %5252, <8 x float> %5269, <8 x float> %5270
  store <8 x float> %5271, ptr %.slot293, align 32
  %5272 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5254)
  %5273 = bitcast <8 x i1> %5254 to i8
  %5274 = call i8 @llvm.cttz.i8(i8 %5273, i1 false)
  %5275 = zext i8 %5274 to i32
  %5276 = select i1 %5272, i32 %5275, i32 0
  %5277 = load <8 x float>, ptr %.slot293, align 32
  %5278 = select <8 x i1> %5254, <8 x float> zeroinitializer, <8 x float> %5277
  store <8 x float> %5278, ptr %.slot293, align 32
  br label %direct.schedule.266

direct.schedule.266:                              ; preds = %direct.schedule.264
  %.spill.load869 = load <8 x i1>, ptr %.spill292, align 1
  %5279 = and <8 x i1> %119, %.spill.load869
  %5280 = xor <8 x i1> %.spill.load869, splat (i1 true)
  %5281 = and <8 x i1> %119, %5280
  %5282 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5279)
  %5283 = bitcast <8 x i1> %5279 to i8
  %5284 = call i8 @llvm.cttz.i8(i8 %5283, i1 false)
  %5285 = zext i8 %5284 to i32
  %5286 = select i1 %5282, i32 %5285, i32 0
  %tile_snapshot.spill.load870 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill118, align 64
  %5287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load870, 0
  %5288 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load870, 1
  %.state871 = load <8 x i64>, ptr %.slot291, align 64
  %5289 = mul <8 x i64> %.state871, splat (i64 32)
  %5290 = add <8 x i64> %5288, %5289
  %5291 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5287, 0
  %5292 = insertvalue { <8 x ptr>, <8 x i64> } %5291, <8 x i64> %5290, 1
  %.state872 = load <8 x float>, ptr %.slot293, align 32
  %5293 = extractvalue { <8 x ptr>, <8 x i64> } %5292, 0
  %5294 = extractvalue { <8 x ptr>, <8 x i64> } %5292, 1
  %5295 = getelementptr i8, <8 x ptr> %5293, <8 x i64> %5294
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state872, <8 x ptr> align 1 %5295, <8 x i1> %5279)
  %5296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5281)
  %5297 = bitcast <8 x i1> %5281 to i8
  %5298 = call i8 @llvm.cttz.i8(i8 %5297, i1 false)
  %5299 = zext i8 %5298 to i32
  %5300 = select i1 %5296, i32 %5299, i32 0
  br label %direct.schedule.268

direct.schedule.268:                              ; preds = %direct.schedule.266
  %.state873 = load <8 x i64>, ptr %.slot291, align 64
  %5301 = add <8 x i64> %.state873, splat (i64 1)
  %5302 = load <8 x i64>, ptr %.slot291, align 64
  %5303 = select <8 x i1> %119, <8 x i64> %5301, <8 x i64> %5302
  store <8 x i64> %5303, ptr %.slot291, align 64
  br label %direct.schedule.263

direct.schedule.269:                              ; preds = %direct.false864
  %5304 = load <8 x i64>, ptr %.slot294, align 64
  %5305 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5304
  store <8 x i64> %5305, ptr %.slot294, align 64
  br label %direct.schedule.270

direct.schedule.270:                              ; preds = %direct.schedule.275, %direct.schedule.269
  %.state874 = load <8 x i64>, ptr %.slot294, align 64
  %5306 = icmp slt <8 x i64> %.state874, splat (i64 1)
  %5307 = extractelement <8 x i1> %5306, i32 0
  br i1 %5307, label %direct.true875, label %direct.false876

direct.schedule.271:                              ; preds = %direct.true875
  %.state877 = load <8 x i64>, ptr %.slot294, align 64
  %5308 = select <8 x i1> %119, <8 x i64> %.state877, <8 x i64> zeroinitializer
  %5309 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5310 = srem <8 x i64> %5308, %5309
  %5311 = mul <8 x i64> %5310, splat (i64 8)
  %.spill.load878 = load <8 x i64>, ptr %.spill, align 64
  %5312 = add <8 x i64> %5311, %.spill.load878
  %5313 = icmp slt <8 x i64> %5312, splat (i64 2)
  %5314 = load <8 x i1>, ptr %.spill295, align 1
  %5315 = select <8 x i1> %119, <8 x i1> %5313, <8 x i1> %5314
  store <8 x i1> %5315, ptr %.spill295, align 1
  %5316 = and <8 x i1> %119, %5313
  %5317 = xor <8 x i1> %5313, splat (i1 true)
  %5318 = and <8 x i1> %119, %5317
  %5319 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5316)
  %5320 = bitcast <8 x i1> %5316 to i8
  %5321 = call i8 @llvm.cttz.i8(i8 %5320, i1 false)
  %5322 = zext i8 %5321 to i32
  %5323 = select i1 %5319, i32 %5322, i32 0
  %tile_snapshot.spill.load879 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %5324 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load879, 0
  %5325 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load879, 1
  %.state880 = load <8 x i64>, ptr %.slot294, align 64
  %5326 = mul <8 x i64> %.state880, splat (i64 32)
  %5327 = add <8 x i64> %5325, %5326
  %5328 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5324, 0
  %5329 = insertvalue { <8 x ptr>, <8 x i64> } %5328, <8 x i64> %5327, 1
  %5330 = extractvalue { <8 x ptr>, <8 x i64> } %5329, 0
  %5331 = extractvalue { <8 x ptr>, <8 x i64> } %5329, 1
  %5332 = getelementptr i8, <8 x ptr> %5330, <8 x i64> %5331
  %5333 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5332, <8 x i1> %5316, <8 x float> zeroinitializer)
  %5334 = load <8 x float>, ptr %.slot296, align 32
  %5335 = select <8 x i1> %5316, <8 x float> %5333, <8 x float> %5334
  store <8 x float> %5335, ptr %.slot296, align 32
  %5336 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5318)
  %5337 = bitcast <8 x i1> %5318 to i8
  %5338 = call i8 @llvm.cttz.i8(i8 %5337, i1 false)
  %5339 = zext i8 %5338 to i32
  %5340 = select i1 %5336, i32 %5339, i32 0
  %5341 = load <8 x float>, ptr %.slot296, align 32
  %5342 = select <8 x i1> %5318, <8 x float> zeroinitializer, <8 x float> %5341
  store <8 x float> %5342, ptr %.slot296, align 32
  br label %direct.schedule.273

direct.schedule.273:                              ; preds = %direct.schedule.271
  %.spill.load881 = load <8 x i1>, ptr %.spill295, align 1
  %5343 = and <8 x i1> %119, %.spill.load881
  %5344 = xor <8 x i1> %.spill.load881, splat (i1 true)
  %5345 = and <8 x i1> %119, %5344
  %5346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5343)
  %5347 = bitcast <8 x i1> %5343 to i8
  %5348 = call i8 @llvm.cttz.i8(i8 %5347, i1 false)
  %5349 = zext i8 %5348 to i32
  %5350 = select i1 %5346, i32 %5349, i32 0
  %tile_snapshot.spill.load882 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %5351 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load882, 0
  %5352 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load882, 1
  %.state883 = load <8 x i64>, ptr %.slot294, align 64
  %5353 = mul <8 x i64> %.state883, splat (i64 32)
  %5354 = add <8 x i64> %5352, %5353
  %5355 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5351, 0
  %5356 = insertvalue { <8 x ptr>, <8 x i64> } %5355, <8 x i64> %5354, 1
  %.state884 = load <8 x float>, ptr %.slot296, align 32
  %5357 = extractvalue { <8 x ptr>, <8 x i64> } %5356, 0
  %5358 = extractvalue { <8 x ptr>, <8 x i64> } %5356, 1
  %5359 = getelementptr i8, <8 x ptr> %5357, <8 x i64> %5358
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state884, <8 x ptr> align 1 %5359, <8 x i1> %5343)
  %5360 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5345)
  %5361 = bitcast <8 x i1> %5345 to i8
  %5362 = call i8 @llvm.cttz.i8(i8 %5361, i1 false)
  %5363 = zext i8 %5362 to i32
  %5364 = select i1 %5360, i32 %5363, i32 0
  br label %direct.schedule.275

direct.schedule.275:                              ; preds = %direct.schedule.273
  %.state885 = load <8 x i64>, ptr %.slot294, align 64
  %5365 = add <8 x i64> %.state885, splat (i64 1)
  %5366 = load <8 x i64>, ptr %.slot294, align 64
  %5367 = select <8 x i1> %119, <8 x i64> %5365, <8 x i64> %5366
  store <8 x i64> %5367, ptr %.slot294, align 64
  br label %direct.schedule.270

direct.schedule.276:                              ; preds = %direct.false876
  %5368 = load <8 x i64>, ptr %.slot297, align 64
  %5369 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5368
  store <8 x i64> %5369, ptr %.slot297, align 64
  br label %direct.schedule.277

direct.schedule.277:                              ; preds = %direct.schedule.282, %direct.schedule.276
  %.state886 = load <8 x i64>, ptr %.slot297, align 64
  %5370 = icmp slt <8 x i64> %.state886, splat (i64 1)
  %5371 = extractelement <8 x i1> %5370, i32 0
  br i1 %5371, label %direct.true887, label %direct.false888

direct.schedule.278:                              ; preds = %direct.true887
  %.state889 = load <8 x i64>, ptr %.slot297, align 64
  %5372 = select <8 x i1> %119, <8 x i64> %.state889, <8 x i64> zeroinitializer
  %5373 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5374 = srem <8 x i64> %5372, %5373
  %5375 = mul <8 x i64> %5374, splat (i64 8)
  %.spill.load890 = load <8 x i64>, ptr %.spill, align 64
  %5376 = add <8 x i64> %5375, %.spill.load890
  %5377 = icmp slt <8 x i64> %5376, splat (i64 2)
  %5378 = load <8 x i1>, ptr %.spill298, align 1
  %5379 = select <8 x i1> %119, <8 x i1> %5377, <8 x i1> %5378
  store <8 x i1> %5379, ptr %.spill298, align 1
  %5380 = and <8 x i1> %119, %5377
  %5381 = xor <8 x i1> %5377, splat (i1 true)
  %5382 = and <8 x i1> %119, %5381
  %5383 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5380)
  %5384 = bitcast <8 x i1> %5380 to i8
  %5385 = call i8 @llvm.cttz.i8(i8 %5384, i1 false)
  %5386 = zext i8 %5385 to i32
  %5387 = select i1 %5383, i32 %5386, i32 0
  %tile_snapshot.spill.load891 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %5388 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load891, 0
  %5389 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load891, 1
  %.state892 = load <8 x i64>, ptr %.slot297, align 64
  %5390 = mul <8 x i64> %.state892, splat (i64 32)
  %5391 = add <8 x i64> %5389, %5390
  %5392 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5388, 0
  %5393 = insertvalue { <8 x ptr>, <8 x i64> } %5392, <8 x i64> %5391, 1
  %5394 = extractvalue { <8 x ptr>, <8 x i64> } %5393, 0
  %5395 = extractvalue { <8 x ptr>, <8 x i64> } %5393, 1
  %5396 = getelementptr i8, <8 x ptr> %5394, <8 x i64> %5395
  %5397 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5396, <8 x i1> %5380, <8 x float> zeroinitializer)
  %5398 = load <8 x float>, ptr %.slot299, align 32
  %5399 = select <8 x i1> %5380, <8 x float> %5397, <8 x float> %5398
  store <8 x float> %5399, ptr %.slot299, align 32
  %5400 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5382)
  %5401 = bitcast <8 x i1> %5382 to i8
  %5402 = call i8 @llvm.cttz.i8(i8 %5401, i1 false)
  %5403 = zext i8 %5402 to i32
  %5404 = select i1 %5400, i32 %5403, i32 0
  %5405 = load <8 x float>, ptr %.slot299, align 32
  %5406 = select <8 x i1> %5382, <8 x float> zeroinitializer, <8 x float> %5405
  store <8 x float> %5406, ptr %.slot299, align 32
  br label %direct.schedule.280

direct.schedule.280:                              ; preds = %direct.schedule.278
  %.spill.load893 = load <8 x i1>, ptr %.spill298, align 1
  %5407 = and <8 x i1> %119, %.spill.load893
  %5408 = xor <8 x i1> %.spill.load893, splat (i1 true)
  %5409 = and <8 x i1> %119, %5408
  %5410 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5407)
  %5411 = bitcast <8 x i1> %5407 to i8
  %5412 = call i8 @llvm.cttz.i8(i8 %5411, i1 false)
  %5413 = zext i8 %5412 to i32
  %5414 = select i1 %5410, i32 %5413, i32 0
  %tile_snapshot.spill.load894 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %5415 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load894, 0
  %5416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load894, 1
  %.state895 = load <8 x i64>, ptr %.slot297, align 64
  %5417 = mul <8 x i64> %.state895, splat (i64 32)
  %5418 = add <8 x i64> %5416, %5417
  %5419 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5415, 0
  %5420 = insertvalue { <8 x ptr>, <8 x i64> } %5419, <8 x i64> %5418, 1
  %.state896 = load <8 x float>, ptr %.slot299, align 32
  %5421 = extractvalue { <8 x ptr>, <8 x i64> } %5420, 0
  %5422 = extractvalue { <8 x ptr>, <8 x i64> } %5420, 1
  %5423 = getelementptr i8, <8 x ptr> %5421, <8 x i64> %5422
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state896, <8 x ptr> align 1 %5423, <8 x i1> %5407)
  %5424 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5409)
  %5425 = bitcast <8 x i1> %5409 to i8
  %5426 = call i8 @llvm.cttz.i8(i8 %5425, i1 false)
  %5427 = zext i8 %5426 to i32
  %5428 = select i1 %5424, i32 %5427, i32 0
  br label %direct.schedule.282

direct.schedule.282:                              ; preds = %direct.schedule.280
  %.state897 = load <8 x i64>, ptr %.slot297, align 64
  %5429 = add <8 x i64> %.state897, splat (i64 1)
  %5430 = load <8 x i64>, ptr %.slot297, align 64
  %5431 = select <8 x i1> %119, <8 x i64> %5429, <8 x i64> %5430
  store <8 x i64> %5431, ptr %.slot297, align 64
  br label %direct.schedule.277

direct.schedule.283:                              ; preds = %direct.false888
  %5432 = load <8 x i64>, ptr %.slot300, align 64
  %5433 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5432
  store <8 x i64> %5433, ptr %.slot300, align 64
  br label %direct.schedule.284

direct.schedule.284:                              ; preds = %direct.schedule.289, %direct.schedule.283
  %.state898 = load <8 x i64>, ptr %.slot300, align 64
  %5434 = icmp slt <8 x i64> %.state898, splat (i64 2)
  %5435 = extractelement <8 x i1> %5434, i32 0
  br i1 %5435, label %direct.true899, label %direct.false900

direct.schedule.285:                              ; preds = %direct.true899
  %.state901 = load <8 x i64>, ptr %.slot300, align 64
  %5436 = select <8 x i1> %119, <8 x i64> %.state901, <8 x i64> zeroinitializer
  %5437 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5438 = srem <8 x i64> %5436, %5437
  %5439 = mul <8 x i64> %5438, splat (i64 8)
  %.spill.load902 = load <8 x i64>, ptr %.spill, align 64
  %5440 = add <8 x i64> %5439, %.spill.load902
  %5441 = icmp slt <8 x i64> %5440, splat (i64 3)
  %5442 = load <8 x i1>, ptr %.spill301, align 1
  %5443 = select <8 x i1> %119, <8 x i1> %5441, <8 x i1> %5442
  store <8 x i1> %5443, ptr %.spill301, align 1
  %5444 = and <8 x i1> %119, %5441
  %5445 = xor <8 x i1> %5441, splat (i1 true)
  %5446 = and <8 x i1> %119, %5445
  %5447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5444)
  %5448 = bitcast <8 x i1> %5444 to i8
  %5449 = call i8 @llvm.cttz.i8(i8 %5448, i1 false)
  %5450 = zext i8 %5449 to i32
  %5451 = select i1 %5447, i32 %5450, i32 0
  %tile_snapshot.spill.load903 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill118, align 64
  %5452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load903, 0
  %5453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load903, 1
  %.state904 = load <8 x i64>, ptr %.slot300, align 64
  %5454 = mul <8 x i64> %.state904, splat (i64 32)
  %5455 = add <8 x i64> %5453, %5454
  %5456 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5452, 0
  %5457 = insertvalue { <8 x ptr>, <8 x i64> } %5456, <8 x i64> %5455, 1
  %5458 = extractvalue { <8 x ptr>, <8 x i64> } %5457, 0
  %5459 = extractvalue { <8 x ptr>, <8 x i64> } %5457, 1
  %5460 = getelementptr i8, <8 x ptr> %5458, <8 x i64> %5459
  %5461 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5460, <8 x i1> %5444, <8 x float> zeroinitializer)
  %5462 = load <8 x float>, ptr %.slot302, align 32
  %5463 = select <8 x i1> %5444, <8 x float> %5461, <8 x float> %5462
  store <8 x float> %5463, ptr %.slot302, align 32
  %5464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5446)
  %5465 = bitcast <8 x i1> %5446 to i8
  %5466 = call i8 @llvm.cttz.i8(i8 %5465, i1 false)
  %5467 = zext i8 %5466 to i32
  %5468 = select i1 %5464, i32 %5467, i32 0
  %5469 = load <8 x float>, ptr %.slot302, align 32
  %5470 = select <8 x i1> %5446, <8 x float> zeroinitializer, <8 x float> %5469
  store <8 x float> %5470, ptr %.slot302, align 32
  br label %direct.schedule.287

direct.schedule.287:                              ; preds = %direct.schedule.285
  %.spill.load905 = load <8 x i1>, ptr %.spill301, align 1
  %5471 = and <8 x i1> %119, %.spill.load905
  %5472 = xor <8 x i1> %.spill.load905, splat (i1 true)
  %5473 = and <8 x i1> %119, %5472
  %5474 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5471)
  %5475 = bitcast <8 x i1> %5471 to i8
  %5476 = call i8 @llvm.cttz.i8(i8 %5475, i1 false)
  %5477 = zext i8 %5476 to i32
  %5478 = select i1 %5474, i32 %5477, i32 0
  %tile_snapshot.spill.load906 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %5479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load906, 0
  %5480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load906, 1
  %.state907 = load <8 x i64>, ptr %.slot300, align 64
  %5481 = mul <8 x i64> %.state907, splat (i64 32)
  %5482 = add <8 x i64> %5480, %5481
  %5483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5479, 0
  %5484 = insertvalue { <8 x ptr>, <8 x i64> } %5483, <8 x i64> %5482, 1
  %.state908 = load <8 x float>, ptr %.slot302, align 32
  %5485 = extractvalue { <8 x ptr>, <8 x i64> } %5484, 0
  %5486 = extractvalue { <8 x ptr>, <8 x i64> } %5484, 1
  %5487 = getelementptr i8, <8 x ptr> %5485, <8 x i64> %5486
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state908, <8 x ptr> align 1 %5487, <8 x i1> %5471)
  %5488 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5473)
  %5489 = bitcast <8 x i1> %5473 to i8
  %5490 = call i8 @llvm.cttz.i8(i8 %5489, i1 false)
  %5491 = zext i8 %5490 to i32
  %5492 = select i1 %5488, i32 %5491, i32 0
  br label %direct.schedule.289

direct.schedule.289:                              ; preds = %direct.schedule.287
  %.state909 = load <8 x i64>, ptr %.slot300, align 64
  %5493 = add <8 x i64> %.state909, splat (i64 1)
  %5494 = load <8 x i64>, ptr %.slot300, align 64
  %5495 = select <8 x i1> %119, <8 x i64> %5493, <8 x i64> %5494
  store <8 x i64> %5495, ptr %.slot300, align 64
  br label %direct.schedule.284

direct.schedule.290:                              ; preds = %direct.false900
  %.state910 = load <8 x i64>, ptr %.slot120, align 64
  %5496 = add <8 x i64> %.state910, splat (i64 1)
  %5497 = load <8 x i64>, ptr %.slot120, align 64
  %5498 = select <8 x i1> %119, <8 x i64> %5496, <8 x i64> %5497
  store <8 x i64> %5498, ptr %.slot120, align 64
  br label %direct.schedule.23

direct.schedule.291:                              ; preds = %direct.false363
  %5499 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill303, align 64
  %5500 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %5501 = extractvalue { <8 x ptr>, <8 x i64> } %5499, 0
  %5502 = select <8 x i1> %119, <8 x ptr> %5500, <8 x ptr> %5501
  %5503 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %5504 = extractvalue { <8 x ptr>, <8 x i64> } %5499, 1
  %5505 = select <8 x i1> %119, <8 x i64> %5503, <8 x i64> %5504
  %5506 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5502, 0
  %5507 = insertvalue { <8 x ptr>, <8 x i64> } %5506, <8 x i64> %5505, 1
  store { <8 x ptr>, <8 x i64> } %5507, ptr %tile_snapshot.spill303, align 64
  %5508 = load <8 x i64>, ptr %.slot304, align 64
  %5509 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5508
  store <8 x i64> %5509, ptr %.slot304, align 64
  br label %direct.schedule.292

direct.schedule.292:                              ; preds = %direct.schedule.299, %direct.schedule.291
  %.state911 = load <8 x i64>, ptr %.slot304, align 64
  %5510 = icmp slt <8 x i64> %.state911, splat (i64 2)
  %5511 = extractelement <8 x i1> %5510, i32 0
  br i1 %5511, label %direct.true912, label %direct.false913

direct.schedule.293:                              ; preds = %direct.true912
  %.state914 = load <8 x i64>, ptr %.slot304, align 64
  %5512 = select <8 x i1> %119, <8 x i64> %.state914, <8 x i64> zeroinitializer
  %5513 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5514 = srem <8 x i64> %5512, %5513
  %.state915 = load <8 x i64>, ptr %.slot304, align 64
  %5515 = select <8 x i1> %119, <8 x i64> %.state915, <8 x i64> zeroinitializer
  %5516 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5517 = sdiv <8 x i64> %5515, %5516
  %5518 = mul <8 x i64> %5514, splat (i64 8)
  %.spill.load916 = load <8 x i64>, ptr %.spill, align 64
  %5519 = add <8 x i64> %5518, %.spill.load916
  %5520 = icmp slt <8 x i64> %5519, splat (i64 3)
  %5521 = load <8 x i1>, ptr %.spill305, align 1
  %5522 = select <8 x i1> %119, <8 x i1> %5520, <8 x i1> %5521
  store <8 x i1> %5522, ptr %.spill305, align 1
  %5523 = select <8 x i1> %119, <8 x i64> %5517, <8 x i64> zeroinitializer
  %5524 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %5525 = srem <8 x i64> %5523, %5524
  %5526 = load <8 x i64>, ptr %.spill306, align 64
  %5527 = select <8 x i1> %119, <8 x i64> %5525, <8 x i64> %5526
  store <8 x i64> %5527, ptr %.spill306, align 64
  store i64 0, ptr %.spill307, align 4
  %5528 = add <8 x i64> zeroinitializer, %5525
  %5529 = mul <8 x i64> %5528, splat (i64 1)
  %5530 = add <8 x i64> %5529, %5514
  %5531 = and <8 x i1> %119, %5520
  %5532 = xor <8 x i1> %5520, splat (i1 true)
  %5533 = and <8 x i1> %119, %5532
  %5534 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5531)
  %5535 = bitcast <8 x i1> %5531 to i8
  %5536 = call i8 @llvm.cttz.i8(i8 %5535, i1 false)
  %5537 = zext i8 %5536 to i32
  %5538 = select i1 %5534, i32 %5537, i32 0
  %tile_snapshot.spill.load917 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %5539 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load917, 0
  %5540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load917, 1
  %5541 = mul <8 x i64> %5530, splat (i64 32)
  %5542 = add <8 x i64> %5540, %5541
  %5543 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5539, 0
  %5544 = insertvalue { <8 x ptr>, <8 x i64> } %5543, <8 x i64> %5542, 1
  %5545 = extractvalue { <8 x ptr>, <8 x i64> } %5544, 0
  %5546 = extractvalue { <8 x ptr>, <8 x i64> } %5544, 1
  %5547 = getelementptr i8, <8 x ptr> %5545, <8 x i64> %5546
  %5548 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5547, <8 x i1> %5531, <8 x float> zeroinitializer)
  %5549 = load <8 x float>, ptr %.slot308, align 32
  %5550 = select <8 x i1> %5531, <8 x float> %5548, <8 x float> %5549
  store <8 x float> %5550, ptr %.slot308, align 32
  %5551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5533)
  %5552 = bitcast <8 x i1> %5533 to i8
  %5553 = call i8 @llvm.cttz.i8(i8 %5552, i1 false)
  %5554 = zext i8 %5553 to i32
  %5555 = select i1 %5551, i32 %5554, i32 0
  %5556 = load <8 x float>, ptr %.slot308, align 32
  %5557 = select <8 x i1> %5533, <8 x float> zeroinitializer, <8 x float> %5556
  store <8 x float> %5557, ptr %.slot308, align 32
  br label %direct.schedule.295

direct.schedule.295:                              ; preds = %direct.schedule.293
  %.spill.load918 = load <8 x i64>, ptr %.spill306, align 64
  %5558 = select <8 x i1> %119, <8 x i64> %.spill.load918, <8 x i64> zeroinitializer
  %5559 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %5560 = sdiv <8 x i64> %5558, %5559
  %.spill.load919 = load i64, ptr %.spill307, align 4
  %5561 = mul i64 %.spill.load919, 1
  %.splatinsert920 = insertelement <8 x i64> poison, i64 %5561, i64 0
  %.splat921 = shufflevector <8 x i64> %.splatinsert920, <8 x i64> poison, <8 x i32> zeroinitializer
  %5562 = add <8 x i64> %.splat921, %5560
  %.spill.load922 = load <8 x i64>, ptr %.spill306, align 64
  %5563 = select <8 x i1> %119, <8 x i64> %.spill.load922, <8 x i64> zeroinitializer
  %5564 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %5565 = srem <8 x i64> %5563, %5564
  %5566 = load <8 x i64>, ptr %.spill309, align 64
  %5567 = select <8 x i1> %119, <8 x i64> %5565, <8 x i64> %5566
  store <8 x i64> %5567, ptr %.spill309, align 64
  %.spill.load923 = load <8 x i64>, ptr %.spill, align 64
  %5568 = icmp eq <8 x i64> %.spill.load923, %5565
  %5569 = and <8 x i1> %119, %5568
  %5570 = xor <8 x i1> %5568, splat (i1 true)
  %5571 = and <8 x i1> %119, %5570
  %5572 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5569)
  %5573 = bitcast <8 x i1> %5569 to i8
  %5574 = call i8 @llvm.cttz.i8(i8 %5573, i1 false)
  %5575 = zext i8 %5574 to i32
  %5576 = select i1 %5572, i32 %5575, i32 0
  %tile_snapshot.spill.load924 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %5577 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load924, 0
  %5578 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load924, 1
  %5579 = mul <8 x i64> %5562, splat (i64 32)
  %5580 = add <8 x i64> %5578, %5579
  %5581 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5577, 0
  %5582 = insertvalue { <8 x ptr>, <8 x i64> } %5581, <8 x i64> %5580, 1
  %5583 = extractvalue { <8 x ptr>, <8 x i64> } %5582, 0
  %5584 = extractvalue { <8 x ptr>, <8 x i64> } %5582, 1
  %5585 = getelementptr i8, <8 x ptr> %5583, <8 x i64> %5584
  %5586 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5585, <8 x i1> %5569, <8 x float> zeroinitializer)
  %5587 = load <8 x float>, ptr %.slot310, align 32
  %5588 = select <8 x i1> %5569, <8 x float> %5586, <8 x float> %5587
  store <8 x float> %5588, ptr %.slot310, align 32
  %5589 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5571)
  %5590 = bitcast <8 x i1> %5571 to i8
  %5591 = call i8 @llvm.cttz.i8(i8 %5590, i1 false)
  %5592 = zext i8 %5591 to i32
  %5593 = select i1 %5589, i32 %5592, i32 0
  %5594 = load <8 x float>, ptr %.slot310, align 32
  %5595 = select <8 x i1> %5571, <8 x float> zeroinitializer, <8 x float> %5594
  store <8 x float> %5595, ptr %.slot310, align 32
  br label %direct.schedule.297

direct.schedule.297:                              ; preds = %direct.schedule.295
  %.spill.load925 = load <8 x i64>, ptr %.spill309, align 64
  %5596 = trunc <8 x i64> %.spill.load925 to <8 x i32>
  %.state926 = load <8 x float>, ptr %.slot310, align 32
  %5597 = extractelement <8 x i32> %5596, i64 0
  %5598 = icmp ult i32 %5597, 8
  %5599 = select i1 %5598, i32 %5597, i32 0
  %5600 = extractelement <8 x i1> %119, i32 %5599
  %5601 = extractelement <8 x i1> %119, i64 0
  %5602 = and i1 %5598, %5600
  %5603 = and i1 %5601, %5602
  %5604 = extractelement <8 x float> %.state926, i32 %5599
  %5605 = select i1 %5603, float %5604, float 0.000000e+00
  %5606 = insertelement <8 x float> poison, float %5605, i64 0
  %5607 = xor i1 %5603, true
  %5608 = and i1 %5601, %5607
  %5609 = insertelement <8 x i1> poison, i1 %5608, i64 0
  %5610 = extractelement <8 x i32> %5596, i64 1
  %5611 = icmp ult i32 %5610, 8
  %5612 = select i1 %5611, i32 %5610, i32 0
  %5613 = extractelement <8 x i1> %119, i32 %5612
  %5614 = extractelement <8 x i1> %119, i64 1
  %5615 = and i1 %5611, %5613
  %5616 = and i1 %5614, %5615
  %5617 = extractelement <8 x float> %.state926, i32 %5612
  %5618 = select i1 %5616, float %5617, float 0.000000e+00
  %5619 = insertelement <8 x float> %5606, float %5618, i64 1
  %5620 = xor i1 %5616, true
  %5621 = and i1 %5614, %5620
  %5622 = insertelement <8 x i1> %5609, i1 %5621, i64 1
  %5623 = extractelement <8 x i32> %5596, i64 2
  %5624 = icmp ult i32 %5623, 8
  %5625 = select i1 %5624, i32 %5623, i32 0
  %5626 = extractelement <8 x i1> %119, i32 %5625
  %5627 = extractelement <8 x i1> %119, i64 2
  %5628 = and i1 %5624, %5626
  %5629 = and i1 %5627, %5628
  %5630 = extractelement <8 x float> %.state926, i32 %5625
  %5631 = select i1 %5629, float %5630, float 0.000000e+00
  %5632 = insertelement <8 x float> %5619, float %5631, i64 2
  %5633 = xor i1 %5629, true
  %5634 = and i1 %5627, %5633
  %5635 = insertelement <8 x i1> %5622, i1 %5634, i64 2
  %5636 = extractelement <8 x i32> %5596, i64 3
  %5637 = icmp ult i32 %5636, 8
  %5638 = select i1 %5637, i32 %5636, i32 0
  %5639 = extractelement <8 x i1> %119, i32 %5638
  %5640 = extractelement <8 x i1> %119, i64 3
  %5641 = and i1 %5637, %5639
  %5642 = and i1 %5640, %5641
  %5643 = extractelement <8 x float> %.state926, i32 %5638
  %5644 = select i1 %5642, float %5643, float 0.000000e+00
  %5645 = insertelement <8 x float> %5632, float %5644, i64 3
  %5646 = xor i1 %5642, true
  %5647 = and i1 %5640, %5646
  %5648 = insertelement <8 x i1> %5635, i1 %5647, i64 3
  %5649 = extractelement <8 x i32> %5596, i64 4
  %5650 = icmp ult i32 %5649, 8
  %5651 = select i1 %5650, i32 %5649, i32 0
  %5652 = extractelement <8 x i1> %119, i32 %5651
  %5653 = extractelement <8 x i1> %119, i64 4
  %5654 = and i1 %5650, %5652
  %5655 = and i1 %5653, %5654
  %5656 = extractelement <8 x float> %.state926, i32 %5651
  %5657 = select i1 %5655, float %5656, float 0.000000e+00
  %5658 = insertelement <8 x float> %5645, float %5657, i64 4
  %5659 = xor i1 %5655, true
  %5660 = and i1 %5653, %5659
  %5661 = insertelement <8 x i1> %5648, i1 %5660, i64 4
  %5662 = extractelement <8 x i32> %5596, i64 5
  %5663 = icmp ult i32 %5662, 8
  %5664 = select i1 %5663, i32 %5662, i32 0
  %5665 = extractelement <8 x i1> %119, i32 %5664
  %5666 = extractelement <8 x i1> %119, i64 5
  %5667 = and i1 %5663, %5665
  %5668 = and i1 %5666, %5667
  %5669 = extractelement <8 x float> %.state926, i32 %5664
  %5670 = select i1 %5668, float %5669, float 0.000000e+00
  %5671 = insertelement <8 x float> %5658, float %5670, i64 5
  %5672 = xor i1 %5668, true
  %5673 = and i1 %5666, %5672
  %5674 = insertelement <8 x i1> %5661, i1 %5673, i64 5
  %5675 = extractelement <8 x i32> %5596, i64 6
  %5676 = icmp ult i32 %5675, 8
  %5677 = select i1 %5676, i32 %5675, i32 0
  %5678 = extractelement <8 x i1> %119, i32 %5677
  %5679 = extractelement <8 x i1> %119, i64 6
  %5680 = and i1 %5676, %5678
  %5681 = and i1 %5679, %5680
  %5682 = extractelement <8 x float> %.state926, i32 %5677
  %5683 = select i1 %5681, float %5682, float 0.000000e+00
  %5684 = insertelement <8 x float> %5671, float %5683, i64 6
  %5685 = xor i1 %5681, true
  %5686 = and i1 %5679, %5685
  %5687 = insertelement <8 x i1> %5674, i1 %5686, i64 6
  %5688 = extractelement <8 x i32> %5596, i64 7
  %5689 = icmp ult i32 %5688, 8
  %5690 = select i1 %5689, i32 %5688, i32 0
  %5691 = extractelement <8 x i1> %119, i32 %5690
  %5692 = extractelement <8 x i1> %119, i64 7
  %5693 = and i1 %5689, %5691
  %5694 = and i1 %5692, %5693
  %5695 = extractelement <8 x float> %.state926, i32 %5690
  %5696 = select i1 %5694, float %5695, float 0.000000e+00
  %5697 = insertelement <8 x float> %5684, float %5696, i64 7
  %5698 = xor i1 %5694, true
  %5699 = and i1 %5692, %5698
  %5700 = insertelement <8 x i1> %5687, i1 %5699, i64 7
  %.state927 = load <8 x float>, ptr %.slot308, align 32
  %5701 = fdiv <8 x float> %.state927, %5697
  %.spill.load928 = load <8 x i1>, ptr %.spill305, align 1
  %5702 = and <8 x i1> %119, %.spill.load928
  %5703 = xor <8 x i1> %.spill.load928, splat (i1 true)
  %5704 = and <8 x i1> %119, %5703
  %5705 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5702)
  %5706 = bitcast <8 x i1> %5702 to i8
  %5707 = call i8 @llvm.cttz.i8(i8 %5706, i1 false)
  %5708 = zext i8 %5707 to i32
  %5709 = select i1 %5705, i32 %5708, i32 0
  %tile_snapshot.spill.load929 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill303, align 64
  %5710 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load929, 0
  %5711 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load929, 1
  %.state930 = load <8 x i64>, ptr %.slot304, align 64
  %5712 = mul <8 x i64> %.state930, splat (i64 32)
  %5713 = add <8 x i64> %5711, %5712
  %5714 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5710, 0
  %5715 = insertvalue { <8 x ptr>, <8 x i64> } %5714, <8 x i64> %5713, 1
  %5716 = extractvalue { <8 x ptr>, <8 x i64> } %5715, 0
  %5717 = extractvalue { <8 x ptr>, <8 x i64> } %5715, 1
  %5718 = getelementptr i8, <8 x ptr> %5716, <8 x i64> %5717
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %5701, <8 x ptr> align 1 %5718, <8 x i1> %5702)
  %5719 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5704)
  %5720 = bitcast <8 x i1> %5704 to i8
  %5721 = call i8 @llvm.cttz.i8(i8 %5720, i1 false)
  %5722 = zext i8 %5721 to i32
  %5723 = select i1 %5719, i32 %5722, i32 0
  br label %direct.schedule.299

direct.schedule.299:                              ; preds = %direct.schedule.297
  %.state931 = load <8 x i64>, ptr %.slot304, align 64
  %5724 = add <8 x i64> %.state931, splat (i64 1)
  %5725 = load <8 x i64>, ptr %.slot304, align 64
  %5726 = select <8 x i1> %119, <8 x i64> %5724, <8 x i64> %5725
  store <8 x i64> %5726, ptr %.slot304, align 64
  br label %direct.schedule.292

direct.schedule.300:                              ; preds = %direct.false913
  %5727 = load <8 x i64>, ptr %.slot311, align 64
  %5728 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5727
  store <8 x i64> %5728, ptr %.slot311, align 64
  br label %direct.schedule.301

direct.schedule.301:                              ; preds = %direct.schedule.306, %direct.schedule.300
  %.state932 = load <8 x i64>, ptr %.slot311, align 64
  %5729 = icmp slt <8 x i64> %.state932, splat (i64 2)
  %5730 = extractelement <8 x i1> %5729, i32 0
  br i1 %5730, label %direct.true933, label %direct.false934

direct.schedule.302:                              ; preds = %direct.true933
  %.state935 = load <8 x i64>, ptr %.slot311, align 64
  %5731 = select <8 x i1> %119, <8 x i64> %.state935, <8 x i64> zeroinitializer
  %5732 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5733 = srem <8 x i64> %5731, %5732
  %.state936 = load <8 x i64>, ptr %.slot311, align 64
  %5734 = select <8 x i1> %119, <8 x i64> %.state936, <8 x i64> zeroinitializer
  %5735 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5736 = sdiv <8 x i64> %5734, %5735
  %5737 = mul <8 x i64> %5733, splat (i64 8)
  %.spill.load937 = load <8 x i64>, ptr %.spill, align 64
  %5738 = add <8 x i64> %5737, %.spill.load937
  %5739 = icmp slt <8 x i64> %5738, splat (i64 3)
  %5740 = load <8 x i1>, ptr %.spill312, align 1
  %5741 = select <8 x i1> %119, <8 x i1> %5739, <8 x i1> %5740
  store <8 x i1> %5741, ptr %.spill312, align 1
  %5742 = select <8 x i1> %5739, <8 x i64> %5738, <8 x i64> splat (i64 2)
  %5743 = load <8 x i64>, ptr %.spill313, align 64
  %5744 = select <8 x i1> %119, <8 x i64> %5742, <8 x i64> %5743
  store <8 x i64> %5744, ptr %.spill313, align 64
  %5745 = select <8 x i1> %119, <8 x i64> %5736, <8 x i64> zeroinitializer
  %5746 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %5747 = srem <8 x i64> %5745, %5746
  %5748 = load <8 x i64>, ptr %.spill314, align 64
  %5749 = select <8 x i1> %119, <8 x i64> %5747, <8 x i64> %5748
  store <8 x i64> %5749, ptr %.spill314, align 64
  %5750 = select <8 x i1> %119, <8 x i64> %5736, <8 x i64> zeroinitializer
  %5751 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %5752 = sdiv <8 x i64> %5750, %5751
  %5753 = select <8 x i1> %119, <8 x i64> %5752, <8 x i64> zeroinitializer
  %5754 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5755 = srem <8 x i64> %5753, %5754
  %5756 = load <8 x i64>, ptr %.spill315, align 64
  %5757 = select <8 x i1> %119, <8 x i64> %5755, <8 x i64> %5756
  store <8 x i64> %5757, ptr %.spill315, align 64
  %5758 = select <8 x i1> %119, <8 x i64> %5752, <8 x i64> zeroinitializer
  %5759 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5760 = sdiv <8 x i64> %5758, %5759
  %5761 = select <8 x i1> %119, <8 x i64> %5760, <8 x i64> zeroinitializer
  %5762 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5763 = srem <8 x i64> %5761, %5762
  %5764 = load <8 x i64>, ptr %.spill316, align 64
  %5765 = select <8 x i1> %119, <8 x i64> %5763, <8 x i64> %5764
  store <8 x i64> %5765, ptr %.spill316, align 64
  store i64 0, ptr %.spill317, align 4
  %5766 = and <8 x i1> %119, %5739
  %5767 = xor <8 x i1> %5739, splat (i1 true)
  %5768 = and <8 x i1> %119, %5767
  %5769 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5766)
  %5770 = bitcast <8 x i1> %5766 to i8
  %5771 = call i8 @llvm.cttz.i8(i8 %5770, i1 false)
  %5772 = zext i8 %5771 to i32
  %5773 = select i1 %5769, i32 %5772, i32 0
  %tile_snapshot.spill.load938 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill303, align 64
  %5774 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load938, 0
  %5775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load938, 1
  %.state939 = load <8 x i64>, ptr %.slot311, align 64
  %5776 = mul <8 x i64> %.state939, splat (i64 32)
  %5777 = add <8 x i64> %5775, %5776
  %5778 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5774, 0
  %5779 = insertvalue { <8 x ptr>, <8 x i64> } %5778, <8 x i64> %5777, 1
  %5780 = extractvalue { <8 x ptr>, <8 x i64> } %5779, 0
  %5781 = extractvalue { <8 x ptr>, <8 x i64> } %5779, 1
  %5782 = getelementptr i8, <8 x ptr> %5780, <8 x i64> %5781
  %5783 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %5782, <8 x i1> %5766, <8 x float> zeroinitializer)
  %5784 = load <8 x float>, ptr %.slot318, align 32
  %5785 = select <8 x i1> %5766, <8 x float> %5783, <8 x float> %5784
  store <8 x float> %5785, ptr %.slot318, align 32
  %5786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5768)
  %5787 = bitcast <8 x i1> %5768 to i8
  %5788 = call i8 @llvm.cttz.i8(i8 %5787, i1 false)
  %5789 = zext i8 %5788 to i32
  %5790 = select i1 %5786, i32 %5789, i32 0
  %5791 = load <8 x float>, ptr %.slot318, align 32
  %5792 = select <8 x i1> %5768, <8 x float> zeroinitializer, <8 x float> %5791
  store <8 x float> %5792, ptr %.slot318, align 32
  br label %direct.schedule.304

direct.schedule.304:                              ; preds = %direct.schedule.302
  %.spill.load940 = load <8 x i64>, ptr %.spill316, align 64
  %5793 = add <8 x i64> zeroinitializer, %.spill.load940
  %.spill.load941 = load i64, ptr %.spill317, align 4
  %.splatinsert942 = insertelement <8 x i64> poison, i64 %.spill.load941, i64 0
  %.splat943 = shufflevector <8 x i64> %.splatinsert942, <8 x i64> poison, <8 x i32> zeroinitializer
  %5794 = add <8 x i64> %.splat943, %5793
  %.spill.load944 = load <8 x i64>, ptr %.spill106, align 64
  %.spill.load945 = load <8 x i64>, ptr %.spill315, align 64
  %5795 = add <8 x i64> %.spill.load944, %.spill.load945
  %5796 = mul <8 x i64> %5794, splat (i64 2)
  %5797 = add <8 x i64> %5796, %5795
  %.spill.load946 = load <8 x i64>, ptr %.spill107, align 64
  %.spill.load947 = load <8 x i64>, ptr %.spill314, align 64
  %5798 = add <8 x i64> %.spill.load946, %.spill.load947
  %5799 = mul <8 x i64> %5797, splat (i64 3)
  %5800 = add <8 x i64> %5799, %5798
  %5801 = icmp sge <8 x i64> %5798, zeroinitializer
  %5802 = and <8 x i1> splat (i1 true), %5801
  %5803 = icmp slt <8 x i64> %5798, splat (i64 3)
  %5804 = and <8 x i1> %5802, %5803
  %.spill.load948 = load <8 x i64>, ptr %.spill313, align 64
  %5805 = add <8 x i64> zeroinitializer, %.spill.load948
  %5806 = mul <8 x i64> %5800, splat (i64 3)
  %5807 = add <8 x i64> %5806, %5805
  %.spill.load949 = load <8 x i1>, ptr %.spill312, align 1
  %5808 = and <8 x i1> %5804, %.spill.load949
  %5809 = and <8 x i1> %119, %5808
  %5810 = xor <8 x i1> %5808, splat (i1 true)
  %5811 = and <8 x i1> %119, %5810
  %5812 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5809)
  %5813 = bitcast <8 x i1> %5809 to i8
  %5814 = call i8 @llvm.cttz.i8(i8 %5813, i1 false)
  %5815 = zext i8 %5814 to i32
  %5816 = select i1 %5812, i32 %5815, i32 0
  %.state950 = load <8 x float>, ptr %.slot318, align 32
  %5817 = extractvalue { ptr, i64 } %95, 0
  %5818 = mul <8 x i64> %5807, splat (i64 4)
  %5819 = getelementptr i8, ptr %5817, <8 x i64> %5818
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state950, <8 x ptr> align 1 %5819, <8 x i1> %5809)
  %5820 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5811)
  %5821 = bitcast <8 x i1> %5811 to i8
  %5822 = call i8 @llvm.cttz.i8(i8 %5821, i1 false)
  %5823 = zext i8 %5822 to i32
  %5824 = select i1 %5820, i32 %5823, i32 0
  br label %direct.schedule.306

direct.schedule.306:                              ; preds = %direct.schedule.304
  %.state951 = load <8 x i64>, ptr %.slot311, align 64
  %5825 = add <8 x i64> %.state951, splat (i64 1)
  %5826 = load <8 x i64>, ptr %.slot311, align 64
  %5827 = select <8 x i1> %119, <8 x i64> %5825, <8 x i64> %5826
  store <8 x i64> %5827, ptr %.slot311, align 64
  br label %direct.schedule.301

direct.schedule.307:                              ; preds = %direct.false934
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.7

direct.true338:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false339:                                  ; preds = %direct.schedule.8
  br label %direct.schedule.12

direct.true346:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false347:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.17

direct.true354:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false355:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.22

direct.true362:                                   ; preds = %direct.schedule.23
  br label %direct.schedule.24

direct.false363:                                  ; preds = %direct.schedule.23
  br label %direct.schedule.291

direct.true366:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false367:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.31

direct.true379:                                   ; preds = %direct.schedule.32
  br label %direct.schedule.33

direct.false380:                                  ; preds = %direct.schedule.32
  br label %direct.schedule.38

direct.true392:                                   ; preds = %direct.schedule.39
  br label %direct.schedule.40

direct.false393:                                  ; preds = %direct.schedule.39
  br label %direct.schedule.50

direct.true398:                                   ; preds = %direct.schedule.41
  br label %direct.schedule.42

direct.false399:                                  ; preds = %direct.schedule.41
  br label %direct.schedule.47

direct.true427:                                   ; preds = %direct.schedule.51
  br label %direct.schedule.52

direct.false428:                                  ; preds = %direct.schedule.51
  br label %direct.schedule.57

direct.true439:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false440:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.62

direct.true447:                                   ; preds = %direct.schedule.63
  br label %direct.schedule.64

direct.false448:                                  ; preds = %direct.schedule.63
  br label %direct.schedule.69

direct.true459:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false460:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.76

direct.true470:                                   ; preds = %direct.schedule.77
  br label %direct.schedule.78

direct.false471:                                  ; preds = %direct.schedule.77
  br label %direct.schedule.81

direct.true478:                                   ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false479:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.88

direct.true490:                                   ; preds = %direct.schedule.89
  br label %direct.schedule.90

direct.false491:                                  ; preds = %direct.schedule.89
  br label %direct.schedule.93

direct.true498:                                   ; preds = %direct.schedule.94
  br label %direct.schedule.95

direct.false499:                                  ; preds = %direct.schedule.94
  br label %direct.schedule.100

direct.true510:                                   ; preds = %direct.schedule.101
  br label %direct.schedule.102

direct.false511:                                  ; preds = %direct.schedule.101
  br label %direct.schedule.107

direct.true521:                                   ; preds = %direct.schedule.108
  br label %direct.schedule.109

direct.false522:                                  ; preds = %direct.schedule.108
  br label %direct.schedule.114

direct.true532:                                   ; preds = %direct.schedule.115
  br label %direct.schedule.116

direct.false533:                                  ; preds = %direct.schedule.115
  br label %direct.schedule.123

direct.true550:                                   ; preds = %direct.schedule.124
  br label %direct.schedule.125

direct.false551:                                  ; preds = %direct.schedule.124
  br label %direct.schedule.132

direct.true567:                                   ; preds = %direct.schedule.133
  br label %direct.schedule.134

direct.false568:                                  ; preds = %direct.schedule.133
  br label %direct.schedule.141

direct.true587:                                   ; preds = %direct.schedule.142
  br label %direct.schedule.143

direct.false588:                                  ; preds = %direct.schedule.142
  br label %direct.schedule.149

direct.true592:                                   ; preds = %direct.schedule.144
  br label %direct.schedule.145

direct.false593:                                  ; preds = %direct.schedule.144
  br label %direct.schedule.148

direct.true621:                                   ; preds = %direct.schedule.150
  br label %direct.schedule.151

direct.false622:                                  ; preds = %direct.schedule.150
  br label %direct.schedule.158

direct.true636:                                   ; preds = %direct.schedule.159
  br label %direct.schedule.160

direct.false637:                                  ; preds = %direct.schedule.159
  br label %direct.schedule.167

direct.true651:                                   ; preds = %direct.schedule.168
  br label %direct.schedule.169

direct.false652:                                  ; preds = %direct.schedule.168
  br label %direct.schedule.174

direct.true662:                                   ; preds = %direct.schedule.175
  br label %direct.schedule.176

direct.false663:                                  ; preds = %direct.schedule.175
  br label %direct.schedule.183

direct.true683:                                   ; preds = %direct.schedule.184
  br label %direct.schedule.185

direct.false684:                                  ; preds = %direct.schedule.184
  br label %direct.schedule.190

direct.true696:                                   ; preds = %direct.schedule.191
  br label %direct.schedule.192

direct.false697:                                  ; preds = %direct.schedule.191
  br label %direct.schedule.199

direct.true716:                                   ; preds = %direct.schedule.200
  br label %direct.schedule.201

direct.false717:                                  ; preds = %direct.schedule.200
  br label %direct.schedule.208

direct.true731:                                   ; preds = %direct.schedule.209
  br label %direct.schedule.210

direct.false732:                                  ; preds = %direct.schedule.209
  br label %direct.schedule.216

direct.true736:                                   ; preds = %direct.schedule.211
  br label %direct.schedule.212

direct.false737:                                  ; preds = %direct.schedule.211
  br label %direct.schedule.215

direct.true765:                                   ; preds = %direct.schedule.217
  br label %direct.schedule.218

direct.false766:                                  ; preds = %direct.schedule.217
  br label %direct.schedule.225

direct.true780:                                   ; preds = %direct.schedule.226
  br label %direct.schedule.227

direct.false781:                                  ; preds = %direct.schedule.226
  br label %direct.schedule.234

direct.true801:                                   ; preds = %direct.schedule.235
  br label %direct.schedule.236

direct.false802:                                  ; preds = %direct.schedule.235
  br label %direct.schedule.248

direct.true810:                                   ; preds = %direct.schedule.239
  br label %direct.schedule.240

direct.false811:                                  ; preds = %direct.schedule.239
  br label %direct.schedule.245

direct.true839:                                   ; preds = %direct.schedule.249
  br label %direct.schedule.250

direct.false840:                                  ; preds = %direct.schedule.249
  br label %direct.schedule.255

direct.true851:                                   ; preds = %direct.schedule.256
  br label %direct.schedule.257

direct.false852:                                  ; preds = %direct.schedule.256
  br label %direct.schedule.262

direct.true863:                                   ; preds = %direct.schedule.263
  br label %direct.schedule.264

direct.false864:                                  ; preds = %direct.schedule.263
  br label %direct.schedule.269

direct.true875:                                   ; preds = %direct.schedule.270
  br label %direct.schedule.271

direct.false876:                                  ; preds = %direct.schedule.270
  br label %direct.schedule.276

direct.true887:                                   ; preds = %direct.schedule.277
  br label %direct.schedule.278

direct.false888:                                  ; preds = %direct.schedule.277
  br label %direct.schedule.283

direct.true899:                                   ; preds = %direct.schedule.284
  br label %direct.schedule.285

direct.false900:                                  ; preds = %direct.schedule.284
  br label %direct.schedule.290

direct.true912:                                   ; preds = %direct.schedule.292
  br label %direct.schedule.293

direct.false913:                                  ; preds = %direct.schedule.292
  br label %direct.schedule.300

direct.true933:                                   ; preds = %direct.schedule.301
  br label %direct.schedule.302

direct.false934:                                  ; preds = %direct.schedule.301
  br label %direct.schedule.307
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i64.v8p0(<8 x i64>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, <8 x i1>, <8 x i64>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #3

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

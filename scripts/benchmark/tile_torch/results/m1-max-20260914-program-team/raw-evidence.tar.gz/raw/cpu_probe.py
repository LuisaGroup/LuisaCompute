"""Controlled same-binary local1/local8 capture and guarded native-entry replay.

Invoke through run.py test after the frozen full build. No source modifications,
rebuild, GPU dispatch, LLVM recompilation or environment search occur here.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import run as receipt

RAW = Path(__file__).resolve().parent
SOURCE = receipt.SELECTED
BUILD = receipt.BUILD
HELPER = SOURCE / 'scripts/benchmark/tile_torch/native_tile.py'
CASES = (
    ('rms65', 'rmsnorm', '129,65', '1', '1'),
    ('softmax65', 'masked_softmax', '129,65', '1', '1'),
    ('rms512', 'rmsnorm', '129,512', '1', '1'),
    ('softmax512', 'masked_softmax', '129,512', '1', '1'),
    ('attention33', 'attention', '1,2,1,3,35,7,3', '2', '33'),
    ('attention65', 'attention', '1,2,1,3,67,33,7', '2', '65'),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('capture', 'prepare', 'replay'))
    parser.add_argument('--case', choices=tuple(case[0] for case in CASES))
    args = parser.parse_args()
    cases = [case for case in CASES if args.case is None or case[0] == args.case]
    frozen = receipt.check_freeze()
    closure = [BUILD / 'bin' / name for name in
               ('benchmark_tile_xir', 'libluisa-backend-simd.so', 'libluisa-tile.dylib', 'libluisa-core.dylib')]
    closure = {str(path): receipt.digest(path) for path in closure}
    helpers = [HELPER, HELPER.with_name('native_tile_replay.cpp'),
               SOURCE / 'src/backends/simd/llvm/llvm_schedule_codegen.h', Path(__file__)]
    helpers = {str(path): receipt.digest(path) for path in helpers}
    label = f'cpu-{args.mode}-6' + ('-' + args.case if args.case else '')
    identity = dict(mode=args.mode, cases=cases, source_freeze=frozen['receipt_sha256'],
                    binary_sha256=closure, helper_sha256=helpers, started=time.time(),
                    capture_measurement='diagnostic only; single capture per variant, not ABBA Runtime evidence',
                    replay_measurement='single-thread native entry; common C++ timer; ABBA; includes entry/block traversal',
                    variants='local1 versus local8; same default compiler and fixed W8/block32/one worker',
                    no_torch_comparison=True)
    receipt.save(RAW / (label + '-manifest.json'), identity)
    for name, op, dims, bq, bk in cases:
        for local in ((1, 8) if args.mode != 'replay' else (None,)):
            tag = f'{name}-l{local}'
            prefix = RAW / ('cpu-capture-' + tag + '-6') / 'output.f32'
            prepared = RAW / ('cpu-prepared-' + tag + '-6')
            if args.mode == 'capture':
                # run() makes this folder before starting the process. The
                # native dump helper creates its own fresh object directory.
                env = {
                    'LUISA_SIMD_WARP_WIDTH': '8', 'LUISA_SIMD_WORKER_COUNT': '1',
                    'LUISA_TILE_BENCH_XIR_BACKEND': 'simd',
                    'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(local),
                    'LUISA_TILE_BENCH_XIR_BLOCK_SIZE': '32',
                    'LUISA_TILE_BENCH_XIR_BLOCKS_PER_TASK': '1',
                    'LUISA_TILE_BENCH_DUMP_SOURCE': str(prefix) + '.source.txt',
                    'LUISA_SIMD_DUMP_ASSEMBLY_DIR': str(prefix.parent / 'objects'),
                }
                command = ['/usr/bin/env', *(f'{key}={value}' for key, value in env.items()),
                           str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, dims,
                           bq, bk, '3', '10', '20', str(prefix)]
                receipt.run('cpu-capture-' + tag + '-6', command, 180, native=True)
            elif args.mode == 'prepare':
                receipt.run('cpu-prepare-' + tag + '-6', [sys.executable, str(HELPER), 'prepare',
                    '--capture-kind', 'llm', '--name', f'local{local}',
                    '--prefix', str(prefix), '--log', str(prefix.parent / 'stdout.txt'),
                    '--objects', str(prefix.parent / 'objects'), '--llvm', '/opt/homebrew/opt/llvm@22/bin',
                    '--output', str(prepared)], 180)
            else:
                receipt.run('cpu-replay-' + name + '-6', [sys.executable, str(HELPER), 'replay',
                    '--prepared', str(RAW / f'cpu-prepared-{name}-l1-6/prepared.json'),
                    '--prepared', str(RAW / f'cpu-prepared-{name}-l8-6/prepared.json'),
                    '--cycles', '3', '--samples', '5', '--warmup-ms', '40', '--target-ms', '20',
                    '--output', str(RAW / f'cpu-replayed-{name}-6')], 180, native=True)
    if receipt.check_freeze()['receipt_sha256'] != frozen['receipt_sha256']:
        raise ValueError('source changed during probe')
    if any(receipt.digest(path) != digest for path, digest in (closure | helpers).items()):
        raise ValueError('binary/helper changed during probe')
    identity.update(status='passed', finished=time.time(), closure_unchanged=True)
    receipt.save(RAW / (label + '-result.json'), identity)


if __name__ == '__main__':
    main()

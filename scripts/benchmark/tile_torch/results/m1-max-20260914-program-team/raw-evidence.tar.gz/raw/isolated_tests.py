"""Prepared, opt-in isolation of 20 host and 10 Metal4 XIR test registrations.

No native work happens on import. Root must first review this script and pass
an immutable successful full-build receipt for the current source freeze.
Known host budget aborts remain Error rows, never successes. Any other failure,
including a Metal diagnostic with exit zero, stops all remaining visits.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import signal
import sys
import time

RAW = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('program_team_receipt_runner', RAW / 'run.py')
RUNNER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUNNER)
# Keep RUNNER.OUT at the original raw root: check_freeze/owned/toolchain resolve
# there. A child output folder is passed to run() as a relative name instead.
assert RUNNER.OUT == RAW
HELPERS = RUNNER.ROOT / 'scripts/benchmark/tile_torch'
sys.path.insert(0, str(HELPERS))
from compare_llm import gpu_failure_diagnostics

HOST_NAMES = [
    'tile_xir_root_traversal_is_bijective_and_identity_is_exact',
    'tile_xir_root_traversal_rejects_invalid_constraints',
    'tile_xir_root_traversal_cost_uses_physical_fast_digit',
    'tile_xir_deferred_map_depth_budget',
    'tile_xir_pure_map_fusion_admission_and_cost',
    'tile_xir_expression_reduction_fusion_contract_and_cost',
    'tile_xir_pointwise_effect_intervals_and_partitioned_outputs',
    'tile_xir_pointwise_does_not_cross_stages_or_reduction_state',
    'tile_xir_task_distribution_matches_static_home_chunks',
    'tile_xir_task_search_and_policy_are_independent_of_legality',
    'tile_xir_load_reduction_fusion_contract_and_cost',
    'tile_xir_packet_local_admission_and_abi',
    'tile_xir_packet_local_rejects_unrealized_redistribution_and_folds',
    'tile_xir_dynamic_extract_has_linear_snapshot_storage',
    'tile_xir_large_tiles_have_bounded_code_and_eager_load_snapshots',
    'tile_xir_expanded_map_extracts_need_no_snapshot',
    'tile_xir_verified_ssa_and_abi',
    'tile_xir_expansion_budget_is_fail_closed',
    'tile_xir_rejects_unrealized_execution_binding',
    'tile_xir_planner_searches_execution_order_not_memory_layout',
]
METAL_NAMES = [
    'tile_xir_metal4_llm_ragged_rows_and_packet_mapping',
    'tile_xir_metal4_short_packet_reductions_seeds_and_snapshots',
    'tile_xir_metal4_packet_fill_is_a_valid_contribution',
    'tile_xir_metal4_program_team_projection_reads',
    'tile_xir_metal4_program_team_attention_key33_value3',
    'tile_xir_metal4_program_team_attention_key65_value7',
    'tile_xir_metal4_program_team_attention_alias_snapshots_and_carries',
    'tile_xir_metal4_bounded_wide_reduction_tails',
    'tile_xir_metal4_rope_complete_program_mapping',
    'tile_xir_metal4_resource_budget_rejects_fixed_and_admits_auto',
]
KNOWN_ABORTS = {
    'tile_xir_large_tiles_have_bounded_code_and_eager_load_snapshots',
    'tile_xir_expansion_budget_is_fail_closed',
}
ABORT_DIAGNOSTIC = 'XIR realization exceeds its static SSA expansion budget; choose smaller Tiles'
INVENTORY_REGEX = r'^\s*"([^"]+)"_test ='
ANSI = re.compile(r'\x1b\[[0-9;]*m')
TIMEOUT = 600


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def check_log_hashes(folder, receipt):
    for channel in ('stdout', 'stderr'):
        require(RUNNER.digest(folder / f'{channel}.txt') == receipt.get(f'{channel}_sha256'),
                f'{folder.name}: {channel} hash mismatch')


def validate_summary(stdout, name, names):
    """Vendored Boost.UT includes filtered registrations in its test total."""
    text = ANSI.sub('', stdout)
    summaries = re.findall(r"Suite 'global': all tests passed \((\d+) asserts in (\d+) tests\)", text)
    require(len(summaries) == 1 and int(summaries[0][0]) > 0 and int(summaries[0][1]) == len(names),
            'missing unique positive assertion/registration summary')
    require(re.findall(r'^(\d+) tests skipped$', text, re.MULTILINE) == [str(len(names) - 1)],
            'filtered-test count does not match one exact registration')
    outcomes = re.findall(r'^Running(?: test)?\s+"([^"]+)"\.\.\.\s+(PASSED|SKIPPED)(?=\s|Suite \'global\':|$)',
                          text, re.MULTILINE)
    require(outcomes == [(item, 'PASSED' if item == name else 'SKIPPED') for item in names],
            'missing, duplicated, reordered or incorrectly filtered named test outcomes; --success required')
    require(not re.search(r'\bFAILED\b|Unexpected exception|early abort for test', text),
            'assertion or exception failure in positive test output')
    return dict(assertions=int(summaries[0][0]), registered_tests=len(names),
                filtered_out_tests=len(names) - 1, executed_tests=1, passed_tests=1)


def check_build(path, frozen):
    result = load(path)
    command = load(path.parent / 'command.json')
    tools = load(RAW / 'toolchain.json')
    expected = [tools['tools']['cmake']['command'][0], '--build', str(RUNNER.BUILD), '-j', '6']
    require(result.get('status') == 'passed' and result.get('exit_code') == 0
            and not result.get('timed_out') and result.get('native') is False,
            'full-build gate did not complete successfully')
    require(result.get('command') == command.get('command') == expected,
            'gate must be the complete selected-tree build, not a target-only build')
    require(result.get('cwd') == command.get('cwd') == str(RUNNER.SELECTED), 'full-build cwd mismatch')
    for key, expected_value in (
            ('source_sha256', frozen['source_sha256']),
            ('source_freeze_sha256', frozen['receipt_sha256']),
            ('owned_sha256', RUNNER.digest(RAW / 'owned.json')),
            ('harness_sha256', RUNNER.digest(RAW / 'run.py')),
            ('toolchain_sha256', RUNNER.digest(RAW / 'toolchain.json'))):
        require(result.get(key) == command.get(key) == expected_value, f'full-build {key} mismatch')
    require(frozen['finished'] <= result['started'] <= result['finished'] <= time.time(),
            'full-build chronology does not follow the current immutable freeze')
    check_log_hashes(path.parent, result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-receipt', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, default=RAW / 'isolated-tests-final')
    parser.add_argument('--suite', choices=('all', 'host', 'metal'), default='all')
    args = parser.parse_args()
    output = args.output_dir.resolve()
    require(output != RAW and output.is_relative_to(RAW) and output.parent == RAW,
            'output must be a fresh immediate child of this raw root')
    require(not output.exists(), 'output directory already exists; no retry or overwrite')
    build_path = args.build_receipt.resolve()
    require(build_path.is_relative_to(RAW) and build_path.name == 'result.json',
            'full-build receipt must be retained below the original raw root')
    frozen = RUNNER.check_freeze()
    build = check_build(build_path, frozen)
    cache = RUNNER.BUILD / 'CMakeCache.txt'
    require(re.findall(r'^LUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON:BOOL=(.*)$', cache.read_text(), re.MULTILINE)
            == ['OFF'], 'selected host configuration must isolate TIRx comparison dependencies')
    sources = {'host': RUNNER.SELECTED / 'src/tests/unit/tile/bridge/test_xir.cpp',
               'metal': RUNNER.SELECTED / 'src/tests/unit/tile/bridge/test_xir_metal.cpp'}
    inventories = {'host': HOST_NAMES, 'metal': METAL_NAMES}
    binaries = {'host': RUNNER.BUILD / 'bin/test_tile_xir', 'metal': RUNNER.BUILD / 'bin/test_tile_xir_metal'}
    for suite, names in inventories.items():
        require(re.findall(INVENTORY_REGEX, sources[suite].read_text(), re.MULTILINE) == names
                and len(set(names)) == len(names), f'{suite}: exact selected-source inventory changed')
    source_hashes = {str(path): RUNNER.digest(path) for path in sources.values()}
    binary_hashes = {str(path): RUNNER.digest(path) for path in binaries.values()}
    identity = {**source_hashes, **binary_hashes,
                str(cache): RUNNER.digest(cache), str(Path(__file__).resolve()): RUNNER.digest(__file__),
                str(RAW / 'run.py'): RUNNER.digest(RAW / 'run.py'),
                str(HELPERS / 'compare_llm.py'): RUNNER.digest(HELPERS / 'compare_llm.py')}
    suites = ['host', 'metal'] if args.suite == 'all' else [args.suite]
    visits = [dict(suite=suite, name=name,
                   command=[str(binaries[suite]), *(['metal4'] if suite == 'metal' else []), name, '--success'],
                   folder=f'{output.name}/{suite}-{index:02d}',
                   expected='historical_abort' if name in KNOWN_ABORTS else 'passed')
              for suite in suites for index, name in enumerate(inventories[suite])]
    output.mkdir()
    started = time.time()
    plan = dict(started=started, suite=args.suite, visits=visits, timeout_seconds=TIMEOUT,
                serial=True, retries=0, expected_host_passes=18 if 'host' in suites else 0,
                expected_historical_errors=2 if 'host' in suites else 0,
                expected_metal_passes=len(METAL_NAMES) if 'metal' in suites else 0,
                source_freeze=frozen, full_build_receipt=str(build_path),
                full_build_sha256=RUNNER.digest(build_path), full_build_finished=build['finished'],
                identity_sha256=identity, selected_source_inventory_sha256=source_hashes,
                known_abort_names=sorted(KNOWN_ABORTS), known_abort_diagnostic=ABORT_DIAGNOSTIC,
                historical_evidence=str(RUNNER.PREVIOUS_RAW / 'isolated-host-results.json'),
                limitation='Known host aborts are retained failures of the recoverable budget contract, '
                           'not positive tests and not fresh baseline executions. No CTest-all pass claim.',
                safety='Any unexpected host failure or any Metal failure/diagnostic stops subsequent visits. '
                       'Process termination does not restore GPU health.')
    RUNNER.save(output / 'manifest.json', plan)
    rows = []
    failure = None
    try:
        for visit in visits:
            require(RUNNER.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'], 'source freeze changed')
            require(all(RUNNER.digest(path) == sha for path, sha in identity.items()), 'frozen input or artifact changed')
            folder = RAW / visit['folder']
            row = dict(suite=visit['suite'], name=visit['name'], expected=visit['expected'],
                       result=str(folder / 'result.json'), status='Error', known_preexisting_abort=False)
            rows.append(row)
            try:
                RUNNER.run(visit['folder'], visit['command'], TIMEOUT, native=visit['suite'] == 'metal')
            except SystemExit as error:
                row['runner_exit'] = error.code
            require((folder / 'result.json').is_file(), 'test has no terminal receipt')
            result = load(folder / 'result.json')
            stdout = (folder / 'stdout.txt').read_bytes()
            stderr = (folder / 'stderr.txt').read_bytes()
            check_log_hashes(folder, result)
            text = ANSI.sub('', (stdout + b'\n' + stderr).decode(errors='replace'))
            row.update(exit_code=result.get('exit_code'), timed_out=result.get('timed_out', False),
                       result_sha256=RUNNER.digest(folder / 'result.json'))
            require(result.get('command') == visit['command'] and result.get('cwd') == str(RUNNER.SELECTED)
                    and result.get('timeout_seconds') == TIMEOUT
                    and result.get('native') == (visit['suite'] == 'metal'), 'test command receipt drift')
            require(result.get('source_sha256') == frozen['source_sha256']
                    and result.get('source_freeze_sha256') == frozen['receipt_sha256']
                    and build['finished'] <= result['started'] <= result['finished'], 'source/build chronology drift')
            require(RUNNER.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'], 'source changed during test')
            require(not row['timed_out'], 'test timed out; stop all subsequent visits')
            if visit['expected'] == 'historical_abort':
                require(result.get('status') == 'failed' and row['exit_code'] == -signal.SIGABRT
                        and text.count(ABORT_DIAGNOSTIC) == 1
                        and 'Lowerer::_fail' in text
                        and not re.search(r'\bFAILED\b|Unexpected exception|all tests passed', text),
                        'host failure does not match the exact retained historical SIGABRT boundary')
                row.update(known_preexisting_abort=True, matched_diagnostic=ABORT_DIAGNOSTIC,
                           scope_decision='Continue only under the two-name historical host waiver; still an Error.')
            else:
                row['gpu_failure_diagnostics'] = gpu_failure_diagnostics(stdout, stderr) if visit['suite'] == 'metal' else []
                require(result.get('status') == 'passed' and row['exit_code'] == 0 and 'runner_exit' not in row,
                        'positive test did not exit successfully')
                require(not row['gpu_failure_diagnostics'], 'GPU failure diagnostic despite possible zero exit status')
                row['summary'] = validate_summary(stdout.decode(errors='replace'), visit['name'], inventories[visit['suite']])
                row['status'] = 'passed'
            RUNNER.save(folder / 'validation.json', row)
        require(all(RUNNER.digest(path) == sha for path, sha in identity.items()), 'final artifact identity drift')
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        if rows and rows[-1]['status'] != 'passed':
            rows[-1]['validation_error'] = failure
            if rows[-1]['suite'] == 'metal':
                rows[-1]['queue_health'] = 'Unestablished; root inspection required before any further GPU work.'
            validation = Path(rows[-1]['result']).parent / 'validation.json'
            if validation.parent.exists() and not validation.exists():
                RUNNER.save(validation, rows[-1])
    finally:
        RUNNER.save(output / 'summary.json', dict(
            started=started, finished=time.time(), manifest_sha256=RUNNER.digest(output / 'manifest.json'),
            cases=rows, passed=sum(row['status'] == 'passed' for row in rows),
            failed=sum(row['status'] == 'Error' for row in rows),
            errors=sum(row['status'] == 'Error' for row in rows),
            historical_errors=sum(row['known_preexisting_abort'] for row in rows),
            positive_assertions=sum(row.get('summary', {}).get('assertions', 0) for row in rows),
            positive_executed_tests=sum(row.get('summary', {}).get('executed_tests', 0) for row in rows),
            not_run=visits[len(rows):], error=failure,
            complete=failure is None and len(rows) == len(visits),
            all_tests_passed=failure is None and len(rows) == len(visits) and all(row['status'] == 'passed' for row in rows)))
    if failure is not None:
        raise SystemExit(failure)


if __name__ == '__main__':
    main()

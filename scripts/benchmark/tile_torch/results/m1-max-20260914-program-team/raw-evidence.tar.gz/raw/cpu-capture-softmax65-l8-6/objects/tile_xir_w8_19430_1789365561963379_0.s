	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_11:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI0_12:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI0_13:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI0_14:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI0_15:
	.quad	54                              ; 0x36
	.quad	63                              ; 0x3f
lCPI0_16:
	.quad	18                              ; 0x12
	.quad	27                              ; 0x1b
lCPI0_17:
	.quad	36                              ; 0x24
	.quad	45                              ; 0x2d
lCPI0_18:
	.quad	0                               ; 0x0
	.quad	9                               ; 0x9
lCPI0_20:
	.long	5                               ; 0x5
	.long	4                               ; 0x4
	.long	7                               ; 0x7
	.long	6                               ; 0x6
lCPI0_21:
	.long	1                               ; 0x1
	.long	0                               ; 0x0
	.long	3                               ; 0x3
	.long	2                               ; 0x2
lCPI0_22:
	.long	6                               ; 0x6
	.long	7                               ; 0x7
	.long	4                               ; 0x4
	.long	5                               ; 0x5
lCPI0_23:
	.long	2                               ; 0x2
	.long	3                               ; 0x3
	.long	0                               ; 0x0
	.long	1                               ; 0x1
lCPI0_24:
	.long	4                               ; 0x4
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.long	0                               ; 0x0
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_19:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #128
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v15, v0, v2
	cmhi.4s	v20, v0, v1
	uzp1.8h	v3, v20, v15
	umaxv.8h	h0, v3
	fmov	w8, s0
	tbz	w8, #0, LBB0_405
; %bb.1:                                ; %direct.activate
	mov	x9, #0                          ; =0x0
	add	x11, sp, #2712
	add	x8, sp, #3360
	dup.2d	v2, x8
	add	x8, sp, #3288
	dup.2d	v6, x8
	add	x8, sp, #3000
	dup.2d	v0, x8
	str	q0, [sp, #944]                  ; 16-byte Spill
	dup.2d	v0, x11
	str	q0, [sp, #640]                  ; 16-byte Spill
	ldr	x8, [x0]
	ldr	x10, [x0, #48]
	str	x10, [sp, #296]                 ; 8-byte Spill
Lloh4:
	adrp	x10, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x10, lCPI0_0@PAGEOFF]
	and.16b	v0, v3, v0
	addv.8h	h0, v0
	fmov	w10, s0
	ldr	w12, [x1]
	ldr	w13, [x1, #36]
	add	w12, w13, w12, lsl #5
	lsr	w12, w12, #3
	dup.4s	v1, w12
	and	w12, w10, #0xff
	and.16b	v28, v20, v1
	and.16b	v1, v15, v1
	ushll2.2d	v7, v1, #0
	ushll2.2d	v16, v28, #0
	ushll.2d	v17, v1, #0
	ushll.2d	v5, v28, #0
	fmov	x10, d5
	mov	w13, #260                       ; =0x104
	umaddl	x10, w10, w13, x8
	fmov	w13, s0
	add	x14, sp, #3936
	b	LBB0_3
LBB0_2:                                 ; %else48
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x14, x9
	stp	q18, q19, [x15]
	add	x9, x9, #32
	cmp	x9, #256
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x15, x10, x9
	add	x17, x14, x9
	ldr	q18, [x17]
	tbnz	w13, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w16, w13, #0xff
	tbnz	w16, #1, LBB0_12
LBB0_5:                                 ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #2, LBB0_13
LBB0_6:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #3, LBB0_14
LBB0_7:                                 ; %else36
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q19, [x17, #16]
	tbnz	w16, #4, LBB0_15
LBB0_8:                                 ; %else39
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #5, LBB0_16
LBB0_9:                                 ; %else42
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w16, #6, LBB0_17
LBB0_10:                                ; %else45
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w16, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v18 }[0], [x15]
	and	w16, w13, #0xff
	tbz	w16, #1, LBB0_5
LBB0_12:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x15, #4
	ld1.s	{ v18 }[1], [x0]
	tbz	w16, #2, LBB0_6
LBB0_13:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x15, #8
	ld1.s	{ v18 }[2], [x0]
	tbz	w16, #3, LBB0_7
LBB0_14:                                ; %cond.load35
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x15, #12
	ld1.s	{ v18 }[3], [x0]
	ldr	q19, [x17, #16]
	tbz	w16, #4, LBB0_8
LBB0_15:                                ; %cond.load38
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #16
	ld1.s	{ v19 }[0], [x17]
	tbz	w16, #5, LBB0_9
LBB0_16:                                ; %cond.load41
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #20
	ld1.s	{ v19 }[1], [x17]
	tbz	w16, #6, LBB0_10
LBB0_17:                                ; %cond.load44
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x17, x15, #24
	ld1.s	{ v19 }[2], [x17]
	tbz	w16, #7, LBB0_2
LBB0_18:                                ; %cond.load47
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x15, x15, #28
	ld1.s	{ v19 }[3], [x15]
	b	LBB0_2
LBB0_19:                                ; %direct.false
	xtn.8b	v4, v3
	sshll.2d	v3, v20, #0
	sshll.2d	v18, v15, #0
	str	q20, [sp, #880]                 ; 16-byte Spill
	sshll2.2d	v21, v20, #0
	sshll2.2d	v22, v15, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q19, [x9, lCPI0_6@PAGEOFF]
	and.16b	v8, v3, v19
	movi.2d	v19, #0000000000000000
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q20, [x9, lCPI0_7@PAGEOFF]
	and.16b	v23, v3, v20
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q3, [x9, lCPI0_8@PAGEOFF]
	and.16b	v25, v18, v3
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q3, [x9, lCPI0_9@PAGEOFF]
	str	q21, [sp, #720]                 ; 16-byte Spill
	and.16b	v26, v21, v3
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q3, [x9, lCPI0_10@PAGEOFF]
	str	q22, [sp, #704]                 ; 16-byte Spill
	and.16b	v27, v22, v3
	movi.8b	v3, #1
	and.8b	v3, v4, v3
	umov.b	w13, v3[0]
	movi.2d	v22, #0000000000000000
	movi.2d	v3, #0000000000000000
	mov.b	v3[0], v4[0]
	stp	q4, q3, [sp, #336]              ; 32-byte Folded Spill
	umaxv.8b	b3, v3
	fmov	w14, s3
	rbit	w9, w13
	clz	w9, w9
	tst	w14, #0x1
	mov	w10, #64                        ; =0x40
	dup.2d	v24, x10
	csel	w4, w9, wzr, ne
	orr.16b	v3, v8, v24
	xtn.2s	v21, v5
	movi.2s	v20, #65
	mov.16b	v29, v3
	umlal.2d	v29, v21, v20
	mov.b	v22[0], v4[0]
	ushll.2d	v5, v22, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	str	q29, [sp, #272]                 ; 16-byte Spill
	and.16b	v5, v5, v29
	str	q19, [sp, #2624]
	str	q19, [sp, #2608]
	str	q19, [sp, #2592]
	str	q5, [sp, #2576]
	ubfiz	x9, x4, #3, #3
	add	x10, sp, #2576
	ldr	x10, [x10, x9]
	sub	x10, x10, x4
	add	x8, x8, x10, lsl #2
	stp	q27, q26, [sp, #896]            ; 32-byte Folded Spill
	str	q27, [sp, #2688]
	str	q25, [sp, #928]                 ; 16-byte Spill
	str	q25, [sp, #2672]
	str	q26, [sp, #2656]
	str	q23, [sp, #2640]
	add	x10, sp, #2640
	ldr	x9, [x10, x9]
	orr	x9, x9, #0x100
	sub	x9, x9, w4, uxtw #2
	tst	w13, #0x1
	csel	x10, xzr, x9, eq
	add	x9, sp, #3936
	add	x9, x9, x10
	ldr	q25, [x9]
	tbnz	w14, #0, LBB0_143
; %bb.20:                               ; %else52
	tbnz	w13, #1, LBB0_144
LBB0_21:                                ; %else55
	tbnz	w13, #2, LBB0_145
LBB0_22:                                ; %else58
	tbnz	w13, #3, LBB0_146
LBB0_23:                                ; %else61
	adrp	x14, lCPI0_3@PAGE
	adrp	x15, lCPI0_4@PAGE
	adrp	x16, lCPI0_5@PAGE
	ldr	q26, [x9, #16]
	tbnz	w13, #4, LBB0_147
LBB0_24:                                ; %else64
	ldr	q5, [x14, lCPI0_3@PAGEOFF]
	ldr	q19, [x15, lCPI0_4@PAGEOFF]
	ldr	q22, [x16, lCPI0_5@PAGEOFF]
	tbz	w13, #5, LBB0_26
LBB0_25:                                ; %cond.load66
	add	x9, x8, #20
	ld1.s	{ v26 }[1], [x9]
LBB0_26:                                ; %else67
	ldr	q4, [sp, #704]                  ; 16-byte Reload
	and.16b	v4, v4, v5
	str	q4, [sp, #656]                  ; 16-byte Spill
	ldr	q4, [sp, #720]                  ; 16-byte Reload
	and.16b	v5, v4, v19
	and.16b	v4, v18, v22
	stp	q4, q5, [sp, #672]              ; 32-byte Folded Spill
	tbz	w13, #6, LBB0_28
; %bb.27:                               ; %cond.load69
	add	x9, x8, #24
	ld1.s	{ v26 }[2], [x9]
LBB0_28:                                ; %else70
	ldr	q4, [sp, #672]                  ; 16-byte Reload
	orr.16b	v5, v4, v24
	ldr	q4, [sp, #688]                  ; 16-byte Reload
	orr.16b	v19, v4, v24
	ldr	q4, [sp, #656]                  ; 16-byte Reload
	orr.16b	v18, v4, v24
	xtn.2s	v22, v16
	xtn.2s	v16, v17
	xtn.2s	v7, v7
	tbz	w13, #7, LBB0_30
; %bb.29:                               ; %cond.load72
	add	x8, x8, #28
	ld1.s	{ v26 }[3], [x8]
LBB0_30:                                ; %else73
	umull.2d	v4, v21, v20
	mov.16b	v17, v18
	umlal.2d	v17, v7, v20
	mov.16b	v7, v19
	umlal.2d	v7, v22, v20
	stp	q7, q17, [sp, #240]             ; 32-byte Folded Spill
	mov.16b	v7, v5
	umlal.2d	v7, v16, v20
	stp	q4, q7, [sp, #208]              ; 32-byte Folded Spill
	add	x8, sp, #3936
	add	x8, x8, x10
	stp	q25, q26, [x8]
	ldp	q25, q22, [sp, #704]            ; 32-byte Folded Reload
	and.16b	v7, v25, v2
	and.16b	v16, v22, v2
	sshll.2d	v20, v15, #0
	and.16b	v17, v20, v2
	ldr	q4, [sp, #880]                  ; 16-byte Reload
	sshll.2d	v21, v4, #0
	and.16b	v24, v21, v2
Lloh16:
	adrp	x8, lCPI0_11@PAGE
Lloh17:
	ldr	q2, [x8, lCPI0_11@PAGEOFF]
	and.16b	v25, v25, v2
Lloh18:
	adrp	x8, lCPI0_12@PAGE
Lloh19:
	ldr	q2, [x8, lCPI0_12@PAGEOFF]
	and.16b	v26, v22, v2
Lloh20:
	adrp	x8, lCPI0_13@PAGE
Lloh21:
	ldr	q2, [x8, lCPI0_13@PAGEOFF]
	and.16b	v27, v20, v2
Lloh22:
	adrp	x8, lCPI0_14@PAGE
Lloh23:
	ldr	q2, [x8, lCPI0_14@PAGEOFF]
	and.16b	v2, v21, v2
	ushll2.2d	v20, v15, #0
	mov	w8, #1                          ; =0x1
	dup.2d	v21, x8
	and.16b	v11, v20, v21
	ushll2.2d	v20, v4, #0
	and.16b	v12, v20, v21
	ushll.2d	v20, v15, #0
	and.16b	v13, v20, v21
	ushll.2d	v20, v4, #0
	and.16b	v14, v20, v21
	movi.2d	v20, #0000000000000000
	fmov	w8, s0
	movi.2d	v21, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	ldr	q4, [sp, #656]                  ; 16-byte Reload
	b	LBB0_32
LBB0_31:                                ; %else90
                                        ;   in Loop: Header=BB0_32 Depth=1
	add.2d	v21, v21, v12
	add.2d	v29, v29, v13
	add.2d	v30, v30, v11
	add.2d	v20, v20, v14
	fmov	x9, d20
	cmp	x9, #8
	b.ge	LBB0_48
LBB0_32:                                ; %direct.true69
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v22, v20, #3
	orr.16b	v22, v22, v8
	shl.2d	v31, v20, #6
	orr.16b	v31, v31, v2
	add.2d	v31, v24, v31
	tbz	w8, #0, LBB0_34
; %bb.33:                               ; %cond.store
                                        ;   in Loop: Header=BB0_32 Depth=1
	fmov	x9, d31
	str	d22, [x9]
LBB0_34:                                ; %else76
                                        ;   in Loop: Header=BB0_32 Depth=1
	and	w9, w8, #0xff
	tbz	w9, #1, LBB0_36
; %bb.35:                               ; %cond.store77
                                        ;   in Loop: Header=BB0_32 Depth=1
	mov.d	x14, v31[1]
	st1.d	{ v22 }[1], [x14]
LBB0_36:                                ; %else78
                                        ;   in Loop: Header=BB0_32 Depth=1
	shl.2d	v22, v21, #3
	ldr	q31, [sp, #688]                 ; 16-byte Reload
	orr.16b	v22, v22, v31
	shl.2d	v31, v21, #6
	orr.16b	v31, v31, v26
	add.2d	v31, v16, v31
	tbz	w9, #2, LBB0_38
; %bb.37:                               ; %cond.store79
                                        ;   in Loop: Header=BB0_32 Depth=1
	fmov	x14, d31
	str	d22, [x14]
LBB0_38:                                ; %else80
                                        ;   in Loop: Header=BB0_32 Depth=1
	tbz	w9, #3, LBB0_40
; %bb.39:                               ; %cond.store81
                                        ;   in Loop: Header=BB0_32 Depth=1
	mov.d	x14, v31[1]
	st1.d	{ v22 }[1], [x14]
LBB0_40:                                ; %else82
                                        ;   in Loop: Header=BB0_32 Depth=1
	shl.2d	v22, v29, #3
	ldr	q31, [sp, #672]                 ; 16-byte Reload
	orr.16b	v22, v22, v31
	shl.2d	v31, v29, #6
	orr.16b	v31, v31, v27
	add.2d	v31, v17, v31
	tbnz	w9, #4, LBB0_44
; %bb.41:                               ; %else84
                                        ;   in Loop: Header=BB0_32 Depth=1
	tbnz	w9, #5, LBB0_45
LBB0_42:                                ; %else86
                                        ;   in Loop: Header=BB0_32 Depth=1
	shl.2d	v22, v30, #3
	orr.16b	v22, v22, v4
	shl.2d	v31, v30, #6
	orr.16b	v31, v31, v25
	add.2d	v31, v7, v31
	tbnz	w9, #6, LBB0_46
LBB0_43:                                ; %else88
                                        ;   in Loop: Header=BB0_32 Depth=1
	tbz	w9, #7, LBB0_31
	b	LBB0_47
LBB0_44:                                ; %cond.store83
                                        ;   in Loop: Header=BB0_32 Depth=1
	fmov	x14, d31
	str	d22, [x14]
	tbz	w9, #5, LBB0_42
LBB0_45:                                ; %cond.store85
                                        ;   in Loop: Header=BB0_32 Depth=1
	mov.d	x14, v31[1]
	st1.d	{ v22 }[1], [x14]
	shl.2d	v22, v30, #3
	orr.16b	v22, v22, v4
	shl.2d	v31, v30, #6
	orr.16b	v31, v31, v25
	add.2d	v31, v7, v31
	tbz	w9, #6, LBB0_43
LBB0_46:                                ; %cond.store87
                                        ;   in Loop: Header=BB0_32 Depth=1
	fmov	x14, d31
	str	d22, [x14]
	tbz	w9, #7, LBB0_31
LBB0_47:                                ; %cond.store89
                                        ;   in Loop: Header=BB0_32 Depth=1
	mov.d	x9, v31[1]
	st1.d	{ v22 }[1], [x9]
	b	LBB0_31
LBB0_48:                                ; %direct.false70
	str	q8, [sp, #400]                  ; 16-byte Spill
	movi.4s	v20, #65
	ldr	q4, [sp, #880]                  ; 16-byte Reload
	and.16b	v21, v4, v20
	mvn.16b	v22, v4
	and.16b	v20, v15, v20
	mvn.16b	v29, v15
	sub.4s	v20, v20, v29
	mov.s	w8, v20[1]
	mov.s	w9, v20[2]
	mov.s	w14, v20[3]
	sub.4s	v21, v21, v22
	fmov	w15, s20
	fmov	w16, s1
	udiv	w17, w16, w15
	mov.s	w0, v1[1]
	msub	w15, w17, w15, w16
	udiv	w16, w0, w8
	msub	w8, w16, w8, w0
	mov.s	w16, v1[2]
	udiv	w17, w16, w9
	msub	w9, w17, w9, w16
	mov.s	w16, v1[3]
	udiv	w17, w16, w14
	mov.s	w0, v21[1]
	msub	w14, w17, w14, w16
	mov.s	w16, v21[2]
	mov.s	w17, v21[3]
	fmov	w1, s21
	fmov	w2, s28
	udiv	w3, w2, w1
	msub	w1, w3, w1, w2
	mov.s	w2, v28[1]
	str	q2, [sp, #2496]
	str	q26, [sp, #2512]
	udiv	w3, w2, w0
	msub	w0, w3, w0, w2
	mov.s	w2, v28[2]
	str	q27, [sp, #2528]
	str	q25, [sp, #2544]
	udiv	w3, w2, w16
	msub	w16, w3, w16, w2
	mov.s	w2, v28[3]
	udiv	w3, w2, w17
	msub	w17, w3, w17, w2
	and	x2, x4, #0x7
	add	x3, sp, #2496
	ldr	x2, [x3, x2, lsl #3]
	fmov	s1, w15
	mov.s	v1[1], w8
	mov.s	v1[2], w9
	mov.s	v1[3], w14
	tst	w13, #0xff
	fmov	s21, w1
	sshll.2d	v20, v4, #0
	sshll.2d	v22, v15, #0
	orr	x8, x2, #0x200
	sub	x8, x8, x4, lsl #3
	csel	x8, xzr, x8, eq
	mov.s	v21[1], w0
	add	x9, sp, #3360
	add	x9, x9, x8
	ldp	q28, q29, [x9, #32]
	ldp	q30, q31, [x9]
	ldr	q10, [sp, #352]                 ; 16-byte Reload
	mov	b8, v10[2]
	mov.b	v8[4], v10[3]
	ushll.2d	v8, v8, #0
	shl.2d	v8, v8, #63
	cmlt.2d	v8, v8, #0
	mov	b9, v10[0]
	mov.b	v9[4], v10[1]
	bif.16b	v19, v31, v8
	ushll.2d	v31, v9, #0
	shl.2d	v31, v31, #63
	cmlt.2d	v31, v31, #0
	bif.16b	v3, v30, v31
	mov	b30, v10[6]
	mov.b	v30[4], v10[7]
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
	bif.16b	v18, v29, v30
	mov	b29, v10[4]
	mov.b	v29[4], v10[5]
	ushll.2d	v29, v29, #0
	shl.2d	v29, v29, #63
	cmlt.2d	v29, v29, #0
	bif.16b	v5, v28, v29
	mov.s	v21[2], w16
	mov.s	v21[3], w17
	and.16b	v21, v4, v21
	stp	q5, q18, [x9, #32]
	stp	q3, q19, [x9]
	and.16b	v3, v15, v1
	ushll2.2d	v1, v3, #0
	ushll2.2d	v5, v21, #0
	ushll.2d	v3, v3, #0
	ushll.2d	v18, v21, #0
	ldr	q19, [sp, #704]                 ; 16-byte Reload
	and.16b	v4, v19, v6
	str	q4, [sp, #848]                  ; 16-byte Spill
	ldr	q4, [sp, #720]                  ; 16-byte Reload
	and.16b	v28, v4, v6
	and.16b	v21, v22, v6
	stp	q21, q28, [sp, #816]            ; 32-byte Folded Spill
	and.16b	v6, v20, v6
	str	q6, [sp, #800]                  ; 16-byte Spill
Lloh24:
	adrp	x9, lCPI0_15@PAGE
Lloh25:
	ldr	q6, [x9, lCPI0_15@PAGEOFF]
	and.16b	v6, v19, v6
	str	q6, [sp, #784]                  ; 16-byte Spill
Lloh26:
	adrp	x9, lCPI0_16@PAGE
Lloh27:
	ldr	q6, [x9, lCPI0_16@PAGEOFF]
	and.16b	v4, v4, v6
	str	q4, [sp, #768]                  ; 16-byte Spill
Lloh28:
	adrp	x9, lCPI0_17@PAGE
Lloh29:
	ldr	q6, [x9, lCPI0_17@PAGEOFF]
	and.16b	v4, v22, v6
	str	q4, [sp, #752]                  ; 16-byte Spill
Lloh30:
	adrp	x9, lCPI0_18@PAGE
Lloh31:
	ldr	q6, [x9, lCPI0_18@PAGEOFF]
	and.16b	v4, v20, v6
	str	q4, [sp, #736]                  ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	movi.8b	v19, #1
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v28, #0000000000000000
	b	LBB0_50
LBB0_49:                                ; %else156
                                        ;   in Loop: Header=BB0_50 Depth=1
	add.2d	v20, v20, v12
	add.2d	v21, v21, v13
	add.2d	v28, v28, v11
	add.2d	v6, v6, v14
	fmov	x9, d6
	cmp	x9, #8
	b.ge	LBB0_82
LBB0_50:                                ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w9, s0
	shl.2d	v22, v6, #6
	orr.16b	v22, v22, v2
	add.2d	v9, v24, v22
	tbz	w9, #0, LBB0_68
; %bb.51:                               ; %cond.load92
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	x13, d9
	ldr	d29, [x13]
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_53
LBB0_52:                                ; %cond.load96
                                        ;   in Loop: Header=BB0_50 Depth=1
	mov.d	x13, v9[1]
	ld1.d	{ v29 }[1], [x13]
LBB0_53:                                ; %else98
                                        ;   in Loop: Header=BB0_50 Depth=1
	shl.2d	v22, v20, #6
	orr.16b	v22, v22, v26
	add.2d	v22, v16, v22
	tbnz	w9, #2, LBB0_69
; %bb.54:                               ; %else102
                                        ;   in Loop: Header=BB0_50 Depth=1
	tbnz	w9, #3, LBB0_70
LBB0_55:                                ; %else106
                                        ;   in Loop: Header=BB0_50 Depth=1
	shl.2d	v22, v21, #6
	orr.16b	v22, v22, v27
	add.2d	v22, v17, v22
	tbnz	w9, #4, LBB0_71
LBB0_56:                                ; %else110
                                        ;   in Loop: Header=BB0_50 Depth=1
	tbnz	w9, #5, LBB0_72
LBB0_57:                                ; %else114
                                        ;   in Loop: Header=BB0_50 Depth=1
	shl.2d	v22, v28, #6
	orr.16b	v22, v22, v25
	add.2d	v22, v7, v22
	tbnz	w9, #6, LBB0_73
LBB0_58:                                ; %else118
                                        ;   in Loop: Header=BB0_50 Depth=1
	tbz	w9, #7, LBB0_60
LBB0_59:                                ; %cond.load120
                                        ;   in Loop: Header=BB0_50 Depth=1
	mov.d	x9, v22[1]
	ld1.d	{ v8 }[1], [x9]
LBB0_60:                                ; %else122
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	w9, s0
	ldr	q4, [sp, #736]                  ; 16-byte Reload
	add.2d	v22, v6, v4
	ldr	q4, [sp, #800]                  ; 16-byte Reload
	add.2d	v22, v4, v22
	cmge.2d	v29, v18, v29
	cmge.2d	v30, v5, v30
	uzp1.4s	v29, v29, v30
	cmge.2d	v30, v3, v31
	cmge.2d	v31, v1, v8
	uzp1.4s	v30, v30, v31
	uzp1.8h	v29, v29, v30
	xtn.8b	v29, v29
	and.8b	v29, v29, v19
	tbnz	w9, #0, LBB0_74
; %bb.61:                               ; %else128
                                        ;   in Loop: Header=BB0_50 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_75
LBB0_62:                                ; %else132
                                        ;   in Loop: Header=BB0_50 Depth=1
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	add.2d	v22, v20, v4
	ldr	q4, [sp, #832]                  ; 16-byte Reload
	add.2d	v22, v4, v22
	tbnz	w9, #2, LBB0_76
LBB0_63:                                ; %else136
                                        ;   in Loop: Header=BB0_50 Depth=1
	tbnz	w9, #3, LBB0_77
LBB0_64:                                ; %else140
                                        ;   in Loop: Header=BB0_50 Depth=1
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	add.2d	v22, v21, v4
	ldr	q4, [sp, #816]                  ; 16-byte Reload
	add.2d	v22, v4, v22
	tbnz	w9, #4, LBB0_78
LBB0_65:                                ; %else144
                                        ;   in Loop: Header=BB0_50 Depth=1
	tbnz	w9, #5, LBB0_79
LBB0_66:                                ; %else148
                                        ;   in Loop: Header=BB0_50 Depth=1
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	add.2d	v22, v28, v4
	ldr	q4, [sp, #848]                  ; 16-byte Reload
	add.2d	v22, v4, v22
	tbnz	w9, #6, LBB0_80
LBB0_67:                                ; %else152
                                        ;   in Loop: Header=BB0_50 Depth=1
	tbz	w9, #7, LBB0_49
	b	LBB0_81
LBB0_68:                                ;   in Loop: Header=BB0_50 Depth=1
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_52
	b	LBB0_53
LBB0_69:                                ; %cond.load100
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	x13, d22
	ld1.d	{ v30 }[0], [x13]
	tbz	w9, #3, LBB0_55
LBB0_70:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_50 Depth=1
	mov.d	x13, v22[1]
	ld1.d	{ v30 }[1], [x13]
	shl.2d	v22, v21, #6
	orr.16b	v22, v22, v27
	add.2d	v22, v17, v22
	tbz	w9, #4, LBB0_56
LBB0_71:                                ; %cond.load108
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	x13, d22
	ld1.d	{ v31 }[0], [x13]
	tbz	w9, #5, LBB0_57
LBB0_72:                                ; %cond.load112
                                        ;   in Loop: Header=BB0_50 Depth=1
	mov.d	x13, v22[1]
	ld1.d	{ v31 }[1], [x13]
	shl.2d	v22, v28, #6
	orr.16b	v22, v22, v25
	add.2d	v22, v7, v22
	tbz	w9, #6, LBB0_58
LBB0_73:                                ; %cond.load116
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	x13, d22
	ld1.d	{ v8 }[0], [x13]
	tbnz	w9, #7, LBB0_59
	b	LBB0_60
LBB0_74:                                ; %cond.store125
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	x13, d22
	str	b29, [x13]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_62
LBB0_75:                                ; %cond.store129
                                        ;   in Loop: Header=BB0_50 Depth=1
	mov.d	x13, v22[1]
	st1.b	{ v29 }[1], [x13]
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	add.2d	v22, v20, v4
	ldr	q4, [sp, #832]                  ; 16-byte Reload
	add.2d	v22, v4, v22
	tbz	w9, #2, LBB0_63
LBB0_76:                                ; %cond.store133
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	x13, d22
	st1.b	{ v29 }[2], [x13]
	tbz	w9, #3, LBB0_64
LBB0_77:                                ; %cond.store137
                                        ;   in Loop: Header=BB0_50 Depth=1
	mov.d	x13, v22[1]
	st1.b	{ v29 }[3], [x13]
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	add.2d	v22, v21, v4
	ldr	q4, [sp, #816]                  ; 16-byte Reload
	add.2d	v22, v4, v22
	tbz	w9, #4, LBB0_65
LBB0_78:                                ; %cond.store141
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	x13, d22
	st1.b	{ v29 }[4], [x13]
	tbz	w9, #5, LBB0_66
LBB0_79:                                ; %cond.store145
                                        ;   in Loop: Header=BB0_50 Depth=1
	mov.d	x13, v22[1]
	st1.b	{ v29 }[5], [x13]
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	add.2d	v22, v28, v4
	ldr	q4, [sp, #848]                  ; 16-byte Reload
	add.2d	v22, v4, v22
	tbz	w9, #6, LBB0_67
LBB0_80:                                ; %cond.store149
                                        ;   in Loop: Header=BB0_50 Depth=1
	fmov	x13, d22
	st1.b	{ v29 }[6], [x13]
	tbz	w9, #7, LBB0_49
LBB0_81:                                ; %cond.store153
                                        ;   in Loop: Header=BB0_50 Depth=1
	mov.d	x9, v22[1]
	st1.b	{ v29 }[7], [x9]
	b	LBB0_49
LBB0_82:                                ; %direct.false84
	add	x9, sp, #3360
	add	x8, x9, x8
	ldp	q6, q2, [x8, #32]
	ldp	q7, q16, [x8]
	cmge.2d	v5, v5, v16
	cmge.2d	v7, v18, v7
	uzp1.4s	v5, v7, v5
	cmge.2d	v3, v3, v6
	cmge.2d	v1, v1, v2
	uzp1.4s	v1, v3, v1
	uzp1.8h	v1, v5, v1
	xtn.8b	v1, v1
Lloh32:
	adrp	x8, lCPI0_19@PAGE
Lloh33:
	ldr	d2, [x8, lCPI0_19@PAGEOFF]
	ldr	q5, [sp, #352]                  ; 16-byte Reload
	shl.8b	v3, v5, #7
	cmlt.8b	v3, v3, #0
	and.8b	v2, v3, v2
	addv.8b	b2, v2
	str	d2, [sp, #328]                  ; 8-byte Spill
	fmov	w8, s2
	orn.8b	v1, v1, v5
	ldr	q2, [sp, #800]                  ; 16-byte Reload
	ldr	q3, [sp, #736]                  ; 16-byte Reload
	add.2d	v3, v3, v2
	mov	w9, #8                          ; =0x8
	dup.2d	v2, x9
	add.2d	v31, v3, v2
	movi.8b	v3, #1
	and.8b	v1, v1, v3
	tbnz	w8, #0, LBB0_148
; %bb.83:                               ; %else161
	ldr	q3, [sp, #832]                  ; 16-byte Reload
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	add.2d	v3, v4, v3
	mov.d	x0, v31[1]
	ldr	q25, [sp, #880]                 ; 16-byte Reload
	tbnz	w8, #1, LBB0_149
LBB0_84:                                ; %else165
	add.2d	v30, v3, v2
	tbnz	w8, #2, LBB0_150
LBB0_85:                                ; %else169
	ldr	q3, [sp, #816]                  ; 16-byte Reload
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	add.2d	v3, v4, v3
	mov.d	x17, v30[1]
	tbnz	w8, #3, LBB0_151
LBB0_86:                                ; %else173
	add.2d	v29, v3, v2
	tbnz	w8, #4, LBB0_152
LBB0_87:                                ; %else177
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	add.2d	v3, v4, v3
	mov.d	x16, v29[1]
	tbnz	w8, #5, LBB0_153
LBB0_88:                                ; %else181
	add	x9, sp, #3936
	add.2d	v28, v3, v2
	tbnz	w8, #6, LBB0_154
LBB0_89:                                ; %else185
	sshll.2d	v5, v25, #0
	sshll.2d	v3, v15, #0
	dup.2d	v6, x9
	mov.d	x15, v28[1]
	tbz	w8, #7, LBB0_91
LBB0_90:                                ; %cond.store186
	st1.b	{ v1 }[7], [x15]
LBB0_91:                                ; %else189
	ldp	q16, q4, [sp, #704]             ; 32-byte Folded Reload
	and.16b	v1, v16, v6
	and.16b	v2, v4, v6
	and.16b	v3, v3, v6
	and.16b	v5, v5, v6
	sshll.2d	v6, v25, #0
	sshll.2d	v7, v15, #0
	ldr	q17, [sp, #944]                 ; 16-byte Reload
	and.16b	v16, v16, v17
	and.16b	v4, v4, v17
	stp	q4, q16, [sp, #976]             ; 32-byte Folded Spill
	and.16b	v4, v7, v17
	str	q4, [sp, #960]                  ; 16-byte Spill
	and.16b	v4, v6, v17
	str	q4, [sp, #944]                  ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	fmov	w8, s0
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	b	LBB0_93
LBB0_92:                                ; %else320
                                        ;   in Loop: Header=BB0_93 Depth=1
	add.2d	v7, v7, v12
	add.2d	v16, v16, v13
	add.2d	v17, v17, v11
	add.2d	v6, v6, v14
	fmov	x13, d6
	cmp	x13, #8
	b.ge	LBB0_141
LBB0_93:                                ; %direct.true97
                                        ; =>This Inner Loop Header: Depth=1
	ldr	q4, [sp, #736]                  ; 16-byte Reload
	add.2d	v4, v6, v4
	ldr	q18, [sp, #800]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #0, LBB0_120
; %bb.94:                               ; %cond.load191
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x13, d4
	ldr	b18, [x13]
	and	w13, w8, #0xff
	tbz	w13, #1, LBB0_96
LBB0_95:                                ; %cond.load197
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v4[1]
	ld1.b	{ v18 }[1], [x14]
LBB0_96:                                ; %else201
                                        ;   in Loop: Header=BB0_93 Depth=1
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	add.2d	v4, v7, v4
	ldr	q19, [sp, #832]                 ; 16-byte Reload
	add.2d	v4, v19, v4
	tbnz	w13, #2, LBB0_121
; %bb.97:                               ; %else207
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbnz	w13, #3, LBB0_122
LBB0_98:                                ; %else213
                                        ;   in Loop: Header=BB0_93 Depth=1
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	add.2d	v4, v16, v4
	ldr	q19, [sp, #816]                 ; 16-byte Reload
	add.2d	v4, v19, v4
	tbnz	w13, #4, LBB0_123
LBB0_99:                                ; %else219
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbnz	w13, #5, LBB0_124
LBB0_100:                               ; %else225
                                        ;   in Loop: Header=BB0_93 Depth=1
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	add.2d	v4, v17, v4
	ldr	q19, [sp, #848]                 ; 16-byte Reload
	add.2d	v4, v19, v4
	tbnz	w13, #6, LBB0_125
LBB0_101:                               ; %else231
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbz	w13, #7, LBB0_103
LBB0_102:                               ; %cond.load233
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x13, v4[1]
	ld1.b	{ v18 }[7], [x13]
LBB0_103:                               ; %else237
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	w13, s0
	shl.2d	v4, v6, #5
	orr.16b	v20, v4, v23
	add.2d	v4, v5, v20
	movi.2d	v21, #0000000000000000
	movi.2d	v19, #0000000000000000
	tbnz	w13, #0, LBB0_126
; %bb.104:                              ; %else244
                                        ;   in Loop: Header=BB0_93 Depth=1
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_127
LBB0_105:                               ; %else250
                                        ;   in Loop: Header=BB0_93 Depth=1
	shl.2d	v4, v7, #5
	ldr	q22, [sp, #912]                 ; 16-byte Reload
	orr.16b	v24, v4, v22
	add.2d	v4, v2, v24
	tbnz	w13, #2, LBB0_128
LBB0_106:                               ; %else256
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbnz	w13, #3, LBB0_129
LBB0_107:                               ; %else262
                                        ;   in Loop: Header=BB0_93 Depth=1
	shl.2d	v4, v16, #5
	ldr	q22, [sp, #928]                 ; 16-byte Reload
	orr.16b	v26, v4, v22
	add.2d	v4, v3, v26
	tbnz	w13, #4, LBB0_130
LBB0_108:                               ; %else268
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbnz	w13, #5, LBB0_131
LBB0_109:                               ; %else274
                                        ;   in Loop: Header=BB0_93 Depth=1
	shl.2d	v4, v17, #5
	ldr	q22, [sp, #896]                 ; 16-byte Reload
	orr.16b	v27, v4, v22
	add.2d	v4, v1, v27
	tbnz	w13, #6, LBB0_132
LBB0_110:                               ; %else280
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbz	w13, #7, LBB0_112
LBB0_111:                               ; %cond.load282
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x13, v4[1]
	ld1.s	{ v19 }[3], [x13]
LBB0_112:                               ; %else286
                                        ;   in Loop: Header=BB0_93 Depth=1
	cmeq.8b	v4, v18, #0
	sshll.8h	v4, v4, #0
	sshll.4s	v22, v4, #0
	fmov	w13, s0
	dup.4s	v18, w9
	bit.16b	v21, v18, v22
	ldr	q22, [sp, #944]                 ; 16-byte Reload
	add.2d	v20, v22, v20
	tbnz	w13, #0, LBB0_133
; %bb.113:                              ; %else292
                                        ;   in Loop: Header=BB0_93 Depth=1
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_134
LBB0_114:                               ; %else296
                                        ;   in Loop: Header=BB0_93 Depth=1
	ldr	q20, [sp, #976]                 ; 16-byte Reload
	add.2d	v20, v20, v24
	tbnz	w13, #2, LBB0_135
LBB0_115:                               ; %else300
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbnz	w13, #3, LBB0_136
LBB0_116:                               ; %else304
                                        ;   in Loop: Header=BB0_93 Depth=1
	sshll2.4s	v4, v4, #0
	bsl.16b	v4, v18, v19
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v18, v18, v26
	tbnz	w13, #4, LBB0_137
LBB0_117:                               ; %else308
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbnz	w13, #5, LBB0_138
LBB0_118:                               ; %else312
                                        ;   in Loop: Header=BB0_93 Depth=1
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v18, v18, v27
	tbnz	w13, #6, LBB0_139
LBB0_119:                               ; %else316
                                        ;   in Loop: Header=BB0_93 Depth=1
	tbz	w13, #7, LBB0_92
	b	LBB0_140
LBB0_120:                               ;   in Loop: Header=BB0_93 Depth=1
	movi.2d	v18, #0000000000000000
	and	w13, w8, #0xff
	tbnz	w13, #1, LBB0_95
	b	LBB0_96
LBB0_121:                               ; %cond.load203
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d4
	ld1.b	{ v18 }[2], [x14]
	tbz	w13, #3, LBB0_98
LBB0_122:                               ; %cond.load209
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v4[1]
	ld1.b	{ v18 }[3], [x14]
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	add.2d	v4, v16, v4
	ldr	q19, [sp, #816]                 ; 16-byte Reload
	add.2d	v4, v19, v4
	tbz	w13, #4, LBB0_99
LBB0_123:                               ; %cond.load215
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d4
	ld1.b	{ v18 }[4], [x14]
	tbz	w13, #5, LBB0_100
LBB0_124:                               ; %cond.load221
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v4[1]
	ld1.b	{ v18 }[5], [x14]
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	add.2d	v4, v17, v4
	ldr	q19, [sp, #848]                 ; 16-byte Reload
	add.2d	v4, v19, v4
	tbz	w13, #6, LBB0_101
LBB0_125:                               ; %cond.load227
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d4
	ld1.b	{ v18 }[6], [x14]
	tbnz	w13, #7, LBB0_102
	b	LBB0_103
LBB0_126:                               ; %cond.load240
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d4
	ldr	s21, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_105
LBB0_127:                               ; %cond.load246
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v4[1]
	ld1.s	{ v21 }[1], [x14]
	shl.2d	v4, v7, #5
	ldr	q22, [sp, #912]                 ; 16-byte Reload
	orr.16b	v24, v4, v22
	add.2d	v4, v2, v24
	tbz	w13, #2, LBB0_106
LBB0_128:                               ; %cond.load252
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d4
	ld1.s	{ v21 }[2], [x14]
	tbz	w13, #3, LBB0_107
LBB0_129:                               ; %cond.load258
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v4[1]
	ld1.s	{ v21 }[3], [x14]
	shl.2d	v4, v16, #5
	ldr	q22, [sp, #928]                 ; 16-byte Reload
	orr.16b	v26, v4, v22
	add.2d	v4, v3, v26
	tbz	w13, #4, LBB0_108
LBB0_130:                               ; %cond.load264
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d4
	ld1.s	{ v19 }[0], [x14]
	tbz	w13, #5, LBB0_109
LBB0_131:                               ; %cond.load270
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v4[1]
	ld1.s	{ v19 }[1], [x14]
	shl.2d	v4, v17, #5
	ldr	q22, [sp, #896]                 ; 16-byte Reload
	orr.16b	v27, v4, v22
	add.2d	v4, v1, v27
	tbz	w13, #6, LBB0_110
LBB0_132:                               ; %cond.load276
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d4
	ld1.s	{ v19 }[2], [x14]
	tbnz	w13, #7, LBB0_111
	b	LBB0_112
LBB0_133:                               ; %cond.store289
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d20
	str	s21, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_114
LBB0_134:                               ; %cond.store293
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v20[1]
	st1.s	{ v21 }[1], [x14]
	ldr	q20, [sp, #976]                 ; 16-byte Reload
	add.2d	v20, v20, v24
	tbz	w13, #2, LBB0_115
LBB0_135:                               ; %cond.store297
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d20
	st1.s	{ v21 }[2], [x14]
	tbz	w13, #3, LBB0_116
LBB0_136:                               ; %cond.store301
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v20[1]
	st1.s	{ v21 }[3], [x14]
	sshll2.4s	v4, v4, #0
	bsl.16b	v4, v18, v19
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v18, v18, v26
	tbz	w13, #4, LBB0_117
LBB0_137:                               ; %cond.store305
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d18
	str	s4, [x14]
	tbz	w13, #5, LBB0_118
LBB0_138:                               ; %cond.store309
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x14, v18[1]
	st1.s	{ v4 }[1], [x14]
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v18, v18, v27
	tbz	w13, #6, LBB0_119
LBB0_139:                               ; %cond.store313
                                        ;   in Loop: Header=BB0_93 Depth=1
	fmov	x14, d18
	st1.s	{ v4 }[2], [x14]
	tbz	w13, #7, LBB0_92
LBB0_140:                               ; %cond.store317
                                        ;   in Loop: Header=BB0_93 Depth=1
	mov.d	x13, v18[1]
	st1.s	{ v4 }[3], [x13]
	b	LBB0_92
LBB0_141:                               ; %direct.true127.preheader
	ldr	d1, [sp, #328]                  ; 8-byte Reload
	fmov	w8, s1
	tbz	w8, #0, LBB0_155
; %bb.142:                              ; %cond.load322
	fmov	x9, d31
	ldr	b1, [x9]
	tbnz	w8, #1, LBB0_156
	b	LBB0_157
LBB0_143:                               ; %cond.load51
	ld1.s	{ v25 }[0], [x8]
	tbz	w13, #1, LBB0_21
LBB0_144:                               ; %cond.load54
	add	x14, x8, #4
	ld1.s	{ v25 }[1], [x14]
	tbz	w13, #2, LBB0_22
LBB0_145:                               ; %cond.load57
	add	x14, x8, #8
	ld1.s	{ v25 }[2], [x14]
	tbz	w13, #3, LBB0_23
LBB0_146:                               ; %cond.load60
	add	x14, x8, #12
	ld1.s	{ v25 }[3], [x14]
	adrp	x14, lCPI0_3@PAGE
	adrp	x15, lCPI0_4@PAGE
	adrp	x16, lCPI0_5@PAGE
	ldr	q26, [x9, #16]
	tbz	w13, #4, LBB0_24
LBB0_147:                               ; %cond.load63
	add	x9, x8, #16
	ld1.s	{ v26 }[0], [x9]
	ldr	q5, [x14, lCPI0_3@PAGEOFF]
	ldr	q19, [x15, lCPI0_4@PAGEOFF]
	ldr	q22, [x16, lCPI0_5@PAGEOFF]
	tbnz	w13, #5, LBB0_25
	b	LBB0_26
LBB0_148:                               ; %cond.store158
	fmov	x9, d31
	str	b1, [x9]
	ldr	q3, [sp, #832]                  ; 16-byte Reload
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	add.2d	v3, v4, v3
	mov.d	x0, v31[1]
	ldr	q25, [sp, #880]                 ; 16-byte Reload
	tbz	w8, #1, LBB0_84
LBB0_149:                               ; %cond.store162
	st1.b	{ v1 }[1], [x0]
	add.2d	v30, v3, v2
	tbz	w8, #2, LBB0_85
LBB0_150:                               ; %cond.store166
	fmov	x9, d30
	st1.b	{ v1 }[2], [x9]
	ldr	q3, [sp, #816]                  ; 16-byte Reload
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	add.2d	v3, v4, v3
	mov.d	x17, v30[1]
	tbz	w8, #3, LBB0_86
LBB0_151:                               ; %cond.store170
	st1.b	{ v1 }[3], [x17]
	add.2d	v29, v3, v2
	tbz	w8, #4, LBB0_87
LBB0_152:                               ; %cond.store174
	fmov	x9, d29
	st1.b	{ v1 }[4], [x9]
	ldr	q3, [sp, #848]                  ; 16-byte Reload
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	add.2d	v3, v4, v3
	mov.d	x16, v29[1]
	tbz	w8, #5, LBB0_88
LBB0_153:                               ; %cond.store178
	st1.b	{ v1 }[5], [x16]
	add	x9, sp, #3936
	add.2d	v28, v3, v2
	tbz	w8, #6, LBB0_89
LBB0_154:                               ; %cond.store182
	fmov	x13, d28
	st1.b	{ v1 }[6], [x13]
	sshll.2d	v5, v25, #0
	sshll.2d	v3, v15, #0
	dup.2d	v6, x9
	mov.d	x15, v28[1]
	tbnz	w8, #7, LBB0_90
	b	LBB0_91
LBB0_155:
	movi.2d	v1, #0000000000000000
	tbz	w8, #1, LBB0_157
LBB0_156:                               ; %cond.load328
	ld1.b	{ v1 }[1], [x0]
LBB0_157:                               ; %else332
	tbnz	w8, #2, LBB0_283
; %bb.158:                              ; %else338
	tbnz	w8, #3, LBB0_284
LBB0_159:                               ; %else344
	tbnz	w8, #4, LBB0_285
LBB0_160:                               ; %else350
	tbnz	w8, #5, LBB0_286
LBB0_161:                               ; %else356
	tbz	w8, #6, LBB0_163
LBB0_162:                               ; %cond.load358
	fmov	x9, d28
	ld1.b	{ v1 }[6], [x9]
LBB0_163:                               ; %else362
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	mov.b	v2[0], wzr
	str	q2, [sp, #304]                  ; 16-byte Spill
	stp	q14, q13, [sp, #608]            ; 32-byte Folded Spill
	stp	q29, q28, [sp, #128]            ; 32-byte Folded Spill
	stp	x17, x16, [sp, #40]             ; 16-byte Folded Spill
	tbz	w8, #7, LBB0_165
; %bb.164:                              ; %cond.load364
	ld1.b	{ v1 }[7], [x15]
LBB0_165:                               ; %else368
	str	q31, [sp, #16]                  ; 16-byte Spill
	str	q30, [sp, #112]                 ; 16-byte Spill
	sshll.2d	v2, v25, #0
	sshll.2d	v3, v15, #0
	cmeq.8b	v1, v1, #0
	sshll.8h	v1, v1, #0
	sshll2.4s	v4, v1, #0
	sshll.4s	v1, v1, #0
	add	x8, sp, #3936
	add	x8, x8, x10
	ldp	q5, q6, [x8]
	ldr	q16, [sp, #352]                 ; 16-byte Reload
	zip2.8b	v7, v16, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	and.16b	v6, v7, v6
	zip1.8b	v16, v16, v0
	ushll.4s	v16, v16, #0
	shl.4s	v16, v16, #31
	cmlt.4s	v16, v16, #0
	and.16b	v5, v16, v5
	mov	w8, #62154                      ; =0xf2ca
	movk	w8, #61769, lsl #16
	dup.4s	v17, w8
	mov.16b	v18, v1
	bsl.16b	v18, v17, v5
	mov.16b	v5, v4
	bsl.16b	v5, v17, v6
	add	x8, sp, #3000
	add	x9, x8, x10
	ldp	q1, q4, [x9]
	stp	q18, q5, [sp, #64]              ; 32-byte Folded Spill
	bit.16b	v4, v5, v7
	bit.16b	v1, v18, v16
	stp	q1, q4, [x9]
	fmov	x13, d23
	mov	w17, #4                         ; =0x4
	dup.2d	v1, x17
	ldp	q5, q4, [sp, #704]              ; 32-byte Folded Reload
	and.16b	v18, v5, v1
	and.16b	v24, v4, v1
	and.16b	v7, v3, v1
	and.16b	v1, v2, v1
	mov	w9, #32                         ; =0x20
	dup.2d	v2, x9
	ldp	q4, q3, [sp, #912]              ; 32-byte Folded Reload
	orr.16b	v6, v3, v2
	orr.16b	v5, v4, v2
	stp	q5, q6, [sp, #576]              ; 32-byte Folded Spill
	orr.16b	v6, v23, v2
	ldr	q5, [sp, #896]                  ; 16-byte Reload
	orr.16b	v2, v5, v2
	stp	q2, q6, [sp, #544]              ; 32-byte Folded Spill
	mov	w9, #64                         ; =0x40
	dup.2d	v2, x9
	orr.16b	v6, v3, v2
	str	q6, [sp, #528]                  ; 16-byte Spill
	orr.16b	v6, v4, v2
	str	q6, [sp, #512]                  ; 16-byte Spill
	orr.16b	v6, v23, v2
	orr.16b	v2, v5, v2
	stp	q2, q6, [sp, #480]              ; 32-byte Folded Spill
	mov	w9, #96                         ; =0x60
	dup.2d	v2, x9
	orr.16b	v6, v3, v2
	orr.16b	v3, v4, v2
	stp	q3, q6, [sp, #448]              ; 32-byte Folded Spill
	orr.16b	v3, v23, v2
	orr.16b	v2, v5, v2
	stp	q2, q3, [sp, #416]              ; 32-byte Folded Spill
	ldp	q2, q3, [x11, #384]
	and.16b	v26, v15, v3
	and.16b	v27, v25, v2
	ldp	q2, q3, [x11, #352]
	and.16b	v17, v15, v3
	and.16b	v6, v25, v2
	ldp	q2, q3, [x11, #320]
	and.16b	v28, v15, v3
	and.16b	v2, v25, v2
	str	x13, [sp, #104]                 ; 8-byte Spill
	add	x8, x8, x13
	ldp	q3, q4, [x8]
	str	q15, [sp, #864]                 ; 16-byte Spill
	and.16b	v5, v15, v4
	and.16b	v3, v25, v3
	mov.16b	v16, v1
	stp	q7, q24, [sp, #160]             ; 32-byte Folded Spill
	str	q18, [sp, #192]                 ; 16-byte Spill
	mov.16b	v15, v18
	stp	q12, q11, [sp, #368]            ; 32-byte Folded Spill
	b	LBB0_167
LBB0_166:                               ; %else564
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmaxnm.4s	v4, v3, v21
	fmaxnm.4s	v18, v5, v31
	fmaxnm.4s	v19, v2, v12
	fmaxnm.4s	v20, v28, v13
	fmaxnm.4s	v21, v6, v14
	fmaxnm.4s	v22, v17, v29
	ldp	q10, q25, [sp, #864]            ; 32-byte Folded Reload
	sshll.2d	v25, v25, #0
	sshll.2d	v29, v10, #0
	fmaxnm.4s	v31, v27, v8
	fmaxnm.4s	v30, v26, v30
	dup.2d	v8, x17
	ldr	q9, [sp, #704]                  ; 16-byte Reload
	and.16b	v9, v9, v8
	add.2d	v15, v15, v9
	ldr	q9, [sp, #720]                  ; 16-byte Reload
	and.16b	v9, v9, v8
	add.2d	v24, v24, v9
	and.16b	v29, v29, v8
	add.2d	v7, v7, v29
	and.16b	v25, v25, v8
	add.2d	v16, v16, v25
	ldr	q25, [sp, #880]                 ; 16-byte Reload
	bit.16b	v5, v18, v10
	bit.16b	v3, v4, v25
	bit.16b	v28, v20, v10
	bit.16b	v2, v19, v25
	bit.16b	v17, v22, v10
	bit.16b	v6, v21, v25
	bit.16b	v26, v30, v10
	bit.16b	v27, v31, v25
	fmov	x8, d16
	cmp	x8, #8
	b.ge	LBB0_231
LBB0_167:                               ; %direct.true127
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w8, s0
	shl.2d	v8, v16, #5
	orr.16b	v4, v8, v23
	ldr	q18, [sp, #944]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	movi.2d	v21, #0000000000000000
	movi.2d	v31, #0000000000000000
	tbnz	w8, #0, LBB0_202
; %bb.168:                              ; %else375
                                        ;   in Loop: Header=BB0_167 Depth=1
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_203
LBB0_169:                               ; %else381
                                        ;   in Loop: Header=BB0_167 Depth=1
	shl.2d	v9, v24, #5
	ldr	q4, [sp, #912]                  ; 16-byte Reload
	orr.16b	v4, v9, v4
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #2, LBB0_204
LBB0_170:                               ; %else387
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbnz	w8, #3, LBB0_205
LBB0_171:                               ; %else393
                                        ;   in Loop: Header=BB0_167 Depth=1
	shl.2d	v10, v7, #5
	ldr	q4, [sp, #928]                  ; 16-byte Reload
	orr.16b	v4, v10, v4
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #4, LBB0_206
LBB0_172:                               ; %else399
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbnz	w8, #5, LBB0_207
LBB0_173:                               ; %else405
                                        ;   in Loop: Header=BB0_167 Depth=1
	shl.2d	v11, v15, #5
	ldr	q4, [sp, #896]                  ; 16-byte Reload
	orr.16b	v4, v11, v4
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #6, LBB0_208
LBB0_174:                               ; %else411
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbz	w8, #7, LBB0_176
LBB0_175:                               ; %cond.load413
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x8, v4[1]
	ld1.s	{ v31 }[3], [x8]
LBB0_176:                               ; %else417
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	w8, s0
	ldr	q4, [sp, #560]                  ; 16-byte Reload
	add.2d	v4, v8, v4
	ldr	q18, [sp, #944]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	movi.2d	v12, #0000000000000000
	movi.2d	v13, #0000000000000000
	tbnz	w8, #0, LBB0_209
; %bb.177:                              ; %else424
                                        ;   in Loop: Header=BB0_167 Depth=1
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_210
LBB0_178:                               ; %else430
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #576]                  ; 16-byte Reload
	add.2d	v4, v9, v4
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #2, LBB0_211
LBB0_179:                               ; %else436
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbnz	w8, #3, LBB0_212
LBB0_180:                               ; %else442
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #592]                  ; 16-byte Reload
	add.2d	v4, v10, v4
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #4, LBB0_213
LBB0_181:                               ; %else448
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbnz	w8, #5, LBB0_214
LBB0_182:                               ; %else454
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #544]                  ; 16-byte Reload
	add.2d	v4, v11, v4
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #6, LBB0_215
LBB0_183:                               ; %else460
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbz	w8, #7, LBB0_185
LBB0_184:                               ; %cond.load462
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x8, v4[1]
	ld1.s	{ v13 }[3], [x8]
LBB0_185:                               ; %else466
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	w8, s0
	ldr	q4, [sp, #496]                  ; 16-byte Reload
	add.2d	v4, v8, v4
	ldr	q18, [sp, #944]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	movi.2d	v14, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w8, #0, LBB0_216
; %bb.186:                              ; %else473
                                        ;   in Loop: Header=BB0_167 Depth=1
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_217
LBB0_187:                               ; %else479
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #512]                  ; 16-byte Reload
	add.2d	v4, v9, v4
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #2, LBB0_218
LBB0_188:                               ; %else485
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbnz	w8, #3, LBB0_219
LBB0_189:                               ; %else491
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #528]                  ; 16-byte Reload
	add.2d	v4, v10, v4
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #4, LBB0_220
LBB0_190:                               ; %else497
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbnz	w8, #5, LBB0_221
LBB0_191:                               ; %else503
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #480]                  ; 16-byte Reload
	add.2d	v4, v11, v4
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #6, LBB0_222
LBB0_192:                               ; %else509
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbz	w8, #7, LBB0_194
LBB0_193:                               ; %cond.load511
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x8, v4[1]
	ld1.s	{ v29 }[3], [x8]
LBB0_194:                               ; %else515
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	w8, s0
	ldr	q4, [sp, #432]                  ; 16-byte Reload
	add.2d	v4, v8, v4
	ldr	q18, [sp, #944]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	movi.2d	v8, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbnz	w8, #0, LBB0_223
; %bb.195:                              ; %else522
                                        ;   in Loop: Header=BB0_167 Depth=1
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_224
LBB0_196:                               ; %else528
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #448]                  ; 16-byte Reload
	add.2d	v4, v9, v4
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #2, LBB0_225
LBB0_197:                               ; %else534
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbnz	w8, #3, LBB0_226
LBB0_198:                               ; %else540
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #464]                  ; 16-byte Reload
	add.2d	v4, v10, v4
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #4, LBB0_227
LBB0_199:                               ; %else546
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbnz	w8, #5, LBB0_228
LBB0_200:                               ; %else552
                                        ;   in Loop: Header=BB0_167 Depth=1
	ldr	q4, [sp, #416]                  ; 16-byte Reload
	add.2d	v4, v11, v4
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbnz	w8, #6, LBB0_229
LBB0_201:                               ; %else558
                                        ;   in Loop: Header=BB0_167 Depth=1
	tbz	w8, #7, LBB0_166
	b	LBB0_230
LBB0_202:                               ; %cond.load371
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ldr	s21, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_169
LBB0_203:                               ; %cond.load377
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v21 }[1], [x9]
	shl.2d	v9, v24, #5
	ldr	q4, [sp, #912]                  ; 16-byte Reload
	orr.16b	v4, v9, v4
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #2, LBB0_170
LBB0_204:                               ; %cond.load383
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v21 }[2], [x9]
	tbz	w8, #3, LBB0_171
LBB0_205:                               ; %cond.load389
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v21 }[3], [x9]
	shl.2d	v10, v7, #5
	ldr	q4, [sp, #928]                  ; 16-byte Reload
	orr.16b	v4, v10, v4
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #4, LBB0_172
LBB0_206:                               ; %cond.load395
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v31 }[0], [x9]
	tbz	w8, #5, LBB0_173
LBB0_207:                               ; %cond.load401
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v31 }[1], [x9]
	shl.2d	v11, v15, #5
	ldr	q4, [sp, #896]                  ; 16-byte Reload
	orr.16b	v4, v11, v4
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #6, LBB0_174
LBB0_208:                               ; %cond.load407
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v31 }[2], [x9]
	tbnz	w8, #7, LBB0_175
	b	LBB0_176
LBB0_209:                               ; %cond.load420
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ldr	s12, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_178
LBB0_210:                               ; %cond.load426
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v12 }[1], [x9]
	ldr	q4, [sp, #576]                  ; 16-byte Reload
	add.2d	v4, v9, v4
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #2, LBB0_179
LBB0_211:                               ; %cond.load432
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v12 }[2], [x9]
	tbz	w8, #3, LBB0_180
LBB0_212:                               ; %cond.load438
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v12 }[3], [x9]
	ldr	q4, [sp, #592]                  ; 16-byte Reload
	add.2d	v4, v10, v4
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #4, LBB0_181
LBB0_213:                               ; %cond.load444
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v13 }[0], [x9]
	tbz	w8, #5, LBB0_182
LBB0_214:                               ; %cond.load450
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v13 }[1], [x9]
	ldr	q4, [sp, #544]                  ; 16-byte Reload
	add.2d	v4, v11, v4
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #6, LBB0_183
LBB0_215:                               ; %cond.load456
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v13 }[2], [x9]
	tbnz	w8, #7, LBB0_184
	b	LBB0_185
LBB0_216:                               ; %cond.load469
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ldr	s14, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_187
LBB0_217:                               ; %cond.load475
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v14 }[1], [x9]
	ldr	q4, [sp, #512]                  ; 16-byte Reload
	add.2d	v4, v9, v4
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #2, LBB0_188
LBB0_218:                               ; %cond.load481
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v14 }[2], [x9]
	tbz	w8, #3, LBB0_189
LBB0_219:                               ; %cond.load487
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v14 }[3], [x9]
	ldr	q4, [sp, #528]                  ; 16-byte Reload
	add.2d	v4, v10, v4
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #4, LBB0_190
LBB0_220:                               ; %cond.load493
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v29 }[0], [x9]
	tbz	w8, #5, LBB0_191
LBB0_221:                               ; %cond.load499
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v29 }[1], [x9]
	ldr	q4, [sp, #480]                  ; 16-byte Reload
	add.2d	v4, v11, v4
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #6, LBB0_192
LBB0_222:                               ; %cond.load505
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v29 }[2], [x9]
	tbnz	w8, #7, LBB0_193
	b	LBB0_194
LBB0_223:                               ; %cond.load518
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ldr	s8, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_196
LBB0_224:                               ; %cond.load524
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v8 }[1], [x9]
	ldr	q4, [sp, #448]                  ; 16-byte Reload
	add.2d	v4, v9, v4
	ldr	q18, [sp, #976]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #2, LBB0_197
LBB0_225:                               ; %cond.load530
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v8 }[2], [x9]
	tbz	w8, #3, LBB0_198
LBB0_226:                               ; %cond.load536
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v8 }[3], [x9]
	ldr	q4, [sp, #464]                  ; 16-byte Reload
	add.2d	v4, v10, v4
	ldr	q18, [sp, #960]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #4, LBB0_199
LBB0_227:                               ; %cond.load542
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v30 }[0], [x9]
	tbz	w8, #5, LBB0_200
LBB0_228:                               ; %cond.load548
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x9, v4[1]
	ld1.s	{ v30 }[1], [x9]
	ldr	q4, [sp, #416]                  ; 16-byte Reload
	add.2d	v4, v11, v4
	ldr	q18, [sp, #992]                 ; 16-byte Reload
	add.2d	v4, v18, v4
	tbz	w8, #6, LBB0_201
LBB0_229:                               ; %cond.load554
                                        ;   in Loop: Header=BB0_167 Depth=1
	fmov	x9, d4
	ld1.s	{ v30 }[2], [x9]
	tbz	w8, #7, LBB0_166
LBB0_230:                               ; %cond.load560
                                        ;   in Loop: Header=BB0_167 Depth=1
	mov.d	x8, v4[1]
	ld1.s	{ v30 }[3], [x8]
	b	LBB0_166
LBB0_231:                               ; %direct.false128
	str	x0, [sp, #32]                   ; 8-byte Spill
	str	x15, [sp, #56]                  ; 8-byte Spill
	str	x4, [sp, #288]                  ; 8-byte Spill
	ldr	q19, [sp, #352]                 ; 16-byte Reload
	zip1.8b	v7, v19, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldp	q16, q20, [sp, #64]             ; 32-byte Folded Reload
	and.16b	v16, v7, v16
	zip2.8b	v19, v19, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	and.16b	v20, v19, v20
	fmaxnm.4s	v5, v5, v20
	fmaxnm.4s	v3, v3, v16
	and.16b	v3, v7, v3
	and.16b	v5, v19, v5
	ldr	q16, [sp, #304]                 ; 16-byte Reload
	zip2.8b	v7, v16, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v5, v18, v7
	zip1.8b	v7, v16, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bit.16b	v3, v4, v7
	fmaxnm.4s	v2, v3, v2
	fmaxnm.4s	v3, v5, v28
	fmaxnm.4s	v3, v3, v17
	fmaxnm.4s	v2, v2, v6
	fmaxnm.4s	v6, v2, v27
	fmaxnm.4s	v7, v3, v26
	ldr	q2, [sp, #400]                  ; 16-byte Reload
	ldp	q4, q3, [sp, #672]              ; 32-byte Folded Reload
	uzp1.4s	v3, v2, v3
	ldr	q2, [sp, #656]                  ; 16-byte Reload
	uzp1.4s	v5, v4, v2
	movi.4s	v2, #1
	eor.16b	v4, v3, v2
	mov.s	w13, v4[1]
	mov.s	w14, v4[2]
	mov.s	w15, v4[3]
	eor.16b	v24, v5, v2
	fmov	w8, s4
	add	x9, sp, #1672
	add	x16, sp, #1672
	bfxil	x16, x8, #0, #3
	ldr	q22, [sp, #336]                 ; 16-byte Reload
	str	d22, [sp, #1672]
	ldrb	w16, [x16]
	and	x8, x8, #0x7
	umov.b	w17, v22[0]
	str	q7, [sp, #2336]
	str	q6, [sp, #2320]
	add	x0, sp, #2320
	ldr	s4, [x0, x8, lsl #2]
	ands	w8, w17, #0x1
	tst	w8, w16
	movi.2d	v2, #0000000000000000
	fcsel	s16, s4, s2, ne
	and	x16, x13, #0x7
	add	x1, sp, #1672
	bfxil	x1, x13, #0, #3
	umov.b	w0, v22[1]
	ldrb	w13, [x1]
	str	q7, [sp, #2304]
	str	q6, [sp, #2288]
	add	x1, sp, #2288
	ldr	s4, [x1, x16, lsl #2]
	and	w13, w0, w13
	tst	w13, #0x1
	fcsel	s17, s4, s2, ne
	and	x13, x14, #0x7
	add	x16, sp, #1672
	bfxil	x16, x14, #0, #3
	ldrb	w14, [x16]
	umov.b	w2, v22[2]
	and	w14, w2, w14
	str	q7, [sp, #2272]
	str	q6, [sp, #2256]
	add	x16, sp, #2256
	ldr	s4, [x16, x13, lsl #2]
	tst	w14, #0x1
	fcsel	s21, s4, s2, ne
	and	x13, x15, #0x7
	add	x14, sp, #1672
	bfxil	x14, x15, #0, #3
	ldrb	w14, [x14]
	umov.b	w1, v22[3]
	and	w14, w1, w14
	str	q7, [sp, #2240]
	str	q6, [sp, #2224]
	add	x15, sp, #2224
	ldr	s4, [x15, x13, lsl #2]
	tst	w14, #0x1
	mov.s	w13, v24[1]
	mov.s	w14, v24[2]
	mov.s	w15, v24[3]
	fcsel	s4, s4, s2, ne
	fmov	w16, s24
	and	x3, x16, #0x7
	add	x4, sp, #1672
	bfxil	x4, x16, #0, #3
	ldrb	w16, [x4]
	umov.b	w7, v22[4]
	and	w16, w7, w16
	str	q7, [sp, #2464]
	str	q6, [sp, #2448]
	add	x4, sp, #2448
	ldr	s18, [x4, x3, lsl #2]
	tst	w16, #0x1
	fcsel	s18, s18, s2, ne
	and	x16, x13, #0x7
	add	x3, sp, #1672
	bfxil	x3, x13, #0, #3
	ldrb	w13, [x3]
	umov.b	w6, v22[5]
	and	w13, w6, w13
	str	q7, [sp, #2432]
	str	q6, [sp, #2416]
	add	x3, sp, #2416
	ldr	s19, [x3, x16, lsl #2]
	tst	w13, #0x1
	fcsel	s19, s19, s2, ne
	and	x13, x14, #0x7
	add	x16, sp, #1672
	bfxil	x16, x14, #0, #3
	ldrb	w14, [x16]
	umov.b	w4, v22[6]
	and	w14, w4, w14
	str	q7, [sp, #2400]
	str	q6, [sp, #2384]
	add	x16, sp, #2384
	ldr	s20, [x16, x13, lsl #2]
	tst	w14, #0x1
	fcsel	s20, s20, s2, ne
	and	x13, x15, #0x7
	add	x14, sp, #1672
	bfxil	x14, x15, #0, #3
	ldrb	w14, [x14]
	umov.b	w5, v22[7]
	and	w14, w5, w14
	str	q7, [sp, #2368]
	str	q6, [sp, #2352]
	add	x15, sp, #2352
	ldr	s22, [x15, x13, lsl #2]
	tst	w14, #0x1
	fcsel	s22, s22, s2, ne
	mov.s	v18[1], v19[0]
	mov.s	v18[2], v20[0]
	mov.s	v18[3], v22[0]
	mov.s	v16[1], v17[0]
	mov.s	v16[2], v21[0]
	mov.s	v16[3], v4[0]
	fmaxnm.4s	v6, v6, v16
	fmaxnm.4s	v7, v7, v18
	movi.4s	v4, #2
	eor.16b	v16, v3, v4
	mov.s	w13, v16[1]
	mov.s	w14, v16[2]
	mov.s	w15, v16[3]
	fmov	w16, s16
	add	x3, sp, #1672
	bfxil	x3, x16, #0, #3
	ldrb	w3, [x3]
	and	x16, x16, #0x7
	str	q7, [sp, #2208]
	str	q6, [sp, #2192]
	add	x19, sp, #2192
	ldr	s16, [x19, x16, lsl #2]
	eor.16b	v24, v5, v4
	tst	w8, w3
	fcsel	s5, s16, s2, ne
	and	x16, x13, #0x7
	add	x3, sp, #1672
	bfxil	x3, x13, #0, #3
	ldrb	w13, [x3]
	str	q7, [sp, #2176]
	str	q6, [sp, #2160]
	add	x3, sp, #2160
	ldr	s4, [x3, x16, lsl #2]
	and	w13, w0, w13
	tst	w13, #0x1
	fcsel	s16, s4, s2, ne
	and	x13, x14, #0x7
	add	x16, sp, #1672
	bfxil	x16, x14, #0, #3
	ldrb	w14, [x16]
	str	q7, [sp, #2144]
	str	q6, [sp, #2128]
	add	x16, sp, #2128
	ldr	s4, [x16, x13, lsl #2]
	and	w13, w2, w14
	tst	w13, #0x1
	fcsel	s17, s4, s2, ne
	and	x13, x15, #0x7
	add	x14, sp, #1672
	bfxil	x14, x15, #0, #3
	ldrb	w14, [x14]
	str	q7, [sp, #2112]
	str	q6, [sp, #2096]
	add	x15, sp, #2096
	ldr	s4, [x15, x13, lsl #2]
	and	w13, w1, w14
	tst	w13, #0x1
	mov.s	w13, v24[3]
	mov.s	w23, v24[1]
	fcsel	s21, s4, s2, ne
	mov.s	w24, v24[2]
	fmov	w14, s24
	and	x25, x14, #0x7
	add	x26, sp, #1672
	bfxil	x26, x14, #0, #3
	add	x14, sp, #1672
	bfxil	x14, x13, #0, #3
	ldrb	w27, [x14]
	movi.4s	v4, #4
	eor.16b	v3, v3, v4
	mov.s	w3, v3[1]
	mov.s	w15, v3[2]
	mov.s	w14, v3[3]
	fmov	w22, s3
	add	x16, sp, #1672
	bfxil	x16, x22, #0, #3
	ldrb	w20, [x16]
	add	x16, sp, #1672
	bfxil	x16, x3, #0, #3
	ldrb	w21, [x16]
	add	x16, sp, #1672
	bfxil	x16, x15, #0, #3
	ldrb	w19, [x16]
	add	x16, sp, #1672
	bfxil	x16, x14, #0, #3
	ldrb	w16, [x16]
	ldrb	w26, [x26]
	and	w26, w7, w26
	str	q7, [sp, #2080]
	str	q6, [sp, #2064]
	add	x28, sp, #2064
	ldr	s3, [x28, x25, lsl #2]
	tst	w26, #0x1
	fcsel	s3, s3, s2, ne
	and	x25, x23, #0x7
	add	x26, sp, #1672
	bfxil	x26, x23, #0, #3
	ldrb	w23, [x26]
	and	w23, w6, w23
	str	q7, [sp, #2048]
	str	q6, [sp, #2032]
	add	x26, sp, #2032
	ldr	s4, [x26, x25, lsl #2]
	tst	w23, #0x1
	fcsel	s4, s4, s2, ne
	and	x23, x24, #0x7
	bfxil	x9, x24, #0, #3
	ldrb	w9, [x9]
	str	q7, [sp, #2016]
	str	q6, [sp, #2000]
	add	x24, sp, #2000
	ldr	s18, [x24, x23, lsl #2]
	and	w9, w4, w9
	tst	w9, #0x1
	fcsel	s18, s18, s2, ne
	and	x9, x13, #0x7
	and	w13, w5, w27
	str	q7, [sp, #1984]
	str	q6, [sp, #1968]
	add	x23, sp, #1968
	ldr	s19, [x23, x9, lsl #2]
	tst	w13, #0x1
	fcsel	s19, s19, s2, ne
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v18[0]
	mov.s	v3[3], v19[0]
	mov.s	v5[1], v16[0]
	mov.s	v5[2], v17[0]
	mov.s	v5[3], v21[0]
	fmaxnm.4s	v5, v6, v5
	fmaxnm.4s	v3, v7, v3
	and	x9, x22, #0x7
	str	q3, [sp, #1952]
	str	q5, [sp, #1936]
	add	x13, sp, #1936
	ldr	s4, [x13, x9, lsl #2]
	tst	w8, w20
	fcsel	s6, s4, s2, ne
	and	x8, x3, #0x7
	and	w9, w0, w21
	str	q3, [sp, #1920]
	str	q5, [sp, #1904]
	add	x13, sp, #1904
	ldr	s4, [x13, x8, lsl #2]
	tst	w9, #0x1
	fcsel	s7, s4, s2, ne
	and	x8, x15, #0x7
	and	w9, w2, w19
	str	q3, [sp, #1888]
	str	q5, [sp, #1872]
	add	x13, sp, #1872
	ldr	s4, [x13, x8, lsl #2]
	tst	w9, #0x1
	fcsel	s16, s4, s2, ne
	and	x8, x14, #0x7
	and	w9, w1, w16
	str	q3, [sp, #1856]
	str	q5, [sp, #1840]
	add	x13, sp, #1840
	ldr	s3, [x13, x8, lsl #2]
	tst	w9, #0x1
	fcsel	s17, s3, s2, ne
	ands	w19, w17, #0x1
	sshll.2d	v3, v25, #0
	ldr	q4, [sp, #864]                  ; 16-byte Reload
	sshll.2d	v4, v4, #0
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	fmaxnm.4s	v5, v5, v6
	fcsel	s6, s5, s2, ne
	and	w9, w0, w17
	and	w8, w0, w17
	str	w8, [sp, #80]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s7, s5, s2, ne
	and	w9, w2, w17
	and	w8, w2, w17
	str	w8, [sp, #64]                   ; 4-byte Spill
	tst	w9, #0x1
	fcsel	s16, s5, s2, ne
	and	w22, w1, w17
	tst	w22, #0x1
	fcsel	s17, s5, s2, ne
	and	w23, w7, w17
	tst	w23, #0x1
	fcsel	s18, s5, s2, ne
	and	w24, w6, w17
	tst	w24, #0x1
	fcsel	s19, s5, s2, ne
	and	w25, w4, w17
	tst	w25, #0x1
	fcsel	s20, s5, s2, ne
	and	w26, w5, w17
	tst	w26, #0x1
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v16[0]
	mov.s	v6[3], v17[0]
	mov.s	v18[1], v19[0]
	mov.s	v18[2], v20[0]
	fcsel	s2, s5, s2, ne
	mov.s	v18[3], v2[0]
	rbit	w8, w12
	clz	w12, w8
	str	q18, [sp, #1696]
	str	q6, [sp, #1680]
	and	x8, x12, #0x7
	add	x9, sp, #1680
	ldr	s2, [x9, x8, lsl #2]
	mov	w8, #-8388608                   ; =0xff800000
	fmov	s5, w8
	fmaxnm	s2, s2, s5
	ldr	q5, [sp, #704]                  ; 16-byte Reload
	ldr	q6, [sp, #640]                  ; 16-byte Reload
	and.16b	v5, v5, v6
	str	q5, [sp, #400]                  ; 16-byte Spill
	ldr	q5, [sp, #720]                  ; 16-byte Reload
	and.16b	v5, v5, v6
	and.16b	v4, v4, v6
	stp	q4, q5, [sp, #656]              ; 32-byte Folded Spill
	and.16b	v3, v3, v6
	str	q3, [sp, #640]                  ; 16-byte Spill
	dup.4s	v2, v2[0]
	movi.2d	v3, #0000000000000000
	mov	w27, #-1026555904               ; =0xc2d00000
	mov	w28, #1120403456                ; =0x42c80000
	mov	w30, #43579                     ; =0xaa3b
	movk	w30, #16312, lsl #16
	movi.4s	v26, #75, lsl #24
	mvni.4s	v27, #128, lsl #24
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	mov	w13, #48782                     ; =0xbe8e
	movk	w13, #46527, lsl #16
	mov	w14, #11226                     ; =0x2bda
	movk	w14, #14672, lsl #16
	mov	w15, #38601                     ; =0x96c9
	movk	w15, #15030, lsl #16
	mov	w16, #34982                     ; =0x88a6
	movk	w16, #15368, lsl #16
	mov	w3, #43642                      ; =0xaa7a
	movk	w3, #15658, lsl #16
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	fmov.4s	v21, #1.00000000
	mvni.4s	v4, #127, msl #16
	fneg.4s	v24, v4
	mvni.4s	v4, #63, msl #16
	fneg.4s	v28, v4
	movi.2d	v31, #0000000000000000
	movi.2d	v15, #0000000000000000
	movi.2d	v8, #0000000000000000
	str	q23, [sp, #688]                 ; 16-byte Spill
	b	LBB0_233
LBB0_232:                               ; %else696
                                        ;   in Loop: Header=BB0_233 Depth=1
	add.2d	v31, v31, v7
	ldp	q4, q5, [sp, #608]              ; 32-byte Folded Reload
	add.2d	v15, v15, v5
	add.2d	v8, v8, v6
	add.2d	v3, v3, v4
	fmov	x20, d3
	cmp	x20, #8
	b.ge	LBB0_281
LBB0_233:                               ; %direct.true154
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w20, s0
	ldr	q4, [sp, #736]                  ; 16-byte Reload
	add.2d	v4, v3, v4
	ldr	q5, [sp, #800]                  ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w20, #0, LBB0_261
; %bb.234:                              ; %cond.load567
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d4
	ldr	b29, [x21]
	and	w20, w20, #0xff
	tbz	w20, #1, LBB0_236
LBB0_235:                               ; %cond.load573
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v4[1]
	ld1.b	{ v29 }[1], [x21]
LBB0_236:                               ; %else577
                                        ;   in Loop: Header=BB0_233 Depth=1
	ldr	q4, [sp, #768]                  ; 16-byte Reload
	add.2d	v4, v31, v4
	ldr	q5, [sp, #832]                  ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w20, #2, LBB0_262
; %bb.237:                              ; %else583
                                        ;   in Loop: Header=BB0_233 Depth=1
	tbnz	w20, #3, LBB0_263
LBB0_238:                               ; %else589
                                        ;   in Loop: Header=BB0_233 Depth=1
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	add.2d	v4, v15, v4
	ldr	q5, [sp, #816]                  ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w20, #4, LBB0_264
LBB0_239:                               ; %else595
                                        ;   in Loop: Header=BB0_233 Depth=1
	tbnz	w20, #5, LBB0_265
LBB0_240:                               ; %else601
                                        ;   in Loop: Header=BB0_233 Depth=1
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	add.2d	v4, v8, v4
	ldr	q5, [sp, #848]                  ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w20, #6, LBB0_266
LBB0_241:                               ; %else607
                                        ;   in Loop: Header=BB0_233 Depth=1
	tbz	w20, #7, LBB0_243
LBB0_242:                               ; %cond.load609
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x20, v4[1]
	ld1.b	{ v29 }[7], [x20]
LBB0_243:                               ; %else613
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	w20, s0
	shl.2d	v4, v3, #5
	orr.16b	v11, v4, v23
	ldr	q4, [sp, #944]                  ; 16-byte Reload
	add.2d	v4, v4, v11
	movi.2d	v14, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w20, #0, LBB0_267
; %bb.244:                              ; %else620
                                        ;   in Loop: Header=BB0_233 Depth=1
	and	w20, w20, #0xff
	tbnz	w20, #1, LBB0_268
LBB0_245:                               ; %else626
                                        ;   in Loop: Header=BB0_233 Depth=1
	shl.2d	v4, v31, #5
	ldr	q5, [sp, #912]                  ; 16-byte Reload
	orr.16b	v13, v4, v5
	ldr	q4, [sp, #976]                  ; 16-byte Reload
	add.2d	v4, v4, v13
	tbnz	w20, #2, LBB0_269
LBB0_246:                               ; %else632
                                        ;   in Loop: Header=BB0_233 Depth=1
	tbnz	w20, #3, LBB0_270
LBB0_247:                               ; %else638
                                        ;   in Loop: Header=BB0_233 Depth=1
	shl.2d	v4, v15, #5
	ldr	q5, [sp, #928]                  ; 16-byte Reload
	orr.16b	v10, v4, v5
	ldr	q4, [sp, #960]                  ; 16-byte Reload
	add.2d	v4, v4, v10
	tbnz	w20, #4, LBB0_271
LBB0_248:                               ; %else644
                                        ;   in Loop: Header=BB0_233 Depth=1
	tbnz	w20, #5, LBB0_272
LBB0_249:                               ; %else650
                                        ;   in Loop: Header=BB0_233 Depth=1
	shl.2d	v4, v8, #5
	ldr	q5, [sp, #896]                  ; 16-byte Reload
	orr.16b	v12, v4, v5
	ldr	q4, [sp, #992]                  ; 16-byte Reload
	add.2d	v4, v4, v12
	tbnz	w20, #6, LBB0_273
LBB0_250:                               ; %else656
                                        ;   in Loop: Header=BB0_233 Depth=1
	tbz	w20, #7, LBB0_252
LBB0_251:                               ; %cond.load658
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x20, v4[1]
	ld1.s	{ v9 }[3], [x20]
LBB0_252:                               ; %else662
                                        ;   in Loop: Header=BB0_233 Depth=1
	cmeq.8b	v4, v29, #0
	sshll.8h	v5, v4, #0
	sshll.4s	v22, v5, #0
	fmov	w20, s0
	fsub.4s	v4, v14, v2
	and.16b	v23, v25, v4
	dup.4s	v29, w27
	dup.4s	v30, w28
	fcmge.4s	v4, v23, v29
	fcmge.4s	v7, v30, v23
	and.16b	v4, v4, v7
	and.16b	v4, v4, v23
	dup.4s	v14, w30
	fmul.4s	v7, v4, v14
	mov.16b	v16, v27
	bsl.16b	v16, v26, v7
	fadd.4s	v7, v7, v16
	fsub.4s	v7, v7, v16
	fcvtzs.4s	v26, v7
	scvtf.4s	v18, v26
	dup.4s	v7, w8
	fmul.4s	v16, v18, v7
	fadd.4s	v4, v4, v16
	dup.4s	v16, w13
	fmul.4s	v18, v18, v16
	fadd.4s	v27, v4, v18
	dup.4s	v25, w14
	dup.4s	v4, w15
	fmul.4s	v18, v27, v25
	fadd.4s	v18, v18, v4
	fmul.4s	v18, v27, v18
	dup.4s	v20, w16
	fadd.4s	v18, v18, v20
	fmul.4s	v19, v27, v18
	dup.4s	v18, w3
	fadd.4s	v17, v19, v18
	dup.4s	v19, w9
	fmul.4s	v17, v27, v17
	fadd.4s	v17, v17, v19
	fmul.4s	v17, v27, v17
	movi.4s	v6, #63, lsl #24
	fadd.4s	v17, v17, v6
	fmul.4s	v6, v27, v27
	fmul.4s	v6, v6, v17
	fadd.4s	v6, v27, v6
	fadd.4s	v6, v6, v21
	sshr.4s	v17, v26, #1
	shl.4s	v27, v17, #23
	add.4s	v27, v27, v21
	fmul.4s	v6, v6, v27
	sub.4s	v17, v26, v17
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v21
	fmul.4s	v6, v6, v17
	fcmgt.4s	v17, v29, v23
	bic.16b	v6, v6, v17
	fcmgt.4s	v17, v23, v30
	bit.16b	v6, v24, v17
	fcmeq.4s	v17, v23, v23
	bif.16b	v6, v28, v17
	bic.16b	v22, v6, v22
	ldr	q6, [sp, #640]                  ; 16-byte Reload
	add.2d	v11, v6, v11
	tbnz	w20, #0, LBB0_274
; %bb.253:                              ; %else668
                                        ;   in Loop: Header=BB0_233 Depth=1
	and	w20, w20, #0xff
	ldr	q6, [sp, #672]                  ; 16-byte Reload
	tbnz	w20, #1, LBB0_275
LBB0_254:                               ; %else672
                                        ;   in Loop: Header=BB0_233 Depth=1
	add.2d	v11, v6, v13
	movi.4s	v26, #75, lsl #24
	mvni.4s	v27, #128, lsl #24
	tbnz	w20, #2, LBB0_276
LBB0_255:                               ; %else676
                                        ;   in Loop: Header=BB0_233 Depth=1
	tbz	w20, #3, LBB0_257
LBB0_256:                               ; %cond.store677
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v11[1]
	st1.s	{ v22 }[3], [x21]
LBB0_257:                               ; %else680
                                        ;   in Loop: Header=BB0_233 Depth=1
	sshll2.4s	v5, v5, #0
	fsub.4s	v6, v9, v2
	ldr	q17, [sp, #864]                 ; 16-byte Reload
	and.16b	v6, v17, v6
	fcmge.4s	v17, v6, v29
	fcmge.4s	v22, v30, v6
	and.16b	v17, v17, v22
	and.16b	v17, v17, v6
	fmul.4s	v22, v17, v14
	mov.16b	v23, v27
	bsl.16b	v23, v26, v22
	fadd.4s	v22, v22, v23
	fsub.4s	v22, v22, v23
	fcvtzs.4s	v22, v22
	scvtf.4s	v23, v22
	fmul.4s	v7, v23, v7
	fadd.4s	v7, v17, v7
	fmul.4s	v16, v23, v16
	fadd.4s	v7, v7, v16
	fmul.4s	v16, v7, v25
	fadd.4s	v4, v16, v4
	fmul.4s	v4, v7, v4
	fadd.4s	v4, v4, v20
	fmul.4s	v4, v7, v4
	fadd.4s	v4, v4, v18
	fmul.4s	v4, v7, v4
	fadd.4s	v4, v4, v19
	fmul.4s	v4, v7, v4
	movi.4s	v16, #63, lsl #24
	fadd.4s	v4, v4, v16
	fmul.4s	v16, v7, v7
	fmul.4s	v4, v16, v4
	fadd.4s	v4, v7, v4
	fadd.4s	v4, v4, v21
	sshr.4s	v7, v22, #1
	shl.4s	v16, v7, #23
	add.4s	v16, v16, v21
	fmul.4s	v4, v4, v16
	sub.4s	v7, v22, v7
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v21
	fmul.4s	v4, v4, v7
	fcmgt.4s	v7, v29, v6
	bic.16b	v4, v4, v7
	fcmgt.4s	v7, v6, v30
	bit.16b	v4, v24, v7
	fcmeq.4s	v6, v6, v6
	bif.16b	v4, v28, v6
	bic.16b	v4, v4, v5
	ldr	q5, [sp, #656]                  ; 16-byte Reload
	add.2d	v5, v5, v10
	tbnz	w20, #4, LBB0_277
; %bb.258:                              ; %else684
                                        ;   in Loop: Header=BB0_233 Depth=1
	ldr	q23, [sp, #688]                 ; 16-byte Reload
	ldp	q6, q30, [sp, #384]             ; 32-byte Folded Reload
	ldr	q25, [sp, #880]                 ; 16-byte Reload
	tbnz	w20, #5, LBB0_278
LBB0_259:                               ; %else688
                                        ;   in Loop: Header=BB0_233 Depth=1
	add.2d	v5, v30, v12
	tbnz	w20, #6, LBB0_279
LBB0_260:                               ; %else692
                                        ;   in Loop: Header=BB0_233 Depth=1
	ldr	q7, [sp, #368]                  ; 16-byte Reload
	tbz	w20, #7, LBB0_232
	b	LBB0_280
LBB0_261:                               ;   in Loop: Header=BB0_233 Depth=1
	movi.2d	v29, #0000000000000000
	and	w20, w20, #0xff
	tbnz	w20, #1, LBB0_235
	b	LBB0_236
LBB0_262:                               ; %cond.load579
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d4
	ld1.b	{ v29 }[2], [x21]
	tbz	w20, #3, LBB0_238
LBB0_263:                               ; %cond.load585
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v4[1]
	ld1.b	{ v29 }[3], [x21]
	ldr	q4, [sp, #752]                  ; 16-byte Reload
	add.2d	v4, v15, v4
	ldr	q5, [sp, #816]                  ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w20, #4, LBB0_239
LBB0_264:                               ; %cond.load591
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d4
	ld1.b	{ v29 }[4], [x21]
	tbz	w20, #5, LBB0_240
LBB0_265:                               ; %cond.load597
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v4[1]
	ld1.b	{ v29 }[5], [x21]
	ldr	q4, [sp, #784]                  ; 16-byte Reload
	add.2d	v4, v8, v4
	ldr	q5, [sp, #848]                  ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w20, #6, LBB0_241
LBB0_266:                               ; %cond.load603
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d4
	ld1.b	{ v29 }[6], [x21]
	tbnz	w20, #7, LBB0_242
	b	LBB0_243
LBB0_267:                               ; %cond.load616
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d4
	ldr	s14, [x21]
	and	w20, w20, #0xff
	tbz	w20, #1, LBB0_245
LBB0_268:                               ; %cond.load622
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v4[1]
	ld1.s	{ v14 }[1], [x21]
	shl.2d	v4, v31, #5
	ldr	q5, [sp, #912]                  ; 16-byte Reload
	orr.16b	v13, v4, v5
	ldr	q4, [sp, #976]                  ; 16-byte Reload
	add.2d	v4, v4, v13
	tbz	w20, #2, LBB0_246
LBB0_269:                               ; %cond.load628
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d4
	ld1.s	{ v14 }[2], [x21]
	tbz	w20, #3, LBB0_247
LBB0_270:                               ; %cond.load634
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v4[1]
	ld1.s	{ v14 }[3], [x21]
	shl.2d	v4, v15, #5
	ldr	q5, [sp, #928]                  ; 16-byte Reload
	orr.16b	v10, v4, v5
	ldr	q4, [sp, #960]                  ; 16-byte Reload
	add.2d	v4, v4, v10
	tbz	w20, #4, LBB0_248
LBB0_271:                               ; %cond.load640
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d4
	ld1.s	{ v9 }[0], [x21]
	tbz	w20, #5, LBB0_249
LBB0_272:                               ; %cond.load646
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v4[1]
	ld1.s	{ v9 }[1], [x21]
	shl.2d	v4, v8, #5
	ldr	q5, [sp, #896]                  ; 16-byte Reload
	orr.16b	v12, v4, v5
	ldr	q4, [sp, #992]                  ; 16-byte Reload
	add.2d	v4, v4, v12
	tbz	w20, #6, LBB0_250
LBB0_273:                               ; %cond.load652
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d4
	ld1.s	{ v9 }[2], [x21]
	tbnz	w20, #7, LBB0_251
	b	LBB0_252
LBB0_274:                               ; %cond.store665
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d11
	str	s22, [x21]
	and	w20, w20, #0xff
	ldr	q6, [sp, #672]                  ; 16-byte Reload
	tbz	w20, #1, LBB0_254
LBB0_275:                               ; %cond.store669
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v11[1]
	st1.s	{ v22 }[1], [x21]
	add.2d	v11, v6, v13
	movi.4s	v26, #75, lsl #24
	mvni.4s	v27, #128, lsl #24
	tbz	w20, #2, LBB0_255
LBB0_276:                               ; %cond.store673
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d11
	st1.s	{ v22 }[2], [x21]
	tbnz	w20, #3, LBB0_256
	b	LBB0_257
LBB0_277:                               ; %cond.store681
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d5
	str	s4, [x21]
	ldr	q23, [sp, #688]                 ; 16-byte Reload
	ldp	q6, q30, [sp, #384]             ; 32-byte Folded Reload
	ldr	q25, [sp, #880]                 ; 16-byte Reload
	tbz	w20, #5, LBB0_259
LBB0_278:                               ; %cond.store685
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x21, v5[1]
	st1.s	{ v4 }[1], [x21]
	add.2d	v5, v30, v12
	tbz	w20, #6, LBB0_260
LBB0_279:                               ; %cond.store689
                                        ;   in Loop: Header=BB0_233 Depth=1
	fmov	x21, d5
	st1.s	{ v4 }[2], [x21]
	ldr	q7, [sp, #368]                  ; 16-byte Reload
	tbz	w20, #7, LBB0_232
LBB0_280:                               ; %cond.store693
                                        ;   in Loop: Header=BB0_233 Depth=1
	mov.d	x20, v5[1]
	st1.s	{ v4 }[3], [x20]
	b	LBB0_232
LBB0_281:                               ; %direct.true191.preheader
	ldr	d3, [sp, #328]                  ; 8-byte Reload
	fmov	w8, s3
	tbz	w8, #0, LBB0_287
; %bb.282:                              ; %cond.load698
	ldr	q3, [sp, #16]                   ; 16-byte Reload
	fmov	x9, d3
	ldr	b3, [x9]
	ldr	q27, [sp, #864]                 ; 16-byte Reload
	ldr	q15, [sp, #192]                 ; 16-byte Reload
	ldp	q5, q4, [sp, #128]              ; 32-byte Folded Reload
	ldr	q6, [sp, #112]                  ; 16-byte Reload
	tbnz	w8, #1, LBB0_288
	b	LBB0_289
LBB0_283:                               ; %cond.load334
	fmov	x9, d30
	ld1.b	{ v1 }[2], [x9]
	tbz	w8, #3, LBB0_159
LBB0_284:                               ; %cond.load340
	ld1.b	{ v1 }[3], [x17]
	tbz	w8, #4, LBB0_160
LBB0_285:                               ; %cond.load346
	fmov	x9, d29
	ld1.b	{ v1 }[4], [x9]
	tbz	w8, #5, LBB0_161
LBB0_286:                               ; %cond.load352
	ld1.b	{ v1 }[5], [x16]
	tbnz	w8, #6, LBB0_162
	b	LBB0_163
LBB0_287:
	movi.2d	v3, #0000000000000000
	ldr	q27, [sp, #864]                 ; 16-byte Reload
	ldr	q15, [sp, #192]                 ; 16-byte Reload
	ldp	q5, q4, [sp, #128]              ; 32-byte Folded Reload
	ldr	q6, [sp, #112]                  ; 16-byte Reload
	tbz	w8, #1, LBB0_289
LBB0_288:                               ; %cond.load704
	ldr	x9, [sp, #32]                   ; 8-byte Reload
	ld1.b	{ v3 }[1], [x9]
LBB0_289:                               ; %else708
	tbnz	w8, #2, LBB0_406
; %bb.290:                              ; %else714
	tbnz	w8, #3, LBB0_407
LBB0_291:                               ; %else720
	tbnz	w8, #4, LBB0_408
LBB0_292:                               ; %else726
	tbnz	w8, #5, LBB0_409
LBB0_293:                               ; %else732
	adrp	x9, lCPI0_20@PAGE
	adrp	x13, lCPI0_21@PAGE
	adrp	x14, lCPI0_22@PAGE
	adrp	x15, lCPI0_23@PAGE
	adrp	x16, lCPI0_24@PAGE
	tbnz	w8, #6, LBB0_410
LBB0_294:                               ; %else738
	ldr	q4, [x9, lCPI0_20@PAGEOFF]
	ldr	q5, [x13, lCPI0_21@PAGEOFF]
	ldr	q7, [x14, lCPI0_22@PAGEOFF]
	ldr	q16, [x15, lCPI0_23@PAGEOFF]
	ldr	q18, [x16, lCPI0_24@PAGEOFF]
	tbz	w8, #7, LBB0_296
LBB0_295:                               ; %cond.load740
	ldr	x8, [sp, #56]                   ; 8-byte Reload
	ld1.b	{ v3 }[7], [x8]
LBB0_296:                               ; %else744
	and.16b	v6, v27, v4
	and.16b	v31, v25, v5
	and.16b	v5, v27, v7
	and.16b	v4, v25, v16
	stp	q6, q4, [sp, #944]              ; 32-byte Folded Spill
	and.16b	v4, v25, v18
	stp	q5, q4, [sp, #976]              ; 32-byte Folded Spill
	cmeq.8b	v3, v3, #0
	sshll.8h	v4, v3, #0
	sshll2.4s	v3, v4, #0
	sshll.4s	v4, v4, #0
	add	x8, sp, #3000
	add	x8, x8, x10
	ldp	q6, q5, [x8]
	fsub.4s	v6, v6, v2
	fsub.4s	v5, v5, v2
	ldr	q16, [sp, #352]                 ; 16-byte Reload
	zip2.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	and.16b	v7, v2, v5
	zip1.8b	v5, v16, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	and.16b	v16, v5, v6
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v21, w8
	fcmge.4s	v6, v16, v21
	fcmge.4s	v17, v7, v21
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v24, w8
	fcmge.4s	v18, v24, v16
	fcmge.4s	v19, v24, v7
	and.16b	v17, v17, v19
	and.16b	v6, v6, v18
	and.16b	v6, v6, v16
	and.16b	v17, v17, v7
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v18, w8
	fmul.4s	v19, v17, v18
	fmul.4s	v18, v6, v18
	movi.4s	v20, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v23, v22
	bsl.16b	v23, v20, v18
	bif.16b	v20, v19, v22
	fadd.4s	v19, v19, v20
	fadd.4s	v18, v18, v23
	fsub.4s	v22, v18, v23
	fsub.4s	v18, v19, v20
	fcvtzs.4s	v18, v18
	fcvtzs.4s	v19, v22
	scvtf.4s	v20, v19
	scvtf.4s	v22, v18
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v23, w8
	fmul.4s	v25, v22, v23
	fmul.4s	v23, v20, v23
	fadd.4s	v6, v6, v23
	fadd.4s	v17, v17, v25
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v23, w8
	fmul.4s	v20, v20, v23
	fmul.4s	v22, v22, v23
	fadd.4s	v17, v17, v22
	fadd.4s	v6, v6, v20
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v20, w8
	fmul.4s	v22, v6, v20
	fmul.4s	v20, v17, v20
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v23, w8
	fadd.4s	v20, v20, v23
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v6, v22
	fmul.4s	v20, v17, v20
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v23, w8
	fadd.4s	v20, v20, v23
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v6, v22
	mov	w8, #43642                      ; =0xaa7a
	movk	w8, #15658, lsl #16
	dup.4s	v23, w8
	fmul.4s	v20, v17, v20
	fadd.4s	v20, v20, v23
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v6, v22
	fmul.4s	v20, v17, v20
	mov	w8, #43691                      ; =0xaaab
	movk	w8, #15914, lsl #16
	dup.4s	v23, w8
	fadd.4s	v20, v20, v23
	fadd.4s	v22, v22, v23
	fmul.4s	v22, v6, v22
	fmul.4s	v20, v17, v20
	movi.4s	v23, #63, lsl #24
	fadd.4s	v20, v20, v23
	fadd.4s	v22, v22, v23
	fmul.4s	v23, v17, v17
	fmul.4s	v25, v6, v6
	fmul.4s	v22, v25, v22
	fmul.4s	v20, v23, v20
	fadd.4s	v17, v17, v20
	fadd.4s	v6, v6, v22
	fmov.4s	v20, #1.00000000
	fadd.4s	v6, v6, v20
	fadd.4s	v17, v17, v20
	sshr.4s	v22, v19, #1
	sshr.4s	v23, v18, #1
	shl.4s	v25, v23, #23
	shl.4s	v26, v22, #23
	add.4s	v26, v26, v20
	add.4s	v25, v25, v20
	fmul.4s	v17, v17, v25
	ldr	q25, [sp, #880]                 ; 16-byte Reload
	fmul.4s	v6, v6, v26
	sub.4s	v18, v18, v23
	sub.4s	v19, v19, v22
	shl.4s	v19, v19, #23
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v20
	add.4s	v19, v19, v20
	fmul.4s	v6, v6, v19
	fmul.4s	v17, v17, v18
	fcmgt.4s	v18, v21, v7
	bic.16b	v17, v17, v18
	fcmgt.4s	v18, v21, v16
	bic.16b	v6, v6, v18
	fcmgt.4s	v18, v7, v24
	fcmgt.4s	v19, v16, v24
	mvni.4s	v20, #127, msl #16
	fneg.4s	v20, v20
	bit.16b	v6, v20, v19
	bit.16b	v17, v20, v18
	fcmeq.4s	v16, v16, v16
	fcmeq.4s	v7, v7, v7
	mvni.4s	v18, #63, msl #16
	fneg.4s	v18, v18
	bsl.16b	v7, v17, v18
	bif.16b	v6, v18, v16
	bic.16b	v6, v6, v4
	bic.16b	v7, v7, v3
	add	x8, sp, #2712
	add	x9, x8, x10
	ldp	q3, q4, [x9]
	stp	q7, q6, [sp, #832]              ; 32-byte Folded Spill
	bsl.16b	v2, v7, v4
	bit.16b	v3, v6, v5
	stp	q3, q2, [x9]
	ldp	q2, q3, [x11, #96]
	and.16b	v8, v27, v3
	and.16b	v9, v25, v2
	ldp	q2, q3, [x11, #64]
	and.16b	v11, v27, v3
	and.16b	v10, v25, v2
	ldp	q2, q3, [x11, #32]
	and.16b	v28, v27, v3
	and.16b	v12, v25, v2
	ldr	x9, [sp, #104]                  ; 8-byte Reload
	add	x8, x8, x9
	ldp	q2, q3, [x8]
	and.16b	v5, v27, v3
	and.16b	v3, v25, v2
	mov	w11, #4                         ; =0x4
	ldp	q19, q23, [sp, #160]            ; 32-byte Folded Reload
	b	LBB0_298
LBB0_297:                               ; %else940
                                        ;   in Loop: Header=BB0_298 Depth=1
	fadd.4s	v7, v3, v7
	fadd.4s	v16, v5, v16
	fadd.4s	v4, v12, v4
	fadd.4s	v2, v28, v2
	fadd.4s	v6, v10, v13
	fadd.4s	v17, v11, v25
	ldr	q25, [sp, #880]                 ; 16-byte Reload
	sshll.2d	v18, v25, #0
	sshll.2d	v19, v27, #0
	fadd.4s	v20, v9, v21
	fadd.4s	v21, v8, v29
	dup.2d	v22, x11
	ldr	q23, [sp, #704]                 ; 16-byte Reload
	and.16b	v23, v23, v22
	add.2d	v15, v15, v23
	ldr	q23, [sp, #720]                 ; 16-byte Reload
	and.16b	v23, v23, v22
	add.2d	v23, v14, v23
	and.16b	v19, v19, v22
	add.2d	v19, v30, v19
	and.16b	v18, v18, v22
	add.2d	v1, v1, v18
	bit.16b	v5, v16, v27
	bit.16b	v3, v7, v25
	bit.16b	v28, v2, v27
	bit.16b	v12, v4, v25
	bit.16b	v11, v17, v27
	bit.16b	v10, v6, v25
	bit.16b	v8, v21, v27
	bit.16b	v9, v20, v25
	fmov	x8, d1
	cmp	x8, #8
	ldr	q30, [sp, #400]                 ; 16-byte Reload
	b.ge	LBB0_362
LBB0_298:                               ; %direct.true191
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w8, s0
	shl.2d	v21, v1, #5
	ldp	q20, q2, [sp, #672]             ; 32-byte Folded Reload
	orr.16b	v2, v21, v2
	ldp	q26, q22, [sp, #640]            ; 32-byte Folded Reload
	add.2d	v2, v26, v2
	movi.2d	v7, #0000000000000000
	movi.2d	v16, #0000000000000000
	tbnz	w8, #0, LBB0_333
; %bb.299:                              ; %else751
                                        ;   in Loop: Header=BB0_298 Depth=1
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_334
LBB0_300:                               ; %else757
                                        ;   in Loop: Header=BB0_298 Depth=1
	shl.2d	v24, v23, #5
	ldr	q2, [sp, #912]                  ; 16-byte Reload
	orr.16b	v2, v24, v2
	add.2d	v2, v20, v2
	tbnz	w8, #2, LBB0_335
LBB0_301:                               ; %else763
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbnz	w8, #3, LBB0_336
LBB0_302:                               ; %else769
                                        ;   in Loop: Header=BB0_298 Depth=1
	shl.2d	v14, v19, #5
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	orr.16b	v2, v14, v2
	add.2d	v2, v22, v2
	tbnz	w8, #4, LBB0_337
LBB0_303:                               ; %else775
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbnz	w8, #5, LBB0_338
LBB0_304:                               ; %else781
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.16b	v17, v15
	shl.2d	v15, v15, #5
	ldr	q2, [sp, #896]                  ; 16-byte Reload
	orr.16b	v2, v15, v2
	add.2d	v2, v30, v2
	tbnz	w8, #6, LBB0_339
LBB0_305:                               ; %else787
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbz	w8, #7, LBB0_307
LBB0_306:                               ; %cond.load789
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x8, v2[1]
	ld1.s	{ v16 }[3], [x8]
LBB0_307:                               ; %else793
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	w8, s0
	ldr	q2, [sp, #560]                  ; 16-byte Reload
	add.2d	v2, v21, v2
	add.2d	v18, v26, v2
	movi.2d	v4, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w8, #0, LBB0_340
; %bb.308:                              ; %else800
                                        ;   in Loop: Header=BB0_298 Depth=1
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_341
LBB0_309:                               ; %else806
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #576]                  ; 16-byte Reload
	add.2d	v6, v24, v6
	add.2d	v18, v20, v6
	tbnz	w8, #2, LBB0_342
LBB0_310:                               ; %else812
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbnz	w8, #3, LBB0_343
LBB0_311:                               ; %else818
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #592]                  ; 16-byte Reload
	add.2d	v6, v14, v6
	add.2d	v18, v22, v6
	tbnz	w8, #4, LBB0_344
LBB0_312:                               ; %else824
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbnz	w8, #5, LBB0_345
LBB0_313:                               ; %else830
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #544]                  ; 16-byte Reload
	add.2d	v6, v15, v6
	add.2d	v18, v30, v6
	tbnz	w8, #6, LBB0_346
LBB0_314:                               ; %else836
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbz	w8, #7, LBB0_316
LBB0_315:                               ; %cond.load838
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v2 }[3], [x8]
LBB0_316:                               ; %else842
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	w8, s0
	ldr	q6, [sp, #496]                  ; 16-byte Reload
	add.2d	v6, v21, v6
	add.2d	v18, v26, v6
	movi.2d	v13, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbnz	w8, #0, LBB0_347
; %bb.317:                              ; %else849
                                        ;   in Loop: Header=BB0_298 Depth=1
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_348
LBB0_318:                               ; %else855
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	add.2d	v6, v24, v6
	add.2d	v18, v20, v6
	tbnz	w8, #2, LBB0_349
LBB0_319:                               ; %else861
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbnz	w8, #3, LBB0_350
LBB0_320:                               ; %else867
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #528]                  ; 16-byte Reload
	add.2d	v6, v14, v6
	add.2d	v18, v22, v6
	tbnz	w8, #4, LBB0_351
LBB0_321:                               ; %else873
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbnz	w8, #5, LBB0_352
LBB0_322:                               ; %else879
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #480]                  ; 16-byte Reload
	add.2d	v6, v15, v6
	add.2d	v18, v30, v6
	tbnz	w8, #6, LBB0_353
LBB0_323:                               ; %else885
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbz	w8, #7, LBB0_325
LBB0_324:                               ; %cond.load887
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v25 }[3], [x8]
LBB0_325:                               ; %else891
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	w8, s0
	ldr	q6, [sp, #432]                  ; 16-byte Reload
	add.2d	v6, v21, v6
	add.2d	v18, v26, v6
	movi.2d	v21, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w8, #0, LBB0_354
; %bb.326:                              ; %else898
                                        ;   in Loop: Header=BB0_298 Depth=1
	and	w8, w8, #0xff
	tbnz	w8, #1, LBB0_355
LBB0_327:                               ; %else904
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #448]                  ; 16-byte Reload
	add.2d	v6, v24, v6
	add.2d	v18, v20, v6
	tbnz	w8, #2, LBB0_356
LBB0_328:                               ; %else910
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbnz	w8, #3, LBB0_357
LBB0_329:                               ; %else916
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #464]                  ; 16-byte Reload
	add.2d	v6, v14, v6
	add.2d	v18, v22, v6
	tbnz	w8, #4, LBB0_358
LBB0_330:                               ; %else922
                                        ;   in Loop: Header=BB0_298 Depth=1
	tbnz	w8, #5, LBB0_359
LBB0_331:                               ; %else928
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldr	q6, [sp, #416]                  ; 16-byte Reload
	add.2d	v6, v15, v6
	add.2d	v18, v30, v6
	tbnz	w8, #6, LBB0_360
LBB0_332:                               ; %else934
                                        ;   in Loop: Header=BB0_298 Depth=1
	ldp	q26, q24, [sp, #608]            ; 32-byte Folded Reload
	ldr	q27, [sp, #864]                 ; 16-byte Reload
	mov.16b	v15, v17
	mov.16b	v30, v19
	mov.16b	v14, v23
	tbz	w8, #7, LBB0_297
	b	LBB0_361
LBB0_333:                               ; %cond.load747
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d2
	ldr	s7, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_300
LBB0_334:                               ; %cond.load753
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v7 }[1], [x9]
	shl.2d	v24, v23, #5
	ldr	q2, [sp, #912]                  ; 16-byte Reload
	orr.16b	v2, v24, v2
	add.2d	v2, v20, v2
	tbz	w8, #2, LBB0_301
LBB0_335:                               ; %cond.load759
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d2
	ld1.s	{ v7 }[2], [x9]
	tbz	w8, #3, LBB0_302
LBB0_336:                               ; %cond.load765
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v7 }[3], [x9]
	shl.2d	v14, v19, #5
	ldr	q2, [sp, #928]                  ; 16-byte Reload
	orr.16b	v2, v14, v2
	add.2d	v2, v22, v2
	tbz	w8, #4, LBB0_303
LBB0_337:                               ; %cond.load771
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d2
	ld1.s	{ v16 }[0], [x9]
	tbz	w8, #5, LBB0_304
LBB0_338:                               ; %cond.load777
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v16 }[1], [x9]
	mov.16b	v17, v15
	shl.2d	v15, v15, #5
	ldr	q2, [sp, #896]                  ; 16-byte Reload
	orr.16b	v2, v15, v2
	add.2d	v2, v30, v2
	tbz	w8, #6, LBB0_305
LBB0_339:                               ; %cond.load783
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d2
	ld1.s	{ v16 }[2], [x9]
	tbnz	w8, #7, LBB0_306
	b	LBB0_307
LBB0_340:                               ; %cond.load796
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ldr	s4, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_309
LBB0_341:                               ; %cond.load802
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v4 }[1], [x9]
	ldr	q6, [sp, #576]                  ; 16-byte Reload
	add.2d	v6, v24, v6
	add.2d	v18, v20, v6
	tbz	w8, #2, LBB0_310
LBB0_342:                               ; %cond.load808
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v4 }[2], [x9]
	tbz	w8, #3, LBB0_311
LBB0_343:                               ; %cond.load814
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v4 }[3], [x9]
	ldr	q6, [sp, #592]                  ; 16-byte Reload
	add.2d	v6, v14, v6
	add.2d	v18, v22, v6
	tbz	w8, #4, LBB0_312
LBB0_344:                               ; %cond.load820
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v2 }[0], [x9]
	tbz	w8, #5, LBB0_313
LBB0_345:                               ; %cond.load826
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v2 }[1], [x9]
	ldr	q6, [sp, #544]                  ; 16-byte Reload
	add.2d	v6, v15, v6
	add.2d	v18, v30, v6
	tbz	w8, #6, LBB0_314
LBB0_346:                               ; %cond.load832
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v2 }[2], [x9]
	tbnz	w8, #7, LBB0_315
	b	LBB0_316
LBB0_347:                               ; %cond.load845
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ldr	s13, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_318
LBB0_348:                               ; %cond.load851
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v13 }[1], [x9]
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	add.2d	v6, v24, v6
	add.2d	v18, v20, v6
	tbz	w8, #2, LBB0_319
LBB0_349:                               ; %cond.load857
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v13 }[2], [x9]
	tbz	w8, #3, LBB0_320
LBB0_350:                               ; %cond.load863
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v13 }[3], [x9]
	ldr	q6, [sp, #528]                  ; 16-byte Reload
	add.2d	v6, v14, v6
	add.2d	v18, v22, v6
	tbz	w8, #4, LBB0_321
LBB0_351:                               ; %cond.load869
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v25 }[0], [x9]
	tbz	w8, #5, LBB0_322
LBB0_352:                               ; %cond.load875
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v25 }[1], [x9]
	ldr	q6, [sp, #480]                  ; 16-byte Reload
	add.2d	v6, v15, v6
	add.2d	v18, v30, v6
	tbz	w8, #6, LBB0_323
LBB0_353:                               ; %cond.load881
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v25 }[2], [x9]
	tbnz	w8, #7, LBB0_324
	b	LBB0_325
LBB0_354:                               ; %cond.load894
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ldr	s21, [x9]
	and	w8, w8, #0xff
	tbz	w8, #1, LBB0_327
LBB0_355:                               ; %cond.load900
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v21 }[1], [x9]
	ldr	q6, [sp, #448]                  ; 16-byte Reload
	add.2d	v6, v24, v6
	add.2d	v18, v20, v6
	tbz	w8, #2, LBB0_328
LBB0_356:                               ; %cond.load906
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v21 }[2], [x9]
	tbz	w8, #3, LBB0_329
LBB0_357:                               ; %cond.load912
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v21 }[3], [x9]
	ldr	q6, [sp, #464]                  ; 16-byte Reload
	add.2d	v6, v14, v6
	add.2d	v18, v22, v6
	tbz	w8, #4, LBB0_330
LBB0_358:                               ; %cond.load918
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v29 }[0], [x9]
	tbz	w8, #5, LBB0_331
LBB0_359:                               ; %cond.load924
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v29 }[1], [x9]
	ldr	q6, [sp, #416]                  ; 16-byte Reload
	add.2d	v6, v15, v6
	add.2d	v18, v30, v6
	tbz	w8, #6, LBB0_332
LBB0_360:                               ; %cond.load930
                                        ;   in Loop: Header=BB0_298 Depth=1
	fmov	x9, d18
	ld1.s	{ v29 }[2], [x9]
	ldp	q26, q24, [sp, #608]            ; 32-byte Folded Reload
	ldr	q27, [sp, #864]                 ; 16-byte Reload
	mov.16b	v15, v17
	mov.16b	v30, v19
	mov.16b	v14, v23
	tbz	w8, #7, LBB0_297
LBB0_361:                               ; %cond.load936
                                        ;   in Loop: Header=BB0_298 Depth=1
	mov.d	x8, v18[1]
	ld1.s	{ v29 }[3], [x8]
	b	LBB0_297
LBB0_362:                               ; %direct.false192
	mov	x11, #0                         ; =0x0
	ldp	q1, q2, [sp, #832]              ; 32-byte Folded Reload
	fadd.4s	v1, v1, v5
	fadd.4s	v2, v2, v3
	ldr	q4, [sp, #352]                  ; 16-byte Reload
	zip1.8b	v3, v4, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v2, v3, v2
	zip2.8b	v3, v4, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v1, v3, v1
	ldr	q4, [sp, #304]                  ; 16-byte Reload
	zip2.8b	v3, v4, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v1, v16, v3
	zip1.8b	v3, v4, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v2, v7, v3
	fadd.4s	v2, v12, v2
	fadd.4s	v1, v28, v1
	fadd.4s	v1, v11, v1
	fadd.4s	v2, v10, v2
	fadd.4s	v2, v9, v2
	fadd.4s	v3, v8, v1
	fmov	w8, s31
	add	x9, sp, #1080
	bfxil	x9, x8, #0, #3
	ldr	q1, [sp, #336]                  ; 16-byte Reload
	str	d1, [sp, #1080]
	ldrb	w9, [x9]
	and	x8, x8, #0x7
	str	q3, [sp, #1520]
	str	q2, [sp, #1504]
	add	x13, sp, #1504
	ldr	s4, [x13, x8, lsl #2]
	tst	w19, w9
	movi.2d	v1, #0000000000000000
	fcsel	s4, s4, s1, ne
	mov.s	w8, v31[1]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w0, w8
	str	q3, [sp, #1488]
	str	q2, [sp, #1472]
	add	x13, sp, #1472
	ldr	s5, [x13, x9, lsl #2]
	tst	w8, #0x1
	mov.s	w8, v31[2]
	fcsel	s5, s5, s1, ne
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w2, w8
	str	q3, [sp, #1456]
	str	q2, [sp, #1440]
	add	x13, sp, #1440
	ldr	s6, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s7, s6, s1, ne
	mov.s	w8, v31[3]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	str	q3, [sp, #1424]
	str	q2, [sp, #1408]
	add	x13, sp, #1408
	ldr	s6, [x13, x9, lsl #2]
	and	w8, w1, w8
	tst	w8, #0x1
	fcsel	s16, s6, s1, ne
	ldr	q19, [sp, #944]                 ; 16-byte Reload
	fmov	w8, s19
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w7, w8
	str	q3, [sp, #1648]
	str	q2, [sp, #1632]
	add	x13, sp, #1632
	ldr	s6, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s6, s6, s1, ne
	mov.s	w8, v19[1]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w6, w8
	str	q3, [sp, #1616]
	str	q2, [sp, #1600]
	add	x13, sp, #1600
	ldr	s17, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s17, s17, s1, ne
	mov.s	w8, v19[2]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w4, w8
	str	q3, [sp, #1584]
	str	q2, [sp, #1568]
	add	x13, sp, #1568
	ldr	s18, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s18, s18, s1, ne
	mov.s	w8, v19[3]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w5, w8
	str	q3, [sp, #1552]
	str	q2, [sp, #1536]
	add	x13, sp, #1536
	ldr	s19, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s19, s19, s1, ne
	mov.s	v6[1], v17[0]
	mov.s	v6[2], v18[0]
	mov.s	v6[3], v19[0]
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v7[0]
	mov.s	v4[3], v16[0]
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v6
	ldr	q7, [sp, #960]                  ; 16-byte Reload
	fmov	w8, s7
	add	x9, sp, #1080
	bfxil	x9, x8, #0, #3
	ldrb	w9, [x9]
	and	x8, x8, #0x7
	str	q3, [sp, #1264]
	str	q2, [sp, #1248]
	add	x13, sp, #1248
	ldr	s4, [x13, x8, lsl #2]
	tst	w19, w9
	fcsel	s4, s4, s1, ne
	mov.s	w8, v7[1]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	str	q3, [sp, #1232]
	str	q2, [sp, #1216]
	add	x13, sp, #1216
	ldr	s5, [x13, x9, lsl #2]
	and	w8, w0, w8
	tst	w8, #0x1
	fcsel	s5, s5, s1, ne
	mov.s	w8, v7[2]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w2, w8
	str	q3, [sp, #1200]
	str	q2, [sp, #1184]
	add	x13, sp, #1184
	ldr	s6, [x13, x9, lsl #2]
	tst	w8, #0x1
	mov.s	w8, v7[3]
	fcsel	s7, s6, s1, ne
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w1, w8
	str	q3, [sp, #1168]
	str	q2, [sp, #1152]
	add	x13, sp, #1152
	ldr	s6, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s16, s6, s1, ne
	ldr	q19, [sp, #976]                 ; 16-byte Reload
	fmov	w8, s19
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w7, w8
	str	q3, [sp, #1392]
	str	q2, [sp, #1376]
	add	x13, sp, #1376
	ldr	s6, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s6, s6, s1, ne
	mov.s	w8, v19[1]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w6, w8
	str	q3, [sp, #1360]
	str	q2, [sp, #1344]
	add	x13, sp, #1344
	ldr	s17, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s17, s17, s1, ne
	mov.s	w8, v19[2]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w4, w8
	str	q3, [sp, #1328]
	str	q2, [sp, #1312]
	add	x13, sp, #1312
	ldr	s18, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s18, s18, s1, ne
	mov.s	w8, v19[3]
	and	x9, x8, #0x7
	add	x13, sp, #1080
	bfxil	x13, x8, #0, #3
	ldrb	w8, [x13]
	and	w8, w5, w8
	str	q3, [sp, #1296]
	str	q2, [sp, #1280]
	add	x13, sp, #1280
	ldr	s19, [x13, x9, lsl #2]
	tst	w8, #0x1
	fcsel	s19, s19, s1, ne
	mov.s	v6[1], v17[0]
	mov.s	v6[2], v18[0]
	mov.s	v6[3], v19[0]
	mov.s	v4[1], v5[0]
	mov.s	v4[2], v7[0]
	add	x8, sp, #1080
	mov.s	v4[3], v16[0]
	fadd.4s	v2, v2, v4
	fadd.4s	v3, v3, v6
	ldr	q4, [sp, #992]                  ; 16-byte Reload
	fmov	w9, s4
	bfxil	x8, x9, #0, #3
	ldrb	w8, [x8]
	and	x9, x9, #0x7
	str	q3, [sp, #1136]
	str	q2, [sp, #1120]
	add	x13, sp, #1120
	ldr	s3, [x13, x9, lsl #2]
	tst	w19, w8
	fcsel	s3, s3, s1, ne
	tst	w17, #0x1
	fadd	s2, s2, s3
	fcsel	s3, s2, s1, ne
	ldr	w8, [sp, #80]                   ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s4, s2, s1, ne
	ldr	w8, [sp, #64]                   ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s5, s2, s1, ne
	tst	w22, #0x1
	fcsel	s6, s2, s1, ne
	tst	w23, #0x1
	fcsel	s7, s2, s1, ne
	tst	w24, #0x1
	fcsel	s16, s2, s1, ne
	tst	w25, #0x1
	fcsel	s17, s2, s1, ne
	tst	w26, #0x1
	mov.s	v3[1], v4[0]
	mov.s	v3[2], v5[0]
	mov.s	v3[3], v6[0]
	mov.s	v7[1], v16[0]
	mov.s	v7[2], v17[0]
	fcsel	s2, s2, s1, ne
	mov.s	v7[3], v2[0]
	str	q7, [sp, #1104]
	str	q3, [sp, #1088]
	and	x8, x12, #0x7
	add	x9, sp, #1088
	ldr	s2, [x9, x8, lsl #2]
	fadd	s1, s2, s1
	dup.4s	v1, v1[0]
	ldr	q2, [sp, #208]                  ; 16-byte Reload
	fmov	x8, d2
	ldp	x14, x13, [sp, #288]            ; 16-byte Folded Reload
	add	x8, x13, x8, lsl #2
	movi.2d	v2, #0000000000000000
	movi.2d	v3, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v5, #0000000000000000
	ldp	q21, q17, [sp, #672]            ; 32-byte Folded Reload
	ldp	q20, q19, [sp, #368]            ; 32-byte Folded Reload
	ldp	q23, q22, [sp, #640]            ; 32-byte Folded Reload
	b	LBB0_364
LBB0_363:                               ; %else1007
                                        ;   in Loop: Header=BB0_364 Depth=1
	add.2d	v3, v3, v20
	add.2d	v4, v4, v24
	add.2d	v5, v5, v19
	add.2d	v2, v2, v26
	fmov	x11, d2
	cmp	x11, #8
	b.ge	LBB0_396
LBB0_364:                               ; %direct.true220
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w9, s0
	shl.2d	v6, v2, #5
	orr.16b	v6, v6, v17
	add.2d	v18, v23, v6
	movi.2d	v16, #0000000000000000
	movi.2d	v7, #0000000000000000
	tbnz	w9, #0, LBB0_380
; %bb.365:                              ; %else947
                                        ;   in Loop: Header=BB0_364 Depth=1
	and	w9, w9, #0xff
	tbnz	w9, #1, LBB0_381
LBB0_366:                               ; %else953
                                        ;   in Loop: Header=BB0_364 Depth=1
	shl.2d	v6, v3, #5
	ldr	q18, [sp, #912]                 ; 16-byte Reload
	orr.16b	v6, v6, v18
	add.2d	v18, v21, v6
	tbnz	w9, #2, LBB0_382
LBB0_367:                               ; %else959
                                        ;   in Loop: Header=BB0_364 Depth=1
	tbnz	w9, #3, LBB0_383
LBB0_368:                               ; %else965
                                        ;   in Loop: Header=BB0_364 Depth=1
	shl.2d	v6, v4, #5
	ldr	q18, [sp, #928]                 ; 16-byte Reload
	orr.16b	v6, v6, v18
	add.2d	v18, v22, v6
	tbnz	w9, #4, LBB0_384
LBB0_369:                               ; %else971
                                        ;   in Loop: Header=BB0_364 Depth=1
	tbnz	w9, #5, LBB0_385
LBB0_370:                               ; %else977
                                        ;   in Loop: Header=BB0_364 Depth=1
	shl.2d	v6, v5, #5
	ldr	q18, [sp, #896]                 ; 16-byte Reload
	orr.16b	v6, v6, v18
	add.2d	v18, v30, v6
	tbnz	w9, #6, LBB0_386
LBB0_371:                               ; %else983
                                        ;   in Loop: Header=BB0_364 Depth=1
	tbnz	w9, #7, LBB0_387
LBB0_372:                               ; %else989
                                        ;   in Loop: Header=BB0_364 Depth=1
	fmov	w12, s0
	fdiv.4s	v16, v16, v1
	add	x9, x8, x11, lsl #5
	tbnz	w12, #0, LBB0_388
LBB0_373:                               ; %else993
                                        ;   in Loop: Header=BB0_364 Depth=1
	and	w11, w12, #0xff
	tbnz	w11, #1, LBB0_389
LBB0_374:                               ; %else995
                                        ;   in Loop: Header=BB0_364 Depth=1
	tbnz	w11, #2, LBB0_390
LBB0_375:                               ; %else997
                                        ;   in Loop: Header=BB0_364 Depth=1
	tbnz	w11, #3, LBB0_391
LBB0_376:                               ; %else999
                                        ;   in Loop: Header=BB0_364 Depth=1
	fdiv.4s	v7, v7, v1
	tbnz	w11, #4, LBB0_392
LBB0_377:                               ; %else1001
                                        ;   in Loop: Header=BB0_364 Depth=1
	tbnz	w11, #5, LBB0_393
LBB0_378:                               ; %else1003
                                        ;   in Loop: Header=BB0_364 Depth=1
	tbnz	w11, #6, LBB0_394
LBB0_379:                               ; %else1005
                                        ;   in Loop: Header=BB0_364 Depth=1
	tbz	w11, #7, LBB0_363
	b	LBB0_395
LBB0_380:                               ; %cond.load943
                                        ;   in Loop: Header=BB0_364 Depth=1
	fmov	x12, d18
	ldr	s16, [x12]
	and	w9, w9, #0xff
	tbz	w9, #1, LBB0_366
LBB0_381:                               ; %cond.load949
                                        ;   in Loop: Header=BB0_364 Depth=1
	mov.d	x12, v18[1]
	ld1.s	{ v16 }[1], [x12]
	shl.2d	v6, v3, #5
	ldr	q18, [sp, #912]                 ; 16-byte Reload
	orr.16b	v6, v6, v18
	add.2d	v18, v21, v6
	tbz	w9, #2, LBB0_367
LBB0_382:                               ; %cond.load955
                                        ;   in Loop: Header=BB0_364 Depth=1
	fmov	x12, d18
	ld1.s	{ v16 }[2], [x12]
	tbz	w9, #3, LBB0_368
LBB0_383:                               ; %cond.load961
                                        ;   in Loop: Header=BB0_364 Depth=1
	mov.d	x12, v18[1]
	ld1.s	{ v16 }[3], [x12]
	shl.2d	v6, v4, #5
	ldr	q18, [sp, #928]                 ; 16-byte Reload
	orr.16b	v6, v6, v18
	add.2d	v18, v22, v6
	tbz	w9, #4, LBB0_369
LBB0_384:                               ; %cond.load967
                                        ;   in Loop: Header=BB0_364 Depth=1
	fmov	x12, d18
	ld1.s	{ v7 }[0], [x12]
	tbz	w9, #5, LBB0_370
LBB0_385:                               ; %cond.load973
                                        ;   in Loop: Header=BB0_364 Depth=1
	mov.d	x12, v18[1]
	ld1.s	{ v7 }[1], [x12]
	shl.2d	v6, v5, #5
	ldr	q18, [sp, #896]                 ; 16-byte Reload
	orr.16b	v6, v6, v18
	add.2d	v18, v30, v6
	tbz	w9, #6, LBB0_371
LBB0_386:                               ; %cond.load979
                                        ;   in Loop: Header=BB0_364 Depth=1
	fmov	x12, d18
	ld1.s	{ v7 }[2], [x12]
	tbz	w9, #7, LBB0_372
LBB0_387:                               ; %cond.load985
                                        ;   in Loop: Header=BB0_364 Depth=1
	mov.d	x9, v18[1]
	ld1.s	{ v7 }[3], [x9]
	fmov	w12, s0
	fdiv.4s	v16, v16, v1
	add	x9, x8, x11, lsl #5
	tbz	w12, #0, LBB0_373
LBB0_388:                               ; %cond.store992
                                        ;   in Loop: Header=BB0_364 Depth=1
	str	s16, [x9]
	and	w11, w12, #0xff
	tbz	w11, #1, LBB0_374
LBB0_389:                               ; %cond.store994
                                        ;   in Loop: Header=BB0_364 Depth=1
	add	x12, x9, #4
	st1.s	{ v16 }[1], [x12]
	tbz	w11, #2, LBB0_375
LBB0_390:                               ; %cond.store996
                                        ;   in Loop: Header=BB0_364 Depth=1
	add	x12, x9, #8
	st1.s	{ v16 }[2], [x12]
	tbz	w11, #3, LBB0_376
LBB0_391:                               ; %cond.store998
                                        ;   in Loop: Header=BB0_364 Depth=1
	add	x12, x9, #12
	st1.s	{ v16 }[3], [x12]
	fdiv.4s	v7, v7, v1
	tbz	w11, #4, LBB0_377
LBB0_392:                               ; %cond.store1000
                                        ;   in Loop: Header=BB0_364 Depth=1
	str	s7, [x9, #16]
	tbz	w11, #5, LBB0_378
LBB0_393:                               ; %cond.store1002
                                        ;   in Loop: Header=BB0_364 Depth=1
	add	x12, x9, #20
	st1.s	{ v7 }[1], [x12]
	tbz	w11, #6, LBB0_379
LBB0_394:                               ; %cond.store1004
                                        ;   in Loop: Header=BB0_364 Depth=1
	add	x12, x9, #24
	st1.s	{ v7 }[2], [x12]
	tbz	w11, #7, LBB0_363
LBB0_395:                               ; %cond.store1006
                                        ;   in Loop: Header=BB0_364 Depth=1
	add	x9, x9, #28
	st1.s	{ v7 }[3], [x9]
	b	LBB0_363
LBB0_396:                               ; %direct.false221
	add	x8, sp, #2712
	add	x8, x8, x10
	ldp	q2, q0, [x8]
	ldr	q4, [sp, #352]                  ; 16-byte Reload
	zip1.8b	v3, v4, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	and.16b	v2, v3, v2
	zip2.8b	v3, v4, v0
	ushll.4s	v3, v3, #0
	ldr	d4, [sp, #328]                  ; 8-byte Reload
	fmov	w8, s4
	fdiv.4s	v2, v2, v1
	ldr	q5, [sp, #272]                  ; 16-byte Reload
	ldp	q4, q6, [sp, #224]              ; 32-byte Folded Reload
	stp	q5, q6, [sp, #1008]
	str	q4, [sp, #1040]
	ldr	q4, [sp, #256]                  ; 16-byte Reload
	str	q4, [sp, #1056]
	and	x9, x14, #0x7
	add	x10, sp, #1008
	ldr	x9, [x10, x9, lsl #3]
	sub	x9, x9, x14
	add	x9, x13, x9, lsl #2
	tbnz	w8, #0, LBB0_411
; %bb.397:                              ; %else1010
	shl.4s	v3, v3, #31
	tbnz	w8, #1, LBB0_412
LBB0_398:                               ; %else1012
	cmlt.4s	v3, v3, #0
	tbnz	w8, #2, LBB0_413
LBB0_399:                               ; %else1014
	and.16b	v0, v3, v0
	tbnz	w8, #3, LBB0_414
LBB0_400:                               ; %else1016
	fdiv.4s	v0, v0, v1
	tbnz	w8, #4, LBB0_415
LBB0_401:                               ; %else1018
	tbnz	w8, #5, LBB0_416
LBB0_402:                               ; %else1020
	tbnz	w8, #6, LBB0_417
LBB0_403:                               ; %else1022
	tbz	w8, #7, LBB0_405
LBB0_404:                               ; %cond.store1023
	add	x8, x9, #28
	st1.s	{ v0 }[3], [x8]
LBB0_405:                               ; %common.ret
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #128
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
	ret
LBB0_406:                               ; %cond.load710
	fmov	x9, d6
	ld1.b	{ v3 }[2], [x9]
	tbz	w8, #3, LBB0_291
LBB0_407:                               ; %cond.load716
	ldr	x9, [sp, #40]                   ; 8-byte Reload
	ld1.b	{ v3 }[3], [x9]
	tbz	w8, #4, LBB0_292
LBB0_408:                               ; %cond.load722
	fmov	x9, d5
	ld1.b	{ v3 }[4], [x9]
	tbz	w8, #5, LBB0_293
LBB0_409:                               ; %cond.load728
	ldr	x9, [sp, #48]                   ; 8-byte Reload
	ld1.b	{ v3 }[5], [x9]
	adrp	x9, lCPI0_20@PAGE
	adrp	x13, lCPI0_21@PAGE
	adrp	x14, lCPI0_22@PAGE
	adrp	x15, lCPI0_23@PAGE
	adrp	x16, lCPI0_24@PAGE
	tbz	w8, #6, LBB0_294
LBB0_410:                               ; %cond.load734
	fmov	x3, d4
	ld1.b	{ v3 }[6], [x3]
	ldr	q4, [x9, lCPI0_20@PAGEOFF]
	ldr	q5, [x13, lCPI0_21@PAGEOFF]
	ldr	q7, [x14, lCPI0_22@PAGEOFF]
	ldr	q16, [x15, lCPI0_23@PAGEOFF]
	ldr	q18, [x16, lCPI0_24@PAGEOFF]
	tbnz	w8, #7, LBB0_295
	b	LBB0_296
LBB0_411:                               ; %cond.store1009
	str	s2, [x9]
	shl.4s	v3, v3, #31
	tbz	w8, #1, LBB0_398
LBB0_412:                               ; %cond.store1011
	add	x10, x9, #4
	st1.s	{ v2 }[1], [x10]
	cmlt.4s	v3, v3, #0
	tbz	w8, #2, LBB0_399
LBB0_413:                               ; %cond.store1013
	add	x10, x9, #8
	st1.s	{ v2 }[2], [x10]
	and.16b	v0, v3, v0
	tbz	w8, #3, LBB0_400
LBB0_414:                               ; %cond.store1015
	add	x10, x9, #12
	st1.s	{ v2 }[3], [x10]
	fdiv.4s	v0, v0, v1
	tbz	w8, #4, LBB0_401
LBB0_415:                               ; %cond.store1017
	str	s0, [x9, #16]
	tbz	w8, #5, LBB0_402
LBB0_416:                               ; %cond.store1019
	add	x10, x9, #20
	st1.s	{ v0 }[1], [x10]
	tbz	w8, #6, LBB0_403
LBB0_417:                               ; %cond.store1021
	add	x10, x9, #24
	st1.s	{ v0 }[2], [x10]
	tbnz	w8, #7, LBB0_404
	b	LBB0_405
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh22, Lloh23
	.loh AdrpAdrp	Lloh20, Lloh22
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpAdrp	Lloh18, Lloh20
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpLdr	Lloh30, Lloh31
	.loh AdrpAdrp	Lloh28, Lloh30
	.loh AdrpLdr	Lloh28, Lloh29
	.loh AdrpAdrp	Lloh26, Lloh28
	.loh AdrpLdr	Lloh26, Lloh27
	.loh AdrpAdrp	Lloh24, Lloh26
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh32, Lloh33
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

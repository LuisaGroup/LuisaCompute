	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_90
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d13, d12, [sp, #-144]!          ; 16-byte Folded Spill
	stp	d11, d10, [sp, #16]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #48]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #128]            ; 16-byte Folded Spill
	sub	sp, sp, #1, lsl #12             ; =4096
	sub	sp, sp, #96
	mov	w8, #0                          ; =0x0
	add	x9, sp, #2112
	ldp	w10, w11, [x2, #44]
	ldp	w6, w7, [x2]
Lloh0:
	adrp	x13, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x13, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x13, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x13, lCPI0_1@PAGEOFF]
	movi.4s	v2, #65
	movi.2s	v3, #65
	add	x13, sp, #32
	mov	w14, #1115815936                ; =0x42820000
	mov	w15, #50604                     ; =0xc5ac
	movk	w15, #14119, lsl #16
	adrp	x16, lCPI0_2@PAGE
	ldp	w19, w17, [x2, #8]
	str	x2, [sp, #16]                   ; 8-byte Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w12, w5, #1
	cmp	w12, w10
	cset	w12, eq
	csinc	w6, wzr, w5, eq
	cinc	w2, w4, eq
	cmp	w2, w11
	cset	w7, eq
	ands	w12, w12, w7
	csel	w7, wzr, w2, ne
	add	w19, w1, w12
	add	w8, w8, #1
	cmp	w8, w3
	b.eq	LBB0_89
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_38 Depth 2
                                        ;       Child Loop BB0_39 Depth 3
                                        ;       Child Loop BB0_41 Depth 3
                                        ;       Child Loop BB0_43 Depth 3
                                        ;       Child Loop BB0_45 Depth 3
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_68 Depth 2
                                        ;     Child Loop BB0_70 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
	mov	x1, x19
	mov	x4, x7
	mov	x5, x6
	ubfiz	x6, x6, #5, #32
	cmp	x6, x17
	csel	x7, x6, xzr, ls
	subs	x19, x17, x7
	cmp	x19, #32
	mov	w12, #32                        ; =0x20
	csel	x19, x19, x12, lo
	cmp	x17, x7
	ccmp	x6, x17, #2, hi
	csel	x7, x19, xzr, ls
	cmp	x7, #32
	b.lo	LBB0_36
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x20, #0                         ; =0x0
	ldr	x21, [x0]
	ldr	x6, [x0, #16]
	ldr	x19, [x0, #48]
	lsl	w7, w5, #5
	dup.4s	v4, w7
	orr.16b	v5, v4, v0
	orr.16b	v4, v4, v1
	umull2.2d	v16, v5, v2
	umull2.2d	v17, v4, v2
	umull.2d	v18, v5, v3
	umull.2d	v19, v4, v3
	dup.2d	v4, x21
LBB0_5:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v5, x20
	add.2d	v6, v5, v16
	add.2d	v7, v5, v18
	add.2d	v20, v5, v17
	add.2d	v5, v5, v19
	shl.2d	v5, v5, #2
	shl.2d	v20, v20, #2
	shl.2d	v7, v7, #2
	shl.2d	v6, v6, #2
	add.2d	v6, v4, v6
	add.2d	v7, v4, v7
	add.2d	v20, v4, v20
	add.2d	v5, v4, v5
	mov.d	x21, v5[1]
	fmov	x22, d5
	mov.d	x23, v20[1]
	fmov	x24, d20
	mov.d	x25, v7[1]
	fmov	x26, d7
	mov.d	x27, v6[1]
	ldr	s5, [x26]
	ld1.s	{ v5 }[1], [x25]
	fmov	x25, d6
	ld1.s	{ v5 }[2], [x25]
	ld1.s	{ v5 }[3], [x27]
	ldr	s6, [x22]
	ld1.s	{ v6 }[1], [x21]
	ld1.s	{ v6 }[2], [x24]
	ld1.s	{ v6 }[3], [x23]
	add	x21, x9, x20, lsl #5
	stp	q6, q5, [x21]
	add	x20, x20, #1
	cmp	x20, #65
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q6, q5, [x9]
	fmul.4s	v5, v5, v5
	fmul.4s	v6, v6, v6
	ldp	q7, q20, [x9, #32]
	fmul.4s	v20, v20, v20
	fmul.4s	v7, v7, v7
	ldp	q22, q21, [x9, #64]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	ldp	q23, q24, [x9, #96]
	fmul.4s	v24, v24, v24
	fmul.4s	v23, v23, v23
	add	x20, x9, #224
	mov	w21, #4                         ; =0x4
LBB0_7:                                 ; %direct.true46.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q26, q25, [x20, #-96]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v5, v5, v25
	fadd.4s	v6, v6, v26
	ldp	q26, q25, [x20, #-64]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v25
	fadd.4s	v7, v7, v26
	ldp	q26, q25, [x20, #-32]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v21, v21, v25
	fadd.4s	v22, v22, v26
	ldp	q26, q25, [x20], #128
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v24, v24, v25
	fadd.4s	v23, v23, v26
	cmp	x21, #60
	add	x21, x21, #4
	b.lo	LBB0_7
; %bb.8:                                ; %direct.false47.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x20, #0                         ; =0x0
	ldr	q26, [x9, #2064]
	ldr	q25, [x9, #2048]
LBB0_9:                                 ; %direct.true97.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x21, x6, x20, lsl #2
	ld1r.4s	{ v27 }, [x21]
	add	x21, x13, x20, lsl #5
	stp	q27, q27, [x21]
	add	x20, x20, #1
	cmp	x20, #65
	b.ne	LBB0_9
; %bb.10:                               ; %direct.false98.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x20, #0                         ; =0x0
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v6, v6, v25
	fadd.4s	v5, v5, v26
	fadd.4s	v5, v20, v5
	fadd.4s	v6, v7, v6
	fadd.4s	v6, v22, v6
	fadd.4s	v5, v21, v5
	fadd.4s	v5, v24, v5
	fadd.4s	v7, v23, v6
	dup.4s	v6, w14
	fdiv.4s	v20, v7, v6
	fdiv.4s	v5, v5, v6
	dup.4s	v7, w15
	fadd.4s	v5, v5, v7
	fadd.4s	v20, v20, v7
	fsqrt.4s	v20, v20
	fsqrt.4s	v21, v5
LBB0_11:                                ; %direct.true112.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v5, x20
	add.2d	v22, v5, v16
	add.2d	v23, v5, v18
	add.2d	v24, v5, v17
	add.2d	v5, v5, v19
	lsl	x21, x20, #5
	add	x22, x9, x21
	ldp	q26, q25, [x22]
	fdiv.4s	v26, v26, v20
	fdiv.4s	v25, v25, v21
	add	x21, x13, x21
	ldp	q27, q28, [x21]
	fmul.4s	v25, v25, v28
	fmul.4s	v26, v26, v27
	shl.2d	v27, v5, #2
	shl.2d	v24, v24, #2
	shl.2d	v23, v23, #2
	shl.2d	v22, v22, #2
	dup.2d	v5, x19
	add.2d	v22, v5, v22
	add.2d	v27, v5, v27
	mov.d	x21, v27[1]
	fmov	x22, d27
	str	s26, [x22]
	st1.s	{ v26 }[1], [x21]
	add.2d	v24, v5, v24
	mov.d	x21, v24[1]
	fmov	x22, d24
	st1.s	{ v26 }[2], [x22]
	add.2d	v23, v5, v23
	st1.s	{ v26 }[3], [x21]
	mov.d	x21, v23[1]
	fmov	x22, d23
	str	s25, [x22]
	st1.s	{ v25 }[1], [x21]
	mov.d	x21, v22[1]
	fmov	x22, d22
	st1.s	{ v25 }[2], [x22]
	st1.s	{ v25 }[3], [x21]
	add	x20, x20, #1
	cmp	x20, #65
	b.ne	LBB0_11
; %bb.12:                               ; %llm_rows.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	orr	w20, w7, #0x8
	dup.4s	v16, w20
	orr.16b	v18, v16, v0
	orr.16b	v19, v16, v1
	umull2.2d	v16, v18, v2
	umull2.2d	v17, v19, v2
	umull.2d	v18, v18, v3
	umull.2d	v19, v19, v3
LBB0_13:                                ; %direct.true.i6.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v20, x19
	add.2d	v21, v20, v16
	add.2d	v22, v20, v18
	add.2d	v23, v20, v17
	add.2d	v20, v20, v19
	shl.2d	v20, v20, #2
	shl.2d	v23, v23, #2
	shl.2d	v22, v22, #2
	shl.2d	v21, v21, #2
	add.2d	v21, v4, v21
	add.2d	v22, v4, v22
	add.2d	v23, v4, v23
	add.2d	v20, v4, v20
	mov.d	x20, v20[1]
	fmov	x21, d20
	mov.d	x22, v23[1]
	fmov	x23, d23
	mov.d	x24, v22[1]
	fmov	x25, d22
	mov.d	x26, v21[1]
	ldr	s20, [x25]
	ld1.s	{ v20 }[1], [x24]
	fmov	x24, d21
	ld1.s	{ v20 }[2], [x24]
	ld1.s	{ v20 }[3], [x26]
	ldr	s21, [x21]
	ld1.s	{ v21 }[1], [x20]
	ld1.s	{ v21 }[2], [x23]
	ld1.s	{ v21 }[3], [x22]
	add	x20, x9, x19, lsl #5
	stp	q21, q20, [x20]
	add	x19, x19, #1
	cmp	x19, #65
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false.i13.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q21, q20, [x9]
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	ldp	q22, q23, [x9, #32]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
	ldp	q25, q24, [x9, #64]
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v25, v25
	ldp	q26, q27, [x9, #96]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	add	x19, x9, #224
	mov	w20, #4                         ; =0x4
LBB0_15:                                ; %direct.true46.i21.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q29, q28, [x19, #-96]
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v20, v20, v28
	fadd.4s	v21, v21, v29
	ldp	q29, q28, [x19, #-64]
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v23, v23, v28
	fadd.4s	v22, v22, v29
	ldp	q29, q28, [x19, #-32]
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v24, v24, v28
	fadd.4s	v25, v25, v29
	ldp	q29, q28, [x19], #128
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v27, v27, v28
	fadd.4s	v26, v26, v29
	cmp	x20, #60
	add	x20, x20, #4
	b.lo	LBB0_15
; %bb.16:                               ; %direct.false47.i35.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	ldr	q29, [x9, #2064]
	ldr	q28, [x9, #2048]
LBB0_17:                                ; %direct.true97.i38.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x20, x6, x19, lsl #2
	ld1r.4s	{ v30 }, [x20]
	add	x20, x13, x19, lsl #5
	stp	q30, q30, [x20]
	add	x19, x19, #1
	cmp	x19, #65
	b.ne	LBB0_17
; %bb.18:                               ; %direct.false98.i45.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v21, v21, v28
	fadd.4s	v20, v20, v29
	fadd.4s	v20, v23, v20
	fadd.4s	v21, v22, v21
	fadd.4s	v21, v25, v21
	fadd.4s	v20, v24, v20
	fadd.4s	v20, v27, v20
	fadd.4s	v21, v26, v21
	fdiv.4s	v21, v21, v6
	fdiv.4s	v20, v20, v6
	fadd.4s	v22, v20, v7
	fadd.4s	v20, v21, v7
	fsqrt.4s	v20, v20
	fsqrt.4s	v21, v22
LBB0_19:                                ; %direct.true112.i46.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v22, x19
	add.2d	v23, v22, v16
	add.2d	v24, v22, v18
	add.2d	v25, v22, v17
	add.2d	v22, v22, v19
	lsl	x20, x19, #5
	add	x21, x9, x20
	ldp	q27, q26, [x21]
	fdiv.4s	v27, v27, v20
	fdiv.4s	v26, v26, v21
	add	x20, x13, x20
	ldp	q28, q29, [x20]
	fmul.4s	v26, v26, v29
	fmul.4s	v27, v27, v28
	shl.2d	v22, v22, #2
	shl.2d	v25, v25, #2
	shl.2d	v24, v24, #2
	shl.2d	v23, v23, #2
	add.2d	v23, v5, v23
	add.2d	v22, v5, v22
	mov.d	x20, v22[1]
	fmov	x21, d22
	str	s27, [x21]
	st1.s	{ v27 }[1], [x20]
	add.2d	v22, v5, v25
	mov.d	x20, v22[1]
	fmov	x21, d22
	st1.s	{ v27 }[2], [x21]
	add.2d	v22, v5, v24
	st1.s	{ v27 }[3], [x20]
	mov.d	x20, v22[1]
	fmov	x21, d22
	str	s26, [x21]
	st1.s	{ v26 }[1], [x20]
	mov.d	x20, v23[1]
	fmov	x21, d23
	st1.s	{ v26 }[2], [x21]
	st1.s	{ v26 }[3], [x20]
	add	x19, x19, #1
	cmp	x19, #65
	b.ne	LBB0_19
; %bb.20:                               ; %llm_rows.exit55.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	orr	w20, w7, #0x10
	dup.4s	v16, w20
	orr.16b	v18, v16, v0
	orr.16b	v19, v16, v1
	umull2.2d	v16, v18, v2
	umull2.2d	v17, v19, v2
	umull.2d	v18, v18, v3
	umull.2d	v19, v19, v3
LBB0_21:                                ; %direct.true.i59.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v20, x19
	add.2d	v21, v20, v16
	add.2d	v22, v20, v18
	add.2d	v23, v20, v17
	add.2d	v20, v20, v19
	shl.2d	v20, v20, #2
	shl.2d	v23, v23, #2
	shl.2d	v22, v22, #2
	shl.2d	v21, v21, #2
	add.2d	v21, v4, v21
	add.2d	v22, v4, v22
	add.2d	v23, v4, v23
	add.2d	v20, v4, v20
	mov.d	x20, v20[1]
	fmov	x21, d20
	mov.d	x22, v23[1]
	fmov	x23, d23
	mov.d	x24, v22[1]
	fmov	x25, d22
	mov.d	x26, v21[1]
	ldr	s20, [x25]
	ld1.s	{ v20 }[1], [x24]
	fmov	x24, d21
	ld1.s	{ v20 }[2], [x24]
	ld1.s	{ v20 }[3], [x26]
	ldr	s21, [x21]
	ld1.s	{ v21 }[1], [x20]
	ld1.s	{ v21 }[2], [x23]
	ld1.s	{ v21 }[3], [x22]
	add	x20, x9, x19, lsl #5
	stp	q21, q20, [x20]
	add	x19, x19, #1
	cmp	x19, #65
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false.i66.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q21, q20, [x9]
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	ldp	q22, q23, [x9, #32]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
	ldp	q25, q24, [x9, #64]
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v25, v25
	ldp	q26, q27, [x9, #96]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	add	x19, x9, #224
	mov	w20, #4                         ; =0x4
LBB0_23:                                ; %direct.true46.i74.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q29, q28, [x19, #-96]
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v20, v20, v28
	fadd.4s	v21, v21, v29
	ldp	q29, q28, [x19, #-64]
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v23, v23, v28
	fadd.4s	v22, v22, v29
	ldp	q29, q28, [x19, #-32]
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v24, v24, v28
	fadd.4s	v25, v25, v29
	ldp	q29, q28, [x19], #128
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v27, v27, v28
	fadd.4s	v26, v26, v29
	cmp	x20, #60
	add	x20, x20, #4
	b.lo	LBB0_23
; %bb.24:                               ; %direct.false47.i88.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	ldr	q29, [x9, #2064]
	ldr	q28, [x9, #2048]
LBB0_25:                                ; %direct.true97.i91.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x20, x6, x19, lsl #2
	ld1r.4s	{ v30 }, [x20]
	add	x20, x13, x19, lsl #5
	stp	q30, q30, [x20]
	add	x19, x19, #1
	cmp	x19, #65
	b.ne	LBB0_25
; %bb.26:                               ; %direct.false98.i98.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	fmul.4s	v29, v29, v29
	fmul.4s	v28, v28, v28
	fadd.4s	v21, v21, v28
	fadd.4s	v20, v20, v29
	fadd.4s	v20, v23, v20
	fadd.4s	v21, v22, v21
	fadd.4s	v21, v25, v21
	fadd.4s	v20, v24, v20
	fadd.4s	v20, v27, v20
	fadd.4s	v21, v26, v21
	fdiv.4s	v21, v21, v6
	fdiv.4s	v20, v20, v6
	fadd.4s	v22, v20, v7
	fadd.4s	v20, v21, v7
	fsqrt.4s	v20, v20
	fsqrt.4s	v21, v22
LBB0_27:                                ; %direct.true112.i99.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v22, x19
	add.2d	v23, v22, v16
	add.2d	v24, v22, v18
	add.2d	v25, v22, v17
	add.2d	v22, v22, v19
	lsl	x20, x19, #5
	add	x21, x9, x20
	ldp	q27, q26, [x21]
	fdiv.4s	v27, v27, v20
	fdiv.4s	v26, v26, v21
	add	x20, x13, x20
	ldp	q28, q29, [x20]
	fmul.4s	v26, v26, v29
	fmul.4s	v27, v27, v28
	shl.2d	v22, v22, #2
	shl.2d	v25, v25, #2
	shl.2d	v24, v24, #2
	shl.2d	v23, v23, #2
	add.2d	v23, v5, v23
	add.2d	v22, v5, v22
	mov.d	x20, v22[1]
	fmov	x21, d22
	str	s27, [x21]
	st1.s	{ v27 }[1], [x20]
	add.2d	v22, v5, v25
	mov.d	x20, v22[1]
	fmov	x21, d22
	st1.s	{ v27 }[2], [x21]
	add.2d	v22, v5, v24
	st1.s	{ v27 }[3], [x20]
	mov.d	x20, v22[1]
	fmov	x21, d22
	str	s26, [x21]
	st1.s	{ v26 }[1], [x20]
	mov.d	x20, v23[1]
	fmov	x21, d23
	st1.s	{ v26 }[2], [x21]
	st1.s	{ v26 }[3], [x20]
	add	x19, x19, #1
	cmp	x19, #65
	b.ne	LBB0_27
; %bb.28:                               ; %llm_rows.exit108.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	orr	w7, w7, #0x18
	dup.4s	v16, w7
	orr.16b	v18, v16, v0
	orr.16b	v19, v16, v1
	umull2.2d	v16, v18, v2
	umull2.2d	v17, v19, v2
	umull.2d	v18, v18, v3
	umull.2d	v19, v19, v3
LBB0_29:                                ; %direct.true.i112.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v20, x19
	add.2d	v21, v20, v16
	add.2d	v22, v20, v18
	add.2d	v23, v20, v17
	add.2d	v20, v20, v19
	shl.2d	v20, v20, #2
	shl.2d	v23, v23, #2
	shl.2d	v22, v22, #2
	shl.2d	v21, v21, #2
	add.2d	v21, v4, v21
	add.2d	v22, v4, v22
	add.2d	v23, v4, v23
	add.2d	v20, v4, v20
	mov.d	x7, v20[1]
	fmov	x20, d20
	mov.d	x21, v23[1]
	fmov	x22, d23
	mov.d	x23, v22[1]
	fmov	x24, d22
	mov.d	x25, v21[1]
	ldr	s20, [x24]
	ld1.s	{ v20 }[1], [x23]
	fmov	x23, d21
	ld1.s	{ v20 }[2], [x23]
	ld1.s	{ v20 }[3], [x25]
	ldr	s21, [x20]
	ld1.s	{ v21 }[1], [x7]
	ld1.s	{ v21 }[2], [x22]
	ld1.s	{ v21 }[3], [x21]
	add	x7, x9, x19, lsl #5
	stp	q21, q20, [x7]
	add	x19, x19, #1
	cmp	x19, #65
	b.ne	LBB0_29
; %bb.30:                               ; %direct.false.i119.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q20, q4, [x9]
	fmul.4s	v4, v4, v4
	fmul.4s	v20, v20, v20
	ldp	q21, q22, [x9, #32]
	fmul.4s	v22, v22, v22
	fmul.4s	v21, v21, v21
	ldp	q24, q23, [x9, #64]
	fmul.4s	v23, v23, v23
	fmul.4s	v24, v24, v24
	ldp	q25, q26, [x9, #96]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	add	x7, x9, #224
	mov	w19, #4                         ; =0x4
LBB0_31:                                ; %direct.true46.i127.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q28, q27, [x7, #-96]
	fmul.4s	v28, v28, v28
	fmul.4s	v27, v27, v27
	fadd.4s	v4, v4, v27
	fadd.4s	v20, v20, v28
	ldp	q28, q27, [x7, #-64]
	fmul.4s	v28, v28, v28
	fmul.4s	v27, v27, v27
	fadd.4s	v22, v22, v27
	fadd.4s	v21, v21, v28
	ldp	q28, q27, [x7, #-32]
	fmul.4s	v28, v28, v28
	fmul.4s	v27, v27, v27
	fadd.4s	v23, v23, v27
	fadd.4s	v24, v24, v28
	ldp	q28, q27, [x7], #128
	fmul.4s	v28, v28, v28
	fmul.4s	v27, v27, v27
	fadd.4s	v26, v26, v27
	fadd.4s	v25, v25, v28
	cmp	x19, #60
	add	x19, x19, #4
	b.lo	LBB0_31
; %bb.32:                               ; %direct.false47.i141.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	ldr	q28, [x9, #2064]
	ldr	q27, [x9, #2048]
LBB0_33:                                ; %direct.true97.i144.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x19, x6, x7, lsl #2
	ld1r.4s	{ v29 }, [x19]
	add	x19, x13, x7, lsl #5
	stp	q29, q29, [x19]
	add	x7, x7, #1
	cmp	x7, #65
	b.ne	LBB0_33
; %bb.34:                               ; %direct.false98.i151.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x6, #0                          ; =0x0
	fmul.4s	v28, v28, v28
	fmul.4s	v27, v27, v27
	fadd.4s	v20, v20, v27
	fadd.4s	v4, v4, v28
	fadd.4s	v4, v22, v4
	fadd.4s	v20, v21, v20
	fadd.4s	v20, v24, v20
	fadd.4s	v4, v23, v4
	fadd.4s	v4, v26, v4
	fadd.4s	v20, v25, v20
	fdiv.4s	v20, v20, v6
	fdiv.4s	v4, v4, v6
	fadd.4s	v6, v4, v7
	fadd.4s	v4, v20, v7
	fsqrt.4s	v4, v4
	fsqrt.4s	v6, v6
LBB0_35:                                ; %direct.true112.i152.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v7, x6
	add.2d	v20, v7, v16
	add.2d	v21, v7, v18
	add.2d	v22, v7, v17
	add.2d	v7, v7, v19
	lsl	x7, x6, #5
	add	x19, x9, x7
	ldp	q24, q23, [x19]
	fdiv.4s	v24, v24, v4
	fdiv.4s	v23, v23, v6
	add	x7, x13, x7
	ldp	q25, q26, [x7]
	fmul.4s	v23, v23, v26
	fmul.4s	v24, v24, v25
	shl.2d	v7, v7, #2
	shl.2d	v22, v22, #2
	shl.2d	v21, v21, #2
	shl.2d	v20, v20, #2
	add.2d	v20, v5, v20
	add.2d	v7, v5, v7
	mov.d	x7, v7[1]
	fmov	x19, d7
	str	s24, [x19]
	st1.s	{ v24 }[1], [x7]
	add.2d	v7, v5, v22
	mov.d	x7, v7[1]
	fmov	x19, d7
	st1.s	{ v24 }[2], [x19]
	add.2d	v7, v5, v21
	st1.s	{ v24 }[3], [x7]
	mov.d	x7, v7[1]
	fmov	x19, d7
	str	s23, [x19]
	st1.s	{ v23 }[1], [x7]
	mov.d	x7, v20[1]
	fmov	x19, d20
	st1.s	{ v23 }[2], [x19]
	st1.s	{ v23 }[3], [x7]
	add	x6, x6, #1
	cmp	x6, #65
	b.ne	LBB0_35
	b	LBB0_2
LBB0_36:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x6, x7, #3
	dup.4s	v5, w14
	dup.4s	v4, w15
	cbz	x6, LBB0_47
; %bb.37:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w19, #0                         ; =0x0
	ldr	x20, [x0]
	ldr	x21, [x0, #16]
	lsl	w22, w5, #5
	ldr	x23, [x0, #48]
LBB0_38:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_39 Depth 3
                                        ;       Child Loop BB0_41 Depth 3
                                        ;       Child Loop BB0_43 Depth 3
                                        ;       Child Loop BB0_45 Depth 3
	mov	x24, #0                         ; =0x0
	add	w25, w22, w19, lsl #3
	dup.4s	v6, w25
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	umull2.2d	v6, v16, v2
	umull2.2d	v7, v17, v2
	umull.2d	v16, v16, v3
	umull.2d	v17, v17, v3
LBB0_39:                                ; %direct.true.i165.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v18, x24
	add.2d	v19, v18, v6
	add.2d	v20, v18, v16
	add.2d	v21, v18, v7
	add.2d	v18, v18, v17
	shl.2d	v18, v18, #2
	shl.2d	v21, v21, #2
	shl.2d	v20, v20, #2
	shl.2d	v19, v19, #2
	dup.2d	v22, x20
	add.2d	v19, v22, v19
	add.2d	v20, v22, v20
	add.2d	v21, v22, v21
	add.2d	v18, v22, v18
	mov.d	x25, v18[1]
	fmov	x26, d18
	mov.d	x27, v21[1]
	fmov	x28, d21
	mov.d	x30, v20[1]
	fmov	x12, d20
	mov.d	x2, v19[1]
	ldr	s18, [x12]
	ld1.s	{ v18 }[1], [x30]
	fmov	x12, d19
	ld1.s	{ v18 }[2], [x12]
	ld1.s	{ v18 }[3], [x2]
	ldr	s19, [x26]
	ld1.s	{ v19 }[1], [x25]
	ld1.s	{ v19 }[2], [x28]
	ld1.s	{ v19 }[3], [x27]
	add	x12, x9, x24, lsl #5
	stp	q19, q18, [x12]
	add	x24, x24, #1
	cmp	x24, #65
	b.ne	LBB0_39
; %bb.40:                               ; %direct.false.i172.i
                                        ;   in Loop: Header=BB0_38 Depth=2
	ldp	q19, q18, [x9]
	fmul.4s	v18, v18, v18
	fmul.4s	v19, v19, v19
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	add	x24, x9, #224
	mov	w25, #4                         ; =0x4
LBB0_41:                                ; %direct.true46.i180.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q27, q26, [x24, #-96]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v18, v18, v26
	fadd.4s	v19, v19, v27
	ldp	q27, q26, [x24, #-64]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x24, #-32]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x24], #128
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	cmp	x25, #60
	add	x25, x25, #4
	b.lo	LBB0_41
; %bb.42:                               ; %direct.false47.i194.i
                                        ;   in Loop: Header=BB0_38 Depth=2
	mov	x24, #0                         ; =0x0
	ldr	q27, [x9, #2064]
	ldr	q26, [x9, #2048]
LBB0_43:                                ; %direct.true97.i197.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x12, x21, x24, lsl #2
	ld1r.4s	{ v28 }, [x12]
	add	x12, x13, x24, lsl #5
	stp	q28, q28, [x12]
	add	x24, x24, #1
	cmp	x24, #65
	b.ne	LBB0_43
; %bb.44:                               ; %direct.false98.i204.i
                                        ;   in Loop: Header=BB0_38 Depth=2
	mov	x24, #0                         ; =0x0
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	fadd.4s	v18, v21, v18
	fadd.4s	v19, v20, v19
	fadd.4s	v19, v23, v19
	fadd.4s	v18, v22, v18
	fadd.4s	v18, v25, v18
	fadd.4s	v19, v24, v19
	fdiv.4s	v19, v19, v5
	fdiv.4s	v18, v18, v5
	fadd.4s	v20, v18, v4
	fadd.4s	v18, v19, v4
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v20
LBB0_45:                                ; %direct.true112.i205.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v20, x24
	add.2d	v21, v20, v6
	add.2d	v22, v20, v16
	add.2d	v23, v20, v7
	add.2d	v20, v20, v17
	lsl	x12, x24, #5
	add	x2, x9, x12
	ldp	q25, q24, [x2]
	fdiv.4s	v25, v25, v18
	fdiv.4s	v24, v24, v19
	add	x12, x13, x12
	ldp	q26, q27, [x12]
	fmul.4s	v24, v24, v27
	fmul.4s	v25, v25, v26
	shl.2d	v20, v20, #2
	shl.2d	v23, v23, #2
	shl.2d	v22, v22, #2
	shl.2d	v21, v21, #2
	dup.2d	v26, x23
	add.2d	v21, v26, v21
	add.2d	v20, v26, v20
	mov.d	x12, v20[1]
	fmov	x2, d20
	str	s25, [x2]
	st1.s	{ v25 }[1], [x12]
	add.2d	v20, v26, v23
	mov.d	x12, v20[1]
	fmov	x2, d20
	st1.s	{ v25 }[2], [x2]
	add.2d	v20, v26, v22
	st1.s	{ v25 }[3], [x12]
	mov.d	x12, v20[1]
	fmov	x2, d20
	str	s24, [x2]
	st1.s	{ v24 }[1], [x12]
	mov.d	x12, v21[1]
	fmov	x2, d21
	st1.s	{ v24 }[2], [x2]
	st1.s	{ v24 }[3], [x12]
	add	x24, x24, #1
	cmp	x24, #65
	b.ne	LBB0_45
; %bb.46:                               ; %llm_rows.exit214.i
                                        ;   in Loop: Header=BB0_38 Depth=2
	add	w19, w19, #1
	cmp	w19, w6
	b.ne	LBB0_38
LBB0_47:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w7, w7, #0x7
	cbz	w7, LBB0_2
; %bb.48:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v7, w7
	cmhi.4s	v6, v7, v0
	cmhi.4s	v7, v7, v1
	uzp1.8h	v21, v7, v6
	umaxv.8h	h16, v21
	fmov	w12, s16
	tbz	w12, #0, LBB0_2
; %bb.49:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	ldr	x20, [x0]
	ldr	x7, [x0, #16]
	lsl	w12, w6, #3
	orr	w12, w12, w5, lsl #5
	dup.4s	v16, w12
	ldr	x6, [x0, #48]
	orr.16b	v17, v16, v1
	orr.16b	v16, v16, v0
	and.16b	v18, v6, v16
	and.16b	v19, v7, v17
	umull2.2d	v16, v18, v2
	umull2.2d	v17, v19, v2
	umull.2d	v18, v18, v3
	umull.2d	v19, v19, v3
	b	LBB0_51
LBB0_50:                                ; %else414
                                        ;   in Loop: Header=BB0_51 Depth=2
	add	x12, x9, x19, lsl #5
	ldp	q24, q25, [x12]
	bif.16b	v23, v25, v6
	bif.16b	v22, v24, v7
	stp	q22, q23, [x12]
	add	x19, x19, #1
	cmp	x19, #65
	b.eq	LBB0_67
LBB0_51:                                ; %direct.true.i218.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q20, [x16, lCPI0_2@PAGEOFF]
	and.16b	v20, v21, v20
	addv.8h	h20, v20
	fmov	w21, s20
	dup.2d	v24, x19
	add.2d	v22, v24, v19
	shl.2d	v22, v22, #2
	dup.2d	v25, x20
	add.2d	v26, v25, v22
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w21, #0, LBB0_59
; %bb.52:                               ; %else
                                        ;   in Loop: Header=BB0_51 Depth=2
	and	w21, w21, #0xff
	tbnz	w21, #1, LBB0_60
LBB0_53:                                ; %else378
                                        ;   in Loop: Header=BB0_51 Depth=2
	add.2d	v26, v24, v17
	shl.2d	v26, v26, #2
	add.2d	v26, v25, v26
	tbnz	w21, #2, LBB0_61
LBB0_54:                                ; %else384
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbnz	w21, #3, LBB0_62
LBB0_55:                                ; %else390
                                        ;   in Loop: Header=BB0_51 Depth=2
	add.2d	v26, v24, v18
	shl.2d	v26, v26, #2
	add.2d	v26, v25, v26
	tbnz	w21, #4, LBB0_63
LBB0_56:                                ; %else396
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbnz	w21, #5, LBB0_64
LBB0_57:                                ; %else402
                                        ;   in Loop: Header=BB0_51 Depth=2
	add.2d	v24, v24, v16
	shl.2d	v24, v24, #2
	add.2d	v24, v25, v24
	tbnz	w21, #6, LBB0_65
LBB0_58:                                ; %else408
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbz	w21, #7, LBB0_50
	b	LBB0_66
LBB0_59:                                ; %cond.load
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x12, d26
	ldr	s22, [x12]
	and	w21, w21, #0xff
	tbz	w21, #1, LBB0_53
LBB0_60:                                ; %cond.load374
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x12, v26[1]
	ld1.s	{ v22 }[1], [x12]
	add.2d	v26, v24, v17
	shl.2d	v26, v26, #2
	add.2d	v26, v25, v26
	tbz	w21, #2, LBB0_54
LBB0_61:                                ; %cond.load380
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x12, d26
	ld1.s	{ v22 }[2], [x12]
	tbz	w21, #3, LBB0_55
LBB0_62:                                ; %cond.load386
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x12, v26[1]
	ld1.s	{ v22 }[3], [x12]
	add.2d	v26, v24, v18
	shl.2d	v26, v26, #2
	add.2d	v26, v25, v26
	tbz	w21, #4, LBB0_56
LBB0_63:                                ; %cond.load392
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x12, d26
	ld1.s	{ v23 }[0], [x12]
	tbz	w21, #5, LBB0_57
LBB0_64:                                ; %cond.load398
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x12, v26[1]
	ld1.s	{ v23 }[1], [x12]
	add.2d	v24, v24, v16
	shl.2d	v24, v24, #2
	add.2d	v24, v25, v24
	tbz	w21, #6, LBB0_58
LBB0_65:                                ; %cond.load404
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x12, d24
	ld1.s	{ v23 }[2], [x12]
	tbz	w21, #7, LBB0_50
LBB0_66:                                ; %cond.load410
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v23 }[3], [x12]
	b	LBB0_50
LBB0_67:                                ; %direct.false.i225.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q22, q21, [x9]
	fmul.4s	v23, v22, v22
	fmul.4s	v21, v21, v21
	ldp	q24, q22, [x9, #32]
	fmul.4s	v24, v24, v24
	fmul.4s	v25, v22, v22
	ldp	q26, q22, [x9, #64]
	fmul.4s	v27, v26, v26
	fmul.4s	v29, v22, v22
	ldp	q26, q22, [x9, #96]
	fmul.4s	v30, v26, v26
	fmul.4s	v31, v22, v22
	and.16b	v22, v6, v21
	and.16b	v28, v7, v23
	and.16b	v26, v6, v25
	and.16b	v25, v7, v24
	and.16b	v21, v6, v29
	and.16b	v27, v7, v27
	and.16b	v24, v6, v31
	and.16b	v23, v7, v30
	add	x19, x9, #224
	mov	w20, #4                         ; =0x4
LBB0_68:                                ; %direct.true46.i233.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q30, q29, [x19, #-96]
	and.16b	v30, v7, v30
	and.16b	v29, v6, v29
	fmul.4s	v29, v29, v29
	fmul.4s	v30, v30, v30
	fadd.4s	v30, v28, v30
	fadd.4s	v29, v22, v29
	ldp	q8, q31, [x19, #-64]
	and.16b	v8, v7, v8
	and.16b	v31, v6, v31
	fmul.4s	v31, v31, v31
	fmul.4s	v8, v8, v8
	fadd.4s	v8, v25, v8
	fadd.4s	v31, v26, v31
	ldp	q10, q9, [x19, #-32]
	and.16b	v10, v7, v10
	and.16b	v9, v6, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v10, v10, v10
	fadd.4s	v10, v27, v10
	fadd.4s	v9, v21, v9
	ldp	q12, q11, [x19], #128
	and.16b	v12, v7, v12
	and.16b	v11, v6, v11
	fmul.4s	v11, v11, v11
	fmul.4s	v12, v12, v12
	fadd.4s	v12, v23, v12
	fadd.4s	v11, v24, v11
	bit.16b	v22, v29, v6
	bit.16b	v28, v30, v7
	bit.16b	v26, v31, v6
	bit.16b	v25, v8, v7
	bit.16b	v21, v9, v6
	bit.16b	v27, v10, v7
	bit.16b	v24, v11, v6
	bit.16b	v23, v12, v7
	cmp	x20, #60
	add	x20, x20, #4
	b.lo	LBB0_68
; %bb.69:                               ; %direct.false47.i247.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	ldr	q29, [x9, #2064]
	ldr	q30, [x9, #2048]
LBB0_70:                                ; %direct.true97.i250.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x7, x19, lsl #2
	ld1r.4s	{ v31 }, [x12]
	add	x12, x13, x19, lsl #5
	ldp	q8, q9, [x12]
	bit.16b	v9, v31, v6
	bif.16b	v31, v8, v7
	stp	q31, q9, [x12]
	add	x19, x19, #1
	cmp	x19, #65
	b.ne	LBB0_70
; %bb.71:                               ; %direct.false98.i257.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	and.16b	v30, v7, v30
	and.16b	v29, v6, v29
	fmul.4s	v29, v29, v29
	fmul.4s	v30, v30, v30
	fadd.4s	v28, v28, v30
	fadd.4s	v22, v22, v29
	fadd.4s	v22, v26, v22
	fadd.4s	v25, v25, v28
	fadd.4s	v25, v27, v25
	fadd.4s	v21, v21, v22
	fadd.4s	v21, v24, v21
	fadd.4s	v22, v23, v25
	fdiv.4s	v22, v22, v5
	fdiv.4s	v5, v21, v5
	fadd.4s	v5, v5, v4
	fadd.4s	v4, v22, v4
	fsqrt.4s	v21, v4
	fsqrt.4s	v4, v5
	and.16b	v4, v6, v4
	and.16b	v5, v7, v21
	b	LBB0_73
LBB0_72:                                ; %else447
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x7, x7, #1
	cmp	x7, #65
	b.eq	LBB0_2
LBB0_73:                                ; %direct.true112.i258.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w19, s20
	dup.2d	v21, x7
	add.2d	v22, v21, v19
	lsl	x12, x7, #5
	add	x2, x9, x12
	ldp	q24, q23, [x2]
	and.16b	v24, v7, v24
	fdiv.4s	v25, v24, v5
	add	x12, x13, x12
	ldp	q26, q24, [x12]
	and.16b	v26, v7, v26
	fmul.4s	v25, v25, v26
	shl.2d	v26, v22, #2
	dup.2d	v22, x6
	add.2d	v26, v22, v26
	tbnz	w19, #0, LBB0_82
; %bb.74:                               ; %else419
                                        ;   in Loop: Header=BB0_73 Depth=2
	and	w19, w19, #0xff
	tbnz	w19, #1, LBB0_83
LBB0_75:                                ; %else423
                                        ;   in Loop: Header=BB0_73 Depth=2
	add.2d	v26, v21, v17
	shl.2d	v26, v26, #2
	add.2d	v26, v22, v26
	tbnz	w19, #2, LBB0_84
LBB0_76:                                ; %else427
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbz	w19, #3, LBB0_78
LBB0_77:                                ; %cond.store428
                                        ;   in Loop: Header=BB0_73 Depth=2
	mov.d	x12, v26[1]
	st1.s	{ v25 }[3], [x12]
LBB0_78:                                ; %else431
                                        ;   in Loop: Header=BB0_73 Depth=2
	add.2d	v25, v21, v18
	and.16b	v23, v6, v23
	fdiv.4s	v23, v23, v4
	and.16b	v24, v6, v24
	fmul.4s	v23, v23, v24
	shl.2d	v24, v25, #2
	add.2d	v24, v22, v24
	tbnz	w19, #4, LBB0_85
; %bb.79:                               ; %else435
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbnz	w19, #5, LBB0_86
LBB0_80:                                ; %else439
                                        ;   in Loop: Header=BB0_73 Depth=2
	add.2d	v21, v21, v16
	shl.2d	v21, v21, #2
	add.2d	v21, v22, v21
	tbnz	w19, #6, LBB0_87
LBB0_81:                                ; %else443
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbz	w19, #7, LBB0_72
	b	LBB0_88
LBB0_82:                                ; %cond.store
                                        ;   in Loop: Header=BB0_73 Depth=2
	fmov	x12, d26
	str	s25, [x12]
	and	w19, w19, #0xff
	tbz	w19, #1, LBB0_75
LBB0_83:                                ; %cond.store420
                                        ;   in Loop: Header=BB0_73 Depth=2
	mov.d	x12, v26[1]
	st1.s	{ v25 }[1], [x12]
	add.2d	v26, v21, v17
	shl.2d	v26, v26, #2
	add.2d	v26, v22, v26
	tbz	w19, #2, LBB0_76
LBB0_84:                                ; %cond.store424
                                        ;   in Loop: Header=BB0_73 Depth=2
	fmov	x12, d26
	st1.s	{ v25 }[2], [x12]
	tbnz	w19, #3, LBB0_77
	b	LBB0_78
LBB0_85:                                ; %cond.store432
                                        ;   in Loop: Header=BB0_73 Depth=2
	fmov	x12, d24
	str	s23, [x12]
	tbz	w19, #5, LBB0_80
LBB0_86:                                ; %cond.store436
                                        ;   in Loop: Header=BB0_73 Depth=2
	mov.d	x12, v24[1]
	st1.s	{ v23 }[1], [x12]
	add.2d	v21, v21, v16
	shl.2d	v21, v21, #2
	add.2d	v21, v22, v21
	tbz	w19, #6, LBB0_81
LBB0_87:                                ; %cond.store440
                                        ;   in Loop: Header=BB0_73 Depth=2
	fmov	x12, d21
	st1.s	{ v23 }[2], [x12]
	tbz	w19, #7, LBB0_72
LBB0_88:                                ; %cond.store444
                                        ;   in Loop: Header=BB0_73 Depth=2
	mov.d	x12, v21[1]
	st1.s	{ v23 }[3], [x12]
	b	LBB0_72
LBB0_89:                                ; %block.batch.exit.loopexit
	ldr	x9, [sp, #16]                   ; 8-byte Reload
	stp	w5, w4, [x9]
	str	w1, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
	add	sp, sp, #1, lsl #12             ; =4096
	add	sp, sp, #96
	ldp	x29, x30, [sp, #128]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #112]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #48]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp], #144            ; 16-byte Folded Reload
LBB0_90:                                ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_1:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_3:
	.quad	390                             ; 0x186
	.quad	455                             ; 0x1c7
lCPI0_4:
	.quad	130                             ; 0x82
	.quad	195                             ; 0xc3
lCPI0_5:
	.quad	260                             ; 0x104
	.quad	325                             ; 0x145
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	65                              ; 0x41
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	dup.4s	v7, w2
Lloh0:
	adrp	x8, lCPI0_0@PAGE
Lloh1:
	ldr	q16, [x8, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_1@PAGE
Lloh3:
	ldr	q17, [x8, lCPI0_1@PAGEOFF]
	cmhi.4s	v0, v7, v17
	cmhi.4s	v1, v7, v16
	uzp1.8h	v6, v1, v0
	umaxv.8h	h2, v6
	fmov	w8, s2
	tbz	w8, #0, LBB0_98
; %bb.1:                                ; %direct.activate
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #2, lsl #12             ; =8192
	sub	sp, sp, #2752
	mov	x10, #0                         ; =0x0
	add	x9, sp, #24
	add	x8, sp, #1, lsl #12             ; =4096
	add	x8, x8, #88
	dup.2d	v18, x8
	ldr	w8, [x1]
	ldr	w11, [x1, #36]
	add	w11, w11, w8, lsl #5
	ldr	x12, [x0]
	ldr	x8, [x0, #48]
	dup.4s	v2, w11
	add.4s	v3, v2, v16
	add.4s	v2, v2, v17
	and.16b	v19, v0, v2
	and.16b	v20, v1, v3
	movi.4s	v3, #65
	umull2.2d	v2, v19, v3
	umull2.2d	v3, v20, v3
	movi.2s	v5, #65
	umull.2d	v4, v19, v5
	umull.2d	v5, v20, v5
Lloh4:
	adrp	x11, lCPI0_2@PAGE
Lloh5:
	ldr	q21, [x11, lCPI0_2@PAGEOFF]
	and.16b	v6, v6, v21
	addv.8h	h6, v6
	fmov	w11, s6
	dup.2d	v21, x12
	add	x12, sp, #2, lsl #12            ; =8192
	add	x12, x12, #672
	b	LBB0_3
LBB0_2:                                 ; %else59
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x13, x12, x10, lsl #5
	ldp	q24, q25, [x13]
	bif.16b	v23, v25, v0
	bif.16b	v22, v24, v1
	stp	q22, q23, [x13]
	add	x10, x10, #1
	cmp	x10, #65
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v24, x10
	add.2d	v22, v24, v5
	shl.2d	v22, v22, #2
	add.2d	v25, v21, v22
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w11, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w13, w11, #0xff
	tbnz	w13, #1, LBB0_12
LBB0_5:                                 ; %else41
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v25, v24, v3
	shl.2d	v25, v25, #2
	add.2d	v25, v21, v25
	tbnz	w13, #2, LBB0_13
LBB0_6:                                 ; %else44
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #3, LBB0_14
LBB0_7:                                 ; %else47
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v25, v24, v4
	shl.2d	v25, v25, #2
	add.2d	v25, v21, v25
	tbnz	w13, #4, LBB0_15
LBB0_8:                                 ; %else50
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w13, #5, LBB0_16
LBB0_9:                                 ; %else53
                                        ;   in Loop: Header=BB0_3 Depth=1
	add.2d	v24, v24, v2
	shl.2d	v24, v24, #2
	add.2d	v24, v21, v24
	tbnz	w13, #6, LBB0_17
LBB0_10:                                ; %else56
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w13, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x13, d25
	ldr	s22, [x13]
	and	w13, w11, #0xff
	tbz	w13, #1, LBB0_5
LBB0_12:                                ; %cond.load40
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v22 }[1], [x14]
	add.2d	v25, v24, v3
	shl.2d	v25, v25, #2
	add.2d	v25, v21, v25
	tbz	w13, #2, LBB0_6
LBB0_13:                                ; %cond.load43
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d25
	ld1.s	{ v22 }[2], [x14]
	tbz	w13, #3, LBB0_7
LBB0_14:                                ; %cond.load46
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v22 }[3], [x14]
	add.2d	v25, v24, v4
	shl.2d	v25, v25, #2
	add.2d	v25, v21, v25
	tbz	w13, #4, LBB0_8
LBB0_15:                                ; %cond.load49
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d25
	ld1.s	{ v23 }[0], [x14]
	tbz	w13, #5, LBB0_9
LBB0_16:                                ; %cond.load52
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x14, v25[1]
	ld1.s	{ v23 }[1], [x14]
	add.2d	v24, v24, v2
	shl.2d	v24, v24, #2
	add.2d	v24, v21, v24
	tbz	w13, #6, LBB0_10
LBB0_17:                                ; %cond.load55
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x14, d24
	ld1.s	{ v23 }[2], [x14]
	tbz	w13, #7, LBB0_2
LBB0_18:                                ; %cond.load58
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x13, v24[1]
	ld1.s	{ v23 }[3], [x13]
	b	LBB0_2
LBB0_19:                                ; %direct.true59.preheader
	mov	x10, #0                         ; =0x0
	sshll2.2d	v23, v0, #0
	sshll2.2d	v21, v1, #0
	sshll.2d	v22, v0, #0
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #608
	sshll.2d	v24, v1, #0
LBB0_20:                                ; %direct.true59
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v25, x10
	add	x12, x11, x10, lsl #6
	ldp	q27, q26, [x12, #32]
	ldp	q29, q28, [x12]
	bit.16b	v29, v25, v24
	bit.16b	v27, v25, v22
	bit.16b	v28, v25, v21
	bif.16b	v25, v26, v23
	stp	q27, q25, [x12, #32]
	stp	q29, q28, [x12]
	add	x10, x10, #1
	cmp	x10, #65
	b.ne	LBB0_20
; %bb.21:                               ; %direct.false60
	mov	x10, #0                         ; =0x0
	sshll.2d	v30, v1, #0
	sshll.2d	v29, v0, #0
	movi.4s	v22, #65
	and.16b	v24, v0, v22
	mvn.16b	v25, v0
	sub.4s	v24, v24, v25
	and.16b	v22, v1, v22
	mvn.16b	v25, v1
	sub.4s	v22, v22, v25
	mov.s	w11, v22[1]
	mov.s	w12, v20[1]
	udiv	w13, w12, w11
	msub	w11, w13, w11, w12
	mov.s	w12, v22[3]
	mov.s	w13, v22[2]
	fmov	w14, s22
	fmov	w15, s20
	udiv	w16, w15, w14
	msub	w14, w16, w14, w15
	mov.s	w15, v20[3]
	udiv	w16, w15, w12
	msub	w12, w16, w12, w15
	mov.s	w15, v20[2]
	udiv	w16, w15, w13
	msub	w13, w16, w13, w15
	mov.s	w15, v24[1]
	mov.s	w16, v19[1]
	udiv	w17, w16, w15
	msub	w15, w17, w15, w16
	mov.s	w16, v24[3]
	mov.s	w17, v19[3]
	udiv	w0, w17, w16
	msub	w16, w0, w16, w17
	mov.s	w17, v24[2]
	mov.s	w0, v19[2]
	udiv	w1, w0, w17
	msub	w17, w1, w17, w0
	fmov	w0, s24
	fmov	w1, s19
	fmov	s19, w17
	mov.s	v19[1], w16
	udiv	w16, w1, w0
	msub	w16, w16, w0, w1
	ushll.2d	v19, v19, #0
	fmov	s20, w16
	mov.s	v20[1], w15
	ushll.2d	v20, v20, #0
	fmov	s22, w13
	mov.s	v22[1], w12
	fmov	s24, w14
	mov.s	v24[1], w11
	ushll.2d	v22, v22, #0
	ushll.2d	v24, v24, #0
	and.16b	v25, v23, v18
	and.16b	v26, v21, v18
	and.16b	v27, v29, v18
	and.16b	v28, v30, v18
Lloh6:
	adrp	x11, lCPI0_3@PAGE
Lloh7:
	ldr	q18, [x11, lCPI0_3@PAGEOFF]
	and.16b	v23, v23, v18
Lloh8:
	adrp	x11, lCPI0_4@PAGE
Lloh9:
	ldr	q18, [x11, lCPI0_4@PAGEOFF]
	and.16b	v21, v21, v18
Lloh10:
	adrp	x11, lCPI0_5@PAGE
Lloh11:
	ldr	q18, [x11, lCPI0_5@PAGEOFF]
	and.16b	v29, v29, v18
Lloh12:
	adrp	x11, lCPI0_6@PAGE
Lloh13:
	ldr	q18, [x11, lCPI0_6@PAGEOFF]
	and.16b	v30, v30, v18
	cmhs.4s	v17, v17, v7
	cmhs.4s	v7, v16, v7
	uzp1.8h	v7, v7, v17
	xtn.8b	v31, v7
	add	x11, sp, #1, lsl #12            ; =4096
	add	x11, x11, #608
	movi.8b	v8, #1
	b	LBB0_23
LBB0_22:                                ; %else84
                                        ;   in Loop: Header=BB0_23 Depth=1
	add	x10, x10, #1
	cmp	x10, #65
	b.eq	LBB0_39
LBB0_23:                                ; %direct.true73
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v9, x10
	fmov	w12, s6
	add	x13, x11, x10, lsl #6
	ldp	q16, q7, [x13, #32]
	ldp	q17, q18, [x13]
	cmge.2d	v18, v22, v18
	cmge.2d	v17, v24, v17
	uzp1.4s	v17, v17, v18
	cmge.2d	v16, v20, v16
	cmge.2d	v7, v19, v7
	uzp1.4s	v7, v16, v7
	uzp1.8h	v7, v17, v7
	xtn.8b	v7, v7
	orr.8b	v17, v31, v7
	add.2d	v7, v28, v30
	add.2d	v16, v7, v9
	and.8b	v10, v17, v8
	tbnz	w12, #0, LBB0_31
; %bb.24:                               ; %else63
                                        ;   in Loop: Header=BB0_23 Depth=1
	and	w12, w12, #0xff
	tbnz	w12, #1, LBB0_32
LBB0_25:                                ; %else66
                                        ;   in Loop: Header=BB0_23 Depth=1
	add.2d	v16, v26, v21
	add.2d	v17, v16, v9
	tbnz	w12, #2, LBB0_33
LBB0_26:                                ; %else69
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w12, #3, LBB0_34
LBB0_27:                                ; %else72
                                        ;   in Loop: Header=BB0_23 Depth=1
	add.2d	v17, v27, v29
	add.2d	v18, v17, v9
	tbnz	w12, #4, LBB0_35
LBB0_28:                                ; %else75
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbnz	w12, #5, LBB0_36
LBB0_29:                                ; %else78
                                        ;   in Loop: Header=BB0_23 Depth=1
	add.2d	v18, v25, v23
	add.2d	v9, v18, v9
	tbnz	w12, #6, LBB0_37
LBB0_30:                                ; %else81
                                        ;   in Loop: Header=BB0_23 Depth=1
	tbz	w12, #7, LBB0_22
	b	LBB0_38
LBB0_31:                                ; %cond.store
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x13, d16
	str	b10, [x13]
	and	w12, w12, #0xff
	tbz	w12, #1, LBB0_25
LBB0_32:                                ; %cond.store64
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x13, v16[1]
	st1.b	{ v10 }[1], [x13]
	add.2d	v16, v26, v21
	add.2d	v17, v16, v9
	tbz	w12, #2, LBB0_26
LBB0_33:                                ; %cond.store67
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x13, d17
	st1.b	{ v10 }[2], [x13]
	tbz	w12, #3, LBB0_27
LBB0_34:                                ; %cond.store70
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x13, v17[1]
	st1.b	{ v10 }[3], [x13]
	add.2d	v17, v27, v29
	add.2d	v18, v17, v9
	tbz	w12, #4, LBB0_28
LBB0_35:                                ; %cond.store73
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x13, d18
	st1.b	{ v10 }[4], [x13]
	tbz	w12, #5, LBB0_29
LBB0_36:                                ; %cond.store76
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x13, v18[1]
	st1.b	{ v10 }[5], [x13]
	add.2d	v18, v25, v23
	add.2d	v9, v18, v9
	tbz	w12, #6, LBB0_30
LBB0_37:                                ; %cond.store79
                                        ;   in Loop: Header=BB0_23 Depth=1
	fmov	x13, d9
	st1.b	{ v10 }[6], [x13]
	tbz	w12, #7, LBB0_22
LBB0_38:                                ; %cond.store82
                                        ;   in Loop: Header=BB0_23 Depth=1
	mov.d	x12, v9[1]
	st1.b	{ v10 }[7], [x12]
	b	LBB0_22
LBB0_39:                                ; %direct.true87.preheader
	mov	x10, #0                         ; =0x0
	fmov	w11, s6
	add	x12, sp, #2, lsl #12            ; =8192
	add	x12, x12, #672
	mov	w13, #62154                     ; =0xf2ca
	movk	w13, #61769, lsl #16
	dup.4s	v19, w13
	add	x13, sp, #2104
	b	LBB0_41
LBB0_40:                                ; %else132
                                        ;   in Loop: Header=BB0_41 Depth=1
	cmeq.8b	v20, v20, #0
	sshll.8h	v20, v20, #0
	sshll2.4s	v21, v20, #0
	sshll.4s	v20, v20, #0
	lsl	x14, x10, #5
	add	x15, x12, x14
	ldp	q22, q23, [x15]
	and.16b	v23, v0, v23
	and.16b	v22, v1, v22
	bsl.16b	v20, v19, v22
	bsl.16b	v21, v19, v23
	add	x14, x13, x14
	ldp	q22, q23, [x14]
	bif.16b	v21, v23, v0
	bif.16b	v20, v22, v1
	stp	q20, q21, [x14]
	add	x10, x10, #1
	cmp	x10, #65
	b.eq	LBB0_57
LBB0_41:                                ; %direct.true87
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v21, x10
	add.2d	v22, v7, v21
	tbz	w11, #0, LBB0_50
; %bb.42:                               ; %cond.load86
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x14, d22
	ldr	b20, [x14]
	and	w14, w11, #0xff
	tbz	w14, #1, LBB0_44
LBB0_43:                                ; %cond.load92
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v22[1]
	ld1.b	{ v20 }[1], [x15]
LBB0_44:                                ; %else96
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v22, v16, v21
	tbnz	w14, #2, LBB0_51
; %bb.45:                               ; %else102
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #3, LBB0_52
LBB0_46:                                ; %else108
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v22, v17, v21
	tbnz	w14, #4, LBB0_53
LBB0_47:                                ; %else114
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbnz	w14, #5, LBB0_54
LBB0_48:                                ; %else120
                                        ;   in Loop: Header=BB0_41 Depth=1
	add.2d	v21, v18, v21
	tbnz	w14, #6, LBB0_55
LBB0_49:                                ; %else126
                                        ;   in Loop: Header=BB0_41 Depth=1
	tbz	w14, #7, LBB0_40
	b	LBB0_56
LBB0_50:                                ;   in Loop: Header=BB0_41 Depth=1
	movi.2d	v20, #0000000000000000
	and	w14, w11, #0xff
	tbnz	w14, #1, LBB0_43
	b	LBB0_44
LBB0_51:                                ; %cond.load98
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d22
	ld1.b	{ v20 }[2], [x15]
	tbz	w14, #3, LBB0_46
LBB0_52:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v22[1]
	ld1.b	{ v20 }[3], [x15]
	add.2d	v22, v17, v21
	tbz	w14, #4, LBB0_47
LBB0_53:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d22
	ld1.b	{ v20 }[4], [x15]
	tbz	w14, #5, LBB0_48
LBB0_54:                                ; %cond.load116
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x15, v22[1]
	ld1.b	{ v20 }[5], [x15]
	add.2d	v21, v18, v21
	tbz	w14, #6, LBB0_49
LBB0_55:                                ; %cond.load122
                                        ;   in Loop: Header=BB0_41 Depth=1
	fmov	x15, d21
	ld1.b	{ v20 }[6], [x15]
	tbz	w14, #7, LBB0_40
LBB0_56:                                ; %cond.load128
                                        ;   in Loop: Header=BB0_41 Depth=1
	mov.d	x14, v21[1]
	ld1.b	{ v20 }[7], [x14]
	b	LBB0_40
LBB0_57:                                ; %direct.false88
	ldr	q19, [x9, #2080]
	ldr	q20, [x9, #2096]
	ldr	q21, [x9, #2112]
	ldr	q22, [x9, #2128]
	ldr	q25, [x9, #2144]
	ldr	q27, [x9, #2160]
	ldr	q28, [x9, #2176]
	and.16b	v26, v0, v20
	and.16b	v19, v1, v19
	ldr	q29, [x9, #2192]
	and.16b	v24, v0, v22
	and.16b	v23, v1, v21
	and.16b	v20, v0, v27
	and.16b	v25, v1, v25
	and.16b	v22, v0, v29
	and.16b	v21, v1, v28
	add	x10, sp, #2104
	add	x10, x10, #224
	mov	w11, #4                         ; =0x4
LBB0_58:                                ; %direct.true118
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q27, q28, [x10, #-96]
	and.16b	v28, v0, v28
	and.16b	v27, v1, v27
	fmaxnm.4s	v27, v19, v27
	fmaxnm.4s	v28, v26, v28
	ldp	q29, q30, [x10, #-64]
	and.16b	v30, v0, v30
	and.16b	v29, v1, v29
	fmaxnm.4s	v29, v23, v29
	fmaxnm.4s	v30, v24, v30
	ldp	q31, q8, [x10, #-32]
	and.16b	v8, v0, v8
	and.16b	v31, v1, v31
	fmaxnm.4s	v31, v25, v31
	fmaxnm.4s	v8, v20, v8
	ldp	q9, q10, [x10], #128
	and.16b	v10, v0, v10
	and.16b	v9, v1, v9
	fmaxnm.4s	v9, v21, v9
	fmaxnm.4s	v10, v22, v10
	bit.16b	v26, v28, v0
	bit.16b	v19, v27, v1
	bit.16b	v24, v30, v0
	bit.16b	v23, v29, v1
	bit.16b	v20, v8, v0
	bit.16b	v25, v31, v1
	bit.16b	v22, v10, v0
	bit.16b	v21, v9, v1
	cmp	x11, #60
	add	x11, x11, #4
	b.lo	LBB0_58
; %bb.59:                               ; %direct.false119
	mov	x10, #0                         ; =0x0
	ldr	q27, [x9, #4144]
	ldr	q28, [x9, #4128]
	and.16b	v28, v1, v28
	and.16b	v27, v0, v27
	fmaxnm.4s	v26, v26, v27
	fmaxnm.4s	v27, v19, v28
	mvni.4s	v19, #127, msl #16
	fmaxnm.4s	v27, v27, v19
	fmaxnm.4s	v26, v26, v19
	fmaxnm.4s	v24, v26, v24
	fmaxnm.4s	v23, v27, v23
	fmaxnm.4s	v23, v23, v25
	fmaxnm.4s	v20, v24, v20
	fmaxnm.4s	v20, v20, v22
	fmaxnm.4s	v21, v23, v21
	str	q6, [sp]                        ; 16-byte Spill
	fmov	w11, s6
	add	x12, sp, #2104
	mov	w13, #-1026555904               ; =0xc2d00000
	mov	w14, #1120403456                ; =0x42c80000
	mov	w15, #43579                     ; =0xaa3b
	movk	w15, #16312, lsl #16
	movi.4s	v22, #75, lsl #24
	mvni.4s	v23, #128, lsl #24
	mov	w16, #29184                     ; =0x7200
	movk	w16, #48945, lsl #16
	mov	w17, #48782                     ; =0xbe8e
	movk	w17, #46527, lsl #16
	mov	w0, #11226                      ; =0x2bda
	movk	w0, #14672, lsl #16
	mov	w1, #38601                      ; =0x96c9
	movk	w1, #15030, lsl #16
	mov	w2, #34982                      ; =0x88a6
	movk	w2, #15368, lsl #16
	mov	w3, #43642                      ; =0xaa7a
	movk	w3, #15658, lsl #16
	mov	w4, #43691                      ; =0xaaab
	movk	w4, #15914, lsl #16
	movi.4s	v24, #63, lsl #24
	fmov.4s	v25, #1.00000000
	mvni.4s	v26, #63, msl #16
	fneg.4s	v26, v26
	add	x5, sp, #24
	b	LBB0_61
LBB0_60:                                ; %else181
                                        ;   in Loop: Header=BB0_61 Depth=1
	cmeq.8b	v27, v27, #0
	sshll.8h	v28, v27, #0
	sshll2.4s	v27, v28, #0
	sshll.4s	v28, v28, #0
	lsl	x6, x10, #5
	add	x7, x12, x6
	ldp	q30, q29, [x7]
	fsub.4s	v30, v30, v21
	fsub.4s	v29, v29, v20
	and.16b	v29, v0, v29
	and.16b	v30, v1, v30
	dup.4s	v31, w13
	fcmge.4s	v9, v30, v31
	fcmge.4s	v10, v29, v31
	dup.4s	v8, w14
	fcmge.4s	v11, v8, v30
	fcmge.4s	v12, v8, v29
	and.16b	v10, v10, v12
	and.16b	v9, v9, v11
	and.16b	v9, v9, v30
	and.16b	v10, v10, v29
	dup.4s	v11, w15
	fmul.4s	v12, v10, v11
	fmul.4s	v11, v9, v11
	mov.16b	v13, v23
	bsl.16b	v13, v22, v11
	mov.16b	v14, v23
	bsl.16b	v14, v22, v12
	fadd.4s	v12, v12, v14
	fadd.4s	v11, v11, v13
	fsub.4s	v11, v11, v13
	fsub.4s	v12, v12, v14
	fcvtzs.4s	v12, v12
	fcvtzs.4s	v11, v11
	scvtf.4s	v13, v11
	scvtf.4s	v14, v12
	dup.4s	v15, w16
	fmul.4s	v6, v14, v15
	fmul.4s	v15, v13, v15
	fadd.4s	v9, v9, v15
	fadd.4s	v6, v10, v6
	dup.4s	v10, w17
	fmul.4s	v13, v13, v10
	fmul.4s	v10, v14, v10
	fadd.4s	v6, v6, v10
	fadd.4s	v9, v9, v13
	dup.4s	v10, w0
	fmul.4s	v13, v9, v10
	fmul.4s	v10, v6, v10
	dup.4s	v14, w1
	fadd.4s	v10, v10, v14
	fadd.4s	v13, v13, v14
	fmul.4s	v13, v9, v13
	fmul.4s	v10, v6, v10
	dup.4s	v14, w2
	fadd.4s	v10, v10, v14
	fadd.4s	v13, v13, v14
	fmul.4s	v13, v9, v13
	fmul.4s	v10, v6, v10
	dup.4s	v14, w3
	fadd.4s	v10, v10, v14
	fadd.4s	v13, v13, v14
	fmul.4s	v13, v9, v13
	fmul.4s	v10, v6, v10
	dup.4s	v14, w4
	fadd.4s	v10, v10, v14
	fadd.4s	v13, v13, v14
	fmul.4s	v13, v9, v13
	fmul.4s	v10, v6, v10
	fadd.4s	v10, v10, v24
	fadd.4s	v13, v13, v24
	fmul.4s	v14, v6, v6
	fmul.4s	v15, v9, v9
	fmul.4s	v13, v15, v13
	fmul.4s	v10, v14, v10
	fadd.4s	v6, v6, v10
	fadd.4s	v9, v9, v13
	fadd.4s	v9, v9, v25
	fadd.4s	v6, v6, v25
	sshr.4s	v10, v11, #1
	sshr.4s	v13, v12, #1
	shl.4s	v14, v13, #23
	shl.4s	v15, v10, #23
	add.4s	v15, v15, v25
	add.4s	v14, v14, v25
	fmul.4s	v6, v6, v14
	fmul.4s	v9, v9, v15
	sub.4s	v12, v12, v13
	sub.4s	v10, v11, v10
	shl.4s	v10, v10, #23
	shl.4s	v11, v12, #23
	add.4s	v11, v11, v25
	add.4s	v10, v10, v25
	fmul.4s	v9, v9, v10
	fmul.4s	v6, v6, v11
	fcmgt.4s	v10, v31, v29
	bic.16b	v6, v6, v10
	fcmgt.4s	v31, v31, v30
	bic.16b	v31, v9, v31
	fcmgt.4s	v9, v29, v8
	fcmgt.4s	v8, v30, v8
	fneg.4s	v10, v19
	bit.16b	v31, v10, v8
	bit.16b	v6, v10, v9
	fcmeq.4s	v30, v30, v30
	fcmeq.4s	v29, v29, v29
	bif.16b	v6, v26, v29
	mov.16b	v29, v30
	bsl.16b	v29, v31, v26
	bic.16b	v28, v29, v28
	bic.16b	v6, v6, v27
	add	x6, x5, x6
	ldp	q27, q29, [x6]
	bif.16b	v6, v29, v0
	bit.16b	v27, v28, v1
	stp	q27, q6, [x6]
	add	x10, x10, #1
	cmp	x10, #65
	b.eq	LBB0_77
LBB0_61:                                ; %direct.true164
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v28, x10
	add.2d	v29, v7, v28
	tbz	w11, #0, LBB0_70
; %bb.62:                               ; %cond.load135
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x6, d29
	ldr	b27, [x6]
	and	w6, w11, #0xff
	tbz	w6, #1, LBB0_64
LBB0_63:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x7, v29[1]
	ld1.b	{ v27 }[1], [x7]
LBB0_64:                                ; %else145
                                        ;   in Loop: Header=BB0_61 Depth=1
	add.2d	v29, v16, v28
	tbnz	w6, #2, LBB0_71
; %bb.65:                               ; %else151
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbnz	w6, #3, LBB0_72
LBB0_66:                                ; %else157
                                        ;   in Loop: Header=BB0_61 Depth=1
	add.2d	v29, v17, v28
	tbnz	w6, #4, LBB0_73
LBB0_67:                                ; %else163
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbnz	w6, #5, LBB0_74
LBB0_68:                                ; %else169
                                        ;   in Loop: Header=BB0_61 Depth=1
	add.2d	v28, v18, v28
	tbnz	w6, #6, LBB0_75
LBB0_69:                                ; %else175
                                        ;   in Loop: Header=BB0_61 Depth=1
	tbz	w6, #7, LBB0_60
	b	LBB0_76
LBB0_70:                                ;   in Loop: Header=BB0_61 Depth=1
	movi.2d	v27, #0000000000000000
	and	w6, w11, #0xff
	tbnz	w6, #1, LBB0_63
	b	LBB0_64
LBB0_71:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x7, d29
	ld1.b	{ v27 }[2], [x7]
	tbz	w6, #3, LBB0_66
LBB0_72:                                ; %cond.load153
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x7, v29[1]
	ld1.b	{ v27 }[3], [x7]
	add.2d	v29, v17, v28
	tbz	w6, #4, LBB0_67
LBB0_73:                                ; %cond.load159
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x7, d29
	ld1.b	{ v27 }[4], [x7]
	tbz	w6, #5, LBB0_68
LBB0_74:                                ; %cond.load165
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x7, v29[1]
	ld1.b	{ v27 }[5], [x7]
	add.2d	v28, v18, v28
	tbz	w6, #6, LBB0_69
LBB0_75:                                ; %cond.load171
                                        ;   in Loop: Header=BB0_61 Depth=1
	fmov	x7, d28
	ld1.b	{ v27 }[6], [x7]
	tbz	w6, #7, LBB0_60
LBB0_76:                                ; %cond.load177
                                        ;   in Loop: Header=BB0_61 Depth=1
	mov.d	x6, v28[1]
	ld1.b	{ v27 }[7], [x6]
	b	LBB0_60
LBB0_77:                                ; %direct.false165
	ldur	q6, [sp, #24]
	ldur	q7, [sp, #40]
	ldur	q17, [sp, #56]
	ldur	q18, [sp, #72]
	ldur	q21, [sp, #88]
	ldur	q22, [sp, #104]
	and.16b	v16, v0, v7
	and.16b	v20, v1, v6
	ldur	q6, [sp, #120]
	ldur	q23, [sp, #136]
	and.16b	v7, v0, v18
	and.16b	v19, v1, v17
	and.16b	v18, v0, v22
	and.16b	v17, v1, v21
	and.16b	v21, v0, v23
	and.16b	v22, v1, v6
	add	x10, sp, #24
	add	x10, x10, #224
	mov	w11, #4                         ; =0x4
LBB0_78:                                ; %direct.true208
                                        ; =>This Inner Loop Header: Depth=1
	ldp	q23, q6, [x10, #-96]
	fadd.4s	v25, v20, v23
	fadd.4s	v6, v16, v6
	ldp	q24, q23, [x10, #-64]
	fadd.4s	v26, v19, v24
	fadd.4s	v27, v7, v23
	ldp	q24, q23, [x10, #-32]
	fadd.4s	v28, v17, v24
	fadd.4s	v29, v18, v23
	ldp	q23, q24, [x10], #128
	fadd.4s	v23, v22, v23
	fadd.4s	v24, v21, v24
	bit.16b	v16, v6, v0
	bit.16b	v20, v25, v1
	bit.16b	v7, v27, v0
	bit.16b	v19, v26, v1
	bit.16b	v18, v29, v0
	bit.16b	v17, v28, v1
	bit.16b	v21, v24, v0
	bit.16b	v22, v23, v1
	cmp	x11, #60
	add	x11, x11, #4
	b.lo	LBB0_78
; %bb.79:                               ; %direct.false209
	mov	x10, #0                         ; =0x0
	ldr	q6, [x9, #2048]
	ldr	q21, [x9, #2064]
	and.16b	v21, v0, v21
	and.16b	v6, v1, v6
	movi.2d	v22, #0000000000000000
	fadd.4s	v6, v20, v6
	fadd.4s	v16, v16, v21
	fadd.4s	v16, v16, v22
	fadd.4s	v6, v6, v22
	fadd.4s	v6, v19, v6
	fadd.4s	v7, v7, v16
	fadd.4s	v7, v18, v7
	fadd.4s	v6, v17, v6
	fadd.4s	v6, v23, v6
	fadd.4s	v7, v24, v7
	and.16b	v7, v0, v7
	and.16b	v16, v1, v6
	ldr	q6, [sp]                        ; 16-byte Reload
	fmov	w9, s6
	dup.2d	v6, x8
	add	x8, sp, #24
	b	LBB0_81
LBB0_80:                                ; %else215
                                        ;   in Loop: Header=BB0_81 Depth=1
	add	x10, x10, #1
	cmp	x10, #65
	b.eq	LBB0_97
LBB0_81:                                ; %direct.true254
                                        ; =>This Inner Loop Header: Depth=1
	dup.2d	v17, x10
	add.2d	v19, v17, v5
	add	x12, x8, x10, lsl #5
	ldr	q18, [x12]
	and.16b	v18, v1, v18
	fdiv.4s	v18, v18, v16
	shl.2d	v19, v19, #2
	add.2d	v19, v6, v19
	tbnz	w9, #0, LBB0_90
; %bb.82:                               ; %else187
                                        ;   in Loop: Header=BB0_81 Depth=1
	and	w11, w9, #0xff
	tbnz	w11, #1, LBB0_91
LBB0_83:                                ; %else191
                                        ;   in Loop: Header=BB0_81 Depth=1
	add.2d	v19, v17, v3
	shl.2d	v19, v19, #2
	add.2d	v19, v6, v19
	tbnz	w11, #2, LBB0_92
LBB0_84:                                ; %else195
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbz	w11, #3, LBB0_86
LBB0_85:                                ; %cond.store196
                                        ;   in Loop: Header=BB0_81 Depth=1
	mov.d	x13, v19[1]
	st1.s	{ v18 }[3], [x13]
LBB0_86:                                ; %else199
                                        ;   in Loop: Header=BB0_81 Depth=1
	add.2d	v19, v17, v4
	ldr	q18, [x12, #16]
	and.16b	v18, v0, v18
	fdiv.4s	v18, v18, v7
	shl.2d	v19, v19, #2
	add.2d	v19, v6, v19
	tbnz	w11, #4, LBB0_93
; %bb.87:                               ; %else203
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbnz	w11, #5, LBB0_94
LBB0_88:                                ; %else207
                                        ;   in Loop: Header=BB0_81 Depth=1
	add.2d	v17, v17, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbnz	w11, #6, LBB0_95
LBB0_89:                                ; %else211
                                        ;   in Loop: Header=BB0_81 Depth=1
	tbz	w11, #7, LBB0_80
	b	LBB0_96
LBB0_90:                                ; %cond.store184
                                        ;   in Loop: Header=BB0_81 Depth=1
	fmov	x11, d19
	str	s18, [x11]
	and	w11, w9, #0xff
	tbz	w11, #1, LBB0_83
LBB0_91:                                ; %cond.store188
                                        ;   in Loop: Header=BB0_81 Depth=1
	mov.d	x13, v19[1]
	st1.s	{ v18 }[1], [x13]
	add.2d	v19, v17, v3
	shl.2d	v19, v19, #2
	add.2d	v19, v6, v19
	tbz	w11, #2, LBB0_84
LBB0_92:                                ; %cond.store192
                                        ;   in Loop: Header=BB0_81 Depth=1
	fmov	x13, d19
	st1.s	{ v18 }[2], [x13]
	tbnz	w11, #3, LBB0_85
	b	LBB0_86
LBB0_93:                                ; %cond.store200
                                        ;   in Loop: Header=BB0_81 Depth=1
	fmov	x12, d19
	str	s18, [x12]
	tbz	w11, #5, LBB0_88
LBB0_94:                                ; %cond.store204
                                        ;   in Loop: Header=BB0_81 Depth=1
	mov.d	x12, v19[1]
	st1.s	{ v18 }[1], [x12]
	add.2d	v17, v17, v2
	shl.2d	v17, v17, #2
	add.2d	v17, v6, v17
	tbz	w11, #6, LBB0_89
LBB0_95:                                ; %cond.store208
                                        ;   in Loop: Header=BB0_81 Depth=1
	fmov	x12, d17
	st1.s	{ v18 }[2], [x12]
	tbz	w11, #7, LBB0_80
LBB0_96:                                ; %cond.store212
                                        ;   in Loop: Header=BB0_81 Depth=1
	mov.d	x11, v17[1]
	st1.s	{ v18 }[3], [x11]
	b	LBB0_80
LBB0_97:
	add	sp, sp, #2, lsl #12             ; =8192
	add	sp, sp, #2752
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
LBB0_98:                                ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

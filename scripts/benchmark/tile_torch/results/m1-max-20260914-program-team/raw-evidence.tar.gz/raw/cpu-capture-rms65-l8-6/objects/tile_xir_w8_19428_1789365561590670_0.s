	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_8:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_9:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_10:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_rows:                              ; @llm_rows
; %bb.0:                                ; %prologue
	stp	d15, d14, [sp, #-80]!           ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	sub	sp, sp, #1792
	dup.4s	v0, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q1, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q2, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v11, v0, v2
	cmhi.4s	v12, v0, v1
	uzp1.8h	v1, v12, v11
	umaxv.8h	h0, v1
	fmov	w8, s0
	tbz	w8, #0, LBB0_197
; %bb.1:                                ; %direct.activate
	mov	x9, #0                          ; =0x0
	add	x8, sp, #1216
	dup.2d	v0, x8
	str	q0, [sp, #80]                   ; 16-byte Spill
	ldr	x10, [x0]
	ldr	x11, [x0, #16]
	ldr	x8, [x0, #48]
Lloh4:
	adrp	x12, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x12, lCPI0_0@PAGEOFF]
	and.16b	v0, v1, v0
	addv.8h	h0, v0
	fmov	w12, s0
	ldr	w13, [x1]
	ldr	w14, [x1, #36]
	add	w13, w14, w13, lsl #5
	lsr	w13, w13, #3
	dup.4s	v2, w13
	and	w12, w12, #0xff
	and.16b	v3, v12, v2
	and.16b	v2, v11, v2
	ushll2.2d	v4, v2, #0
	ushll2.2d	v5, v3, #0
	ushll.2d	v7, v2, #0
	ushll.2d	v17, v3, #0
	fmov	x13, d17
	mov	w14, #260                       ; =0x104
	umaddl	x13, w13, w14, x10
	fmov	w14, s0
	add	x15, sp, #1504
	b	LBB0_3
LBB0_2:                                 ; %else33
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x15, x9
	stp	q2, q3, [x16]
	add	x9, x9, #32
	cmp	x9, #256
	b.eq	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	add	x16, x13, x9
	add	x0, x15, x9
	ldr	q2, [x0]
	tbnz	w14, #0, LBB0_11
; %bb.4:                                ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w17, w14, #0xff
	tbnz	w17, #1, LBB0_12
LBB0_5:                                 ; %else15
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #2, LBB0_13
LBB0_6:                                 ; %else18
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #3, LBB0_14
LBB0_7:                                 ; %else21
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q3, [x0, #16]
	tbnz	w17, #4, LBB0_15
LBB0_8:                                 ; %else24
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #5, LBB0_16
LBB0_9:                                 ; %else27
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w17, #6, LBB0_17
LBB0_10:                                ; %else30
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w17, #7, LBB0_2
	b	LBB0_18
LBB0_11:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	ld1.s	{ v2 }[0], [x16]
	and	w17, w14, #0xff
	tbz	w17, #1, LBB0_5
LBB0_12:                                ; %cond.load14
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #4
	ld1.s	{ v2 }[1], [x1]
	tbz	w17, #2, LBB0_6
LBB0_13:                                ; %cond.load17
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #8
	ld1.s	{ v2 }[2], [x1]
	tbz	w17, #3, LBB0_7
LBB0_14:                                ; %cond.load20
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x1, x16, #12
	ld1.s	{ v2 }[3], [x1]
	ldr	q3, [x0, #16]
	tbz	w17, #4, LBB0_8
LBB0_15:                                ; %cond.load23
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #16
	ld1.s	{ v3 }[0], [x0]
	tbz	w17, #5, LBB0_9
LBB0_16:                                ; %cond.load26
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #20
	ld1.s	{ v3 }[1], [x0]
	tbz	w17, #6, LBB0_10
LBB0_17:                                ; %cond.load29
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x0, x16, #24
	ld1.s	{ v3 }[2], [x0]
	tbz	w17, #7, LBB0_2
LBB0_18:                                ; %cond.load32
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	x16, x16, #28
	ld1.s	{ v3 }[3], [x16]
	b	LBB0_2
LBB0_19:                                ; %direct.true56.preheader
	xtn.8b	v25, v1
	sshll.2d	v2, v12, #0
	sshll.2d	v16, v11, #0
	sshll2.2d	v18, v12, #0
	sshll2.2d	v22, v11, #0
	add	x13, sp, #1504
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q1, [x9, lCPI0_6@PAGEOFF]
	and.16b	v21, v2, v1
	movi.2d	v3, #0000000000000000
Lloh8:
	adrp	x9, lCPI0_7@PAGE
Lloh9:
	ldr	q1, [x9, lCPI0_7@PAGEOFF]
	and.16b	v1, v2, v1
Lloh10:
	adrp	x9, lCPI0_8@PAGE
Lloh11:
	ldr	q6, [x9, lCPI0_8@PAGEOFF]
	and.16b	v19, v16, v6
Lloh12:
	adrp	x9, lCPI0_9@PAGE
Lloh13:
	ldr	q6, [x9, lCPI0_9@PAGEOFF]
	str	q18, [sp, #496]                 ; 16-byte Spill
	and.16b	v20, v18, v6
Lloh14:
	adrp	x9, lCPI0_10@PAGE
Lloh15:
	ldr	q6, [x9, lCPI0_10@PAGEOFF]
	movi.8b	v18, #1
	and.8b	v18, v25, v18
	umov.b	w14, v18[0]
	str	q22, [sp, #480]                 ; 16-byte Spill
	and.16b	v24, v22, v6
	movi.2d	v6, #0000000000000000
	movi.2d	v23, #0000000000000000
	mov.b	v23[0], v25[0]
	umaxv.8b	b18, v23
	fmov	w17, s18
	rbit	w9, w14
	clz	w9, w9
	tst	w17, #0x1
	csel	w9, w9, wzr, ne
	mov	w15, #64                        ; =0x40
	dup.2d	v18, x15
	str	q21, [sp, #96]                  ; 16-byte Spill
	orr.16b	v21, v21, v18
	xtn.2s	v22, v17
	movi.2s	v17, #65
	stp	q25, q21, [sp, #160]            ; 32-byte Folded Spill
	umlal.2d	v21, v22, v17
	mov.b	v6[0], v25[0]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	str	q21, [sp, #256]                 ; 16-byte Spill
	and.16b	v6, v6, v21
	str	q3, [sp, #1120]
	str	q3, [sp, #1104]
	str	q3, [sp, #1088]
	str	q6, [sp, #1072]
	ubfiz	x16, x9, #3, #3
	add	x15, sp, #1072
	ldr	x15, [x15, x16]
	sub	x15, x15, x9
	add	x15, x10, x15, lsl #2
	stp	q24, q20, [sp, #512]            ; 32-byte Folded Spill
	str	q24, [sp, #1184]
	str	q19, [sp, #544]                 ; 16-byte Spill
	str	q19, [sp, #1168]
	str	q20, [sp, #1152]
	str	q1, [sp, #1136]
	add	x10, sp, #1136
	ldr	x10, [x10, x16]
	orr	x10, x10, #0x100
	sub	x10, x10, w9, uxtw #2
	tst	w14, #0x1
	csel	x10, xzr, x10, eq
	add	x16, x13, x10
	ldr	q26, [x16]
	tbnz	w17, #0, LBB0_198
; %bb.20:                               ; %else37
	tbnz	w14, #1, LBB0_199
LBB0_21:                                ; %else40
	tbnz	w14, #2, LBB0_200
LBB0_22:                                ; %else43
	tbnz	w14, #3, LBB0_201
LBB0_23:                                ; %else46
	adrp	x17, lCPI0_3@PAGE
	adrp	x0, lCPI0_4@PAGE
	adrp	x1, lCPI0_5@PAGE
	ldr	q27, [x16, #16]
	tbnz	w14, #4, LBB0_202
LBB0_24:                                ; %else49
	ldr	q3, [x17, lCPI0_3@PAGEOFF]
	ldr	q6, [x0, lCPI0_4@PAGEOFF]
	ldr	q19, [x1, lCPI0_5@PAGEOFF]
	tbnz	w14, #5, LBB0_203
LBB0_25:                                ; %else52
	ldp	q21, q20, [sp, #480]            ; 32-byte Folded Reload
	and.16b	v3, v21, v3
	and.16b	v6, v20, v6
	and.16b	v19, v16, v19
	tbz	w14, #6, LBB0_27
LBB0_26:                                ; %cond.load54
	add	x16, x15, #24
	ld1.s	{ v27 }[2], [x16]
LBB0_27:                                ; %else55
	dup.2d	v21, x13
	orr.16b	v24, v19, v18
	stp	q6, q3, [sp, #32]               ; 32-byte Folded Spill
	orr.16b	v25, v6, v18
	orr.16b	v6, v3, v18
	xtn.2s	v5, v5
	xtn.2s	v3, v7
	xtn.2s	v4, v4
	str	q19, [sp, #16]                  ; 16-byte Spill
	tbz	w14, #7, LBB0_29
; %bb.28:                               ; %cond.load57
	add	x13, x15, #28
	ld1.s	{ v27 }[3], [x13]
LBB0_29:                                ; %else58
	str	q23, [sp, #272]                 ; 16-byte Spill
	ldp	q29, q23, [sp, #480]            ; 32-byte Folded Reload
	and.16b	v18, v29, v21
	and.16b	v19, v23, v21
	and.16b	v20, v16, v21
	and.16b	v21, v2, v21
	umull.2d	v7, v22, v17
	stp	q24, q6, [sp, #128]             ; 32-byte Folded Spill
	mov.16b	v2, v6
	umlal.2d	v2, v4, v17
	str	q2, [sp, #240]                  ; 16-byte Spill
	str	q25, [sp, #112]                 ; 16-byte Spill
	mov.16b	v2, v25
	umlal.2d	v2, v5, v17
	str	q2, [sp, #224]                  ; 16-byte Spill
	mov.16b	v2, v24
	umlal.2d	v2, v3, v17
	stp	q7, q2, [sp, #192]              ; 32-byte Folded Spill
	sshll.2d	v2, v12, #0
	sshll.2d	v3, v11, #0
	add	x13, sp, #1504
	add	x14, x13, x10
	str	q27, [sp]                       ; 16-byte Spill
	stp	q26, q27, [x14]
	str	q26, [sp, #64]                  ; 16-byte Spill
	mov	w14, #32                        ; =0x20
	dup.2d	v4, x14
	ldr	q5, [sp, #544]                  ; 16-byte Reload
	orr.16b	v6, v5, v4
	str	q6, [sp, #464]                  ; 16-byte Spill
	ldr	q6, [sp, #528]                  ; 16-byte Reload
	orr.16b	v7, v6, v4
	str	q7, [sp, #448]                  ; 16-byte Spill
	orr.16b	v7, v1, v4
	str	q7, [sp, #432]                  ; 16-byte Spill
	ldr	q7, [sp, #512]                  ; 16-byte Reload
	orr.16b	v4, v7, v4
	str	q4, [sp, #416]                  ; 16-byte Spill
	mov	w14, #64                        ; =0x40
	dup.2d	v4, x14
	orr.16b	v17, v5, v4
	orr.16b	v16, v6, v4
	stp	q16, q17, [sp, #384]            ; 32-byte Folded Spill
	orr.16b	v16, v1, v4
	orr.16b	v4, v7, v4
	stp	q4, q16, [sp, #352]             ; 32-byte Folded Spill
	mov	w14, #96                        ; =0x60
	dup.2d	v4, x14
	orr.16b	v5, v5, v4
	str	q5, [sp, #336]                  ; 16-byte Spill
	orr.16b	v5, v6, v4
	str	q5, [sp, #320]                  ; 16-byte Spill
	orr.16b	v5, v1, v4
	orr.16b	v4, v7, v4
	stp	q4, q5, [sp, #288]              ; 32-byte Folded Spill
	ldr	q4, [sp, #1616]
	ldr	q5, [sp, #1600]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	and.16b	v7, v11, v4
	and.16b	v16, v12, v5
	ldr	q4, [sp, #1584]
	ldr	q5, [sp, #1568]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	and.16b	v25, v11, v4
	and.16b	v17, v12, v5
	ldr	q4, [sp, #1552]
	ldr	q5, [sp, #1536]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	and.16b	v26, v11, v4
	and.16b	v27, v12, v5
	fmov	x14, d1
	add	x13, x13, x14
	ldp	q5, q4, [x13]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	and.16b	v28, v11, v4
	and.16b	v5, v12, v5
	mov	w13, #4                         ; =0x4
	dup.2d	v4, x13
	and.16b	v29, v29, v4
	and.16b	v31, v3, v4
	and.16b	v9, v2, v4
	and.16b	v10, v23, v4
	b	LBB0_31
LBB0_30:                                ; %else230
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmul.4s	v6, v22, v22
	fmul.4s	v22, v14, v14
	fadd.4s	v22, v5, v22
	fadd.4s	v23, v28, v6
	fmul.4s	v6, v24, v24
	fmul.4s	v4, v4, v4
	fadd.4s	v4, v27, v4
	fadd.4s	v6, v26, v6
	fmul.4s	v2, v2, v2
	fmul.4s	v24, v30, v30
	fadd.4s	v24, v17, v24
	fadd.4s	v2, v25, v2
	sshll.2d	v30, v12, #0
	sshll.2d	v8, v11, #0
	fmul.4s	v13, v15, v15
	fmul.4s	v3, v3, v3
	fadd.4s	v3, v7, v3
	fadd.4s	v13, v16, v13
	dup.2d	v14, x13
	ldr	q15, [sp, #480]                 ; 16-byte Reload
	and.16b	v15, v15, v14
	add.2d	v29, v29, v15
	ldr	q15, [sp, #496]                 ; 16-byte Reload
	and.16b	v15, v15, v14
	add.2d	v10, v10, v15
	and.16b	v8, v8, v14
	add.2d	v31, v31, v8
	and.16b	v30, v30, v14
	add.2d	v9, v9, v30
	bit.16b	v28, v23, v11
	bit.16b	v5, v22, v12
	bit.16b	v26, v6, v11
	bit.16b	v27, v4, v12
	bit.16b	v25, v2, v11
	bit.16b	v17, v24, v12
	bit.16b	v16, v13, v12
	bit.16b	v7, v3, v11
	fmov	x14, d9
	cmp	x14, #8
	b.ge	LBB0_95
LBB0_31:                                ; %direct.true56
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w14, s0
	shl.2d	v15, v9, #5
	orr.16b	v2, v15, v1
	add.2d	v2, v21, v2
	movi.2d	v14, #0000000000000000
	movi.2d	v22, #0000000000000000
	tbnz	w14, #0, LBB0_66
; %bb.32:                               ; %else62
                                        ;   in Loop: Header=BB0_31 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_67
LBB0_33:                                ; %else65
                                        ;   in Loop: Header=BB0_31 Depth=1
	shl.2d	v8, v10, #5
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	orr.16b	v2, v8, v2
	add.2d	v2, v19, v2
	tbnz	w14, #2, LBB0_68
LBB0_34:                                ; %else68
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w14, #3, LBB0_69
LBB0_35:                                ; %else71
                                        ;   in Loop: Header=BB0_31 Depth=1
	shl.2d	v13, v31, #5
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	orr.16b	v2, v13, v2
	add.2d	v2, v20, v2
	tbnz	w14, #4, LBB0_70
LBB0_36:                                ; %else74
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w14, #5, LBB0_71
LBB0_37:                                ; %else77
                                        ;   in Loop: Header=BB0_31 Depth=1
	shl.2d	v23, v29, #5
	ldr	q2, [sp, #512]                  ; 16-byte Reload
	orr.16b	v2, v23, v2
	add.2d	v2, v18, v2
	tbnz	w14, #6, LBB0_72
LBB0_38:                                ; %else80
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbz	w14, #7, LBB0_40
LBB0_39:                                ; %cond.load82
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x14, v2[1]
	ld1.s	{ v22 }[3], [x14]
LBB0_40:                                ; %else83
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	w14, s0
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	add.2d	v2, v15, v2
	add.2d	v2, v21, v2
	movi.2d	v4, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w14, #0, LBB0_73
; %bb.41:                               ; %else90
                                        ;   in Loop: Header=BB0_31 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_74
LBB0_42:                                ; %else96
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	add.2d	v2, v8, v2
	add.2d	v2, v19, v2
	tbnz	w14, #2, LBB0_75
LBB0_43:                                ; %else102
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w14, #3, LBB0_76
LBB0_44:                                ; %else108
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q2, [sp, #464]                  ; 16-byte Reload
	add.2d	v2, v13, v2
	add.2d	v2, v20, v2
	tbnz	w14, #4, LBB0_77
LBB0_45:                                ; %else114
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w14, #5, LBB0_78
LBB0_46:                                ; %else120
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q2, [sp, #416]                  ; 16-byte Reload
	add.2d	v2, v23, v2
	add.2d	v2, v18, v2
	tbnz	w14, #6, LBB0_79
LBB0_47:                                ; %else126
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbz	w14, #7, LBB0_49
LBB0_48:                                ; %cond.load128
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x14, v2[1]
	ld1.s	{ v24 }[3], [x14]
LBB0_49:                                ; %else132
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	w14, s0
	ldr	q2, [sp, #368]                  ; 16-byte Reload
	add.2d	v2, v15, v2
	add.2d	v3, v21, v2
	movi.2d	v30, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbnz	w14, #0, LBB0_80
; %bb.50:                               ; %else139
                                        ;   in Loop: Header=BB0_31 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_81
LBB0_51:                                ; %else145
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	add.2d	v3, v8, v3
	add.2d	v3, v19, v3
	tbnz	w14, #2, LBB0_82
LBB0_52:                                ; %else151
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w14, #3, LBB0_83
LBB0_53:                                ; %else157
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q3, [sp, #400]                  ; 16-byte Reload
	add.2d	v3, v13, v3
	add.2d	v3, v20, v3
	tbnz	w14, #4, LBB0_84
LBB0_54:                                ; %else163
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w14, #5, LBB0_85
LBB0_55:                                ; %else169
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	add.2d	v3, v23, v3
	add.2d	v3, v18, v3
	tbnz	w14, #6, LBB0_86
LBB0_56:                                ; %else175
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbz	w14, #7, LBB0_58
LBB0_57:                                ; %cond.load177
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x14, v3[1]
	ld1.s	{ v2 }[3], [x14]
LBB0_58:                                ; %else181
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	w14, s0
	ldr	q3, [sp, #304]                  ; 16-byte Reload
	add.2d	v3, v15, v3
	add.2d	v6, v21, v3
	movi.2d	v15, #0000000000000000
	movi.2d	v3, #0000000000000000
	tbnz	w14, #0, LBB0_87
; %bb.59:                               ; %else188
                                        ;   in Loop: Header=BB0_31 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_88
LBB0_60:                                ; %else194
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q6, [sp, #320]                  ; 16-byte Reload
	add.2d	v6, v8, v6
	add.2d	v6, v19, v6
	tbnz	w14, #2, LBB0_89
LBB0_61:                                ; %else200
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w14, #3, LBB0_90
LBB0_62:                                ; %else206
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q6, [sp, #336]                  ; 16-byte Reload
	add.2d	v6, v13, v6
	add.2d	v6, v20, v6
	tbnz	w14, #4, LBB0_91
LBB0_63:                                ; %else212
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbnz	w14, #5, LBB0_92
LBB0_64:                                ; %else218
                                        ;   in Loop: Header=BB0_31 Depth=1
	ldr	q6, [sp, #288]                  ; 16-byte Reload
	add.2d	v6, v23, v6
	add.2d	v6, v18, v6
	tbnz	w14, #6, LBB0_93
LBB0_65:                                ; %else224
                                        ;   in Loop: Header=BB0_31 Depth=1
	tbz	w14, #7, LBB0_30
	b	LBB0_94
LBB0_66:                                ; %cond.load61
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d2
	ldr	s14, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_33
LBB0_67:                                ; %cond.load64
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v2[1]
	ld1.s	{ v14 }[1], [x15]
	shl.2d	v8, v10, #5
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	orr.16b	v2, v8, v2
	add.2d	v2, v19, v2
	tbz	w14, #2, LBB0_34
LBB0_68:                                ; %cond.load67
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d2
	ld1.s	{ v14 }[2], [x15]
	tbz	w14, #3, LBB0_35
LBB0_69:                                ; %cond.load70
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v2[1]
	ld1.s	{ v14 }[3], [x15]
	shl.2d	v13, v31, #5
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	orr.16b	v2, v13, v2
	add.2d	v2, v20, v2
	tbz	w14, #4, LBB0_36
LBB0_70:                                ; %cond.load73
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d2
	ld1.s	{ v22 }[0], [x15]
	tbz	w14, #5, LBB0_37
LBB0_71:                                ; %cond.load76
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v2[1]
	ld1.s	{ v22 }[1], [x15]
	shl.2d	v23, v29, #5
	ldr	q2, [sp, #512]                  ; 16-byte Reload
	orr.16b	v2, v23, v2
	add.2d	v2, v18, v2
	tbz	w14, #6, LBB0_38
LBB0_72:                                ; %cond.load79
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d2
	ld1.s	{ v22 }[2], [x15]
	tbnz	w14, #7, LBB0_39
	b	LBB0_40
LBB0_73:                                ; %cond.load86
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d2
	ldr	s4, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_42
LBB0_74:                                ; %cond.load92
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v2[1]
	ld1.s	{ v4 }[1], [x15]
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	add.2d	v2, v8, v2
	add.2d	v2, v19, v2
	tbz	w14, #2, LBB0_43
LBB0_75:                                ; %cond.load98
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d2
	ld1.s	{ v4 }[2], [x15]
	tbz	w14, #3, LBB0_44
LBB0_76:                                ; %cond.load104
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v2[1]
	ld1.s	{ v4 }[3], [x15]
	ldr	q2, [sp, #464]                  ; 16-byte Reload
	add.2d	v2, v13, v2
	add.2d	v2, v20, v2
	tbz	w14, #4, LBB0_45
LBB0_77:                                ; %cond.load110
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d2
	ld1.s	{ v24 }[0], [x15]
	tbz	w14, #5, LBB0_46
LBB0_78:                                ; %cond.load116
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v2[1]
	ld1.s	{ v24 }[1], [x15]
	ldr	q2, [sp, #416]                  ; 16-byte Reload
	add.2d	v2, v23, v2
	add.2d	v2, v18, v2
	tbz	w14, #6, LBB0_47
LBB0_79:                                ; %cond.load122
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d2
	ld1.s	{ v24 }[2], [x15]
	tbnz	w14, #7, LBB0_48
	b	LBB0_49
LBB0_80:                                ; %cond.load135
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d3
	ldr	s30, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_51
LBB0_81:                                ; %cond.load141
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v3[1]
	ld1.s	{ v30 }[1], [x15]
	ldr	q3, [sp, #384]                  ; 16-byte Reload
	add.2d	v3, v8, v3
	add.2d	v3, v19, v3
	tbz	w14, #2, LBB0_52
LBB0_82:                                ; %cond.load147
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d3
	ld1.s	{ v30 }[2], [x15]
	tbz	w14, #3, LBB0_53
LBB0_83:                                ; %cond.load153
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v3[1]
	ld1.s	{ v30 }[3], [x15]
	ldr	q3, [sp, #400]                  ; 16-byte Reload
	add.2d	v3, v13, v3
	add.2d	v3, v20, v3
	tbz	w14, #4, LBB0_54
LBB0_84:                                ; %cond.load159
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d3
	ld1.s	{ v2 }[0], [x15]
	tbz	w14, #5, LBB0_55
LBB0_85:                                ; %cond.load165
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v3[1]
	ld1.s	{ v2 }[1], [x15]
	ldr	q3, [sp, #352]                  ; 16-byte Reload
	add.2d	v3, v23, v3
	add.2d	v3, v18, v3
	tbz	w14, #6, LBB0_56
LBB0_86:                                ; %cond.load171
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d3
	ld1.s	{ v2 }[2], [x15]
	tbnz	w14, #7, LBB0_57
	b	LBB0_58
LBB0_87:                                ; %cond.load184
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d6
	ldr	s15, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_60
LBB0_88:                                ; %cond.load190
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v15 }[1], [x15]
	ldr	q6, [sp, #320]                  ; 16-byte Reload
	add.2d	v6, v8, v6
	add.2d	v6, v19, v6
	tbz	w14, #2, LBB0_61
LBB0_89:                                ; %cond.load196
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d6
	ld1.s	{ v15 }[2], [x15]
	tbz	w14, #3, LBB0_62
LBB0_90:                                ; %cond.load202
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v15 }[3], [x15]
	ldr	q6, [sp, #336]                  ; 16-byte Reload
	add.2d	v6, v13, v6
	add.2d	v6, v20, v6
	tbz	w14, #4, LBB0_63
LBB0_91:                                ; %cond.load208
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d6
	ld1.s	{ v3 }[0], [x15]
	tbz	w14, #5, LBB0_64
LBB0_92:                                ; %cond.load214
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v3 }[1], [x15]
	ldr	q6, [sp, #288]                  ; 16-byte Reload
	add.2d	v6, v23, v6
	add.2d	v6, v18, v6
	tbz	w14, #6, LBB0_65
LBB0_93:                                ; %cond.load220
                                        ;   in Loop: Header=BB0_31 Depth=1
	fmov	x15, d6
	ld1.s	{ v3 }[2], [x15]
	tbz	w14, #7, LBB0_30
LBB0_94:                                ; %cond.load226
                                        ;   in Loop: Header=BB0_31 Depth=1
	mov.d	x14, v6[1]
	ld1.s	{ v3 }[3], [x14]
	b	LBB0_30
LBB0_95:                                ; %direct.false57
	mov	x13, #0                         ; =0x0
	mov	w14, #1                         ; =0x1
	dup.2d	v2, x14
	ldr	q4, [sp, #80]                   ; 16-byte Reload
	ldp	q6, q3, [sp, #480]              ; 32-byte Folded Reload
	and.16b	v29, v6, v4
	and.16b	v30, v3, v4
	sshll.2d	v3, v11, #0
	and.16b	v31, v3, v4
	sshll.2d	v3, v12, #0
	and.16b	v8, v3, v4
	ushll2.2d	v3, v11, #0
	and.16b	v9, v3, v2
	ushll2.2d	v3, v12, #0
	and.16b	v10, v3, v2
	ushll.2d	v3, v11, #0
	and.16b	v11, v3, v2
	ushll.2d	v3, v12, #0
	and.16b	v12, v3, v2
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v13, #0000000000000000
	b	LBB0_97
LBB0_96:                                ; %else280
                                        ;   in Loop: Header=BB0_97 Depth=1
	add.2d	v4, v4, v10
	add.2d	v24, v24, v11
	add.2d	v13, v13, v9
	add.2d	v2, v2, v12
	fmov	x13, d2
	cmp	x13, #8
	b.ge	LBB0_129
LBB0_97:                                ; %direct.true83
                                        ; =>This Inner Loop Header: Depth=1
	fmov	w14, s0
	add	x13, x11, x13, lsl #5
	movi.2d	v15, #0000000000000000
	movi.2d	v14, #0000000000000000
	tbnz	w14, #0, LBB0_113
; %bb.98:                               ; %else234
                                        ;   in Loop: Header=BB0_97 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_114
LBB0_99:                                ; %else237
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbnz	w14, #2, LBB0_115
LBB0_100:                               ; %else240
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbnz	w14, #3, LBB0_116
LBB0_101:                               ; %else243
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbnz	w14, #4, LBB0_117
LBB0_102:                               ; %else246
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbnz	w14, #5, LBB0_118
LBB0_103:                               ; %else249
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbnz	w14, #6, LBB0_119
LBB0_104:                               ; %else252
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbnz	w14, #7, LBB0_120
LBB0_105:                               ; %else255
                                        ;   in Loop: Header=BB0_97 Depth=1
	fmov	w13, s0
	shl.2d	v3, v2, #5
	orr.16b	v3, v3, v1
	add.2d	v3, v8, v3
	tbnz	w13, #0, LBB0_121
LBB0_106:                               ; %else259
                                        ;   in Loop: Header=BB0_97 Depth=1
	and	w13, w13, #0xff
	tbnz	w13, #1, LBB0_122
LBB0_107:                               ; %else262
                                        ;   in Loop: Header=BB0_97 Depth=1
	shl.2d	v3, v4, #5
	ldr	q6, [sp, #528]                  ; 16-byte Reload
	orr.16b	v3, v3, v6
	add.2d	v3, v30, v3
	tbnz	w13, #2, LBB0_123
LBB0_108:                               ; %else265
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbnz	w13, #3, LBB0_124
LBB0_109:                               ; %else268
                                        ;   in Loop: Header=BB0_97 Depth=1
	shl.2d	v3, v24, #5
	ldr	q6, [sp, #544]                  ; 16-byte Reload
	orr.16b	v3, v3, v6
	add.2d	v3, v31, v3
	tbnz	w13, #4, LBB0_125
LBB0_110:                               ; %else271
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbnz	w13, #5, LBB0_126
LBB0_111:                               ; %else274
                                        ;   in Loop: Header=BB0_97 Depth=1
	shl.2d	v3, v13, #5
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	orr.16b	v3, v3, v6
	add.2d	v3, v29, v3
	tbnz	w13, #6, LBB0_127
LBB0_112:                               ; %else277
                                        ;   in Loop: Header=BB0_97 Depth=1
	tbz	w13, #7, LBB0_96
	b	LBB0_128
LBB0_113:                               ; %cond.load233
                                        ;   in Loop: Header=BB0_97 Depth=1
	ldr	s15, [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_99
LBB0_114:                               ; %cond.load236
                                        ;   in Loop: Header=BB0_97 Depth=1
	add	x15, x13, #4
	ld1.s	{ v15 }[1], [x15]
	tbz	w14, #2, LBB0_100
LBB0_115:                               ; %cond.load239
                                        ;   in Loop: Header=BB0_97 Depth=1
	add	x15, x13, #8
	ld1.s	{ v15 }[2], [x15]
	tbz	w14, #3, LBB0_101
LBB0_116:                               ; %cond.load242
                                        ;   in Loop: Header=BB0_97 Depth=1
	add	x15, x13, #12
	ld1.s	{ v15 }[3], [x15]
	tbz	w14, #4, LBB0_102
LBB0_117:                               ; %cond.load245
                                        ;   in Loop: Header=BB0_97 Depth=1
	add	x15, x13, #16
	ld1.s	{ v14 }[0], [x15]
	tbz	w14, #5, LBB0_103
LBB0_118:                               ; %cond.load248
                                        ;   in Loop: Header=BB0_97 Depth=1
	add	x15, x13, #20
	ld1.s	{ v14 }[1], [x15]
	tbz	w14, #6, LBB0_104
LBB0_119:                               ; %cond.load251
                                        ;   in Loop: Header=BB0_97 Depth=1
	add	x15, x13, #24
	ld1.s	{ v14 }[2], [x15]
	tbz	w14, #7, LBB0_105
LBB0_120:                               ; %cond.load254
                                        ;   in Loop: Header=BB0_97 Depth=1
	add	x13, x13, #28
	ld1.s	{ v14 }[3], [x13]
	fmov	w13, s0
	shl.2d	v3, v2, #5
	orr.16b	v3, v3, v1
	add.2d	v3, v8, v3
	tbz	w13, #0, LBB0_106
LBB0_121:                               ; %cond.store
                                        ;   in Loop: Header=BB0_97 Depth=1
	fmov	x14, d3
	str	s15, [x14]
	and	w13, w13, #0xff
	tbz	w13, #1, LBB0_107
LBB0_122:                               ; %cond.store260
                                        ;   in Loop: Header=BB0_97 Depth=1
	mov.d	x14, v3[1]
	st1.s	{ v15 }[1], [x14]
	shl.2d	v3, v4, #5
	ldr	q6, [sp, #528]                  ; 16-byte Reload
	orr.16b	v3, v3, v6
	add.2d	v3, v30, v3
	tbz	w13, #2, LBB0_108
LBB0_123:                               ; %cond.store263
                                        ;   in Loop: Header=BB0_97 Depth=1
	fmov	x14, d3
	st1.s	{ v15 }[2], [x14]
	tbz	w13, #3, LBB0_109
LBB0_124:                               ; %cond.store266
                                        ;   in Loop: Header=BB0_97 Depth=1
	mov.d	x14, v3[1]
	st1.s	{ v15 }[3], [x14]
	shl.2d	v3, v24, #5
	ldr	q6, [sp, #544]                  ; 16-byte Reload
	orr.16b	v3, v3, v6
	add.2d	v3, v31, v3
	tbz	w13, #4, LBB0_110
LBB0_125:                               ; %cond.store269
                                        ;   in Loop: Header=BB0_97 Depth=1
	fmov	x14, d3
	str	s14, [x14]
	tbz	w13, #5, LBB0_111
LBB0_126:                               ; %cond.store272
                                        ;   in Loop: Header=BB0_97 Depth=1
	mov.d	x14, v3[1]
	st1.s	{ v14 }[1], [x14]
	shl.2d	v3, v13, #5
	ldr	q6, [sp, #512]                  ; 16-byte Reload
	orr.16b	v3, v3, v6
	add.2d	v3, v29, v3
	tbz	w13, #6, LBB0_112
LBB0_127:                               ; %cond.store275
                                        ;   in Loop: Header=BB0_97 Depth=1
	fmov	x14, d3
	st1.s	{ v14 }[2], [x14]
	tbz	w13, #7, LBB0_96
LBB0_128:                               ; %cond.store278
                                        ;   in Loop: Header=BB0_97 Depth=1
	mov.d	x13, v3[1]
	st1.s	{ v14 }[3], [x13]
	b	LBB0_96
LBB0_129:                               ; %direct.false84
	ldr	q13, [sp, #272]                 ; 16-byte Reload
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp]                        ; 16-byte Reload
	and.16b	v3, v2, v3
	zip1.8b	v4, v13, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q6, [sp, #64]                   ; 16-byte Reload
	and.16b	v6, v4, v6
	fmul.4s	v6, v6, v6
	fmul.4s	v3, v3, v3
	fadd.4s	v3, v3, v28
	fadd.4s	v5, v6, v5
	and.16b	v4, v4, v5
	and.16b	v2, v2, v3
	ldr	q28, [sp, #160]                 ; 16-byte Reload
	zip2.8b	v3, v28, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bit.16b	v2, v23, v3
	movi.2d	v3, #0000000000000000
	mov.b	v3[2], v28[1]
	mov.b	v3[4], v28[2]
	mov.b	v3[6], v28[3]
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	bsl.16b	v3, v22, v4
	fadd.4s	v3, v27, v3
	fadd.4s	v2, v26, v2
	fadd.4s	v2, v25, v2
	fadd.4s	v3, v17, v3
	fadd.4s	v4, v16, v3
	fadd.4s	v7, v7, v2
	ldr	q2, [sp, #96]                   ; 16-byte Reload
	ldp	q5, q3, [sp, #32]               ; 32-byte Folded Reload
	uzp1.4s	v2, v2, v5
	ldr	q5, [sp, #16]                   ; 16-byte Reload
	uzp1.4s	v16, v5, v3
	movi.4s	v3, #1
	eor.16b	v5, v2, v3
	mov.s	w15, v5[1]
	eor.16b	v22, v16, v3
	mov.s	w0, v5[2]
	mov.s	w1, v5[3]
	fmov	w14, s5
	add	x13, sp, #632
	bfxil	x13, x14, #0, #3
	str	d28, [sp, #632]
	ldrb	w16, [x13]
	umov.b	w13, v28[0]
	and	x14, x14, #0x7
	stp	q4, q7, [sp, #896]
	add	x17, sp, #896
	ldr	s3, [x17, x14, lsl #2]
	add	x17, sp, #632
	ands	w14, w13, #0x1
	tst	w14, w16
	movi.2d	v5, #0000000000000000
	fcsel	s17, s3, s5, ne
	add	x16, sp, #632
	bfxil	x16, x15, #0, #3
	ldrb	w16, [x16]
	and	x2, x15, #0x7
	umov.b	w15, v28[1]
	stp	q4, q7, [sp, #864]
	add	x3, sp, #864
	ldr	s3, [x3, x2, lsl #2]
	ands	w2, w15, #0x1
	tst	w2, w16
	fcsel	s3, s3, s5, ne
	add	x16, sp, #632
	bfxil	x16, x0, #0, #3
	ldrb	w2, [x16]
	umov.b	w16, v28[2]
	and	x0, x0, #0x7
	stp	q4, q7, [sp, #832]
	add	x3, sp, #832
	ldr	s6, [x3, x0, lsl #2]
	ands	w0, w16, #0x1
	tst	w0, w2
	fcsel	s23, s6, s5, ne
	add	x0, sp, #632
	bfxil	x0, x1, #0, #3
	ldrb	w2, [x0]
	and	x1, x1, #0x7
	umov.b	w0, v28[3]
	stp	q4, q7, [sp, #800]
	add	x3, sp, #800
	ldr	s6, [x3, x1, lsl #2]
	ands	w1, w0, #0x1
	tst	w1, w2
	mov.s	w3, v22[1]
	fcsel	s24, s6, s5, ne
	mov.s	w4, v22[2]
	mov.s	w5, v22[3]
	fmov	w1, s22
	and	x2, x1, #0x7
	add	x6, sp, #632
	bfxil	x6, x1, #0, #3
	ldrb	w6, [x6]
	umov.b	w1, v28[4]
	and	w6, w1, w6
	str	q7, [sp, #1040]
	str	q4, [sp, #1024]
	add	x7, sp, #1024
	ldr	s6, [x7, x2, lsl #2]
	tst	w6, #0x1
	add	x2, sp, #632
	bfxil	x2, x3, #0, #3
	ldrb	w6, [x2]
	umov.b	w2, v28[5]
	and	x3, x3, #0x7
	stp	q4, q7, [sp, #992]
	add	x7, sp, #992
	ldr	s22, [x7, x3, lsl #2]
	fcsel	s6, s6, s5, ne
	ands	w3, w2, #0x1
	tst	w3, w6
	fcsel	s22, s22, s5, ne
	add	x3, sp, #632
	bfxil	x3, x4, #0, #3
	ldrb	w6, [x3]
	and	x4, x4, #0x7
	umov.b	w3, v28[6]
	stp	q4, q7, [sp, #960]
	add	x7, sp, #960
	ldr	s25, [x7, x4, lsl #2]
	ands	w4, w3, #0x1
	tst	w4, w6
	fcsel	s25, s25, s5, ne
	add	x4, sp, #632
	bfxil	x4, x5, #0, #3
	ldrb	w6, [x4]
	and	x5, x5, #0x7
	umov.b	w4, v28[7]
	stp	q4, q7, [sp, #928]
	add	x7, sp, #928
	ldr	s26, [x7, x5, lsl #2]
	ands	w5, w4, #0x1
	tst	w5, w6
	fcsel	s26, s26, s5, ne
	mov.s	v6[1], v22[0]
	mov.s	v6[2], v25[0]
	mov.s	v6[3], v26[0]
	mov.s	v17[1], v3[0]
	mov.s	v17[2], v23[0]
	mov.s	v17[3], v24[0]
	fadd.4s	v3, v4, v17
	fadd.4s	v4, v7, v6
	movi.4s	v6, #2
	eor.16b	v7, v16, v6
	eor.16b	v2, v2, v6
	fmov	w5, s2
	add	x6, sp, #632
	bfxil	x6, x5, #0, #3
	ldrb	w6, [x6]
	and	x5, x5, #0x7
	stp	q3, q4, [sp, #768]
	add	x7, sp, #768
	ldr	s2, [x7, x5, lsl #2]
	tst	w14, w6
	fcsel	s2, s2, s5, ne
	fmov	w5, s7
	and	x6, x5, #0x7
	bfxil	x17, x5, #0, #3
	ldrb	w17, [x17]
	and	w17, w1, w17
	stp	q3, q4, [sp, #736]
	add	x5, sp, #736
	ldr	s6, [x5, x6, lsl #2]
	tst	w17, #0x1
	fcsel	s6, s6, s5, ne
	fadd.4s	v4, v4, v6
	tst	w14, w1
	fcsel	s4, s4, s5, ne
	ands	w13, w13, #0x1
	fadd.4s	v2, v3, v2
	fadd	s2, s2, s4
	fcsel	s3, s2, s5, ne
	tst	w15, #0x1
	fcsel	s6, s3, s5, ne
	tst	w16, #0x1
	fcsel	s7, s3, s5, ne
	tst	w0, #0x1
	fcsel	s16, s3, s5, ne
	tst	w13, w1
	fcsel	s2, s2, s5, ne
	tst	w2, #0x1
	fcsel	s17, s3, s5, ne
	tst	w3, #0x1
	fcsel	s22, s3, s5, ne
	tst	w4, #0x1
Lloh16:
	adrp	x13, lCPI0_11@PAGE
Lloh17:
	ldr	d4, [x13, lCPI0_11@PAGEOFF]
	shl.8b	v23, v13, #7
	cmlt.8b	v23, v23, #0
	and.8b	v4, v23, v4
	addv.8b	b4, v4
	fcsel	s23, s3, s5, ne
	mov.s	v3[1], v6[0]
	mov.s	v3[2], v7[0]
	mov.s	v3[3], v16[0]
	mov.s	v2[1], v17[0]
	mov.s	v2[2], v22[0]
	mov.s	v2[3], v23[0]
	rbit	w12, w12
	clz	w12, w12
	stp	q3, q2, [sp, #704]
	and	x12, x12, #0x7
	add	x13, sp, #704
	ldr	s2, [x13, x12, lsl #2]
	mov	b3, v13[0]
	mov.b	v3[4], v13[1]
	ushll.2d	v3, v3, #0
	shl.2d	v3, v3, #63
	cmlt.2d	v3, v3, #0
	ldr	q6, [sp, #176]                  ; 16-byte Reload
	and.16b	v3, v3, v6
	mov	b6, v13[2]
	mov.b	v6[4], v13[3]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldp	q7, q16, [sp, #112]             ; 32-byte Folded Reload
	and.16b	v6, v6, v7
	mov	b7, v13[4]
	mov.b	v7[4], v13[5]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v7, v7, v16
	mov	b16, v13[6]
	mov.b	v16[4], v13[7]
	ushll.2d	v16, v16, #0
	shl.2d	v16, v16, #63
	cmlt.2d	v16, v16, #0
	ldr	q17, [sp, #144]                 ; 16-byte Reload
	and.16b	v16, v16, v17
	stp	q7, q16, [sp, #672]
	stp	q3, q6, [sp, #640]
	and	x12, x9, #0x7
	add	x13, sp, #640
	ldr	x13, [x13, x12, lsl #3]
	fmov	w12, s4
	sub	x13, x13, x9
	add	x11, x11, x13, lsl #2
	add	x13, sp, #1216
	add	x13, x13, x10
	ldr	q3, [x13]
	tbnz	w12, #0, LBB0_204
; %bb.130:                              ; %else283
	tbnz	w12, #1, LBB0_205
LBB0_131:                               ; %else286
	tbnz	w12, #2, LBB0_206
LBB0_132:                               ; %else289
	tbnz	w12, #3, LBB0_207
LBB0_133:                               ; %else292
	ldr	q7, [x13, #16]
	tbnz	w12, #4, LBB0_208
LBB0_134:                               ; %else295
	mov	w13, #1115815936                ; =0x42820000
	tbnz	w12, #5, LBB0_209
LBB0_135:                               ; %else298
	fadd	s2, s2, s5
	fmov	s5, w13
	tbnz	w12, #6, LBB0_210
LBB0_136:                               ; %else301
	fdiv	s2, s2, s5
	tbz	w12, #7, LBB0_138
LBB0_137:                               ; %cond.load303
	add	x11, x11, #28
	ld1.s	{ v7 }[3], [x11]
LBB0_138:                               ; %else304
	mov	x13, #0                         ; =0x0
	add	x11, sp, #1216
	add	x11, x11, x10
	stp	q3, q7, [x11]
	mov	w11, #50604                     ; =0xc5ac
	movk	w11, #14119, lsl #16
	fmov	s3, w11
	fadd	s2, s2, s3
	fsqrt	s2, s2
	dup.4s	v5, v2[0]
	ldr	q2, [sp, #192]                  ; 16-byte Reload
	fmov	x11, d2
	add	x11, x8, x11, lsl #2
	movi.2d	v7, #0000000000000000
	fmov	w12, s0
	movi.2d	v16, #0000000000000000
	movi.2d	v17, #0000000000000000
	movi.2d	v22, #0000000000000000
	b	LBB0_140
LBB0_139:                               ; %else420
                                        ;   in Loop: Header=BB0_140 Depth=1
	add.2d	v16, v16, v10
	add.2d	v17, v17, v11
	add.2d	v22, v22, v9
	add.2d	v7, v7, v12
	fmov	x13, d7
	cmp	x13, #8
	b.ge	LBB0_188
LBB0_140:                               ; %direct.true107
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v2, v7, #5
	orr.16b	v3, v2, v1
	add.2d	v6, v21, v3
	movi.2d	v2, #0000000000000000
	movi.2d	v23, #0000000000000000
	tbnz	w12, #0, LBB0_164
; %bb.141:                              ; %else311
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w14, w12, #0xff
	tbnz	w14, #1, LBB0_165
LBB0_142:                               ; %else317
                                        ;   in Loop: Header=BB0_140 Depth=1
	shl.2d	v6, v16, #5
	ldr	q24, [sp, #528]                 ; 16-byte Reload
	orr.16b	v25, v6, v24
	add.2d	v6, v19, v25
	tbnz	w14, #2, LBB0_166
LBB0_143:                               ; %else323
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #3, LBB0_167
LBB0_144:                               ; %else329
                                        ;   in Loop: Header=BB0_140 Depth=1
	shl.2d	v6, v17, #5
	ldr	q24, [sp, #544]                 ; 16-byte Reload
	orr.16b	v26, v6, v24
	add.2d	v6, v20, v26
	tbnz	w14, #4, LBB0_168
LBB0_145:                               ; %else335
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #5, LBB0_169
LBB0_146:                               ; %else341
                                        ;   in Loop: Header=BB0_140 Depth=1
	shl.2d	v6, v22, #5
	ldr	q24, [sp, #512]                 ; 16-byte Reload
	orr.16b	v27, v6, v24
	add.2d	v6, v18, v27
	tbnz	w14, #6, LBB0_170
LBB0_147:                               ; %else347
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #7, LBB0_171
LBB0_148:                               ; %else353
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	w14, s0
	add.2d	v6, v8, v3
	movi.2d	v3, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbnz	w14, #0, LBB0_172
LBB0_149:                               ; %else360
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_173
LBB0_150:                               ; %else366
                                        ;   in Loop: Header=BB0_140 Depth=1
	add.2d	v6, v30, v25
	tbnz	w14, #2, LBB0_174
LBB0_151:                               ; %else372
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #3, LBB0_175
LBB0_152:                               ; %else378
                                        ;   in Loop: Header=BB0_140 Depth=1
	add.2d	v6, v31, v26
	tbnz	w14, #4, LBB0_176
LBB0_153:                               ; %else384
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #5, LBB0_177
LBB0_154:                               ; %else390
                                        ;   in Loop: Header=BB0_140 Depth=1
	add.2d	v6, v29, v27
	tbnz	w14, #6, LBB0_178
LBB0_155:                               ; %else396
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #7, LBB0_179
LBB0_156:                               ; %else402
                                        ;   in Loop: Header=BB0_140 Depth=1
	fdiv.4s	v2, v2, v5
	fmov	w14, s0
	fmul.4s	v2, v2, v3
	add	x13, x11, x13, lsl #5
	tbnz	w14, #0, LBB0_180
LBB0_157:                               ; %else406
                                        ;   in Loop: Header=BB0_140 Depth=1
	and	w14, w14, #0xff
	tbnz	w14, #1, LBB0_181
LBB0_158:                               ; %else408
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #2, LBB0_182
LBB0_159:                               ; %else410
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #3, LBB0_183
LBB0_160:                               ; %else412
                                        ;   in Loop: Header=BB0_140 Depth=1
	fdiv.4s	v2, v23, v5
	fmul.4s	v2, v2, v24
	tbnz	w14, #4, LBB0_184
LBB0_161:                               ; %else414
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #5, LBB0_185
LBB0_162:                               ; %else416
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbnz	w14, #6, LBB0_186
LBB0_163:                               ; %else418
                                        ;   in Loop: Header=BB0_140 Depth=1
	tbz	w14, #7, LBB0_139
	b	LBB0_187
LBB0_164:                               ; %cond.load307
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x14, d6
	ldr	s2, [x14]
	and	w14, w12, #0xff
	tbz	w14, #1, LBB0_142
LBB0_165:                               ; %cond.load313
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v2 }[1], [x15]
	shl.2d	v6, v16, #5
	ldr	q24, [sp, #528]                 ; 16-byte Reload
	orr.16b	v25, v6, v24
	add.2d	v6, v19, v25
	tbz	w14, #2, LBB0_143
LBB0_166:                               ; %cond.load319
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d6
	ld1.s	{ v2 }[2], [x15]
	tbz	w14, #3, LBB0_144
LBB0_167:                               ; %cond.load325
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v2 }[3], [x15]
	shl.2d	v6, v17, #5
	ldr	q24, [sp, #544]                 ; 16-byte Reload
	orr.16b	v26, v6, v24
	add.2d	v6, v20, v26
	tbz	w14, #4, LBB0_145
LBB0_168:                               ; %cond.load331
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d6
	ld1.s	{ v23 }[0], [x15]
	tbz	w14, #5, LBB0_146
LBB0_169:                               ; %cond.load337
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v23 }[1], [x15]
	shl.2d	v6, v22, #5
	ldr	q24, [sp, #512]                 ; 16-byte Reload
	orr.16b	v27, v6, v24
	add.2d	v6, v18, v27
	tbz	w14, #6, LBB0_147
LBB0_170:                               ; %cond.load343
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d6
	ld1.s	{ v23 }[2], [x15]
	tbz	w14, #7, LBB0_148
LBB0_171:                               ; %cond.load349
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x14, v6[1]
	ld1.s	{ v23 }[3], [x14]
	fmov	w14, s0
	add.2d	v6, v8, v3
	movi.2d	v3, #0000000000000000
	movi.2d	v24, #0000000000000000
	tbz	w14, #0, LBB0_149
LBB0_172:                               ; %cond.load356
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d6
	ldr	s3, [x15]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_150
LBB0_173:                               ; %cond.load362
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v3 }[1], [x15]
	add.2d	v6, v30, v25
	tbz	w14, #2, LBB0_151
LBB0_174:                               ; %cond.load368
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d6
	ld1.s	{ v3 }[2], [x15]
	tbz	w14, #3, LBB0_152
LBB0_175:                               ; %cond.load374
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v3 }[3], [x15]
	add.2d	v6, v31, v26
	tbz	w14, #4, LBB0_153
LBB0_176:                               ; %cond.load380
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d6
	ld1.s	{ v24 }[0], [x15]
	tbz	w14, #5, LBB0_154
LBB0_177:                               ; %cond.load386
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x15, v6[1]
	ld1.s	{ v24 }[1], [x15]
	add.2d	v6, v29, v27
	tbz	w14, #6, LBB0_155
LBB0_178:                               ; %cond.load392
                                        ;   in Loop: Header=BB0_140 Depth=1
	fmov	x15, d6
	ld1.s	{ v24 }[2], [x15]
	tbz	w14, #7, LBB0_156
LBB0_179:                               ; %cond.load398
                                        ;   in Loop: Header=BB0_140 Depth=1
	mov.d	x14, v6[1]
	ld1.s	{ v24 }[3], [x14]
	fdiv.4s	v2, v2, v5
	fmov	w14, s0
	fmul.4s	v2, v2, v3
	add	x13, x11, x13, lsl #5
	tbz	w14, #0, LBB0_157
LBB0_180:                               ; %cond.store405
                                        ;   in Loop: Header=BB0_140 Depth=1
	str	s2, [x13]
	and	w14, w14, #0xff
	tbz	w14, #1, LBB0_158
LBB0_181:                               ; %cond.store407
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x15, x13, #4
	st1.s	{ v2 }[1], [x15]
	tbz	w14, #2, LBB0_159
LBB0_182:                               ; %cond.store409
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x15, x13, #8
	st1.s	{ v2 }[2], [x15]
	tbz	w14, #3, LBB0_160
LBB0_183:                               ; %cond.store411
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x15, x13, #12
	st1.s	{ v2 }[3], [x15]
	fdiv.4s	v2, v23, v5
	fmul.4s	v2, v2, v24
	tbz	w14, #4, LBB0_161
LBB0_184:                               ; %cond.store413
                                        ;   in Loop: Header=BB0_140 Depth=1
	str	s2, [x13, #16]
	tbz	w14, #5, LBB0_162
LBB0_185:                               ; %cond.store415
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x15, x13, #20
	st1.s	{ v2 }[1], [x15]
	tbz	w14, #6, LBB0_163
LBB0_186:                               ; %cond.store417
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x15, x13, #24
	st1.s	{ v2 }[2], [x15]
	tbz	w14, #7, LBB0_139
LBB0_187:                               ; %cond.store419
                                        ;   in Loop: Header=BB0_140 Depth=1
	add	x13, x13, #28
	st1.s	{ v2 }[3], [x13]
	b	LBB0_139
LBB0_188:                               ; %direct.false108
	add	x11, sp, #1504
	add	x11, x11, x10
	ldp	q1, q0, [x11]
	zip2.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v3, v2, #31
	zip1.8b	v2, v13, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v6, v2, #0
	and.16b	v1, v6, v1
	fmov	w11, s4
	fdiv.4s	v1, v1, v5
	add	x12, sp, #1216
	add	x10, x12, x10
	ldp	q4, q2, [x10]
	and.16b	v4, v6, v4
	fmul.4s	v1, v1, v4
	ldr	q6, [sp, #256]                  ; 16-byte Reload
	ldp	q4, q7, [sp, #208]              ; 32-byte Folded Reload
	stp	q6, q7, [sp, #560]
	str	q4, [sp, #592]
	ldr	q4, [sp, #240]                  ; 16-byte Reload
	str	q4, [sp, #608]
	and	x10, x9, #0x7
	add	x12, sp, #560
	ldr	x10, [x12, x10, lsl #3]
	sub	x9, x10, x9
	add	x8, x8, x9, lsl #2
	tbnz	w11, #0, LBB0_211
; %bb.189:                              ; %else423
	cmlt.4s	v3, v3, #0
	tbnz	w11, #1, LBB0_212
LBB0_190:                               ; %else425
	and.16b	v0, v3, v0
	tbnz	w11, #2, LBB0_213
LBB0_191:                               ; %else427
	fdiv.4s	v0, v0, v5
	and.16b	v2, v3, v2
	tbnz	w11, #3, LBB0_214
LBB0_192:                               ; %else429
	fmul.4s	v0, v0, v2
	tbnz	w11, #4, LBB0_215
LBB0_193:                               ; %else431
	tbnz	w11, #5, LBB0_216
LBB0_194:                               ; %else433
	tbnz	w11, #6, LBB0_217
LBB0_195:                               ; %else435
	tbz	w11, #7, LBB0_197
LBB0_196:                               ; %cond.store436
	add	x8, x8, #28
	st1.s	{ v0 }[3], [x8]
LBB0_197:                               ; %common.ret
	add	sp, sp, #1792
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #80             ; 16-byte Folded Reload
	ret
LBB0_198:                               ; %cond.load36
	ld1.s	{ v26 }[0], [x15]
	tbz	w14, #1, LBB0_21
LBB0_199:                               ; %cond.load39
	add	x17, x15, #4
	ld1.s	{ v26 }[1], [x17]
	tbz	w14, #2, LBB0_22
LBB0_200:                               ; %cond.load42
	add	x17, x15, #8
	ld1.s	{ v26 }[2], [x17]
	tbz	w14, #3, LBB0_23
LBB0_201:                               ; %cond.load45
	add	x17, x15, #12
	ld1.s	{ v26 }[3], [x17]
	adrp	x17, lCPI0_3@PAGE
	adrp	x0, lCPI0_4@PAGE
	adrp	x1, lCPI0_5@PAGE
	ldr	q27, [x16, #16]
	tbz	w14, #4, LBB0_24
LBB0_202:                               ; %cond.load48
	add	x16, x15, #16
	ld1.s	{ v27 }[0], [x16]
	ldr	q3, [x17, lCPI0_3@PAGEOFF]
	ldr	q6, [x0, lCPI0_4@PAGEOFF]
	ldr	q19, [x1, lCPI0_5@PAGEOFF]
	tbz	w14, #5, LBB0_25
LBB0_203:                               ; %cond.load51
	add	x16, x15, #20
	ld1.s	{ v27 }[1], [x16]
	ldp	q21, q20, [sp, #480]            ; 32-byte Folded Reload
	and.16b	v3, v21, v3
	and.16b	v6, v20, v6
	and.16b	v19, v16, v19
	tbnz	w14, #6, LBB0_26
	b	LBB0_27
LBB0_204:                               ; %cond.load282
	ld1.s	{ v3 }[0], [x11]
	tbz	w12, #1, LBB0_131
LBB0_205:                               ; %cond.load285
	add	x14, x11, #4
	ld1.s	{ v3 }[1], [x14]
	tbz	w12, #2, LBB0_132
LBB0_206:                               ; %cond.load288
	add	x14, x11, #8
	ld1.s	{ v3 }[2], [x14]
	tbz	w12, #3, LBB0_133
LBB0_207:                               ; %cond.load291
	add	x14, x11, #12
	ld1.s	{ v3 }[3], [x14]
	ldr	q7, [x13, #16]
	tbz	w12, #4, LBB0_134
LBB0_208:                               ; %cond.load294
	add	x13, x11, #16
	ld1.s	{ v7 }[0], [x13]
	mov	w13, #1115815936                ; =0x42820000
	tbz	w12, #5, LBB0_135
LBB0_209:                               ; %cond.load297
	add	x14, x11, #20
	ld1.s	{ v7 }[1], [x14]
	fadd	s2, s2, s5
	fmov	s5, w13
	tbz	w12, #6, LBB0_136
LBB0_210:                               ; %cond.load300
	add	x13, x11, #24
	ld1.s	{ v7 }[2], [x13]
	fdiv	s2, s2, s5
	tbnz	w12, #7, LBB0_137
	b	LBB0_138
LBB0_211:                               ; %cond.store422
	str	s1, [x8]
	cmlt.4s	v3, v3, #0
	tbz	w11, #1, LBB0_190
LBB0_212:                               ; %cond.store424
	add	x9, x8, #4
	st1.s	{ v1 }[1], [x9]
	and.16b	v0, v3, v0
	tbz	w11, #2, LBB0_191
LBB0_213:                               ; %cond.store426
	add	x9, x8, #8
	st1.s	{ v1 }[2], [x9]
	fdiv.4s	v0, v0, v5
	and.16b	v2, v3, v2
	tbz	w11, #3, LBB0_192
LBB0_214:                               ; %cond.store428
	add	x9, x8, #12
	st1.s	{ v1 }[3], [x9]
	fmul.4s	v0, v0, v2
	tbz	w11, #4, LBB0_193
LBB0_215:                               ; %cond.store430
	str	s0, [x8, #16]
	tbz	w11, #5, LBB0_194
LBB0_216:                               ; %cond.store432
	add	x9, x8, #20
	st1.s	{ v0 }[1], [x9]
	tbz	w11, #6, LBB0_195
LBB0_217:                               ; %cond.store434
	add	x9, x8, #24
	st1.s	{ v0 }[2], [x9]
	tbnz	w11, #7, LBB0_196
	b	LBB0_197
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh16, Lloh17
                                        ; -- End function
	.globl	_llm_rows.packet_batch.blocks   ; -- Begin function llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_3:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_rows
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_rows
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_rows.packet_batch.blocks
lCPI0_0:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.globl	_llm_rows.packet_batch.blocks
	.p2align	2
_llm_rows.packet_batch.blocks:          ; @llm_rows.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB0_90
; %bb.1:                                ; %block.batch.loop.preheader
	stp	d11, d10, [sp, #-128]!          ; 16-byte Folded Spill
	stp	d9, d8, [sp, #16]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #32]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #48]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #112]            ; 16-byte Folded Spill
	sub	sp, sp, #8, lsl #12             ; =32768
	sub	sp, sp, #32
	mov	w8, #0                          ; =0x0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #32
	ldp	w10, w11, [x2, #44]
	ldp	w5, w6, [x2]
Lloh0:
	adrp	x13, lCPI0_0@PAGE
Lloh1:
	ldr	q0, [x13, lCPI0_0@PAGEOFF]
Lloh2:
	adrp	x13, lCPI0_1@PAGE
Lloh3:
	ldr	q1, [x13, lCPI0_1@PAGEOFF]
	add	x13, sp, #32
	movi.4s	v2, #59, lsl #24
	mov	w14, #50604                     ; =0xc5ac
	movk	w14, #14119, lsl #16
	adrp	x15, lCPI0_2@PAGE
	ldp	w7, w16, [x2, #8]
	str	x2, [sp, #16]                   ; 8-byte Spill
	b	LBB0_3
LBB0_2:                                 ; %llm_rows.packet_batch.exit
                                        ;   in Loop: Header=BB0_3 Depth=1
	add	w12, w4, #1
	cmp	w12, w10
	cset	w12, eq
	csinc	w5, wzr, w4, eq
	cinc	w2, w1, eq
	cmp	w2, w11
	cset	w6, eq
	ands	w12, w12, w6
	csel	w6, wzr, w2, ne
	add	w7, w17, w12
	add	w8, w8, #1
	cmp	w8, w3
	b.eq	LBB0_89
LBB0_3:                                 ; %block.batch.loop
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_38 Depth 2
                                        ;       Child Loop BB0_39 Depth 3
                                        ;       Child Loop BB0_41 Depth 3
                                        ;       Child Loop BB0_43 Depth 3
                                        ;       Child Loop BB0_45 Depth 3
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_68 Depth 2
                                        ;     Child Loop BB0_70 Depth 2
                                        ;     Child Loop BB0_73 Depth 2
                                        ;     Child Loop BB0_5 Depth 2
                                        ;     Child Loop BB0_7 Depth 2
                                        ;     Child Loop BB0_9 Depth 2
                                        ;     Child Loop BB0_11 Depth 2
                                        ;     Child Loop BB0_13 Depth 2
                                        ;     Child Loop BB0_15 Depth 2
                                        ;     Child Loop BB0_17 Depth 2
                                        ;     Child Loop BB0_19 Depth 2
                                        ;     Child Loop BB0_21 Depth 2
                                        ;     Child Loop BB0_23 Depth 2
                                        ;     Child Loop BB0_25 Depth 2
                                        ;     Child Loop BB0_27 Depth 2
                                        ;     Child Loop BB0_29 Depth 2
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_33 Depth 2
                                        ;     Child Loop BB0_35 Depth 2
	mov	x17, x7
	mov	x1, x6
	mov	x4, x5
	ubfiz	x5, x5, #5, #32
	cmp	x5, x16
	csel	x6, x5, xzr, ls
	subs	x7, x16, x6
	cmp	x7, #32
	mov	w12, #32                        ; =0x20
	csel	x7, x7, x12, lo
	cmp	x16, x6
	ccmp	x5, x16, #2, hi
	csel	x5, x7, xzr, ls
	cmp	x5, #32
	b.lo	LBB0_36
; %bb.4:                                ; %packet.batch.full.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	ldr	x21, [x0]
	ldr	x5, [x0, #16]
	ldr	x7, [x0, #48]
	lsl	w6, w4, #5
	dup.4s	v3, w6
	orr.16b	v4, v3, v0
	orr.16b	v3, v3, v1
	ushll2.2d	v6, v4, #11
	ushll2.2d	v7, v3, #11
	ushll.2d	v16, v4, #11
	ushll.2d	v17, v3, #11
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #32
	dup.2d	v3, x21
LBB0_5:                                 ; %direct.true.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v4, x19
	add.2d	v5, v4, v17
	add.2d	v18, v4, v7
	add.2d	v19, v4, v16
	add.2d	v4, v4, v6
	add.2d	v4, v3, v4
	add.2d	v19, v3, v19
	add.2d	v18, v3, v18
	add.2d	v5, v3, v5
	mov.d	x21, v5[1]
	fmov	x22, d5
	mov.d	x23, v18[1]
	fmov	x24, d18
	mov.d	x25, v19[1]
	fmov	x26, d19
	mov.d	x27, v4[1]
	ldr	s5, [x26]
	ld1.s	{ v5 }[1], [x25]
	fmov	x25, d4
	ld1.s	{ v5 }[2], [x25]
	ld1.s	{ v5 }[3], [x27]
	ldr	s4, [x22]
	ld1.s	{ v4 }[1], [x21]
	ld1.s	{ v4 }[2], [x24]
	ld1.s	{ v4 }[3], [x23]
	stp	q4, q5, [x20], #32
	add	x19, x19, #4
	cmp	x19, #2048
	b.ne	LBB0_5
; %bb.6:                                ; %direct.false.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q4, q5, [x9]
	fmul.4s	v5, v5, v5
	fmul.4s	v4, v4, v4
	ldp	q18, q19, [x9, #32]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q21, q20, [x9, #64]
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	ldp	q22, q23, [x9, #96]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
	add	x19, x9, #224
	mov	w20, #4                         ; =0x4
LBB0_7:                                 ; %direct.true46.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q25, q24, [x19, #-96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v5, v5, v24
	fadd.4s	v4, v4, v25
	ldp	q25, q24, [x19, #-64]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v19, v19, v24
	fadd.4s	v18, v18, v25
	ldp	q25, q24, [x19, #-32]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v20, v20, v24
	fadd.4s	v21, v21, v25
	ldp	q25, q24, [x19], #128
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v25
	cmp	x20, #508
	add	x20, x20, #4
	b.lo	LBB0_7
; %bb.8:                                ; %direct.true90.i.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
LBB0_9:                                 ; %direct.true90.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x20, x5, x19, lsl #2
	ld1r.4s	{ v24 }, [x20]
	add	x20, x13, x19, lsl #5
	stp	q24, q24, [x20]
	add	x19, x19, #1
	cmp	x19, #512
	b.ne	LBB0_9
; %bb.10:                               ; %direct.false91.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	fadd.4s	v5, v5, v19
	fadd.4s	v4, v4, v18
	fadd.4s	v4, v4, v21
	fadd.4s	v5, v5, v20
	fadd.4s	v5, v5, v23
	fadd.4s	v4, v4, v22
	fmul.4s	v4, v4, v2
	fmul.4s	v18, v5, v2
	dup.4s	v5, w14
	fadd.4s	v19, v18, v5
	fadd.4s	v4, v4, v5
	fsqrt.4s	v18, v4
	fsqrt.4s	v19, v19
	add	x20, sp, #32
	add	x21, sp, #4, lsl #12            ; =16384
	add	x21, x21, #32
LBB0_11:                                ; %direct.true105.i.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q20, q4, [x21], #32
	fdiv.4s	v20, v20, v18
	fdiv.4s	v4, v4, v19
	ldp	q21, q22, [x20], #32
	fmul.4s	v22, v4, v22
	fmul.4s	v20, v20, v21
	dup.2d	v4, x19
	add.2d	v21, v4, v17
	add.2d	v23, v4, v7
	add.2d	v24, v4, v16
	add.2d	v25, v4, v6
	dup.2d	v4, x7
	add.2d	v23, v4, v23
	add.2d	v21, v4, v21
	mov.d	x22, v21[1]
	fmov	x23, d21
	str	s20, [x23]
	st1.s	{ v20 }[1], [x22]
	mov.d	x22, v23[1]
	add.2d	v21, v4, v24
	fmov	x23, d23
	st1.s	{ v20 }[2], [x23]
	st1.s	{ v20 }[3], [x22]
	mov.d	x22, v21[1]
	fmov	x23, d21
	str	s22, [x23]
	st1.s	{ v22 }[1], [x22]
	add.2d	v20, v4, v25
	mov.d	x22, v20[1]
	fmov	x23, d20
	st1.s	{ v22 }[2], [x23]
	st1.s	{ v22 }[3], [x22]
	add	x19, x19, #4
	cmp	x19, #2048
	b.ne	LBB0_11
; %bb.12:                               ; %llm_rows.exit.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	orr	w19, w6, #0x8
	dup.4s	v6, w19
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #11
	ushll2.2d	v7, v17, #11
	ushll.2d	v16, v16, #11
	ushll.2d	v17, v17, #11
	add	x19, sp, #4, lsl #12            ; =16384
	add	x19, x19, #32
LBB0_13:                                ; %direct.true.i6.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x7
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v3, v18
	add.2d	v21, v3, v21
	add.2d	v20, v3, v20
	add.2d	v19, v3, v19
	mov.d	x20, v19[1]
	fmov	x21, d19
	mov.d	x22, v20[1]
	fmov	x23, d20
	mov.d	x24, v21[1]
	fmov	x25, d21
	mov.d	x26, v18[1]
	ldr	s19, [x25]
	ld1.s	{ v19 }[1], [x24]
	fmov	x24, d18
	ld1.s	{ v19 }[2], [x24]
	ld1.s	{ v19 }[3], [x26]
	ldr	s18, [x21]
	ld1.s	{ v18 }[1], [x20]
	ld1.s	{ v18 }[2], [x23]
	ld1.s	{ v18 }[3], [x22]
	stp	q18, q19, [x19], #32
	add	x7, x7, #4
	cmp	x7, #2048
	b.ne	LBB0_13
; %bb.14:                               ; %direct.false.i12.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q18, q19, [x9]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	add	x7, x9, #224
	mov	w19, #4                         ; =0x4
LBB0_15:                                ; %direct.true46.i20.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q26, [x7, #-96]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	ldp	q27, q26, [x7, #-64]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x7, #-32]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x7], #128
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	cmp	x19, #508
	add	x19, x19, #4
	b.lo	LBB0_15
; %bb.16:                               ; %direct.true90.i35.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
LBB0_17:                                ; %direct.true90.i35.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x19, x5, x7, lsl #2
	ld1r.4s	{ v26 }, [x19]
	add	x19, x13, x7, lsl #5
	stp	q26, q26, [x19]
	add	x7, x7, #1
	cmp	x7, #512
	b.ne	LBB0_17
; %bb.18:                               ; %direct.false91.i42.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v23
	fadd.4s	v19, v19, v22
	fadd.4s	v19, v19, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v18, v2
	fmul.4s	v19, v19, v2
	fadd.4s	v19, v19, v5
	fadd.4s	v18, v18, v5
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v19
	add	x19, sp, #32
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #32
LBB0_19:                                ; %direct.true105.i43.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q21, q20, [x20], #32
	fdiv.4s	v21, v21, v18
	fdiv.4s	v20, v20, v19
	ldp	q22, q23, [x19], #32
	fmul.4s	v20, v20, v23
	fmul.4s	v21, v21, v22
	dup.2d	v22, x7
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	add.2d	v24, v4, v24
	add.2d	v23, v4, v23
	mov.d	x21, v23[1]
	fmov	x22, d23
	str	s21, [x22]
	st1.s	{ v21 }[1], [x21]
	mov.d	x21, v24[1]
	add.2d	v23, v4, v25
	fmov	x22, d24
	st1.s	{ v21 }[2], [x22]
	st1.s	{ v21 }[3], [x21]
	mov.d	x21, v23[1]
	fmov	x22, d23
	str	s20, [x22]
	st1.s	{ v20 }[1], [x21]
	add.2d	v21, v4, v22
	mov.d	x21, v21[1]
	fmov	x22, d21
	st1.s	{ v20 }[2], [x22]
	st1.s	{ v20 }[3], [x21]
	add	x7, x7, #4
	cmp	x7, #2048
	b.ne	LBB0_19
; %bb.20:                               ; %llm_rows.exit51.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	orr	w19, w6, #0x10
	dup.4s	v6, w19
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #11
	ushll2.2d	v7, v17, #11
	ushll.2d	v16, v16, #11
	ushll.2d	v17, v17, #11
	add	x19, sp, #4, lsl #12            ; =16384
	add	x19, x19, #32
LBB0_21:                                ; %direct.true.i55.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x7
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v3, v18
	add.2d	v21, v3, v21
	add.2d	v20, v3, v20
	add.2d	v19, v3, v19
	mov.d	x20, v19[1]
	fmov	x21, d19
	mov.d	x22, v20[1]
	fmov	x23, d20
	mov.d	x24, v21[1]
	fmov	x25, d21
	mov.d	x26, v18[1]
	ldr	s19, [x25]
	ld1.s	{ v19 }[1], [x24]
	fmov	x24, d18
	ld1.s	{ v19 }[2], [x24]
	ld1.s	{ v19 }[3], [x26]
	ldr	s18, [x21]
	ld1.s	{ v18 }[1], [x20]
	ld1.s	{ v18 }[2], [x23]
	ld1.s	{ v18 }[3], [x22]
	stp	q18, q19, [x19], #32
	add	x7, x7, #4
	cmp	x7, #2048
	b.ne	LBB0_21
; %bb.22:                               ; %direct.false.i61.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q18, q19, [x9]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q20, q21, [x9, #32]
	fmul.4s	v21, v21, v21
	fmul.4s	v20, v20, v20
	ldp	q23, q22, [x9, #64]
	fmul.4s	v22, v22, v22
	fmul.4s	v23, v23, v23
	ldp	q24, q25, [x9, #96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	add	x7, x9, #224
	mov	w19, #4                         ; =0x4
LBB0_23:                                ; %direct.true46.i69.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q27, q26, [x7, #-96]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v19, v19, v26
	fadd.4s	v18, v18, v27
	ldp	q27, q26, [x7, #-64]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v21, v21, v26
	fadd.4s	v20, v20, v27
	ldp	q27, q26, [x7, #-32]
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v22, v22, v26
	fadd.4s	v23, v23, v27
	ldp	q27, q26, [x7], #128
	fmul.4s	v27, v27, v27
	fmul.4s	v26, v26, v26
	fadd.4s	v25, v25, v26
	fadd.4s	v24, v24, v27
	cmp	x19, #508
	add	x19, x19, #4
	b.lo	LBB0_23
; %bb.24:                               ; %direct.true90.i84.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
LBB0_25:                                ; %direct.true90.i84.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x19, x5, x7, lsl #2
	ld1r.4s	{ v26 }, [x19]
	add	x19, x13, x7, lsl #5
	stp	q26, q26, [x19]
	add	x7, x7, #1
	cmp	x7, #512
	b.ne	LBB0_25
; %bb.26:                               ; %direct.false91.i91.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	fadd.4s	v19, v19, v21
	fadd.4s	v18, v18, v20
	fadd.4s	v18, v18, v23
	fadd.4s	v19, v19, v22
	fadd.4s	v19, v19, v25
	fadd.4s	v18, v18, v24
	fmul.4s	v18, v18, v2
	fmul.4s	v19, v19, v2
	fadd.4s	v19, v19, v5
	fadd.4s	v18, v18, v5
	fsqrt.4s	v18, v18
	fsqrt.4s	v19, v19
	add	x19, sp, #32
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #32
LBB0_27:                                ; %direct.true105.i92.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q21, q20, [x20], #32
	fdiv.4s	v21, v21, v18
	fdiv.4s	v20, v20, v19
	ldp	q22, q23, [x19], #32
	fmul.4s	v20, v20, v23
	fmul.4s	v21, v21, v22
	dup.2d	v22, x7
	add.2d	v23, v22, v17
	add.2d	v24, v22, v7
	add.2d	v25, v22, v16
	add.2d	v22, v22, v6
	add.2d	v24, v4, v24
	add.2d	v23, v4, v23
	mov.d	x21, v23[1]
	fmov	x22, d23
	str	s21, [x22]
	st1.s	{ v21 }[1], [x21]
	mov.d	x21, v24[1]
	add.2d	v23, v4, v25
	fmov	x22, d24
	st1.s	{ v21 }[2], [x22]
	st1.s	{ v21 }[3], [x21]
	mov.d	x21, v23[1]
	fmov	x22, d23
	str	s20, [x22]
	st1.s	{ v20 }[1], [x21]
	add.2d	v21, v4, v22
	mov.d	x21, v21[1]
	fmov	x22, d21
	st1.s	{ v20 }[2], [x22]
	st1.s	{ v20 }[3], [x21]
	add	x7, x7, #4
	cmp	x7, #2048
	b.ne	LBB0_27
; %bb.28:                               ; %llm_rows.exit100.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
	orr	w6, w6, #0x18
	dup.4s	v6, w6
	orr.16b	v16, v6, v0
	orr.16b	v17, v6, v1
	ushll2.2d	v6, v16, #11
	ushll2.2d	v7, v17, #11
	ushll.2d	v16, v16, #11
	ushll.2d	v17, v17, #11
	add	x6, sp, #4, lsl #12             ; =16384
	add	x6, x6, #32
LBB0_29:                                ; %direct.true.i104.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	dup.2d	v18, x7
	add.2d	v19, v18, v17
	add.2d	v20, v18, v7
	add.2d	v21, v18, v16
	add.2d	v18, v18, v6
	add.2d	v18, v3, v18
	add.2d	v21, v3, v21
	add.2d	v20, v3, v20
	add.2d	v19, v3, v19
	mov.d	x19, v19[1]
	fmov	x20, d19
	mov.d	x21, v20[1]
	fmov	x22, d20
	mov.d	x23, v21[1]
	fmov	x24, d21
	mov.d	x25, v18[1]
	ldr	s19, [x24]
	ld1.s	{ v19 }[1], [x23]
	fmov	x23, d18
	ld1.s	{ v19 }[2], [x23]
	ld1.s	{ v19 }[3], [x25]
	ldr	s18, [x20]
	ld1.s	{ v18 }[1], [x19]
	ld1.s	{ v18 }[2], [x22]
	ld1.s	{ v18 }[3], [x21]
	stp	q18, q19, [x6], #32
	add	x7, x7, #4
	cmp	x7, #2048
	b.ne	LBB0_29
; %bb.30:                               ; %direct.false.i110.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q3, q18, [x9]
	fmul.4s	v18, v18, v18
	fmul.4s	v3, v3, v3
	ldp	q19, q20, [x9, #32]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	ldp	q22, q21, [x9, #64]
	fmul.4s	v21, v21, v21
	fmul.4s	v22, v22, v22
	ldp	q23, q24, [x9, #96]
	fmul.4s	v24, v24, v24
	fmul.4s	v23, v23, v23
	add	x6, x9, #224
	mov	w7, #4                          ; =0x4
LBB0_31:                                ; %direct.true46.i118.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q26, q25, [x6, #-96]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v18, v18, v25
	fadd.4s	v3, v3, v26
	ldp	q26, q25, [x6, #-64]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v20, v20, v25
	fadd.4s	v19, v19, v26
	ldp	q26, q25, [x6, #-32]
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v21, v21, v25
	fadd.4s	v22, v22, v26
	ldp	q26, q25, [x6], #128
	fmul.4s	v26, v26, v26
	fmul.4s	v25, v25, v25
	fadd.4s	v24, v24, v25
	fadd.4s	v23, v23, v26
	cmp	x7, #508
	add	x7, x7, #4
	b.lo	LBB0_31
; %bb.32:                               ; %direct.true90.i133.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x6, #0                          ; =0x0
LBB0_33:                                ; %direct.true90.i133.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x7, x5, x6, lsl #2
	ld1r.4s	{ v25 }, [x7]
	add	x7, x13, x6, lsl #5
	stp	q25, q25, [x7]
	add	x6, x6, #1
	cmp	x6, #512
	b.ne	LBB0_33
; %bb.34:                               ; %direct.false91.i140.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x5, #0                          ; =0x0
	fadd.4s	v18, v18, v20
	fadd.4s	v3, v3, v19
	fadd.4s	v3, v3, v22
	fadd.4s	v18, v18, v21
	fadd.4s	v18, v18, v24
	fadd.4s	v3, v3, v23
	fmul.4s	v3, v3, v2
	fmul.4s	v18, v18, v2
	fadd.4s	v18, v18, v5
	fadd.4s	v3, v3, v5
	fsqrt.4s	v3, v3
	fsqrt.4s	v5, v18
	add	x6, sp, #32
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #32
LBB0_35:                                ; %direct.true105.i141.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q19, q18, [x7], #32
	fdiv.4s	v19, v19, v3
	fdiv.4s	v18, v18, v5
	ldp	q20, q21, [x6], #32
	fmul.4s	v18, v18, v21
	fmul.4s	v19, v19, v20
	dup.2d	v20, x5
	add.2d	v21, v20, v17
	add.2d	v22, v20, v7
	add.2d	v23, v20, v16
	add.2d	v20, v20, v6
	add.2d	v22, v4, v22
	add.2d	v21, v4, v21
	mov.d	x19, v21[1]
	fmov	x20, d21
	str	s19, [x20]
	st1.s	{ v19 }[1], [x19]
	mov.d	x19, v22[1]
	add.2d	v21, v4, v23
	fmov	x20, d22
	st1.s	{ v19 }[2], [x20]
	st1.s	{ v19 }[3], [x19]
	mov.d	x19, v21[1]
	fmov	x20, d21
	str	s18, [x20]
	st1.s	{ v18 }[1], [x19]
	add.2d	v19, v4, v20
	mov.d	x19, v19[1]
	fmov	x20, d19
	st1.s	{ v18 }[2], [x20]
	st1.s	{ v18 }[3], [x19]
	add	x5, x5, #4
	cmp	x5, #2048
	b.ne	LBB0_35
	b	LBB0_2
LBB0_36:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	lsr	x7, x5, #3
	dup.4s	v3, w14
	cbz	x7, LBB0_47
; %bb.37:                               ; %packet.batch.partial.full.loop.preheader.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	w6, #0                          ; =0x0
	ldr	x19, [x0]
	ldr	x20, [x0, #16]
	lsl	w21, w4, #5
	ldr	x22, [x0, #48]
LBB0_38:                                ; %packet.batch.partial.full.loop.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_39 Depth 3
                                        ;       Child Loop BB0_41 Depth 3
                                        ;       Child Loop BB0_43 Depth 3
                                        ;       Child Loop BB0_45 Depth 3
	mov	x23, #0                         ; =0x0
	add	w24, w21, w6, lsl #3
	dup.4s	v4, w24
	orr.16b	v6, v4, v0
	orr.16b	v7, v4, v1
	ushll2.2d	v4, v6, #11
	ushll2.2d	v5, v7, #11
	ushll.2d	v6, v6, #11
	ushll.2d	v7, v7, #11
	add	x24, sp, #4, lsl #12            ; =16384
	add	x24, x24, #32
LBB0_39:                                ; %direct.true.i153.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	dup.2d	v16, x23
	add.2d	v17, v16, v7
	add.2d	v18, v16, v5
	add.2d	v19, v16, v6
	add.2d	v16, v16, v4
	dup.2d	v20, x19
	add.2d	v16, v20, v16
	add.2d	v19, v20, v19
	add.2d	v18, v20, v18
	add.2d	v17, v20, v17
	mov.d	x25, v17[1]
	fmov	x26, d17
	mov.d	x27, v18[1]
	fmov	x28, d18
	mov.d	x30, v19[1]
	fmov	x12, d19
	mov.d	x2, v16[1]
	ldr	s17, [x12]
	ld1.s	{ v17 }[1], [x30]
	fmov	x12, d16
	ld1.s	{ v17 }[2], [x12]
	ld1.s	{ v17 }[3], [x2]
	ldr	s16, [x26]
	ld1.s	{ v16 }[1], [x25]
	ld1.s	{ v16 }[2], [x28]
	ld1.s	{ v16 }[3], [x27]
	stp	q16, q17, [x24], #32
	add	x23, x23, #4
	cmp	x23, #2048
	b.ne	LBB0_39
; %bb.40:                               ; %direct.false.i159.i
                                        ;   in Loop: Header=BB0_38 Depth=2
	ldp	q16, q17, [x9]
	fmul.4s	v17, v17, v17
	fmul.4s	v16, v16, v16
	ldp	q18, q19, [x9, #32]
	fmul.4s	v19, v19, v19
	fmul.4s	v18, v18, v18
	ldp	q21, q20, [x9, #64]
	fmul.4s	v20, v20, v20
	fmul.4s	v21, v21, v21
	ldp	q22, q23, [x9, #96]
	fmul.4s	v23, v23, v23
	fmul.4s	v22, v22, v22
	add	x23, x9, #224
	mov	w24, #4                         ; =0x4
LBB0_41:                                ; %direct.true46.i167.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q25, q24, [x23, #-96]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v17, v17, v24
	fadd.4s	v16, v16, v25
	ldp	q25, q24, [x23, #-64]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v19, v19, v24
	fadd.4s	v18, v18, v25
	ldp	q25, q24, [x23, #-32]
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v20, v20, v24
	fadd.4s	v21, v21, v25
	ldp	q25, q24, [x23], #128
	fmul.4s	v25, v25, v25
	fmul.4s	v24, v24, v24
	fadd.4s	v23, v23, v24
	fadd.4s	v22, v22, v25
	cmp	x24, #508
	add	x24, x24, #4
	b.lo	LBB0_41
; %bb.42:                               ; %direct.true90.i182.i.preheader
                                        ;   in Loop: Header=BB0_38 Depth=2
	mov	x23, #0                         ; =0x0
LBB0_43:                                ; %direct.true90.i182.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	add	x12, x20, x23, lsl #2
	ld1r.4s	{ v24 }, [x12]
	add	x12, x13, x23, lsl #5
	stp	q24, q24, [x12]
	add	x23, x23, #1
	cmp	x23, #512
	b.ne	LBB0_43
; %bb.44:                               ; %direct.false91.i189.i
                                        ;   in Loop: Header=BB0_38 Depth=2
	mov	x23, #0                         ; =0x0
	fadd.4s	v17, v17, v19
	fadd.4s	v16, v16, v18
	fadd.4s	v16, v16, v21
	fadd.4s	v17, v17, v20
	fadd.4s	v17, v17, v23
	fadd.4s	v16, v16, v22
	fmul.4s	v16, v16, v2
	fmul.4s	v17, v17, v2
	fadd.4s	v17, v17, v3
	fadd.4s	v16, v16, v3
	fsqrt.4s	v16, v16
	fsqrt.4s	v17, v17
	add	x24, sp, #32
	add	x25, sp, #4, lsl #12            ; =16384
	add	x25, x25, #32
LBB0_45:                                ; %direct.true105.i190.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ;     Parent Loop BB0_38 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldp	q19, q18, [x25], #32
	fdiv.4s	v19, v19, v16
	fdiv.4s	v18, v18, v17
	ldp	q20, q21, [x24], #32
	fmul.4s	v18, v18, v21
	fmul.4s	v19, v19, v20
	dup.2d	v20, x23
	add.2d	v21, v20, v7
	add.2d	v22, v20, v5
	add.2d	v23, v20, v6
	add.2d	v20, v20, v4
	dup.2d	v24, x22
	add.2d	v22, v24, v22
	add.2d	v21, v24, v21
	mov.d	x12, v21[1]
	fmov	x2, d21
	str	s19, [x2]
	st1.s	{ v19 }[1], [x12]
	mov.d	x12, v22[1]
	add.2d	v21, v24, v23
	fmov	x2, d22
	st1.s	{ v19 }[2], [x2]
	st1.s	{ v19 }[3], [x12]
	mov.d	x12, v21[1]
	fmov	x2, d21
	str	s18, [x2]
	st1.s	{ v18 }[1], [x12]
	add.2d	v19, v24, v20
	mov.d	x12, v19[1]
	fmov	x2, d19
	st1.s	{ v18 }[2], [x2]
	st1.s	{ v18 }[3], [x12]
	add	x23, x23, #4
	cmp	x23, #2048
	b.ne	LBB0_45
; %bb.46:                               ; %llm_rows.exit198.i
                                        ;   in Loop: Header=BB0_38 Depth=2
	add	w6, w6, #1
	cmp	w6, w7
	b.ne	LBB0_38
LBB0_47:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	and	w5, w5, #0x7
	cbz	w5, LBB0_2
; %bb.48:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.4s	v5, w5
	cmhi.4s	v4, v5, v0
	cmhi.4s	v5, v5, v1
	uzp1.8h	v19, v5, v4
	umaxv.8h	h6, v19
	fmov	w12, s6
	tbz	w12, #0, LBB0_2
; %bb.49:                               ; %direct.activate.i.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x19, #0                         ; =0x0
	ldr	x20, [x0]
	ldr	x6, [x0, #16]
	ldr	x5, [x0, #48]
	lsl	w12, w7, #3
	orr	w12, w12, w4, lsl #5
	dup.4s	v6, w12
	orr.16b	v7, v6, v1
	orr.16b	v6, v6, v0
	and.16b	v16, v4, v6
	and.16b	v17, v5, v7
	ushll2.2d	v6, v16, #11
	ushll2.2d	v7, v17, #11
	ushll.2d	v16, v16, #11
	ushll.2d	v17, v17, #11
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #32
	b	LBB0_51
LBB0_50:                                ; %else455
                                        ;   in Loop: Header=BB0_51 Depth=2
	ldp	q22, q23, [x7]
	bif.16b	v21, v23, v4
	bif.16b	v20, v22, v5
	stp	q20, q21, [x7], #32
	add	x19, x19, #4
	cmp	x19, #2048
	b.eq	LBB0_67
LBB0_51:                                ; %direct.true.i202.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q18, [x15, lCPI0_2@PAGEOFF]
	and.16b	v18, v19, v18
	addv.8h	h18, v18
	fmov	w21, s18
	dup.2d	v22, x19
	add.2d	v20, v22, v17
	dup.2d	v23, x20
	add.2d	v24, v23, v20
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbnz	w21, #0, LBB0_59
; %bb.52:                               ; %else
                                        ;   in Loop: Header=BB0_51 Depth=2
	and	w21, w21, #0xff
	tbnz	w21, #1, LBB0_60
LBB0_53:                                ; %else419
                                        ;   in Loop: Header=BB0_51 Depth=2
	add.2d	v24, v22, v7
	add.2d	v24, v23, v24
	tbnz	w21, #2, LBB0_61
LBB0_54:                                ; %else425
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbnz	w21, #3, LBB0_62
LBB0_55:                                ; %else431
                                        ;   in Loop: Header=BB0_51 Depth=2
	add.2d	v24, v22, v16
	add.2d	v24, v23, v24
	tbnz	w21, #4, LBB0_63
LBB0_56:                                ; %else437
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbnz	w21, #5, LBB0_64
LBB0_57:                                ; %else443
                                        ;   in Loop: Header=BB0_51 Depth=2
	add.2d	v22, v22, v6
	add.2d	v22, v23, v22
	tbnz	w21, #6, LBB0_65
LBB0_58:                                ; %else449
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbz	w21, #7, LBB0_50
	b	LBB0_66
LBB0_59:                                ; %cond.load
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x12, d24
	ldr	s20, [x12]
	and	w21, w21, #0xff
	tbz	w21, #1, LBB0_53
LBB0_60:                                ; %cond.load415
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v20 }[1], [x12]
	add.2d	v24, v22, v7
	add.2d	v24, v23, v24
	tbz	w21, #2, LBB0_54
LBB0_61:                                ; %cond.load421
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x12, d24
	ld1.s	{ v20 }[2], [x12]
	tbz	w21, #3, LBB0_55
LBB0_62:                                ; %cond.load427
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v20 }[3], [x12]
	add.2d	v24, v22, v16
	add.2d	v24, v23, v24
	tbz	w21, #4, LBB0_56
LBB0_63:                                ; %cond.load433
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x12, d24
	ld1.s	{ v21 }[0], [x12]
	tbz	w21, #5, LBB0_57
LBB0_64:                                ; %cond.load439
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x12, v24[1]
	ld1.s	{ v21 }[1], [x12]
	add.2d	v22, v22, v6
	add.2d	v22, v23, v22
	tbz	w21, #6, LBB0_58
LBB0_65:                                ; %cond.load445
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x12, d22
	ld1.s	{ v21 }[2], [x12]
	tbz	w21, #7, LBB0_50
LBB0_66:                                ; %cond.load451
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x12, v22[1]
	ld1.s	{ v21 }[3], [x12]
	b	LBB0_50
LBB0_67:                                ; %direct.false.i208.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldp	q20, q19, [x9]
	fmul.4s	v20, v20, v20
	fmul.4s	v19, v19, v19
	ldp	q22, q21, [x9, #32]
	fmul.4s	v23, v22, v22
	fmul.4s	v21, v21, v21
	ldp	q24, q22, [x9, #64]
	fmul.4s	v25, v24, v24
	fmul.4s	v24, v22, v22
	ldp	q26, q22, [x9, #96]
	fmul.4s	v27, v26, v26
	fmul.4s	v28, v22, v22
	and.16b	v19, v4, v19
	and.16b	v22, v5, v20
	and.16b	v21, v4, v21
	and.16b	v26, v5, v23
	and.16b	v24, v4, v24
	and.16b	v23, v5, v25
	and.16b	v20, v4, v28
	and.16b	v25, v5, v27
	add	x7, x9, #224
	mov	w19, #4                         ; =0x4
LBB0_68:                                ; %direct.true46.i216.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldp	q28, q27, [x7, #-96]
	and.16b	v28, v5, v28
	and.16b	v27, v4, v27
	fmul.4s	v27, v27, v27
	fmul.4s	v28, v28, v28
	fadd.4s	v28, v22, v28
	fadd.4s	v27, v19, v27
	ldp	q30, q29, [x7, #-64]
	and.16b	v30, v5, v30
	and.16b	v29, v4, v29
	fmul.4s	v29, v29, v29
	fmul.4s	v30, v30, v30
	fadd.4s	v30, v26, v30
	fadd.4s	v29, v21, v29
	ldp	q8, q31, [x7, #-32]
	and.16b	v8, v5, v8
	and.16b	v31, v4, v31
	fmul.4s	v31, v31, v31
	fmul.4s	v8, v8, v8
	fadd.4s	v8, v23, v8
	fadd.4s	v31, v24, v31
	ldp	q10, q9, [x7], #128
	and.16b	v10, v5, v10
	and.16b	v9, v4, v9
	fmul.4s	v9, v9, v9
	fmul.4s	v10, v10, v10
	fadd.4s	v10, v25, v10
	fadd.4s	v9, v20, v9
	bit.16b	v19, v27, v4
	bit.16b	v22, v28, v5
	bit.16b	v21, v29, v4
	bit.16b	v26, v30, v5
	bit.16b	v24, v31, v4
	bit.16b	v23, v8, v5
	bit.16b	v20, v9, v4
	bit.16b	v25, v10, v5
	cmp	x19, #508
	add	x19, x19, #4
	b.lo	LBB0_68
; %bb.69:                               ; %direct.true90.i231.i.preheader
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x7, #0                          ; =0x0
LBB0_70:                                ; %direct.true90.i231.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	add	x12, x6, x7, lsl #2
	ld1r.4s	{ v27 }, [x12]
	add	x12, x13, x7, lsl #5
	ldp	q28, q29, [x12]
	bit.16b	v29, v27, v4
	bif.16b	v27, v28, v5
	stp	q27, q29, [x12]
	add	x7, x7, #1
	cmp	x7, #512
	b.ne	LBB0_70
; %bb.71:                               ; %direct.false91.i238.i
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov	x6, #0                          ; =0x0
	fadd.4s	v22, v22, v26
	fadd.4s	v19, v19, v21
	fadd.4s	v19, v19, v24
	fadd.4s	v21, v22, v23
	fadd.4s	v21, v21, v25
	fadd.4s	v19, v19, v20
	fmul.4s	v19, v19, v2
	fmul.4s	v20, v21, v2
	fadd.4s	v20, v20, v3
	fadd.4s	v3, v19, v3
	fsqrt.4s	v19, v3
	fsqrt.4s	v3, v20
	and.16b	v3, v5, v3
	and.16b	v19, v4, v19
	add	x7, sp, #32
	add	x19, sp, #4, lsl #12            ; =16384
	add	x19, x19, #32
	b	LBB0_73
LBB0_72:                                ; %else488
                                        ;   in Loop: Header=BB0_73 Depth=2
	add	x6, x6, #4
	add	x7, x7, #32
	add	x19, x19, #32
	cmp	x6, #2048
	b.eq	LBB0_2
LBB0_73:                                ; %direct.true105.i239.i
                                        ;   Parent Loop BB0_3 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w20, s18
	ldp	q20, q22, [x19]
	and.16b	v20, v5, v20
	fdiv.4s	v20, v20, v3
	ldp	q21, q23, [x7]
	and.16b	v21, v5, v21
	fmul.4s	v24, v20, v21
	dup.2d	v20, x6
	add.2d	v25, v20, v17
	dup.2d	v21, x5
	add.2d	v25, v21, v25
	tbnz	w20, #0, LBB0_82
; %bb.74:                               ; %else460
                                        ;   in Loop: Header=BB0_73 Depth=2
	and	w20, w20, #0xff
	tbnz	w20, #1, LBB0_83
LBB0_75:                                ; %else464
                                        ;   in Loop: Header=BB0_73 Depth=2
	add.2d	v25, v20, v7
	add.2d	v25, v21, v25
	tbnz	w20, #2, LBB0_84
LBB0_76:                                ; %else468
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbz	w20, #3, LBB0_78
LBB0_77:                                ; %cond.store469
                                        ;   in Loop: Header=BB0_73 Depth=2
	mov.d	x12, v25[1]
	st1.s	{ v24 }[3], [x12]
LBB0_78:                                ; %else472
                                        ;   in Loop: Header=BB0_73 Depth=2
	and.16b	v22, v4, v22
	fdiv.4s	v22, v22, v19
	and.16b	v23, v4, v23
	fmul.4s	v22, v22, v23
	add.2d	v23, v20, v16
	add.2d	v23, v21, v23
	tbnz	w20, #4, LBB0_85
; %bb.79:                               ; %else476
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbnz	w20, #5, LBB0_86
LBB0_80:                                ; %else480
                                        ;   in Loop: Header=BB0_73 Depth=2
	add.2d	v20, v20, v6
	add.2d	v20, v21, v20
	tbnz	w20, #6, LBB0_87
LBB0_81:                                ; %else484
                                        ;   in Loop: Header=BB0_73 Depth=2
	tbz	w20, #7, LBB0_72
	b	LBB0_88
LBB0_82:                                ; %cond.store
                                        ;   in Loop: Header=BB0_73 Depth=2
	fmov	x12, d25
	str	s24, [x12]
	and	w20, w20, #0xff
	tbz	w20, #1, LBB0_75
LBB0_83:                                ; %cond.store461
                                        ;   in Loop: Header=BB0_73 Depth=2
	mov.d	x12, v25[1]
	st1.s	{ v24 }[1], [x12]
	add.2d	v25, v20, v7
	add.2d	v25, v21, v25
	tbz	w20, #2, LBB0_76
LBB0_84:                                ; %cond.store465
                                        ;   in Loop: Header=BB0_73 Depth=2
	fmov	x12, d25
	st1.s	{ v24 }[2], [x12]
	tbnz	w20, #3, LBB0_77
	b	LBB0_78
LBB0_85:                                ; %cond.store473
                                        ;   in Loop: Header=BB0_73 Depth=2
	fmov	x12, d23
	str	s22, [x12]
	tbz	w20, #5, LBB0_80
LBB0_86:                                ; %cond.store477
                                        ;   in Loop: Header=BB0_73 Depth=2
	mov.d	x12, v23[1]
	st1.s	{ v22 }[1], [x12]
	add.2d	v20, v20, v6
	add.2d	v20, v21, v20
	tbz	w20, #6, LBB0_81
LBB0_87:                                ; %cond.store481
                                        ;   in Loop: Header=BB0_73 Depth=2
	fmov	x12, d20
	st1.s	{ v22 }[2], [x12]
	tbz	w20, #7, LBB0_72
LBB0_88:                                ; %cond.store485
                                        ;   in Loop: Header=BB0_73 Depth=2
	mov.d	x12, v20[1]
	st1.s	{ v22 }[3], [x12]
	b	LBB0_72
LBB0_89:                                ; %block.batch.exit.loopexit
	ldr	x9, [sp, #16]                   ; 8-byte Reload
	stp	w4, w1, [x9]
	str	w17, [x9, #8]
	mov	w8, #24                         ; =0x18
	str	w8, [x9, #36]
	add	sp, sp, #8, lsl #12             ; =32768
	add	sp, sp, #32
	ldp	x29, x30, [sp, #112]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #96]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #80]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #48]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #32]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp], #128            ; 16-byte Folded Reload
LBB0_90:                                ; %block.batch.exit
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
                                        ; -- End function
.subsections_via_symbols

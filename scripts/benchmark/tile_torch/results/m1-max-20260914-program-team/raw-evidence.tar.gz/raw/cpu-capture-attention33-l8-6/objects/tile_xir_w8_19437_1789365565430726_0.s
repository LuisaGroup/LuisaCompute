	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_4:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_5:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_6:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_12:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI0_13:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI0_14:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI0_15:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI0_16:
	.quad	30                              ; 0x1e
	.quad	35                              ; 0x23
lCPI0_17:
	.quad	10                              ; 0xa
	.quad	15                              ; 0xf
lCPI0_18:
	.quad	20                              ; 0x14
	.quad	25                              ; 0x19
lCPI0_19:
	.quad	0                               ; 0x0
	.quad	5                               ; 0x5
lCPI0_20:
	.quad	60                              ; 0x3c
	.quad	70                              ; 0x46
lCPI0_21:
	.quad	20                              ; 0x14
	.quad	30                              ; 0x1e
lCPI0_22:
	.quad	40                              ; 0x28
	.quad	50                              ; 0x32
lCPI0_23:
	.quad	0                               ; 0x0
	.quad	10                              ; 0xa
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v4, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q5, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q6, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v27, v4, v6
	cmhi.4s	v24, v4, v5
	uzp1.8h	v31, v24, v27
	umaxv.8h	h0, v31
	fmov	w8, s0
	tbnz	w8, #0, LBB0_1
	b	LBB0_1552
LBB0_1:                                 ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #6, lsl #12             ; =24576
	sub	sp, sp, #224
	add	x13, sp, #3, lsl #12            ; =12288
	add	x13, x13, #1200
Lloh4:
	adrp	x8, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x8, lCPI0_0@PAGEOFF]
	and.16b	v0, v31, v0
	addv.8h	h16, v0
	ldr	w8, [x1]
	sshll2.2d	v12, v24, #0
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
	sshll.2d	v1, v27, #0
	sshll.2d	v0, v24, #0
	sshll2.2d	v14, v27, #0
Lloh6:
	adrp	x9, lCPI0_6@PAGE
Lloh7:
	ldr	q2, [x9, lCPI0_6@PAGEOFF]
	and.16b	v10, v14, v2
	lsr	w8, w8, #3
	dup.4s	v2, w8
	and.16b	v3, v24, v2
	and.16b	v2, v27, v2
	ushll2.2d	v17, v2, #0
	ushll2.2d	v25, v3, #0
	ushll.2d	v26, v2, #0
	ushll.2d	v18, v3, #0
	mov	w8, #2                          ; =0x2
	dup.2d	v3, x8
	and.16b	v2, v0, v3
	mvn.16b	v19, v0
	sub.2d	v13, v2, v19
	add	x28, sp, #4, lsl #12            ; =16384
	add	x28, x28, #3624
	add	x27, sp, #4, lsl #12            ; =16384
	add	x27, x27, #3544
	ldr	x14, [x0]
	and.16b	v2, v1, v3
	mvn.16b	v19, v1
	sub.2d	v15, v2, v19
	ldr	x8, [x0, #16]
	str	x8, [sp, #4512]                 ; 8-byte Spill
	ldr	x8, [x0, #32]
	str	x8, [sp, #4504]                 ; 8-byte Spill
	ldr	x8, [x0, #48]
	str	x8, [sp, #32]                   ; 8-byte Spill
	and.16b	v19, v12, v3
	mvn.16b	v2, v12
	sub.2d	v7, v19, v2
	str	q16, [sp, #8048]                ; 16-byte Spill
	fmov	w8, s16
	and	w8, w8, #0xff
	str	w8, [sp, #12944]                ; 4-byte Spill
	and.16b	v19, v14, v3
	mvn.16b	v3, v14
	sub.2d	v16, v19, v3
Lloh8:
	adrp	x8, lCPI0_3@PAGE
Lloh9:
	ldr	q19, [x8, lCPI0_3@PAGEOFF]
	mov	w8, #1                          ; =0x1
	dup.2d	v23, x8
	ushr.2d	v30, v18, #1
	ushr.2d	v8, v26, #1
Lloh10:
	adrp	x8, lCPI0_4@PAGE
Lloh11:
	ldr	q22, [x8, lCPI0_4@PAGEOFF]
	ushr.2d	v21, v25, #1
	ushr.2d	v9, v17, #1
	str	q17, [sp, #13232]               ; 16-byte Spill
	and.16b	v20, v14, v17
	str	q25, [sp, #13216]               ; 16-byte Spill
	and.16b	v28, v12, v25
	str	q26, [sp, #13200]               ; 16-byte Spill
	and.16b	v25, v1, v26
	mov.16b	v17, v27
	and.16b	v26, v0, v18
	movi.2d	v29, #0xffffffffffffffff
	str	q31, [sp, #13328]               ; 16-byte Spill
	add.2d	v31, v13, v29
	and.16b	v26, v26, v31
	add.2d	v31, v15, v29
	and.16b	v25, v25, v31
	add.2d	v31, v16, v29
	add.2d	v29, v7, v29
	and.16b	v28, v28, v29
	and.16b	v29, v20, v31
	cmhs.4s	v6, v6, v4
	cmhs.4s	v4, v5, v4
	uzp1.8h	v4, v4, v6
	xtn.8b	v5, v4
	movi	d4, #0xffffffffffffff
	str	d5, [sp, #11616]                ; 8-byte Spill
	orr.8b	v20, v5, v4
	mov	b4, v20[6]
	mov.b	v4[4], v20[7]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v6, v4, #0
	mov	w8, #6                          ; =0x6
	dup.2d	v31, x8
	mov.d	x8, v9[1]
	fmov	x9, d9
	add	x9, x9, x9, lsl #1
	fmov	d4, x9
	add	x8, x8, x8, lsl #1
	mov.d	v4[1], x8
	mov.d	x8, v21[1]
	fmov	x9, d21
	add	x9, x9, x9, lsl #1
	fmov	d5, x9
	add	x8, x8, x8, lsl #1
	mov.d	v5[1], x8
	str	q10, [sp, #13040]               ; 16-byte Spill
	mov.16b	v21, v6
	bsl.16b	v21, v10, v31
	mov.d	x8, v8[1]
	fmov	x9, d8
	mov.d	x10, v30[1]
	add	x9, x9, x9, lsl #1
	fmov	x11, d30
	ushll2.2d	v6, v27, #0
	and.16b	v11, v6, v23
	ushll2.2d	v6, v24, #0
	and.16b	v6, v6, v23
	str	q6, [sp, #13296]                ; 16-byte Spill
	ushll.2d	v6, v17, #0
	and.16b	v6, v6, v23
	str	q6, [sp, #13280]                ; 16-byte Spill
	ushll.2d	v6, v24, #0
	and.16b	v6, v6, v23
	str	q6, [sp, #13264]                ; 16-byte Spill
	fmov	d6, x9
	add	x9, sp, #6, lsl #12             ; =24576
	add	x9, x9, #160
	and.16b	v19, v12, v19
	str	q19, [sp, #13072]               ; 16-byte Spill
	and.16b	v19, v1, v22
	str	q19, [sp, #13056]               ; 16-byte Spill
	add.2d	v19, v29, v29
	add.2d	v22, v28, v28
	add.2d	v25, v25, v25
	add.2d	v26, v26, v26
	add	x8, x8, x8, lsl #1
	mov.d	v6[1], x8
	add	x8, x11, x11, lsl #1
	add	x10, x10, x10, lsl #1
	fmov	d28, x8
	mov.d	v28[1], x10
	ldr	q23, [sp, #13328]               ; 16-byte Reload
	xtn.8b	v23, v23
	str	q23, [sp, #13136]               ; 16-byte Spill
	mov.b	v23[7], wzr
	and.16b	v26, v0, v26
	and.16b	v25, v1, v25
	mov.d	x10, v16[1]
	mov.d	x11, v15[1]
	and.16b	v22, v12, v22
	and.16b	v29, v14, v19
	mov.d	x12, v7[1]
	dup.2d	v19, x9
	and.16b	v30, v14, v19
	str	q30, [sp, #11840]               ; 16-byte Spill
	and.16b	v30, v12, v19
	str	q30, [sp, #11824]               ; 16-byte Spill
	and.16b	v30, v1, v19
	str	q30, [sp, #11808]               ; 16-byte Spill
	and.16b	v19, v0, v19
	str	q19, [sp, #11792]               ; 16-byte Spill
	mov.d	x8, v13[1]
	str	x8, [sp, #11736]                ; 8-byte Spill
	and.16b	v6, v1, v6
Lloh12:
	adrp	x8, lCPI0_9@PAGE
Lloh13:
	ldr	q19, [x8, lCPI0_9@PAGEOFF]
	str	q19, [sp, #4576]                ; 16-byte Spill
	and.16b	v1, v1, v19
	str	q1, [sp, #12352]                ; 16-byte Spill
	and.16b	v1, v0, v28
Lloh14:
	adrp	x8, lCPI0_10@PAGE
Lloh15:
	adrp	x9, lCPI0_5@PAGE
Lloh16:
	ldr	q19, [x9, lCPI0_5@PAGEOFF]
Lloh17:
	ldr	q28, [x8, lCPI0_10@PAGEOFF]
	str	q19, [sp, #5808]                ; 16-byte Spill
	and.16b	v19, v0, v19
	str	q19, [sp, #13104]               ; 16-byte Spill
	str	q28, [sp, #4560]                ; 16-byte Spill
	and.16b	v0, v0, v28
	str	q0, [sp, #12336]                ; 16-byte Spill
	and.16b	v0, v12, v5
	and.16b	v4, v14, v4
	str	q29, [sp, #3008]                ; 16-byte Spill
	add.2d	v4, v29, v4
	str	q4, [sp, #1952]                 ; 16-byte Spill
	str	q22, [sp, #3024]                ; 16-byte Spill
	add.2d	v0, v22, v0
	str	q0, [sp, #1936]                 ; 16-byte Spill
	str	q25, [sp, #3040]                ; 16-byte Spill
	add.2d	v0, v25, v6
	str	q0, [sp, #1920]                 ; 16-byte Spill
	str	q26, [sp, #3056]                ; 16-byte Spill
	add.2d	v0, v26, v1
	mov.16b	v26, v27
	str	q0, [sp, #1904]                 ; 16-byte Spill
	add	x25, sp, #4, lsl #12            ; =16384
	add	x25, x25, #3224
	add	x1, sp, #4, lsl #12             ; =16384
	add	x1, x1, #3160
	add	x2, sp, #4, lsl #12             ; =16384
	add	x2, x2, #3128
	add	x3, sp, #4, lsl #12             ; =16384
	add	x3, x3, #3096
	add	x4, sp, #4, lsl #12             ; =16384
	add	x4, x4, #3064
	add	x5, sp, #4, lsl #12             ; =16384
	add	x5, x5, #2744
	add	x6, sp, #4, lsl #12             ; =16384
	add	x6, x6, #2424
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #2104
	add	x19, sp, #4, lsl #12            ; =16384
	add	x19, x19, #2072
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #2008
	add	x21, sp, #4, lsl #12            ; =16384
	add	x21, x21, #1976
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #1912
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #1848
	add	x24, sp, #4, lsl #12            ; =16384
	add	x24, x24, #1784
Lloh18:
	adrp	x26, lCPI0_8@PAGE
	str	q16, [sp, #11664]               ; 16-byte Spill
	fmov	x8, d16
	str	q15, [sp, #11696]               ; 16-byte Spill
	fmov	x15, d15
	str	q7, [sp, #11680]                ; 16-byte Spill
	fmov	x16, d7
	str	q13, [sp, #11712]               ; 16-byte Spill
	fmov	x17, d13
	mov	w0, #3                          ; =0x3
Lloh19:
	adrp	x9, lCPI0_11@PAGE
	add	x30, sp, #6, lsl #12            ; =24576
	add	x30, x30, #128
	dup.2d	v16, x30
	add	x30, sp, #6, lsl #12            ; =24576
	add	x30, x30, #96
	dup.2d	v6, x30
	add	x30, sp, #6, lsl #12            ; =24576
	add	x30, x30, #64
	dup.2d	v22, x30
	add	x30, sp, #6, lsl #12            ; =24576
	add	x30, x30, #32
	dup.2d	v5, x30
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #4064
	dup.2d	v19, x30
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #4000
	dup.2d	v4, x30
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #2880
	dup.2d	v1, x30
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #1824
	dup.2d	v0, x30
	stp	q0, q1, [sp, #656]              ; 32-byte Folded Spill
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #1504
	dup.2d	v1, x30
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #1184
	dup.2d	v0, x30
	stp	q0, q1, [sp, #624]              ; 32-byte Folded Spill
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #864
	dup.2d	v1, x30
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #544
	dup.2d	v0, x30
	stp	q0, q1, [sp, #592]              ; 32-byte Folded Spill
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #504
	dup.2d	v1, x30
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #184
	dup.2d	v0, x30
	stp	q0, q1, [sp, #560]              ; 32-byte Folded Spill
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #3960
	dup.2d	v1, x30
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #3896
	dup.2d	v0, x30
	stp	q0, q1, [sp, #528]              ; 32-byte Folded Spill
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #3832
	dup.2d	v1, x30
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #3768
	dup.2d	v0, x30
	stp	q0, q1, [sp, #496]              ; 32-byte Folded Spill
	add	x30, sp, #4, lsl #12            ; =16384
	add	x30, x30, #3704
	dup.2d	v1, x30
	dup.2d	v0, x28
	stp	q0, q1, [sp, #464]              ; 32-byte Folded Spill
	dup.2d	v1, x27
	dup.2d	v0, x25
	stp	q0, q1, [sp, #432]              ; 32-byte Folded Spill
	dup.2d	v1, x1
	dup.2d	v0, x2
	stp	q0, q1, [sp, #400]              ; 32-byte Folded Spill
	dup.2d	v1, x3
	dup.2d	v0, x4
	stp	q0, q1, [sp, #368]              ; 32-byte Folded Spill
	dup.2d	v1, x5
	dup.2d	v0, x6
	stp	q0, q1, [sp, #336]              ; 32-byte Folded Spill
	dup.2d	v1, x7
	dup.2d	v0, x19
	stp	q0, q1, [sp, #304]              ; 32-byte Folded Spill
	dup.2d	v1, x20
	dup.2d	v0, x21
	stp	q0, q1, [sp, #272]              ; 32-byte Folded Spill
	dup.2d	v1, x22
	dup.2d	v0, x23
	stp	q0, q1, [sp, #240]              ; 32-byte Folded Spill
	dup.2d	v0, x24
	str	q0, [sp, #16]                   ; 16-byte Spill
Lloh20:
	adrp	x1, lCPI0_7@PAGE
Lloh21:
	ldr	q0, [x1, lCPI0_7@PAGEOFF]
Lloh22:
	ldr	q1, [x26, lCPI0_8@PAGEOFF]
	str	q0, [sp, #4544]                 ; 16-byte Spill
	and.16b	v0, v14, v0
	str	q0, [sp, #12320]                ; 16-byte Spill
	str	q1, [sp, #4528]                 ; 16-byte Spill
	and.16b	v0, v12, v1
	str	q0, [sp, #12304]                ; 16-byte Spill
	movi.2d	v25, #0000000000000000
Lloh23:
	ldr	d0, [x9, lCPI0_11@PAGEOFF]
	str	d0, [sp, #13320]                ; 8-byte Spill
	movi.2d	v30, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v8, #0000000000000000
	str	q12, [sp, #12864]               ; 16-byte Spill
	str	q14, [sp, #13024]               ; 16-byte Spill
	str	q11, [sp, #13248]               ; 16-byte Spill
	b	LBB0_3
LBB0_2:                                 ; %else433
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v28, v28, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v29, v29, v0
	add.2d	v8, v8, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v25, v25, v0
	fmov	x9, d25
	cmp	x9, #2
	b.ge	LBB0_35
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v0, v26, #0
	sshll.2d	v1, v24, #0
	and.16b	v1, v1, v25
	and.16b	v31, v12, v28
	and.16b	v0, v0, v29
	and.16b	v10, v14, v8
	mov.d	x9, v10[1]
	fmov	x1, d10
	sdiv	x2, x1, x8
	msub	x1, x2, x8, x1
	fmov	d10, x1
	sdiv	x1, x9, x10
	msub	x9, x1, x10, x9
	mov.d	v10[1], x9
	mov.d	x9, v0[1]
	fmov	x1, d0
	sdiv	x2, x1, x15
	msub	x1, x2, x15, x1
	fmov	d14, x1
	sdiv	x1, x9, x11
	msub	x9, x1, x11, x9
	mov.d	v14[1], x9
	mov.d	x9, v31[1]
	fmov	x1, d31
	sdiv	x2, x1, x16
	msub	x1, x2, x16, x1
	fmov	d15, x1
	sdiv	x1, x9, x12
	msub	x9, x1, x12, x9
	mov.d	v15[1], x9
	mov.d	x9, v1[1]
	fmov	x1, d1
	sdiv	x2, x1, x17
	msub	x1, x2, x17, x1
	fmov	d0, x1
	ldr	x2, [sp, #11736]                ; 8-byte Reload
	sdiv	x1, x9, x2
	msub	x9, x1, x2, x9
	mov.d	v0[1], x9
	ldr	q1, [sp, #3056]                 ; 16-byte Reload
	add.2d	v1, v0, v1
	ldr	q31, [sp, #3024]                ; 16-byte Reload
	add.2d	v31, v15, v31
	ldr	q11, [sp, #3040]                ; 16-byte Reload
	add.2d	v11, v14, v11
	ldr	q12, [sp, #3008]                ; 16-byte Reload
	add.2d	v12, v10, v12
	ldr	q13, [sp, #1904]                ; 16-byte Reload
	add.2d	v0, v0, v13
	dup.2d	v13, x0
	cmhi.2d	v12, v13, v12
	cmhi.2d	v11, v13, v11
	uzp1.4s	v11, v11, v12
	cmhi.2d	v31, v13, v31
	cmhi.2d	v1, v13, v1
	uzp1.4s	v1, v1, v31
	uzp1.8h	v1, v1, v11
	xtn.8b	v11, v1
	mov.d	x9, v0[1]
	lsl	x1, x9, #3
	sub	x9, x1, x9
	fmov	x1, d0
	lsl	x2, x1, #3
	sub	x1, x2, x1
	fmov	d0, x1
	mov.d	v0[1], x9
	ldr	q1, [sp, #13104]                ; 16-byte Reload
	add.2d	v1, v0, v1
	and.8b	v0, v11, v23
	shl.8b	v31, v0, #7
	cmlt.8b	v31, v31, #0
	ldr	d12, [sp, #13320]               ; 8-byte Reload
	and.8b	v31, v31, v12
	addv.8b	b31, v31
	fmov	w9, s31
	shl.2d	v1, v1, #2
	mov	b31, v0[0]
	mov.b	v31[4], v0[1]
	ushll.2d	v31, v31, #0
	shl.2d	v31, v31, #63
	cmlt.2d	v31, v31, #0
	and.16b	v1, v31, v1
	dup.2d	v13, x14
	add.2d	v31, v13, v1
	movi.2d	v12, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w9, #0, LBB0_5
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d31
	ldr	s12, [x1]
LBB0_5:                                 ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #1, LBB0_7
; %bb.6:                                ; %cond.load389
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v31[1]
	ld1.s	{ v12 }[1], [x1]
LBB0_7:                                 ; %else390
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q31, [sp, #1936]                ; 16-byte Reload
	add.2d	v31, v15, v31
	mov.d	x1, v31[1]
	lsl	x2, x1, #3
	sub	x1, x2, x1
	fmov	x2, d31
	lsl	x3, x2, #3
	sub	x2, x3, x2
	fmov	d31, x2
	mov.d	v31[1], x1
	ldr	q7, [sp, #13072]                ; 16-byte Reload
	add.2d	v31, v31, v7
	mov	b15, v0[2]
	mov.b	v15[4], v0[3]
	shl.2d	v31, v31, #2
	ushll.2d	v15, v15, #0
	shl.2d	v15, v15, #63
	cmlt.2d	v15, v15, #0
	and.16b	v31, v15, v31
	add.2d	v31, v13, v31
	tbz	w9, #2, LBB0_9
; %bb.8:                                ; %cond.load392
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d31
	ld1.s	{ v12 }[2], [x1]
LBB0_9:                                 ; %else393
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #3, LBB0_11
; %bb.10:                               ; %cond.load395
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v31[1]
	ld1.s	{ v12 }[3], [x1]
LBB0_11:                                ; %else396
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q31, [sp, #1920]                ; 16-byte Reload
	add.2d	v31, v14, v31
	mov.d	x1, v31[1]
	lsl	x2, x1, #3
	sub	x1, x2, x1
	fmov	x2, d31
	lsl	x3, x2, #3
	sub	x2, x3, x2
	fmov	d31, x2
	mov.d	v31[1], x1
	ldr	q7, [sp, #13056]                ; 16-byte Reload
	add.2d	v31, v31, v7
	mov	b14, v0[4]
	mov.b	v14[4], v0[5]
	shl.2d	v31, v31, #2
	ushll.2d	v14, v14, #0
	shl.2d	v14, v14, #63
	cmlt.2d	v14, v14, #0
	and.16b	v31, v14, v31
	add.2d	v31, v13, v31
	tbz	w9, #4, LBB0_13
; %bb.12:                               ; %cond.load398
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d31
	ld1.s	{ v1 }[0], [x1]
LBB0_13:                                ; %else399
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q14, [sp, #13024]               ; 16-byte Reload
	tbz	w9, #5, LBB0_15
; %bb.14:                               ; %cond.load401
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v31[1]
	ld1.s	{ v1 }[1], [x1]
LBB0_15:                                ; %else402
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q31, [sp, #1952]                ; 16-byte Reload
	add.2d	v31, v10, v31
	mov.d	x1, v31[1]
	lsl	x2, x1, #3
	sub	x1, x2, x1
	fmov	x2, d31
	lsl	x3, x2, #3
	sub	x2, x3, x2
	fmov	d31, x2
	mov.d	v31[1], x1
	add.2d	v31, v31, v21
	mov	b10, v0[6]
	mov.b	v10[4], v0[7]
	shl.2d	v31, v31, #2
	ushll.2d	v10, v10, #0
	shl.2d	v10, v10, #63
	cmlt.2d	v10, v10, #0
	and.16b	v31, v10, v31
	add.2d	v31, v13, v31
	tbz	w9, #6, LBB0_17
; %bb.16:                               ; %cond.load404
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d31
	ld1.s	{ v1 }[2], [x1]
LBB0_17:                                ; %else405
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_19
; %bb.18:                               ; %cond.load407
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v31[1]
	ld1.s	{ v1 }[3], [x9]
LBB0_19:                                ; %else408
                                        ;   in Loop: Header=BB0_3 Depth=1
	and.8b	v31, v20, v11
	ldr	q10, [sp, #13136]               ; 16-byte Reload
	bic.8b	v10, v10, v31
	zip1.8b	v31, v0, v0
	ushll.4s	v31, v31, #0
	shl.4s	v31, v31, #31
	cmlt.4s	v31, v31, #0
	bit.16b	v30, v12, v31
	zip1.8b	v31, v10, v0
	ushll.4s	v31, v31, #0
	shl.4s	v31, v31, #31
	cmge.4s	v31, v31, #0
	and.16b	v30, v31, v30
	shl.2d	v31, v25, #5
	ldr	q11, [sp, #12336]               ; 16-byte Reload
	orr.16b	v31, v31, v11
	ldr	q7, [sp, #11792]                ; 16-byte Reload
	add.2d	v31, v7, v31
	shl.8b	v11, v23, #7
	cmlt.8b	v11, v11, #0
	ldr	d12, [sp, #13320]               ; 8-byte Reload
	and.8b	v11, v11, v12
	addv.8b	b11, v11
	fmov	w9, s11
	tbnz	w9, #0, LBB0_28
; %bb.20:                               ; %else412
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q12, [sp, #12864]               ; 16-byte Reload
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	tbnz	w9, #1, LBB0_29
LBB0_21:                                ; %else415
                                        ;   in Loop: Header=BB0_3 Depth=1
	shl.2d	v31, v28, #5
	ldr	q13, [sp, #12304]               ; 16-byte Reload
	orr.16b	v31, v31, v13
	ldr	q7, [sp, #11824]                ; 16-byte Reload
	add.2d	v31, v7, v31
	tbnz	w9, #2, LBB0_30
LBB0_22:                                ; %else418
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #3, LBB0_24
LBB0_23:                                ; %cond.store419
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v31[1]
	st1.s	{ v30 }[3], [x1]
LBB0_24:                                ; %else421
                                        ;   in Loop: Header=BB0_3 Depth=1
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	bsl.16b	v0, v1, v9
	zip2.8b	v1, v10, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v9, v1, v0
	shl.2d	v0, v29, #5
	ldr	q1, [sp, #12352]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #11808]                ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w9, #4, LBB0_31
; %bb.25:                               ; %else424
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbnz	w9, #5, LBB0_32
LBB0_26:                                ; %else427
                                        ;   in Loop: Header=BB0_3 Depth=1
	shl.2d	v0, v8, #5
	ldr	q1, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #11840]                ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w9, #6, LBB0_33
LBB0_27:                                ; %else430
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w9, #7, LBB0_2
	b	LBB0_34
LBB0_28:                                ; %cond.store
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d31
	str	s30, [x1]
	ldr	q12, [sp, #12864]               ; 16-byte Reload
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	tbz	w9, #1, LBB0_21
LBB0_29:                                ; %cond.store413
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v31[1]
	st1.s	{ v30 }[1], [x1]
	shl.2d	v31, v28, #5
	ldr	q13, [sp, #12304]               ; 16-byte Reload
	orr.16b	v31, v31, v13
	ldr	q7, [sp, #11824]                ; 16-byte Reload
	add.2d	v31, v7, v31
	tbz	w9, #2, LBB0_22
LBB0_30:                                ; %cond.store416
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d31
	st1.s	{ v30 }[2], [x1]
	tbnz	w9, #3, LBB0_23
	b	LBB0_24
LBB0_31:                                ; %cond.store422
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d0
	str	s9, [x1]
	tbz	w9, #5, LBB0_26
LBB0_32:                                ; %cond.store425
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x1, v0[1]
	st1.s	{ v9 }[1], [x1]
	shl.2d	v0, v8, #5
	ldr	q1, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #11840]                ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w9, #6, LBB0_27
LBB0_33:                                ; %cond.store428
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x1, d0
	st1.s	{ v9 }[2], [x1]
	tbz	w9, #7, LBB0_2
LBB0_34:                                ; %cond.store431
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x9, v0[1]
	st1.s	{ v9 }[3], [x9]
	b	LBB0_2
LBB0_35:                                ; %direct.false
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	and.16b	v31, v14, v16
	and.16b	v7, v12, v16
	str	q7, [sp, #2992]                 ; 16-byte Spill
	and.16b	v1, v1, v16
	str	q1, [sp, #2976]                 ; 16-byte Spill
	and.16b	v0, v0, v16
	str	q0, [sp, #2960]                 ; 16-byte Spill
	movi	d0, #0x0000000000ffff
	ldr	q26, [sp, #13136]               ; 16-byte Reload
	and.8b	v1, v26, v0
	movi.2d	v0, #0000000000000000
	str	q1, [sp, #11648]                ; 16-byte Spill
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	ldr	d20, [sp, #13320]               ; 8-byte Reload
	and.8b	v1, v1, v20
	addv.8b	b27, v1
	fmov	w8, s27
	mov	w9, #62154                      ; =0xf2ca
	movk	w9, #61769, lsl #16
	movi.2d	v1, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	b	LBB0_37
LBB0_36:                                ; %else458
                                        ;   in Loop: Header=BB0_37 Depth=1
	ldr	q23, [sp, #13296]               ; 16-byte Reload
	add.2d	v1, v1, v23
	ldr	q23, [sp, #13280]               ; 16-byte Reload
	add.2d	v20, v20, v23
	add.2d	v21, v21, v11
	ldr	q23, [sp, #13264]               ; 16-byte Reload
	add.2d	v0, v0, v23
	fmov	x14, d0
	cmp	x14, #1
	b.ge	LBB0_53
LBB0_37:                                ; %direct.true338
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v23, v0, #5
	ldr	q25, [sp, #12336]               ; 16-byte Reload
	orr.16b	v23, v23, v25
	ldr	q7, [sp, #2960]                 ; 16-byte Reload
	add.2d	v23, v7, v23
	tbnz	w8, #0, LBB0_45
; %bb.38:                               ; %else437
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w8, #1, LBB0_46
LBB0_39:                                ; %else440
                                        ;   in Loop: Header=BB0_37 Depth=1
	shl.2d	v23, v1, #5
	ldr	q25, [sp, #12304]               ; 16-byte Reload
	orr.16b	v23, v23, v25
	ldr	q7, [sp, #2992]                 ; 16-byte Reload
	add.2d	v23, v7, v23
	tbnz	w8, #2, LBB0_47
LBB0_40:                                ; %else443
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w8, #3, LBB0_48
LBB0_41:                                ; %else446
                                        ;   in Loop: Header=BB0_37 Depth=1
	shl.2d	v23, v20, #5
	ldr	q25, [sp, #12352]               ; 16-byte Reload
	orr.16b	v23, v23, v25
	ldr	q7, [sp, #2976]                 ; 16-byte Reload
	add.2d	v23, v7, v23
	tbnz	w8, #4, LBB0_49
LBB0_42:                                ; %else449
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbnz	w8, #5, LBB0_50
LBB0_43:                                ; %else452
                                        ;   in Loop: Header=BB0_37 Depth=1
	shl.2d	v23, v21, #5
	ldr	q25, [sp, #12320]               ; 16-byte Reload
	orr.16b	v23, v23, v25
	add.2d	v23, v31, v23
	tbnz	w8, #6, LBB0_51
LBB0_44:                                ; %else455
                                        ;   in Loop: Header=BB0_37 Depth=1
	tbz	w8, #7, LBB0_36
	b	LBB0_52
LBB0_45:                                ; %cond.store435
                                        ;   in Loop: Header=BB0_37 Depth=1
	fmov	x14, d23
	str	w9, [x14]
	tbz	w8, #1, LBB0_39
LBB0_46:                                ; %cond.store438
                                        ;   in Loop: Header=BB0_37 Depth=1
	mov.d	x14, v23[1]
	str	w9, [x14]
	shl.2d	v23, v1, #5
	ldr	q25, [sp, #12304]               ; 16-byte Reload
	orr.16b	v23, v23, v25
	ldr	q7, [sp, #2992]                 ; 16-byte Reload
	add.2d	v23, v7, v23
	tbz	w8, #2, LBB0_40
LBB0_47:                                ; %cond.store441
                                        ;   in Loop: Header=BB0_37 Depth=1
	fmov	x14, d23
	str	w9, [x14]
	tbz	w8, #3, LBB0_41
LBB0_48:                                ; %cond.store444
                                        ;   in Loop: Header=BB0_37 Depth=1
	mov.d	x14, v23[1]
	str	w9, [x14]
	shl.2d	v23, v20, #5
	ldr	q25, [sp, #12352]               ; 16-byte Reload
	orr.16b	v23, v23, v25
	ldr	q7, [sp, #2976]                 ; 16-byte Reload
	add.2d	v23, v7, v23
	tbz	w8, #4, LBB0_42
LBB0_49:                                ; %cond.store447
                                        ;   in Loop: Header=BB0_37 Depth=1
	fmov	x14, d23
	str	w9, [x14]
	tbz	w8, #5, LBB0_43
LBB0_50:                                ; %cond.store450
                                        ;   in Loop: Header=BB0_37 Depth=1
	mov.d	x14, v23[1]
	str	w9, [x14]
	shl.2d	v23, v21, #5
	ldr	q25, [sp, #12320]               ; 16-byte Reload
	orr.16b	v23, v23, v25
	add.2d	v23, v31, v23
	tbz	w8, #6, LBB0_44
LBB0_51:                                ; %cond.store453
                                        ;   in Loop: Header=BB0_37 Depth=1
	fmov	x14, d23
	str	w9, [x14]
	tbz	w8, #7, LBB0_36
LBB0_52:                                ; %cond.store456
                                        ;   in Loop: Header=BB0_37 Depth=1
	mov.d	x14, v23[1]
	str	w9, [x14]
	b	LBB0_36
LBB0_53:                                ; %direct.false339
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v17, #0
	and.16b	v25, v14, v22
	and.16b	v28, v12, v22
	and.16b	v29, v1, v22
	and.16b	v30, v0, v22
	movi.2d	v0, #0000000000000000
	fmov	w8, s27
	movi.2d	v1, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	b	LBB0_55
LBB0_54:                                ; %else483
                                        ;   in Loop: Header=BB0_55 Depth=1
	ldr	q22, [sp, #13296]               ; 16-byte Reload
	add.2d	v1, v1, v22
	ldr	q22, [sp, #13280]               ; 16-byte Reload
	add.2d	v20, v20, v22
	add.2d	v21, v21, v11
	ldr	q22, [sp, #13264]               ; 16-byte Reload
	add.2d	v0, v0, v22
	fmov	x9, d0
	cmp	x9, #1
	b.ge	LBB0_71
LBB0_55:                                ; %direct.true346
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v22, v0, #5
	ldr	q23, [sp, #12336]               ; 16-byte Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v30, v22
	tbnz	w8, #0, LBB0_63
; %bb.56:                               ; %else462
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w8, #1, LBB0_64
LBB0_57:                                ; %else465
                                        ;   in Loop: Header=BB0_55 Depth=1
	shl.2d	v22, v1, #5
	ldr	q23, [sp, #12304]               ; 16-byte Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v28, v22
	tbnz	w8, #2, LBB0_65
LBB0_58:                                ; %else468
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w8, #3, LBB0_66
LBB0_59:                                ; %else471
                                        ;   in Loop: Header=BB0_55 Depth=1
	shl.2d	v22, v20, #5
	ldr	q23, [sp, #12352]               ; 16-byte Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v29, v22
	tbnz	w8, #4, LBB0_67
LBB0_60:                                ; %else474
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbnz	w8, #5, LBB0_68
LBB0_61:                                ; %else477
                                        ;   in Loop: Header=BB0_55 Depth=1
	shl.2d	v22, v21, #5
	ldr	q23, [sp, #12320]               ; 16-byte Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v25, v22
	tbnz	w8, #6, LBB0_69
LBB0_62:                                ; %else480
                                        ;   in Loop: Header=BB0_55 Depth=1
	tbz	w8, #7, LBB0_54
	b	LBB0_70
LBB0_63:                                ; %cond.store460
                                        ;   in Loop: Header=BB0_55 Depth=1
	fmov	x9, d22
	str	wzr, [x9]
	tbz	w8, #1, LBB0_57
LBB0_64:                                ; %cond.store463
                                        ;   in Loop: Header=BB0_55 Depth=1
	mov.d	x9, v22[1]
	str	wzr, [x9]
	shl.2d	v22, v1, #5
	ldr	q23, [sp, #12304]               ; 16-byte Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v28, v22
	tbz	w8, #2, LBB0_58
LBB0_65:                                ; %cond.store466
                                        ;   in Loop: Header=BB0_55 Depth=1
	fmov	x9, d22
	str	wzr, [x9]
	tbz	w8, #3, LBB0_59
LBB0_66:                                ; %cond.store469
                                        ;   in Loop: Header=BB0_55 Depth=1
	mov.d	x9, v22[1]
	str	wzr, [x9]
	shl.2d	v22, v20, #5
	ldr	q23, [sp, #12352]               ; 16-byte Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v29, v22
	tbz	w8, #4, LBB0_60
LBB0_67:                                ; %cond.store472
                                        ;   in Loop: Header=BB0_55 Depth=1
	fmov	x9, d22
	str	wzr, [x9]
	tbz	w8, #5, LBB0_61
LBB0_68:                                ; %cond.store475
                                        ;   in Loop: Header=BB0_55 Depth=1
	mov.d	x9, v22[1]
	str	wzr, [x9]
	shl.2d	v22, v21, #5
	ldr	q23, [sp, #12320]               ; 16-byte Reload
	orr.16b	v22, v22, v23
	add.2d	v22, v25, v22
	tbz	w8, #6, LBB0_62
LBB0_69:                                ; %cond.store478
                                        ;   in Loop: Header=BB0_55 Depth=1
	fmov	x9, d22
	str	wzr, [x9]
	tbz	w8, #7, LBB0_54
LBB0_70:                                ; %cond.store481
                                        ;   in Loop: Header=BB0_55 Depth=1
	mov.d	x9, v22[1]
	str	wzr, [x9]
	b	LBB0_54
LBB0_71:                                ; %direct.false347
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v17, #0
	and.16b	v7, v14, v19
	str	q7, [sp, #9824]                 ; 16-byte Spill
	and.16b	v7, v12, v19
	str	q7, [sp, #9808]                 ; 16-byte Spill
	and.16b	v1, v1, v19
	str	q1, [sp, #9792]                 ; 16-byte Spill
	and.16b	v0, v0, v19
	str	q0, [sp, #9776]                 ; 16-byte Spill
	movi	d0, #0x00000000ffffff
	and.8b	v1, v26, v0
	movi.2d	v0, #0000000000000000
	str	d1, [sp, #4520]                 ; 8-byte Spill
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	ldr	d19, [sp, #13320]               ; 8-byte Reload
	and.8b	v1, v1, v19
	addv.8b	b1, v1
	str	d1, [sp, #12376]                ; 8-byte Spill
	fmov	w8, s1
	movi.2d	v1, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	str	q25, [sp, #1888]                ; 16-byte Spill
	str	q28, [sp, #1872]                ; 16-byte Spill
	str	q29, [sp, #1856]                ; 16-byte Spill
	str	q30, [sp, #1840]                ; 16-byte Spill
	str	q31, [sp, #224]                 ; 16-byte Spill
	str	d27, [sp, #11624]               ; 8-byte Spill
	b	LBB0_73
LBB0_72:                                ; %else508
                                        ;   in Loop: Header=BB0_73 Depth=1
	ldr	q21, [sp, #13296]               ; 16-byte Reload
	add.2d	v1, v1, v21
	ldr	q21, [sp, #13280]               ; 16-byte Reload
	add.2d	v19, v19, v21
	add.2d	v20, v20, v11
	ldr	q21, [sp, #13264]               ; 16-byte Reload
	add.2d	v0, v0, v21
	fmov	x9, d0
	cmp	x9, #2
	b.ge	LBB0_89
LBB0_73:                                ; %direct.true354
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v21, v0, #5
	ldr	q22, [sp, #12336]               ; 16-byte Reload
	orr.16b	v21, v21, v22
	ldr	q7, [sp, #9776]                 ; 16-byte Reload
	add.2d	v21, v7, v21
	tbnz	w8, #0, LBB0_81
; %bb.74:                               ; %else487
                                        ;   in Loop: Header=BB0_73 Depth=1
	tbnz	w8, #1, LBB0_82
LBB0_75:                                ; %else490
                                        ;   in Loop: Header=BB0_73 Depth=1
	shl.2d	v21, v1, #5
	ldr	q22, [sp, #12304]               ; 16-byte Reload
	orr.16b	v21, v21, v22
	ldr	q7, [sp, #9808]                 ; 16-byte Reload
	add.2d	v21, v7, v21
	tbnz	w8, #2, LBB0_83
LBB0_76:                                ; %else493
                                        ;   in Loop: Header=BB0_73 Depth=1
	tbnz	w8, #3, LBB0_84
LBB0_77:                                ; %else496
                                        ;   in Loop: Header=BB0_73 Depth=1
	shl.2d	v21, v19, #5
	ldr	q22, [sp, #12352]               ; 16-byte Reload
	orr.16b	v21, v21, v22
	ldr	q7, [sp, #9792]                 ; 16-byte Reload
	add.2d	v21, v7, v21
	tbnz	w8, #4, LBB0_85
LBB0_78:                                ; %else499
                                        ;   in Loop: Header=BB0_73 Depth=1
	tbnz	w8, #5, LBB0_86
LBB0_79:                                ; %else502
                                        ;   in Loop: Header=BB0_73 Depth=1
	shl.2d	v21, v20, #5
	ldr	q22, [sp, #12320]               ; 16-byte Reload
	orr.16b	v21, v21, v22
	ldr	q7, [sp, #9824]                 ; 16-byte Reload
	add.2d	v21, v7, v21
	tbnz	w8, #6, LBB0_87
LBB0_80:                                ; %else505
                                        ;   in Loop: Header=BB0_73 Depth=1
	tbz	w8, #7, LBB0_72
	b	LBB0_88
LBB0_81:                                ; %cond.store485
                                        ;   in Loop: Header=BB0_73 Depth=1
	fmov	x9, d21
	str	wzr, [x9]
	tbz	w8, #1, LBB0_75
LBB0_82:                                ; %cond.store488
                                        ;   in Loop: Header=BB0_73 Depth=1
	mov.d	x9, v21[1]
	str	wzr, [x9]
	shl.2d	v21, v1, #5
	ldr	q22, [sp, #12304]               ; 16-byte Reload
	orr.16b	v21, v21, v22
	ldr	q7, [sp, #9808]                 ; 16-byte Reload
	add.2d	v21, v7, v21
	tbz	w8, #2, LBB0_76
LBB0_83:                                ; %cond.store491
                                        ;   in Loop: Header=BB0_73 Depth=1
	fmov	x9, d21
	str	wzr, [x9]
	tbz	w8, #3, LBB0_77
LBB0_84:                                ; %cond.store494
                                        ;   in Loop: Header=BB0_73 Depth=1
	mov.d	x9, v21[1]
	str	wzr, [x9]
	shl.2d	v21, v19, #5
	ldr	q22, [sp, #12352]               ; 16-byte Reload
	orr.16b	v21, v21, v22
	ldr	q7, [sp, #9792]                 ; 16-byte Reload
	add.2d	v21, v7, v21
	tbz	w8, #4, LBB0_78
LBB0_85:                                ; %cond.store497
                                        ;   in Loop: Header=BB0_73 Depth=1
	fmov	x9, d21
	str	wzr, [x9]
	tbz	w8, #5, LBB0_79
LBB0_86:                                ; %cond.store500
                                        ;   in Loop: Header=BB0_73 Depth=1
	mov.d	x9, v21[1]
	str	wzr, [x9]
	shl.2d	v21, v20, #5
	ldr	q22, [sp, #12320]               ; 16-byte Reload
	orr.16b	v21, v21, v22
	ldr	q7, [sp, #9824]                 ; 16-byte Reload
	add.2d	v21, v7, v21
	tbz	w8, #6, LBB0_80
LBB0_87:                                ; %cond.store503
                                        ;   in Loop: Header=BB0_73 Depth=1
	fmov	x9, d21
	str	wzr, [x9]
	tbz	w8, #7, LBB0_72
LBB0_88:                                ; %cond.store506
                                        ;   in Loop: Header=BB0_73 Depth=1
	mov.d	x9, v21[1]
	str	wzr, [x9]
	b	LBB0_72
LBB0_89:                                ; %direct.schedule.23.preheader
	sshll.2d	v19, v24, #0
	mov	w8, #2                          ; =0x2
	dup.2d	v1, x8
	mov.16b	v8, v17
	sshll.2d	v20, v8, #0
	ushr.2d	v0, v18, #2
	ldr	q7, [sp, #13216]                ; 16-byte Reload
	ushr.2d	v18, v7, #2
	ldr	q7, [sp, #13200]                ; 16-byte Reload
	ushr.2d	v17, v7, #2
	ldr	q7, [sp, #13232]                ; 16-byte Reload
	ushr.2d	v21, v7, #2
	mov	w8, #7                          ; =0x7
	dup.2d	v16, x8
	and.16b	v7, v14, v16
	sub.2d	v7, v7, v3
	str	q7, [sp, #4480]                 ; 16-byte Spill
	and.16b	v7, v12, v16
	sub.2d	v7, v7, v2
	str	q7, [sp, #4464]                 ; 16-byte Spill
	and.16b	v22, v20, v16
	mvn.16b	v7, v20
	sub.2d	v22, v22, v7
	str	q22, [sp, #4448]                ; 16-byte Spill
	and.16b	v22, v19, v16
	mvn.16b	v16, v19
	sub.2d	v22, v22, v16
	str	q22, [sp, #4432]                ; 16-byte Spill
	mov	w8, #5                          ; =0x5
	dup.2d	v22, x8
	and.16b	v23, v14, v22
	sub.2d	v23, v23, v3
	str	q23, [sp, #13216]               ; 16-byte Spill
	and.16b	v23, v12, v22
	sub.2d	v23, v23, v2
	str	q23, [sp, #13200]               ; 16-byte Spill
	and.16b	v23, v20, v22
	sub.2d	v23, v23, v7
	str	q23, [sp, #13184]               ; 16-byte Spill
	and.16b	v22, v19, v22
	mov.d	x16, v21[1]
	sub.2d	v22, v22, v16
	str	q22, [sp, #13168]               ; 16-byte Spill
	fmov	x17, d21
	mov.d	x0, v17[1]
	mov.d	x1, v18[1]
	fmov	x3, d17
	fmov	x2, d18
	mov.d	x4, v0[1]
	fmov	x5, d0
	movi	d17, #0x00000000ffffff
	ldr	d0, [sp, #11616]                ; 8-byte Reload
	orr.8b	v17, v0, v17
	mov	b0, v17[6]
	mov.b	v0[4], v17[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q18, [sp, #13040]               ; 16-byte Reload
	bsl.16b	v0, v18, v1
	str	q0, [sp, #4400]                 ; 16-byte Spill
	mov	b0, v17[4]
	mov.b	v0[4], v17[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q22, [sp, #13056]               ; 16-byte Reload
	bsl.16b	v0, v22, v1
	str	q0, [sp, #4384]                 ; 16-byte Spill
	mov	b0, v17[2]
	str	q17, [sp, #4416]                ; 16-byte Spill
	mov.b	v0[4], v17[3]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v17, v0, #0
	mov	w8, #33                         ; =0x21
	dup.2d	v0, x8
	ldr	q21, [sp, #13072]               ; 16-byte Reload
	bit.16b	v1, v21, v17
	str	q1, [sp, #4368]                 ; 16-byte Spill
	and.16b	v1, v14, v0
	sub.2d	v1, v1, v3
	str	q1, [sp, #4352]                 ; 16-byte Spill
	and.16b	v1, v12, v0
	sub.2d	v1, v1, v2
	str	q1, [sp, #4336]                 ; 16-byte Spill
	and.16b	v1, v20, v0
	sub.2d	v1, v1, v7
	str	q1, [sp, #4320]                 ; 16-byte Spill
	and.16b	v1, v19, v0
	sub.2d	v1, v1, v16
	str	q1, [sp, #4304]                 ; 16-byte Spill
	mov	w8, #8                          ; =0x8
	dup.2d	v1, x8
	and.16b	v17, v14, v1
	sub.2d	v3, v17, v3
	str	q3, [sp, #13008]                ; 16-byte Spill
	and.16b	v3, v12, v1
	sub.2d	v2, v3, v2
	str	q2, [sp, #12992]                ; 16-byte Spill
	and.16b	v2, v20, v1
	sub.2d	v2, v2, v7
	str	q2, [sp, #12976]                ; 16-byte Spill
	and.16b	v1, v19, v1
	sub.2d	v1, v1, v16
	str	q1, [sp, #12960]                ; 16-byte Spill
	ldr	q16, [sp, #13104]               ; 16-byte Reload
	uzp1.4s	v1, v16, v21
	uzp1.4s	v2, v22, v18
	movi.4s	v7, #1
	eor.16b	v3, v1, v7
	mov.s	w14, v3[1]
	str	x14, [sp, #12928]               ; 8-byte Spill
	mov.s	w23, v3[2]
	str	x23, [sp, #12912]               ; 8-byte Spill
	mov.s	w24, v3[3]
	str	x24, [sp, #12896]               ; 8-byte Spill
	eor.16b	v7, v2, v7
	fmov	w19, s3
	mov.s	w30, v7[1]
	mov.s	w25, v7[2]
	str	x25, [sp, #12768]               ; 8-byte Spill
	mov.s	w28, v7[3]
	fmov	w26, s7
	movi.4s	v3, #2
	eor.16b	v2, v2, v3
	eor.16b	v3, v1, v3
	mov.s	w8, v3[1]
	str	x8, [sp, #12784]                ; 8-byte Spill
	mov.s	w8, v3[2]
	str	x8, [sp, #12800]                ; 8-byte Spill
	mov.s	w8, v3[3]
	str	x8, [sp, #12816]                ; 8-byte Spill
	and.16b	v7, v14, v6
	str	q7, [sp, #5792]                 ; 16-byte Spill
	fmov	w22, s3
	mov.s	w6, v2[3]
	str	x6, [sp, #12752]                ; 8-byte Spill
	mov.s	w8, v2[1]
	str	x8, [sp, #12832]                ; 8-byte Spill
	and.16b	v3, v12, v6
	str	q3, [sp, #5776]                 ; 16-byte Spill
	mov.s	w8, v2[2]
	str	x8, [sp, #12848]                ; 8-byte Spill
	fmov	w20, s2
	movi.4s	v2, #4
	eor.16b	v1, v1, v2
	and.16b	v2, v20, v6
	str	q2, [sp, #5760]                 ; 16-byte Spill
	and.16b	v2, v19, v6
	str	q2, [sp, #5744]                 ; 16-byte Spill
	str	x10, [sp, #11400]               ; 8-byte Spill
	mov.s	w15, v1[1]
	str	x15, [sp, #12736]               ; 8-byte Spill
	str	x11, [sp, #11632]               ; 8-byte Spill
	mov.s	w10, v1[2]
	str	x10, [sp, #12720]               ; 8-byte Spill
	str	x12, [sp, #11640]               ; 8-byte Spill
	mov.s	w12, v1[3]
	str	x12, [sp, #12704]               ; 8-byte Spill
	fmov	w21, s1
	and.16b	v1, v14, v5
	str	q1, [sp, #5728]                 ; 16-byte Spill
	and.16b	v1, v12, v5
	str	q1, [sp, #5712]                 ; 16-byte Spill
	and.16b	v1, v20, v5
	str	q1, [sp, #5696]                 ; 16-byte Spill
	and.16b	v1, v19, v5
	str	q1, [sp, #5680]                 ; 16-byte Spill
	and.16b	v1, v14, v4
	str	q1, [sp, #8032]                 ; 16-byte Spill
	and.16b	v1, v12, v4
	str	q1, [sp, #8016]                 ; 16-byte Spill
	and.16b	v1, v20, v4
	str	q1, [sp, #8000]                 ; 16-byte Spill
	and.16b	v1, v19, v4
	str	q1, [sp, #7984]                 ; 16-byte Spill
	mov	w8, #35                         ; =0x23
	mul	x9, x16, x8
	mul	x16, x17, x8
	mov	w7, #1                          ; =0x1
	fmov	d1, x16
	mov.d	v1[1], x9
	mul	x9, x0, x8
	mul	x16, x3, x8
	fmov	d2, x16
	mov.d	v2[1], x9
	mul	x9, x1, x8
	mul	x16, x2, x8
	fmov	d3, x16
	mov.d	v3[1], x9
	mul	x9, x4, x8
	mul	x16, x5, x8
	fmov	d4, x16
	mov.d	v4[1], x9
	and.16b	v4, v19, v4
	and.16b	v3, v12, v3
	stp	q3, q4, [sp, #192]              ; 32-byte Folded Spill
	and.16b	v2, v20, v2
	umov.b	w16, v26[0]
	umov.b	w17, v26[1]
	umov.b	w0, v26[2]
	and.16b	v1, v14, v1
	stp	q1, q2, [sp, #160]              ; 32-byte Folded Spill
	umov.b	w1, v26[3]
	sub.2d	v9, v0, v22
	sub.2d	v1, v0, v21
	str	q1, [sp, #13152]                ; 16-byte Spill
	sub.2d	v1, v0, v16
	str	q1, [sp, #13120]                ; 16-byte Spill
	sub.2d	v0, v0, v18
	str	q0, [sp, #13232]                ; 16-byte Spill
	dup.2d	v0, x7
	and.16b	v2, v20, v0
	and.16b	v1, v14, v0
	stp	q1, q2, [sp, #48]               ; 32-byte Folded Spill
	and.16b	v0, v12, v0
	str	q0, [sp, #2880]                 ; 16-byte Spill
	ldr	q0, [sp, #5808]                 ; 16-byte Reload
	and.16b	v0, v19, v0
	str	q0, [sp, #2864]                 ; 16-byte Spill
	movi	d0, #0xffffffffffff0000
	and.8b	v4, v26, v0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x19, #0, #3
	str	d26, [sp, #18152]
	ldrb	w9, [x9]
	and	w8, w16, w9
	str	w8, [sp, #7980]                 ; 4-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x14, #0, #3
	ldrb	w9, [x9]
	and	w8, w17, w9
	str	w8, [sp, #7976]                 ; 4-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x23, #0, #3
	ldrb	w9, [x9]
	and	w8, w0, w9
	str	w8, [sp, #7972]                 ; 4-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x24, #0, #3
	ldrb	w9, [x9]
	and	w8, w1, w9
	str	w8, [sp, #7968]                 ; 4-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x26, #0, #3
	mov	x11, x26
	ldrb	w9, [x9]
	movi	d0, #0xffffffffff000000
	and.8b	v2, v26, v0
	ldr	q3, [sp, #11648]                ; 16-byte Reload
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	umov.b	w2, v26[4]
	and	w8, w2, w9
	str	w8, [sp, #7964]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2848]                 ; 16-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x30, #0, #3
	ldrb	w9, [x9]
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2832]                 ; 16-byte Spill
	umov.b	w3, v26[5]
	and	w8, w3, w9
	str	w8, [sp, #7960]                 ; 4-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x25, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w9, [x9]
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2816]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	umov.b	w4, v26[6]
	and	w8, w4, w9
	str	w8, [sp, #7956]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2800]                 ; 16-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x28, #0, #3
	ldrb	w9, [x9]
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2784]                 ; 16-byte Spill
	umov.b	w5, v26[7]
	mov.16b	v26, v8
	and	w8, w5, w9
	str	w8, [sp, #7952]                 ; 4-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x22, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w9, [x9]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2768]                 ; 16-byte Spill
	and	w8, w16, w9
	str	w8, [sp, #7948]                 ; 4-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	ldr	x27, [sp, #12784]               ; 8-byte Reload
	bfxil	x9, x27, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w9, [x9]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2752]                 ; 16-byte Spill
	and	w8, w17, w9
	str	w8, [sp, #7944]                 ; 4-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	ldr	x26, [sp, #12800]               ; 8-byte Reload
	bfxil	x9, x26, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w9, [x9]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2736]                 ; 16-byte Spill
	and	w8, w0, w9
	str	w8, [sp, #7940]                 ; 4-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	ldr	x25, [sp, #12816]               ; 8-byte Reload
	bfxil	x9, x25, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w9, [x9]
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2720]                 ; 16-byte Spill
	and	w8, w1, w9
	str	w8, [sp, #7936]                 ; 4-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	bfxil	x9, x20, #0, #3
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2704]                 ; 16-byte Spill
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #1768
	bfxil	x7, x6, #0, #3
	ldrb	w7, [x7]
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x21, #0, #3
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2688]                 ; 16-byte Spill
	ldrb	w14, [x8]
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x15, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w15, [x8]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2672]                 ; 16-byte Spill
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1768
	bfxil	x8, x10, #0, #3
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ldrb	w8, [x8]
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2656]                 ; 16-byte Spill
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #1768
	bfxil	x23, x12, #0, #3
	ldrb	w23, [x23]
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ldrb	w9, [x9]
	shl.4s	v0, v0, #31
	and	w9, w2, w9
	str	w9, [sp, #7932]                 ; 4-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2640]                 ; 16-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	ldr	x24, [sp, #12832]               ; 8-byte Reload
	bfxil	x9, x24, #0, #3
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ldrb	w9, [x9]
	shl.4s	v0, v0, #31
	and	w9, w3, w9
	str	w9, [sp, #7928]                 ; 4-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2624]                 ; 16-byte Spill
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1768
	ldr	x12, [sp, #12848]               ; 8-byte Reload
	bfxil	x9, x12, #0, #3
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ldrb	w9, [x9]
	shl.4s	v0, v0, #31
	and	w9, w4, w9
	str	w9, [sp, #7924]                 ; 4-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2608]                 ; 16-byte Spill
	and	w9, w5, w7
	str	w9, [sp, #7920]                 ; 4-byte Spill
	and	w9, w16, w14
	str	w9, [sp, #7916]                 ; 4-byte Spill
	mvni.4s	v0, #127, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #11232]                ; 16-byte Spill
	and	w9, w17, w15
	str	w9, [sp, #7912]                 ; 4-byte Spill
	and	w8, w0, w8
	str	w8, [sp, #7908]                 ; 4-byte Spill
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #11216]                ; 16-byte Spill
	and	w8, w1, w23
	str	w8, [sp, #7904]                 ; 4-byte Spill
	ldr	w8, [sp, #12944]                ; 4-byte Reload
	rbit	w8, w8
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	clz	w9, w8
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2592]                 ; 16-byte Spill
	mov	x7, x19
                                        ; kill: def $w19 killed $w19 killed $x19 def $x19
	ubfiz	x8, x19, #2, #3
	str	x8, [sp, #4296]                 ; 8-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	mov	x19, x11
                                        ; kill: def $w11 killed $w11 killed $x11 def $x11
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2576]                 ; 16-byte Spill
	ubfiz	x8, x11, #2, #3
	str	x8, [sp, #4288]                 ; 8-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	mov	x6, x22
                                        ; kill: def $w22 killed $w22 killed $x22 def $x22
	shl.4s	v0, v0, #31
	ubfiz	x8, x22, #2, #3
	str	x8, [sp, #4280]                 ; 8-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2560]                 ; 16-byte Spill
	mov	x15, x20
                                        ; kill: def $w20 killed $w20 killed $x20 def $x20
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ubfiz	x8, x20, #2, #3
	str	x8, [sp, #4272]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2544]                 ; 16-byte Spill
	mov	x8, x21
                                        ; kill: def $w21 killed $w21 killed $x21 def $x21
	ubfiz	x10, x21, #2, #3
	str	x10, [sp, #4264]                ; 8-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2528]                 ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2512]                 ; 16-byte Spill
	ubfiz	x10, x7, #2, #3
	str	x10, [sp, #4256]                ; 8-byte Spill
	ldr	x11, [sp, #12928]               ; 8-byte Reload
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4248]                ; 8-byte Spill
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4240]                ; 8-byte Spill
	ldr	x11, [sp, #12912]               ; 8-byte Reload
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4232]                ; 8-byte Spill
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4224]                ; 8-byte Spill
	ldr	x11, [sp, #12896]               ; 8-byte Reload
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4216]                ; 8-byte Spill
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4208]                ; 8-byte Spill
	ubfiz	x10, x19, #2, #3
	str	x10, [sp, #4200]                ; 8-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ubfiz	x10, x30, #2, #3
	str	x10, [sp, #4192]                ; 8-byte Spill
	ubfiz	x10, x30, #2, #3
	str	x10, [sp, #4184]                ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2496]                 ; 16-byte Spill
	ldr	x11, [sp, #12768]               ; 8-byte Reload
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4176]                ; 8-byte Spill
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4168]                ; 8-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ubfiz	x10, x28, #2, #3
	str	x10, [sp, #4160]                ; 8-byte Spill
	ubfiz	x10, x28, #2, #3
	str	x10, [sp, #4152]                ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2480]                 ; 16-byte Spill
	ubfiz	x10, x6, #2, #3
	str	x10, [sp, #4144]                ; 8-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ubfiz	x10, x27, #2, #3
	str	x10, [sp, #4136]                ; 8-byte Spill
	ubfiz	x10, x27, #2, #3
	str	x10, [sp, #4128]                ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2464]                 ; 16-byte Spill
	ubfiz	x10, x26, #2, #3
	str	x10, [sp, #4120]                ; 8-byte Spill
	ubfiz	x10, x26, #2, #3
	str	x10, [sp, #4112]                ; 8-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	ubfiz	x10, x25, #2, #3
	str	x10, [sp, #4104]                ; 8-byte Spill
	ubfiz	x10, x25, #2, #3
	str	x10, [sp, #4096]                ; 8-byte Spill
	shl.4s	v0, v0, #31
	ubfiz	x10, x15, #2, #3
	str	x10, [sp, #4088]                ; 8-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2448]                 ; 16-byte Spill
	ubfiz	x10, x24, #2, #3
	str	x10, [sp, #4080]                ; 8-byte Spill
	ubfiz	x10, x24, #2, #3
	str	x10, [sp, #4072]                ; 8-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ubfiz	x10, x12, #2, #3
	str	x10, [sp, #4064]                ; 8-byte Spill
	ubfiz	x10, x12, #2, #3
	str	x10, [sp, #4056]                ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2432]                 ; 16-byte Spill
	ldr	x11, [sp, #12752]               ; 8-byte Reload
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4048]                ; 8-byte Spill
	ubfiz	x10, x11, #2, #3
	str	x10, [sp, #4040]                ; 8-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	ubfiz	x8, x8, #2, #3
	str	x8, [sp, #4032]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2416]                 ; 16-byte Spill
	ldr	x10, [sp, #12736]               ; 8-byte Reload
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4024]                 ; 8-byte Spill
	and	x8, x10, #0x7
	str	x8, [sp, #4016]                 ; 8-byte Spill
	ldr	x27, [sp, #11400]               ; 8-byte Reload
	ldr	d1, [sp, #4520]                 ; 8-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	ldr	x10, [sp, #12720]               ; 8-byte Reload
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #4008]                 ; 8-byte Spill
	and	x8, x10, #0x7
	str	x8, [sp, #4000]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3984]                 ; 16-byte Spill
	ldr	x10, [sp, #12704]               ; 8-byte Reload
	ubfiz	x8, x10, #2, #3
	str	x8, [sp, #3976]                 ; 8-byte Spill
	and	x8, x10, #0x7
	str	x8, [sp, #3968]                 ; 8-byte Spill
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	and	x8, x9, #0x7
	str	x8, [sp, #3960]                 ; 8-byte Spill
	and	x8, x9, #0x7
	str	x8, [sp, #3952]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3936]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3920]                 ; 16-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3904]                 ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3888]                 ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3872]                 ; 16-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3856]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3840]                 ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #11776]                ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #11760]                ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2400]                 ; 16-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2384]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2368]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2352]                 ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2336]                 ; 16-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2320]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2304]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2288]                 ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3824]                 ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3808]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3792]                 ; 16-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3776]                 ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2272]                 ; 16-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2256]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2240]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2224]                 ; 16-byte Spill
	zip1.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2208]                 ; 16-byte Spill
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #2192]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2176]                 ; 16-byte Spill
	str	q4, [sp, #144]                  ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #2160]                 ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3760]                 ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #3744]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3728]                 ; 16-byte Spill
	str	d2, [sp, #40]                   ; 8-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #3712]                 ; 16-byte Spill
Lloh24:
	adrp	x6, lCPI0_13@PAGE
Lloh25:
	adrp	x12, lCPI0_14@PAGE
Lloh26:
	adrp	x15, lCPI0_15@PAGE
Lloh27:
	adrp	x10, lCPI0_16@PAGE
Lloh28:
	adrp	x11, lCPI0_17@PAGE
Lloh29:
	adrp	x28, lCPI0_18@PAGE
Lloh30:
	adrp	x30, lCPI0_19@PAGE
Lloh31:
	adrp	x14, lCPI0_20@PAGE
Lloh32:
	adrp	x8, lCPI0_21@PAGE
Lloh33:
	adrp	x26, lCPI0_23@PAGE
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #10880]                ; 16-byte Spill
	str	q0, [sp, #10864]                ; 16-byte Spill
	str	q0, [sp, #12160]                ; 16-byte Spill
	str	q0, [sp, #12144]                ; 16-byte Spill
	str	q0, [sp, #12128]                ; 16-byte Spill
	str	q0, [sp, #12720]                ; 16-byte Spill
	str	q0, [sp, #12704]                ; 16-byte Spill
	str	q0, [sp, #4768]                 ; 16-byte Spill
	str	q0, [sp, #6512]                 ; 16-byte Spill
	str	q0, [sp, #11488]                ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	movi.2d	v20, #0000000000000000
	str	q0, [sp, #1360]                 ; 16-byte Spill
	str	q0, [sp, #12656]                ; 16-byte Spill
	str	q0, [sp, #12608]                ; 16-byte Spill
	str	q0, [sp, #12688]                ; 16-byte Spill
	str	q0, [sp, #12672]                ; 16-byte Spill
	str	q0, [sp, #9760]                 ; 16-byte Spill
	str	q0, [sp, #9744]                 ; 16-byte Spill
	str	q0, [sp, #9728]                 ; 16-byte Spill
	str	q0, [sp, #9712]                 ; 16-byte Spill
	str	q0, [sp, #12640]                ; 16-byte Spill
	str	q0, [sp, #12624]                ; 16-byte Spill
	str	q0, [sp, #5840]                 ; 16-byte Spill
	str	q0, [sp, #1824]                 ; 16-byte Spill
	str	q0, [sp, #9696]                 ; 16-byte Spill
	str	q0, [sp, #9680]                 ; 16-byte Spill
	str	q0, [sp, #9664]                 ; 16-byte Spill
	str	q0, [sp, #9648]                 ; 16-byte Spill
	str	q0, [sp, #9632]                 ; 16-byte Spill
	str	q0, [sp, #9616]                 ; 16-byte Spill
	str	q0, [sp, #7872]                 ; 16-byte Spill
	str	q0, [sp, #7888]                 ; 16-byte Spill
	str	q0, [sp, #5824]                 ; 16-byte Spill
	str	q0, [sp, #1808]                 ; 16-byte Spill
	str	q0, [sp, #9600]                 ; 16-byte Spill
	str	q0, [sp, #9584]                 ; 16-byte Spill
	str	q0, [sp, #9568]                 ; 16-byte Spill
	str	q0, [sp, #9552]                 ; 16-byte Spill
	str	q0, [sp, #9536]                 ; 16-byte Spill
	str	q0, [sp, #9520]                 ; 16-byte Spill
	str	q0, [sp, #9504]                 ; 16-byte Spill
	str	q0, [sp, #9488]                 ; 16-byte Spill
	str	q0, [sp, #1792]                 ; 16-byte Spill
	str	q0, [sp, #2016]                 ; 16-byte Spill
	str	q0, [sp, #1776]                 ; 16-byte Spill
	str	q0, [sp, #2000]                 ; 16-byte Spill
	str	q0, [sp, #9472]                 ; 16-byte Spill
	str	q0, [sp, #9456]                 ; 16-byte Spill
	str	q0, [sp, #9440]                 ; 16-byte Spill
	str	q0, [sp, #9424]                 ; 16-byte Spill
	str	q0, [sp, #9408]                 ; 16-byte Spill
	str	q0, [sp, #9392]                 ; 16-byte Spill
	str	q0, [sp, #7856]                 ; 16-byte Spill
	str	q0, [sp, #7840]                 ; 16-byte Spill
	str	q0, [sp, #1760]                 ; 16-byte Spill
	str	q0, [sp, #1744]                 ; 16-byte Spill
	str	q0, [sp, #1728]                 ; 16-byte Spill
	str	q0, [sp, #1712]                 ; 16-byte Spill
	str	q0, [sp, #9376]                 ; 16-byte Spill
	str	q0, [sp, #9360]                 ; 16-byte Spill
	str	q0, [sp, #9344]                 ; 16-byte Spill
	str	q0, [sp, #9328]                 ; 16-byte Spill
	str	q0, [sp, #7824]                 ; 16-byte Spill
	str	q0, [sp, #7808]                 ; 16-byte Spill
	str	q0, [sp, #1696]                 ; 16-byte Spill
	str	q0, [sp, #1680]                 ; 16-byte Spill
	str	q0, [sp, #9312]                 ; 16-byte Spill
	str	q0, [sp, #9296]                 ; 16-byte Spill
	str	q0, [sp, #9280]                 ; 16-byte Spill
	str	q0, [sp, #9264]                 ; 16-byte Spill
	str	q0, [sp, #7792]                 ; 16-byte Spill
	str	q0, [sp, #7776]                 ; 16-byte Spill
	str	q0, [sp, #7696]                 ; 16-byte Spill
	str	q0, [sp, #7680]                 ; 16-byte Spill
	str	q0, [sp, #1664]                 ; 16-byte Spill
	str	q0, [sp, #4752]                 ; 16-byte Spill
	str	q0, [sp, #9248]                 ; 16-byte Spill
	str	q0, [sp, #9232]                 ; 16-byte Spill
	str	q0, [sp, #9216]                 ; 16-byte Spill
	str	q0, [sp, #9200]                 ; 16-byte Spill
	str	q0, [sp, #9184]                 ; 16-byte Spill
	str	q0, [sp, #9168]                 ; 16-byte Spill
	str	q0, [sp, #1648]                 ; 16-byte Spill
	str	q0, [sp, #1632]                 ; 16-byte Spill
	str	q0, [sp, #8080]                 ; 16-byte Spill
	str	q0, [sp, #8064]                 ; 16-byte Spill
	str	q0, [sp, #9152]                 ; 16-byte Spill
	str	q0, [sp, #9136]                 ; 16-byte Spill
	str	q0, [sp, #9120]                 ; 16-byte Spill
	str	q0, [sp, #9104]                 ; 16-byte Spill
	str	q0, [sp, #9088]                 ; 16-byte Spill
	str	q0, [sp, #9072]                 ; 16-byte Spill
	str	q0, [sp, #9056]                 ; 16-byte Spill
	str	q0, [sp, #9040]                 ; 16-byte Spill
	str	q0, [sp, #4736]                 ; 16-byte Spill
	str	q0, [sp, #1616]                 ; 16-byte Spill
	str	q0, [sp, #1600]                 ; 16-byte Spill
	str	q0, [sp, #1584]                 ; 16-byte Spill
	str	q0, [sp, #9024]                 ; 16-byte Spill
	str	q0, [sp, #9008]                 ; 16-byte Spill
	str	q0, [sp, #3696]                 ; 16-byte Spill
	str	q0, [sp, #3680]                 ; 16-byte Spill
	str	q0, [sp, #7760]                 ; 16-byte Spill
	str	q0, [sp, #7744]                 ; 16-byte Spill
	str	q0, [sp, #7728]                 ; 16-byte Spill
	str	q0, [sp, #7712]                 ; 16-byte Spill
	str	q0, [sp, #3664]                 ; 16-byte Spill
	str	q0, [sp, #3648]                 ; 16-byte Spill
	str	q0, [sp, #3632]                 ; 16-byte Spill
	str	q0, [sp, #3616]                 ; 16-byte Spill
	str	q0, [sp, #3600]                 ; 16-byte Spill
	str	q0, [sp, #3584]                 ; 16-byte Spill
	str	q0, [sp, #3568]                 ; 16-byte Spill
	str	q0, [sp, #3552]                 ; 16-byte Spill
	str	q0, [sp, #1568]                 ; 16-byte Spill
	str	q0, [sp, #10400]                ; 16-byte Spill
	str	q0, [sp, #10384]                ; 16-byte Spill
	str	q0, [sp, #10368]                ; 16-byte Spill
	str	q0, [sp, #3536]                 ; 16-byte Spill
	str	q0, [sp, #3520]                 ; 16-byte Spill
	str	q0, [sp, #3504]                 ; 16-byte Spill
	str	q0, [sp, #3488]                 ; 16-byte Spill
	str	q0, [sp, #3472]                 ; 16-byte Spill
	str	q0, [sp, #3456]                 ; 16-byte Spill
	str	q0, [sp, #5664]                 ; 16-byte Spill
	str	q0, [sp, #5648]                 ; 16-byte Spill
	str	q0, [sp, #10352]                ; 16-byte Spill
	str	q0, [sp, #10336]                ; 16-byte Spill
	str	q0, [sp, #10320]                ; 16-byte Spill
	str	q0, [sp, #10304]                ; 16-byte Spill
	str	q0, [sp, #3440]                 ; 16-byte Spill
	str	q0, [sp, #3424]                 ; 16-byte Spill
	str	q0, [sp, #3408]                 ; 16-byte Spill
	str	q0, [sp, #3392]                 ; 16-byte Spill
	str	q0, [sp, #5616]                 ; 16-byte Spill
	str	q0, [sp, #5632]                 ; 16-byte Spill
	str	q0, [sp, #4720]                 ; 16-byte Spill
	str	q0, [sp, #1552]                 ; 16-byte Spill
	str	q0, [sp, #3376]                 ; 16-byte Spill
	str	q0, [sp, #3360]                 ; 16-byte Spill
	str	q0, [sp, #3344]                 ; 16-byte Spill
	str	q0, [sp, #3328]                 ; 16-byte Spill
	str	q0, [sp, #5584]                 ; 16-byte Spill
	str	q0, [sp, #5600]                 ; 16-byte Spill
	str	q0, [sp, #5568]                 ; 16-byte Spill
	str	q0, [sp, #5552]                 ; 16-byte Spill
	str	q0, [sp, #1536]                 ; 16-byte Spill
	str	q0, [sp, #1520]                 ; 16-byte Spill
	str	q0, [sp, #6352]                 ; 16-byte Spill
	str	q0, [sp, #6336]                 ; 16-byte Spill
	str	q0, [sp, #6320]                 ; 16-byte Spill
	str	q0, [sp, #6304]                 ; 16-byte Spill
	str	q0, [sp, #6288]                 ; 16-byte Spill
	str	q0, [sp, #6272]                 ; 16-byte Spill
	str	q0, [sp, #10288]                ; 16-byte Spill
	str	q0, [sp, #10272]                ; 16-byte Spill
	str	q0, [sp, #10256]                ; 16-byte Spill
	str	q0, [sp, #10240]                ; 16-byte Spill
	str	q0, [sp, #6256]                 ; 16-byte Spill
	str	q0, [sp, #6240]                 ; 16-byte Spill
	str	q0, [sp, #8992]                 ; 16-byte Spill
	str	q0, [sp, #8976]                 ; 16-byte Spill
	str	q0, [sp, #5520]                 ; 16-byte Spill
	str	q0, [sp, #5536]                 ; 16-byte Spill
	str	q0, [sp, #5504]                 ; 16-byte Spill
	str	q0, [sp, #5488]                 ; 16-byte Spill
	str	q0, [sp, #8960]                 ; 16-byte Spill
	str	q0, [sp, #8944]                 ; 16-byte Spill
	str	q0, [sp, #8928]                 ; 16-byte Spill
	str	q0, [sp, #8912]                 ; 16-byte Spill
	str	q0, [sp, #8896]                 ; 16-byte Spill
	str	q0, [sp, #8880]                 ; 16-byte Spill
	str	q0, [sp, #10768]                ; 16-byte Spill
	str	q0, [sp, #10784]                ; 16-byte Spill
	str	q0, [sp, #1504]                 ; 16-byte Spill
	str	q0, [sp, #8864]                 ; 16-byte Spill
	str	q0, [sp, #8848]                 ; 16-byte Spill
	str	q0, [sp, #8832]                 ; 16-byte Spill
	str	q0, [sp, #10848]                ; 16-byte Spill
	str	q0, [sp, #10832]                ; 16-byte Spill
	str	q0, [sp, #10816]                ; 16-byte Spill
	str	q0, [sp, #10800]                ; 16-byte Spill
	str	q0, [sp, #10720]                ; 16-byte Spill
	str	q0, [sp, #10736]                ; 16-byte Spill
	str	q0, [sp, #11200]                ; 16-byte Spill
	str	q0, [sp, #11184]                ; 16-byte Spill
	str	q0, [sp, #7632]                 ; 16-byte Spill
	str	q0, [sp, #7456]                 ; 16-byte Spill
	str	q0, [sp, #7232]                 ; 16-byte Spill
	str	q0, [sp, #7184]                 ; 16-byte Spill
	str	q0, [sp, #11168]                ; 16-byte Spill
	str	q0, [sp, #11152]                ; 16-byte Spill
	str	q0, [sp, #11136]                ; 16-byte Spill
	str	q0, [sp, #11120]                ; 16-byte Spill
	str	q0, [sp, #11104]                ; 16-byte Spill
	str	q0, [sp, #11088]                ; 16-byte Spill
	str	q0, [sp, #7664]                 ; 16-byte Spill
	str	q0, [sp, #7648]                 ; 16-byte Spill
	str	q0, [sp, #1488]                 ; 16-byte Spill
	str	q0, [sp, #1472]                 ; 16-byte Spill
	str	q0, [sp, #1456]                 ; 16-byte Spill
	str	q0, [sp, #4704]                 ; 16-byte Spill
	str	q0, [sp, #7616]                 ; 16-byte Spill
	str	q0, [sp, #7600]                 ; 16-byte Spill
	str	q0, [sp, #7584]                 ; 16-byte Spill
	str	q0, [sp, #7568]                 ; 16-byte Spill
	str	q0, [sp, #7552]                 ; 16-byte Spill
	str	q0, [sp, #7536]                 ; 16-byte Spill
	str	q0, [sp, #12288]                ; 16-byte Spill
	str	q0, [sp, #12272]                ; 16-byte Spill
	str	q0, [sp, #12256]                ; 16-byte Spill
	str	q0, [sp, #12240]                ; 16-byte Spill
	str	q0, [sp, #7504]                 ; 16-byte Spill
	str	q0, [sp, #7520]                 ; 16-byte Spill
	str	q0, [sp, #1440]                 ; 16-byte Spill
	str	q0, [sp, #1424]                 ; 16-byte Spill
	str	q0, [sp, #12224]                ; 16-byte Spill
	str	q0, [sp, #12208]                ; 16-byte Spill
	str	q0, [sp, #12192]                ; 16-byte Spill
	str	q0, [sp, #12176]                ; 16-byte Spill
	str	q0, [sp, #7488]                 ; 16-byte Spill
	str	q0, [sp, #7472]                 ; 16-byte Spill
	str	q0, [sp, #7440]                 ; 16-byte Spill
	str	q0, [sp, #7424]                 ; 16-byte Spill
	str	q0, [sp, #1408]                 ; 16-byte Spill
	str	q0, [sp, #1392]                 ; 16-byte Spill
	str	q0, [sp, #10752]                ; 16-byte Spill
	str	q0, [sp, #7408]                 ; 16-byte Spill
	str	q0, [sp, #7392]                 ; 16-byte Spill
	str	q0, [sp, #7376]                 ; 16-byte Spill
	str	q0, [sp, #7360]                 ; 16-byte Spill
	str	q0, [sp, #7344]                 ; 16-byte Spill
	str	q0, [sp, #6224]                 ; 16-byte Spill
	str	q0, [sp, #6208]                 ; 16-byte Spill
	str	q0, [sp, #6192]                 ; 16-byte Spill
	str	q0, [sp, #6176]                 ; 16-byte Spill
	str	q0, [sp, #7328]                 ; 16-byte Spill
	str	q0, [sp, #7312]                 ; 16-byte Spill
	str	q0, [sp, #10928]                ; 16-byte Spill
	str	q0, [sp, #11072]                ; 16-byte Spill
	str	q0, [sp, #6160]                 ; 16-byte Spill
	str	q0, [sp, #6144]                 ; 16-byte Spill
	str	q0, [sp, #6128]                 ; 16-byte Spill
	str	q0, [sp, #6112]                 ; 16-byte Spill
	str	q0, [sp, #7296]                 ; 16-byte Spill
	str	q0, [sp, #11056]                ; 16-byte Spill
	str	q0, [sp, #7280]                 ; 16-byte Spill
	str	q0, [sp, #7264]                 ; 16-byte Spill
	str	q0, [sp, #10912]                ; 16-byte Spill
	str	q0, [sp, #10896]                ; 16-byte Spill
	str	q0, [sp, #7248]                 ; 16-byte Spill
	str	q0, [sp, #7216]                 ; 16-byte Spill
	str	q0, [sp, #7200]                 ; 16-byte Spill
	str	q0, [sp, #11472]                ; 16-byte Spill
	str	q0, [sp, #4688]                 ; 16-byte Spill
	str	q0, [sp, #4672]                 ; 16-byte Spill
	str	q0, [sp, #10528]                ; 16-byte Spill
	str	q0, [sp, #10512]                ; 16-byte Spill
	str	q0, [sp, #10496]                ; 16-byte Spill
	str	q0, [sp, #12592]                ; 16-byte Spill
	str	q0, [sp, #12576]                ; 16-byte Spill
	str	q0, [sp, #12944]                ; 16-byte Spill
	str	q0, [sp, #1376]                 ; 16-byte Spill
	str	q0, [sp, #10480]                ; 16-byte Spill
	str	q0, [sp, #10464]                ; 16-byte Spill
	str	q0, [sp, #10448]                ; 16-byte Spill
	str	q0, [sp, #10432]                ; 16-byte Spill
	str	q0, [sp, #10416]                ; 16-byte Spill
	str	q0, [sp, #5472]                 ; 16-byte Spill
	str	q0, [sp, #5456]                 ; 16-byte Spill
	str	q0, [sp, #5440]                 ; 16-byte Spill
	str	q0, [sp, #10224]                ; 16-byte Spill
	str	q0, [sp, #10208]                ; 16-byte Spill
	str	q0, [sp, #10192]                ; 16-byte Spill
	str	q0, [sp, #5376]                 ; 16-byte Spill
	str	q0, [sp, #5360]                 ; 16-byte Spill
	str	q0, [sp, #5424]                 ; 16-byte Spill
	str	q0, [sp, #5408]                 ; 16-byte Spill
	str	q0, [sp, #5392]                 ; 16-byte Spill
	str	q0, [sp, #5344]                 ; 16-byte Spill
	str	q0, [sp, #3312]                 ; 16-byte Spill
	str	q0, [sp, #3296]                 ; 16-byte Spill
	str	q0, [sp, #3280]                 ; 16-byte Spill
	str	q0, [sp, #3264]                 ; 16-byte Spill
	str	q0, [sp, #3248]                 ; 16-byte Spill
	str	q0, [sp, #3232]                 ; 16-byte Spill
	str	q0, [sp, #10176]                ; 16-byte Spill
	str	q0, [sp, #10160]                ; 16-byte Spill
	str	q0, [sp, #10144]                ; 16-byte Spill
	str	q0, [sp, #10128]                ; 16-byte Spill
	str	q0, [sp, #3216]                 ; 16-byte Spill
	str	q0, [sp, #3200]                 ; 16-byte Spill
	str	q0, [sp, #6480]                 ; 16-byte Spill
	str	q0, [sp, #5280]                 ; 16-byte Spill
	str	q0, [sp, #5264]                 ; 16-byte Spill
	str	q0, [sp, #5328]                 ; 16-byte Spill
	str	q0, [sp, #5312]                 ; 16-byte Spill
	str	q0, [sp, #5296]                 ; 16-byte Spill
	str	q0, [sp, #6464]                 ; 16-byte Spill
	str	q0, [sp, #6448]                 ; 16-byte Spill
	str	q0, [sp, #6432]                 ; 16-byte Spill
	str	q0, [sp, #6416]                 ; 16-byte Spill
	str	q0, [sp, #6400]                 ; 16-byte Spill
	str	q0, [sp, #6384]                 ; 16-byte Spill
	str	q0, [sp, #5248]                 ; 16-byte Spill
	str	q0, [sp, #10112]                ; 16-byte Spill
	str	q0, [sp, #10096]                ; 16-byte Spill
	str	q0, [sp, #10080]                ; 16-byte Spill
	str	q0, [sp, #10064]                ; 16-byte Spill
	str	q0, [sp, #6368]                 ; 16-byte Spill
	str	q0, [sp, #8816]                 ; 16-byte Spill
	str	q0, [sp, #8800]                 ; 16-byte Spill
	str	q0, [sp, #8784]                 ; 16-byte Spill
	str	q0, [sp, #8768]                 ; 16-byte Spill
	str	q0, [sp, #8752]                 ; 16-byte Spill
	str	q0, [sp, #5232]                 ; 16-byte Spill
	str	q0, [sp, #6496]                 ; 16-byte Spill
	str	q0, [sp, #1344]                 ; 16-byte Spill
	str	q0, [sp, #1984]                 ; 16-byte Spill
	str	q0, [sp, #8736]                 ; 16-byte Spill
	str	q0, [sp, #8720]                 ; 16-byte Spill
	str	q0, [sp, #8704]                 ; 16-byte Spill
	str	q0, [sp, #7168]                 ; 16-byte Spill
	str	q0, [sp, #7152]                 ; 16-byte Spill
	str	q0, [sp, #10704]                ; 16-byte Spill
	str	q0, [sp, #10688]                ; 16-byte Spill
	str	q0, [sp, #7136]                 ; 16-byte Spill
	str	q0, [sp, #11040]                ; 16-byte Spill
	str	q0, [sp, #8688]                 ; 16-byte Spill
	str	q0, [sp, #8672]                 ; 16-byte Spill
	str	q0, [sp, #8656]                 ; 16-byte Spill
	str	q0, [sp, #7104]                 ; 16-byte Spill
	str	q0, [sp, #7056]                 ; 16-byte Spill
	str	q0, [sp, #7120]                 ; 16-byte Spill
	str	q0, [sp, #1328]                 ; 16-byte Spill
	str	q0, [sp, #8640]                 ; 16-byte Spill
	str	q0, [sp, #8624]                 ; 16-byte Spill
	str	q0, [sp, #8608]                 ; 16-byte Spill
	str	q0, [sp, #8592]                 ; 16-byte Spill
	str	q0, [sp, #8576]                 ; 16-byte Spill
	str	q0, [sp, #12848]                ; 16-byte Spill
	str	q0, [sp, #7088]                 ; 16-byte Spill
	str	q0, [sp, #7072]                 ; 16-byte Spill
	str	q0, [sp, #1312]                 ; 16-byte Spill
	str	q0, [sp, #1296]                 ; 16-byte Spill
	str	q0, [sp, #1280]                 ; 16-byte Spill
	str	q0, [sp, #12832]                ; 16-byte Spill
	str	q0, [sp, #12816]                ; 16-byte Spill
	str	q0, [sp, #12800]                ; 16-byte Spill
	str	q0, [sp, #12784]                ; 16-byte Spill
	str	q0, [sp, #12768]                ; 16-byte Spill
	str	q0, [sp, #12752]                ; 16-byte Spill
	str	q0, [sp, #7040]                 ; 16-byte Spill
	str	q0, [sp, #1264]                 ; 16-byte Spill
	str	q0, [sp, #1248]                 ; 16-byte Spill
	str	q0, [sp, #1232]                 ; 16-byte Spill
	str	q0, [sp, #1216]                 ; 16-byte Spill
	str	q0, [sp, #12736]                ; 16-byte Spill
	str	q0, [sp, #7024]                 ; 16-byte Spill
	str	q0, [sp, #7008]                 ; 16-byte Spill
	str	q0, [sp, #6992]                 ; 16-byte Spill
	str	q0, [sp, #6976]                 ; 16-byte Spill
	str	q0, [sp, #6960]                 ; 16-byte Spill
	str	q0, [sp, #6944]                 ; 16-byte Spill
	str	q0, [sp, #3184]                 ; 16-byte Spill
	str	q0, [sp, #6896]                 ; 16-byte Spill
	str	q0, [sp, #6880]                 ; 16-byte Spill
	str	q0, [sp, #10672]                ; 16-byte Spill
	str	q0, [sp, #6928]                 ; 16-byte Spill
	str	q0, [sp, #6912]                 ; 16-byte Spill
	str	q0, [sp, #3168]                 ; 16-byte Spill
	str	q0, [sp, #3152]                 ; 16-byte Spill
	str	q0, [sp, #3136]                 ; 16-byte Spill
	str	q0, [sp, #3120]                 ; 16-byte Spill
	str	q0, [sp, #3104]                 ; 16-byte Spill
	str	q0, [sp, #3088]                 ; 16-byte Spill
	str	q0, [sp, #5216]                 ; 16-byte Spill
	str	q0, [sp, #1200]                 ; 16-byte Spill
	str	q0, [sp, #10048]                ; 16-byte Spill
	str	q0, [sp, #10032]                ; 16-byte Spill
	str	q0, [sp, #10016]                ; 16-byte Spill
	str	q0, [sp, #3072]                 ; 16-byte Spill
	str	q0, [sp, #6096]                 ; 16-byte Spill
	str	q0, [sp, #6080]                 ; 16-byte Spill
	str	q0, [sp, #5168]                 ; 16-byte Spill
	str	q0, [sp, #5152]                 ; 16-byte Spill
	str	q0, [sp, #5200]                 ; 16-byte Spill
	str	q0, [sp, #5184]                 ; 16-byte Spill
	str	q0, [sp, #6064]                 ; 16-byte Spill
	str	q0, [sp, #6048]                 ; 16-byte Spill
	str	q0, [sp, #6032]                 ; 16-byte Spill
	str	q0, [sp, #6016]                 ; 16-byte Spill
	str	q0, [sp, #6000]                 ; 16-byte Spill
	str	q0, [sp, #5984]                 ; 16-byte Spill
	str	q0, [sp, #6864]                 ; 16-byte Spill
	str	q0, [sp, #6848]                 ; 16-byte Spill
	str	q0, [sp, #8560]                 ; 16-byte Spill
	str	q0, [sp, #9856]                 ; 16-byte Spill
	str	q0, [sp, #9840]                 ; 16-byte Spill
	str	q0, [sp, #8544]                 ; 16-byte Spill
	str	q0, [sp, #6832]                 ; 16-byte Spill
	str	q0, [sp, #11456]                ; 16-byte Spill
	str	q0, [sp, #6816]                 ; 16-byte Spill
	str	q0, [sp, #11440]                ; 16-byte Spill
	str	q0, [sp, #6800]                 ; 16-byte Spill
	str	q0, [sp, #6784]                 ; 16-byte Spill
	str	q0, [sp, #5968]                 ; 16-byte Spill
	str	q0, [sp, #12560]                ; 16-byte Spill
	str	q0, [sp, #12544]                ; 16-byte Spill
	str	q0, [sp, #12928]                ; 16-byte Spill
	str	q0, [sp, #12912]                ; 16-byte Spill
	str	q0, [sp, #12896]                ; 16-byte Spill
	str	q0, [sp, #5952]                 ; 16-byte Spill
	str	q0, [sp, #5936]                 ; 16-byte Spill
	str	q0, [sp, #5920]                 ; 16-byte Spill
	str	q0, [sp, #5904]                 ; 16-byte Spill
	str	q0, [sp, #5888]                 ; 16-byte Spill
	str	q0, [sp, #5872]                 ; 16-byte Spill
	str	q0, [sp, #5136]                 ; 16-byte Spill
	str	q0, [sp, #1184]                 ; 16-byte Spill
	str	q0, [sp, #1168]                 ; 16-byte Spill
	str	q0, [sp, #10000]                ; 16-byte Spill
	str	q0, [sp, #9984]                 ; 16-byte Spill
	str	q0, [sp, #5856]                 ; 16-byte Spill
	str	q0, [sp, #5120]                 ; 16-byte Spill
	str	q0, [sp, #5104]                 ; 16-byte Spill
	str	q0, [sp, #5088]                 ; 16-byte Spill
	str	q0, [sp, #5072]                 ; 16-byte Spill
	str	q0, [sp, #5056]                 ; 16-byte Spill
	str	q0, [sp, #5040]                 ; 16-byte Spill
	str	q0, [sp, #8528]                 ; 16-byte Spill
	str	q0, [sp, #8512]                 ; 16-byte Spill
	str	q0, [sp, #8496]                 ; 16-byte Spill
	str	q0, [sp, #8480]                 ; 16-byte Spill
	str	q0, [sp, #5024]                 ; 16-byte Spill
	str	q0, [sp, #5008]                 ; 16-byte Spill
	str	q0, [sp, #11600]                ; 16-byte Spill
	str	q0, [sp, #11584]                ; 16-byte Spill
	str	q0, [sp, #8464]                 ; 16-byte Spill
	str	q0, [sp, #8448]                 ; 16-byte Spill
	str	q0, [sp, #8432]                 ; 16-byte Spill
	str	q0, [sp, #8416]                 ; 16-byte Spill
	str	q0, [sp, #10656]                ; 16-byte Spill
	str	q0, [sp, #10640]                ; 16-byte Spill
	str	q0, [sp, #10624]                ; 16-byte Spill
	str	q0, [sp, #6768]                 ; 16-byte Spill
	str	q0, [sp, #1152]                 ; 16-byte Spill
	str	q0, [sp, #11568]                ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	str	q0, [sp, #8400]                 ; 16-byte Spill
	str	q0, [sp, #6752]                 ; 16-byte Spill
	str	q0, [sp, #6704]                 ; 16-byte Spill
	str	q0, [sp, #10608]                ; 16-byte Spill
	str	q0, [sp, #10592]                ; 16-byte Spill
	str	q0, [sp, #8384]                 ; 16-byte Spill
	str	q0, [sp, #8368]                 ; 16-byte Spill
	str	q0, [sp, #8352]                 ; 16-byte Spill
	str	q0, [sp, #8336]                 ; 16-byte Spill
	str	q0, [sp, #8320]                 ; 16-byte Spill
	str	q0, [sp, #8304]                 ; 16-byte Spill
	str	q0, [sp, #6736]                 ; 16-byte Spill
	str	q0, [sp, #6720]                 ; 16-byte Spill
	str	q0, [sp, #8288]                 ; 16-byte Spill
	str	q0, [sp, #8272]                 ; 16-byte Spill
	str	q0, [sp, #8256]                 ; 16-byte Spill
	str	q0, [sp, #8240]                 ; 16-byte Spill
	movi.2d	v3, #0000000000000000
	str	q0, [sp, #6640]                 ; 16-byte Spill
	str	q0, [sp, #6624]                 ; 16-byte Spill
	str	q0, [sp, #6688]                 ; 16-byte Spill
	str	q0, [sp, #6672]                 ; 16-byte Spill
	str	q0, [sp, #6656]                 ; 16-byte Spill
	str	q0, [sp, #12528]                ; 16-byte Spill
	str	q0, [sp, #1136]                 ; 16-byte Spill
	str	q0, [sp, #1120]                 ; 16-byte Spill
	movi.2d	v13, #0000000000000000
	str	q0, [sp, #1104]                 ; 16-byte Spill
	str	q0, [sp, #1088]                 ; 16-byte Spill
	str	q0, [sp, #12512]                ; 16-byte Spill
	str	q0, [sp, #12448]                ; 16-byte Spill
	str	q0, [sp, #12384]                ; 16-byte Spill
	str	q0, [sp, #12496]                ; 16-byte Spill
	str	q0, [sp, #12480]                ; 16-byte Spill
	str	q0, [sp, #12464]                ; 16-byte Spill
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v21, #0000000000000000
	str	q0, [sp, #12432]                ; 16-byte Spill
	str	q0, [sp, #12400]                ; 16-byte Spill
	str	q0, [sp, #12416]                ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	movi.2d	v8, #0000000000000000
	str	q0, [sp, #9968]                 ; 16-byte Spill
	str	q0, [sp, #10576]                ; 16-byte Spill
	str	q0, [sp, #4992]                 ; 16-byte Spill
	str	q0, [sp, #1072]                 ; 16-byte Spill
	str	q0, [sp, #11024]                ; 16-byte Spill
	str	q0, [sp, #11008]                ; 16-byte Spill
	str	q0, [sp, #10992]                ; 16-byte Spill
	str	q0, [sp, #10560]                ; 16-byte Spill
	str	q0, [sp, #4976]                 ; 16-byte Spill
	str	q0, [sp, #1056]                 ; 16-byte Spill
	str	q0, [sp, #9952]                 ; 16-byte Spill
	str	q0, [sp, #9936]                 ; 16-byte Spill
	str	q0, [sp, #9920]                 ; 16-byte Spill
	str	q0, [sp, #11424]                ; 16-byte Spill
	str	q0, [sp, #6608]                 ; 16-byte Spill
	str	q0, [sp, #1040]                 ; 16-byte Spill
	str	q0, [sp, #9904]                 ; 16-byte Spill
	str	q0, [sp, #9888]                 ; 16-byte Spill
	str	q0, [sp, #9872]                 ; 16-byte Spill
	str	q0, [sp, #10544]                ; 16-byte Spill
	str	q0, [sp, #4960]                 ; 16-byte Spill
	stp	q0, q0, [sp, #1008]             ; 32-byte Folded Spill
	str	q0, [sp, #10976]                ; 16-byte Spill
	str	q0, [sp, #10960]                ; 16-byte Spill
	str	q0, [sp, #10944]                ; 16-byte Spill
	str	q0, [sp, #4944]                 ; 16-byte Spill
	str	q0, [sp, #4928]                 ; 16-byte Spill
	str	q0, [sp, #11408]                ; 16-byte Spill
	str	q0, [sp, #6592]                 ; 16-byte Spill
Lloh34:
	adrp	x9, lCPI0_22@PAGE
Lloh35:
	ldr	q0, [x9, lCPI0_22@PAGEOFF]
	str	q0, [sp, #992]                  ; 16-byte Spill
Lloh36:
	ldr	q0, [x26, lCPI0_23@PAGEOFF]
	str	q0, [sp, #976]                  ; 16-byte Spill
	ldr	x26, [sp, #11632]               ; 8-byte Reload
Lloh37:
	adrp	x9, lCPI0_12@PAGE
Lloh38:
	ldr	q0, [x9, lCPI0_12@PAGEOFF]
	str	q0, [sp, #2080]                 ; 16-byte Spill
Lloh39:
	ldr	q0, [x6, lCPI0_13@PAGEOFF]
	str	q0, [sp, #2064]                 ; 16-byte Spill
Lloh40:
	ldr	q0, [x8, lCPI0_21@PAGEOFF]
	str	q0, [sp, #960]                  ; 16-byte Spill
Lloh41:
	ldr	q0, [x12, lCPI0_14@PAGEOFF]
	str	q0, [sp, #2048]                 ; 16-byte Spill
Lloh42:
	ldr	q0, [x15, lCPI0_15@PAGEOFF]
	str	q0, [sp, #2032]                 ; 16-byte Spill
Lloh43:
	ldr	q0, [x28, lCPI0_18@PAGEOFF]
	str	q0, [sp, #128]                  ; 16-byte Spill
Lloh44:
	ldr	q0, [x30, lCPI0_19@PAGEOFF]
	str	q0, [sp, #112]                  ; 16-byte Spill
Lloh45:
	ldr	q0, [x14, lCPI0_20@PAGEOFF]
	str	q0, [sp, #944]                  ; 16-byte Spill
Lloh46:
	ldr	q0, [x10, lCPI0_16@PAGEOFF]
	str	q0, [sp, #96]                   ; 16-byte Spill
Lloh47:
	ldr	q0, [x11, lCPI0_17@PAGEOFF]
	str	q0, [sp, #80]                   ; 16-byte Spill
	ldr	q1, [sp, #12336]                ; 16-byte Reload
	ldr	q0, [sp, #2960]                 ; 16-byte Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #2944]                 ; 16-byte Spill
	ldr	q4, [sp, #12304]                ; 16-byte Reload
	ldr	q0, [sp, #2992]                 ; 16-byte Reload
	add.2d	v0, v0, v4
	str	q0, [sp, #2928]                 ; 16-byte Spill
	ldr	q0, [sp, #12352]                ; 16-byte Reload
	ldr	q2, [sp, #2976]                 ; 16-byte Reload
	add.2d	v2, v2, v0
	str	q2, [sp, #2912]                 ; 16-byte Spill
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	add.2d	v5, v31, v2
	str	q5, [sp, #2896]                 ; 16-byte Spill
	add.2d	v1, v30, v1
	str	q1, [sp, #2144]                 ; 16-byte Spill
	add.2d	v1, v28, v4
	str	q1, [sp, #2128]                 ; 16-byte Spill
	add.2d	v0, v29, v0
	str	q0, [sp, #2112]                 ; 16-byte Spill
	add.2d	v0, v25, v2
	str	q0, [sp, #2096]                 ; 16-byte Spill
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	str	q0, [sp, #12112]                ; 16-byte Spill
	str	q0, [sp, #4864]                 ; 16-byte Spill
	str	q0, [sp, #4848]                 ; 16-byte Spill
	str	q0, [sp, #4832]                 ; 16-byte Spill
	str	q0, [sp, #4816]                 ; 16-byte Spill
	str	q0, [sp, #4800]                 ; 16-byte Spill
	str	q0, [sp, #4784]                 ; 16-byte Spill
	str	q0, [sp, #4912]                 ; 16-byte Spill
	str	q0, [sp, #4896]                 ; 16-byte Spill
	str	q0, [sp, #4880]                 ; 16-byte Spill
	str	q0, [sp, #8224]                 ; 16-byte Spill
	str	q0, [sp, #8208]                 ; 16-byte Spill
	str	q0, [sp, #8192]                 ; 16-byte Spill
	str	q0, [sp, #8176]                 ; 16-byte Spill
	str	q0, [sp, #8160]                 ; 16-byte Spill
	str	q0, [sp, #8144]                 ; 16-byte Spill
	str	q0, [sp, #8128]                 ; 16-byte Spill
	str	q0, [sp, #8112]                 ; 16-byte Spill
	str	q0, [sp, #6576]                 ; 16-byte Spill
	str	q0, [sp, #6560]                 ; 16-byte Spill
	movi.2d	v11, #0000000000000000
	str	q0, [sp, #4656]                 ; 16-byte Spill
	str	q0, [sp, #4640]                 ; 16-byte Spill
	str	q0, [sp, #4624]                 ; 16-byte Spill
	str	q0, [sp, #12096]                ; 16-byte Spill
	str	q0, [sp, #12080]                ; 16-byte Spill
	str	q0, [sp, #12064]                ; 16-byte Spill
	str	q0, [sp, #12048]                ; 16-byte Spill
	str	q0, [sp, #12032]                ; 16-byte Spill
	str	q0, [sp, #12016]                ; 16-byte Spill
	str	q0, [sp, #12000]                ; 16-byte Spill
	str	q0, [sp, #11984]                ; 16-byte Spill
	str	q0, [sp, #6544]                 ; 16-byte Spill
	str	q0, [sp, #6528]                 ; 16-byte Spill
	stp	q0, q0, [sp, #912]              ; 32-byte Folded Spill
	movi.2d	v10, #0000000000000000
	movi.2d	v17, #0000000000000000
	str	q0, [sp, #11968]                ; 16-byte Spill
	str	q0, [sp, #11952]                ; 16-byte Spill
	str	q0, [sp, #11936]                ; 16-byte Spill
	str	q0, [sp, #11920]                ; 16-byte Spill
	str	q0, [sp, #11904]                ; 16-byte Spill
	str	q0, [sp, #11888]                ; 16-byte Spill
	str	q0, [sp, #11872]                ; 16-byte Spill
	str	q0, [sp, #11856]                ; 16-byte Spill
	str	q0, [sp, #11552]                ; 16-byte Spill
	str	q0, [sp, #11536]                ; 16-byte Spill
	str	q0, [sp, #11520]                ; 16-byte Spill
	str	q0, [sp, #11504]                ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v2, #0000000000000000
	str	q24, [sp, #11744]               ; 16-byte Spill
	str	q26, [sp, #12880]               ; 16-byte Spill
	str	q9, [sp, #13088]                ; 16-byte Spill
	b	LBB0_91
LBB0_90:                                ; %direct.false900
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v6, v2, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldp	q4, q23, [sp, #688]             ; 32-byte Folded Reload
	add.2d	v23, v23, v0
	ldr	q0, [sp, #13248]                ; 16-byte Reload
	add.2d	v4, v4, v0
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	ldr	q2, [sp, #720]                  ; 16-byte Reload
	add.2d	v0, v2, v0
	mov.16b	v2, v4
	fmov	x8, d0
	cmp	x8, #2
	ldr	q11, [sp, #752]                 ; 16-byte Reload
	b.ge	LBB0_1467
LBB0_91:                                ; %direct.true362
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_96 Depth 2
                                        ;     Child Loop BB0_129 Depth 2
                                        ;     Child Loop BB0_165 Depth 2
                                        ;       Child Loop BB0_168 Depth 3
                                        ;     Child Loop BB0_223 Depth 2
                                        ;     Child Loop BB0_256 Depth 2
                                        ;     Child Loop BB0_276 Depth 2
                                        ;     Child Loop BB0_312 Depth 2
                                        ;     Child Loop BB0_359 Depth 2
                                        ;     Child Loop BB0_376 Depth 2
                                        ;     Child Loop BB0_1131 Depth 2
                                        ;     Child Loop BB0_1149 Depth 2
                                        ;     Child Loop BB0_1183 Depth 2
                                        ;     Child Loop BB0_1217 Depth 2
                                        ;     Child Loop BB0_409 Depth 2
                                        ;     Child Loop BB0_458 Depth 2
                                        ;     Child Loop BB0_507 Depth 2
                                        ;     Child Loop BB0_560 Depth 2
                                        ;       Child Loop BB0_563 Depth 3
                                        ;     Child Loop BB0_597 Depth 2
                                        ;     Child Loop BB0_1251 Depth 2
                                        ;     Child Loop BB0_1301 Depth 2
                                        ;     Child Loop BB0_651 Depth 2
                                        ;     Child Loop BB0_703 Depth 2
                                        ;     Child Loop BB0_739 Depth 2
                                        ;     Child Loop BB0_1335 Depth 2
                                        ;     Child Loop BB0_793 Depth 2
                                        ;       Child Loop BB0_796 Depth 3
                                        ;     Child Loop BB0_1385 Depth 2
                                        ;     Child Loop BB0_836 Depth 2
                                        ;     Child Loop BB0_885 Depth 2
                                        ;       Child Loop BB0_904 Depth 3
                                        ;     Child Loop BB0_957 Depth 2
                                        ;     Child Loop BB0_990 Depth 2
                                        ;     Child Loop BB0_1028 Depth 2
                                        ;     Child Loop BB0_1435 Depth 2
                                        ;     Child Loop BB0_1061 Depth 2
                                        ;     Child Loop BB0_1097 Depth 2
	stp	q1, q8, [sp, #768]              ; 32-byte Folded Spill
	str	q15, [sp, #1968]                ; 16-byte Spill
	stp	q22, q21, [sp, #800]            ; 32-byte Folded Spill
	stp	q19, q18, [sp, #832]            ; 32-byte Folded Spill
	mov.16b	v5, v0
	sshll.2d	v0, v26, #0
	sshll.2d	v1, v24, #0
	fmov	x8, d2
	add	x8, x8, x8, lsl #5
	mov.16b	v4, v2
	fmov	d2, x8
	stp	q4, q23, [sp, #688]             ; 32-byte Folded Spill
	mov.d	x8, v4[1]
	add	x8, x8, x8, lsl #5
	mov.d	v2[1], x8
	fmov	x8, d23
	fmov	x9, d6
	add	x9, x9, x9, lsl #5
	fmov	x14, d5
	add	x14, x14, x14, lsl #5
	fmov	d4, x14
	str	q5, [sp, #720]                  ; 16-byte Spill
	mov.d	x14, v5[1]
	add	x14, x14, x14, lsl #5
	mov.d	v4[1], x14
	ldr	q5, [sp, #11552]                ; 16-byte Reload
	bit.16b	v5, v4, v1
	fmov	d4, x9
	str	q6, [sp, #4592]                 ; 16-byte Spill
	mov.d	x9, v6[1]
	add	x9, x9, x9, lsl #5
	mov.d	v4[1], x9
	add	x8, x8, x8, lsl #5
	ldr	q7, [sp, #11536]                ; 16-byte Reload
	bit.16b	v7, v4, v12
	fmov	d4, x8
	mov.d	x8, v23[1]
	add	x8, x8, x8, lsl #5
	mov.d	v4[1], x8
	ldr	q18, [sp, #11520]               ; 16-byte Reload
	bit.16b	v18, v4, v0
	ldr	q21, [sp, #11504]               ; 16-byte Reload
	bit.16b	v21, v2, v14
	ldr	q2, [sp, #672]                  ; 16-byte Reload
	ldr	q4, [sp, #11920]                ; 16-byte Reload
	bit.16b	v4, v2, v14
	str	q4, [sp, #11920]                ; 16-byte Spill
	ldr	q4, [sp, #11952]                ; 16-byte Reload
	bit.16b	v4, v2, v12
	str	q4, [sp, #11952]                ; 16-byte Spill
	ldr	q4, [sp, #11936]                ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #11936]                ; 16-byte Spill
	ldr	q4, [sp, #11968]                ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #11968]                ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q4, [sp, #11856]                ; 16-byte Reload
	bit.16b	v4, v2, v14
	str	q4, [sp, #11856]                ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q4, [sp, #11888]                ; 16-byte Reload
	bit.16b	v4, v2, v12
	str	q4, [sp, #11888]                ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q4, [sp, #11872]                ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #11872]                ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q4, [sp, #11904]                ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #11904]                ; 16-byte Spill
	bic.16b	v17, v17, v14
	ldp	q19, q6, [sp, #912]             ; 32-byte Folded Reload
	bic.16b	v19, v19, v12
	bic.16b	v10, v10, v0
	bic.16b	v6, v6, v1
	fmov	x9, d6
	ldp	q0, q1, [sp, #192]              ; 32-byte Folded Reload
	str	q5, [sp, #11552]                ; 16-byte Spill
	add.2d	v27, v5, v1
	str	q7, [sp, #11536]                ; 16-byte Spill
	add.2d	v0, v7, v0
	str	q0, [sp, #11376]                ; 16-byte Spill
	ldr	q0, [sp, #176]                  ; 16-byte Reload
	str	q18, [sp, #11520]               ; 16-byte Spill
	add.2d	v0, v18, v0
	str	q0, [sp, #11360]                ; 16-byte Spill
	ldr	q0, [sp, #13168]                ; 16-byte Reload
	mov.d	x28, v0[1]
	ldr	q0, [sp, #13200]                ; 16-byte Reload
	mov.d	x30, v0[1]
	ldr	q0, [sp, #160]                  ; 16-byte Reload
	str	q21, [sp, #11504]               ; 16-byte Spill
	add.2d	v0, v21, v0
	str	q0, [sp, #11344]                ; 16-byte Spill
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	mov.d	x8, v0[1]
	ldr	q0, [sp, #13216]                ; 16-byte Reload
	mov.d	x14, v0[1]
	cmp	x9, #34
	b.le	LBB0_96
; %bb.92:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	ldr	q22, [sp, #4768]                ; 16-byte Reload
	ldr	q25, [sp, #5840]                ; 16-byte Reload
	ldr	q29, [sp, #5824]                ; 16-byte Reload
	ldr	q23, [sp, #4656]                ; 16-byte Reload
	ldr	q28, [sp, #4640]                ; 16-byte Reload
	ldr	q31, [sp, #4624]                ; 16-byte Reload
LBB0_93:                                ; %direct.false367
                                        ;   in Loop: Header=BB0_91 Depth=1
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #656]                  ; 16-byte Reload
	ldr	q4, [sp, #12048]                ; 16-byte Reload
	bit.16b	v4, v2, v14
	str	q4, [sp, #12048]                ; 16-byte Spill
	ldr	q4, [sp, #12080]                ; 16-byte Reload
	bit.16b	v4, v2, v12
	str	q4, [sp, #12080]                ; 16-byte Spill
	ldr	q4, [sp, #12064]                ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #12064]                ; 16-byte Spill
	ldr	q4, [sp, #12096]                ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #12096]                ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q4, [sp, #11984]                ; 16-byte Reload
	bit.16b	v4, v2, v14
	str	q4, [sp, #11984]                ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q4, [sp, #12016]                ; 16-byte Reload
	bit.16b	v4, v2, v12
	str	q4, [sp, #12016]                ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q4, [sp, #12000]                ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #12000]                ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q4, [sp, #12032]                ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #12032]                ; 16-byte Spill
	bic.16b	v31, v31, v14
	bic.16b	v23, v23, v12
	bic.16b	v28, v28, v1
	bic.16b	v11, v11, v0
	fmov	x9, d11
	cmp	x9, #32
	stp	q19, q6, [sp, #912]             ; 32-byte Folded Spill
	b.gt	LBB0_161
; %bb.94:                               ; %direct.true379.lr.ph
                                        ;   in Loop: Header=BB0_91 Depth=1
	mov.16b	v15, v27
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	b	LBB0_129
LBB0_95:                                ; %else590
                                        ;   in Loop: Header=BB0_96 Depth=2
	str	q1, [sp, #6528]                 ; 16-byte Spill
	str	q5, [sp, #6544]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v19, v19, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v10, v10, v0
	ldr	q0, [sp, #13248]                ; 16-byte Reload
	add.2d	v17, v17, v0
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v6, v6, v0
	fmov	x9, d6
	cmp	x9, #35
	b.ge	LBB0_93
LBB0_96:                                ; %direct.true366
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v5, v24, #0
	sshll.2d	v4, v26, #0
	str	q17, [sp, #8096]                ; 16-byte Spill
	and.16b	v2, v14, v17
	mov.16b	v17, v10
	and.16b	v1, v4, v10
	mov.16b	v15, v6
	and.16b	v0, v5, v6
	fmov	x9, d0
	ldr	q7, [sp, #4432]                 ; 16-byte Reload
	fmov	x15, d7
	sdiv	x9, x9, x15
	mov.d	x6, v0[1]
	mul	x24, x9, x15
	fmov	d6, x9
	mov.d	x10, v7[1]
	sdiv	x11, x6, x10
	mov.d	v6[1], x11
	mov.16b	v10, v19
	and.16b	v30, v12, v19
	fmov	x15, d30
	ldr	q18, [sp, #4464]                ; 16-byte Reload
	fmov	x9, d18
	sdiv	x25, x15, x9
	mov.d	x15, v30[1]
	fmov	d7, x25
	mov.d	x26, v18[1]
	sdiv	x27, x15, x26
	mov.d	v7[1], x27
	fmov	x15, d1
	ldr	q19, [sp, #4448]                ; 16-byte Reload
	fmov	x20, d19
	sdiv	x21, x15, x20
	fmov	d18, x21
	mov.d	x15, v1[1]
	mov.d	x22, v19[1]
	sdiv	x23, x15, x22
	mov.d	v18[1], x23
	fmov	x6, d2
	ldr	q19, [sp, #4480]                ; 16-byte Reload
	fmov	x15, d19
	sdiv	x6, x6, x15
	mov.d	x19, v2[1]
	mov.d	x7, v19[1]
	fmov	d21, x6
	sdiv	x19, x19, x7
	mov.d	v21[1], x19
	mul	x10, x11, x10
	fmov	d23, x24
	mov.d	v23[1], x10
	sub.2d	v0, v0, v23
	and.16b	v5, v5, v6
	mov.d	x10, v5[1]
	and.16b	v6, v12, v7
	sdiv	x11, x10, x28
	msub	x10, x11, x28, x10
	fmov	x11, d5
	ldr	q5, [sp, #13168]                ; 16-byte Reload
	fmov	x24, d5
	sdiv	x12, x11, x24
	msub	x11, x12, x24, x11
	fmov	d5, x11
	mov.d	v5[1], x10
	mov.d	x10, v6[1]
	and.16b	v4, v4, v18
	sdiv	x11, x10, x30
	msub	x10, x11, x30, x10
	fmov	x11, d6
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x24, x11, x12
	msub	x11, x24, x12, x11
	fmov	d6, x11
	mov.d	v6[1], x10
	mov.d	x10, v4[1]
	and.16b	v7, v14, v21
	sdiv	x11, x10, x8
	msub	x10, x11, x8, x10
	fmov	x11, d4
	ldr	q4, [sp, #13184]                ; 16-byte Reload
	fmov	x12, d4
	sdiv	x24, x11, x12
	msub	x11, x24, x12, x11
	fmov	d4, x11
	mov.d	v4[1], x10
	mov.d	x10, v7[1]
	sdiv	x11, x10, x14
	msub	x10, x11, x14, x10
	fmov	x11, d7
	ldr	q7, [sp, #13216]                ; 16-byte Reload
	fmov	x12, d7
	sdiv	x24, x11, x12
	msub	x11, x24, x12, x11
	fmov	d7, x11
	mov.d	v7[1], x10
	shl.2d	v7, v7, #3
	shl.2d	v18, v4, #3
	shl.2d	v6, v6, #3
	shl.2d	v4, v5, #3
	ldr	q5, [sp, #13104]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #13072]                ; 16-byte Reload
	orr.16b	v6, v6, v5
	ldr	q5, [sp, #13056]                ; 16-byte Reload
	orr.16b	v5, v18, v5
	mov	w10, #33                        ; =0x21
	dup.2d	v18, x10
	ldr	q19, [sp, #13040]               ; 16-byte Reload
	orr.16b	v7, v7, v19
	cmgt.2d	v21, v18, v7
	cmgt.2d	v23, v18, v5
	uzp1.4s	v25, v23, v21
	cmgt.2d	v28, v18, v6
	cmgt.2d	v18, v18, v4
	uzp1.4s	v29, v18, v28
	uzp1.8h	v31, v29, v25
	mov	w10, #32                        ; =0x20
	dup.2d	v8, x10
	mov.16b	v29, v21
	bsl.16b	v29, v7, v8
	bsl.16b	v23, v5, v8
	mov.16b	v25, v28
	bsl.16b	v25, v6, v8
	bsl.16b	v18, v4, v8
	ldr	q19, [sp, #11552]               ; 16-byte Reload
	add.2d	v21, v18, v19
	ldr	q19, [sp, #11520]               ; 16-byte Reload
	add.2d	v28, v23, v19
	mov	w10, #35                        ; =0x23
	dup.2d	v8, x10
	ldr	q19, [sp, #11504]               ; 16-byte Reload
	add.2d	v9, v29, v19
	cmhi.2d	v9, v8, v9
	cmhi.2d	v28, v8, v28
	uzp1.4s	v28, v28, v9
	ldr	q19, [sp, #11536]               ; 16-byte Reload
	add.2d	v9, v25, v19
	cmhi.2d	v9, v8, v9
	cmhi.2d	v21, v8, v21
	add.2d	v18, v18, v27
	uzp1.4s	v21, v21, v9
	uzp1.8h	v21, v21, v28
	mov.d	x10, v18[1]
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	x11, d18
	lsl	x12, x11, #3
	sub	x11, x12, x11
	fmov	d18, x11
	mov.d	v18[1], x10
	add.2d	v18, v18, v0
	and.16b	v0, v31, v21
	xtn.8b	v21, v0
	ldr	q19, [sp, #13136]               ; 16-byte Reload
	and.8b	v0, v19, v21
	shl.8b	v28, v0, #7
	cmlt.8b	v28, v28, #0
	ldr	d31, [sp, #13320]               ; 8-byte Reload
	and.8b	v28, v28, v31
	addv.8b	b28, v28
	fmov	w24, s28
	shl.2d	v18, v18, #2
	mov	b28, v0[0]
	mov.b	v28[4], v0[1]
	ushll.2d	v28, v28, #0
	shl.2d	v28, v28, #63
	cmlt.2d	v28, v28, #0
	and.16b	v18, v28, v18
	ldr	x10, [sp, #4512]                ; 8-byte Reload
	dup.2d	v8, x10
	add.2d	v31, v8, v18
	movi.2d	v28, #0000000000000000
	movi.2d	v18, #0000000000000000
	tbz	w24, #0, LBB0_98
; %bb.97:                               ; %cond.load510
                                        ;   in Loop: Header=BB0_96 Depth=2
	fmov	x10, d31
	ldr	s28, [x10]
LBB0_98:                                ; %else514
                                        ;   in Loop: Header=BB0_96 Depth=2
	tbz	w24, #1, LBB0_100
; %bb.99:                               ; %cond.load516
                                        ;   in Loop: Header=BB0_96 Depth=2
	mov.d	x10, v31[1]
	ld1.s	{ v28 }[1], [x10]
LBB0_100:                               ; %else520
                                        ;   in Loop: Header=BB0_96 Depth=2
	ldr	q9, [sp, #6544]                 ; 16-byte Reload
	mul	x10, x27, x26
	mul	x9, x25, x9
	fmov	d31, x9
	mov.d	v31[1], x10
	sub.2d	v30, v30, v31
	ldr	q22, [sp, #11376]               ; 16-byte Reload
	add.2d	v25, v25, v22
	mov.d	x9, v25[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d25
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d25, x10
	mov.d	v25[1], x9
	add.2d	v25, v25, v30
	mov	b30, v0[2]
	mov.b	v30[4], v0[3]
	shl.2d	v25, v25, #2
	ushll.2d	v30, v30, #0
	shl.2d	v30, v30, #63
	cmlt.2d	v30, v30, #0
	and.16b	v25, v30, v25
	add.2d	v25, v8, v25
	tbz	w24, #2, LBB0_102
; %bb.101:                              ; %cond.load522
                                        ;   in Loop: Header=BB0_96 Depth=2
	fmov	x9, d25
	ld1.s	{ v28 }[2], [x9]
LBB0_102:                               ; %else526
                                        ;   in Loop: Header=BB0_96 Depth=2
	ldr	x27, [sp, #11400]               ; 8-byte Reload
	ldr	x26, [sp, #11632]               ; 8-byte Reload
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	ldr	q30, [sp, #13328]               ; 16-byte Reload
	ldr	q31, [sp, #4624]                ; 16-byte Reload
	tbz	w24, #3, LBB0_104
; %bb.103:                              ; %cond.load528
                                        ;   in Loop: Header=BB0_96 Depth=2
	mov.d	x9, v25[1]
	ld1.s	{ v28 }[3], [x9]
LBB0_104:                               ; %else532
                                        ;   in Loop: Header=BB0_96 Depth=2
	mul	x9, x23, x22
	mul	x10, x21, x20
	fmov	d25, x10
	mov.d	v25[1], x9
	sub.2d	v1, v1, v25
	ldr	q22, [sp, #11360]               ; 16-byte Reload
	add.2d	v23, v23, v22
	mov.d	x9, v23[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d23
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	add.2d	v1, v23, v1
	mov	b23, v0[4]
	mov.b	v23[4], v0[5]
	shl.2d	v1, v1, #2
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmlt.2d	v23, v23, #0
	and.16b	v1, v23, v1
	add.2d	v1, v8, v1
	tbz	w24, #4, LBB0_106
; %bb.105:                              ; %cond.load534
                                        ;   in Loop: Header=BB0_96 Depth=2
	fmov	x9, d1
	ld1.s	{ v18 }[0], [x9]
LBB0_106:                               ; %else538
                                        ;   in Loop: Header=BB0_96 Depth=2
	ldr	q25, [sp, #5840]                ; 16-byte Reload
	tbz	w24, #5, LBB0_108
; %bb.107:                              ; %cond.load540
                                        ;   in Loop: Header=BB0_96 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[1], [x9]
LBB0_108:                               ; %else544
                                        ;   in Loop: Header=BB0_96 Depth=2
	mul	x9, x19, x7
	mul	x10, x6, x15
	fmov	d1, x10
	mov.d	v1[1], x9
	sub.2d	v1, v2, v1
	ldr	q2, [sp, #11344]                ; 16-byte Reload
	add.2d	v2, v29, v2
	mov.d	x9, v2[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d2
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	add.2d	v1, v2, v1
	mov	b2, v0[6]
	mov.b	v2[4], v0[7]
	shl.2d	v1, v1, #2
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	and.16b	v1, v2, v1
	add.2d	v1, v8, v1
	tbz	w24, #6, LBB0_110
; %bb.109:                              ; %cond.load546
                                        ;   in Loop: Header=BB0_96 Depth=2
	fmov	x9, d1
	ld1.s	{ v18 }[2], [x9]
LBB0_110:                               ; %else550
                                        ;   in Loop: Header=BB0_96 Depth=2
	ldr	q22, [sp, #4768]                ; 16-byte Reload
	ldr	q29, [sp, #5824]                ; 16-byte Reload
	tbz	w24, #7, LBB0_112
; %bb.111:                              ; %cond.load552
                                        ;   in Loop: Header=BB0_96 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_112:                               ; %else556
                                        ;   in Loop: Header=BB0_96 Depth=2
	bic.8b	v1, v19, v21
	mov	w9, #33                         ; =0x21
	dup.2d	v2, x9
	cmgt.2d	v6, v2, v6
	cmgt.2d	v4, v2, v4
	uzp1.4s	v4, v4, v6
	cmgt.2d	v5, v2, v5
	cmgt.2d	v2, v2, v7
	uzp1.4s	v2, v5, v2
	uzp1.8h	v2, v4, v2
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bsl.16b	v4, v28, v9
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v5, v5, v4
	and.16b	v2, v30, v2
	xtn.8b	v2, v2
	shl.8b	v2, v2, #7
	cmlt.8b	v2, v2, #0
	ldr	d4, [sp, #13320]                ; 8-byte Reload
	and.8b	v2, v2, v4
	addv.8b	b2, v2
	fmov	w9, s2
	mov.16b	v6, v15
	shl.2d	v2, v15, #5
	ldr	q4, [sp, #11904]                ; 16-byte Reload
	orr.16b	v2, v2, v4
	ldr	q4, [sp, #11968]                ; 16-byte Reload
	add.2d	v2, v4, v2
	tbz	w9, #0, LBB0_114
; %bb.113:                              ; %cond.store559
                                        ;   in Loop: Header=BB0_96 Depth=2
	fmov	x10, d2
	str	s5, [x10]
LBB0_114:                               ; %else562
                                        ;   in Loop: Header=BB0_96 Depth=2
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	ldr	q23, [sp, #4656]                ; 16-byte Reload
	ldr	q28, [sp, #4640]                ; 16-byte Reload
	mov.16b	v19, v10
	tbz	w9, #1, LBB0_116
; %bb.115:                              ; %cond.store563
                                        ;   in Loop: Header=BB0_96 Depth=2
	mov.d	x10, v2[1]
	st1.s	{ v5 }[1], [x10]
LBB0_116:                               ; %else566
                                        ;   in Loop: Header=BB0_96 Depth=2
	shl.2d	v2, v19, #5
	ldr	q4, [sp, #11888]                ; 16-byte Reload
	orr.16b	v2, v2, v4
	ldr	q4, [sp, #11952]                ; 16-byte Reload
	add.2d	v2, v4, v2
	mov.16b	v10, v17
	tbz	w9, #2, LBB0_118
; %bb.117:                              ; %cond.store567
                                        ;   in Loop: Header=BB0_96 Depth=2
	fmov	x10, d2
	st1.s	{ v5 }[2], [x10]
LBB0_118:                               ; %else570
                                        ;   in Loop: Header=BB0_96 Depth=2
	ldr	q17, [sp, #8096]                ; 16-byte Reload
	tbz	w9, #3, LBB0_120
; %bb.119:                              ; %cond.store571
                                        ;   in Loop: Header=BB0_96 Depth=2
	mov.d	x10, v2[1]
	st1.s	{ v5 }[3], [x10]
LBB0_120:                               ; %else574
                                        ;   in Loop: Header=BB0_96 Depth=2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q2, [sp, #6528]                 ; 16-byte Reload
	bsl.16b	v0, v18, v2
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v1, v1, v0
	shl.2d	v0, v10, #5
	ldr	q2, [sp, #11872]                ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #11936]                ; 16-byte Reload
	add.2d	v0, v2, v0
	tbnz	w9, #4, LBB0_124
; %bb.121:                              ; %else578
                                        ;   in Loop: Header=BB0_96 Depth=2
	tbnz	w9, #5, LBB0_125
LBB0_122:                               ; %else582
                                        ;   in Loop: Header=BB0_96 Depth=2
	shl.2d	v0, v17, #5
	ldr	q2, [sp, #11856]                ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #11920]                ; 16-byte Reload
	add.2d	v0, v2, v0
	tbnz	w9, #6, LBB0_126
LBB0_123:                               ; %else586
                                        ;   in Loop: Header=BB0_96 Depth=2
	tbz	w9, #7, LBB0_95
	b	LBB0_127
LBB0_124:                               ; %cond.store575
                                        ;   in Loop: Header=BB0_96 Depth=2
	fmov	x10, d0
	str	s1, [x10]
	tbz	w9, #5, LBB0_122
LBB0_125:                               ; %cond.store579
                                        ;   in Loop: Header=BB0_96 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v1 }[1], [x10]
	shl.2d	v0, v17, #5
	ldr	q2, [sp, #11856]                ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #11920]                ; 16-byte Reload
	add.2d	v0, v2, v0
	tbz	w9, #6, LBB0_123
LBB0_126:                               ; %cond.store583
                                        ;   in Loop: Header=BB0_96 Depth=2
	fmov	x10, d0
	st1.s	{ v1 }[2], [x10]
	tbz	w9, #7, LBB0_95
LBB0_127:                               ; %cond.store587
                                        ;   in Loop: Header=BB0_96 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[3], [x9]
	b	LBB0_95
LBB0_128:                               ; %else672
                                        ;   in Loop: Header=BB0_129 Depth=2
	str	q1, [sp, #6560]                 ; 16-byte Spill
	str	q6, [sp, #6576]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v23, v23, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v28, v28, v0
	ldr	q0, [sp, #13248]                ; 16-byte Reload
	add.2d	v31, v31, v0
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v11, v11, v0
	fmov	x9, d11
	cmp	x9, #33
	b.ge	LBB0_162
LBB0_129:                               ; %direct.true379
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v26, #0
	sshll.2d	v1, v24, #0
	and.16b	v2, v1, v11
	and.16b	v4, v12, v23
	and.16b	v0, v0, v28
	and.16b	v1, v14, v31
	mov.d	x9, v1[1]
	fmov	x10, d1
	ldr	q5, [sp, #4352]                 ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d1, x10
	mov.d	x10, v5[1]
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	mov.d	v1[1], x9
	mov.d	x9, v0[1]
	fmov	x10, d0
	ldr	q0, [sp, #4320]                 ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	x10, v0[1]
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	mov.d	v6[1], x9
	mov.d	x9, v4[1]
	fmov	x10, d4
	ldr	q0, [sp, #4336]                 ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	mov.d	x11, v0[1]
	sdiv	x12, x9, x11
	msub	x9, x12, x11, x9
	mov.d	x11, v2[1]
	fmov	x12, d2
	ldr	q0, [sp, #4304]                 ; 16-byte Reload
	fmov	x15, d0
	sdiv	x6, x12, x15
	msub	x12, x6, x15, x12
	fmov	d18, x10
	mov.d	v18[1], x9
	mov.d	x9, v0[1]
	fmov	d0, x12
	sdiv	x10, x11, x9
	msub	x9, x10, x9, x11
	mov.d	v0[1], x9
	ldr	q2, [sp, #11552]                ; 16-byte Reload
	add.2d	v2, v0, v2
	ldr	q4, [sp, #11536]                ; 16-byte Reload
	add.2d	v4, v18, v4
	ldr	q5, [sp, #11520]                ; 16-byte Reload
	add.2d	v5, v6, v5
	ldr	q7, [sp, #11504]                ; 16-byte Reload
	add.2d	v7, v1, v7
	add.2d	v0, v0, v15
	mov	w9, #35                         ; =0x23
	dup.2d	v21, x9
	cmhi.2d	v7, v21, v7
	cmhi.2d	v5, v21, v5
	uzp1.4s	v5, v5, v7
	cmhi.2d	v4, v21, v4
	cmhi.2d	v2, v21, v2
	uzp1.4s	v2, v2, v4
	uzp1.8h	v2, v2, v5
	xtn.8b	v4, v2
	mov.d	x9, v0[1]
	fmov	x10, d0
	add	x10, x10, x10, lsl #1
	fmov	d0, x10
	add	x9, x9, x9, lsl #1
	mov.d	v0[1], x9
	ldr	q2, [sp, #13104]                ; 16-byte Reload
	add.2d	v2, v0, v2
	ldr	d0, [sp, #4520]                 ; 8-byte Reload
	and.8b	v0, v4, v0
	shl.8b	v5, v0, #7
	cmlt.8b	v5, v5, #0
	ldr	d7, [sp, #13320]                ; 8-byte Reload
	and.8b	v5, v5, v7
	addv.8b	b5, v5
	fmov	w15, s5
	shl.2d	v2, v2, #2
	mov	b5, v0[0]
	mov.b	v5[4], v0[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	and.16b	v2, v5, v2
	ldr	x9, [sp, #4504]                 ; 8-byte Reload
	dup.2d	v7, x9
	add.2d	v21, v7, v2
	movi.2d	v5, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w15, #0, LBB0_131
; %bb.130:                              ; %cond.load592
                                        ;   in Loop: Header=BB0_129 Depth=2
	fmov	x9, d21
	ldr	s5, [x9]
LBB0_131:                               ; %else596
                                        ;   in Loop: Header=BB0_129 Depth=2
	tbz	w15, #1, LBB0_133
; %bb.132:                              ; %cond.load598
                                        ;   in Loop: Header=BB0_129 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v5 }[1], [x9]
LBB0_133:                               ; %else602
                                        ;   in Loop: Header=BB0_129 Depth=2
	ldr	q19, [sp, #11376]               ; 16-byte Reload
	add.2d	v18, v18, v19
	mov.d	x9, v18[1]
	fmov	x10, d18
	add	x10, x10, x10, lsl #1
	fmov	d18, x10
	add	x9, x9, x9, lsl #1
	mov.d	v18[1], x9
	ldr	q19, [sp, #4368]                ; 16-byte Reload
	add.2d	v18, v18, v19
	mov	b21, v0[2]
	mov.b	v21[4], v0[3]
	shl.2d	v18, v18, #2
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmlt.2d	v21, v21, #0
	and.16b	v18, v21, v18
	add.2d	v18, v7, v18
	tbz	w15, #2, LBB0_135
; %bb.134:                              ; %cond.load604
                                        ;   in Loop: Header=BB0_129 Depth=2
	fmov	x9, d18
	ld1.s	{ v5 }[2], [x9]
LBB0_135:                               ; %else608
                                        ;   in Loop: Header=BB0_129 Depth=2
	ldr	q19, [sp, #6576]                ; 16-byte Reload
	tbz	w15, #3, LBB0_137
; %bb.136:                              ; %cond.load610
                                        ;   in Loop: Header=BB0_129 Depth=2
	mov.d	x9, v18[1]
	ld1.s	{ v5 }[3], [x9]
LBB0_137:                               ; %else614
                                        ;   in Loop: Header=BB0_129 Depth=2
	ldr	q18, [sp, #11360]               ; 16-byte Reload
	add.2d	v6, v6, v18
	mov.d	x9, v6[1]
	fmov	x10, d6
	add	x10, x10, x10, lsl #1
	fmov	d6, x10
	add	x9, x9, x9, lsl #1
	mov.d	v6[1], x9
	ldr	q18, [sp, #4384]                ; 16-byte Reload
	add.2d	v6, v6, v18
	mov	b18, v0[4]
	mov.b	v18[4], v0[5]
	shl.2d	v6, v6, #2
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	and.16b	v6, v18, v6
	add.2d	v6, v7, v6
	tbz	w15, #4, LBB0_139
; %bb.138:                              ; %cond.load616
                                        ;   in Loop: Header=BB0_129 Depth=2
	fmov	x9, d6
	ld1.s	{ v2 }[0], [x9]
LBB0_139:                               ; %else620
                                        ;   in Loop: Header=BB0_129 Depth=2
	tbz	w15, #5, LBB0_141
; %bb.140:                              ; %cond.load622
                                        ;   in Loop: Header=BB0_129 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_141:                               ; %else626
                                        ;   in Loop: Header=BB0_129 Depth=2
	ldr	q6, [sp, #11344]                ; 16-byte Reload
	add.2d	v1, v1, v6
	mov.d	x9, v1[1]
	fmov	x10, d1
	add	x10, x10, x10, lsl #1
	fmov	d1, x10
	add	x9, x9, x9, lsl #1
	mov.d	v1[1], x9
	ldr	q6, [sp, #4400]                 ; 16-byte Reload
	add.2d	v1, v1, v6
	mov	b6, v0[6]
	mov.b	v6[4], v0[7]
	shl.2d	v1, v1, #2
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	and.16b	v1, v6, v1
	add.2d	v1, v7, v1
	tbz	w15, #6, LBB0_143
; %bb.142:                              ; %cond.load628
                                        ;   in Loop: Header=BB0_129 Depth=2
	fmov	x9, d1
	ld1.s	{ v2 }[2], [x9]
LBB0_143:                               ; %else632
                                        ;   in Loop: Header=BB0_129 Depth=2
	tbz	w15, #7, LBB0_145
; %bb.144:                              ; %cond.load634
                                        ;   in Loop: Header=BB0_129 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v2 }[3], [x9]
LBB0_145:                               ; %else638
                                        ;   in Loop: Header=BB0_129 Depth=2
	ldr	q1, [sp, #4416]                 ; 16-byte Reload
	and.8b	v1, v1, v4
	bic.8b	v1, v8, v1
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bsl.16b	v4, v5, v19
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v6, v5, v4
	shl.2d	v4, v11, #5
	ldr	q5, [sp, #12032]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12096]                ; 16-byte Reload
	add.2d	v4, v5, v4
	ldr	d5, [sp, #12376]                ; 8-byte Reload
	fmov	w9, s5
	tbnz	w9, #0, LBB0_154
; %bb.146:                              ; %else644
                                        ;   in Loop: Header=BB0_129 Depth=2
	tbnz	w9, #1, LBB0_155
LBB0_147:                               ; %else648
                                        ;   in Loop: Header=BB0_129 Depth=2
	shl.2d	v4, v23, #5
	ldr	q5, [sp, #12016]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12080]                ; 16-byte Reload
	add.2d	v4, v5, v4
	tbnz	w9, #2, LBB0_156
LBB0_148:                               ; %else652
                                        ;   in Loop: Header=BB0_129 Depth=2
	tbz	w9, #3, LBB0_150
LBB0_149:                               ; %cond.store653
                                        ;   in Loop: Header=BB0_129 Depth=2
	mov.d	x10, v4[1]
	st1.s	{ v6 }[3], [x10]
LBB0_150:                               ; %else656
                                        ;   in Loop: Header=BB0_129 Depth=2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q4, [sp, #6560]                 ; 16-byte Reload
	bsl.16b	v0, v2, v4
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v1, v1, v0
	shl.2d	v0, v28, #5
	ldr	q2, [sp, #12000]                ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #12064]                ; 16-byte Reload
	add.2d	v0, v2, v0
	tbnz	w9, #4, LBB0_157
; %bb.151:                              ; %else660
                                        ;   in Loop: Header=BB0_129 Depth=2
	tbnz	w9, #5, LBB0_158
LBB0_152:                               ; %else664
                                        ;   in Loop: Header=BB0_129 Depth=2
	shl.2d	v0, v31, #5
	ldr	q2, [sp, #11984]                ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #12048]                ; 16-byte Reload
	add.2d	v0, v2, v0
	tbnz	w9, #6, LBB0_159
LBB0_153:                               ; %else668
                                        ;   in Loop: Header=BB0_129 Depth=2
	tbz	w9, #7, LBB0_128
	b	LBB0_160
LBB0_154:                               ; %cond.store641
                                        ;   in Loop: Header=BB0_129 Depth=2
	fmov	x10, d4
	str	s6, [x10]
	tbz	w9, #1, LBB0_147
LBB0_155:                               ; %cond.store645
                                        ;   in Loop: Header=BB0_129 Depth=2
	mov.d	x10, v4[1]
	st1.s	{ v6 }[1], [x10]
	shl.2d	v4, v23, #5
	ldr	q5, [sp, #12016]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #12080]                ; 16-byte Reload
	add.2d	v4, v5, v4
	tbz	w9, #2, LBB0_148
LBB0_156:                               ; %cond.store649
                                        ;   in Loop: Header=BB0_129 Depth=2
	fmov	x10, d4
	st1.s	{ v6 }[2], [x10]
	tbnz	w9, #3, LBB0_149
	b	LBB0_150
LBB0_157:                               ; %cond.store657
                                        ;   in Loop: Header=BB0_129 Depth=2
	fmov	x10, d0
	str	s1, [x10]
	tbz	w9, #5, LBB0_152
LBB0_158:                               ; %cond.store661
                                        ;   in Loop: Header=BB0_129 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v1 }[1], [x10]
	shl.2d	v0, v31, #5
	ldr	q2, [sp, #11984]                ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #12048]                ; 16-byte Reload
	add.2d	v0, v2, v0
	tbz	w9, #6, LBB0_153
LBB0_159:                               ; %cond.store665
                                        ;   in Loop: Header=BB0_129 Depth=2
	fmov	x10, d0
	st1.s	{ v1 }[2], [x10]
	tbz	w9, #7, LBB0_128
LBB0_160:                               ; %cond.store669
                                        ;   in Loop: Header=BB0_129 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[3], [x9]
	b	LBB0_128
LBB0_161:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	q9, [sp, #13088]                ; 16-byte Reload
LBB0_162:                               ; %direct.false380
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q17, [sp, #8096]                ; 16-byte Spill
	stp	q10, q11, [sp, #736]            ; 32-byte Folded Spill
	str	q31, [sp, #4624]                ; 16-byte Spill
	str	q28, [sp, #4640]                ; 16-byte Spill
	str	q23, [sp, #4656]                ; 16-byte Spill
	str	q3, [sp, #864]                  ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #640]                  ; 16-byte Reload
	ldr	q3, [sp, #8176]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8176]                 ; 16-byte Spill
	ldr	q3, [sp, #8208]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8208]                 ; 16-byte Spill
	ldr	q3, [sp, #8192]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8192]                 ; 16-byte Spill
	ldr	q3, [sp, #8224]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8224]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #8112]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8112]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #8144]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8144]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #8128]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8128]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #8160]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8160]                 ; 16-byte Spill
	ldr	q2, [sp, #4880]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #4880]                 ; 16-byte Spill
	ldr	q2, [sp, #4912]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #4912]                 ; 16-byte Spill
	ldr	q2, [sp, #4896]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #4896]                 ; 16-byte Spill
	ldr	q1, [sp, #4784]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	mov.16b	v21, v1
	fmov	x9, d1
	cmp	x9, #9
	str	q13, [sp, #4608]                ; 16-byte Spill
	b.gt	LBB0_218
; %bb.163:                              ; %direct.true392.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q31, [sp, #4864]                ; 16-byte Reload
	ldr	q11, [sp, #4848]                ; 16-byte Reload
	ldr	q13, [sp, #4832]                ; 16-byte Reload
	ldr	q18, [sp, #4816]                ; 16-byte Reload
	ldr	q19, [sp, #4800]                ; 16-byte Reload
	ldr	q23, [sp, #4912]                ; 16-byte Reload
	ldr	q28, [sp, #4896]                ; 16-byte Reload
	ldr	q10, [sp, #4880]                ; 16-byte Reload
	ldr	q27, [sp, #1360]                ; 16-byte Reload
	b	LBB0_165
LBB0_164:                               ; %else803
                                        ;   in Loop: Header=BB0_165 Depth=2
	str	q3, [sp, #6512]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v23, v23, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v28, v28, v0
	ldr	q0, [sp, #13248]                ; 16-byte Reload
	add.2d	v10, v10, v0
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v21, v21, v0
	fmov	x9, d21
	cmp	x9, #10
	b.ge	LBB0_219
LBB0_165:                               ; %direct.true392
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_168 Depth 3
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	and.16b	v2, v14, v10
	and.16b	v4, v12, v23
	and.16b	v5, v1, v28
	and.16b	v6, v0, v21
	fmov	x9, d6
	ldr	q7, [sp, #13168]                ; 16-byte Reload
	fmov	x10, d7
	sdiv	x19, x9, x10
	mov.d	x9, v6[1]
	sdiv	x21, x9, x28
	fmov	x9, d5
	ldr	q7, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d7
	sdiv	x20, x9, x11
	mov.d	x9, v5[1]
	sdiv	x22, x9, x8
	fmov	x9, d4
	ldr	q7, [sp, #13200]                ; 16-byte Reload
	fmov	x12, d7
	sdiv	x6, x9, x12
	mov.d	x9, v4[1]
	sdiv	x7, x9, x30
	fmov	x9, d2
	ldr	q7, [sp, #13216]                ; 16-byte Reload
	fmov	x23, d7
	sdiv	x9, x9, x23
	mov.d	x15, v2[1]
	sdiv	x15, x15, x14
	mul	x10, x19, x10
	fmov	d7, x10
	mul	x10, x21, x28
	mov.d	v7[1], x10
	mul	x10, x15, x14
	mul	x23, x9, x23
	mul	x11, x20, x11
	sub.2d	v6, v6, v7
	fmov	d7, x11
	mul	x11, x22, x8
	mov.d	v7[1], x11
	mul	x11, x7, x30
	mul	x12, x6, x12
	sub.2d	v5, v5, v7
	fmov	d7, x12
	mov.d	v7[1], x11
	sub.2d	v4, v4, v7
	fmov	d7, x23
	mov.d	v7[1], x10
	sub.2d	v2, v2, v7
	bit.16b	v19, v2, v14
	bit.16b	v18, v5, v1
	shl.2d	v5, v5, #3
	shl.2d	v2, v2, #3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v2, v3, v2
	cmgt.2d	v5, v9, v5
	uzp1.4s	v2, v5, v2
	bit.16b	v13, v4, v12
	bit.16b	v11, v6, v0
	shl.2d	v5, v6, #3
	shl.2d	v4, v4, #3
	cmgt.2d	v4, v30, v4
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	cmgt.2d	v5, v3, v5
	uzp1.4s	v4, v5, v4
	fmov	d5, x19
	mov.d	v5[1], x21
	uzp1.8h	v4, v4, v2
	ldr	q7, [sp, #13328]                ; 16-byte Reload
	and.16b	v2, v4, v7
	xtn.8b	v2, v2
	bic.8b	v6, v31, v8
	orr.8b	v31, v2, v6
	fmov	d2, x20
	mov.d	v2[1], x22
	and.16b	v2, v1, v2
	and.16b	v5, v0, v5
	mov.d	x10, v5[1]
	mov.d	x11, v2[1]
	fmov	x12, d5
	fmov	x19, d2
	fmov	d2, x6
	mov.d	v2[1], x7
	and.16b	v2, v12, v2
	mov.d	x6, v2[1]
	fmov	x7, d2
	fmov	d2, x9
	mov.d	v2[1], x15
	and.16b	v2, v14, v2
	ldr	x15, [sp, #11736]               ; 8-byte Reload
	sdiv	x9, x10, x15
	msub	x9, x9, x15, x10
	ldr	q5, [sp, #11712]                ; 16-byte Reload
	fmov	x10, d5
	sdiv	x15, x12, x10
	msub	x10, x15, x10, x12
	sdiv	x12, x11, x26
	msub	x11, x12, x26, x11
	ldr	q5, [sp, #11696]                ; 16-byte Reload
	fmov	x12, d5
	sdiv	x15, x6, x25
	msub	x15, x15, x25, x6
	ldr	q5, [sp, #11680]                ; 16-byte Reload
	fmov	x6, d5
	mov.d	x20, v2[1]
	fmov	x21, d2
	ldr	q2, [sp, #11664]                ; 16-byte Reload
	fmov	x22, d2
	sdiv	x23, x21, x22
	msub	x21, x23, x22, x21
	sdiv	x22, x7, x6
	sdiv	x23, x20, x27
	msub	x20, x23, x27, x20
	fmov	d2, x21
	mov.d	v2[1], x20
	msub	x6, x22, x6, x7
	ldr	q3, [sp, #12112]                ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #12112]                ; 16-byte Spill
	fmov	d2, x6
	mov.d	v2[1], x15
	sdiv	x15, x19, x12
	msub	x12, x15, x12, x19
	ldr	q3, [sp, #12144]                ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #12144]                ; 16-byte Spill
	fmov	d2, x12
	mov.d	v2[1], x11
	ldr	q3, [sp, #12128]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #12128]                ; 16-byte Spill
	fmov	d2, x10
	mov.d	v2[1], x9
	ldr	q3, [sp, #12160]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #12160]                ; 16-byte Spill
	ldr	q2, [sp, #10880]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10880]                ; 16-byte Spill
	ldr	q1, [sp, #11488]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	ldr	q0, [sp, #10864]                ; 16-byte Reload
	bic.16b	v0, v0, v14
	str	q0, [sp, #10864]                ; 16-byte Spill
	bic.16b	v16, v16, v12
	ldr	q3, [sp, #6512]                 ; 16-byte Reload
	bic.16b	v3, v3, v26
	bic.16b	v22, v22, v24
	str	q1, [sp, #11488]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #7
	mov.16b	v5, v8
	b.ge	LBB0_200
; %bb.166:                              ; %direct.true398.lr.ph
                                        ;   in Loop: Header=BB0_165 Depth=2
	str	q10, [sp, #4880]                ; 16-byte Spill
	str	q28, [sp, #4896]                ; 16-byte Spill
	str	q23, [sp, #4912]                ; 16-byte Spill
	str	q21, [sp, #4784]                ; 16-byte Spill
	mov.16b	v10, v3
	mov.16b	v15, v22
	mov.d	x9, v11[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	str	q11, [sp, #4848]                ; 16-byte Spill
	fmov	x10, d11
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	mov.d	x9, v13[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	str	q13, [sp, #4832]                ; 16-byte Spill
	fmov	x10, d13
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d29, x10
	mov.d	v29[1], x9
	mov.d	x9, v18[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	str	q18, [sp, #4816]                ; 16-byte Spill
	fmov	x10, d18
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	mov.d	x9, v19[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	str	q19, [sp, #4800]                ; 16-byte Spill
	fmov	x10, d19
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d30, x10
	mov.d	v30[1], x9
	and.16b	v0, v7, v4
	xtn.8b	v8, v0
	str	q31, [sp, #4864]                ; 16-byte Spill
	bic.8b	v0, v5, v31
	zip2.8b	v1, v8, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v18, v1, #0
	zip1.8b	v1, v8, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v7, v1, #0
	zip1.8b	v1, v0, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v9, v1, #0
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v4, v0, #0
	ldr	q19, [sp, #10880]               ; 16-byte Reload
	ldr	q23, [sp, #10864]               ; 16-byte Reload
	ldr	q22, [sp, #11488]               ; 16-byte Reload
	b	LBB0_168
LBB0_167:                               ; %else769
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.s	v28[1], v11[0]
	mov.s	v28[2], v14[0]
	mov.s	v28[3], v25[0]
	mov.s	v5[1], v0[0]
	mov.s	v5[2], v1[0]
	mov.s	v5[3], v21[0]
	bit.16b	v20, v5, v24
	bit.16b	v27, v28, v26
	ldr	q0, [sp, #12624]                ; 16-byte Reload
	bit.16b	v0, v12, v18
	ldr	q1, [sp, #12640]                ; 16-byte Reload
	bit.16b	v1, v23, v7
	and.16b	v1, v9, v1
	and.16b	v0, v4, v0
	str	q0, [sp, #12624]                ; 16-byte Spill
	fmul.4s	v0, v0, v27
	str	q1, [sp, #12640]                ; 16-byte Spill
	fmul.4s	v1, v1, v20
	fadd.4s	v1, v15, v1
	fadd.4s	v0, v10, v0
	ldr	q5, [sp, #13296]                ; 16-byte Reload
	add.2d	v16, v16, v5
	ldr	q5, [sp, #13280]                ; 16-byte Reload
	add.2d	v19, v13, v5
	ldr	q17, [sp, #13248]               ; 16-byte Reload
	add.2d	v23, v3, v17
	ldr	q5, [sp, #13264]                ; 16-byte Reload
	add.2d	v22, v22, v5
	bit.16b	v10, v0, v26
	bit.16b	v15, v1, v24
	fmov	x9, d22
	cmp	x9, #7
	ldr	q12, [sp, #12864]               ; 16-byte Reload
	ldr	q14, [sp, #13024]               ; 16-byte Reload
	b.ge	LBB0_201
LBB0_168:                               ; %direct.true398
                                        ;   Parent Loop BB0_91 Depth=1
                                        ;     Parent Loop BB0_165 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v0, v26, #0
	sshll.2d	v1, v24, #0
	and.16b	v5, v1, v22
	mov.16b	v13, v19
	and.16b	v21, v0, v19
	mov.16b	v3, v23
	and.16b	v23, v14, v23
	mov.d	x9, v23[1]
	and.16b	v25, v12, v16
	ldr	q19, [sp, #13008]               ; 16-byte Reload
	mov.d	x10, v19[1]
	sdiv	x9, x9, x10
	fmov	x11, d23
	fmov	x12, d19
	sdiv	x15, x11, x12
	mov.d	x11, v25[1]
	ldr	q19, [sp, #12992]               ; 16-byte Reload
	mov.d	x7, v19[1]
	sdiv	x19, x11, x7
	fmov	x11, d25
	fmov	x21, d19
	mov.d	x6, v21[1]
	ldr	q19, [sp, #12976]               ; 16-byte Reload
	mov.d	x22, v19[1]
	sdiv	x20, x11, x21
	sdiv	x6, x6, x22
	fmov	x11, d21
	fmov	x23, d19
	mov.d	x24, v5[1]
	ldr	q19, [sp, #12960]               ; 16-byte Reload
	mov.d	x25, v19[1]
	sdiv	x24, x24, x25
	fmov	x26, d5
	fmov	x27, d19
	sdiv	x26, x26, x27
	mul	x27, x26, x27
	fmov	d28, x26
	mov.d	v28[1], x24
	mul	x10, x9, x10
	mul	x12, x15, x12
	fmov	d31, x12
	mov.d	v31[1], x10
	mul	x10, x19, x7
	mul	x12, x20, x21
	fmov	d11, x12
	mov.d	v11[1], x10
	mul	x10, x6, x22
	sdiv	x21, x11, x23
	mul	x11, x21, x23
	fmov	d12, x11
	mov.d	v12[1], x10
	mul	x10, x24, x25
	fmov	d14, x27
	mov.d	v14[1], x10
	ldr	q19, [sp, #12160]               ; 16-byte Reload
	add.2d	v19, v28, v19
	sub.2d	v5, v5, v14
	sub.2d	v21, v21, v12
	sub.2d	v11, v25, v11
	sub.2d	v14, v23, v31
	ldr	q23, [sp, #13040]               ; 16-byte Reload
	cmeq.2d	v23, v23, v14
	ldr	q25, [sp, #13056]               ; 16-byte Reload
	cmeq.2d	v25, v25, v21
	uzp1.4s	v23, v25, v23
	ldr	q25, [sp, #13072]               ; 16-byte Reload
	cmeq.2d	v25, v25, v11
	ldr	q28, [sp, #13104]               ; 16-byte Reload
	cmeq.2d	v28, v28, v5
	uzp1.4s	v25, v28, v25
	uzp1.8h	v23, v25, v23
	ldr	q25, [sp, #13328]               ; 16-byte Reload
	and.16b	v25, v25, v23
	xtn.8b	v28, v25
	shl.8b	v25, v28, #7
	cmlt.8b	v25, v25, #0
	ldr	d31, [sp, #13320]               ; 8-byte Reload
	and.8b	v25, v25, v31
	addv.8b	b25, v25
	fmov	w7, s25
	shl.2d	v19, v19, #5
	ldr	q25, [sp, #12336]               ; 16-byte Reload
	orr.16b	v19, v19, v25
	ldr	q25, [sp, #11792]               ; 16-byte Reload
	add.2d	v31, v25, v19
	movi.2d	v25, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbz	w7, #0, LBB0_170
; %bb.169:                              ; %cond.load674
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	x10, d31
	ldr	s25, [x10]
LBB0_170:                               ; %else678
                                        ;   in Loop: Header=BB0_168 Depth=3
	tbz	w7, #1, LBB0_172
; %bb.171:                              ; %cond.load680
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v25 }[1], [x10]
LBB0_172:                               ; %else684
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	d19, x20
	mov.d	v19[1], x19
	ldr	q31, [sp, #12144]               ; 16-byte Reload
	add.2d	v19, v19, v31
	shl.2d	v19, v19, #5
	ldr	q31, [sp, #12304]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #11824]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbz	w7, #2, LBB0_174
; %bb.173:                              ; %cond.load686
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	x10, d31
	ld1.s	{ v25 }[2], [x10]
LBB0_174:                               ; %else690
                                        ;   in Loop: Header=BB0_168 Depth=3
	tbz	w7, #3, LBB0_176
; %bb.175:                              ; %cond.load692
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v25 }[3], [x10]
LBB0_176:                               ; %else696
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	d19, x21
	mov.d	v19[1], x6
	ldr	q31, [sp, #12128]               ; 16-byte Reload
	add.2d	v19, v19, v31
	shl.2d	v19, v19, #5
	ldr	q31, [sp, #12352]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #11808]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbz	w7, #4, LBB0_178
; %bb.177:                              ; %cond.load698
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	x10, d31
	ld1.s	{ v12 }[0], [x10]
LBB0_178:                               ; %else702
                                        ;   in Loop: Header=BB0_168 Depth=3
	tbz	w7, #5, LBB0_180
; %bb.179:                              ; %cond.load704
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v12 }[1], [x10]
LBB0_180:                               ; %else708
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	d19, x15
	mov.d	v19[1], x9
	ldr	q17, [sp, #12112]               ; 16-byte Reload
	add.2d	v19, v19, v17
	shl.2d	v19, v19, #5
	ldr	q31, [sp, #12320]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #11840]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbz	w7, #6, LBB0_182
; %bb.181:                              ; %cond.load710
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	x9, d31
	ld1.s	{ v12 }[2], [x9]
LBB0_182:                               ; %else714
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.16b	v24, v22
	tbz	w7, #7, LBB0_184
; %bb.183:                              ; %cond.load716
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.d	x9, v31[1]
	ld1.s	{ v12 }[3], [x9]
LBB0_184:                               ; %else720
                                        ;   in Loop: Header=BB0_168 Depth=3
	ldr	q19, [sp, #13024]               ; 16-byte Reload
	ldr	q22, [sp, #12704]               ; 16-byte Reload
	bit.16b	v22, v14, v19
	ldr	q19, [sp, #12864]               ; 16-byte Reload
	ldr	q26, [sp, #12672]               ; 16-byte Reload
	bit.16b	v26, v11, v19
	ldr	q31, [sp, #12720]               ; 16-byte Reload
	bit.16b	v31, v21, v0
	ldr	q21, [sp, #12688]               ; 16-byte Reload
	bit.16b	v21, v5, v1
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	bic.16b	v0, v0, v23
	xtn.8b	v0, v0
	zip2.8b	v1, v28, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q5, [sp, #12608]                ; 16-byte Reload
	bsl.16b	v1, v12, v5
	zip1.8b	v5, v28, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q19, [sp, #12656]               ; 16-byte Reload
	bsl.16b	v5, v25, v19
	zip1.8b	v19, v0, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmge.4s	v19, v19, #0
	and.16b	v25, v19, v5
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v12, v0, v1
	str	q22, [sp, #12704]               ; 16-byte Spill
	xtn.2s	v14, v22
	str	q31, [sp, #12720]               ; 16-byte Spill
	xtn.2s	v23, v31
	str	q26, [sp, #12672]               ; 16-byte Spill
	xtn.2s	v1, v26
	str	q21, [sp, #12688]               ; 16-byte Spill
	xtn.2s	v0, v21
	mov.s	w9, v0[1]
	fmov	w10, s0
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldr	q0, [sp, #13136]                ; 16-byte Reload
	str	d0, [sp, #17880]
	ldrb	w12, [x12]
	and	w12, w16, w12
	str	q12, [x13, #4416]
	str	q25, [x13, #4400]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1504
	ldr	s0, [x15, x10, lsl #2]
	tst	w11, w12
	movi.2d	v17, #0000000000000000
	fcsel	s5, s0, s17, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w17, w9
	str	q12, [x13, #4448]
	str	q25, [x13, #4432]
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1536
	ldr	s0, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s0, s0, s17, ne
	mov.s	w9, v1[1]
	fmov	w10, s1
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	str	q12, [x13, #4480]
	str	q25, [x13, #4464]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1568
	ldr	s1, [x15, x10, lsl #2]
	and	w10, w0, w12
	tst	w11, w10
	fcsel	s1, s1, s17, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w1, w9
	str	q12, [x13, #4512]
	str	q25, [x13, #4496]
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1600
	ldr	s19, [x12, x11, lsl #2]
	tst	w10, w9
	mov.s	w9, v23[1]
	fcsel	s21, s19, s17, ne
	fmov	w10, s23
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	and	w12, w2, w12
	str	q12, [x13, #4544]
	str	q25, [x13, #4528]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1632
	ldr	s19, [x15, x10, lsl #2]
	tst	w11, w12
	fcsel	s28, s19, s17, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w3, w9
	str	q12, [x13, #4576]
	str	q25, [x13, #4560]
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1664
	ldr	s19, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s11, s19, s17, ne
	mov.s	w9, v14[1]
	fmov	w10, s14
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	and	w12, w4, w12
	str	q12, [x13, #4608]
	str	q25, [x13, #4592]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1696
	ldr	s19, [x15, x10, lsl #2]
	tst	w11, w12
	fcsel	s14, s19, s17, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1496
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w5, w9
	str	q12, [sp, #12608]               ; 16-byte Spill
	str	q12, [x13, #4640]
	str	q25, [sp, #12656]               ; 16-byte Spill
	str	q25, [x13, #4624]
	add	x12, sp, #4, lsl #12            ; =16384
	add	x12, x12, #1728
	ldr	s19, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s25, s19, s17, ne
	mov.16b	v22, v24
	add.2d	v19, v24, v6
	shl.2d	v19, v19, #5
	ldr	q17, [sp, #11904]               ; 16-byte Reload
	orr.16b	v19, v19, v17
	ldr	q17, [sp, #11968]               ; 16-byte Reload
	add.2d	v31, v17, v19
	shl.8b	v19, v8, #7
	cmlt.8b	v19, v19, #0
	ldr	d23, [sp, #13320]               ; 8-byte Reload
	and.8b	v19, v19, v23
	addv.8b	b19, v19
	fmov	w9, s19
	movi.2d	v23, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbz	w9, #0, LBB0_186
; %bb.185:                              ; %cond.load723
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	x10, d31
	ldr	s23, [x10]
LBB0_186:                               ; %else727
                                        ;   in Loop: Header=BB0_168 Depth=3
	ldr	q26, [sp, #12880]               ; 16-byte Reload
	tbz	w9, #1, LBB0_188
; %bb.187:                              ; %cond.load729
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v23 }[1], [x10]
LBB0_188:                               ; %else733
                                        ;   in Loop: Header=BB0_168 Depth=3
	add.2d	v19, v16, v29
	shl.2d	v19, v19, #5
	ldr	q17, [sp, #11888]               ; 16-byte Reload
	orr.16b	v19, v19, v17
	ldr	q17, [sp, #11952]               ; 16-byte Reload
	add.2d	v31, v17, v19
	tbz	w9, #2, LBB0_190
; %bb.189:                              ; %cond.load735
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	x10, d31
	ld1.s	{ v23 }[2], [x10]
LBB0_190:                               ; %else739
                                        ;   in Loop: Header=BB0_168 Depth=3
	ldr	q24, [sp, #11744]               ; 16-byte Reload
	tbz	w9, #3, LBB0_192
; %bb.191:                              ; %cond.load741
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v23 }[3], [x10]
LBB0_192:                               ; %else745
                                        ;   in Loop: Header=BB0_168 Depth=3
	add.2d	v19, v13, v2
	shl.2d	v19, v19, #5
	ldr	q17, [sp, #11872]               ; 16-byte Reload
	orr.16b	v19, v19, v17
	ldr	q17, [sp, #11936]               ; 16-byte Reload
	add.2d	v31, v17, v19
	tbz	w9, #4, LBB0_194
; %bb.193:                              ; %cond.load747
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	x10, d31
	ld1.s	{ v12 }[0], [x10]
LBB0_194:                               ; %else751
                                        ;   in Loop: Header=BB0_168 Depth=3
	tbz	w9, #5, LBB0_196
; %bb.195:                              ; %cond.load753
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v12 }[1], [x10]
LBB0_196:                               ; %else757
                                        ;   in Loop: Header=BB0_168 Depth=3
	add.2d	v19, v3, v30
	shl.2d	v19, v19, #5
	ldr	q17, [sp, #11856]               ; 16-byte Reload
	orr.16b	v19, v19, v17
	ldr	q17, [sp, #11920]               ; 16-byte Reload
	add.2d	v31, v17, v19
	tbz	w9, #6, LBB0_198
; %bb.197:                              ; %cond.load759
                                        ;   in Loop: Header=BB0_168 Depth=3
	fmov	x10, d31
	ld1.s	{ v12 }[2], [x10]
LBB0_198:                               ; %else763
                                        ;   in Loop: Header=BB0_168 Depth=3
	tbz	w9, #7, LBB0_167
; %bb.199:                              ; %cond.load765
                                        ;   in Loop: Header=BB0_168 Depth=3
	mov.d	x9, v31[1]
	ld1.s	{ v12 }[3], [x9]
	b	LBB0_167
LBB0_200:                               ; %direct.true392.direct.false399_crit_edge
                                        ;   in Loop: Header=BB0_165 Depth=2
	and.16b	v0, v7, v4
	xtn.8b	v8, v0
	b	LBB0_202
LBB0_201:                               ;   in Loop: Header=BB0_165 Depth=2
	str	q22, [sp, #11488]               ; 16-byte Spill
	str	q23, [sp, #10864]               ; 16-byte Spill
	str	q19, [sp, #10880]               ; 16-byte Spill
	ldr	q5, [sp, #13136]                ; 16-byte Reload
	ldr	x27, [sp, #11400]               ; 8-byte Reload
	ldr	x26, [sp, #11632]               ; 8-byte Reload
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	mov.16b	v22, v15
	mov.16b	v3, v10
	ldr	q25, [sp, #5840]                ; 16-byte Reload
	ldr	q29, [sp, #5824]                ; 16-byte Reload
	ldr	q31, [sp, #4864]                ; 16-byte Reload
	ldr	q11, [sp, #4848]                ; 16-byte Reload
	ldr	q13, [sp, #4832]                ; 16-byte Reload
	ldr	q18, [sp, #4816]                ; 16-byte Reload
	ldr	q19, [sp, #4800]                ; 16-byte Reload
	ldr	q21, [sp, #4784]                ; 16-byte Reload
	ldr	q23, [sp, #4912]                ; 16-byte Reload
	ldr	q28, [sp, #4896]                ; 16-byte Reload
	ldr	q10, [sp, #4880]                ; 16-byte Reload
LBB0_202:                               ; %direct.false399
                                        ;   in Loop: Header=BB0_165 Depth=2
	shl.2d	v0, v21, #5
	ldr	q1, [sp, #8160]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #8224]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	shl.8b	v1, v8, #7
	cmlt.8b	v1, v1, #0
	ldr	d2, [sp, #13320]                ; 8-byte Reload
	and.8b	v1, v1, v2
	addv.8b	b1, v1
	fmov	w9, s1
	tbnz	w9, #0, LBB0_210
; %bb.203:                              ; %else775
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.16b	v8, v5
	tbnz	w9, #1, LBB0_211
LBB0_204:                               ; %else779
                                        ;   in Loop: Header=BB0_165 Depth=2
	shl.2d	v0, v23, #5
	ldr	q1, [sp, #8144]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #8208]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w9, #2, LBB0_212
LBB0_205:                               ; %else783
                                        ;   in Loop: Header=BB0_165 Depth=2
	tbnz	w9, #3, LBB0_213
LBB0_206:                               ; %else787
                                        ;   in Loop: Header=BB0_165 Depth=2
	shl.2d	v0, v28, #5
	ldr	q1, [sp, #8128]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #8192]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w9, #4, LBB0_214
LBB0_207:                               ; %else791
                                        ;   in Loop: Header=BB0_165 Depth=2
	tbnz	w9, #5, LBB0_215
LBB0_208:                               ; %else795
                                        ;   in Loop: Header=BB0_165 Depth=2
	shl.2d	v0, v10, #5
	ldr	q1, [sp, #8112]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #8176]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w9, #6, LBB0_216
LBB0_209:                               ; %else799
                                        ;   in Loop: Header=BB0_165 Depth=2
	tbz	w9, #7, LBB0_164
	b	LBB0_217
LBB0_210:                               ; %cond.store772
                                        ;   in Loop: Header=BB0_165 Depth=2
	fmov	x10, d0
	str	s22, [x10]
	mov.16b	v8, v5
	tbz	w9, #1, LBB0_204
LBB0_211:                               ; %cond.store776
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v22 }[1], [x10]
	shl.2d	v0, v23, #5
	ldr	q1, [sp, #8144]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #8208]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w9, #2, LBB0_205
LBB0_212:                               ; %cond.store780
                                        ;   in Loop: Header=BB0_165 Depth=2
	fmov	x10, d0
	st1.s	{ v22 }[2], [x10]
	tbz	w9, #3, LBB0_206
LBB0_213:                               ; %cond.store784
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v22 }[3], [x10]
	shl.2d	v0, v28, #5
	ldr	q1, [sp, #8128]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #8192]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w9, #4, LBB0_207
LBB0_214:                               ; %cond.store788
                                        ;   in Loop: Header=BB0_165 Depth=2
	fmov	x10, d0
	str	s3, [x10]
	tbz	w9, #5, LBB0_208
LBB0_215:                               ; %cond.store792
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.d	x10, v0[1]
	st1.s	{ v3 }[1], [x10]
	shl.2d	v0, v10, #5
	ldr	q1, [sp, #8112]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #8176]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w9, #6, LBB0_209
LBB0_216:                               ; %cond.store796
                                        ;   in Loop: Header=BB0_165 Depth=2
	fmov	x10, d0
	st1.s	{ v3 }[2], [x10]
	tbz	w9, #7, LBB0_164
LBB0_217:                               ; %cond.store800
                                        ;   in Loop: Header=BB0_165 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v3 }[3], [x9]
	b	LBB0_164
LBB0_218:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q31, [sp, #4864]                ; 16-byte Reload
	ldr	q11, [sp, #4848]                ; 16-byte Reload
	ldr	q13, [sp, #4832]                ; 16-byte Reload
	ldr	q18, [sp, #4816]                ; 16-byte Reload
	ldr	q19, [sp, #4800]                ; 16-byte Reload
	ldr	q23, [sp, #4912]                ; 16-byte Reload
	ldr	q28, [sp, #4896]                ; 16-byte Reload
	ldr	q10, [sp, #4880]                ; 16-byte Reload
	ldr	q27, [sp, #1360]                ; 16-byte Reload
LBB0_219:                               ; %direct.false393
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q10, [sp, #4880]                ; 16-byte Spill
	str	q28, [sp, #4896]                ; 16-byte Spill
	str	q23, [sp, #4912]                ; 16-byte Spill
	str	q21, [sp, #4784]                ; 16-byte Spill
	str	q19, [sp, #4800]                ; 16-byte Spill
	str	q18, [sp, #4816]                ; 16-byte Spill
	str	q22, [sp, #4768]                ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #624]                  ; 16-byte Reload
	ldr	q3, [sp, #9648]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #9648]                 ; 16-byte Spill
	ldr	q3, [sp, #9680]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #9680]                 ; 16-byte Spill
	ldr	q3, [sp, #9664]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9664]                 ; 16-byte Spill
	ldr	q3, [sp, #9696]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9696]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #9712]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #9712]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #9744]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #9744]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #9728]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9728]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #9760]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9760]                 ; 16-byte Spill
	ldr	q2, [sp, #1824]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	ldr	q22, [sp, #1808]                ; 16-byte Reload
	bic.16b	v22, v22, v12
	bic.16b	v25, v25, v1
	bic.16b	v29, v29, v0
	fmov	x9, d29
	cmp	x9, #9
	b.le	LBB0_223
LBB0_220:                               ; %direct.false428
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q22, [sp, #1808]                ; 16-byte Spill
	str	q27, [sp, #1360]                ; 16-byte Spill
	str	q2, [sp, #1824]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #608]                  ; 16-byte Reload
	ldr	q4, [sp, #9552]                 ; 16-byte Reload
	bit.16b	v4, v2, v14
	str	q4, [sp, #9552]                 ; 16-byte Spill
	ldr	q3, [sp, #9584]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #9584]                 ; 16-byte Spill
	ldr	q4, [sp, #9568]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #9568]                 ; 16-byte Spill
	ldr	q3, [sp, #9600]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9600]                 ; 16-byte Spill
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #9616]                 ; 16-byte Spill
	ldr	q2, [sp, #9520]                 ; 16-byte Reload
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #9520]                 ; 16-byte Spill
	ldr	q2, [sp, #2048]                 ; 16-byte Reload
	ldr	q3, [sp, #9632]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9632]                 ; 16-byte Spill
	ldr	q2, [sp, #9536]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9536]                 ; 16-byte Spill
	ldr	q2, [sp, #2000]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #2000]                 ; 16-byte Spill
	ldr	q2, [sp, #2016]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #2016]                 ; 16-byte Spill
	ldr	q5, [sp, #1776]                 ; 16-byte Reload
	bic.16b	v5, v5, v1
	ldr	q2, [sp, #1792]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	fmov	x9, d2
	cmp	x9, #4
	b.gt	LBB0_272
; %bb.221:                              ; %direct.true439.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	ldr	q6, [sp, #2000]                 ; 16-byte Reload
	b	LBB0_256
LBB0_222:                               ; %else885
                                        ;   in Loop: Header=BB0_223 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v22, v22, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v25, v25, v0
	ldr	q0, [sp, #13248]                ; 16-byte Reload
	add.2d	v2, v10, v0
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v29, v29, v0
	fmov	x9, d29
	cmp	x9, #10
	b.ge	LBB0_220
LBB0_223:                               ; %direct.true427
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v24, #0
	sshll.2d	v28, v26, #0
	mov.16b	v10, v2
	and.16b	v1, v14, v2
	mov.16b	v15, v22
	and.16b	v2, v12, v22
	mov.16b	v22, v25
	and.16b	v4, v28, v25
	mov.16b	v3, v29
	and.16b	v5, v0, v29
	fmov	x9, d5
	ldr	q6, [sp, #13168]                ; 16-byte Reload
	fmov	x10, d6
	sdiv	x11, x9, x10
	mov.d	x9, v5[1]
	sdiv	x12, x9, x28
	fmov	x9, d4
	ldr	q6, [sp, #13184]                ; 16-byte Reload
	fmov	x6, d6
	sdiv	x7, x9, x6
	mov.d	x9, v4[1]
	sdiv	x19, x9, x8
	fmov	x9, d2
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x22, d6
	sdiv	x20, x9, x22
	mov.d	x9, v2[1]
	sdiv	x21, x9, x30
	fmov	x9, d1
	ldr	q6, [sp, #13216]                ; 16-byte Reload
	fmov	x23, d6
	sdiv	x9, x9, x23
	mov.d	x15, v1[1]
	sdiv	x15, x15, x14
	mul	x10, x11, x10
	fmov	d6, x10
	mul	x10, x12, x28
	mov.d	v6[1], x10
	mul	x10, x21, x30
	mul	x22, x20, x22
	fmov	d7, x22
	mov.d	v7[1], x10
	mul	x10, x19, x8
	mul	x6, x7, x6
	fmov	d18, x6
	mov.d	v18[1], x10
	mul	x10, x15, x14
	mul	x6, x9, x23
	fmov	d19, x6
	mov.d	v19[1], x10
	sub.2d	v21, v1, v19
	sub.2d	v23, v4, v18
	sub.2d	v25, v2, v7
	sub.2d	v1, v5, v6
	shl.2d	v2, v1, #3
	shl.2d	v4, v25, #3
	shl.2d	v5, v23, #3
	shl.2d	v6, v21, #3
	ldr	q7, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v7, v7, v6
	cmgt.2d	v18, v9, v5
	uzp1.4s	v7, v18, v7
	cmgt.2d	v18, v30, v4
	ldr	q19, [sp, #13120]               ; 16-byte Reload
	cmgt.2d	v19, v19, v2
	uzp1.4s	v18, v19, v18
	fmov	d19, x11
	mov.d	v19[1], x12
	uzp1.8h	v7, v18, v7
	and.16b	v0, v0, v19
	mov.d	x10, v0[1]
	ldr	x12, [sp, #11736]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	x11, d0
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	fmov	x12, d0
	sdiv	x6, x11, x12
	msub	x11, x6, x12, x11
	add	x11, x11, x11, lsl #2
	fmov	d0, x11
	add	x10, x10, x10, lsl #2
	mov.d	v0[1], x10
	add.2d	v1, v0, v1
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	and.16b	v0, v0, v7
	xtn.8b	v0, v0
	shl.8b	v7, v0, #7
	cmlt.8b	v7, v7, #0
	ldr	d18, [sp, #13320]               ; 8-byte Reload
	and.8b	v7, v7, v18
	addv.8b	b7, v7
	fmov	w6, s7
	shl.2d	v1, v1, #5
	ldr	q18, [sp, #8160]                ; 16-byte Reload
	orr.16b	v1, v1, v18
	ldr	q18, [sp, #8224]                ; 16-byte Reload
	add.2d	v29, v18, v1
	movi.2d	v18, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w6, #0, LBB0_225
; %bb.224:                              ; %cond.load805
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	x10, d29
	ldr	s18, [x10]
LBB0_225:                               ; %else809
                                        ;   in Loop: Header=BB0_223 Depth=2
	tbz	w6, #1, LBB0_227
; %bb.226:                              ; %cond.load811
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.d	x10, v29[1]
	ld1.s	{ v18 }[1], [x10]
LBB0_227:                               ; %else815
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.16b	v29, v3
	fmov	d19, x20
	mov.d	v19[1], x21
	and.16b	v19, v12, v19
	mov.d	x10, v19[1]
	sdiv	x11, x10, x25
	msub	x10, x11, x25, x10
	fmov	x11, d19
	ldr	q19, [sp, #11680]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x20, x11, x12
	msub	x11, x20, x12, x11
	add	x11, x11, x11, lsl #2
	fmov	d19, x11
	add	x10, x10, x10, lsl #2
	mov.d	v19[1], x10
	add.2d	v19, v19, v25
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #8144]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #8208]                 ; 16-byte Reload
	add.2d	v25, v3, v19
	tbz	w6, #2, LBB0_229
; %bb.228:                              ; %cond.load817
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	x10, d25
	ld1.s	{ v18 }[2], [x10]
LBB0_229:                               ; %else821
                                        ;   in Loop: Header=BB0_223 Depth=2
	tbz	w6, #3, LBB0_231
; %bb.230:                              ; %cond.load823
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.d	x10, v25[1]
	ld1.s	{ v18 }[3], [x10]
LBB0_231:                               ; %else827
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.16b	v25, v22
	fmov	d19, x7
	mov.d	v19[1], x19
	and.16b	v19, v28, v19
	mov.d	x10, v19[1]
	sdiv	x11, x10, x26
	msub	x10, x11, x26, x10
	fmov	x11, d19
	ldr	q19, [sp, #11696]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x7, x11, x12
	msub	x11, x7, x12, x11
	add	x11, x11, x11, lsl #2
	fmov	d19, x11
	add	x10, x10, x10, lsl #2
	mov.d	v19[1], x10
	add.2d	v19, v19, v23
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #8128]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #8192]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	mov.16b	v22, v15
	tbz	w6, #4, LBB0_233
; %bb.232:                              ; %cond.load829
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	x10, d23
	ld1.s	{ v1 }[0], [x10]
LBB0_233:                               ; %else833
                                        ;   in Loop: Header=BB0_223 Depth=2
	tbz	w6, #5, LBB0_235
; %bb.234:                              ; %cond.load835
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v1 }[1], [x10]
LBB0_235:                               ; %else839
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	d19, x9
	mov.d	v19[1], x15
	and.16b	v19, v14, v19
	mov.d	x9, v19[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d19
	ldr	q19, [sp, #11664]               ; 16-byte Reload
	fmov	x11, d19
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	add	x10, x10, x10, lsl #2
	fmov	d19, x10
	add	x9, x9, x9, lsl #2
	mov.d	v19[1], x9
	add.2d	v19, v19, v21
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #8112]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #8176]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w6, #6, LBB0_237
; %bb.236:                              ; %cond.load841
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	x9, d21
	ld1.s	{ v1 }[2], [x9]
LBB0_237:                               ; %else845
                                        ;   in Loop: Header=BB0_223 Depth=2
	tbz	w6, #7, LBB0_239
; %bb.238:                              ; %cond.load847
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v1 }[3], [x9]
LBB0_239:                               ; %else851
                                        ;   in Loop: Header=BB0_223 Depth=2
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmge.2d	v6, v6, v3
	cmge.2d	v5, v5, v9
	uzp1.4s	v5, v5, v6
	cmge.2d	v4, v4, v30
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	cmge.2d	v2, v2, v3
	uzp1.4s	v2, v2, v4
	uzp1.8h	v2, v2, v5
	ldr	q4, [sp, #13328]                ; 16-byte Reload
	and.16b	v2, v4, v2
	xtn.8b	v2, v2
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #7872]                 ; 16-byte Reload
	bit.16b	v5, v18, v4
	zip1.8b	v4, v2, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v6, v4, #0
	mov	w9, #33936                      ; =0x8490
	movk	w9, #16065, lsl #16
	dup.4s	v4, w9
	and.16b	v5, v6, v5
	str	q5, [sp, #7872]                 ; 16-byte Spill
	fmul.4s	v5, v5, v4
	fmov	w9, s7
	shl.2d	v6, v29, #5
	ldr	q3, [sp, #9760]                 ; 16-byte Reload
	orr.16b	v6, v6, v3
	ldr	q7, [sp, #9696]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbnz	w9, #0, LBB0_248
; %bb.240:                              ; %else857
                                        ;   in Loop: Header=BB0_223 Depth=2
	tbnz	w9, #1, LBB0_249
LBB0_241:                               ; %else861
                                        ;   in Loop: Header=BB0_223 Depth=2
	shl.2d	v6, v22, #5
	ldr	q7, [sp, #9744]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #9680]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbnz	w9, #2, LBB0_250
LBB0_242:                               ; %else865
                                        ;   in Loop: Header=BB0_223 Depth=2
	tbz	w9, #3, LBB0_244
LBB0_243:                               ; %cond.store866
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v5 }[3], [x10]
LBB0_244:                               ; %else869
                                        ;   in Loop: Header=BB0_223 Depth=2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q5, [sp, #7888]                 ; 16-byte Reload
	bsl.16b	v0, v1, v5
	zip2.8b	v1, v2, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7888]                 ; 16-byte Spill
	fmul.4s	v0, v0, v4
	shl.2d	v1, v25, #5
	ldr	q2, [sp, #9728]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #9664]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_251
; %bb.245:                              ; %else873
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.16b	v2, v10
	tbnz	w9, #5, LBB0_252
LBB0_246:                               ; %else877
                                        ;   in Loop: Header=BB0_223 Depth=2
	shl.2d	v1, v2, #5
	ldr	q2, [sp, #9712]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_253
LBB0_247:                               ; %else881
                                        ;   in Loop: Header=BB0_223 Depth=2
	tbz	w9, #7, LBB0_222
	b	LBB0_254
LBB0_248:                               ; %cond.store854
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	x10, d6
	str	s5, [x10]
	tbz	w9, #1, LBB0_241
LBB0_249:                               ; %cond.store858
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v5 }[1], [x10]
	shl.2d	v6, v22, #5
	ldr	q7, [sp, #9744]                 ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #9680]                 ; 16-byte Reload
	add.2d	v6, v7, v6
	tbz	w9, #2, LBB0_242
LBB0_250:                               ; %cond.store862
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	x10, d6
	st1.s	{ v5 }[2], [x10]
	tbnz	w9, #3, LBB0_243
	b	LBB0_244
LBB0_251:                               ; %cond.store870
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	mov.16b	v2, v10
	tbz	w9, #5, LBB0_246
LBB0_252:                               ; %cond.store874
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v2, #5
	ldr	q2, [sp, #9712]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_247
LBB0_253:                               ; %cond.store878
                                        ;   in Loop: Header=BB0_223 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_222
LBB0_254:                               ; %cond.store882
                                        ;   in Loop: Header=BB0_223 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_222
LBB0_255:                               ; %else918
                                        ;   in Loop: Header=BB0_256 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v4, v10, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v5, v15, v0
	ldr	q0, [sp, #13248]                ; 16-byte Reload
	add.2d	v6, v3, v0
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v2, v2, v0
	fmov	x9, d2
	cmp	x9, #5
	b.ge	LBB0_273
LBB0_256:                               ; %direct.true439
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	and.16b	v0, v0, v2
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13168]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	mov.16b	v28, v2
	mov.16b	v10, v4
	and.16b	v2, v12, v4
	mov.d	x9, v2[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d2
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	mov.16b	v15, v5
	and.16b	v1, v1, v5
	mov.d	x9, v1[1]
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d1
	ldr	q1, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	mov.16b	v3, v6
	and.16b	v4, v14, v6
	mov.d	x9, v4[1]
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d4
	ldr	q4, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	shl.2d	v5, v4, #3
	shl.2d	v1, v1, #3
	shl.2d	v2, v2, #3
	shl.2d	v0, v0, #3
	ldr	q4, [sp, #13104]                ; 16-byte Reload
	orr.16b	v18, v0, v4
	ldr	q0, [sp, #13072]                ; 16-byte Reload
	orr.16b	v6, v2, v0
	ldr	q0, [sp, #13056]                ; 16-byte Reload
	orr.16b	v4, v1, v0
	ldr	q0, [sp, #13040]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	mov	w9, #33                         ; =0x21
	dup.2d	v2, x9
	cmgt.2d	v1, v2, v0
	cmgt.2d	v5, v2, v4
	uzp1.4s	v19, v5, v1
	cmgt.2d	v7, v2, v6
	cmgt.2d	v21, v2, v18
	uzp1.4s	v23, v21, v7
	mov	w9, #32                         ; =0x20
	dup.2d	v2, x9
	uzp1.8h	v19, v23, v19
	bif.16b	v18, v2, v21
	ldr	q21, [sp, #13328]               ; 16-byte Reload
	and.16b	v19, v21, v19
	xtn.8b	v19, v19
	shl.8b	v19, v19, #7
	cmlt.8b	v19, v19, #0
	ldr	d21, [sp, #13320]               ; 8-byte Reload
	and.8b	v19, v19, v21
	addv.8b	b19, v19
	fmov	w9, s19
	mov.16b	v22, v28
	shl.2d	v19, v28, #6
	ldr	q21, [sp, #9536]                ; 16-byte Reload
	orr.16b	v19, v19, v21
	ldr	q21, [sp, #9600]                ; 16-byte Reload
	add.2d	v21, v21, v19
	tbz	w9, #0, LBB0_258
; %bb.257:                              ; %cond.store887
                                        ;   in Loop: Header=BB0_256 Depth=2
	fmov	x10, d21
	str	d18, [x10]
LBB0_258:                               ; %else890
                                        ;   in Loop: Header=BB0_256 Depth=2
	tbz	w9, #1, LBB0_260
; %bb.259:                              ; %cond.store891
                                        ;   in Loop: Header=BB0_256 Depth=2
	mov.d	x10, v21[1]
	st1.d	{ v18 }[1], [x10]
LBB0_260:                               ; %else894
                                        ;   in Loop: Header=BB0_256 Depth=2
	bif.16b	v6, v2, v7
	shl.2d	v7, v10, #6
	ldr	q18, [sp, #9520]                ; 16-byte Reload
	orr.16b	v7, v7, v18
	ldr	q18, [sp, #9584]                ; 16-byte Reload
	add.2d	v7, v18, v7
	tbz	w9, #2, LBB0_262
; %bb.261:                              ; %cond.store895
                                        ;   in Loop: Header=BB0_256 Depth=2
	fmov	x10, d7
	str	d6, [x10]
LBB0_262:                               ; %else898
                                        ;   in Loop: Header=BB0_256 Depth=2
	tbz	w9, #3, LBB0_264
; %bb.263:                              ; %cond.store899
                                        ;   in Loop: Header=BB0_256 Depth=2
	mov.d	x10, v7[1]
	st1.d	{ v6 }[1], [x10]
LBB0_264:                               ; %else902
                                        ;   in Loop: Header=BB0_256 Depth=2
	bif.16b	v4, v2, v5
	shl.2d	v5, v15, #6
	ldr	q6, [sp, #9632]                 ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #9568]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #4, LBB0_266
; %bb.265:                              ; %cond.store903
                                        ;   in Loop: Header=BB0_256 Depth=2
	fmov	x10, d5
	str	d4, [x10]
LBB0_266:                               ; %else906
                                        ;   in Loop: Header=BB0_256 Depth=2
	tbz	w9, #5, LBB0_268
; %bb.267:                              ; %cond.store907
                                        ;   in Loop: Header=BB0_256 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v4 }[1], [x10]
LBB0_268:                               ; %else910
                                        ;   in Loop: Header=BB0_256 Depth=2
	bif.16b	v0, v2, v1
	shl.2d	v1, v3, #6
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #9552]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_270
; %bb.269:                              ; %cond.store911
                                        ;   in Loop: Header=BB0_256 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_270:                               ; %else914
                                        ;   in Loop: Header=BB0_256 Depth=2
	mov.16b	v2, v22
	tbz	w9, #7, LBB0_255
; %bb.271:                              ; %cond.store915
                                        ;   in Loop: Header=BB0_256 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_255
LBB0_272:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q4, [sp, #2016]                 ; 16-byte Reload
	ldr	q6, [sp, #2000]                 ; 16-byte Reload
LBB0_273:                               ; %direct.false440
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q13, [sp, #4832]                ; 16-byte Spill
	str	q11, [sp, #4848]                ; 16-byte Spill
	str	q31, [sp, #4864]                ; 16-byte Spill
	str	q6, [sp, #2000]                 ; 16-byte Spill
	str	q5, [sp, #1776]                 ; 16-byte Spill
	str	q4, [sp, #2016]                 ; 16-byte Spill
	str	q2, [sp, #1792]                 ; 16-byte Spill
	str	q29, [sp, #5824]                ; 16-byte Spill
	str	q25, [sp, #5840]                ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #592]                  ; 16-byte Reload
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #9424]                 ; 16-byte Spill
	ldr	q3, [sp, #9456]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #9456]                 ; 16-byte Spill
	ldr	q3, [sp, #9440]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9440]                 ; 16-byte Spill
	ldr	q3, [sp, #9472]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9472]                 ; 16-byte Spill
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #9488]                 ; 16-byte Spill
	ldr	q2, [sp, #9392]                 ; 16-byte Reload
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #9392]                 ; 16-byte Spill
	ldr	q2, [sp, #9504]                 ; 16-byte Reload
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9504]                 ; 16-byte Spill
	ldr	q2, [sp, #9408]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9408]                 ; 16-byte Spill
	ldr	q2, [sp, #1712]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	ldr	q17, [sp, #1744]                ; 16-byte Reload
	bic.16b	v17, v17, v12
	ldr	q23, [sp, #1728]                ; 16-byte Reload
	bic.16b	v23, v23, v1
	ldr	q25, [sp, #1760]                ; 16-byte Reload
	bic.16b	v25, v25, v0
	fmov	x9, d25
	cmp	x9, #4
	b.gt	LBB0_308
; %bb.274:                              ; %direct.true447.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	ldr	q31, [sp, #13120]               ; 16-byte Reload
	b	LBB0_276
LBB0_275:                               ; %else1000
                                        ;   in Loop: Header=BB0_276 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v17, v17, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v23, v23, v0
	add.2d	v2, v13, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v25, v25, v0
	fmov	x9, d25
	cmp	x9, #5
	b.ge	LBB0_309
LBB0_276:                               ; %direct.true447
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v26, #0
	sshll.2d	v1, v24, #0
	mov.16b	v13, v2
	and.16b	v2, v14, v2
	mov.d	x9, v2[1]
	mov.16b	v3, v23
	and.16b	v0, v0, v23
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d2
	ldr	q2, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d2
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d29, x10
	mov.d	v29[1], x9
	mov.d	x9, v0[1]
	mov.16b	v15, v17
	and.16b	v2, v12, v17
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.d	x9, v2[1]
	mov.16b	v10, v25
	and.16b	v0, v1, v25
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d2
	ldr	q1, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d25, x10
	mov.d	v25[1], x9
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13168]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	shl.2d	v6, v0, #3
	shl.2d	v7, v25, #3
	shl.2d	v18, v23, #3
	shl.2d	v21, v29, #3
	ldr	q1, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v1, v1, v21
	cmgt.2d	v2, v9, v18
	uzp1.4s	v1, v2, v1
	cmgt.2d	v2, v30, v7
	cmgt.2d	v4, v31, v6
	uzp1.4s	v2, v4, v2
	uzp1.8h	v1, v2, v1
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	and.16b	v1, v2, v1
	xtn.8b	v2, v1
	shl.8b	v1, v2, #7
	cmlt.8b	v1, v1, #0
	ldr	d4, [sp, #13320]                ; 8-byte Reload
	and.8b	v1, v1, v4
	addv.8b	b5, v1
	fmov	w9, s5
	shl.2d	v0, v0, #6
	ldr	q1, [sp, #9536]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9600]                 ; 16-byte Reload
	add.2d	v30, v1, v0
	tbz	w9, #0, LBB0_278
; %bb.277:                              ; %cond.load920
                                        ;   in Loop: Header=BB0_276 Depth=2
	fmov	x10, d30
	ldr	d28, [x10]
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #1, LBB0_279
	b	LBB0_280
LBB0_278:                               ;   in Loop: Header=BB0_276 Depth=2
	movi.2d	v28, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w9, #1, LBB0_280
LBB0_279:                               ; %cond.load926
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.d	x10, v30[1]
	ld1.d	{ v28 }[1], [x10]
LBB0_280:                               ; %else930
                                        ;   in Loop: Header=BB0_276 Depth=2
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	shl.2d	v19, v25, #6
	ldr	q22, [sp, #9520]                ; 16-byte Reload
	orr.16b	v19, v19, v22
	ldr	q17, [sp, #9584]                ; 16-byte Reload
	add.2d	v25, v17, v19
	tbz	w9, #2, LBB0_282
; %bb.281:                              ; %cond.load932
                                        ;   in Loop: Header=BB0_276 Depth=2
	fmov	x10, d25
	ld1.d	{ v1 }[0], [x10]
LBB0_282:                               ; %else936
                                        ;   in Loop: Header=BB0_276 Depth=2
	tbz	w9, #3, LBB0_284
; %bb.283:                              ; %cond.load938
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.d	x10, v25[1]
	ld1.d	{ v1 }[1], [x10]
LBB0_284:                               ; %else942
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.16b	v25, v10
	shl.2d	v19, v23, #6
	ldr	q17, [sp, #9632]                ; 16-byte Reload
	orr.16b	v19, v19, v17
	ldr	q22, [sp, #9568]                ; 16-byte Reload
	add.2d	v23, v22, v19
	mov.16b	v17, v15
	ldr	q15, [sp, #8080]                ; 16-byte Reload
	tbnz	w9, #4, LBB0_305
; %bb.285:                              ; %else948
                                        ;   in Loop: Header=BB0_276 Depth=2
	ldr	q27, [sp, #8064]                ; 16-byte Reload
	tbnz	w9, #5, LBB0_306
LBB0_286:                               ; %else954
                                        ;   in Loop: Header=BB0_276 Depth=2
	shl.2d	v19, v29, #6
	ldr	q22, [sp, #9616]                ; 16-byte Reload
	orr.16b	v19, v19, v22
	ldr	q22, [sp, #9552]                ; 16-byte Reload
	add.2d	v23, v22, v19
	tbnz	w9, #6, LBB0_307
LBB0_287:                               ; %else960
                                        ;   in Loop: Header=BB0_276 Depth=2
	ldr	q22, [sp, #4752]                ; 16-byte Reload
	tbz	w9, #7, LBB0_289
LBB0_288:                               ; %cond.load962
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.d	x9, v23[1]
	ld1.d	{ v4 }[1], [x9]
LBB0_289:                               ; %else966
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.16b	v23, v3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmge.2d	v19, v21, v3
	cmge.2d	v18, v18, v9
	uzp1.4s	v18, v18, v19
	cmge.2d	v7, v7, v30
	cmge.2d	v6, v6, v31
	uzp1.4s	v6, v6, v7
	uzp1.8h	v6, v6, v18
	ldr	q7, [sp, #13328]                ; 16-byte Reload
	and.16b	v6, v7, v6
	xtn.8b	v6, v6
	mov	b7, v2[0]
	mov.b	v7[4], v2[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	ldr	q3, [sp, #7824]                 ; 16-byte Reload
	bsl.16b	v7, v28, v3
	mov	b18, v6[0]
	mov.b	v18[4], v6[1]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmge.2d	v18, v18, #0
	and.16b	v3, v18, v7
	str	q3, [sp, #7824]                 ; 16-byte Spill
	ldr	q7, [sp, #11552]                ; 16-byte Reload
	add.2d	v7, v3, v7
	fmov	w9, s5
	shl.2d	v5, v25, #6
	ldr	q18, [sp, #9408]                ; 16-byte Reload
	orr.16b	v5, v5, v18
	ldr	q3, [sp, #9472]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #0, LBB0_291
; %bb.290:                              ; %cond.store969
                                        ;   in Loop: Header=BB0_276 Depth=2
	fmov	x10, d5
	str	d7, [x10]
LBB0_291:                               ; %else972
                                        ;   in Loop: Header=BB0_276 Depth=2
	tbz	w9, #1, LBB0_293
; %bb.292:                              ; %cond.store973
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v7 }[1], [x10]
LBB0_293:                               ; %else976
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov	b5, v2[2]
	mov.b	v5[4], v2[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q3, [sp, #7808]                 ; 16-byte Reload
	bif.16b	v1, v3, v5
	mov	b5, v6[2]
	mov.b	v5[4], v6[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v1, v5, v1
	str	q1, [sp, #7808]                 ; 16-byte Spill
	ldr	q3, [sp, #11536]                ; 16-byte Reload
	add.2d	v1, v1, v3
	shl.2d	v5, v17, #6
	ldr	q7, [sp, #9392]                 ; 16-byte Reload
	orr.16b	v5, v5, v7
	ldr	q3, [sp, #9456]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #2, LBB0_295
; %bb.294:                              ; %cond.store977
                                        ;   in Loop: Header=BB0_276 Depth=2
	fmov	x10, d5
	str	d1, [x10]
LBB0_295:                               ; %else980
                                        ;   in Loop: Header=BB0_276 Depth=2
	tbz	w9, #3, LBB0_297
; %bb.296:                              ; %cond.store981
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v1 }[1], [x10]
LBB0_297:                               ; %else984
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov	b1, v2[4]
	mov.b	v1[4], v2[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q3, [sp, #7856]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	mov	b1, v6[4]
	mov.b	v1[4], v6[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7856]                 ; 16-byte Spill
	ldr	q1, [sp, #11520]                ; 16-byte Reload
	add.2d	v0, v0, v1
	shl.2d	v1, v23, #6
	ldr	q5, [sp, #9504]                 ; 16-byte Reload
	orr.16b	v1, v1, v5
	ldr	q3, [sp, #9440]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_299
; %bb.298:                              ; %cond.store985
                                        ;   in Loop: Header=BB0_276 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_299:                               ; %else988
                                        ;   in Loop: Header=BB0_276 Depth=2
	tbz	w9, #5, LBB0_301
; %bb.300:                              ; %cond.store989
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.d	x10, v1[1]
	st1.d	{ v0 }[1], [x10]
LBB0_301:                               ; %else992
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov	b0, v2[6]
	mov.b	v0[4], v2[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q1, [sp, #7840]                 ; 16-byte Reload
	bsl.16b	v0, v4, v1
	mov	b1, v6[6]
	mov.b	v1[4], v6[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7840]                 ; 16-byte Spill
	ldr	q1, [sp, #11504]                ; 16-byte Reload
	add.2d	v0, v0, v1
	shl.2d	v1, v13, #6
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #9424]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_303
; %bb.302:                              ; %cond.store993
                                        ;   in Loop: Header=BB0_276 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_303:                               ; %else996
                                        ;   in Loop: Header=BB0_276 Depth=2
	tbz	w9, #7, LBB0_275
; %bb.304:                              ; %cond.store997
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_275
LBB0_305:                               ; %cond.load944
                                        ;   in Loop: Header=BB0_276 Depth=2
	fmov	x10, d23
	ld1.d	{ v0 }[0], [x10]
	ldr	q27, [sp, #8064]                ; 16-byte Reload
	tbz	w9, #5, LBB0_286
LBB0_306:                               ; %cond.load950
                                        ;   in Loop: Header=BB0_276 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v0 }[1], [x10]
	shl.2d	v19, v29, #6
	ldr	q22, [sp, #9616]                ; 16-byte Reload
	orr.16b	v19, v19, v22
	ldr	q22, [sp, #9552]                ; 16-byte Reload
	add.2d	v23, v22, v19
	tbz	w9, #6, LBB0_287
LBB0_307:                               ; %cond.load956
                                        ;   in Loop: Header=BB0_276 Depth=2
	fmov	x10, d23
	ld1.d	{ v4 }[0], [x10]
	ldr	q22, [sp, #4752]                ; 16-byte Reload
	tbnz	w9, #7, LBB0_288
	b	LBB0_289
LBB0_308:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q22, [sp, #4752]                ; 16-byte Reload
	ldr	q15, [sp, #8080]                ; 16-byte Reload
	ldr	q27, [sp, #8064]                ; 16-byte Reload
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	ldr	q31, [sp, #13120]               ; 16-byte Reload
LBB0_309:                               ; %direct.false448
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q17, [sp, #1744]                ; 16-byte Spill
	str	q2, [sp, #1712]                 ; 16-byte Spill
	str	q25, [sp, #1760]                ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #576]                  ; 16-byte Reload
	ldr	q3, [sp, #9264]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #9264]                 ; 16-byte Spill
	ldr	q3, [sp, #9296]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #9296]                 ; 16-byte Spill
	ldr	q3, [sp, #9280]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9280]                 ; 16-byte Spill
	ldr	q3, [sp, #9312]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9312]                 ; 16-byte Spill
	ldr	q2, [sp, #9328]                 ; 16-byte Reload
	ldp	q3, q4, [sp, #80]               ; 32-byte Folded Reload
	bit.16b	v2, v4, v14
	str	q2, [sp, #9328]                 ; 16-byte Spill
	ldr	q2, [sp, #9360]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #9360]                 ; 16-byte Spill
	ldr	q2, [sp, #9344]                 ; 16-byte Reload
	ldp	q3, q4, [sp, #112]              ; 32-byte Folded Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #9344]                 ; 16-byte Spill
	ldr	q2, [sp, #9376]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9376]                 ; 16-byte Spill
	ldr	q2, [sp, #1680]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	bic.16b	v22, v22, v12
	ldr	q3, [sp, #1696]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	ldr	q25, [sp, #1664]                ; 16-byte Reload
	bic.16b	v25, v25, v0
	fmov	x9, d25
	cmp	x9, #4
	str	q23, [sp, #1728]                ; 16-byte Spill
	b.gt	LBB0_344
; %bb.310:                              ; %direct.true459.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	d27, [sp, #11624]               ; 8-byte Reload
	b	LBB0_312
LBB0_311:                               ; %else1082
                                        ;   in Loop: Header=BB0_312 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v22, v22, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v3, v3, v0
	add.2d	v2, v2, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v25, v25, v0
	fmov	x9, d25
	cmp	x9, #5
	b.ge	LBB0_345
LBB0_312:                               ; %direct.true459
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v26, #0
	sshll.2d	v1, v24, #0
	mov.16b	v8, v2
	and.16b	v2, v14, v2
	mov.d	x9, v2[1]
	mov.16b	v13, v3
	and.16b	v0, v0, v3
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d2
	ldr	q2, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d2
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d28, x10
	mov.d	v28[1], x9
	mov.d	x9, v0[1]
	mov.16b	v15, v22
	and.16b	v2, v12, v22
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.d	x9, v2[1]
	mov.16b	v10, v25
	and.16b	v0, v1, v25
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d2
	ldr	q1, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d25, x10
	mov.d	v25[1], x9
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13168]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	shl.2d	v5, v2, #3
	shl.2d	v6, v25, #3
	shl.2d	v18, v23, #3
	shl.2d	v21, v28, #3
	ldr	q0, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v0, v0, v21
	cmgt.2d	v1, v9, v18
	uzp1.4s	v0, v1, v0
	cmgt.2d	v1, v30, v6
	cmgt.2d	v4, v31, v5
	uzp1.4s	v1, v4, v1
	uzp1.8h	v0, v1, v0
	ldr	q1, [sp, #13328]                ; 16-byte Reload
	and.16b	v0, v1, v0
	xtn.8b	v1, v0
	shl.8b	v0, v1, #7
	cmlt.8b	v0, v0, #0
	ldr	d4, [sp, #13320]                ; 8-byte Reload
	and.8b	v0, v0, v4
	addv.8b	b0, v0
	fmov	w9, s0
	shl.2d	v2, v2, #6
	ldr	q4, [sp, #9408]                 ; 16-byte Reload
	orr.16b	v2, v2, v4
	ldr	q3, [sp, #9472]                 ; 16-byte Reload
	add.2d	v30, v3, v2
	tbz	w9, #0, LBB0_314
; %bb.313:                              ; %cond.load1002
                                        ;   in Loop: Header=BB0_312 Depth=2
	fmov	x10, d30
	ldr	d2, [x10]
	movi.2d	v4, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbnz	w9, #1, LBB0_315
	b	LBB0_316
LBB0_314:                               ;   in Loop: Header=BB0_312 Depth=2
	movi.2d	v2, #0000000000000000
	movi.2d	v4, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbz	w9, #1, LBB0_316
LBB0_315:                               ; %cond.load1008
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.d	x10, v30[1]
	ld1.d	{ v2 }[1], [x10]
LBB0_316:                               ; %else1012
                                        ;   in Loop: Header=BB0_312 Depth=2
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	shl.2d	v19, v25, #6
	ldr	q22, [sp, #9392]                ; 16-byte Reload
	orr.16b	v19, v19, v22
	ldr	q3, [sp, #9456]                 ; 16-byte Reload
	add.2d	v25, v3, v19
	tbz	w9, #2, LBB0_318
; %bb.317:                              ; %cond.load1014
                                        ;   in Loop: Header=BB0_312 Depth=2
	fmov	x10, d25
	ld1.d	{ v4 }[0], [x10]
LBB0_318:                               ; %else1018
                                        ;   in Loop: Header=BB0_312 Depth=2
	tbz	w9, #3, LBB0_320
; %bb.319:                              ; %cond.load1020
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.d	x10, v25[1]
	ld1.d	{ v4 }[1], [x10]
LBB0_320:                               ; %else1024
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.16b	v3, v13
	mov.16b	v25, v10
	shl.2d	v19, v23, #6
	ldr	q22, [sp, #9504]                ; 16-byte Reload
	orr.16b	v19, v19, v22
	ldr	q17, [sp, #9440]                ; 16-byte Reload
	add.2d	v23, v17, v19
	ldr	q13, [sp, #8080]                ; 16-byte Reload
	ldr	q10, [sp, #4736]                ; 16-byte Reload
	tbnz	w9, #4, LBB0_333
; %bb.321:                              ; %else1030
                                        ;   in Loop: Header=BB0_312 Depth=2
	tbnz	w9, #5, LBB0_334
LBB0_322:                               ; %else1036
                                        ;   in Loop: Header=BB0_312 Depth=2
	shl.2d	v19, v28, #6
	ldr	q22, [sp, #9488]                ; 16-byte Reload
	orr.16b	v19, v19, v22
	ldr	q22, [sp, #9424]                ; 16-byte Reload
	add.2d	v23, v22, v19
	tbnz	w9, #6, LBB0_335
LBB0_323:                               ; %else1042
                                        ;   in Loop: Header=BB0_312 Depth=2
	tbz	w9, #7, LBB0_325
LBB0_324:                               ; %cond.load1044
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.d	x9, v23[1]
	ld1.d	{ v29 }[1], [x9]
LBB0_325:                               ; %else1048
                                        ;   in Loop: Header=BB0_312 Depth=2
	ldr	q17, [sp, #13232]               ; 16-byte Reload
	cmge.2d	v19, v21, v17
	cmge.2d	v18, v18, v9
	uzp1.4s	v18, v18, v19
	cmge.2d	v6, v6, v30
	cmge.2d	v5, v5, v31
	uzp1.4s	v5, v5, v6
	uzp1.8h	v5, v5, v18
	ldr	q6, [sp, #13328]                ; 16-byte Reload
	and.16b	v5, v6, v5
	xtn.8b	v5, v5
	mov	b6, v1[6]
	mov.b	v6[4], v1[7]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmlt.2d	v6, v6, #0
	ldr	q18, [sp, #7680]                ; 16-byte Reload
	bsl.16b	v6, v29, v18
	mov	b18, v1[4]
	mov.b	v18[4], v1[5]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	mov	b19, v1[2]
	mov.b	v19[4], v1[3]
	ldr	q21, [sp, #7696]                ; 16-byte Reload
	bif.16b	v7, v21, v18
	ushll.2d	v18, v19, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldr	q19, [sp, #7776]                ; 16-byte Reload
	bif.16b	v4, v19, v18
	mov	b18, v1[0]
	mov.b	v18[4], v1[1]
	ushll.2d	v1, v18, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q18, [sp, #7792]                ; 16-byte Reload
	bsl.16b	v1, v2, v18
	mov	b2, v5[0]
	mov.b	v2[4], v5[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	and.16b	v18, v2, v1
	mov	b1, v5[2]
	mov.b	v1[4], v5[3]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v19, v1, v4
	mov	b1, v5[4]
	mov.b	v1[4], v5[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v4, v1, v7
	mov	b1, v5[6]
	mov.b	v1[4], v5[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v5, v1, v6
	mov	w9, #35                         ; =0x23
	dup.2d	v2, x9
	fmov	w9, s0
	ldr	q0, [sp, #9376]                 ; 16-byte Reload
	add.2d	v0, v25, v0
	ldr	q1, [sp, #9312]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q5, [sp, #7680]                 ; 16-byte Spill
	cmgt.2d	v0, v2, v5
	str	q4, [sp, #7696]                 ; 16-byte Spill
	cmgt.2d	v4, v2, v4
	uzp1.4s	v0, v4, v0
	str	q19, [sp, #7776]                ; 16-byte Spill
	cmgt.2d	v4, v2, v19
	str	q18, [sp, #7792]                ; 16-byte Spill
	cmgt.2d	v2, v2, v18
	uzp1.4s	v2, v2, v4
	uzp1.8h	v0, v2, v0
	xtn.8b	v0, v0
	movi.8b	v2, #1
	and.8b	v0, v0, v2
	tbnz	w9, #0, LBB0_336
; %bb.326:                              ; %else1054
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.16b	v2, v8
	mov.16b	v22, v15
	tbnz	w9, #1, LBB0_337
LBB0_327:                               ; %else1058
                                        ;   in Loop: Header=BB0_312 Depth=2
	ldr	q1, [sp, #9360]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	ldr	q4, [sp, #9296]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	ldr	q17, [sp, #8064]                ; 16-byte Reload
	tbnz	w9, #2, LBB0_338
LBB0_328:                               ; %else1062
                                        ;   in Loop: Header=BB0_312 Depth=2
	tbnz	w9, #3, LBB0_339
LBB0_329:                               ; %else1066
                                        ;   in Loop: Header=BB0_312 Depth=2
	ldr	q1, [sp, #9344]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q4, [sp, #9280]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	tbnz	w9, #4, LBB0_340
LBB0_330:                               ; %else1070
                                        ;   in Loop: Header=BB0_312 Depth=2
	tbnz	w9, #5, LBB0_341
LBB0_331:                               ; %else1074
                                        ;   in Loop: Header=BB0_312 Depth=2
	ldr	q1, [sp, #9328]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	ldr	q4, [sp, #9264]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	tbnz	w9, #6, LBB0_342
LBB0_332:                               ; %else1078
                                        ;   in Loop: Header=BB0_312 Depth=2
	tbz	w9, #7, LBB0_311
	b	LBB0_343
LBB0_333:                               ; %cond.load1026
                                        ;   in Loop: Header=BB0_312 Depth=2
	fmov	x10, d23
	ld1.d	{ v7 }[0], [x10]
	tbz	w9, #5, LBB0_322
LBB0_334:                               ; %cond.load1032
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v7 }[1], [x10]
	shl.2d	v19, v28, #6
	ldr	q22, [sp, #9488]                ; 16-byte Reload
	orr.16b	v19, v19, v22
	ldr	q22, [sp, #9424]                ; 16-byte Reload
	add.2d	v23, v22, v19
	tbz	w9, #6, LBB0_323
LBB0_335:                               ; %cond.load1038
                                        ;   in Loop: Header=BB0_312 Depth=2
	fmov	x10, d23
	ld1.d	{ v29 }[0], [x10]
	tbnz	w9, #7, LBB0_324
	b	LBB0_325
LBB0_336:                               ; %cond.store1051
                                        ;   in Loop: Header=BB0_312 Depth=2
	fmov	x10, d1
	str	b0, [x10]
	mov.16b	v2, v8
	mov.16b	v22, v15
	tbz	w9, #1, LBB0_327
LBB0_337:                               ; %cond.store1055
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[1], [x10]
	ldr	q1, [sp, #9360]                 ; 16-byte Reload
	add.2d	v1, v22, v1
	ldr	q4, [sp, #9296]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	ldr	q17, [sp, #8064]                ; 16-byte Reload
	tbz	w9, #2, LBB0_328
LBB0_338:                               ; %cond.store1059
                                        ;   in Loop: Header=BB0_312 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[2], [x10]
	tbz	w9, #3, LBB0_329
LBB0_339:                               ; %cond.store1063
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[3], [x10]
	ldr	q1, [sp, #9344]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q4, [sp, #9280]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	tbz	w9, #4, LBB0_330
LBB0_340:                               ; %cond.store1067
                                        ;   in Loop: Header=BB0_312 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[4], [x10]
	tbz	w9, #5, LBB0_331
LBB0_341:                               ; %cond.store1071
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[5], [x10]
	ldr	q1, [sp, #9328]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	ldr	q4, [sp, #9264]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	tbz	w9, #6, LBB0_332
LBB0_342:                               ; %cond.store1075
                                        ;   in Loop: Header=BB0_312 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[6], [x10]
	tbz	w9, #7, LBB0_311
LBB0_343:                               ; %cond.store1079
                                        ;   in Loop: Header=BB0_312 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[7], [x9]
	b	LBB0_311
LBB0_344:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q10, [sp, #4736]                ; 16-byte Reload
	mov.16b	v13, v15
	mov.16b	v17, v27
	ldr	d27, [sp, #11624]               ; 8-byte Reload
LBB0_345:                               ; %direct.false460
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q2, [sp, #1680]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #560]                  ; 16-byte Reload
	ldr	q4, [sp, #9232]                 ; 16-byte Reload
	bit.16b	v4, v2, v14
	str	q4, [sp, #9232]                 ; 16-byte Spill
	ldr	q4, [sp, #9136]                 ; 16-byte Reload
	bit.16b	v4, v2, v12
	str	q4, [sp, #9136]                 ; 16-byte Spill
	ldr	q4, [sp, #9248]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #9248]                 ; 16-byte Spill
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #9152]                 ; 16-byte Spill
	ldr	q2, [sp, #9168]                 ; 16-byte Reload
	ldr	q4, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v2, v4, v14
	str	q2, [sp, #9168]                 ; 16-byte Spill
	ldr	q2, [sp, #9200]                 ; 16-byte Reload
	ldr	q4, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v4, v12
	str	q2, [sp, #9200]                 ; 16-byte Spill
	ldr	q2, [sp, #9184]                 ; 16-byte Reload
	ldr	q4, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #9184]                 ; 16-byte Spill
	ldr	q2, [sp, #9216]                 ; 16-byte Reload
	ldr	q4, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #9216]                 ; 16-byte Spill
	bic.16b	v17, v17, v14
	ldr	q2, [sp, #1632]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	bic.16b	v13, v13, v1
	ldr	q23, [sp, #1648]                ; 16-byte Reload
	bic.16b	v23, v23, v0
	fmov	x9, d23
	cmp	x9, #4
	b.le	LBB0_359
LBB0_346:                               ; %direct.false471
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q13, [sp, #8080]                ; 16-byte Spill
	str	q2, [sp, #1632]                 ; 16-byte Spill
	str	q23, [sp, #1648]                ; 16-byte Spill
	str	q22, [sp, #4752]                ; 16-byte Spill
	str	q25, [sp, #1664]                ; 16-byte Spill
	str	q3, [sp, #1696]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #544]                  ; 16-byte Reload
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #9104]                 ; 16-byte Spill
	ldr	q3, [sp, #9008]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #9008]                 ; 16-byte Spill
	ldr	q3, [sp, #9120]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9120]                 ; 16-byte Spill
	ldr	q3, [sp, #9024]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9024]                 ; 16-byte Spill
	ldr	q2, [sp, #9040]                 ; 16-byte Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #9040]                 ; 16-byte Spill
	ldr	q2, [sp, #9072]                 ; 16-byte Reload
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #9072]                 ; 16-byte Spill
	ldr	q2, [sp, #9056]                 ; 16-byte Reload
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9056]                 ; 16-byte Spill
	ldr	q2, [sp, #9088]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9088]                 ; 16-byte Spill
	ldr	q2, [sp, #1584]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	ldr	q22, [sp, #1616]                ; 16-byte Reload
	bic.16b	v22, v22, v12
	ldr	q3, [sp, #1600]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	bic.16b	v10, v10, v0
	fmov	x9, d10
	cmp	x9, #4
	b.le	LBB0_376
; %bb.347:                              ;   in Loop: Header=BB0_91 Depth=1
	ldr	q25, [sp, #4720]                ; 16-byte Reload
LBB0_348:                               ; %direct.false479
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q17, [sp, #8064]                ; 16-byte Spill
	str	q2, [sp, #1584]                 ; 16-byte Spill
	str	q3, [sp, #1600]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #528]                  ; 16-byte Reload
	ldr	q3, [sp, #3616]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #3616]                 ; 16-byte Spill
	ldr	q3, [sp, #3648]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #3648]                 ; 16-byte Spill
	ldr	q3, [sp, #3632]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3632]                 ; 16-byte Spill
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3664]                 ; 16-byte Spill
	ldr	q2, [sp, #3680]                 ; 16-byte Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #3680]                 ; 16-byte Spill
	ldr	q2, [sp, #3584]                 ; 16-byte Reload
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #3584]                 ; 16-byte Spill
	ldr	q2, [sp, #3696]                 ; 16-byte Reload
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #3696]                 ; 16-byte Spill
	ldr	q2, [sp, #3600]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #3600]                 ; 16-byte Spill
	ldr	q2, [sp, #10368]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #10368]                ; 16-byte Spill
	ldr	q2, [sp, #10400]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #10400]                ; 16-byte Spill
	ldr	q2, [sp, #10384]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10384]                ; 16-byte Spill
	ldr	q1, [sp, #1568]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x9, d0
	cmp	x9, #0
	b.le	LBB0_1129
; %bb.349:                              ;   in Loop: Header=BB0_91 Depth=1
	ldr	q28, [sp, #1552]                ; 16-byte Reload
	ldr	q29, [sp, #1536]                ; 16-byte Reload
	ldr	q8, [sp, #1520]                 ; 16-byte Reload
	ldr	q17, [sp, #144]                 ; 16-byte Reload
LBB0_350:                               ; %direct.false491
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q0, [sp, #1568]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #512]                  ; 16-byte Reload
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #3488]                 ; 16-byte Spill
	ldr	q3, [sp, #3520]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #3520]                 ; 16-byte Spill
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3504]                 ; 16-byte Spill
	ldr	q3, [sp, #3536]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3536]                 ; 16-byte Spill
	ldr	q2, [sp, #3552]                 ; 16-byte Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #3552]                 ; 16-byte Spill
	ldr	q2, [sp, #3456]                 ; 16-byte Reload
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #3456]                 ; 16-byte Spill
	ldr	q2, [sp, #3568]                 ; 16-byte Reload
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #3568]                 ; 16-byte Spill
	ldr	q2, [sp, #3472]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #3472]                 ; 16-byte Spill
	ldr	q2, [sp, #10304]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #10304]                ; 16-byte Spill
	ldr	q2, [sp, #10336]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #10336]                ; 16-byte Spill
	ldr	q2, [sp, #10320]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10320]                ; 16-byte Spill
	ldr	q1, [sp, #10352]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10352]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #0
	b.le	LBB0_1147
LBB0_351:                               ; %direct.false499
                                        ;   in Loop: Header=BB0_91 Depth=1
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #496]                  ; 16-byte Reload
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #3328]                 ; 16-byte Spill
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #3360]                 ; 16-byte Spill
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3344]                 ; 16-byte Spill
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3376]                 ; 16-byte Spill
	ldr	q2, [sp, #3392]                 ; 16-byte Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #3392]                 ; 16-byte Spill
	ldr	q2, [sp, #3424]                 ; 16-byte Reload
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #3424]                 ; 16-byte Spill
	ldr	q2, [sp, #3408]                 ; 16-byte Reload
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #3408]                 ; 16-byte Spill
	ldr	q2, [sp, #3440]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #3440]                 ; 16-byte Spill
	bic.16b	v28, v28, v14
	bic.16b	v8, v8, v12
	bic.16b	v25, v25, v1
	bic.16b	v29, v29, v0
	fmov	x9, d29
	cmp	x9, #0
	b.le	LBB0_1181
LBB0_352:                               ; %direct.false511
                                        ;   in Loop: Header=BB0_91 Depth=1
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #480]                  ; 16-byte Reload
	ldr	q3, [sp, #6336]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #6336]                 ; 16-byte Spill
	ldr	q3, [sp, #6240]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #6240]                 ; 16-byte Spill
	ldr	q3, [sp, #6352]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #6352]                 ; 16-byte Spill
	ldr	q3, [sp, #6256]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #6256]                 ; 16-byte Spill
	ldr	q2, [sp, #6272]                 ; 16-byte Reload
	ldr	q3, [sp, #2080]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #6272]                 ; 16-byte Spill
	ldr	q2, [sp, #6304]                 ; 16-byte Reload
	ldr	q3, [sp, #2064]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #6304]                 ; 16-byte Spill
	ldr	q2, [sp, #6288]                 ; 16-byte Reload
	ldr	q3, [sp, #2048]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #6288]                 ; 16-byte Spill
	ldr	q2, [sp, #6320]                 ; 16-byte Reload
	ldr	q3, [sp, #2032]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #6320]                 ; 16-byte Spill
	ldr	q2, [sp, #10240]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #10240]                ; 16-byte Spill
	ldr	q2, [sp, #10272]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #10272]                ; 16-byte Spill
	ldr	q2, [sp, #10256]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10256]                ; 16-byte Spill
	ldr	q1, [sp, #10288]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10288]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #0
	b.le	LBB0_1215
LBB0_353:                               ; %direct.false522
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q10, [sp, #4736]                ; 16-byte Spill
	str	q25, [sp, #4720]                ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #464]                  ; 16-byte Reload
	ldr	q3, [sp, #8912]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8912]                 ; 16-byte Spill
	ldr	q3, [sp, #8944]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8944]                 ; 16-byte Spill
	ldr	q3, [sp, #8928]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8928]                 ; 16-byte Spill
	ldr	q3, [sp, #8960]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8960]                 ; 16-byte Spill
	ldr	q2, [sp, #8976]                 ; 16-byte Reload
	ldp	q4, q3, [sp, #944]              ; 32-byte Folded Reload
	bit.16b	v2, v4, v14
	str	q2, [sp, #8976]                 ; 16-byte Spill
	ldr	q2, [sp, #8880]                 ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #8880]                 ; 16-byte Spill
	ldr	q2, [sp, #8992]                 ; 16-byte Reload
	ldp	q3, q4, [sp, #976]              ; 32-byte Folded Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #8992]                 ; 16-byte Spill
	ldr	q2, [sp, #8896]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #8896]                 ; 16-byte Spill
	ldr	q19, [sp, #8832]                ; 16-byte Reload
	bic.16b	v19, v19, v14
	ldr	q7, [sp, #8864]                 ; 16-byte Reload
	bic.16b	v7, v7, v12
	ldr	q18, [sp, #8848]                ; 16-byte Reload
	bic.16b	v18, v18, v1
	ldr	q1, [sp, #1504]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	fmov	x9, d1
	cmp	x9, #9
	str	q22, [sp, #1616]                ; 16-byte Spill
	str	q28, [sp, #1552]                ; 16-byte Spill
	str	q29, [sp, #1536]                ; 16-byte Spill
	str	q8, [sp, #1520]                 ; 16-byte Spill
	str	q16, [sp, #880]                 ; 16-byte Spill
	mov.16b	v29, v1
	b.le	LBB0_409
; %bb.354:                              ;   in Loop: Header=BB0_91 Depth=1
	ldr	q25, [sp, #4704]                ; 16-byte Reload
	ldr	q8, [sp, #13136]                ; 16-byte Reload
LBB0_355:                               ; %direct.false533
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q19, [sp, #8832]                ; 16-byte Spill
	str	q18, [sp, #8848]                ; 16-byte Spill
	str	q7, [sp, #8864]                 ; 16-byte Spill
	str	q29, [sp, #1504]                ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #448]                  ; 16-byte Reload
	ldr	q3, [sp, #11120]                ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #11120]                ; 16-byte Spill
	ldr	q3, [sp, #11152]                ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #11152]                ; 16-byte Spill
	ldr	q3, [sp, #11136]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #11136]                ; 16-byte Spill
	ldr	q3, [sp, #11168]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #11168]                ; 16-byte Spill
	ldr	q2, [sp, #11184]                ; 16-byte Reload
	ldp	q4, q3, [sp, #944]              ; 32-byte Folded Reload
	bit.16b	v2, v4, v14
	str	q2, [sp, #11184]                ; 16-byte Spill
	ldr	q2, [sp, #11088]                ; 16-byte Reload
	bit.16b	v2, v3, v12
	str	q2, [sp, #11088]                ; 16-byte Spill
	ldr	q2, [sp, #11200]                ; 16-byte Reload
	ldp	q3, q4, [sp, #976]              ; 32-byte Folded Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #11200]                ; 16-byte Spill
	ldr	q2, [sp, #11104]                ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #11104]                ; 16-byte Spill
	bic.16b	v25, v25, v14
	ldr	q2, [sp, #1472]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	ldr	q3, [sp, #1456]                 ; 16-byte Reload
	bic.16b	v1, v3, v1
	ldr	q30, [sp, #1488]                ; 16-byte Reload
	bic.16b	v30, v30, v0
	fmov	x9, d30
	cmp	x9, #9
	b.le	LBB0_458
LBB0_356:                               ; %direct.false551
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q20, [sp, #896]                 ; 16-byte Spill
	str	q25, [sp, #4704]                ; 16-byte Spill
	str	q1, [sp, #1456]                 ; 16-byte Spill
	str	q2, [sp, #1472]                 ; 16-byte Spill
	str	q30, [sp, #1488]                ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #432]                  ; 16-byte Reload
	ldr	q3, [sp, #12176]                ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #12176]                ; 16-byte Spill
	ldr	q3, [sp, #12208]                ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #12208]                ; 16-byte Spill
	ldr	q3, [sp, #12192]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #12192]                ; 16-byte Spill
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #12224]                ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #12240]                ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #12240]                ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #12272]                ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #12272]                ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #12256]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #12256]                ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #12288]                ; 16-byte Spill
	ldr	q6, [sp, #1424]                 ; 16-byte Reload
	bic.16b	v6, v6, v14
	ldr	q19, [sp, #1392]                ; 16-byte Reload
	bic.16b	v19, v19, v12
	ldr	q3, [sp, #1440]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	ldr	q18, [sp, #1408]                ; 16-byte Reload
	bic.16b	v18, v18, v0
	fmov	x9, d18
	cmp	x9, #9
	b.gt	LBB0_555
; %bb.357:                              ; %direct.true567.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	mov.16b	v17, v31
	b	LBB0_507
LBB0_358:                               ; %else1115
                                        ;   in Loop: Header=BB0_359 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v2, v2, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v13, v13, v0
	add.2d	v17, v17, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v23, v23, v0
	fmov	x9, d23
	cmp	x9, #5
	b.ge	LBB0_346
LBB0_359:                               ; %direct.true470
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	and.16b	v0, v0, v23
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13168]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	mov.16b	v28, v23
	mov.16b	v29, v2
	and.16b	v2, v12, v2
	mov.d	x9, v2[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d2
	ldr	q2, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d2
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	and.16b	v1, v1, v13
	mov.d	x9, v1[1]
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d1
	ldr	q1, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	and.16b	v4, v14, v17
	mov.d	x9, v4[1]
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d4
	ldr	q4, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	shl.2d	v5, v4, #3
	shl.2d	v1, v1, #3
	shl.2d	v2, v2, #3
	shl.2d	v0, v0, #3
	ldr	q4, [sp, #13104]                ; 16-byte Reload
	orr.16b	v18, v0, v4
	ldr	q0, [sp, #13072]                ; 16-byte Reload
	orr.16b	v6, v2, v0
	ldr	q0, [sp, #13056]                ; 16-byte Reload
	orr.16b	v4, v1, v0
	ldr	q0, [sp, #13040]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	mov	w9, #33                         ; =0x21
	dup.2d	v2, x9
	cmgt.2d	v1, v2, v0
	cmgt.2d	v5, v2, v4
	uzp1.4s	v19, v5, v1
	cmgt.2d	v7, v2, v6
	cmgt.2d	v21, v2, v18
	uzp1.4s	v23, v21, v7
	mov	w9, #32                         ; =0x20
	dup.2d	v2, x9
	uzp1.8h	v19, v23, v19
	bif.16b	v18, v2, v21
	ldr	q21, [sp, #13328]               ; 16-byte Reload
	and.16b	v19, v21, v19
	xtn.8b	v19, v19
	shl.8b	v19, v19, #7
	cmlt.8b	v19, v19, #0
	ldr	d21, [sp, #13320]               ; 8-byte Reload
	and.8b	v19, v19, v21
	addv.8b	b19, v19
	fmov	w9, s19
	mov.16b	v23, v28
	shl.2d	v19, v28, #6
	ldr	q21, [sp, #9216]                ; 16-byte Reload
	orr.16b	v19, v19, v21
	ldr	q21, [sp, #9152]                ; 16-byte Reload
	add.2d	v21, v21, v19
	tbz	w9, #0, LBB0_361
; %bb.360:                              ; %cond.store1084
                                        ;   in Loop: Header=BB0_359 Depth=2
	fmov	x10, d21
	str	d18, [x10]
LBB0_361:                               ; %else1087
                                        ;   in Loop: Header=BB0_359 Depth=2
	tbz	w9, #1, LBB0_363
; %bb.362:                              ; %cond.store1088
                                        ;   in Loop: Header=BB0_359 Depth=2
	mov.d	x10, v21[1]
	st1.d	{ v18 }[1], [x10]
LBB0_363:                               ; %else1091
                                        ;   in Loop: Header=BB0_359 Depth=2
	bif.16b	v6, v2, v7
	shl.2d	v7, v29, #6
	ldr	q18, [sp, #9200]                ; 16-byte Reload
	orr.16b	v7, v7, v18
	ldr	q18, [sp, #9136]                ; 16-byte Reload
	add.2d	v7, v18, v7
	tbz	w9, #2, LBB0_365
; %bb.364:                              ; %cond.store1092
                                        ;   in Loop: Header=BB0_359 Depth=2
	fmov	x10, d7
	str	d6, [x10]
LBB0_365:                               ; %else1095
                                        ;   in Loop: Header=BB0_359 Depth=2
	tbz	w9, #3, LBB0_367
; %bb.366:                              ; %cond.store1096
                                        ;   in Loop: Header=BB0_359 Depth=2
	mov.d	x10, v7[1]
	st1.d	{ v6 }[1], [x10]
LBB0_367:                               ; %else1099
                                        ;   in Loop: Header=BB0_359 Depth=2
	bif.16b	v4, v2, v5
	shl.2d	v5, v13, #6
	ldr	q6, [sp, #9184]                 ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #9248]                 ; 16-byte Reload
	add.2d	v5, v6, v5
	tbz	w9, #4, LBB0_369
; %bb.368:                              ; %cond.store1100
                                        ;   in Loop: Header=BB0_359 Depth=2
	fmov	x10, d5
	str	d4, [x10]
LBB0_369:                               ; %else1103
                                        ;   in Loop: Header=BB0_359 Depth=2
	tbz	w9, #5, LBB0_371
; %bb.370:                              ; %cond.store1104
                                        ;   in Loop: Header=BB0_359 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v4 }[1], [x10]
LBB0_371:                               ; %else1107
                                        ;   in Loop: Header=BB0_359 Depth=2
	bif.16b	v0, v2, v1
	shl.2d	v1, v17, #6
	ldr	q2, [sp, #9168]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #9232]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_373
; %bb.372:                              ; %cond.store1108
                                        ;   in Loop: Header=BB0_359 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_373:                               ; %else1111
                                        ;   in Loop: Header=BB0_359 Depth=2
	mov.16b	v2, v29
	tbz	w9, #7, LBB0_358
; %bb.374:                              ; %cond.store1112
                                        ;   in Loop: Header=BB0_359 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_358
LBB0_375:                               ; %else1197
                                        ;   in Loop: Header=BB0_376 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v22, v22, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v3, v8, v0
	add.2d	v2, v13, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v10, v10, v0
	fmov	x9, d10
	cmp	x9, #5
	b.ge	LBB0_348
LBB0_376:                               ; %direct.true478
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v26, #0
	sshll.2d	v1, v24, #0
	mov.16b	v13, v2
	and.16b	v2, v14, v2
	mov.d	x9, v2[1]
	mov.16b	v8, v3
	and.16b	v0, v0, v3
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d2
	ldr	q2, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d2
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d29, x10
	mov.d	v29[1], x9
	mov.d	x9, v0[1]
	and.16b	v2, v12, v22
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d0
	ldr	q0, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.d	x9, v2[1]
	and.16b	v0, v1, v10
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d2
	ldr	q1, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d25, x10
	mov.d	v25[1], x9
	mov.d	x9, v0[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d0
	ldr	q0, [sp, #13168]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	shl.2d	v6, v0, #3
	shl.2d	v7, v25, #3
	shl.2d	v18, v23, #3
	shl.2d	v21, v29, #3
	ldr	q1, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v1, v1, v21
	cmgt.2d	v2, v9, v18
	uzp1.4s	v1, v2, v1
	cmgt.2d	v2, v30, v7
	cmgt.2d	v4, v31, v6
	uzp1.4s	v2, v4, v2
	uzp1.8h	v1, v2, v1
	ldr	q2, [sp, #13328]                ; 16-byte Reload
	and.16b	v1, v2, v1
	xtn.8b	v2, v1
	shl.8b	v1, v2, #7
	cmlt.8b	v1, v1, #0
	ldr	d4, [sp, #13320]                ; 8-byte Reload
	and.8b	v1, v1, v4
	addv.8b	b5, v1
	fmov	w9, s5
	shl.2d	v0, v0, #6
	ldr	q1, [sp, #9216]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9152]                 ; 16-byte Reload
	add.2d	v30, v1, v0
	tbz	w9, #0, LBB0_378
; %bb.377:                              ; %cond.load1117
                                        ;   in Loop: Header=BB0_376 Depth=2
	fmov	x10, d30
	ldr	d28, [x10]
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #1, LBB0_379
	b	LBB0_380
LBB0_378:                               ;   in Loop: Header=BB0_376 Depth=2
	movi.2d	v28, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w9, #1, LBB0_380
LBB0_379:                               ; %cond.load1123
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov.d	x10, v30[1]
	ld1.d	{ v28 }[1], [x10]
LBB0_380:                               ; %else1127
                                        ;   in Loop: Header=BB0_376 Depth=2
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	shl.2d	v19, v25, #6
	ldr	q3, [sp, #9200]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9136]                 ; 16-byte Reload
	add.2d	v25, v3, v19
	tbz	w9, #2, LBB0_382
; %bb.381:                              ; %cond.load1129
                                        ;   in Loop: Header=BB0_376 Depth=2
	fmov	x10, d25
	ld1.d	{ v1 }[0], [x10]
LBB0_382:                               ; %else1133
                                        ;   in Loop: Header=BB0_376 Depth=2
	tbz	w9, #3, LBB0_384
; %bb.383:                              ; %cond.load1135
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov.d	x10, v25[1]
	ld1.d	{ v1 }[1], [x10]
LBB0_384:                               ; %else1139
                                        ;   in Loop: Header=BB0_376 Depth=2
	ldr	q25, [sp, #4720]                ; 16-byte Reload
	shl.2d	v19, v23, #6
	ldr	q3, [sp, #9184]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9248]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbnz	w9, #4, LBB0_405
; %bb.385:                              ; %else1145
                                        ;   in Loop: Header=BB0_376 Depth=2
	tbnz	w9, #5, LBB0_406
LBB0_386:                               ; %else1151
                                        ;   in Loop: Header=BB0_376 Depth=2
	shl.2d	v19, v29, #6
	ldr	q3, [sp, #9168]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9232]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbnz	w9, #6, LBB0_407
LBB0_387:                               ; %else1157
                                        ;   in Loop: Header=BB0_376 Depth=2
	tbz	w9, #7, LBB0_389
LBB0_388:                               ; %cond.load1159
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov.d	x9, v23[1]
	ld1.d	{ v4 }[1], [x9]
LBB0_389:                               ; %else1163
                                        ;   in Loop: Header=BB0_376 Depth=2
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmge.2d	v19, v21, v3
	cmge.2d	v18, v18, v9
	uzp1.4s	v18, v18, v19
	cmge.2d	v7, v7, v30
	cmge.2d	v6, v6, v31
	uzp1.4s	v6, v6, v7
	uzp1.8h	v6, v6, v18
	ldr	q7, [sp, #13328]                ; 16-byte Reload
	and.16b	v6, v7, v6
	xtn.8b	v6, v6
	mov	b7, v2[0]
	mov.b	v7[4], v2[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	ldr	q3, [sp, #7760]                 ; 16-byte Reload
	bsl.16b	v7, v28, v3
	mov	b18, v6[0]
	mov.b	v18[4], v6[1]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmge.2d	v18, v18, #0
	and.16b	v3, v18, v7
	str	q3, [sp, #7760]                 ; 16-byte Spill
	ldr	q7, [sp, #11552]                ; 16-byte Reload
	add.2d	v7, v3, v7
	fmov	w9, s5
	shl.2d	v5, v10, #6
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #9024]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #0, LBB0_391
; %bb.390:                              ; %cond.store1166
                                        ;   in Loop: Header=BB0_376 Depth=2
	fmov	x10, d5
	str	d7, [x10]
LBB0_391:                               ; %else1169
                                        ;   in Loop: Header=BB0_376 Depth=2
	tbz	w9, #1, LBB0_393
; %bb.392:                              ; %cond.store1170
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v7 }[1], [x10]
LBB0_393:                               ; %else1173
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov	b5, v2[2]
	mov.b	v5[4], v2[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q3, [sp, #7744]                 ; 16-byte Reload
	bif.16b	v1, v3, v5
	mov	b5, v6[2]
	mov.b	v5[4], v6[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v1, v5, v1
	str	q1, [sp, #7744]                 ; 16-byte Spill
	ldr	q3, [sp, #11536]                ; 16-byte Reload
	add.2d	v1, v1, v3
	shl.2d	v5, v22, #6
	ldr	q3, [sp, #9072]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #9008]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #2, LBB0_395
; %bb.394:                              ; %cond.store1174
                                        ;   in Loop: Header=BB0_376 Depth=2
	fmov	x10, d5
	str	d1, [x10]
LBB0_395:                               ; %else1177
                                        ;   in Loop: Header=BB0_376 Depth=2
	tbz	w9, #3, LBB0_397
; %bb.396:                              ; %cond.store1178
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v1 }[1], [x10]
LBB0_397:                               ; %else1181
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov	b1, v2[4]
	mov.b	v1[4], v2[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q3, [sp, #7728]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	mov	b1, v6[4]
	mov.b	v1[4], v6[5]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7728]                 ; 16-byte Spill
	ldr	q1, [sp, #11520]                ; 16-byte Reload
	add.2d	v0, v0, v1
	shl.2d	v1, v8, #6
	ldr	q3, [sp, #9056]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #9120]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_399
; %bb.398:                              ; %cond.store1182
                                        ;   in Loop: Header=BB0_376 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_399:                               ; %else1185
                                        ;   in Loop: Header=BB0_376 Depth=2
	tbz	w9, #5, LBB0_401
; %bb.400:                              ; %cond.store1186
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov.d	x10, v1[1]
	st1.d	{ v0 }[1], [x10]
LBB0_401:                               ; %else1189
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov	b0, v2[6]
	mov.b	v0[4], v2[7]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	ldr	q1, [sp, #7712]                 ; 16-byte Reload
	bsl.16b	v0, v4, v1
	mov	b1, v6[6]
	mov.b	v1[4], v6[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7712]                 ; 16-byte Spill
	ldr	q1, [sp, #11504]                ; 16-byte Reload
	add.2d	v0, v0, v1
	shl.2d	v1, v13, #6
	ldr	q2, [sp, #9040]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #9104]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_403
; %bb.402:                              ; %cond.store1190
                                        ;   in Loop: Header=BB0_376 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_403:                               ; %else1193
                                        ;   in Loop: Header=BB0_376 Depth=2
	tbz	w9, #7, LBB0_375
; %bb.404:                              ; %cond.store1194
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_375
LBB0_405:                               ; %cond.load1141
                                        ;   in Loop: Header=BB0_376 Depth=2
	fmov	x10, d23
	ld1.d	{ v0 }[0], [x10]
	tbz	w9, #5, LBB0_386
LBB0_406:                               ; %cond.load1147
                                        ;   in Loop: Header=BB0_376 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v0 }[1], [x10]
	shl.2d	v19, v29, #6
	ldr	q3, [sp, #9168]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9232]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w9, #6, LBB0_387
LBB0_407:                               ; %cond.load1153
                                        ;   in Loop: Header=BB0_376 Depth=2
	fmov	x10, d23
	ld1.d	{ v4 }[0], [x10]
	tbnz	w9, #7, LBB0_388
	b	LBB0_389
LBB0_408:                               ; %else1607
                                        ;   in Loop: Header=BB0_409 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v7, v7, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v18, v18, v0
	add.2d	v19, v19, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v29, v29, v0
	fmov	x9, d29
	cmp	x9, #10
	b.ge	LBB0_355
LBB0_409:                               ; %direct.true532
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v4, v26, #0
	sshll.2d	v2, v24, #0
	and.16b	v0, v2, v29
	str	q7, [sp, #8864]                 ; 16-byte Spill
	and.16b	v1, v12, v7
	str	q18, [sp, #8848]                ; 16-byte Spill
	and.16b	v5, v4, v18
	str	q19, [sp, #8832]                ; 16-byte Spill
	and.16b	v18, v14, v19
	fmov	x9, d18
	ldr	q6, [sp, #11664]                ; 16-byte Reload
	fmov	x15, d6
	sdiv	x6, x9, x15
	fmov	d6, x6
	mov.d	x9, v18[1]
	sdiv	x7, x9, x27
	mov.d	v6[1], x7
	fmov	x9, d5
	ldr	q7, [sp, #11696]                ; 16-byte Reload
	fmov	x19, d7
	sdiv	x20, x9, x19
	fmov	d7, x20
	mov.d	x9, v5[1]
	sdiv	x23, x9, x26
	mov.d	v7[1], x23
	fmov	x9, d1
	ldr	q19, [sp, #11680]               ; 16-byte Reload
	fmov	x21, d19
	sdiv	x22, x9, x21
	fmov	d19, x22
	mov.d	x9, v1[1]
	sdiv	x24, x9, x25
	mov.d	v19[1], x24
	fmov	x9, d0
	ldr	q21, [sp, #11712]               ; 16-byte Reload
	fmov	x25, d21
	sdiv	x26, x9, x25
	fmov	d25, x26
	mov.d	x9, v0[1]
	ldr	x10, [sp, #11736]               ; 8-byte Reload
	sdiv	x27, x9, x10
	mov.d	v25[1], x27
	and.16b	v6, v14, v6
	mov.d	x9, v6[1]
	and.16b	v4, v4, v7
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d6
	ldr	q6, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d6
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d21, x10
	mov.d	v21[1], x9
	mov.d	x9, v4[1]
	and.16b	v6, v12, v19
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d4
	ldr	q4, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.d	x9, v6[1]
	and.16b	v2, v2, v25
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d6
	ldr	q4, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d25, x10
	mov.d	v25[1], x9
	mov.d	x9, v2[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d2
	ldr	q2, [sp, #13168]                ; 16-byte Reload
	fmov	x11, d2
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	shl.2d	v3, v4, #3
	shl.2d	v16, v25, #3
	shl.2d	v22, v23, #3
	shl.2d	v6, v21, #3
	ldr	q2, [sp, #13232]                ; 16-byte Reload
	mov.16b	v10, v6
	cmgt.2d	v2, v2, v6
	cmgt.2d	v6, v9, v22
	uzp1.4s	v2, v6, v2
	cmgt.2d	v6, v30, v16
	mov.16b	v15, v3
	cmgt.2d	v7, v31, v3
	uzp1.4s	v6, v7, v6
	uzp1.8h	v2, v6, v2
	ldr	q31, [sp, #13328]               ; 16-byte Reload
	and.16b	v2, v31, v2
	xtn.8b	v2, v2
	shl.8b	v6, v2, #7
	cmlt.8b	v6, v6, #0
	ldr	d7, [sp, #13320]                ; 8-byte Reload
	and.8b	v6, v6, v7
	addv.8b	b27, v6
	fmov	w9, s27
	shl.2d	v4, v4, #6
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	orr.16b	v4, v4, v3
	ldr	q3, [sp, #9024]                 ; 16-byte Reload
	add.2d	v28, v3, v4
	tbz	w9, #0, LBB0_411
; %bb.410:                              ; %cond.load1478
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d28
	ldr	d17, [x10]
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbnz	w9, #1, LBB0_412
	b	LBB0_413
LBB0_411:                               ;   in Loop: Header=BB0_409 Depth=2
	movi.2d	v17, #0000000000000000
	movi.2d	v7, #0000000000000000
	movi.2d	v6, #0000000000000000
	movi.2d	v4, #0000000000000000
	tbz	w9, #1, LBB0_413
LBB0_412:                               ; %cond.load1484
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x10, v28[1]
	ld1.d	{ v17 }[1], [x10]
LBB0_413:                               ; %else1488
                                        ;   in Loop: Header=BB0_409 Depth=2
	shl.2d	v19, v25, #6
	ldr	q3, [sp, #9072]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9008]                 ; 16-byte Reload
	add.2d	v25, v3, v19
	tbnz	w9, #2, LBB0_423
; %bb.414:                              ; %else1494
                                        ;   in Loop: Header=BB0_409 Depth=2
	tbnz	w9, #3, LBB0_424
LBB0_415:                               ; %else1500
                                        ;   in Loop: Header=BB0_409 Depth=2
	shl.2d	v19, v23, #6
	ldr	q3, [sp, #9056]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9120]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbnz	w9, #4, LBB0_425
LBB0_416:                               ; %else1506
                                        ;   in Loop: Header=BB0_409 Depth=2
	tbnz	w9, #5, LBB0_426
LBB0_417:                               ; %else1512
                                        ;   in Loop: Header=BB0_409 Depth=2
	shl.2d	v19, v21, #6
	ldr	q3, [sp, #9040]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w9, #6, LBB0_419
LBB0_418:                               ; %cond.load1514
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d21
	ld1.d	{ v4 }[0], [x10]
LBB0_419:                               ; %else1518
                                        ;   in Loop: Header=BB0_409 Depth=2
	ldr	x10, [sp, #11736]               ; 8-byte Reload
	mul	x10, x27, x10
	mul	x11, x26, x25
	fmov	d19, x11
	mov.d	v19[1], x10
	ldr	x10, [sp, #11632]               ; 8-byte Reload
	mul	x10, x23, x10
	mul	x11, x20, x19
	fmov	d25, x11
	mov.d	v25[1], x10
	ldr	x10, [sp, #11640]               ; 8-byte Reload
	mul	x10, x24, x10
	mul	x11, x22, x21
	fmov	d23, x11
	mov.d	v23[1], x10
	ldr	x27, [sp, #11400]               ; 8-byte Reload
	mul	x10, x7, x27
	mul	x11, x6, x15
	fmov	d28, x11
	mov.d	v28[1], x10
	sub.2d	v28, v18, v28
	sub.2d	v23, v1, v23
	sub.2d	v25, v5, v25
	sub.2d	v1, v0, v19
	mov.16b	v13, v29
	tbz	w9, #7, LBB0_421
; %bb.420:                              ; %cond.load1520
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x9, v21[1]
	ld1.d	{ v4 }[1], [x9]
LBB0_421:                               ; %else1524
                                        ;   in Loop: Header=BB0_409 Depth=2
	sshll.2d	v18, v24, #0
	sshll.2d	v29, v26, #0
	and.16b	v0, v14, v28
	and.16b	v5, v12, v23
	and.16b	v21, v29, v25
	and.16b	v1, v18, v1
	mov.d	x9, v1[1]
	ldr	q19, [sp, #12960]               ; 16-byte Reload
	mov.d	x15, v19[1]
	sdiv	x22, x9, x15
	fmov	x9, d1
	fmov	x10, d19
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d19, x9
	mov.d	v19[1], x22
	mov.d	x9, v21[1]
	ldr	q25, [sp, #12976]               ; 16-byte Reload
	mov.d	x11, v25[1]
	sdiv	x9, x9, x11
	fmov	x12, d21
	mov.d	x6, v5[1]
	ldr	q23, [sp, #12992]               ; 16-byte Reload
	mov.d	x19, v23[1]
	fmov	x23, d25
	sdiv	x20, x6, x19
	fmov	x6, d5
	fmov	x24, d23
	mov.d	x7, v0[1]
	sdiv	x21, x6, x24
	ldr	q23, [sp, #13008]               ; 16-byte Reload
	mov.d	x25, v23[1]
	sdiv	x6, x7, x25
	fmov	x7, d0
	fmov	x26, d23
	sdiv	x7, x7, x26
	mul	x25, x6, x25
	mul	x26, x7, x26
	fmov	d23, x26
	mov.d	v23[1], x25
	mul	x19, x20, x19
	mul	x24, x21, x24
	fmov	d25, x24
	mov.d	v25[1], x19
	mul	x11, x9, x11
	sdiv	x19, x12, x23
	mul	x12, x19, x23
	fmov	d28, x12
	mov.d	v28[1], x11
	mul	x11, x22, x15
	fmov	d30, x10
	mov.d	v30[1], x11
	sub.2d	v1, v1, v30
	sub.2d	v21, v21, v28
	sub.2d	v28, v5, v25
	sub.2d	v14, v0, v23
	ldr	q0, [sp, #13040]                ; 16-byte Reload
	cmeq.2d	v0, v0, v14
	ldr	q5, [sp, #13056]                ; 16-byte Reload
	cmeq.2d	v5, v5, v21
	uzp1.4s	v0, v5, v0
	ldr	q5, [sp, #13072]                ; 16-byte Reload
	cmeq.2d	v5, v5, v28
	ldr	q23, [sp, #13104]               ; 16-byte Reload
	cmeq.2d	v23, v23, v1
	uzp1.4s	v5, v23, v5
	uzp1.8h	v11, v5, v0
	and.16b	v0, v31, v11
	xtn.8b	v30, v0
	shl.8b	v0, v30, #7
	cmlt.8b	v0, v0, #0
	ldr	d5, [sp, #13320]                ; 8-byte Reload
	and.8b	v0, v0, v5
	addv.8b	b0, v0
	fmov	w15, s0
	shl.2d	v0, v19, #6
	ldr	q3, [sp, #6320]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #6256]                 ; 16-byte Reload
	add.2d	v23, v3, v0
	tbz	w15, #0, LBB0_427
; %bb.422:                              ; %cond.load1527
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d23
	ldr	d8, [x10]
	movi.2d	v9, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v0, #0000000000000000
	ldr	x26, [sp, #11632]               ; 8-byte Reload
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	tbnz	w15, #1, LBB0_428
	b	LBB0_429
LBB0_423:                               ; %cond.load1490
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d25
	ld1.d	{ v7 }[0], [x10]
	tbz	w9, #3, LBB0_415
LBB0_424:                               ; %cond.load1496
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x10, v25[1]
	ld1.d	{ v7 }[1], [x10]
	shl.2d	v19, v23, #6
	ldr	q3, [sp, #9056]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9120]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w9, #4, LBB0_416
LBB0_425:                               ; %cond.load1502
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d23
	ld1.d	{ v6 }[0], [x10]
	tbz	w9, #5, LBB0_417
LBB0_426:                               ; %cond.load1508
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v6 }[1], [x10]
	shl.2d	v19, v21, #6
	ldr	q3, [sp, #9040]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #9104]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbnz	w9, #6, LBB0_418
	b	LBB0_419
LBB0_427:                               ;   in Loop: Header=BB0_409 Depth=2
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v0, #0000000000000000
	ldr	x26, [sp, #11632]               ; 8-byte Reload
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	tbz	w15, #1, LBB0_429
LBB0_428:                               ; %cond.load1533
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v8 }[1], [x10]
LBB0_429:                               ; %else1537
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	d19, x21
	mov.d	v19[1], x20
	shl.2d	v19, v19, #6
	ldr	q3, [sp, #6304]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6240]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w15, #2, LBB0_431
; %bb.430:                              ; %cond.load1539
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d23
	ld1.d	{ v9 }[0], [x10]
LBB0_431:                               ; %else1543
                                        ;   in Loop: Header=BB0_409 Depth=2
	tbz	w15, #3, LBB0_433
; %bb.432:                              ; %cond.load1545
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x10, v23[1]
	ld1.d	{ v9 }[1], [x10]
LBB0_433:                               ; %else1549
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	d19, x19
	mov.d	v19[1], x9
	shl.2d	v19, v19, #6
	ldr	q3, [sp, #6288]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6352]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w15, #4, LBB0_435
; %bb.434:                              ; %cond.load1551
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x9, d23
	ld1.d	{ v5 }[0], [x9]
LBB0_435:                               ; %else1555
                                        ;   in Loop: Header=BB0_409 Depth=2
	tbz	w15, #5, LBB0_437
; %bb.436:                              ; %cond.load1557
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x9, v23[1]
	ld1.d	{ v5 }[1], [x9]
LBB0_437:                               ; %else1561
                                        ;   in Loop: Header=BB0_409 Depth=2
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmge.2d	v19, v10, v3
	ldr	q23, [sp, #13088]               ; 16-byte Reload
	cmge.2d	v23, v22, v23
	ldr	q22, [sp, #13152]               ; 16-byte Reload
	cmge.2d	v25, v16, v22
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	mov.16b	v16, v3
	cmge.2d	v31, v15, v3
	uzp1.4s	v19, v23, v19
	uzp1.4s	v23, v31, v25
	uzp1.8h	v19, v23, v19
	ldr	q31, [sp, #13328]               ; 16-byte Reload
	and.16b	v19, v31, v19
	xtn.8b	v25, v19
	fmov	d19, x7
	mov.d	v19[1], x6
	shl.2d	v19, v19, #6
	ldr	q3, [sp, #6272]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6336]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w15, #6, LBB0_439
; %bb.438:                              ; %cond.load1563
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x9, d23
	ld1.d	{ v0 }[0], [x9]
LBB0_439:                               ; %else1567
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov	b19, v2[0]
	mov.b	v19[4], v2[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q3, [sp, #10720]                ; 16-byte Reload
	mov.16b	v12, v19
	bsl.16b	v12, v17, v3
	mov	b19, v2[2]
	mov.b	v19[4], v2[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q3, [sp, #10736]                ; 16-byte Reload
	bif.16b	v7, v3, v19
	mov	b19, v2[4]
	mov.b	v19[4], v2[5]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q3, [sp, #10768]                ; 16-byte Reload
	bif.16b	v6, v3, v19
	mov	b19, v2[6]
	mov.b	v19[4], v2[7]
	ushll.2d	v2, v19, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	ldr	q3, [sp, #10784]                ; 16-byte Reload
	bsl.16b	v2, v4, v3
	mov	b4, v25[6]
	mov.b	v4[4], v25[7]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmge.2d	v4, v4, #0
	and.16b	v2, v4, v2
	str	q2, [sp, #10784]                ; 16-byte Spill
	mov	b2, v25[4]
	mov.b	v2[4], v25[5]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	mov	b4, v25[2]
	mov.b	v4[4], v25[3]
	and.16b	v2, v2, v6
	str	q2, [sp, #10768]                ; 16-byte Spill
	ushll.2d	v2, v4, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	and.16b	v2, v2, v7
	str	q2, [sp, #10736]                ; 16-byte Spill
	mov	b2, v25[0]
	mov.b	v2[4], v25[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmge.2d	v2, v2, #0
	and.16b	v2, v2, v12
	str	q2, [sp, #10720]                ; 16-byte Spill
	ldr	q2, [sp, #13024]                ; 16-byte Reload
	ldr	q3, [sp, #10800]                ; 16-byte Reload
	bit.16b	v3, v14, v2
	str	q3, [sp, #10800]                ; 16-byte Spill
	mov.16b	v14, v2
	ldr	q12, [sp, #12864]               ; 16-byte Reload
	ldr	q2, [sp, #10832]                ; 16-byte Reload
	bit.16b	v2, v28, v12
	str	q2, [sp, #10832]                ; 16-byte Spill
	ldr	q2, [sp, #10816]                ; 16-byte Reload
	bit.16b	v2, v21, v29
	str	q2, [sp, #10816]                ; 16-byte Spill
	ldr	q2, [sp, #10848]                ; 16-byte Reload
	bit.16b	v2, v1, v18
	str	q2, [sp, #10848]                ; 16-byte Spill
	bic.16b	v1, v31, v11
	xtn.8b	v1, v1
	tbz	w15, #7, LBB0_441
; %bb.440:                              ; %cond.load1569
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x9, v23[1]
	ld1.d	{ v0 }[1], [x9]
LBB0_441:                               ; %else1573
                                        ;   in Loop: Header=BB0_409 Depth=2
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	mov.16b	v29, v13
	ldr	q7, [sp, #8864]                 ; 16-byte Reload
	ldr	q18, [sp, #8848]                ; 16-byte Reload
	ldr	q19, [sp, #8832]                ; 16-byte Reload
	ldr	q25, [sp, #4704]                ; 16-byte Reload
	mov.16b	v31, v16
	mov	b2, v30[6]
	mov.b	v2[4], v30[7]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	mov	b4, v30[4]
	mov.b	v4[4], v30[5]
	ldr	q3, [sp, #7184]                 ; 16-byte Reload
	bif.16b	v0, v3, v2
	ushll.2d	v2, v4, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	ldr	q3, [sp, #7232]                 ; 16-byte Reload
	bsl.16b	v2, v5, v3
	mov	b4, v30[2]
	mov.b	v4[4], v30[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	ldr	q3, [sp, #7456]                 ; 16-byte Reload
	bsl.16b	v4, v9, v3
	mov	b5, v30[0]
	mov.b	v5[4], v30[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q3, [sp, #7632]                 ; 16-byte Reload
	bsl.16b	v5, v8, v3
	mov	b6, v1[0]
	mov.b	v6[4], v1[1]
	ushll.2d	v6, v6, #0
	shl.2d	v6, v6, #63
	cmge.2d	v6, v6, #0
	and.16b	v6, v6, v5
	mov	b5, v1[2]
	mov.b	v5[4], v1[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v21, v5, v4
	mov	b4, v1[4]
	mov.b	v4[4], v1[5]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmge.2d	v4, v4, #0
	mov	b5, v1[6]
	mov.b	v5[4], v1[7]
	and.16b	v22, v4, v2
	ushll.2d	v1, v5, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v5, v1, v0
	ldr	q0, [sp, #10800]                ; 16-byte Reload
	xtn.2s	v0, v0
	ldr	q1, [sp, #10816]                ; 16-byte Reload
	xtn.2s	v1, v1
	ldr	q2, [sp, #10832]                ; 16-byte Reload
	xtn.2s	v2, v2
	ldr	q3, [sp, #10848]                ; 16-byte Reload
	xtn.2s	v4, v3
	mov.s	w10, v4[1]
	fmov	w9, s4
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w11, lo
	and	x12, x9, #0x7
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #968
	bfxil	x15, x9, #0, #3
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	str	d8, [sp, #17352]
	ldrb	w9, [x15]
	and	w9, w16, w9
	str	q5, [x13, #3920]
	str	q22, [x13, #3904]
	str	q21, [x13, #3888]
	str	q6, [x13, #3872]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #976
	ldr	x12, [x15, x12, lsl #3]
	tst	w11, w9
	csel	x9, x12, xzr, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	and	x12, x10, #0x7
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #968
	bfxil	x15, x10, #0, #3
	ldrb	w10, [x15]
	str	q5, [x13, #3984]
	str	q22, [x13, #3968]
	str	q21, [x13, #3952]
	str	q6, [x13, #3936]
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1040
	ldr	x12, [x15, x12, lsl #3]
	and	w10, w17, w10
	tst	w11, w10
	csel	x15, x12, xzr, ne
	mov.s	w10, v2[1]
	fmov	w11, s2
	cmp	w11, #8
	csel	w11, w11, wzr, lo
	cset	w12, lo
	and	x6, x11, #0x7
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #968
	bfxil	x7, x11, #0, #3
	ldrb	w11, [x7]
	and	w11, w0, w11
	str	q5, [x13, #4048]
	str	q22, [x13, #4032]
	str	q21, [x13, #4016]
	str	q6, [x13, #4000]
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #1104
	ldr	x6, [x7, x6, lsl #3]
	tst	w12, w11
	csel	x6, x6, xzr, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	and	x12, x10, #0x7
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #968
	bfxil	x7, x10, #0, #3
	ldrb	w10, [x7]
	and	w10, w1, w10
	str	q5, [x13, #4112]
	str	q22, [x13, #4096]
	str	q21, [x13, #4080]
	str	q6, [x13, #4064]
	add	x7, sp, #4, lsl #12             ; =16384
	add	x7, x7, #1168
	ldr	x12, [x7, x12, lsl #3]
	tst	w11, w10
	csel	x7, x12, xzr, ne
	mov.s	w10, v1[1]
	fmov	w11, s1
	cmp	w11, #8
	csel	w11, w11, wzr, lo
	cset	w12, lo
	and	x19, x11, #0x7
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #968
	bfxil	x20, x11, #0, #3
	ldrb	w11, [x20]
	str	q5, [x13, #4176]
	str	q22, [x13, #4160]
	str	q21, [x13, #4144]
	str	q6, [x13, #4128]
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #1232
	ldr	x19, [x20, x19, lsl #3]
	and	w11, w2, w11
	tst	w12, w11
	csel	x19, x19, xzr, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	and	x12, x10, #0x7
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #968
	bfxil	x20, x10, #0, #3
	ldrb	w10, [x20]
	and	w10, w3, w10
	str	q5, [x13, #4240]
	str	q22, [x13, #4224]
	str	q21, [x13, #4208]
	str	q6, [x13, #4192]
	add	x20, sp, #4, lsl #12            ; =16384
	add	x20, x20, #1296
	ldr	x12, [x20, x12, lsl #3]
	tst	w11, w10
	csel	x20, x12, xzr, ne
	mov.s	w10, v0[1]
	fmov	w11, s0
	cmp	w11, #8
	csel	w11, w11, wzr, lo
	cset	w12, lo
	and	x21, x11, #0x7
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #968
	bfxil	x22, x11, #0, #3
	ldrb	w11, [x22]
	and	w11, w4, w11
	str	q5, [x13, #4304]
	str	q22, [x13, #4288]
	str	q21, [x13, #4272]
	str	q6, [x13, #4256]
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #1360
	ldr	x21, [x22, x21, lsl #3]
	tst	w12, w11
	csel	x11, x21, xzr, ne
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w12, lo
	and	x21, x10, #0x7
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #968
	bfxil	x22, x10, #0, #3
	ldrb	w10, [x22]
	and	w10, w5, w10
	str	q5, [sp, #7184]                 ; 16-byte Spill
	str	q5, [x13, #4368]
	str	q22, [sp, #7232]                ; 16-byte Spill
	str	q22, [x13, #4352]
	str	q21, [sp, #7456]                ; 16-byte Spill
	str	q21, [x13, #4336]
	str	q6, [sp, #7632]                 ; 16-byte Spill
	str	q6, [x13, #4320]
	add	x22, sp, #4, lsl #12            ; =16384
	add	x22, x22, #1424
	ldr	x21, [x22, x21, lsl #3]
	tst	w12, w10
	csel	x10, x21, xzr, ne
	fmov	d0, x9
	mov.d	v0[1], x15
	fmov	d2, x6
	mov.d	v2[1], x7
	fmov	d4, x19
	mov.d	v4[1], x20
	fmov	d5, x11
	mov.d	v5[1], x10
	fmov	w9, s27
	ldr	q1, [sp, #8896]                 ; 16-byte Reload
	add.2d	v1, v13, v1
	ldr	q3, [sp, #8960]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	ldr	q3, [sp, #10784]                ; 16-byte Reload
	cmge.2d	v5, v5, v3
	ldr	q3, [sp, #10768]                ; 16-byte Reload
	cmge.2d	v4, v4, v3
	uzp1.4s	v4, v4, v5
	ldr	q3, [sp, #10736]                ; 16-byte Reload
	cmge.2d	v2, v2, v3
	ldr	q3, [sp, #10720]                ; 16-byte Reload
	cmge.2d	v0, v0, v3
	uzp1.4s	v0, v0, v2
	uzp1.8h	v0, v0, v4
	xtn.8b	v0, v0
	movi.8b	v2, #1
	and.8b	v0, v0, v2
	tbnz	w9, #0, LBB0_449
; %bb.442:                              ; %else1579
                                        ;   in Loop: Header=BB0_409 Depth=2
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	tbnz	w9, #1, LBB0_450
LBB0_443:                               ; %else1583
                                        ;   in Loop: Header=BB0_409 Depth=2
	ldr	q1, [sp, #8880]                 ; 16-byte Reload
	add.2d	v1, v7, v1
	ldr	q2, [sp, #8944]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #2, LBB0_451
LBB0_444:                               ; %else1587
                                        ;   in Loop: Header=BB0_409 Depth=2
	tbnz	w9, #3, LBB0_452
LBB0_445:                               ; %else1591
                                        ;   in Loop: Header=BB0_409 Depth=2
	ldr	q1, [sp, #8992]                 ; 16-byte Reload
	add.2d	v1, v18, v1
	ldr	q2, [sp, #8928]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_453
LBB0_446:                               ; %else1595
                                        ;   in Loop: Header=BB0_409 Depth=2
	tbnz	w9, #5, LBB0_454
LBB0_447:                               ; %else1599
                                        ;   in Loop: Header=BB0_409 Depth=2
	ldr	q1, [sp, #8976]                 ; 16-byte Reload
	add.2d	v1, v19, v1
	ldr	q2, [sp, #8912]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_455
LBB0_448:                               ; %else1603
                                        ;   in Loop: Header=BB0_409 Depth=2
	tbz	w9, #7, LBB0_408
	b	LBB0_456
LBB0_449:                               ; %cond.store1576
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d1
	str	b0, [x10]
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	tbz	w9, #1, LBB0_443
LBB0_450:                               ; %cond.store1580
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[1], [x10]
	ldr	q1, [sp, #8880]                 ; 16-byte Reload
	add.2d	v1, v7, v1
	ldr	q2, [sp, #8944]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #2, LBB0_444
LBB0_451:                               ; %cond.store1584
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[2], [x10]
	tbz	w9, #3, LBB0_445
LBB0_452:                               ; %cond.store1588
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[3], [x10]
	ldr	q1, [sp, #8992]                 ; 16-byte Reload
	add.2d	v1, v18, v1
	ldr	q2, [sp, #8928]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #4, LBB0_446
LBB0_453:                               ; %cond.store1592
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[4], [x10]
	tbz	w9, #5, LBB0_447
LBB0_454:                               ; %cond.store1596
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[5], [x10]
	ldr	q1, [sp, #8976]                 ; 16-byte Reload
	add.2d	v1, v19, v1
	ldr	q2, [sp, #8912]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_448
LBB0_455:                               ; %cond.store1600
                                        ;   in Loop: Header=BB0_409 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[6], [x10]
	tbz	w9, #7, LBB0_408
LBB0_456:                               ; %cond.store1604
                                        ;   in Loop: Header=BB0_409 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[7], [x9]
	b	LBB0_408
LBB0_457:                               ; %else1738
                                        ;   in Loop: Header=BB0_458 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v2, v2, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v1, v15, v0
	add.2d	v25, v25, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v30, v30, v0
	fmov	x9, d30
	cmp	x9, #10
	b.ge	LBB0_356
LBB0_458:                               ; %direct.true550
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v16, v8
	sshll.2d	v0, v26, #0
	sshll.2d	v29, v24, #0
	mov.16b	v10, v30
	and.16b	v30, v29, v30
	mov.16b	v13, v2
	and.16b	v18, v12, v2
	mov.16b	v15, v1
	and.16b	v1, v0, v1
	mov.16b	v22, v25
	and.16b	v2, v14, v25
	fmov	x9, d2
	ldr	q4, [sp, #11664]                ; 16-byte Reload
	fmov	x15, d4
	sdiv	x6, x9, x15
	fmov	d4, x6
	mov.d	x9, v2[1]
	sdiv	x7, x9, x27
	mov.d	v4[1], x7
	fmov	x9, d1
	ldr	q5, [sp, #11696]                ; 16-byte Reload
	fmov	x19, d5
	sdiv	x20, x9, x19
	fmov	d5, x20
	mov.d	x9, v1[1]
	sdiv	x21, x9, x26
	mov.d	v5[1], x21
	fmov	x9, d18
	ldr	q6, [sp, #11680]                ; 16-byte Reload
	fmov	x22, d6
	sdiv	x23, x9, x22
	fmov	d6, x23
	mov.d	x9, v18[1]
	sdiv	x24, x9, x25
	mov.d	v6[1], x24
	fmov	x10, d30
	ldr	q7, [sp, #11712]                ; 16-byte Reload
	fmov	x9, d7
	sdiv	x25, x10, x9
	fmov	d7, x25
	mov.d	x10, v30[1]
	ldr	x11, [sp, #11736]               ; 8-byte Reload
	sdiv	x26, x10, x11
	mov.d	v7[1], x26
	and.16b	v4, v14, v4
	mov.d	x10, v4[1]
	and.16b	v5, v0, v5
	sdiv	x11, x10, x14
	msub	x10, x11, x14, x10
	fmov	x11, d4
	ldr	q4, [sp, #13216]                ; 16-byte Reload
	fmov	x12, d4
	sdiv	x27, x11, x12
	msub	x11, x27, x12, x11
	fmov	d4, x11
	mov.d	v4[1], x10
	mov.d	x10, v5[1]
	and.16b	v6, v12, v6
	sdiv	x11, x10, x8
	msub	x10, x11, x8, x10
	fmov	x11, d5
	ldr	q5, [sp, #13184]                ; 16-byte Reload
	fmov	x12, d5
	sdiv	x27, x11, x12
	msub	x11, x27, x12, x11
	fmov	d28, x11
	mov.d	v28[1], x10
	mov.d	x10, v6[1]
	and.16b	v5, v29, v7
	sdiv	x11, x10, x30
	msub	x10, x11, x30, x10
	fmov	x11, d6
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x27, x11, x12
	msub	x11, x27, x12, x11
	fmov	d8, x11
	mov.d	v8[1], x10
	mov.d	x10, v5[1]
	sdiv	x11, x10, x28
	msub	x10, x11, x28, x10
	fmov	x11, d5
	ldr	q5, [sp, #13168]                ; 16-byte Reload
	fmov	x12, d5
	sdiv	x27, x11, x12
	msub	x11, x27, x12, x11
	fmov	d23, x11
	mov.d	v23[1], x10
	shl.2d	v5, v23, #3
	shl.2d	v6, v8, #3
	shl.2d	v7, v28, #3
	shl.2d	v19, v4, #3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v19, v3, v19
	cmgt.2d	v7, v9, v7
	uzp1.4s	v7, v7, v19
	ldr	q19, [sp, #13152]               ; 16-byte Reload
	cmgt.2d	v6, v19, v6
	cmgt.2d	v5, v31, v5
	uzp1.4s	v5, v5, v6
	uzp1.8h	v7, v5, v7
	ldr	q5, [sp, #13328]                ; 16-byte Reload
	and.16b	v5, v5, v7
	xtn.8b	v5, v5
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	ldr	d6, [sp, #13320]                ; 8-byte Reload
	and.8b	v6, v5, v6
	addv.8b	b6, v6
	fmov	w27, s6
	ldr	q3, [sp, #9376]                 ; 16-byte Reload
	ldr	q19, [sp, #9312]                ; 16-byte Reload
	add.2d	v19, v19, v3
	add.2d	v25, v19, v23
	tbz	w27, #0, LBB0_460
; %bb.459:                              ; %cond.load1609
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d25
	ldr	b21, [x10]
	tbnz	w27, #1, LBB0_461
	b	LBB0_462
LBB0_460:                               ;   in Loop: Header=BB0_458 Depth=2
	movi.2d	v21, #0000000000000000
	tbz	w27, #1, LBB0_462
LBB0_461:                               ; %cond.load1615
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v25[1]
	ld1.b	{ v21 }[1], [x10]
LBB0_462:                               ; %else1619
                                        ;   in Loop: Header=BB0_458 Depth=2
	ldr	q3, [sp, #9360]                 ; 16-byte Reload
	ldr	q19, [sp, #9296]                ; 16-byte Reload
	add.2d	v19, v19, v3
	add.2d	v25, v19, v8
	tbnz	w27, #2, LBB0_471
; %bb.463:                              ; %else1625
                                        ;   in Loop: Header=BB0_458 Depth=2
	tbnz	w27, #3, LBB0_472
LBB0_464:                               ; %else1631
                                        ;   in Loop: Header=BB0_458 Depth=2
	ldr	q3, [sp, #9344]                 ; 16-byte Reload
	ldr	q19, [sp, #9280]                ; 16-byte Reload
	add.2d	v19, v19, v3
	add.2d	v25, v19, v28
	tbnz	w27, #4, LBB0_473
LBB0_465:                               ; %else1637
                                        ;   in Loop: Header=BB0_458 Depth=2
	tbnz	w27, #5, LBB0_474
LBB0_466:                               ; %else1643
                                        ;   in Loop: Header=BB0_458 Depth=2
	ldr	q3, [sp, #9328]                 ; 16-byte Reload
	ldr	q19, [sp, #9264]                ; 16-byte Reload
	add.2d	v19, v19, v3
	add.2d	v25, v19, v4
	tbnz	w27, #6, LBB0_475
LBB0_467:                               ; %else1649
                                        ;   in Loop: Header=BB0_458 Depth=2
	tbz	w27, #7, LBB0_469
LBB0_468:                               ; %cond.load1651
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v25[1]
	ld1.b	{ v21 }[7], [x10]
LBB0_469:                               ; %else1655
                                        ;   in Loop: Header=BB0_458 Depth=2
	ldr	x10, [sp, #11736]               ; 8-byte Reload
	mul	x10, x26, x10
	mul	x9, x25, x9
	fmov	d19, x9
	mov.d	v19[1], x10
	sub.2d	v19, v30, v19
	ldr	q25, [sp, #7552]                ; 16-byte Reload
	bit.16b	v25, v19, v29
	ldr	q3, [sp, #7616]                 ; 16-byte Reload
	bit.16b	v3, v23, v29
	str	q3, [sp, #7616]                 ; 16-byte Spill
	add.2d	v19, v3, v3
	fmov	w9, s6
	ldr	q3, [sp, #8896]                 ; 16-byte Reload
	str	q25, [sp, #7552]                ; 16-byte Spill
	add.2d	v23, v25, v3
	ldr	q3, [sp, #8960]                 ; 16-byte Reload
	add.2d	v23, v3, v23
	add.2d	v25, v23, v19
	ldr	x27, [sp, #11400]               ; 8-byte Reload
	tbz	w9, #0, LBB0_476
; %bb.470:                              ; %cond.load1658
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d25
	ldr	b23, [x10]
	ldr	x26, [sp, #11632]               ; 8-byte Reload
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	mov.16b	v30, v10
	tbnz	w9, #1, LBB0_477
	b	LBB0_478
LBB0_471:                               ; %cond.load1621
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d25
	ld1.b	{ v21 }[2], [x10]
	tbz	w27, #3, LBB0_464
LBB0_472:                               ; %cond.load1627
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v25[1]
	ld1.b	{ v21 }[3], [x10]
	ldr	q3, [sp, #9344]                 ; 16-byte Reload
	ldr	q19, [sp, #9280]                ; 16-byte Reload
	add.2d	v19, v19, v3
	add.2d	v25, v19, v28
	tbz	w27, #4, LBB0_465
LBB0_473:                               ; %cond.load1633
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d25
	ld1.b	{ v21 }[4], [x10]
	tbz	w27, #5, LBB0_466
LBB0_474:                               ; %cond.load1639
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v25[1]
	ld1.b	{ v21 }[5], [x10]
	ldr	q3, [sp, #9328]                 ; 16-byte Reload
	ldr	q19, [sp, #9264]                ; 16-byte Reload
	add.2d	v19, v19, v3
	add.2d	v25, v19, v4
	tbz	w27, #6, LBB0_467
LBB0_475:                               ; %cond.load1645
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d25
	ld1.b	{ v21 }[6], [x10]
	tbnz	w27, #7, LBB0_468
	b	LBB0_469
LBB0_476:                               ;   in Loop: Header=BB0_458 Depth=2
	movi.2d	v23, #0000000000000000
	ldr	x26, [sp, #11632]               ; 8-byte Reload
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	mov.16b	v30, v10
	tbz	w9, #1, LBB0_478
LBB0_477:                               ; %cond.load1664
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v25[1]
	ld1.b	{ v23 }[1], [x10]
LBB0_478:                               ; %else1668
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.16b	v25, v22
	mul	x10, x24, x25
	mul	x11, x23, x22
	fmov	d19, x11
	mov.d	v19[1], x10
	sub.2d	v18, v18, v19
	ldr	q19, [sp, #7536]                ; 16-byte Reload
	bit.16b	v19, v18, v12
	ldr	q3, [sp, #7600]                 ; 16-byte Reload
	bit.16b	v3, v8, v12
	str	q3, [sp, #7600]                 ; 16-byte Spill
	add.2d	v18, v3, v3
	ldr	q3, [sp, #8880]                 ; 16-byte Reload
	str	q19, [sp, #7536]                ; 16-byte Spill
	add.2d	v19, v19, v3
	ldr	q3, [sp, #8944]                 ; 16-byte Reload
	add.2d	v19, v3, v19
	add.2d	v18, v19, v18
	tbz	w9, #2, LBB0_480
; %bb.479:                              ; %cond.load1670
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d18
	ld1.b	{ v23 }[2], [x10]
LBB0_480:                               ; %else1674
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.16b	v8, v16
	tbz	w9, #3, LBB0_482
; %bb.481:                              ; %cond.load1676
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v18[1]
	ld1.b	{ v23 }[3], [x10]
LBB0_482:                               ; %else1680
                                        ;   in Loop: Header=BB0_458 Depth=2
	mul	x10, x21, x26
	mul	x11, x20, x19
	fmov	d18, x11
	mov.d	v18[1], x10
	sub.2d	v1, v1, v18
	ldr	q3, [sp, #7664]                 ; 16-byte Reload
	bit.16b	v3, v1, v0
	ldr	q1, [sp, #7584]                 ; 16-byte Reload
	bit.16b	v1, v28, v0
	str	q1, [sp, #7584]                 ; 16-byte Spill
	add.2d	v0, v1, v1
	ldr	q1, [sp, #8992]                 ; 16-byte Reload
	str	q3, [sp, #7664]                 ; 16-byte Spill
	add.2d	v1, v3, v1
	ldr	q3, [sp, #8928]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	add.2d	v0, v1, v0
	tbz	w9, #4, LBB0_484
; %bb.483:                              ; %cond.load1682
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d0
	ld1.b	{ v23 }[4], [x10]
LBB0_484:                               ; %else1686
                                        ;   in Loop: Header=BB0_458 Depth=2
	tbz	w9, #5, LBB0_486
; %bb.485:                              ; %cond.load1688
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v0[1]
	ld1.b	{ v23 }[5], [x10]
LBB0_486:                               ; %else1692
                                        ;   in Loop: Header=BB0_458 Depth=2
	mul	x10, x7, x27
	mul	x11, x6, x15
	fmov	d0, x11
	mov.d	v0[1], x10
	sub.2d	v0, v2, v0
	ldr	q2, [sp, #7648]                 ; 16-byte Reload
	bit.16b	v2, v0, v14
	ldr	q0, [sp, #7568]                 ; 16-byte Reload
	bit.16b	v0, v4, v14
	str	q0, [sp, #7568]                 ; 16-byte Spill
	add.2d	v0, v0, v0
	ldr	q1, [sp, #8976]                 ; 16-byte Reload
	str	q2, [sp, #7648]                 ; 16-byte Spill
	add.2d	v1, v2, v1
	ldr	q2, [sp, #8912]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	add.2d	v0, v1, v0
	tbz	w9, #6, LBB0_488
; %bb.487:                              ; %cond.load1694
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d0
	ld1.b	{ v23 }[6], [x10]
LBB0_488:                               ; %else1698
                                        ;   in Loop: Header=BB0_458 Depth=2
	tbz	w9, #7, LBB0_490
; %bb.489:                              ; %cond.load1700
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x9, v0[1]
	ld1.b	{ v23 }[7], [x9]
LBB0_490:                               ; %else1704
                                        ;   in Loop: Header=BB0_458 Depth=2
	xtn.8b	v0, v7
	cmtst.8b	v1, v21, v21
	ldr	q2, [sp, #7520]                 ; 16-byte Reload
	bif.8b	v1, v2, v5
	ldr	d4, [sp, #11616]                ; 8-byte Reload
	orr.8b	v2, v0, v4
	and.8b	v2, v2, v1
	cmtst.8b	v1, v23, v23
	ldr	q3, [sp, #7504]                 ; 16-byte Reload
	bif.8b	v1, v3, v5
	fmov	w9, s6
	orr.8b	v0, v4, v0
	and.8b	v0, v0, v1
	str	q2, [sp, #7520]                 ; 16-byte Spill
	str	q0, [sp, #7504]                 ; 16-byte Spill
	and.8b	v0, v2, v0
	ldr	q1, [sp, #11104]                ; 16-byte Reload
	add.2d	v1, v30, v1
	ldr	q2, [sp, #11168]                ; 16-byte Reload
	add.2d	v1, v2, v1
	movi.8b	v2, #1
	and.8b	v0, v0, v2
	tbnz	w9, #0, LBB0_498
; %bb.491:                              ; %else1710
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.16b	v2, v13
	tbnz	w9, #1, LBB0_499
LBB0_492:                               ; %else1714
                                        ;   in Loop: Header=BB0_458 Depth=2
	ldr	q1, [sp, #11088]                ; 16-byte Reload
	add.2d	v1, v2, v1
	ldr	q2, [sp, #11152]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #2, LBB0_500
LBB0_493:                               ; %else1718
                                        ;   in Loop: Header=BB0_458 Depth=2
	tbnz	w9, #3, LBB0_501
LBB0_494:                               ; %else1722
                                        ;   in Loop: Header=BB0_458 Depth=2
	ldr	q1, [sp, #11200]                ; 16-byte Reload
	add.2d	v1, v15, v1
	ldr	q2, [sp, #11136]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_502
LBB0_495:                               ; %else1726
                                        ;   in Loop: Header=BB0_458 Depth=2
	tbnz	w9, #5, LBB0_503
LBB0_496:                               ; %else1730
                                        ;   in Loop: Header=BB0_458 Depth=2
	ldr	q1, [sp, #11184]                ; 16-byte Reload
	add.2d	v1, v25, v1
	ldr	q2, [sp, #11120]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_504
LBB0_497:                               ; %else1734
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.16b	v2, v13
	tbz	w9, #7, LBB0_457
	b	LBB0_505
LBB0_498:                               ; %cond.store1707
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d1
	str	b0, [x10]
	mov.16b	v2, v13
	tbz	w9, #1, LBB0_492
LBB0_499:                               ; %cond.store1711
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[1], [x10]
	ldr	q1, [sp, #11088]                ; 16-byte Reload
	add.2d	v1, v2, v1
	ldr	q2, [sp, #11152]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #2, LBB0_493
LBB0_500:                               ; %cond.store1715
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[2], [x10]
	tbz	w9, #3, LBB0_494
LBB0_501:                               ; %cond.store1719
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[3], [x10]
	ldr	q1, [sp, #11200]                ; 16-byte Reload
	add.2d	v1, v15, v1
	ldr	q2, [sp, #11136]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #4, LBB0_495
LBB0_502:                               ; %cond.store1723
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[4], [x10]
	tbz	w9, #5, LBB0_496
LBB0_503:                               ; %cond.store1727
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x10, v1[1]
	st1.b	{ v0 }[5], [x10]
	ldr	q1, [sp, #11184]                ; 16-byte Reload
	add.2d	v1, v25, v1
	ldr	q2, [sp, #11120]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_497
LBB0_504:                               ; %cond.store1731
                                        ;   in Loop: Header=BB0_458 Depth=2
	fmov	x10, d1
	st1.b	{ v0 }[6], [x10]
	mov.16b	v2, v13
	tbz	w9, #7, LBB0_457
LBB0_505:                               ; %cond.store1735
                                        ;   in Loop: Header=BB0_458 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[7], [x9]
	b	LBB0_457
LBB0_506:                               ; %else1869
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v19, v19, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v3, v3, v0
	add.2d	v6, v6, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v18, v18, v0
	fmov	x9, d18
	cmp	x9, #10
	b.ge	LBB0_556
LBB0_507:                               ; %direct.true567
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v1, v24, #0
	sshll.2d	v2, v26, #0
	mov.16b	v10, v6
	and.16b	v4, v14, v6
	mov.16b	v15, v19
	and.16b	v5, v12, v19
	mov.16b	v22, v3
	and.16b	v0, v2, v3
	mov.16b	v16, v31
	mov.16b	v31, v18
	and.16b	v6, v1, v18
	fmov	x9, d6
	ldr	q7, [sp, #13168]                ; 16-byte Reload
	fmov	x10, d7
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d7, x9
	mov.d	x9, v6[1]
	sdiv	x11, x9, x28
	mov.d	v7[1], x11
	fmov	x9, d0
	ldr	q18, [sp, #13184]               ; 16-byte Reload
	fmov	x12, d18
	sdiv	x7, x9, x12
	mov.d	x6, v0[1]
	fmov	x9, d5
	ldr	q18, [sp, #13200]               ; 16-byte Reload
	fmov	x19, d18
	mov.d	x21, v5[1]
	sdiv	x20, x9, x19
	fmov	x9, d4
	ldr	q18, [sp, #13216]               ; 16-byte Reload
	fmov	x22, d18
	sdiv	x9, x9, x22
	mov.d	x15, v4[1]
	sdiv	x15, x15, x14
	mul	x23, x15, x14
	mul	x22, x9, x22
	fmov	d18, x22
	mov.d	v18[1], x23
	sdiv	x21, x21, x30
	mul	x22, x21, x30
	mul	x19, x20, x19
	fmov	d19, x19
	mov.d	v19[1], x22
	sdiv	x19, x6, x8
	mul	x6, x19, x8
	mul	x12, x7, x12
	fmov	d23, x12
	mov.d	v23[1], x6
	mul	x11, x11, x28
	fmov	d21, x10
	mov.d	v21[1], x11
	sub.2d	v21, v6, v21
	sub.2d	v0, v0, v23
	sub.2d	v5, v5, v19
	sub.2d	v18, v4, v18
	shl.2d	v4, v21, #3
	shl.2d	v6, v5, #3
	shl.2d	v19, v0, #3
	shl.2d	v23, v18, #3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v23, v3, v23
	cmgt.2d	v19, v9, v19
	uzp1.4s	v19, v19, v23
	cmgt.2d	v6, v25, v6
	cmgt.2d	v4, v16, v4
	uzp1.4s	v4, v4, v6
	uzp1.8h	v28, v4, v19
	ldr	q4, [sp, #13328]                ; 16-byte Reload
	and.16b	v4, v4, v28
	xtn.8b	v4, v4
	and.16b	v6, v1, v7
	mov.d	x10, v6[1]
	ldr	x12, [sp, #11736]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	x11, d6
	ldr	q6, [sp, #11712]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x6, x11, x12
	msub	x11, x6, x12, x11
	fmov	d30, x11
	mov.d	v30[1], x10
	shl.8b	v6, v4, #7
	cmlt.8b	v6, v6, #0
	ldr	d7, [sp, #13320]                ; 8-byte Reload
	and.8b	v7, v6, v7
	addv.8b	b7, v7
	fmov	w6, s7
	add.2d	v7, v21, v21
	ldr	q3, [sp, #11104]                ; 16-byte Reload
	add.2d	v7, v7, v3
	ldr	q3, [sp, #11168]                ; 16-byte Reload
	add.2d	v7, v3, v7
	add.2d	v23, v7, v30
	tbz	w6, #0, LBB0_509
; %bb.508:                              ; %cond.load1740
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d23
	ldr	b7, [x10]
	tbnz	w6, #1, LBB0_510
	b	LBB0_511
LBB0_509:                               ;   in Loop: Header=BB0_507 Depth=2
	movi.2d	v7, #0000000000000000
	tbz	w6, #1, LBB0_511
LBB0_510:                               ; %cond.load1746
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v23[1]
	ld1.b	{ v7 }[1], [x10]
LBB0_511:                               ; %else1750
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	d19, x20
	mov.d	v19[1], x21
	and.16b	v19, v12, v19
	mov.d	x10, v19[1]
	sdiv	x11, x10, x25
	msub	x10, x11, x25, x10
	fmov	x11, d19
	ldr	q19, [sp, #11680]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x20, x11, x12
	msub	x11, x20, x12, x11
	fmov	d29, x11
	mov.d	v29[1], x10
	add.2d	v19, v5, v5
	ldr	q3, [sp, #11088]                ; 16-byte Reload
	add.2d	v19, v19, v3
	ldr	q3, [sp, #11152]                ; 16-byte Reload
	add.2d	v19, v3, v19
	add.2d	v23, v19, v29
	tbz	w6, #2, LBB0_513
; %bb.512:                              ; %cond.load1752
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d23
	ld1.b	{ v7 }[2], [x10]
LBB0_513:                               ; %else1756
                                        ;   in Loop: Header=BB0_507 Depth=2
	tbz	w6, #3, LBB0_515
; %bb.514:                              ; %cond.load1758
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v23[1]
	ld1.b	{ v7 }[3], [x10]
LBB0_515:                               ; %else1762
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	d19, x7
	mov.d	v19[1], x19
	and.16b	v19, v2, v19
	mov.d	x10, v19[1]
	sdiv	x11, x10, x26
	msub	x10, x11, x26, x10
	fmov	x11, d19
	ldr	q19, [sp, #11696]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x7, x11, x12
	msub	x11, x7, x12, x11
	fmov	d8, x11
	mov.d	v8[1], x10
	add.2d	v19, v0, v0
	ldr	q3, [sp, #11200]                ; 16-byte Reload
	add.2d	v19, v19, v3
	ldr	q3, [sp, #11136]                ; 16-byte Reload
	add.2d	v19, v3, v19
	add.2d	v23, v19, v8
	tbz	w6, #4, LBB0_517
; %bb.516:                              ; %cond.load1764
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d23
	ld1.b	{ v7 }[4], [x10]
LBB0_517:                               ; %else1768
                                        ;   in Loop: Header=BB0_507 Depth=2
	tbz	w6, #5, LBB0_519
; %bb.518:                              ; %cond.load1770
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v23[1]
	ld1.b	{ v7 }[5], [x10]
LBB0_519:                               ; %else1774
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	d19, x9
	mov.d	v19[1], x15
	and.16b	v19, v14, v19
	mov.d	x9, v19[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d19
	ldr	q19, [sp, #11664]               ; 16-byte Reload
	fmov	x11, d19
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d9, x10
	mov.d	v9[1], x9
	add.2d	v19, v18, v18
	ldr	q3, [sp, #11184]                ; 16-byte Reload
	add.2d	v19, v19, v3
	ldr	q3, [sp, #11120]                ; 16-byte Reload
	add.2d	v19, v3, v19
	add.2d	v23, v19, v9
	tbz	w6, #6, LBB0_521
; %bb.520:                              ; %cond.load1776
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x9, d23
	ld1.b	{ v7 }[6], [x9]
LBB0_521:                               ; %else1780
                                        ;   in Loop: Header=BB0_507 Depth=2
	tbz	w6, #7, LBB0_523
; %bb.522:                              ; %cond.load1782
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x9, v23[1]
	ld1.b	{ v7 }[7], [x9]
LBB0_523:                               ; %else1786
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	q3, [sp, #7488]                 ; 16-byte Reload
	bit.16b	v3, v21, v1
	ldr	q19, [sp, #7408]                ; 16-byte Reload
	bit.16b	v19, v30, v1
	xtn.8b	v28, v28
	fmov	x9, d19
	add	x9, x9, x9, lsl #2
	fmov	d1, x9
	str	q19, [sp, #7408]                ; 16-byte Spill
	mov.d	x9, v19[1]
	add	x9, x9, x9, lsl #2
	mov.d	v1[1], x9
	str	q3, [sp, #7488]                 ; 16-byte Spill
	add.2d	v19, v1, v3
	ldr	q1, [sp, #13136]                ; 16-byte Reload
	and.8b	v1, v1, v28
	shl.8b	v21, v1, #7
	cmlt.8b	v21, v21, #0
	ldr	d23, [sp, #13320]               ; 8-byte Reload
	and.8b	v21, v21, v23
	addv.8b	b30, v21
	fmov	w9, s30
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #9760]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q21, [sp, #9696]                ; 16-byte Reload
	add.2d	v23, v21, v19
	movi.2d	v11, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w9, #0, LBB0_525
; %bb.524:                              ; %cond.load1789
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d23
	ldr	s11, [x10]
LBB0_525:                               ; %else1793
                                        ;   in Loop: Header=BB0_507 Depth=2
	tbz	w9, #1, LBB0_527
; %bb.526:                              ; %cond.load1795
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v11 }[1], [x10]
LBB0_527:                               ; %else1799
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	q3, [sp, #7472]                 ; 16-byte Reload
	bit.16b	v3, v5, v12
	ldr	q19, [sp, #7392]                ; 16-byte Reload
	bit.16b	v19, v29, v12
	fmov	x10, d19
	add	x10, x10, x10, lsl #2
	fmov	d5, x10
	str	q19, [sp, #7392]                ; 16-byte Spill
	mov.d	x10, v19[1]
	add	x10, x10, x10, lsl #2
	mov.d	v5[1], x10
	str	q3, [sp, #7472]                 ; 16-byte Spill
	add.2d	v5, v5, v3
	shl.2d	v5, v5, #5
	ldr	q19, [sp, #9744]                ; 16-byte Reload
	orr.16b	v5, v5, v19
	ldr	q19, [sp, #9680]                ; 16-byte Reload
	add.2d	v5, v19, v5
	tbz	w9, #2, LBB0_529
; %bb.528:                              ; %cond.load1801
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d5
	ld1.s	{ v11 }[2], [x10]
LBB0_529:                               ; %else1805
                                        ;   in Loop: Header=BB0_507 Depth=2
	tbz	w9, #3, LBB0_531
; %bb.530:                              ; %cond.load1807
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v11 }[3], [x10]
LBB0_531:                               ; %else1811
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	q3, [sp, #7440]                 ; 16-byte Reload
	bit.16b	v3, v0, v2
	ldr	q5, [sp, #7376]                 ; 16-byte Reload
	bit.16b	v5, v8, v2
	fmov	x10, d5
	add	x10, x10, x10, lsl #2
	fmov	d0, x10
	str	q5, [sp, #7376]                 ; 16-byte Spill
	mov.d	x10, v5[1]
	add	x10, x10, x10, lsl #2
	mov.d	v0[1], x10
	str	q3, [sp, #7440]                 ; 16-byte Spill
	add.2d	v0, v0, v3
	shl.2d	v0, v0, #5
	ldr	q2, [sp, #9728]                 ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #9664]                 ; 16-byte Reload
	add.2d	v0, v2, v0
	tbz	w9, #4, LBB0_533
; %bb.532:                              ; %cond.load1813
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d0
	ld1.s	{ v21 }[0], [x10]
LBB0_533:                               ; %else1817
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	d23, [sp, #11624]               ; 8-byte Reload
	tbz	w9, #5, LBB0_535
; %bb.534:                              ; %cond.load1819
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v21 }[1], [x10]
LBB0_535:                               ; %else1823
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	q2, [sp, #7424]                 ; 16-byte Reload
	bit.16b	v2, v18, v14
	ldr	q3, [sp, #7360]                 ; 16-byte Reload
	bit.16b	v3, v9, v14
	fmov	x10, d3
	add	x10, x10, x10, lsl #2
	fmov	d0, x10
	str	q3, [sp, #7360]                 ; 16-byte Spill
	mov.d	x10, v3[1]
	add	x10, x10, x10, lsl #2
	mov.d	v0[1], x10
	str	q2, [sp, #7424]                 ; 16-byte Spill
	add.2d	v0, v0, v2
	shl.2d	v0, v0, #5
	ldr	q2, [sp, #9712]                 ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	add.2d	v0, v2, v0
	tbz	w9, #6, LBB0_537
; %bb.536:                              ; %cond.load1825
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d0
	ld1.s	{ v21 }[2], [x10]
LBB0_537:                               ; %else1829
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	tbz	w9, #7, LBB0_539
; %bb.538:                              ; %cond.load1831
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v21 }[3], [x9]
LBB0_539:                               ; %else1835
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	q0, [sp, #7344]                 ; 16-byte Reload
	bic.8b	v0, v0, v8
	orr.8b	v4, v4, v0
	cmtst.8b	v0, v7, v7
	ldr	q2, [sp, #10752]                ; 16-byte Reload
	bif.8b	v0, v2, v6
	ldr	d2, [sp, #11616]                ; 8-byte Reload
	orr.8b	v2, v28, v2
	and.8b	v3, v2, v0
	str	q4, [sp, #7344]                 ; 16-byte Spill
	bic.8b	v0, v8, v4
	fmov	w9, s30
	zip1.8b	v2, v1, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #7328]                 ; 16-byte Reload
	bsl.16b	v2, v11, v4
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v4, v4, #0
	and.16b	v5, v4, v2
	mov	w10, #62154                     ; =0xf2ca
	movk	w10, #61769, lsl #16
	dup.4s	v2, w10
	str	q3, [sp, #10752]                ; 16-byte Spill
	zip1.8b	v4, v3, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	str	q5, [sp, #7328]                 ; 16-byte Spill
	bsl.16b	v4, v5, v2
	mov.16b	v18, v31
	shl.2d	v5, v31, #5
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #0, LBB0_541
; %bb.540:                              ; %cond.store1838
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d5
	str	s4, [x10]
LBB0_541:                               ; %else1841
                                        ;   in Loop: Header=BB0_507 Depth=2
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	mov.16b	v3, v22
	mov.16b	v6, v10
	mov.16b	v19, v15
	ldr	q22, [sp, #10928]               ; 16-byte Reload
	ldr	q28, [sp, #10912]               ; 16-byte Reload
	ldr	q29, [sp, #10896]               ; 16-byte Reload
	ldr	q16, [sp, #4688]                ; 16-byte Reload
	ldr	q20, [sp, #4672]                ; 16-byte Reload
	mov.16b	v31, v17
	tbnz	w9, #1, LBB0_549
; %bb.542:                              ; %else1845
                                        ;   in Loop: Header=BB0_507 Depth=2
	shl.2d	v5, v19, #5
	ldr	q7, [sp, #12272]                ; 16-byte Reload
	orr.16b	v5, v5, v7
	ldr	q7, [sp, #12208]                ; 16-byte Reload
	add.2d	v5, v7, v5
	tbnz	w9, #2, LBB0_550
LBB0_543:                               ; %else1849
                                        ;   in Loop: Header=BB0_507 Depth=2
	tbz	w9, #3, LBB0_545
LBB0_544:                               ; %cond.store1850
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v4 }[3], [x10]
LBB0_545:                               ; %else1853
                                        ;   in Loop: Header=BB0_507 Depth=2
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q4, [sp, #7312]                 ; 16-byte Reload
	bsl.16b	v1, v21, v4
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	ldr	q0, [sp, #10752]                ; 16-byte Reload
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q1, [sp, #7312]                 ; 16-byte Spill
	bsl.16b	v0, v1, v2
	shl.2d	v1, v3, #5
	ldr	q2, [sp, #12256]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_551
; %bb.546:                              ; %else1857
                                        ;   in Loop: Header=BB0_507 Depth=2
	tbnz	w9, #5, LBB0_552
LBB0_547:                               ; %else1861
                                        ;   in Loop: Header=BB0_507 Depth=2
	shl.2d	v1, v6, #5
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #12176]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_553
LBB0_548:                               ; %else1865
                                        ;   in Loop: Header=BB0_507 Depth=2
	tbz	w9, #7, LBB0_506
	b	LBB0_554
LBB0_549:                               ; %cond.store1842
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v4 }[1], [x10]
	shl.2d	v5, v19, #5
	ldr	q7, [sp, #12272]                ; 16-byte Reload
	orr.16b	v5, v5, v7
	ldr	q7, [sp, #12208]                ; 16-byte Reload
	add.2d	v5, v7, v5
	tbz	w9, #2, LBB0_543
LBB0_550:                               ; %cond.store1846
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d5
	st1.s	{ v4 }[2], [x10]
	tbnz	w9, #3, LBB0_544
	b	LBB0_545
LBB0_551:                               ; %cond.store1854
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	tbz	w9, #5, LBB0_547
LBB0_552:                               ; %cond.store1858
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v6, #5
	ldr	q2, [sp, #12240]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #12176]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_548
LBB0_553:                               ; %cond.store1862
                                        ;   in Loop: Header=BB0_507 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_506
LBB0_554:                               ; %cond.store1866
                                        ;   in Loop: Header=BB0_507 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_506
LBB0_555:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	d23, [sp, #11624]               ; 8-byte Reload
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q22, [sp, #10928]               ; 16-byte Reload
	ldr	q28, [sp, #10912]               ; 16-byte Reload
	ldr	q29, [sp, #10896]               ; 16-byte Reload
	ldr	q16, [sp, #4688]                ; 16-byte Reload
	ldr	q20, [sp, #4672]                ; 16-byte Reload
LBB0_556:                               ; %direct.false568
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q19, [sp, #1392]                ; 16-byte Spill
	str	q18, [sp, #1408]                ; 16-byte Spill
	str	q6, [sp, #1424]                 ; 16-byte Spill
	str	q3, [sp, #1440]                 ; 16-byte Spill
	mov.16b	v27, v24
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #416]                  ; 16-byte Reload
	ldr	q3, [sp, #6112]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #6112]                 ; 16-byte Spill
	ldr	q3, [sp, #6144]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #6144]                 ; 16-byte Spill
	ldr	q3, [sp, #6128]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #6128]                 ; 16-byte Spill
	ldr	q3, [sp, #6160]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #6160]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #6176]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #6176]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #6208]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #6208]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #6192]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #6192]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #6224]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #6224]                 ; 16-byte Spill
	ldr	q2, [sp, #11072]                ; 16-byte Reload
	mov.16b	v3, v12
	mov.16b	v12, v14
	bic.16b	v2, v2, v14
	mov.16b	v26, v3
	bic.16b	v29, v29, v3
	bic.16b	v22, v22, v1
	bic.16b	v28, v28, v0
	fmov	x9, d28
	cmp	x9, #1
	b.le	LBB0_560
; %bb.557:                              ;   in Loop: Header=BB0_91 Depth=1
	ldr	q3, [sp, #11488]                ; 16-byte Reload
LBB0_558:                               ; %direct.false588
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q3, [sp, #11488]                ; 16-byte Spill
	str	q2, [sp, #11072]                ; 16-byte Spill
	mov.16b	v24, v27
	sshll.2d	v0, v24, #0
	ldr	q4, [sp, #12880]                ; 16-byte Reload
	sshll.2d	v1, v4, #0
	ldr	q2, [sp, #400]                  ; 16-byte Reload
	ldr	q3, [sp, #10432]                ; 16-byte Reload
	mov.16b	v14, v12
	bit.16b	v3, v2, v12
	str	q3, [sp, #10432]                ; 16-byte Spill
	ldr	q3, [sp, #10464]                ; 16-byte Reload
	mov.16b	v12, v26
	mov.16b	v26, v4
	bit.16b	v3, v2, v12
	str	q3, [sp, #10464]                ; 16-byte Spill
	ldr	q3, [sp, #10448]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #10448]                ; 16-byte Spill
	ldr	q3, [sp, #10480]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #10480]                ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #10496]                ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #10496]                ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #10528]                ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #10512]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #10512]                ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #10416]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #10416]                ; 16-byte Spill
	ldr	q25, [sp, #1376]                ; 16-byte Reload
	bic.16b	v25, v25, v14
	ldr	q2, [sp, #10208]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #10208]                ; 16-byte Spill
	ldr	q2, [sp, #10192]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10192]                ; 16-byte Spill
	ldr	q1, [sp, #10224]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	ldr	q0, [sp, #2896]                 ; 16-byte Reload
	mov.d	x15, v0[1]
	ldr	q0, [sp, #2912]                 ; 16-byte Reload
	mov.d	x7, v0[1]
	str	q1, [sp, #10224]                ; 16-byte Spill
	fmov	x9, d1
	ldr	q0, [sp, #2928]                 ; 16-byte Reload
	mov.d	x6, v0[1]
	ldr	q0, [sp, #2944]                 ; 16-byte Reload
	mov.d	x19, v0[1]
	b	LBB0_597
LBB0_559:                               ; %else1951
                                        ;   in Loop: Header=BB0_560 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v29, v29, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v22, v22, v0
	ldr	q2, [sp, #11072]                ; 16-byte Reload
	add.2d	v2, v2, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v28, v28, v0
	fmov	x9, d28
	cmp	x9, #2
	b.ge	LBB0_558
LBB0_560:                               ; %direct.true587
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_563 Depth 3
	mov.16b	v14, v11
	mov.16b	v24, v31
	mov.16b	v21, v27
	sshll.2d	v0, v21, #0
	ldr	q23, [sp, #12880]               ; 16-byte Reload
	sshll.2d	v1, v23, #0
	str	q2, [sp, #11072]                ; 16-byte Spill
	and.16b	v2, v12, v2
	and.16b	v4, v0, v28
	mov.d	x9, v4[1]
	ldr	x11, [sp, #11736]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d4
	ldr	q4, [sp, #11712]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	str	q22, [sp, #10928]               ; 16-byte Spill
	and.16b	v5, v1, v22
	mov.d	x9, v5[1]
	sdiv	x10, x9, x26
	msub	x9, x10, x26, x9
	fmov	x10, d5
	ldr	q5, [sp, #11696]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d5, x10
	mov.d	v5[1], x9
	str	q29, [sp, #10896]               ; 16-byte Spill
	and.16b	v6, v26, v29
	mov.d	x9, v6[1]
	sdiv	x10, x9, x25
	msub	x9, x10, x25, x9
	fmov	x10, d6
	ldr	q6, [sp, #11680]                ; 16-byte Reload
	fmov	x11, d6
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	mov.d	x9, v2[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d2
	ldr	q2, [sp, #11664]                ; 16-byte Reload
	fmov	x11, d2
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	ldr	q18, [sp, #7264]                ; 16-byte Reload
	bit.16b	v18, v2, v12
	ldr	q7, [sp, #11056]                ; 16-byte Reload
	bit.16b	v7, v6, v26
	ldr	q6, [sp, #7280]                 ; 16-byte Reload
	bit.16b	v6, v5, v1
	ldr	q3, [sp, #7296]                 ; 16-byte Reload
	bit.16b	v3, v4, v0
	bic.16b	v20, v20, v12
	ldr	q2, [sp, #11472]                ; 16-byte Reload
	bic.16b	v2, v2, v26
	str	q2, [sp, #11472]                ; 16-byte Spill
	bic.16b	v16, v16, v1
	ldr	q1, [sp, #7200]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	ldr	q10, [sp, #7216]                ; 16-byte Reload
	bic.16b	v10, v10, v23
	ldr	q15, [sp, #7248]                ; 16-byte Reload
	bic.16b	v15, v15, v27
	ldr	d0, [sp, #11616]                ; 8-byte Reload
	ldr	q2, [sp, #12944]                ; 16-byte Reload
	and.8b	v2, v0, v2
	str	q2, [sp, #12944]                ; 16-byte Spill
	mov.16b	v5, v1
	fmov	x9, d1
	cmp	x9, #4
	str	q3, [sp, #7296]                 ; 16-byte Spill
	str	q7, [sp, #11056]                ; 16-byte Spill
	str	q6, [sp, #7280]                 ; 16-byte Spill
	str	q18, [sp, #7264]                ; 16-byte Spill
	str	q28, [sp, #10912]               ; 16-byte Spill
	b.gt	LBB0_579
; %bb.561:                              ; %direct.true592.lr.ph
                                        ;   in Loop: Header=BB0_560 Depth=2
	fmov	x9, d3
	add	x9, x9, x9, lsl #2
	fmov	d2, x9
	mov.d	x9, v3[1]
	add	x9, x9, x9, lsl #2
	mov.d	v2[1], x9
	fmov	x9, d7
	add	x9, x9, x9, lsl #2
	fmov	d4, x9
	mov.d	x9, v7[1]
	add	x9, x9, x9, lsl #2
	mov.d	v4[1], x9
	fmov	x9, d6
	add	x9, x9, x9, lsl #2
	mov.d	x10, v6[1]
	fmov	d0, x9
	add	x9, x10, x10, lsl #2
	mov.d	v0[1], x9
	fmov	x9, d18
	add	x9, x9, x9, lsl #2
	fmov	d1, x9
	mov.d	x9, v18[1]
	add	x9, x9, x9, lsl #2
	mov.d	v1[1], x9
	ldr	q31, [sp, #13328]               ; 16-byte Reload
	mov.16b	v3, v5
	ldr	q28, [sp, #11472]               ; 16-byte Reload
	ldr	q17, [sp, #13232]               ; 16-byte Reload
	mov.16b	v21, v27
	ldr	q30, [sp, #12880]               ; 16-byte Reload
	b	LBB0_563
LBB0_562:                               ; %else1917
                                        ;   in Loop: Header=BB0_563 Depth=3
	cmge.2d	v19, v22, v17
	cmge.2d	v23, v28, v9
	uzp1.4s	v19, v23, v19
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	cmge.2d	v21, v21, v25
	ldr	q24, [sp, #13120]               ; 16-byte Reload
	cmge.2d	v18, v18, v24
	uzp1.4s	v18, v18, v21
	uzp1.8h	v18, v18, v19
	and.16b	v18, v31, v18
	xtn.8b	v18, v18
	zip2.8b	v19, v6, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	ldr	q3, [sp, #12576]                ; 16-byte Reload
	bsl.16b	v19, v30, v3
	zip1.8b	v21, v6, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	ldr	q3, [sp, #12592]                ; 16-byte Reload
	bsl.16b	v21, v29, v3
	zip1.8b	v23, v18, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmge.4s	v23, v23, #0
	and.16b	v3, v23, v21
	zip2.8b	v18, v18, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmge.4s	v18, v18, #0
	and.16b	v28, v18, v19
	fmaxnm.4s	v18, v10, v28
	fmaxnm.4s	v19, v15, v3
	ldr	q23, [sp, #12944]               ; 16-byte Reload
	zip1.8b	v21, v23, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	str	q3, [sp, #12592]                ; 16-byte Spill
	bif.16b	v19, v3, v21
	zip2.8b	v21, v23, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	str	q28, [sp, #12576]               ; 16-byte Spill
	bif.16b	v18, v28, v21
	ldr	q21, [sp, #13296]               ; 16-byte Reload
	add.2d	v28, v16, v21
	ldr	q21, [sp, #13280]               ; 16-byte Reload
	add.2d	v16, v20, v21
	add.2d	v20, v11, v14
	ldr	q21, [sp, #13264]               ; 16-byte Reload
	add.2d	v3, v13, v21
	mov.16b	v21, v27
	and.16b	v7, v27, v7
	ldr	q30, [sp, #12880]               ; 16-byte Reload
	and.16b	v5, v30, v5
	bit.16b	v10, v18, v5
	bit.16b	v15, v19, v7
	orr.8b	v23, v23, v6
	str	q23, [sp, #12944]               ; 16-byte Spill
	fmov	x9, d3
	cmp	x9, #5
	b.ge	LBB0_580
LBB0_563:                               ; %direct.true592
                                        ;   Parent Loop BB0_91 Depth=1
                                        ;     Parent Loop BB0_560 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v5, v30, #0
	sshll.2d	v6, v21, #0
	mov.16b	v11, v20
	and.16b	v7, v12, v20
	mov.d	x9, v7[1]
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d7
	ldr	q7, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d7
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.16b	v20, v16
	and.16b	v5, v5, v16
	mov.d	x9, v5[1]
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d5
	ldr	q5, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d8, x10
	mov.d	v8[1], x9
	mov.16b	v16, v28
	and.16b	v5, v26, v28
	mov.d	x9, v5[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d5
	ldr	q5, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	mov.16b	v7, v9
	fmov	d9, x10
	mov.d	v9[1], x9
	mov.16b	v13, v3
	and.16b	v5, v6, v3
	mov.d	x9, v5[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d5
	ldr	q5, [sp, #13168]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	shl.2d	v18, v6, #3
	shl.2d	v21, v9, #3
	shl.2d	v28, v8, #3
	shl.2d	v22, v23, #3
	cmgt.2d	v5, v17, v22
	cmgt.2d	v7, v7, v28
	uzp1.4s	v5, v7, v5
	cmgt.2d	v7, v25, v21
	cmgt.2d	v19, v24, v18
	uzp1.4s	v7, v19, v7
	uzp1.8h	v19, v7, v5
	add.2d	v29, v6, v2
	and.16b	v6, v31, v19
	xtn.8b	v6, v6
	shl.8b	v19, v6, #7
	cmlt.8b	v19, v19, #0
	ldr	d30, [sp, #13320]               ; 8-byte Reload
	and.8b	v19, v19, v30
	addv.8b	b19, v19
	fmov	w9, s19
	shl.2d	v19, v29, #5
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	add.2d	v31, v3, v19
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbz	w9, #0, LBB0_565
; %bb.564:                              ; %cond.load1871
                                        ;   in Loop: Header=BB0_563 Depth=3
	fmov	x10, d31
	ldr	s29, [x10]
LBB0_565:                               ; %else1875
                                        ;   in Loop: Header=BB0_563 Depth=3
	tbz	w9, #1, LBB0_567
; %bb.566:                              ; %cond.load1877
                                        ;   in Loop: Header=BB0_563 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v29 }[1], [x10]
LBB0_567:                               ; %else1881
                                        ;   in Loop: Header=BB0_563 Depth=3
	ldr	q17, [sp, #13232]               ; 16-byte Reload
	add.2d	v19, v9, v4
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12272]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12208]                ; 16-byte Reload
	add.2d	v31, v3, v19
	tbz	w9, #2, LBB0_569
; %bb.568:                              ; %cond.load1883
                                        ;   in Loop: Header=BB0_563 Depth=3
	fmov	x10, d31
	ld1.s	{ v29 }[2], [x10]
LBB0_569:                               ; %else1887
                                        ;   in Loop: Header=BB0_563 Depth=3
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	tbz	w9, #3, LBB0_571
; %bb.570:                              ; %cond.load1889
                                        ;   in Loop: Header=BB0_563 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v29 }[3], [x10]
LBB0_571:                               ; %else1893
                                        ;   in Loop: Header=BB0_563 Depth=3
	add.2d	v19, v8, v0
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12256]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12192]                ; 16-byte Reload
	add.2d	v31, v3, v19
	tbz	w9, #4, LBB0_573
; %bb.572:                              ; %cond.load1895
                                        ;   in Loop: Header=BB0_563 Depth=3
	fmov	x10, d31
	ld1.s	{ v30 }[0], [x10]
LBB0_573:                               ; %else1899
                                        ;   in Loop: Header=BB0_563 Depth=3
	tbz	w9, #5, LBB0_575
; %bb.574:                              ; %cond.load1901
                                        ;   in Loop: Header=BB0_563 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v30 }[1], [x10]
LBB0_575:                               ; %else1905
                                        ;   in Loop: Header=BB0_563 Depth=3
	ldr	q31, [sp, #13328]               ; 16-byte Reload
	add.2d	v19, v23, v1
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12240]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12176]                ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w9, #6, LBB0_577
; %bb.576:                              ; %cond.load1907
                                        ;   in Loop: Header=BB0_563 Depth=3
	fmov	x10, d23
	ld1.s	{ v30 }[2], [x10]
LBB0_577:                               ; %else1911
                                        ;   in Loop: Header=BB0_563 Depth=3
	tbz	w9, #7, LBB0_562
; %bb.578:                              ; %cond.load1913
                                        ;   in Loop: Header=BB0_563 Depth=3
	mov.d	x9, v23[1]
	ld1.s	{ v30 }[3], [x9]
	b	LBB0_562
LBB0_579:                               ;   in Loop: Header=BB0_560 Depth=2
	mov.16b	v3, v5
	ldr	q28, [sp, #11472]               ; 16-byte Reload
LBB0_580:                               ; %direct.false593
                                        ;   in Loop: Header=BB0_560 Depth=2
	str	q28, [sp, #11472]               ; 16-byte Spill
	str	q3, [sp, #7200]                 ; 16-byte Spill
	str	q15, [x13, #3824]
	str	q10, [x13, #3840]
	ldr	x10, [sp, #4296]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #928
	ldr	s0, [x9, x10]
	ldr	w9, [sp, #7980]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q15, [x13, #3792]
	str	q10, [x13, #3808]
	ldr	x11, [sp, #4248]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #896
	ldr	s4, [x9, x11]
	movi.2d	v17, #0000000000000000
	fcsel	s0, s0, s17, ne
	ldr	q3, [sp, #12944]                ; 16-byte Reload
	movi.8b	v1, #1
	and.8b	v1, v3, v1
	ushll.8h	v2, v1, #0
	ushll.4s	v1, v2, #0
	ushll2.4s	v2, v2, #0
	str	q2, [x13, #3360]
	str	q1, [x13, #3344]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #448
	ldr	w9, [x9, x10]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7976]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s4, s4, s17, ne
	str	q15, [x13, #3760]
	str	q10, [x13, #3776]
	ldr	x12, [sp, #4232]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #864
	ldr	s5, [x10, x12]
	str	q2, [x13, #3392]
	str	q1, [x13, #3376]
	fmov	s6, w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #480
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7972]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s7, s5, s17, ne
	str	q15, [x13, #3728]
	str	q10, [x13, #3744]
	ldr	x15, [sp, #4216]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #832
	ldr	s5, [x10, x15]
	str	q2, [x13, #3424]
	str	q1, [x13, #3408]
	mov.s	v6[1], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #512
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7968]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s18, s5, s17, ne
	str	q15, [x13, #3696]
	str	q10, [x13, #3712]
	ldr	x11, [sp, #4288]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #800
	ldr	s5, [x10, x11]
	str	q2, [x13, #3456]
	str	q1, [x13, #3440]
	mov.s	v6[2], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #544
	ldr	w9, [x9, x15]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7964]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s5, s5, s17, ne
	str	q15, [x13, #3664]
	str	q10, [x13, #3680]
	ldr	x12, [sp, #4192]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #768
	ldr	s19, [x10, x12]
	str	q2, [x13, #3488]
	str	q1, [x13, #3472]
	mov.s	v6[3], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #576
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7960]                ; 4-byte Reload
	tst	w10, #0x1
	str	q15, [x13, #3632]
	str	q10, [x13, #3648]
	ldr	x11, [sp, #4176]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #736
	ldr	s21, [x10, x11]
	fcsel	s19, s19, s17, ne
	str	q2, [x13, #3520]
	str	q1, [x13, #3504]
	fmov	s23, w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #608
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7956]                ; 4-byte Reload
	tst	w10, #0x1
	str	q15, [x13, #3600]
	str	q10, [x13, #3616]
	ldr	x12, [sp, #4160]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #704
	ldr	s25, [x10, x12]
	str	q2, [x13, #3552]
	str	q1, [x13, #3536]
	mov.s	v23[1], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #640
	ldr	w9, [x9, x11]
	fcsel	s21, s21, s17, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7952]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s25, s25, s17, ne
	mov.s	v5[1], v19[0]
	mov.s	v5[2], v21[0]
	mov.s	v5[3], v25[0]
	mov.s	v0[1], v4[0]
	mov.s	v0[2], v7[0]
	mov.s	v0[3], v18[0]
	fmaxnm.4s	v4, v15, v0
	str	q2, [x13, #3584]
	str	q1, [x13, #3568]
	mov.s	v23[2], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #672
	ldr	w9, [x9, x12]
	fmaxnm.4s	v1, v10, v5
	csel	w9, w9, wzr, ne
	mov.s	v23[3], w9
	cmtst.4s	v2, v23, v23
	cmtst.4s	v7, v6, v6
	uzp1.8h	v2, v7, v2
	xtn.8b	v7, v2
	cmeq.4s	v2, v6, #0
	cmeq.4s	v6, v23, #0
	str	q10, [sp, #7216]                ; 16-byte Spill
	bit.16b	v1, v10, v6
	bsl.16b	v2, v15, v4
	zip1.8b	v4, v3, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bit.16b	v0, v2, v4
	zip2.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bsl.16b	v2, v1, v5
	orr.8b	v1, v3, v7
	str	q2, [x13, #3328]
	str	q0, [x13, #3312]
	ldr	x10, [sp, #4280]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #416
	ldr	s4, [x9, x10]
	ldr	w9, [sp, #7948]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q2, [x13, #3264]
	str	q0, [x13, #3248]
	ldr	x11, [sp, #4136]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #352
	ldr	s21, [x9, x11]
	zip1.8b	v5, v1, v0
	ushll.4s	v6, v5, #0
	movi.4s	v31, #1
	and.16b	v5, v6, v31
	zip2.8b	v7, v1, v0
	ushll.4s	v18, v7, #0
	and.16b	v7, v18, v31
	str	q7, [x13, #3296]
	str	q5, [x13, #3280]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #384
	ldr	w9, [x9, x10]
	fcsel	s4, s4, s17, ne
	csel	w9, w9, wzr, ne
	str	q2, [x13, #3200]
	str	q0, [x13, #3184]
	ldr	x12, [sp, #4120]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #288
	ldr	s23, [x10, x12]
	ldr	w10, [sp, #7944]                ; 4-byte Reload
	tst	w10, #0x1
	str	q7, [x13, #3232]
	str	q5, [x13, #3216]
	fmov	s25, w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #320
	ldr	w9, [x9, x11]
	fcsel	s19, s21, s17, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7940]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s21, s23, s17, ne
	str	q2, [x13, #3136]
	str	q0, [x13, #3120]
	ldr	x15, [sp, #4104]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #224
	ldr	s23, [x10, x15]
	str	q7, [x13, #3168]
	str	q5, [x13, #3152]
	mov.s	v25[1], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #256
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7936]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s23, s23, s17, ne
	str	q2, [x13, #3072]
	str	q0, [x13, #3056]
	ldr	x11, [sp, #4272]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #160
	ldr	s28, [x10, x11]
	str	q7, [x13, #3104]
	mov.s	v25[2], w9
	str	q5, [x13, #3088]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #192
	ldr	w9, [x9, x15]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7932]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s28, s28, s17, ne
	str	q2, [x13, #3008]
	str	q0, [x13, #2992]
	ldr	x12, [sp, #4080]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #96
	ldr	s29, [x10, x12]
	str	q7, [x13, #3040]
	str	q5, [x13, #3024]
	mov.s	v25[3], w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #128
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7928]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s29, s29, s17, ne
	str	q2, [x13, #2944]
	str	q0, [x13, #2928]
	ldr	x11, [sp, #4064]                ; 8-byte Reload
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #32
	ldr	s30, [x10, x11]
	str	q7, [x13, #2976]
	str	q5, [x13, #2960]
	mov.s	v28[1], v29[0]
	fmov	s29, w9
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #64
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7924]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s30, s30, s17, ne
	str	q2, [x13, #2880]
	mov.s	v28[2], v30[0]
	str	q0, [x13, #2864]
	ldr	x12, [sp, #4048]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #4064
	ldr	s30, [x10, x12]
	str	q7, [x13, #2912]
	mov.s	v29[1], w9
	str	q5, [x13, #2896]
	add	x9, sp, #4, lsl #12             ; =16384
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7920]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s30, s30, s17, ne
	mov.s	v28[3], v30[0]
	mov.s	v4[1], v19[0]
	mov.s	v4[2], v21[0]
	mov.s	v4[3], v23[0]
	fmaxnm.4s	v19, v0, v4
	fmaxnm.4s	v21, v2, v28
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	str	q7, [x13, #2848]
	str	q5, [x13, #2832]
	mov.s	v29[2], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #4032
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	mov.s	v29[3], w9
	cmtst.4s	v5, v29, v29
	cmtst.4s	v7, v25, v25
	uzp1.8h	v5, v7, v5
	xtn.8b	v5, v5
	cmeq.4s	v7, v25, #0
	cmeq.4s	v23, v29, #0
	bif.16b	v2, v21, v23
	bif.16b	v0, v19, v7
	bif.16b	v0, v4, v6
	mov.16b	v6, v18
	bsl.16b	v6, v2, v28
	orr.8b	v5, v1, v5
	str	q6, [x13, #2816]
	str	q0, [x13, #2800]
	ldr	x10, [sp, #4264]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #4000
	ldr	s1, [x9, x10]
	ldr	w9, [sp, #7916]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s1, s1, s17, ne
	str	q6, [x13, #2752]
	str	q0, [x13, #2736]
	ldr	x11, [sp, #4024]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3936
	ldr	s7, [x9, x11]
	zip1.8b	v2, v5, v0
	ushll.4s	v4, v2, #0
	and.16b	v2, v4, v31
	zip2.8b	v5, v5, v0
	ushll.4s	v5, v5, #0
	and.16b	v5, v5, v31
	str	q5, [x13, #2784]
	str	q2, [x13, #2768]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3968
	ldr	w9, [x9, x10]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7912]                ; 4-byte Reload
	tst	w10, #0x1
	str	q6, [x13, #2688]
	str	q0, [x13, #2672]
	ldr	x12, [sp, #4008]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3872
	ldr	s18, [x10, x12]
	fcsel	s7, s7, s17, ne
	str	q5, [x13, #2720]
	str	q2, [x13, #2704]
	fmov	s19, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3904
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7908]                ; 4-byte Reload
	tst	w10, #0x1
	str	q6, [x13, #2624]
	str	q0, [x13, #2608]
	ldr	x11, [sp, #3976]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3808
	ldr	s6, [x10, x11]
	str	q5, [x13, #2656]
	str	q2, [x13, #2640]
	mov.s	v19[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3840
	ldr	w9, [x9, x12]
	fcsel	s18, s18, s17, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7904]                ; 4-byte Reload
	tst	w10, #0x1
	mov.16b	v21, v1
	mov.s	v21[1], v7[0]
	fcsel	s6, s6, s17, ne
	mov.s	v21[2], v18[0]
	mov.s	v21[3], v6[0]
	fmaxnm.4s	v6, v0, v21
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	str	q5, [x13, #2592]
	str	q2, [x13, #2576]
	mov.s	v19[2], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3776
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	mov.s	v19[3], w9
	cmeq.4s	v2, v19, #0
	bif.16b	v0, v6, v2
	bif.16b	v0, v1, v4
	tst	w16, #0x1
	fcsel	s1, s0, s17, ne
	and	w9, w17, w16
	tst	w9, #0x1
	fcsel	s2, s0, s17, ne
	and	w9, w0, w16
	tst	w9, #0x1
	fcsel	s4, s0, s17, ne
	and	w9, w1, w16
	tst	w9, #0x1
	fcsel	s5, s0, s17, ne
	and	w9, w2, w16
	tst	w9, #0x1
	fcsel	s6, s0, s17, ne
	and	w9, w3, w16
	tst	w9, #0x1
	fcsel	s7, s0, s17, ne
	and	w9, w4, w16
	tst	w9, #0x1
	fcsel	s18, s0, s17, ne
	and	w9, w5, w16
	tst	w9, #0x1
	fcsel	s0, s0, s17, ne
	mov.s	v1[1], v2[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v5[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v18[0]
	mov.s	v6[3], v0[0]
	ldr	q0, [sp, #8048]                 ; 16-byte Reload
	fmov	w9, s0
	str	q6, [x13, #2304]
	str	q1, [x13, #2288]
	ldr	x10, [sp, #3960]                ; 8-byte Reload
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #3488
	ldr	s0, [x11, x10, lsl #2]
	mov	w10, #-8388608                  ; =0xff800000
	fmov	s1, w10
	fmaxnm	s0, s0, s1
	ldr	q28, [sp, #10912]               ; 16-byte Reload
	shl.2d	v1, v28, #5
	ldr	q2, [sp, #6224]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	dup.4s	v0, v0[0]
	ldr	q2, [sp, #6160]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #0, LBB0_582
; %bb.581:                              ; %cond.store1920
                                        ;   in Loop: Header=BB0_560 Depth=2
	fmov	x10, d1
	str	s0, [x10]
LBB0_582:                               ; %else1923
                                        ;   in Loop: Header=BB0_560 Depth=2
	str	q15, [sp, #7248]                ; 16-byte Spill
	and	w9, w9, #0xff
	ldr	q29, [sp, #10896]               ; 16-byte Reload
	mov.16b	v31, v24
	tbz	w9, #1, LBB0_584
; %bb.583:                              ; %cond.store1924
                                        ;   in Loop: Header=BB0_560 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
LBB0_584:                               ; %else1927
                                        ;   in Loop: Header=BB0_560 Depth=2
	shl.2d	v1, v29, #5
	ldr	q2, [sp, #6208]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6144]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	ldr	q25, [sp, #13152]               ; 16-byte Reload
	ldr	q22, [sp, #10928]               ; 16-byte Reload
	mov.16b	v11, v14
	tbnz	w9, #2, LBB0_590
; %bb.585:                              ; %else1931
                                        ;   in Loop: Header=BB0_560 Depth=2
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	d23, [sp, #11624]               ; 8-byte Reload
	ldr	q3, [sp, #11488]                ; 16-byte Reload
	tbnz	w9, #3, LBB0_591
LBB0_586:                               ; %else1935
                                        ;   in Loop: Header=BB0_560 Depth=2
	shl.2d	v1, v22, #5
	ldr	q2, [sp, #6192]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6128]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_592
LBB0_587:                               ; %else1939
                                        ;   in Loop: Header=BB0_560 Depth=2
	ldr	q2, [sp, #11072]                ; 16-byte Reload
	tbnz	w9, #5, LBB0_593
LBB0_588:                               ; %else1943
                                        ;   in Loop: Header=BB0_560 Depth=2
	shl.2d	v1, v2, #5
	ldr	q2, [sp, #6176]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6112]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_594
LBB0_589:                               ; %else1947
                                        ;   in Loop: Header=BB0_560 Depth=2
	tbz	w9, #7, LBB0_559
	b	LBB0_595
LBB0_590:                               ; %cond.store1928
                                        ;   in Loop: Header=BB0_560 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	d23, [sp, #11624]               ; 8-byte Reload
	ldr	q3, [sp, #11488]                ; 16-byte Reload
	tbz	w9, #3, LBB0_586
LBB0_591:                               ; %cond.store1932
                                        ;   in Loop: Header=BB0_560 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[3], [x10]
	shl.2d	v1, v22, #5
	ldr	q2, [sp, #6192]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6128]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #4, LBB0_587
LBB0_592:                               ; %cond.store1936
                                        ;   in Loop: Header=BB0_560 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	ldr	q2, [sp, #11072]                ; 16-byte Reload
	tbz	w9, #5, LBB0_588
LBB0_593:                               ; %cond.store1940
                                        ;   in Loop: Header=BB0_560 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v2, #5
	ldr	q2, [sp, #6176]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6112]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_589
LBB0_594:                               ; %cond.store1944
                                        ;   in Loop: Header=BB0_560 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_559
LBB0_595:                               ; %cond.store1948
                                        ;   in Loop: Header=BB0_560 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_559
LBB0_596:                               ; %else2082
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #10208]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10208]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #10192]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10192]                ; 16-byte Spill
	add.2d	v25, v25, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	ldr	q1, [sp, #10224]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10224]                ; 16-byte Spill
	fmov	x9, d1
LBB0_597:                               ; %else2082
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	cmp	x9, #1
	b.ge	LBB0_646
; %bb.598:                              ; %direct.true621
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	w9, s23
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w9, #0, LBB0_635
; %bb.599:                              ; %else1957
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbnz	w9, #1, LBB0_636
LBB0_600:                               ; %else1963
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbnz	w9, #2, LBB0_637
LBB0_601:                               ; %else1969
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbnz	w9, #3, LBB0_638
LBB0_602:                               ; %else1975
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbnz	w9, #4, LBB0_639
LBB0_603:                               ; %else1981
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbnz	w9, #5, LBB0_640
LBB0_604:                               ; %else1987
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbnz	w9, #6, LBB0_641
LBB0_605:                               ; %else1993
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbz	w9, #7, LBB0_607
LBB0_606:                               ; %cond.load1995
                                        ;   in Loop: Header=BB0_597 Depth=2
	ld1.s	{ v0 }[3], [x15]
LBB0_607:                               ; %else1999
                                        ;   in Loop: Header=BB0_597 Depth=2
	sshll.2d	v2, v24, #0
	ldr	q4, [sp, #5808]                 ; 16-byte Reload
	ldr	q3, [sp, #5392]                 ; 16-byte Reload
	bit.16b	v3, v4, v2
	fmov	w9, s23
	str	q3, [sp, #5392]                 ; 16-byte Spill
	shl.2d	v2, v3, #5
	ldr	q3, [sp, #6224]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #6160]                 ; 16-byte Reload
	add.2d	v5, v3, v2
	movi.2d	v4, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w9, #0, LBB0_609
; %bb.608:                              ; %cond.load2002
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	x10, d5
	ldr	s4, [x10]
LBB0_609:                               ; %else2006
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbz	w9, #1, LBB0_611
; %bb.610:                              ; %cond.load2008
                                        ;   in Loop: Header=BB0_597 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v4 }[1], [x10]
LBB0_611:                               ; %else2012
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q3, [sp, #5344]                 ; 16-byte Reload
	bic.16b	v5, v3, v12
	ssubw2.2d	v3, v5, v24
	str	q3, [sp, #5344]                 ; 16-byte Spill
	shl.2d	v5, v3, #5
	ldr	q3, [sp, #6208]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #6144]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #2, LBB0_613
; %bb.612:                              ; %cond.load2014
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	x10, d5
	ld1.s	{ v4 }[2], [x10]
LBB0_613:                               ; %else2018
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbz	w9, #3, LBB0_615
; %bb.614:                              ; %cond.load2020
                                        ;   in Loop: Header=BB0_597 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v4 }[3], [x10]
LBB0_615:                               ; %else2024
                                        ;   in Loop: Header=BB0_597 Depth=2
	sshll.2d	v5, v26, #0
	ldr	q3, [sp, #5472]                 ; 16-byte Reload
	bic.16b	v5, v3, v5
	ssubw.2d	v3, v5, v26
	str	q3, [sp, #5472]                 ; 16-byte Spill
	shl.2d	v5, v3, #5
	ldr	q3, [sp, #6192]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #6128]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #4, LBB0_617
; %bb.616:                              ; %cond.load2026
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	x10, d5
	ld1.s	{ v2 }[0], [x10]
LBB0_617:                               ; %else2030
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbz	w9, #5, LBB0_619
; %bb.618:                              ; %cond.load2032
                                        ;   in Loop: Header=BB0_597 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v2 }[1], [x10]
LBB0_619:                               ; %else2036
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q3, [sp, #5456]                 ; 16-byte Reload
	bic.16b	v5, v3, v14
	ssubw2.2d	v3, v5, v26
	str	q3, [sp, #5456]                 ; 16-byte Spill
	shl.2d	v5, v3, #5
	ldr	q3, [sp, #6176]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #6112]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #6, LBB0_621
; %bb.620:                              ; %cond.load2038
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	x10, d5
	ld1.s	{ v2 }[2], [x10]
LBB0_621:                               ; %else2042
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbz	w9, #7, LBB0_623
; %bb.622:                              ; %cond.load2044
                                        ;   in Loop: Header=BB0_597 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v2 }[3], [x9]
LBB0_623:                               ; %else2048
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q3, [sp, #5440]                 ; 16-byte Reload
	movi	d5, #0x0000000000ffff
	bit.8b	v3, v5, v8
	ldr	q5, [sp, #2848]                 ; 16-byte Reload
	ldr	q6, [sp, #5424]                 ; 16-byte Reload
	bif.16b	v1, v6, v5
	ldr	q5, [sp, #2800]                 ; 16-byte Reload
	and.16b	v6, v5, v1
	str	q3, [sp, #5440]                 ; 16-byte Spill
	bic.8b	v1, v8, v3
	fmov	w9, s23
	ldr	q5, [sp, #2768]                 ; 16-byte Reload
	ldr	q3, [sp, #5376]                 ; 16-byte Reload
	bif.16b	v4, v3, v5
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v3, v5, v4
	str	q6, [sp, #5424]                 ; 16-byte Spill
	str	q3, [sp, #5376]                 ; 16-byte Spill
	fmaxnm.4s	v4, v6, v3
	ldr	q3, [sp, #10224]                ; 16-byte Reload
	shl.2d	v5, v3, #5
	ldr	q3, [sp, #10416]                ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #10480]                ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #0, LBB0_625
; %bb.624:                              ; %cond.store2051
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	x10, d5
	str	s4, [x10]
LBB0_625:                               ; %else2054
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbz	w9, #1, LBB0_627
; %bb.626:                              ; %cond.store2055
                                        ;   in Loop: Header=BB0_597 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v4 }[1], [x10]
LBB0_627:                               ; %else2058
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q3, [sp, #10208]                ; 16-byte Reload
	shl.2d	v5, v3, #5
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #10464]                ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #2, LBB0_629
; %bb.628:                              ; %cond.store2059
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	x10, d5
	st1.s	{ v4 }[2], [x10]
LBB0_629:                               ; %else2062
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbz	w9, #3, LBB0_631
; %bb.630:                              ; %cond.store2063
                                        ;   in Loop: Header=BB0_597 Depth=2
	mov.d	x10, v5[1]
	st1.s	{ v4 }[3], [x10]
LBB0_631:                               ; %else2066
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q4, [sp, #2832]                 ; 16-byte Reload
	ldr	q3, [sp, #5408]                 ; 16-byte Reload
	bif.16b	v0, v3, v4
	ldr	q4, [sp, #2816]                 ; 16-byte Reload
	and.16b	v3, v4, v0
	ldr	q0, [sp, #2784]                 ; 16-byte Reload
	ldr	q4, [sp, #5360]                 ; 16-byte Reload
	bsl.16b	v0, v2, v4
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q3, [sp, #5408]                 ; 16-byte Spill
	str	q0, [sp, #5360]                 ; 16-byte Spill
	fmaxnm.4s	v0, v3, v0
	ldr	q1, [sp, #10192]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q2, [sp, #10512]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #10448]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_642
; %bb.632:                              ; %else2070
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbnz	w9, #5, LBB0_643
LBB0_633:                               ; %else2074
                                        ;   in Loop: Header=BB0_597 Depth=2
	shl.2d	v1, v25, #5
	ldr	q2, [sp, #10496]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #10432]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_644
LBB0_634:                               ; %else2078
                                        ;   in Loop: Header=BB0_597 Depth=2
	tbz	w9, #7, LBB0_596
	b	LBB0_645
LBB0_635:                               ; %cond.load1953
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q0, [sp, #2944]                 ; 16-byte Reload
	fmov	x10, d0
	ldr	s1, [x10]
	movi.2d	v0, #0000000000000000
	tbz	w9, #1, LBB0_600
LBB0_636:                               ; %cond.load1959
                                        ;   in Loop: Header=BB0_597 Depth=2
	ld1.s	{ v1 }[1], [x19]
	tbz	w9, #2, LBB0_601
LBB0_637:                               ; %cond.load1965
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q2, [sp, #2928]                 ; 16-byte Reload
	fmov	x10, d2
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB0_602
LBB0_638:                               ; %cond.load1971
                                        ;   in Loop: Header=BB0_597 Depth=2
	ld1.s	{ v1 }[3], [x6]
	tbz	w9, #4, LBB0_603
LBB0_639:                               ; %cond.load1977
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q2, [sp, #2912]                 ; 16-byte Reload
	fmov	x10, d2
	ld1.s	{ v0 }[0], [x10]
	tbz	w9, #5, LBB0_604
LBB0_640:                               ; %cond.load1983
                                        ;   in Loop: Header=BB0_597 Depth=2
	ld1.s	{ v0 }[1], [x7]
	tbz	w9, #6, LBB0_605
LBB0_641:                               ; %cond.load1989
                                        ;   in Loop: Header=BB0_597 Depth=2
	ldr	q2, [sp, #2896]                 ; 16-byte Reload
	fmov	x10, d2
	ld1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_606
	b	LBB0_607
LBB0_642:                               ; %cond.store2067
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	tbz	w9, #5, LBB0_633
LBB0_643:                               ; %cond.store2071
                                        ;   in Loop: Header=BB0_597 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v25, #5
	ldr	q2, [sp, #10496]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #10432]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_634
LBB0_644:                               ; %cond.store2075
                                        ;   in Loop: Header=BB0_597 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_596
LBB0_645:                               ; %cond.store2079
                                        ;   in Loop: Header=BB0_597 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_596
LBB0_646:                               ; %direct.false622
                                        ;   in Loop: Header=BB0_91 Depth=1
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #384]                  ; 16-byte Reload
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #3296]                 ; 16-byte Spill
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #3200]                 ; 16-byte Spill
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3312]                 ; 16-byte Spill
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3216]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #3232]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #3264]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #3264]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #3248]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3248]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3280]                 ; 16-byte Spill
	ldr	q2, [sp, #10128]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #10128]                ; 16-byte Spill
	ldr	q2, [sp, #10160]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #10160]                ; 16-byte Spill
	ldr	q2, [sp, #10144]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10144]                ; 16-byte Spill
	ldr	q1, [sp, #10176]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #10176]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #0
	b.le	LBB0_1249
LBB0_647:                               ; %direct.false637
                                        ;   in Loop: Header=BB0_91 Depth=1
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #368]                  ; 16-byte Reload
	ldr	q3, [sp, #6432]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #6432]                 ; 16-byte Spill
	ldr	q3, [sp, #6464]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #6464]                 ; 16-byte Spill
	ldr	q3, [sp, #6448]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #6448]                 ; 16-byte Spill
	ldr	q3, [sp, #6368]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #6368]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #6480]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #6480]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #6400]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #6400]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #6384]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #6384]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #6416]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #6416]                 ; 16-byte Spill
	ldr	q2, [sp, #10064]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #10064]                ; 16-byte Spill
	ldr	q2, [sp, #10096]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #10096]                ; 16-byte Spill
	ldr	q2, [sp, #10112]                ; 16-byte Reload
	bic.16b	v2, v2, v0
	str	q2, [sp, #10112]                ; 16-byte Spill
	fmov	x9, d2
	mov	w10, #-1026555904               ; =0xc2d00000
	dup.4s	v27, w10
	mov	w10, #1120403456                ; =0x42c80000
	dup.4s	v0, w10
	str	q0, [sp, #11376]                ; 16-byte Spill
	mov	w10, #43579                     ; =0xaa3b
	movk	w10, #16312, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11360]                ; 16-byte Spill
	mov	w10, #29184                     ; =0x7200
	movk	w10, #48945, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11344]                ; 16-byte Spill
	mov	w10, #48782                     ; =0xbe8e
	movk	w10, #46527, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11328]                ; 16-byte Spill
	mov	w10, #11226                     ; =0x2bda
	movk	w10, #14672, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11312]                ; 16-byte Spill
	mov	w10, #38601                     ; =0x96c9
	movk	w10, #15030, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11296]                ; 16-byte Spill
	mov	w10, #34982                     ; =0x88a6
	movk	w10, #15368, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11280]                ; 16-byte Spill
	ldr	q0, [sp, #10080]                ; 16-byte Reload
	bic.16b	v0, v0, v1
	str	q0, [sp, #10080]                ; 16-byte Spill
	mov	w10, #43642                     ; =0xaa7a
	movk	w10, #15658, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11264]                ; 16-byte Spill
	mov	w10, #43691                     ; =0xaaab
	movk	w10, #15914, lsl #16
	dup.4s	v0, w10
	str	q0, [sp, #11248]                ; 16-byte Spill
	cmp	x9, #0
	b.le	LBB0_1299
LBB0_648:                               ; %direct.false652
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q20, [sp, #4672]                ; 16-byte Spill
	str	q16, [sp, #4688]                ; 16-byte Spill
	str	q29, [sp, #10896]               ; 16-byte Spill
	str	q28, [sp, #10912]               ; 16-byte Spill
	str	q22, [sp, #10928]               ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #352]                  ; 16-byte Reload
	ldr	q3, [sp, #8816]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8816]                 ; 16-byte Spill
	ldr	q3, [sp, #8720]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8720]                 ; 16-byte Spill
	ldr	q3, [sp, #8704]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8704]                 ; 16-byte Spill
	ldr	q3, [sp, #8736]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8736]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #8752]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8752]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #8784]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8784]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #8768]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8768]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #8800]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8800]                 ; 16-byte Spill
	ldr	q2, [sp, #1984]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #1984]                 ; 16-byte Spill
	ldr	q2, [sp, #6496]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #6496]                 ; 16-byte Spill
	ldr	q2, [sp, #1344]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	ldr	q1, [sp, #11040]                ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x9, d0
	cmp	x9, #9
	str	q25, [sp, #1376]                ; 16-byte Spill
	b.gt	LBB0_699
; %bb.649:                              ; %direct.true662.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q20, [sp, #896]                 ; 16-byte Reload
	ldr	q25, [sp, #6496]                ; 16-byte Reload
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	ldr	q16, [sp, #1216]                ; 16-byte Reload
	b	LBB0_651
LBB0_650:                               ; %else2426
                                        ;   in Loop: Header=BB0_651 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v25, v25, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v2, v2, v0
	add.2d	v3, v15, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	ldr	q22, [sp, #11040]               ; 16-byte Reload
	add.2d	v0, v22, v0
	fmov	x9, d0
	cmp	x9, #10
	b.ge	LBB0_700
LBB0_651:                               ; %direct.true662
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v1, v26, #0
	sshll.2d	v5, v24, #0
	str	q0, [sp, #11040]                ; 16-byte Spill
	and.16b	v6, v5, v0
	mov.16b	v13, v2
	and.16b	v2, v1, v2
	and.16b	v4, v12, v25
	mov.16b	v15, v3
	and.16b	v0, v14, v3
	fmov	x9, d0
	ldr	q7, [sp, #13216]                ; 16-byte Reload
	fmov	x10, d7
	sdiv	x15, x9, x10
	mov.d	x9, v0[1]
	sdiv	x6, x9, x14
	fmov	x9, d4
	ldr	q7, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d7
	sdiv	x22, x9, x11
	mov.d	x9, v4[1]
	sdiv	x23, x9, x30
	fmov	x9, d2
	ldr	q7, [sp, #13184]                ; 16-byte Reload
	fmov	x12, d7
	sdiv	x20, x9, x12
	mov.d	x9, v2[1]
	sdiv	x21, x9, x8
	fmov	x9, d6
	ldr	q7, [sp, #13168]                ; 16-byte Reload
	fmov	x7, d7
	sdiv	x9, x9, x7
	mov.d	x19, v6[1]
	sdiv	x19, x19, x28
	mul	x7, x9, x7
	fmov	d7, x7
	mul	x7, x19, x28
	mov.d	v7[1], x7
	mul	x7, x23, x30
	mul	x11, x22, x11
	fmov	d18, x11
	mov.d	v18[1], x7
	mul	x11, x21, x8
	mul	x12, x20, x12
	fmov	d19, x12
	mov.d	v19[1], x11
	mul	x11, x6, x14
	mul	x10, x15, x10
	fmov	d21, x10
	mov.d	v21[1], x11
	sub.2d	v0, v0, v21
	sub.2d	v2, v2, v19
	sub.2d	v4, v4, v18
	sub.2d	v6, v6, v7
	shl.2d	v17, v6, #3
	shl.2d	v7, v4, #3
	shl.2d	v18, v2, #3
	shl.2d	v30, v0, #3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v19, v3, v30
	cmgt.2d	v21, v9, v18
	uzp1.4s	v19, v21, v19
	ldr	q21, [sp, #13152]               ; 16-byte Reload
	cmgt.2d	v21, v21, v7
	mov.16b	v22, v17
	cmgt.2d	v23, v31, v17
	uzp1.4s	v21, v23, v21
	fmov	d23, x9
	mov.d	v23[1], x19
	uzp1.8h	v19, v21, v19
	and.16b	v5, v5, v23
	mov.d	x9, v5[1]
	ldr	x11, [sp, #11736]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x7, x10, x11, x9
	fmov	x9, d5
	ldr	q5, [sp, #11712]                ; 16-byte Reload
	fmov	x10, d5
	sdiv	x11, x9, x10
	msub	x19, x11, x10, x9
	add	x9, x19, x19, lsl #2
	fmov	d5, x9
	add	x9, x7, x7, lsl #2
	mov.d	v5[1], x9
	add.2d	v5, v5, v6
	ldr	q31, [sp, #13328]               ; 16-byte Reload
	and.16b	v6, v31, v19
	xtn.8b	v17, v6
	shl.8b	v6, v17, #7
	cmlt.8b	v6, v6, #0
	ldr	d19, [sp, #13320]               ; 8-byte Reload
	and.8b	v6, v6, v19
	addv.8b	b3, v6
	str	d3, [sp, #6496]                 ; 8-byte Spill
	fmov	w9, s3
	shl.2d	v5, v5, #5
	ldr	q3, [sp, #12288]                ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #12224]                ; 16-byte Reload
	add.2d	v5, v3, v5
	movi.2d	v8, #0000000000000000
	movi.2d	v29, #0000000000000000
	tbz	w9, #0, LBB0_653
; %bb.652:                              ; %cond.load2297
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d5
	ldr	s8, [x10]
LBB0_653:                               ; %else2301
                                        ;   in Loop: Header=BB0_651 Depth=2
	tbz	w9, #1, LBB0_655
; %bb.654:                              ; %cond.load2303
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v8 }[1], [x10]
LBB0_655:                               ; %else2307
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	d5, x22
	mov.d	v5[1], x23
	and.16b	v5, v12, v5
	mov.d	x10, v5[1]
	sdiv	x11, x10, x25
	msub	x22, x11, x25, x10
	fmov	x10, d5
	ldr	q5, [sp, #11680]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x23, x12, x11, x10
	add	x10, x23, x23, lsl #2
	fmov	d5, x10
	add	x10, x22, x22, lsl #2
	mov.d	v5[1], x10
	add.2d	v4, v5, v4
	shl.2d	v4, v4, #5
	ldr	q3, [sp, #12272]                ; 16-byte Reload
	orr.16b	v4, v4, v3
	ldr	q3, [sp, #12208]                ; 16-byte Reload
	add.2d	v4, v3, v4
	tbz	w9, #2, LBB0_657
; %bb.656:                              ; %cond.load2309
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d4
	ld1.s	{ v8 }[2], [x10]
LBB0_657:                               ; %else2313
                                        ;   in Loop: Header=BB0_651 Depth=2
	tbz	w9, #3, LBB0_659
; %bb.658:                              ; %cond.load2315
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v4[1]
	ld1.s	{ v8 }[3], [x10]
LBB0_659:                               ; %else2319
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	d4, x20
	mov.d	v4[1], x21
	and.16b	v1, v1, v4
	mov.d	x10, v1[1]
	sdiv	x11, x10, x26
	msub	x20, x11, x26, x10
	fmov	x10, d1
	ldr	q1, [sp, #11696]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x21, x12, x11, x10
	add	x10, x21, x21, lsl #2
	fmov	d1, x10
	add	x10, x20, x20, lsl #2
	mov.d	v1[1], x10
	add.2d	v1, v1, v2
	shl.2d	v1, v1, #5
	ldr	q2, [sp, #12256]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #12192]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #4, LBB0_661
; %bb.660:                              ; %cond.load2321
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d1
	ld1.s	{ v29 }[0], [x10]
LBB0_661:                               ; %else2325
                                        ;   in Loop: Header=BB0_651 Depth=2
	tbz	w9, #5, LBB0_663
; %bb.662:                              ; %cond.load2327
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v1[1]
	ld1.s	{ v29 }[1], [x10]
LBB0_663:                               ; %else2331
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	d1, x15
	mov.d	v1[1], x6
	and.16b	v1, v14, v1
	mov.d	x10, v1[1]
	sdiv	x11, x10, x27
	msub	x15, x11, x27, x10
	fmov	x10, d1
	ldr	q1, [sp, #11664]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x12, x10, x11
	msub	x6, x12, x11, x10
	add	x10, x6, x6, lsl #2
	fmov	d1, x10
	add	x10, x15, x15, lsl #2
	mov.d	v1[1], x10
	add.2d	v0, v1, v0
	shl.2d	v0, v0, #5
	ldr	q1, [sp, #12240]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #12176]                ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w9, #6, LBB0_665
; %bb.664:                              ; %cond.load2333
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d0
	ld1.s	{ v29 }[2], [x10]
LBB0_665:                               ; %else2337
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.16b	v10, v25
	tbz	w9, #7, LBB0_667
; %bb.666:                              ; %cond.load2339
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v29 }[3], [x9]
LBB0_667:                               ; %else2343
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	d0, x6
	mov.d	v0[1], x15
	fmov	d6, x23
	mov.d	v6[1], x22
	fmov	d2, x21
	mov.d	v2[1], x20
	fmov	d4, x19
	mov.d	v4[1], x7
	sshll.2d	v1, v24, #0
	sshll.2d	v5, v26, #0
	and.16b	v0, v14, v0
	and.16b	v2, v5, v2
	and.16b	v4, v1, v4
	mov.d	x10, v4[1]
	ldr	q19, [sp, #12960]               ; 16-byte Reload
	mov.d	x9, v19[1]
	sdiv	x22, x10, x9
	fmov	x10, d4
	fmov	x11, d19
	sdiv	x10, x10, x11
	mul	x11, x10, x11
	fmov	d19, x10
	mov.d	v19[1], x22
	mov.d	x10, v2[1]
	and.16b	v6, v12, v6
	ldr	q21, [sp, #12976]               ; 16-byte Reload
	mov.d	x12, v21[1]
	sdiv	x7, x10, x12
	fmov	x10, d2
	fmov	x23, d21
	mov.d	x15, v6[1]
	ldr	q21, [sp, #12992]               ; 16-byte Reload
	mov.d	x19, v21[1]
	sdiv	x20, x15, x19
	fmov	x15, d6
	fmov	x24, d21
	sdiv	x21, x15, x24
	mov.d	x15, v0[1]
	ldr	q21, [sp, #13008]               ; 16-byte Reload
	mov.d	x25, v21[1]
	sdiv	x15, x15, x25
	fmov	x6, d0
	fmov	x26, d21
	sdiv	x6, x6, x26
	mul	x25, x15, x25
	mul	x26, x6, x26
	fmov	d21, x26
	mov.d	v21[1], x25
	mul	x19, x20, x19
	mul	x24, x21, x24
	fmov	d23, x24
	mov.d	v23[1], x19
	mul	x12, x7, x12
	sdiv	x19, x10, x23
	mul	x10, x19, x23
	fmov	d25, x10
	mov.d	v25[1], x12
	mul	x9, x22, x9
	fmov	d28, x11
	mov.d	v28[1], x9
	sub.2d	v9, v4, v28
	sub.2d	v11, v2, v25
	sub.2d	v14, v6, v23
	sub.2d	v2, v0, v21
	ldr	q0, [sp, #13040]                ; 16-byte Reload
	cmeq.2d	v0, v0, v2
	ldr	q4, [sp, #13056]                ; 16-byte Reload
	cmeq.2d	v4, v4, v11
	uzp1.4s	v0, v4, v0
	ldr	q4, [sp, #13072]                ; 16-byte Reload
	cmeq.2d	v4, v4, v14
	ldr	q6, [sp, #13104]                ; 16-byte Reload
	cmeq.2d	v6, v6, v9
	uzp1.4s	v4, v6, v4
	uzp1.8h	v4, v4, v0
	and.16b	v0, v31, v4
	xtn.8b	v21, v0
	shl.8b	v0, v21, #7
	cmlt.8b	v0, v0, #0
	ldr	d6, [sp, #13320]                ; 8-byte Reload
	and.8b	v0, v0, v6
	addv.8b	b0, v0
	fmov	w9, s0
	shl.2d	v0, v19, #5
	ldr	q3, [sp, #10416]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #10480]                ; 16-byte Reload
	add.2d	v0, v3, v0
	movi.2d	v28, #0000000000000000
	movi.2d	v6, #0000000000000000
	tbz	w9, #0, LBB0_669
; %bb.668:                              ; %cond.load2346
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d0
	ldr	s28, [x10]
LBB0_669:                               ; %else2350
                                        ;   in Loop: Header=BB0_651 Depth=2
	tbz	w9, #1, LBB0_671
; %bb.670:                              ; %cond.load2352
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v28 }[1], [x10]
LBB0_671:                               ; %else2356
                                        ;   in Loop: Header=BB0_651 Depth=2
	ldr	x26, [sp, #11632]               ; 8-byte Reload
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	mov.16b	v25, v10
	fmov	d0, x21
	mov.d	v0[1], x20
	shl.2d	v0, v0, #5
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #10464]                ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #2, LBB0_673
; %bb.672:                              ; %cond.load2358
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d0
	ld1.s	{ v28 }[2], [x10]
LBB0_673:                               ; %else2362
                                        ;   in Loop: Header=BB0_651 Depth=2
	tbz	w9, #3, LBB0_675
; %bb.674:                              ; %cond.load2364
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v28 }[3], [x10]
LBB0_675:                               ; %else2368
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	d0, x19
	mov.d	v0[1], x7
	shl.2d	v0, v0, #5
	ldr	q3, [sp, #10512]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #10448]                ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #4, LBB0_677
; %bb.676:                              ; %cond.load2370
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d0
	ld1.s	{ v6 }[0], [x10]
LBB0_677:                               ; %else2374
                                        ;   in Loop: Header=BB0_651 Depth=2
	tbz	w9, #5, LBB0_679
; %bb.678:                              ; %cond.load2376
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v6 }[1], [x10]
LBB0_679:                               ; %else2380
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	d0, x6
	mov.d	v0[1], x15
	shl.2d	v0, v0, #5
	ldr	q3, [sp, #10496]                ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #10432]                ; 16-byte Reload
	add.2d	v23, v3, v0
	tbz	w9, #6, LBB0_681
; %bb.680:                              ; %cond.load2382
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d23
	ld1.s	{ v6 }[2], [x10]
LBB0_681:                               ; %else2386
                                        ;   in Loop: Header=BB0_651 Depth=2
	ldr	q0, [sp, #13232]                ; 16-byte Reload
	cmge.2d	v0, v30, v0
	ldr	q19, [sp, #13088]               ; 16-byte Reload
	cmge.2d	v18, v18, v19
	uzp1.4s	v0, v18, v0
	ldr	q18, [sp, #13152]               ; 16-byte Reload
	cmge.2d	v7, v7, v18
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	cmge.2d	v18, v22, v3
	uzp1.4s	v7, v18, v7
	uzp1.8h	v0, v7, v0
	and.16b	v0, v31, v0
	xtn.8b	v0, v0
	zip1.8b	v7, v17, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	ldr	q3, [sp, #10688]                ; 16-byte Reload
	bsl.16b	v7, v8, v3
	zip1.8b	v18, v0, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmge.4s	v18, v18, #0
	and.16b	v3, v18, v7
	str	q3, [sp, #10688]                ; 16-byte Spill
	ldr	q7, [sp, #13024]                ; 16-byte Reload
	ldr	q3, [sp, #10704]                ; 16-byte Reload
	bit.16b	v3, v2, v7
	str	q3, [sp, #10704]                ; 16-byte Spill
	ldr	q3, [sp, #7168]                 ; 16-byte Reload
	bit.16b	v3, v14, v12
	ldr	q7, [sp, #7152]                 ; 16-byte Reload
	bit.16b	v7, v11, v5
	ldr	q18, [sp, #7120]                ; 16-byte Reload
	bit.16b	v18, v9, v1
	bic.16b	v1, v31, v4
	xtn.8b	v1, v1
	tbz	w9, #7, LBB0_683
; %bb.682:                              ; %cond.load2388
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x9, v23[1]
	ld1.s	{ v6 }[3], [x9]
LBB0_683:                               ; %else2392
                                        ;   in Loop: Header=BB0_651 Depth=2
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	zip2.8b	v2, v21, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q4, [sp, #7056]                 ; 16-byte Reload
	bsl.16b	v2, v6, v4
	zip1.8b	v4, v21, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #7104]                 ; 16-byte Reload
	bsl.16b	v4, v28, v5
	zip1.8b	v5, v1, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v19, v5, v4
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v21, v1, v2
	ldr	q1, [sp, #10704]                ; 16-byte Reload
	xtn.2s	v1, v1
	str	q7, [sp, #7152]                 ; 16-byte Spill
	xtn.2s	v5, v7
	str	q3, [sp, #7168]                 ; 16-byte Spill
	xtn.2s	v6, v3
	str	q18, [sp, #7120]                ; 16-byte Spill
	xtn.2s	v2, v18
	mov.s	w9, v2[1]
	fmov	w10, s2
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	str	d8, [sp, #15512]
	ldrb	w12, [x12]
	and	w12, w16, w12
	str	q21, [x13, #2048]
	str	q19, [x13, #2032]
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3232
	ldr	s2, [x15, x10, lsl #2]
	tst	w11, w12
	movi.2d	v3, #0000000000000000
	fcsel	s4, s2, s3, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w17, w9
	str	q21, [x13, #2080]
	str	q19, [x13, #2064]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3264
	ldr	s2, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s2, s2, s3, ne
	mov.s	w9, v6[1]
	fmov	w10, s6
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	str	q21, [x13, #2112]
	str	q19, [x13, #2096]
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3296
	ldr	s6, [x15, x10, lsl #2]
	and	w10, w0, w12
	tst	w11, w10
	fcsel	s6, s6, s3, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w1, w9
	str	q21, [x13, #2144]
	str	q19, [x13, #2128]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3328
	ldr	s7, [x12, x11, lsl #2]
	tst	w10, w9
	mov.s	w9, v5[1]
	fcsel	s18, s7, s3, ne
	fmov	w10, s5
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	and	w12, w2, w12
	str	q21, [x13, #2176]
	str	q19, [x13, #2160]
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3360
	ldr	s5, [x15, x10, lsl #2]
	tst	w11, w12
	fcsel	s5, s5, s3, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w3, w9
	str	q21, [x13, #2208]
	str	q19, [x13, #2192]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3392
	ldr	s7, [x12, x11, lsl #2]
	tst	w10, w9
	fcsel	s7, s7, s3, ne
	mov.s	w9, v1[1]
	fmov	w10, s1
	cmp	w10, #8
	csel	w10, w10, wzr, lo
	cset	w11, lo
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w12, [x12]
	and	w12, w4, w12
	str	q21, [x13, #2240]
	str	q19, [x13, #2224]
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3424
	ldr	s1, [x15, x10, lsl #2]
	tst	w11, w12
	fcsel	s1, s1, s3, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	and	x11, x9, #0x7
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3224
	bfxil	x12, x9, #0, #3
	ldrb	w9, [x12]
	and	w9, w5, w9
	str	q21, [sp, #7056]                ; 16-byte Spill
	str	q21, [x13, #2272]
	str	q19, [sp, #7104]                ; 16-byte Spill
	str	q19, [x13, #2256]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #3456
	ldr	s19, [x12, x11, lsl #2]
	tst	w10, w9
	mov.s	v4[1], v2[0]
	mov.s	v4[2], v6[0]
	mov.s	v4[3], v18[0]
	fcsel	s2, s19, s3, ne
	ldr	q3, [sp, #10688]                ; 16-byte Reload
	fsub.4s	v4, v3, v4
	ldr	d3, [sp, #6496]                 ; 8-byte Reload
	fmov	w9, s3
	ldr	q3, [sp, #11040]                ; 16-byte Reload
	shl.2d	v6, v3, #5
	ldr	q3, [sp, #8800]                 ; 16-byte Reload
	orr.16b	v6, v6, v3
	ldr	q3, [sp, #8736]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	ldr	q14, [sp, #13024]               ; 16-byte Reload
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	ldr	q31, [sp, #13120]               ; 16-byte Reload
	tbnz	w9, #0, LBB0_692
; %bb.684:                              ; %else2398
                                        ;   in Loop: Header=BB0_651 Depth=2
	tbnz	w9, #1, LBB0_693
LBB0_685:                               ; %else2402
                                        ;   in Loop: Header=BB0_651 Depth=2
	shl.2d	v6, v25, #5
	ldr	q3, [sp, #8784]                 ; 16-byte Reload
	orr.16b	v6, v6, v3
	ldr	q3, [sp, #8720]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	tbnz	w9, #2, LBB0_694
LBB0_686:                               ; %else2406
                                        ;   in Loop: Header=BB0_651 Depth=2
	tbz	w9, #3, LBB0_688
LBB0_687:                               ; %cond.store2407
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v4 }[3], [x10]
LBB0_688:                               ; %else2410
                                        ;   in Loop: Header=BB0_651 Depth=2
	zip2.8b	v4, v17, v0
	ushll.4s	v4, v4, #0
	zip2.8b	v0, v0, v0
	shl.4s	v4, v4, #31
	ushll.4s	v0, v0, #0
	cmlt.4s	v4, v4, #0
	shl.4s	v0, v0, #31
	ldr	q3, [sp, #7136]                 ; 16-byte Reload
	bsl.16b	v4, v29, v3
	cmge.4s	v0, v0, #0
	and.16b	v0, v0, v4
	mov.s	v5[1], v7[0]
	mov.s	v5[2], v1[0]
	mov.s	v5[3], v2[0]
	str	q0, [sp, #7136]                 ; 16-byte Spill
	fsub.4s	v0, v0, v5
	shl.2d	v1, v13, #5
	ldr	q2, [sp, #8768]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #8704]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_695
; %bb.689:                              ; %else2414
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.16b	v2, v15
	tbnz	w9, #5, LBB0_696
LBB0_690:                               ; %else2418
                                        ;   in Loop: Header=BB0_651 Depth=2
	shl.2d	v1, v2, #5
	ldr	q2, [sp, #8752]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #8816]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_697
LBB0_691:                               ; %else2422
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.16b	v2, v13
	tbz	w9, #7, LBB0_650
	b	LBB0_698
LBB0_692:                               ; %cond.store2395
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d6
	str	s4, [x10]
	tbz	w9, #1, LBB0_685
LBB0_693:                               ; %cond.store2399
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v6[1]
	st1.s	{ v4 }[1], [x10]
	shl.2d	v6, v25, #5
	ldr	q3, [sp, #8784]                 ; 16-byte Reload
	orr.16b	v6, v6, v3
	ldr	q3, [sp, #8720]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	tbz	w9, #2, LBB0_686
LBB0_694:                               ; %cond.store2403
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d6
	st1.s	{ v4 }[2], [x10]
	tbnz	w9, #3, LBB0_687
	b	LBB0_688
LBB0_695:                               ; %cond.store2411
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	mov.16b	v2, v15
	tbz	w9, #5, LBB0_690
LBB0_696:                               ; %cond.store2415
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v2, #5
	ldr	q2, [sp, #8752]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #8816]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_691
LBB0_697:                               ; %cond.store2419
                                        ;   in Loop: Header=BB0_651 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	mov.16b	v2, v13
	tbz	w9, #7, LBB0_650
LBB0_698:                               ; %cond.store2423
                                        ;   in Loop: Header=BB0_651 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_650
LBB0_699:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q20, [sp, #896]                 ; 16-byte Reload
	ldr	q25, [sp, #6496]                ; 16-byte Reload
	ldr	q3, [sp, #1984]                 ; 16-byte Reload
	ldr	q16, [sp, #1216]                ; 16-byte Reload
LBB0_700:                               ; %direct.false663
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q0, [sp, #11040]                ; 16-byte Spill
	str	q3, [sp, #1984]                 ; 16-byte Spill
	str	q2, [sp, #1344]                 ; 16-byte Spill
	str	q25, [sp, #6496]                ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #336]                  ; 16-byte Reload
	ldr	q3, [sp, #8592]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8592]                 ; 16-byte Spill
	ldr	q3, [sp, #8624]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8624]                 ; 16-byte Spill
	ldr	q3, [sp, #8608]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8608]                 ; 16-byte Spill
	ldr	q3, [sp, #8640]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8640]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #8656]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8656]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #8688]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8688]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #8672]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8672]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #8576]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8576]                 ; 16-byte Spill
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	ldr	q13, [sp, #1296]                ; 16-byte Reload
	bic.16b	v13, v13, v12
	ldr	q15, [sp, #1280]                ; 16-byte Reload
	bic.16b	v15, v15, v1
	ldr	q10, [sp, #1312]                ; 16-byte Reload
	bic.16b	v10, v10, v0
	fmov	x9, d10
	cmp	x9, #9
	b.gt	LBB0_735
; %bb.701:                              ; %direct.true683.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	mvni.4s	v22, #128, lsl #24
	b	LBB0_703
LBB0_702:                               ; %else2508
                                        ;   in Loop: Header=BB0_703 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v13, v13, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v15, v15, v0
	add.2d	v3, v3, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v10, v10, v0
	fmov	x9, d10
	cmp	x9, #10
	b.ge	LBB0_736
LBB0_703:                               ; %direct.true683
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v24, #0
	sshll.2d	v28, v26, #0
	mov.16b	v17, v3
	and.16b	v1, v14, v3
	and.16b	v2, v12, v13
	and.16b	v4, v28, v15
	and.16b	v5, v0, v10
	fmov	x9, d5
	ldr	q6, [sp, #13168]                ; 16-byte Reload
	fmov	x10, d6
	sdiv	x11, x9, x10
	mov.d	x9, v5[1]
	sdiv	x12, x9, x28
	fmov	x9, d4
	ldr	q6, [sp, #13184]                ; 16-byte Reload
	fmov	x6, d6
	sdiv	x7, x9, x6
	mov.d	x9, v4[1]
	sdiv	x19, x9, x8
	fmov	x9, d2
	ldr	q6, [sp, #13200]                ; 16-byte Reload
	fmov	x22, d6
	sdiv	x20, x9, x22
	mov.d	x9, v2[1]
	sdiv	x21, x9, x30
	fmov	x9, d1
	ldr	q6, [sp, #13216]                ; 16-byte Reload
	fmov	x23, d6
	sdiv	x9, x9, x23
	mov.d	x15, v1[1]
	sdiv	x15, x15, x14
	mul	x10, x11, x10
	fmov	d6, x10
	mul	x10, x12, x28
	mov.d	v6[1], x10
	mul	x10, x21, x30
	mul	x22, x20, x22
	fmov	d7, x22
	mov.d	v7[1], x10
	mul	x10, x19, x8
	mul	x6, x7, x6
	fmov	d18, x6
	mov.d	v18[1], x10
	mul	x10, x15, x14
	mul	x6, x9, x23
	fmov	d19, x6
	mov.d	v19[1], x10
	sub.2d	v21, v1, v19
	sub.2d	v23, v4, v18
	sub.2d	v25, v2, v7
	sub.2d	v1, v5, v6
	shl.2d	v4, v1, #3
	shl.2d	v5, v25, #3
	shl.2d	v6, v23, #3
	shl.2d	v7, v21, #3
	ldr	q2, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v2, v2, v7
	cmgt.2d	v18, v9, v6
	uzp1.4s	v2, v18, v2
	cmgt.2d	v18, v30, v5
	cmgt.2d	v19, v31, v4
	uzp1.4s	v18, v19, v18
	fmov	d19, x11
	mov.d	v19[1], x12
	uzp1.8h	v2, v18, v2
	and.16b	v0, v0, v19
	mov.d	x10, v0[1]
	ldr	x12, [sp, #11736]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	x11, d0
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	fmov	x12, d0
	sdiv	x6, x11, x12
	msub	x11, x6, x12, x11
	add	x11, x11, x11, lsl #2
	fmov	d0, x11
	add	x10, x10, x10, lsl #2
	mov.d	v0[1], x10
	add.2d	v1, v0, v1
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	and.16b	v0, v0, v2
	xtn.8b	v0, v0
	shl.8b	v2, v0, #7
	cmlt.8b	v2, v2, #0
	ldr	d18, [sp, #13320]               ; 8-byte Reload
	and.8b	v2, v2, v18
	addv.8b	b2, v2
	fmov	w6, s2
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #8800]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #8736]                 ; 16-byte Reload
	add.2d	v29, v3, v1
	movi.2d	v18, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w6, #0, LBB0_705
; %bb.704:                              ; %cond.load2428
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	x10, d29
	ldr	s18, [x10]
LBB0_705:                               ; %else2432
                                        ;   in Loop: Header=BB0_703 Depth=2
	tbz	w6, #1, LBB0_707
; %bb.706:                              ; %cond.load2434
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.d	x10, v29[1]
	ld1.s	{ v18 }[1], [x10]
LBB0_707:                               ; %else2438
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	d19, x20
	mov.d	v19[1], x21
	and.16b	v19, v12, v19
	mov.d	x10, v19[1]
	sdiv	x11, x10, x25
	msub	x10, x11, x25, x10
	fmov	x11, d19
	ldr	q19, [sp, #11680]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x20, x11, x12
	msub	x11, x20, x12, x11
	add	x11, x11, x11, lsl #2
	fmov	d19, x11
	add	x10, x10, x10, lsl #2
	mov.d	v19[1], x10
	add.2d	v19, v19, v25
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #8784]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #8720]                 ; 16-byte Reload
	add.2d	v25, v3, v19
	tbz	w6, #2, LBB0_709
; %bb.708:                              ; %cond.load2440
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	x10, d25
	ld1.s	{ v18 }[2], [x10]
LBB0_709:                               ; %else2444
                                        ;   in Loop: Header=BB0_703 Depth=2
	tbz	w6, #3, LBB0_711
; %bb.710:                              ; %cond.load2446
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.d	x10, v25[1]
	ld1.s	{ v18 }[3], [x10]
LBB0_711:                               ; %else2450
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	d19, x7
	mov.d	v19[1], x19
	and.16b	v19, v28, v19
	mov.d	x10, v19[1]
	sdiv	x11, x10, x26
	msub	x10, x11, x26, x10
	fmov	x11, d19
	ldr	q19, [sp, #11696]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x7, x11, x12
	msub	x11, x7, x12, x11
	add	x11, x11, x11, lsl #2
	fmov	d19, x11
	add	x10, x10, x10, lsl #2
	mov.d	v19[1], x10
	add.2d	v19, v19, v23
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #8768]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #8704]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w6, #4, LBB0_713
; %bb.712:                              ; %cond.load2452
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	x10, d23
	ld1.s	{ v1 }[0], [x10]
LBB0_713:                               ; %else2456
                                        ;   in Loop: Header=BB0_703 Depth=2
	tbz	w6, #5, LBB0_715
; %bb.714:                              ; %cond.load2458
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v1 }[1], [x10]
LBB0_715:                               ; %else2462
                                        ;   in Loop: Header=BB0_703 Depth=2
	movi.4s	v23, #75, lsl #24
	fmov	d19, x9
	mov.d	v19[1], x15
	and.16b	v19, v14, v19
	mov.d	x9, v19[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d19
	ldr	q19, [sp, #11664]               ; 16-byte Reload
	fmov	x11, d19
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	add	x10, x10, x10, lsl #2
	fmov	d19, x10
	add	x9, x9, x9, lsl #2
	mov.d	v19[1], x9
	add.2d	v19, v19, v21
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #8752]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #8816]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w6, #6, LBB0_717
; %bb.716:                              ; %cond.load2464
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	x9, d21
	ld1.s	{ v1 }[2], [x9]
LBB0_717:                               ; %else2468
                                        ;   in Loop: Header=BB0_703 Depth=2
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmge.2d	v7, v7, v3
	cmge.2d	v6, v6, v9
	uzp1.4s	v6, v6, v7
	cmge.2d	v5, v5, v30
	cmge.2d	v4, v4, v31
	uzp1.4s	v4, v4, v5
	uzp1.8h	v4, v4, v6
	ldr	q5, [sp, #13328]                ; 16-byte Reload
	and.16b	v4, v5, v4
	xtn.8b	v4, v4
	tbz	w6, #7, LBB0_719
; %bb.718:                              ; %cond.load2470
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v1 }[3], [x9]
LBB0_719:                               ; %else2474
                                        ;   in Loop: Header=BB0_703 Depth=2
	zip1.8b	v5, v0, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q3, [sp, #7088]                 ; 16-byte Reload
	bsl.16b	v5, v18, v3
	zip1.8b	v6, v4, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmge.4s	v6, v6, #0
	and.16b	v3, v6, v5
	str	q3, [sp, #7088]                 ; 16-byte Spill
	and.16b	v5, v24, v3
	fcmge.4s	v6, v5, v27
	ldr	q21, [sp, #11376]               ; 16-byte Reload
	fcmge.4s	v7, v21, v5
	and.16b	v6, v6, v7
	and.16b	v6, v6, v5
	ldr	q3, [sp, #11360]                ; 16-byte Reload
	fmul.4s	v7, v6, v3
	mov.16b	v18, v22
	bsl.16b	v18, v23, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v7, v7
	scvtf.4s	v18, v7
	ldr	q3, [sp, #11344]                ; 16-byte Reload
	fmul.4s	v19, v18, v3
	fadd.4s	v6, v6, v19
	ldr	q3, [sp, #11328]                ; 16-byte Reload
	fmul.4s	v18, v18, v3
	fadd.4s	v6, v6, v18
	ldr	q3, [sp, #11312]                ; 16-byte Reload
	fmul.4s	v18, v6, v3
	ldr	q3, [sp, #11296]                ; 16-byte Reload
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v6, v18
	ldr	q3, [sp, #11280]                ; 16-byte Reload
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v6, v18
	ldr	q3, [sp, #11264]                ; 16-byte Reload
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v6, v18
	ldr	q3, [sp, #11248]                ; 16-byte Reload
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v6, v18
	movi.4s	v3, #63, lsl #24
	fadd.4s	v18, v18, v3
	fmul.4s	v19, v6, v6
	fmul.4s	v18, v19, v18
	fadd.4s	v6, v6, v18
	fmov.4s	v3, #1.00000000
	fadd.4s	v6, v6, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v6, v6, v19
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v6, v6, v7
	fcmgt.4s	v7, v27, v5
	bic.16b	v6, v6, v7
	fcmgt.4s	v7, v5, v21
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	bit.16b	v6, v18, v7
	fcmeq.4s	v5, v5, v5
	ldr	q7, [sp, #11216]                ; 16-byte Reload
	bsl.16b	v5, v6, v7
	fmov	w9, s2
	shl.2d	v2, v10, #5
	ldr	q3, [sp, #8576]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #8640]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #0, LBB0_728
; %bb.720:                              ; %else2480
                                        ;   in Loop: Header=BB0_703 Depth=2
	tbnz	w9, #1, LBB0_729
LBB0_721:                               ; %else2484
                                        ;   in Loop: Header=BB0_703 Depth=2
	shl.2d	v2, v13, #5
	ldr	q3, [sp, #8688]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #8624]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w9, #2, LBB0_730
LBB0_722:                               ; %else2488
                                        ;   in Loop: Header=BB0_703 Depth=2
	tbz	w9, #3, LBB0_724
LBB0_723:                               ; %cond.store2489
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.d	x10, v2[1]
	st1.s	{ v5 }[3], [x10]
LBB0_724:                               ; %else2492
                                        ;   in Loop: Header=BB0_703 Depth=2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q2, [sp, #7072]                 ; 16-byte Reload
	bsl.16b	v0, v1, v2
	zip2.8b	v1, v4, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #7072]                 ; 16-byte Spill
	and.16b	v0, v26, v0
	fcmge.4s	v1, v0, v27
	ldr	q6, [sp, #11376]                ; 16-byte Reload
	fcmge.4s	v2, v6, v0
	and.16b	v1, v1, v2
	and.16b	v1, v1, v0
	ldr	q2, [sp, #11360]                ; 16-byte Reload
	fmul.4s	v2, v1, v2
	mov.16b	v4, v22
	bsl.16b	v4, v23, v2
	fadd.4s	v2, v2, v4
	fsub.4s	v2, v2, v4
	fcvtzs.4s	v2, v2
	scvtf.4s	v4, v2
	ldr	q3, [sp, #11344]                ; 16-byte Reload
	fmul.4s	v5, v4, v3
	fadd.4s	v1, v1, v5
	ldr	q3, [sp, #11328]                ; 16-byte Reload
	fmul.4s	v4, v4, v3
	fadd.4s	v1, v1, v4
	ldr	q3, [sp, #11312]                ; 16-byte Reload
	fmul.4s	v4, v1, v3
	ldr	q3, [sp, #11296]                ; 16-byte Reload
	fadd.4s	v4, v4, v3
	fmul.4s	v4, v1, v4
	ldr	q3, [sp, #11280]                ; 16-byte Reload
	fadd.4s	v4, v4, v3
	fmul.4s	v4, v1, v4
	ldr	q3, [sp, #11264]                ; 16-byte Reload
	fadd.4s	v4, v4, v3
	fmul.4s	v4, v1, v4
	ldr	q3, [sp, #11248]                ; 16-byte Reload
	fadd.4s	v4, v4, v3
	fmul.4s	v4, v1, v4
	movi.4s	v3, #63, lsl #24
	fadd.4s	v4, v4, v3
	fmul.4s	v5, v1, v1
	fmul.4s	v4, v5, v4
	fadd.4s	v1, v1, v4
	fmov.4s	v3, #1.00000000
	fadd.4s	v1, v1, v3
	sshr.4s	v4, v2, #1
	shl.4s	v5, v4, #23
	add.4s	v5, v5, v3
	fmul.4s	v1, v1, v5
	sub.4s	v2, v2, v4
	shl.4s	v2, v2, #23
	add.4s	v2, v2, v3
	fmul.4s	v1, v1, v2
	fcmgt.4s	v2, v27, v0
	bic.16b	v1, v1, v2
	fcmgt.4s	v2, v0, v6
	ldr	q4, [sp, #11232]                ; 16-byte Reload
	bit.16b	v1, v4, v2
	fcmeq.4s	v0, v0, v0
	ldr	q2, [sp, #11216]                ; 16-byte Reload
	bsl.16b	v0, v1, v2
	shl.2d	v1, v15, #5
	ldr	q2, [sp, #8672]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #8608]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_731
; %bb.725:                              ; %else2496
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.16b	v3, v17
	tbnz	w9, #5, LBB0_732
LBB0_726:                               ; %else2500
                                        ;   in Loop: Header=BB0_703 Depth=2
	shl.2d	v1, v3, #5
	ldr	q2, [sp, #8656]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #8592]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_733
LBB0_727:                               ; %else2504
                                        ;   in Loop: Header=BB0_703 Depth=2
	tbz	w9, #7, LBB0_702
	b	LBB0_734
LBB0_728:                               ; %cond.store2477
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	x10, d2
	str	s5, [x10]
	tbz	w9, #1, LBB0_721
LBB0_729:                               ; %cond.store2481
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.d	x10, v2[1]
	st1.s	{ v5 }[1], [x10]
	shl.2d	v2, v13, #5
	ldr	q3, [sp, #8688]                 ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #8624]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w9, #2, LBB0_722
LBB0_730:                               ; %cond.store2485
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	x10, d2
	st1.s	{ v5 }[2], [x10]
	tbnz	w9, #3, LBB0_723
	b	LBB0_724
LBB0_731:                               ; %cond.store2493
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	mov.16b	v3, v17
	tbz	w9, #5, LBB0_726
LBB0_732:                               ; %cond.store2497
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v3, #5
	ldr	q2, [sp, #8656]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #8592]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_727
LBB0_733:                               ; %cond.store2501
                                        ;   in Loop: Header=BB0_703 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_702
LBB0_734:                               ; %cond.store2505
                                        ;   in Loop: Header=BB0_703 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_702
LBB0_735:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q30, [sp, #13152]               ; 16-byte Reload
LBB0_736:                               ; %direct.false684
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q3, [sp, #1328]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #320]                  ; 16-byte Reload
	ldr	q3, [sp, #12800]                ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #12800]                ; 16-byte Spill
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #12832]                ; 16-byte Spill
	ldr	q3, [sp, #12816]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #12816]                ; 16-byte Spill
	ldr	q3, [sp, #12736]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #12736]                ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #12848]                ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #12848]                ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #12768]                ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #12768]                ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #12752]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #12752]                ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #12784]                ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #12784]                ; 16-byte Spill
	bic.16b	v16, v16, v14
	ldr	q2, [sp, #1248]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	ldr	q6, [sp, #1232]                 ; 16-byte Reload
	bic.16b	v6, v6, v1
	ldr	q3, [sp, #1264]                 ; 16-byte Reload
	bic.16b	v3, v3, v0
	fmov	x9, d3
	cmp	x9, #9
	ldr	d27, [sp, #11624]               ; 8-byte Reload
	b.gt	LBB0_787
; %bb.737:                              ; %direct.true696.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	mov.16b	v17, v31
	mov.16b	v0, v2
	b	LBB0_739
LBB0_738:                               ; %else2639
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v22, v22, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v6, v16, v0
	add.2d	v16, v31, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v3, v25, v0
	fmov	x9, d3
	cmp	x9, #10
	mov.16b	v0, v22
	b.ge	LBB0_788
LBB0_739:                               ; %direct.true696
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v1, v24, #0
	sshll.2d	v2, v26, #0
	mov.16b	v31, v16
	and.16b	v4, v14, v16
	mov.16b	v22, v0
	and.16b	v5, v12, v0
	mov.16b	v16, v6
	and.16b	v0, v2, v6
	mov.16b	v25, v3
	and.16b	v6, v1, v3
	fmov	x9, d6
	ldr	q7, [sp, #13168]                ; 16-byte Reload
	fmov	x10, d7
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	fmov	d7, x9
	mov.d	x9, v6[1]
	sdiv	x11, x9, x28
	mov.d	v7[1], x11
	fmov	x9, d0
	ldr	q18, [sp, #13184]               ; 16-byte Reload
	fmov	x12, d18
	sdiv	x7, x9, x12
	mov.d	x6, v0[1]
	fmov	x9, d5
	ldr	q18, [sp, #13200]               ; 16-byte Reload
	fmov	x19, d18
	mov.d	x21, v5[1]
	sdiv	x20, x9, x19
	fmov	x9, d4
	ldr	q18, [sp, #13216]               ; 16-byte Reload
	fmov	x22, d18
	sdiv	x9, x9, x22
	mov.d	x15, v4[1]
	sdiv	x15, x15, x14
	mul	x23, x15, x14
	mul	x22, x9, x22
	fmov	d18, x22
	mov.d	v18[1], x23
	sdiv	x21, x21, x30
	mul	x22, x21, x30
	mul	x19, x20, x19
	fmov	d19, x19
	mov.d	v19[1], x22
	sdiv	x19, x6, x8
	mul	x6, x19, x8
	mul	x12, x7, x12
	fmov	d23, x12
	mov.d	v23[1], x6
	mul	x11, x11, x28
	fmov	d21, x10
	mov.d	v21[1], x11
	sub.2d	v21, v6, v21
	sub.2d	v0, v0, v23
	sub.2d	v5, v5, v19
	sub.2d	v18, v4, v18
	shl.2d	v4, v21, #3
	shl.2d	v6, v5, #3
	shl.2d	v19, v0, #3
	shl.2d	v23, v18, #3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	cmgt.2d	v23, v3, v23
	cmgt.2d	v19, v9, v19
	uzp1.4s	v19, v19, v23
	cmgt.2d	v6, v30, v6
	cmgt.2d	v4, v17, v4
	uzp1.4s	v4, v4, v6
	uzp1.8h	v28, v4, v19
	ldr	q4, [sp, #13328]                ; 16-byte Reload
	and.16b	v4, v4, v28
	xtn.8b	v4, v4
	and.16b	v6, v1, v7
	mov.d	x10, v6[1]
	ldr	x12, [sp, #11736]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	x11, d6
	ldr	q6, [sp, #11712]                ; 16-byte Reload
	fmov	x12, d6
	sdiv	x6, x11, x12
	msub	x11, x6, x12, x11
	fmov	d30, x11
	mov.d	v30[1], x10
	shl.8b	v6, v4, #7
	cmlt.8b	v6, v6, #0
	ldr	d7, [sp, #13320]                ; 8-byte Reload
	and.8b	v7, v6, v7
	addv.8b	b7, v7
	fmov	w6, s7
	add.2d	v7, v21, v21
	ldr	q3, [sp, #11104]                ; 16-byte Reload
	add.2d	v7, v7, v3
	ldr	q3, [sp, #11168]                ; 16-byte Reload
	add.2d	v7, v3, v7
	add.2d	v23, v7, v30
	tbz	w6, #0, LBB0_741
; %bb.740:                              ; %cond.load2510
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d23
	ldr	b7, [x10]
	tbnz	w6, #1, LBB0_742
	b	LBB0_743
LBB0_741:                               ;   in Loop: Header=BB0_739 Depth=2
	movi.2d	v7, #0000000000000000
	tbz	w6, #1, LBB0_743
LBB0_742:                               ; %cond.load2516
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v23[1]
	ld1.b	{ v7 }[1], [x10]
LBB0_743:                               ; %else2520
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	d19, x20
	mov.d	v19[1], x21
	and.16b	v19, v12, v19
	mov.d	x10, v19[1]
	sdiv	x11, x10, x25
	msub	x10, x11, x25, x10
	fmov	x11, d19
	ldr	q19, [sp, #11680]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x20, x11, x12
	msub	x11, x20, x12, x11
	fmov	d29, x11
	mov.d	v29[1], x10
	add.2d	v19, v5, v5
	ldr	q3, [sp, #11088]                ; 16-byte Reload
	add.2d	v19, v19, v3
	ldr	q3, [sp, #11152]                ; 16-byte Reload
	add.2d	v19, v3, v19
	add.2d	v23, v19, v29
	tbz	w6, #2, LBB0_745
; %bb.744:                              ; %cond.load2522
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d23
	ld1.b	{ v7 }[2], [x10]
LBB0_745:                               ; %else2526
                                        ;   in Loop: Header=BB0_739 Depth=2
	tbz	w6, #3, LBB0_747
; %bb.746:                              ; %cond.load2528
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v23[1]
	ld1.b	{ v7 }[3], [x10]
LBB0_747:                               ; %else2532
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	d19, x7
	mov.d	v19[1], x19
	and.16b	v19, v2, v19
	mov.d	x10, v19[1]
	sdiv	x11, x10, x26
	msub	x10, x11, x26, x10
	fmov	x11, d19
	ldr	q19, [sp, #11696]               ; 16-byte Reload
	fmov	x12, d19
	sdiv	x7, x11, x12
	msub	x11, x7, x12, x11
	fmov	d8, x11
	mov.d	v8[1], x10
	add.2d	v19, v0, v0
	ldr	q3, [sp, #11200]                ; 16-byte Reload
	add.2d	v19, v19, v3
	ldr	q3, [sp, #11136]                ; 16-byte Reload
	add.2d	v19, v3, v19
	add.2d	v23, v19, v8
	tbz	w6, #4, LBB0_749
; %bb.748:                              ; %cond.load2534
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d23
	ld1.b	{ v7 }[4], [x10]
LBB0_749:                               ; %else2538
                                        ;   in Loop: Header=BB0_739 Depth=2
	tbz	w6, #5, LBB0_751
; %bb.750:                              ; %cond.load2540
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v23[1]
	ld1.b	{ v7 }[5], [x10]
LBB0_751:                               ; %else2544
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	d19, x9
	mov.d	v19[1], x15
	and.16b	v19, v14, v19
	mov.d	x9, v19[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d19
	ldr	q19, [sp, #11664]               ; 16-byte Reload
	fmov	x11, d19
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d9, x10
	mov.d	v9[1], x9
	add.2d	v19, v18, v18
	ldr	q3, [sp, #11184]                ; 16-byte Reload
	add.2d	v19, v19, v3
	ldr	q3, [sp, #11120]                ; 16-byte Reload
	add.2d	v19, v3, v19
	add.2d	v23, v19, v9
	tbz	w6, #6, LBB0_753
; %bb.752:                              ; %cond.load2546
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x9, d23
	ld1.b	{ v7 }[6], [x9]
LBB0_753:                               ; %else2550
                                        ;   in Loop: Header=BB0_739 Depth=2
	tbz	w6, #7, LBB0_755
; %bb.754:                              ; %cond.load2552
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x9, v23[1]
	ld1.b	{ v7 }[7], [x9]
LBB0_755:                               ; %else2556
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	q3, [sp, #6976]                 ; 16-byte Reload
	bit.16b	v3, v21, v1
	ldr	q19, [sp, #6928]                ; 16-byte Reload
	bit.16b	v19, v30, v1
	xtn.8b	v28, v28
	fmov	x9, d19
	add	x9, x9, x9, lsl #2
	fmov	d1, x9
	str	q19, [sp, #6928]                ; 16-byte Spill
	mov.d	x9, v19[1]
	add	x9, x9, x9, lsl #2
	mov.d	v1[1], x9
	str	q3, [sp, #6976]                 ; 16-byte Spill
	add.2d	v19, v1, v3
	ldr	q1, [sp, #13136]                ; 16-byte Reload
	and.8b	v1, v1, v28
	shl.8b	v21, v1, #7
	cmlt.8b	v21, v21, #0
	ldr	d23, [sp, #13320]               ; 8-byte Reload
	and.8b	v21, v21, v23
	addv.8b	b30, v21
	fmov	w9, s30
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #8576]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #8640]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	movi.2d	v11, #0000000000000000
	movi.2d	v21, #0000000000000000
	tbz	w9, #0, LBB0_757
; %bb.756:                              ; %cond.load2559
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d23
	ldr	s11, [x10]
LBB0_757:                               ; %else2563
                                        ;   in Loop: Header=BB0_739 Depth=2
	tbz	w9, #1, LBB0_759
; %bb.758:                              ; %cond.load2565
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v23[1]
	ld1.s	{ v11 }[1], [x10]
LBB0_759:                               ; %else2569
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	q3, [sp, #6960]                 ; 16-byte Reload
	bit.16b	v3, v5, v12
	ldr	q19, [sp, #6912]                ; 16-byte Reload
	bit.16b	v19, v29, v12
	fmov	x10, d19
	add	x10, x10, x10, lsl #2
	fmov	d5, x10
	str	q19, [sp, #6912]                ; 16-byte Spill
	mov.d	x10, v19[1]
	add	x10, x10, x10, lsl #2
	mov.d	v5[1], x10
	str	q3, [sp, #6960]                 ; 16-byte Spill
	add.2d	v5, v5, v3
	shl.2d	v5, v5, #5
	ldr	q3, [sp, #8688]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #8624]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #2, LBB0_761
; %bb.760:                              ; %cond.load2571
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d5
	ld1.s	{ v11 }[2], [x10]
LBB0_761:                               ; %else2575
                                        ;   in Loop: Header=BB0_739 Depth=2
	tbz	w9, #3, LBB0_763
; %bb.762:                              ; %cond.load2577
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v11 }[3], [x10]
LBB0_763:                               ; %else2581
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	q5, [sp, #6944]                 ; 16-byte Reload
	bit.16b	v5, v0, v2
	ldr	q3, [sp, #7024]                 ; 16-byte Reload
	bit.16b	v3, v8, v2
	fmov	x10, d3
	add	x10, x10, x10, lsl #2
	fmov	d0, x10
	str	q3, [sp, #7024]                 ; 16-byte Spill
	mov.d	x10, v3[1]
	add	x10, x10, x10, lsl #2
	mov.d	v0[1], x10
	str	q5, [sp, #6944]                 ; 16-byte Spill
	add.2d	v0, v0, v5
	shl.2d	v0, v0, #5
	ldr	q2, [sp, #8672]                 ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #8608]                 ; 16-byte Reload
	add.2d	v0, v2, v0
	tbz	w9, #4, LBB0_765
; %bb.764:                              ; %cond.load2583
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d0
	ld1.s	{ v21 }[0], [x10]
LBB0_765:                               ; %else2587
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	d27, [sp, #11624]               ; 8-byte Reload
	tbz	w9, #5, LBB0_767
; %bb.766:                              ; %cond.load2589
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v0[1]
	ld1.s	{ v21 }[1], [x10]
LBB0_767:                               ; %else2593
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	q2, [sp, #7040]                 ; 16-byte Reload
	bit.16b	v2, v18, v14
	ldr	q3, [sp, #7008]                 ; 16-byte Reload
	bit.16b	v3, v9, v14
	fmov	x10, d3
	add	x10, x10, x10, lsl #2
	fmov	d0, x10
	str	q3, [sp, #7008]                 ; 16-byte Spill
	mov.d	x10, v3[1]
	add	x10, x10, x10, lsl #2
	mov.d	v0[1], x10
	str	q2, [sp, #7040]                 ; 16-byte Spill
	add.2d	v0, v0, v2
	shl.2d	v0, v0, #5
	ldr	q2, [sp, #8656]                 ; 16-byte Reload
	orr.16b	v0, v0, v2
	ldr	q2, [sp, #8592]                 ; 16-byte Reload
	add.2d	v0, v2, v0
	tbz	w9, #6, LBB0_769
; %bb.768:                              ; %cond.load2595
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d0
	ld1.s	{ v21 }[2], [x10]
LBB0_769:                               ; %else2599
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	tbz	w9, #7, LBB0_771
; %bb.770:                              ; %cond.load2601
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v21 }[3], [x9]
LBB0_771:                               ; %else2605
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	q0, [sp, #6992]                 ; 16-byte Reload
	mov.16b	v17, v8
	bic.8b	v0, v0, v17
	orr.8b	v3, v4, v0
	cmtst.8b	v0, v7, v7
	ldr	q2, [sp, #10672]                ; 16-byte Reload
	bif.8b	v0, v2, v6
	ldr	d2, [sp, #11616]                ; 8-byte Reload
	orr.8b	v2, v28, v2
	and.8b	v5, v2, v0
	str	q3, [sp, #6992]                 ; 16-byte Spill
	bic.8b	v0, v17, v3
	fmov	w9, s30
	zip1.8b	v2, v1, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	ldr	q3, [sp, #6896]                 ; 16-byte Reload
	bsl.16b	v2, v11, v3
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v4, v4, #0
	and.16b	v3, v4, v2
	str	q5, [sp, #10672]                ; 16-byte Spill
	zip1.8b	v2, v5, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	str	q3, [sp, #6896]                 ; 16-byte Spill
	and.16b	v2, v2, v3
	shl.2d	v4, v25, #5
	ldr	q3, [sp, #12784]                ; 16-byte Reload
	orr.16b	v4, v4, v3
	ldr	q3, [sp, #12736]                ; 16-byte Reload
	add.2d	v4, v3, v4
	tbnz	w9, #0, LBB0_780
; %bb.772:                              ; %else2611
                                        ;   in Loop: Header=BB0_739 Depth=2
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	ldr	q17, [sp, #13120]               ; 16-byte Reload
	tbnz	w9, #1, LBB0_781
LBB0_773:                               ; %else2615
                                        ;   in Loop: Header=BB0_739 Depth=2
	shl.2d	v4, v22, #5
	ldr	q3, [sp, #12768]                ; 16-byte Reload
	orr.16b	v4, v4, v3
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	add.2d	v4, v3, v4
	tbnz	w9, #2, LBB0_782
LBB0_774:                               ; %else2619
                                        ;   in Loop: Header=BB0_739 Depth=2
	tbz	w9, #3, LBB0_776
LBB0_775:                               ; %cond.store2620
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v4[1]
	st1.s	{ v2 }[3], [x10]
LBB0_776:                               ; %else2623
                                        ;   in Loop: Header=BB0_739 Depth=2
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q2, [sp, #6880]                 ; 16-byte Reload
	bsl.16b	v1, v21, v2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v1, v0, v1
	ldr	q0, [sp, #10672]                ; 16-byte Reload
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q1, [sp, #6880]                 ; 16-byte Spill
	and.16b	v0, v0, v1
	shl.2d	v1, v16, #5
	ldr	q2, [sp, #12752]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #12816]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_783
; %bb.777:                              ; %else2627
                                        ;   in Loop: Header=BB0_739 Depth=2
	tbnz	w9, #5, LBB0_784
LBB0_778:                               ; %else2631
                                        ;   in Loop: Header=BB0_739 Depth=2
	shl.2d	v1, v31, #5
	ldr	q2, [sp, #12848]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_785
LBB0_779:                               ; %else2635
                                        ;   in Loop: Header=BB0_739 Depth=2
	tbz	w9, #7, LBB0_738
	b	LBB0_786
LBB0_780:                               ; %cond.store2608
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d4
	str	s2, [x10]
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	ldr	q17, [sp, #13120]               ; 16-byte Reload
	tbz	w9, #1, LBB0_773
LBB0_781:                               ; %cond.store2612
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v4[1]
	st1.s	{ v2 }[1], [x10]
	shl.2d	v4, v22, #5
	ldr	q3, [sp, #12768]                ; 16-byte Reload
	orr.16b	v4, v4, v3
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	add.2d	v4, v3, v4
	tbz	w9, #2, LBB0_774
LBB0_782:                               ; %cond.store2616
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d4
	st1.s	{ v2 }[2], [x10]
	tbnz	w9, #3, LBB0_775
	b	LBB0_776
LBB0_783:                               ; %cond.store2624
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	tbz	w9, #5, LBB0_778
LBB0_784:                               ; %cond.store2628
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v31, #5
	ldr	q2, [sp, #12848]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #12800]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_779
LBB0_785:                               ; %cond.store2632
                                        ;   in Loop: Header=BB0_739 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_738
LBB0_786:                               ; %cond.store2636
                                        ;   in Loop: Header=BB0_739 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_738
LBB0_787:                               ;   in Loop: Header=BB0_91 Depth=1
	mov.16b	v0, v2
LBB0_788:                               ; %direct.false697
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q16, [sp, #1216]                ; 16-byte Spill
	str	q6, [sp, #1232]                 ; 16-byte Spill
	str	q0, [sp, #1248]                 ; 16-byte Spill
	str	q3, [sp, #1264]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #304]                  ; 16-byte Reload
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #3136]                 ; 16-byte Spill
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #3168]                 ; 16-byte Spill
	ldr	q3, [sp, #3152]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3152]                 ; 16-byte Spill
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3072]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #3184]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #3184]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #3104]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #3088]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #3120]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #3120]                 ; 16-byte Spill
	ldr	q2, [sp, #10016]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #10016]                ; 16-byte Spill
	ldr	q2, [sp, #10048]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #10048]                ; 16-byte Spill
	ldr	q2, [sp, #10032]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10032]                ; 16-byte Spill
	ldr	q28, [sp, #1200]                ; 16-byte Reload
	bic.16b	v28, v28, v0
	fmov	x9, d28
	cmp	x9, #1
	b.lt	LBB0_1333
; %bb.789:                              ;   in Loop: Header=BB0_91 Depth=1
	ldr	q16, [sp, #880]                 ; 16-byte Reload
	ldr	q25, [sp, #11056]               ; 16-byte Reload
LBB0_790:                               ; %direct.false717
                                        ;   in Loop: Header=BB0_91 Depth=1
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #288]                  ; 16-byte Reload
	ldr	q3, [sp, #6016]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #6016]                 ; 16-byte Spill
	ldr	q3, [sp, #6048]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #6048]                 ; 16-byte Spill
	ldr	q3, [sp, #6032]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #6032]                 ; 16-byte Spill
	ldr	q3, [sp, #6064]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #6064]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #6080]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #6080]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #5984]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #5984]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #6096]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #6096]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #6000]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #6000]                 ; 16-byte Spill
	ldr	q4, [sp, #8544]                 ; 16-byte Reload
	bic.16b	v4, v4, v14
	ldr	q2, [sp, #9856]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #9856]                 ; 16-byte Spill
	ldr	q2, [sp, #9840]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #9840]                 ; 16-byte Spill
	ldr	q3, [sp, #8560]                 ; 16-byte Reload
	bic.16b	v3, v3, v0
	fmov	x9, d3
	cmp	x9, #1
	str	q10, [sp, #1312]                ; 16-byte Spill
	str	q13, [sp, #1296]                ; 16-byte Spill
	str	q15, [sp, #1280]                ; 16-byte Spill
	str	q28, [sp, #1200]                ; 16-byte Spill
	b.gt	LBB0_829
; %bb.791:                              ; %direct.true731.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q6, [sp, #9856]                 ; 16-byte Reload
	ldr	q5, [sp, #9840]                 ; 16-byte Reload
	b	LBB0_793
LBB0_792:                               ; %else2852
                                        ;   in Loop: Header=BB0_793 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v6, v6, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v5, v5, v0
	add.2d	v4, v4, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v3, v3, v0
	fmov	x9, d3
	cmp	x9, #2
	b.ge	LBB0_830
LBB0_793:                               ; %direct.true731
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_796 Depth 3
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	str	q4, [sp, #8544]                 ; 16-byte Spill
	and.16b	v2, v14, v4
	str	q3, [sp, #8560]                 ; 16-byte Spill
	and.16b	v4, v0, v3
	mov.d	x9, v4[1]
	ldr	x11, [sp, #11736]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d4
	ldr	q4, [sp, #11712]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	str	q5, [sp, #9840]                 ; 16-byte Spill
	and.16b	v5, v1, v5
	mov.d	x9, v5[1]
	sdiv	x10, x9, x26
	msub	x9, x10, x26, x9
	fmov	x10, d5
	ldr	q5, [sp, #11696]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d5, x10
	mov.d	v5[1], x9
	str	q6, [sp, #9856]                 ; 16-byte Spill
	and.16b	v6, v12, v6
	mov.d	x9, v6[1]
	sdiv	x10, x9, x25
	msub	x9, x10, x25, x9
	fmov	x10, d6
	ldr	q6, [sp, #11680]                ; 16-byte Reload
	fmov	x11, d6
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	mov.d	x9, v2[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d2
	ldr	q2, [sp, #11664]                ; 16-byte Reload
	fmov	x11, d2
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	ldr	q7, [sp, #6848]                 ; 16-byte Reload
	bit.16b	v7, v2, v14
	ldr	q17, [sp, #6784]                ; 16-byte Reload
	bit.16b	v17, v6, v12
	ldr	q3, [sp, #6864]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	ldr	q2, [sp, #6800]                 ; 16-byte Reload
	bif.16b	v4, v2, v0
	ldr	q2, [sp, #11440]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #11440]                ; 16-byte Spill
	ldr	q2, [sp, #11456]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #11456]                ; 16-byte Spill
	ldr	q8, [sp, #6816]                 ; 16-byte Reload
	bic.16b	v8, v8, v1
	ldr	q1, [sp, #6832]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	ldr	q0, [sp, #12896]                ; 16-byte Reload
	bic.16b	v0, v0, v26
	str	q0, [sp, #12896]                ; 16-byte Spill
	ldr	q0, [sp, #12912]                ; 16-byte Reload
	bic.16b	v0, v0, v24
	str	q0, [sp, #12912]                ; 16-byte Spill
	ldr	d0, [sp, #11616]                ; 8-byte Reload
	ldr	q2, [sp, #12928]                ; 16-byte Reload
	and.8b	v2, v0, v2
	str	q2, [sp, #12928]                ; 16-byte Spill
	mov.16b	v25, v1
	fmov	x9, d1
	cmp	x9, #4
	str	q3, [sp, #6864]                 ; 16-byte Spill
	str	q7, [sp, #6848]                 ; 16-byte Spill
	str	q4, [sp, #6800]                 ; 16-byte Spill
	str	q17, [sp, #6784]                ; 16-byte Spill
	b.gt	LBB0_812
; %bb.794:                              ; %direct.true736.lr.ph
                                        ;   in Loop: Header=BB0_793 Depth=2
	fmov	x9, d4
	add	x9, x9, x9, lsl #2
	fmov	d2, x9
	mov.d	x9, v4[1]
	add	x9, x9, x9, lsl #2
	mov.d	v2[1], x9
	fmov	x9, d17
	add	x9, x9, x9, lsl #2
	fmov	d4, x9
	mov.d	x9, v17[1]
	add	x9, x9, x9, lsl #2
	mov.d	v4[1], x9
	fmov	x9, d3
	add	x9, x9, x9, lsl #2
	mov.d	x10, v3[1]
	fmov	d0, x9
	add	x9, x10, x10, lsl #2
	mov.d	v0[1], x9
	fmov	x9, d7
	add	x9, x9, x9, lsl #2
	fmov	d1, x9
	mov.d	x9, v7[1]
	add	x9, x9, x9, lsl #2
	mov.d	v1[1], x9
	ldr	q31, [sp, #13328]               ; 16-byte Reload
	mov.16b	v22, v30
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	ldr	q13, [sp, #13232]               ; 16-byte Reload
	ldr	q28, [sp, #11456]               ; 16-byte Reload
	ldr	q17, [sp, #11440]               ; 16-byte Reload
	b	LBB0_796
LBB0_795:                               ; %else2818
                                        ;   in Loop: Header=BB0_796 Depth=3
	cmge.2d	v19, v25, v13
	cmge.2d	v23, v28, v9
	uzp1.4s	v19, v23, v19
	ldr	q22, [sp, #13152]               ; 16-byte Reload
	cmge.2d	v21, v21, v22
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	cmge.2d	v18, v18, v3
	uzp1.4s	v18, v18, v21
	uzp1.8h	v18, v18, v19
	and.16b	v18, v31, v18
	xtn.8b	v18, v18
	zip2.8b	v19, v6, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmlt.4s	v19, v19, #0
	ldr	q17, [sp, #12544]               ; 16-byte Reload
	bsl.16b	v19, v30, v17
	zip1.8b	v21, v6, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	ldr	q17, [sp, #12560]               ; 16-byte Reload
	bsl.16b	v21, v29, v17
	zip1.8b	v23, v18, v0
	ushll.4s	v23, v23, #0
	shl.4s	v23, v23, #31
	cmge.4s	v23, v23, #0
	and.16b	v17, v23, v21
	zip2.8b	v18, v18, v0
	ushll.4s	v18, v18, #0
	shl.4s	v18, v18, #31
	cmge.4s	v18, v18, #0
	and.16b	v25, v18, v19
	ldr	q30, [sp, #12896]               ; 16-byte Reload
	fadd.4s	v18, v30, v25
	ldr	q29, [sp, #12912]               ; 16-byte Reload
	fadd.4s	v19, v29, v17
	ldr	q23, [sp, #12928]               ; 16-byte Reload
	zip1.8b	v21, v23, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	str	q17, [sp, #12560]               ; 16-byte Spill
	bif.16b	v19, v17, v21
	zip2.8b	v21, v23, v0
	ushll.4s	v21, v21, #0
	shl.4s	v21, v21, #31
	cmlt.4s	v21, v21, #0
	str	q25, [sp, #12544]               ; 16-byte Spill
	bif.16b	v18, v25, v21
	ldr	q21, [sp, #13296]               ; 16-byte Reload
	add.2d	v28, v11, v21
	ldr	q21, [sp, #13280]               ; 16-byte Reload
	add.2d	v8, v8, v21
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	add.2d	v17, v10, v11
	ldr	q21, [sp, #13264]               ; 16-byte Reload
	add.2d	v25, v15, v21
	and.16b	v7, v24, v7
	and.16b	v5, v26, v5
	bit.16b	v30, v18, v5
	str	q30, [sp, #12896]               ; 16-byte Spill
	bit.16b	v29, v19, v7
	str	q29, [sp, #12912]               ; 16-byte Spill
	orr.8b	v23, v23, v6
	str	q23, [sp, #12928]               ; 16-byte Spill
	fmov	x9, d25
	cmp	x9, #5
	b.ge	LBB0_813
LBB0_796:                               ; %direct.true736
                                        ;   Parent Loop BB0_91 Depth=1
                                        ;     Parent Loop BB0_793 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v5, v26, #0
	sshll.2d	v6, v24, #0
	mov.16b	v10, v17
	and.16b	v7, v14, v17
	mov.d	x9, v7[1]
	sdiv	x10, x9, x14
	msub	x9, x10, x14, x9
	fmov	x10, d7
	ldr	q7, [sp, #13216]                ; 16-byte Reload
	fmov	x11, d7
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d23, x10
	mov.d	v23[1], x9
	mov.16b	v17, v8
	and.16b	v5, v5, v8
	mov.d	x9, v5[1]
	sdiv	x10, x9, x8
	msub	x9, x10, x8, x9
	fmov	x10, d5
	ldr	q5, [sp, #13184]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d8, x10
	mov.d	v8[1], x9
	mov.16b	v11, v28
	and.16b	v5, v12, v28
	mov.d	x9, v5[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d5
	ldr	q5, [sp, #13200]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	mov.16b	v7, v9
	fmov	d9, x10
	mov.d	v9[1], x9
	mov.16b	v15, v25
	and.16b	v5, v6, v25
	mov.d	x9, v5[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d5
	ldr	q5, [sp, #13168]                ; 16-byte Reload
	fmov	x11, d5
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d6, x10
	mov.d	v6[1], x9
	shl.2d	v18, v6, #3
	shl.2d	v21, v9, #3
	shl.2d	v28, v8, #3
	shl.2d	v25, v23, #3
	cmgt.2d	v5, v13, v25
	cmgt.2d	v7, v7, v28
	uzp1.4s	v5, v7, v5
	cmgt.2d	v7, v22, v21
	cmgt.2d	v19, v3, v18
	uzp1.4s	v7, v19, v7
	uzp1.8h	v19, v7, v5
	add.2d	v29, v6, v2
	and.16b	v6, v31, v19
	xtn.8b	v6, v6
	shl.8b	v19, v6, #7
	cmlt.8b	v19, v19, #0
	ldr	d30, [sp, #13320]               ; 8-byte Reload
	and.8b	v19, v19, v30
	addv.8b	b19, v19
	fmov	w9, s19
	shl.2d	v19, v29, #5
	ldr	q3, [sp, #12784]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12736]                ; 16-byte Reload
	add.2d	v31, v3, v19
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	tbz	w9, #0, LBB0_798
; %bb.797:                              ; %cond.load2772
                                        ;   in Loop: Header=BB0_796 Depth=3
	fmov	x10, d31
	ldr	s29, [x10]
LBB0_798:                               ; %else2776
                                        ;   in Loop: Header=BB0_796 Depth=3
	tbz	w9, #1, LBB0_800
; %bb.799:                              ; %cond.load2778
                                        ;   in Loop: Header=BB0_796 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v29 }[1], [x10]
LBB0_800:                               ; %else2782
                                        ;   in Loop: Header=BB0_796 Depth=3
	ldr	q13, [sp, #13232]               ; 16-byte Reload
	add.2d	v19, v9, v4
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12768]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	add.2d	v31, v3, v19
	tbz	w9, #2, LBB0_802
; %bb.801:                              ; %cond.load2784
                                        ;   in Loop: Header=BB0_796 Depth=3
	fmov	x10, d31
	ld1.s	{ v29 }[2], [x10]
LBB0_802:                               ; %else2788
                                        ;   in Loop: Header=BB0_796 Depth=3
	ldr	q9, [sp, #13088]                ; 16-byte Reload
	tbz	w9, #3, LBB0_804
; %bb.803:                              ; %cond.load2790
                                        ;   in Loop: Header=BB0_796 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v29 }[3], [x10]
LBB0_804:                               ; %else2794
                                        ;   in Loop: Header=BB0_796 Depth=3
	add.2d	v19, v8, v0
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12752]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12816]                ; 16-byte Reload
	add.2d	v31, v3, v19
	tbz	w9, #4, LBB0_806
; %bb.805:                              ; %cond.load2796
                                        ;   in Loop: Header=BB0_796 Depth=3
	fmov	x10, d31
	ld1.s	{ v30 }[0], [x10]
LBB0_806:                               ; %else2800
                                        ;   in Loop: Header=BB0_796 Depth=3
	mov.16b	v8, v17
	tbz	w9, #5, LBB0_808
; %bb.807:                              ; %cond.load2802
                                        ;   in Loop: Header=BB0_796 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v30 }[1], [x10]
LBB0_808:                               ; %else2806
                                        ;   in Loop: Header=BB0_796 Depth=3
	ldr	q31, [sp, #13328]               ; 16-byte Reload
	add.2d	v19, v23, v1
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12848]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12800]                ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w9, #6, LBB0_810
; %bb.809:                              ; %cond.load2808
                                        ;   in Loop: Header=BB0_796 Depth=3
	fmov	x10, d23
	ld1.s	{ v30 }[2], [x10]
LBB0_810:                               ; %else2812
                                        ;   in Loop: Header=BB0_796 Depth=3
	tbz	w9, #7, LBB0_795
; %bb.811:                              ; %cond.load2814
                                        ;   in Loop: Header=BB0_796 Depth=3
	mov.d	x9, v23[1]
	ld1.s	{ v30 }[3], [x9]
	b	LBB0_795
LBB0_812:                               ;   in Loop: Header=BB0_793 Depth=2
	ldr	q28, [sp, #11456]               ; 16-byte Reload
	ldr	q17, [sp, #11440]               ; 16-byte Reload
LBB0_813:                               ; %direct.false737
                                        ;   in Loop: Header=BB0_793 Depth=2
	str	q17, [sp, #11440]               ; 16-byte Spill
	str	q28, [sp, #11456]               ; 16-byte Spill
	str	q25, [sp, #6832]                ; 16-byte Spill
	ldr	q17, [sp, #12912]               ; 16-byte Reload
	str	q17, [x13, #1984]
	ldr	q22, [sp, #12896]               ; 16-byte Reload
	str	q22, [x13, #2000]
	ldr	x10, [sp, #4256]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3184
	ldr	s0, [x9, x10]
	ldr	w9, [sp, #7980]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q17, [x13, #1952]
	str	q22, [x13, #1968]
	ldr	x11, [sp, #4240]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3152
	ldr	s4, [x9, x11]
	ldr	q3, [sp, #12928]                ; 16-byte Reload
	movi.8b	v1, #1
	and.8b	v1, v3, v1
	ushll.8h	v2, v1, #0
	ushll.4s	v1, v2, #0
	ushll2.4s	v2, v2, #0
	str	q2, [x13, #1520]
	str	q1, [x13, #1504]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2704
	ldr	w9, [x9, x10]
	movi.2d	v10, #0000000000000000
	fcsel	s0, s0, s10, ne
	csel	w9, w9, wzr, ne
	str	q17, [x13, #1920]
	str	q22, [x13, #1936]
	ldr	x12, [sp, #4224]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3120
	ldr	s5, [x10, x12]
	ldr	w10, [sp, #7976]                ; 4-byte Reload
	tst	w10, #0x1
	str	q2, [x13, #1552]
	str	q1, [x13, #1536]
	fmov	s6, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2736
	ldr	w9, [x9, x11]
	fcsel	s7, s4, s10, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7972]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s5, s5, s10, ne
	str	q17, [x13, #1888]
	str	q22, [x13, #1904]
	ldr	x11, [sp, #4208]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3088
	ldr	s4, [x10, x11]
	str	q2, [x13, #1584]
	str	q1, [x13, #1568]
	mov.s	v6[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2768
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7968]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s18, s4, s10, ne
	str	q17, [x13, #1856]
	str	q22, [x13, #1872]
	ldr	x12, [sp, #4200]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3056
	ldr	s4, [x10, x12]
	str	q2, [x13, #1616]
	mov.s	v6[2], w9
	str	q1, [x13, #1600]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2800
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7964]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s4, s4, s10, ne
	str	q17, [x13, #1824]
	str	q22, [x13, #1840]
	ldr	x11, [sp, #4184]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #3024
	ldr	s19, [x10, x11]
	str	q2, [x13, #1648]
	str	q1, [x13, #1632]
	mov.s	v6[3], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2832
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7960]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s19, s19, s10, ne
	str	q17, [x13, #1792]
	str	q22, [x13, #1808]
	ldr	x12, [sp, #4168]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2992
	ldr	s21, [x10, x12]
	str	q2, [x13, #1680]
	str	q1, [x13, #1664]
	fmov	s23, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2864
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7956]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s21, s21, s10, ne
	str	q17, [x13, #1760]
	str	q22, [x13, #1776]
	ldr	x11, [sp, #4152]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2960
	ldr	s25, [x10, x11]
	str	q2, [x13, #1712]
	str	q1, [x13, #1696]
	mov.s	v23[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2896
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7952]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s25, s25, s10, ne
	mov.s	v4[1], v19[0]
	mov.s	v4[2], v21[0]
	mov.s	v4[3], v25[0]
	mov.s	v0[1], v7[0]
	mov.s	v0[2], v5[0]
	mov.s	v0[3], v18[0]
	fadd.4s	v5, v17, v0
	str	q2, [x13, #1744]
	mov.s	v23[2], w9
	str	q1, [x13, #1728]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2928
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	mov.s	v23[3], w9
	fadd.4s	v1, v22, v4
	cmtst.4s	v2, v23, v23
	cmtst.4s	v7, v6, v6
	uzp1.8h	v2, v7, v2
	xtn.8b	v7, v2
	cmeq.4s	v2, v6, #0
	cmeq.4s	v6, v23, #0
	bsl.16b	v6, v22, v1
	mov.16b	v1, v2
	bsl.16b	v1, v17, v5
	zip1.8b	v2, v3, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bif.16b	v1, v0, v2
	zip2.8b	v0, v3, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	mov.16b	v2, v0
	bsl.16b	v2, v6, v4
	orr.8b	v0, v3, v7
	str	q2, [x13, #1488]
	str	q1, [x13, #1472]
	ldr	x10, [sp, #4144]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2672
	ldr	s4, [x9, x10]
	ldr	w9, [sp, #7948]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s4, s4, s10, ne
	str	q2, [x13, #1424]
	str	q1, [x13, #1408]
	ldr	x11, [sp, #4128]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2608
	ldr	s19, [x9, x11]
	zip1.8b	v5, v0, v0
	ushll.4s	v6, v5, #0
	movi.4s	v31, #1
	and.16b	v5, v6, v31
	zip2.8b	v7, v0, v0
	ushll.4s	v18, v7, #0
	and.16b	v7, v18, v31
	str	q7, [x13, #1456]
	str	q5, [x13, #1440]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2640
	ldr	w9, [x9, x10]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7944]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s21, s19, s10, ne
	str	q2, [x13, #1360]
	str	q1, [x13, #1344]
	ldr	x12, [sp, #4112]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2544
	ldr	s23, [x10, x12]
	str	q7, [x13, #1392]
	str	q5, [x13, #1376]
	fmov	s25, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2576
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7940]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s19, s23, s10, ne
	str	q2, [x13, #1296]
	str	q1, [x13, #1280]
	ldr	x11, [sp, #4096]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2480
	ldr	s23, [x10, x11]
	str	q7, [x13, #1328]
	str	q5, [x13, #1312]
	mov.s	v25[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2512
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7936]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s23, s23, s10, ne
	str	q2, [x13, #1232]
	str	q1, [x13, #1216]
	ldr	x12, [sp, #4088]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2416
	ldr	s28, [x10, x12]
	str	q7, [x13, #1264]
	str	q5, [x13, #1248]
	mov.s	v25[2], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2448
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7932]                ; 4-byte Reload
	tst	w10, #0x1
	str	q2, [x13, #1168]
	str	q1, [x13, #1152]
	ldr	x11, [sp, #4072]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2352
	ldr	s29, [x10, x11]
	str	q7, [x13, #1200]
	str	q5, [x13, #1184]
	mov.s	v25[3], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2384
	ldr	w9, [x9, x12]
	fcsel	s28, s28, s10, ne
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7928]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s29, s29, s10, ne
	str	q2, [x13, #1104]
	str	q1, [x13, #1088]
	ldr	x12, [sp, #4056]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2288
	ldr	s30, [x10, x12]
	str	q7, [x13, #1136]
	str	q5, [x13, #1120]
	mov.s	v28[1], v29[0]
	fmov	s29, w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2320
	ldr	w9, [x9, x11]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7924]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s30, s30, s10, ne
	str	q2, [x13, #1040]
	str	q1, [x13, #1024]
	mov.s	v28[2], v30[0]
	ldr	x11, [sp, #4040]                ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2224
	ldr	s30, [x10, x11]
	str	q7, [x13, #1072]
	str	q5, [x13, #1056]
	mov.s	v29[1], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2256
	ldr	w9, [x9, x12]
	csel	w9, w9, wzr, ne
	ldr	w10, [sp, #7920]                ; 4-byte Reload
	tst	w10, #0x1
	fcsel	s30, s30, s10, ne
	mov.s	v28[3], v30[0]
	mov.s	v4[1], v21[0]
	mov.s	v4[2], v19[0]
	mov.s	v4[3], v23[0]
	fadd.4s	v19, v1, v4
	fadd.4s	v21, v2, v28
	shl.4s	v18, v18, #31
	cmlt.4s	v18, v18, #0
	shl.4s	v6, v6, #31
	stp	q5, q7, [x13, #992]
	mov.s	v29[2], w9
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2192
	ldr	w9, [x9, x11]
	cmlt.4s	v5, v6, #0
	csel	w9, w9, wzr, ne
	mov.s	v29[3], w9
	cmtst.4s	v6, v29, v29
	cmtst.4s	v7, v25, v25
	uzp1.8h	v6, v7, v6
	xtn.8b	v6, v6
	cmeq.4s	v7, v25, #0
	cmeq.4s	v23, v29, #0
	bif.16b	v2, v21, v23
	bif.16b	v1, v19, v7
	bif.16b	v1, v4, v5
	bif.16b	v2, v28, v18
	stp	q1, q2, [x13, #960]
	ldr	x10, [sp, #4032]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2160
	ldr	s2, [x9, x10]
	orr.8b	v0, v0, v6
	ldr	w9, [sp, #7916]                 ; 4-byte Reload
	tst	w9, #0x1
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	and.16b	v5, v4, v31
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	and.16b	v0, v0, v31
	stp	q5, q0, [x13, #928]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2128
	ldr	w9, [x9, x10]
	csel	w9, w9, wzr, ne
	stp	q5, q0, [x13, #896]
	fmov	s6, w9
	ldr	x9, [sp, #4016]                 ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2096
	ldr	w9, [x10, x9, lsl #2]
	fcsel	s2, s2, s10, ne
	ldr	w10, [sp, #7912]                ; 4-byte Reload
	tst	w10, #0x1
	csel	w9, w9, wzr, ne
	mov.s	v6[1], w9
	stp	q5, q0, [x13, #864]
	ldr	x9, [sp, #4000]                 ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2064
	ldr	w9, [x10, x9, lsl #2]
	ldr	w10, [sp, #7908]                ; 4-byte Reload
	tst	w10, #0x1
	csel	w9, w9, wzr, ne
	stp	q5, q0, [x13, #832]
	mov.s	v6[2], w9
	ldr	x9, [sp, #3968]                 ; 8-byte Reload
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #2032
	ldr	w9, [x10, x9, lsl #2]
	ldr	w10, [sp, #7904]                ; 4-byte Reload
	tst	w10, #0x1
	csel	w9, w9, wzr, ne
	mov.s	v6[3], w9
	ldr	q0, [sp, #8048]                 ; 16-byte Reload
	fmov	w9, s0
	fadd.4s	v0, v1, v2
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	cmeq.4s	v5, v6, #0
	bit.16b	v0, v1, v5
	bif.16b	v0, v2, v4
	tst	w16, #0x1
	fcsel	s1, s0, s10, ne
	and	w10, w17, w16
	tst	w10, #0x1
	fcsel	s2, s0, s10, ne
	and	w10, w0, w16
	tst	w10, #0x1
	fcsel	s4, s0, s10, ne
	and	w10, w1, w16
	tst	w10, #0x1
	fcsel	s5, s0, s10, ne
	and	w10, w2, w16
	tst	w10, #0x1
	fcsel	s6, s0, s10, ne
	and	w10, w3, w16
	tst	w10, #0x1
	fcsel	s7, s0, s10, ne
	and	w10, w4, w16
	tst	w10, #0x1
	fcsel	s18, s0, s10, ne
	and	w10, w5, w16
	tst	w10, #0x1
	fcsel	s0, s0, s10, ne
	mov.s	v1[1], v2[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v5[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v18[0]
	mov.s	v6[3], v0[0]
	stp	q1, q6, [x13, #672]
	ldr	x10, [sp, #3952]                ; 8-byte Reload
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1872
	ldr	s0, [x11, x10, lsl #2]
	fadd	s0, s0, s10
	ldr	q3, [sp, #8560]                 ; 16-byte Reload
	shl.2d	v1, v3, #5
	ldr	q2, [sp, #6000]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	dup.4s	v0, v0[0]
	ldr	q2, [sp, #6064]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #0, LBB0_815
; %bb.814:                              ; %cond.store2821
                                        ;   in Loop: Header=BB0_793 Depth=2
	fmov	x10, d1
	str	s0, [x10]
LBB0_815:                               ; %else2824
                                        ;   in Loop: Header=BB0_793 Depth=2
	and	w9, w9, #0xff
	ldr	q25, [sp, #11056]               ; 16-byte Reload
	ldr	q6, [sp, #9856]                 ; 16-byte Reload
	ldr	q4, [sp, #8544]                 ; 16-byte Reload
	ldr	q13, [sp, #4608]                ; 16-byte Reload
	tbz	w9, #1, LBB0_817
; %bb.816:                              ; %cond.store2825
                                        ;   in Loop: Header=BB0_793 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
LBB0_817:                               ; %else2828
                                        ;   in Loop: Header=BB0_793 Depth=2
	str	q8, [sp, #6816]                 ; 16-byte Spill
	shl.2d	v1, v6, #5
	ldr	q2, [sp, #5984]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6048]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	ldr	q30, [sp, #13152]               ; 16-byte Reload
	ldr	q5, [sp, #9840]                 ; 16-byte Reload
	tbnz	w9, #2, LBB0_823
; %bb.818:                              ; %else2832
                                        ;   in Loop: Header=BB0_793 Depth=2
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	d27, [sp, #11624]               ; 8-byte Reload
	tbnz	w9, #3, LBB0_824
LBB0_819:                               ; %else2836
                                        ;   in Loop: Header=BB0_793 Depth=2
	shl.2d	v1, v5, #5
	ldr	q2, [sp, #6096]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6032]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #4, LBB0_825
LBB0_820:                               ; %else2840
                                        ;   in Loop: Header=BB0_793 Depth=2
	tbnz	w9, #5, LBB0_826
LBB0_821:                               ; %else2844
                                        ;   in Loop: Header=BB0_793 Depth=2
	shl.2d	v1, v4, #5
	ldr	q2, [sp, #6080]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6016]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w9, #6, LBB0_827
LBB0_822:                               ; %else2848
                                        ;   in Loop: Header=BB0_793 Depth=2
	tbz	w9, #7, LBB0_792
	b	LBB0_828
LBB0_823:                               ; %cond.store2829
                                        ;   in Loop: Header=BB0_793 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	d27, [sp, #11624]               ; 8-byte Reload
	tbz	w9, #3, LBB0_819
LBB0_824:                               ; %cond.store2833
                                        ;   in Loop: Header=BB0_793 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[3], [x10]
	shl.2d	v1, v5, #5
	ldr	q2, [sp, #6096]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6032]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #4, LBB0_820
LBB0_825:                               ; %cond.store2837
                                        ;   in Loop: Header=BB0_793 Depth=2
	fmov	x10, d1
	str	s0, [x10]
	tbz	w9, #5, LBB0_821
LBB0_826:                               ; %cond.store2841
                                        ;   in Loop: Header=BB0_793 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
	shl.2d	v1, v4, #5
	ldr	q2, [sp, #6080]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #6016]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w9, #6, LBB0_822
LBB0_827:                               ; %cond.store2845
                                        ;   in Loop: Header=BB0_793 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_792
LBB0_828:                               ; %cond.store2849
                                        ;   in Loop: Header=BB0_793 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_792
LBB0_829:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q6, [sp, #9856]                 ; 16-byte Reload
	ldr	q5, [sp, #9840]                 ; 16-byte Reload
	ldr	q13, [sp, #4608]                ; 16-byte Reload
LBB0_830:                               ; %direct.false732
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q6, [sp, #9856]                 ; 16-byte Spill
	str	q4, [sp, #8544]                 ; 16-byte Spill
	str	q5, [sp, #9840]                 ; 16-byte Spill
	str	q3, [sp, #8560]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #272]                  ; 16-byte Reload
	ldr	q3, [sp, #5920]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #5920]                 ; 16-byte Spill
	ldr	q3, [sp, #5952]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #5952]                 ; 16-byte Spill
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #5936]                 ; 16-byte Spill
	ldr	q3, [sp, #5856]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #5856]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #5968]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #5968]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #5888]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #5888]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #5872]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #5904]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #5904]                 ; 16-byte Spill
	ldr	q2, [sp, #9984]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #9984]                 ; 16-byte Spill
	ldr	q30, [sp, #1168]                ; 16-byte Reload
	bic.16b	v30, v30, v12
	ldr	q2, [sp, #10000]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10000]                ; 16-byte Spill
	ldr	q17, [sp, #1184]                ; 16-byte Reload
	bic.16b	v17, v17, v0
	fmov	x8, d17
	cmp	x8, #1
	b.lt	LBB0_1383
; %bb.831:                              ;   in Loop: Header=BB0_91 Depth=1
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #1616
	add	x30, sp, #3, lsl #12            ; =12288
	add	x30, x30, #1648
LBB0_832:                               ; %direct.false766
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q25, [sp, #11056]               ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #256]                  ; 16-byte Reload
	ldr	q3, [sp, #8416]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8416]                 ; 16-byte Spill
	ldr	q3, [sp, #8448]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8448]                 ; 16-byte Spill
	ldr	q3, [sp, #8432]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8432]                 ; 16-byte Spill
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8464]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #8480]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8480]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #8512]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8512]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #8496]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8496]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #8528]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8528]                 ; 16-byte Spill
	ldr	q2, [sp, #11584]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #11584]                ; 16-byte Spill
	ldr	q2, [sp, #11568]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #11568]                ; 16-byte Spill
	ldr	q2, [sp, #11600]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #11600]                ; 16-byte Spill
	ldr	q1, [sp, #1152]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	fmov	x8, d1
	cmp	x8, #1
	b.le	LBB0_836
LBB0_833:                               ; %direct.false781
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q1, [sp, #1152]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #240]                  ; 16-byte Reload
	ldr	q3, [sp, #8336]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8336]                 ; 16-byte Spill
	ldr	q3, [sp, #8368]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8368]                 ; 16-byte Spill
	ldr	q3, [sp, #8352]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #8352]                 ; 16-byte Spill
	ldr	q3, [sp, #8384]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8384]                 ; 16-byte Spill
	ldr	q2, [sp, #4544]                 ; 16-byte Reload
	ldr	q3, [sp, #8400]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #8400]                 ; 16-byte Spill
	ldr	q2, [sp, #4528]                 ; 16-byte Reload
	ldr	q3, [sp, #8304]                 ; 16-byte Reload
	bit.16b	v3, v2, v12
	str	q3, [sp, #8304]                 ; 16-byte Spill
	ldr	q2, [sp, #4576]                 ; 16-byte Reload
	ldr	q3, [sp, #1968]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #1968]                 ; 16-byte Spill
	ldr	q2, [sp, #4560]                 ; 16-byte Reload
	ldr	q3, [sp, #8320]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #8320]                 ; 16-byte Spill
	ldr	q7, [sp, #8240]                 ; 16-byte Reload
	bic.16b	v7, v7, v14
	ldr	q6, [sp, #8272]                 ; 16-byte Reload
	bic.16b	v6, v6, v12
	ldr	q4, [sp, #8256]                 ; 16-byte Reload
	bic.16b	v4, v4, v1
	ldr	q5, [sp, #8288]                 ; 16-byte Reload
	bic.16b	v5, v5, v0
	fmov	x8, d5
	cmp	x8, #1
	str	q17, [sp, #1184]                ; 16-byte Spill
	str	q30, [sp, #1168]                ; 16-byte Spill
	b.gt	LBB0_953
; %bb.834:                              ; %direct.true801.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q15, [sp, #1968]                ; 16-byte Reload
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	ldr	q22, [sp, #1136]                ; 16-byte Reload
	ldr	q10, [sp, #1120]                ; 16-byte Reload
	ldr	q25, [sp, #1104]                ; 16-byte Reload
	ldr	q28, [sp, #1088]                ; 16-byte Reload
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #1344
	add	x30, sp, #3, lsl #12            ; =12288
	add	x30, x30, #1376
	b	LBB0_885
LBB0_835:                               ; %else3114
                                        ;   in Loop: Header=BB0_836 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #11568]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #11568]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #11600]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #11600]                ; 16-byte Spill
	ldr	q0, [sp, #11584]                ; 16-byte Reload
	add.2d	v0, v0, v11
	str	q0, [sp, #11584]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v1, v31, v0
	fmov	x8, d1
	cmp	x8, #2
	b.ge	LBB0_833
LBB0_836:                               ; %direct.true780
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v24, #0
	mov.16b	v31, v1
	and.16b	v0, v0, v1
	mov.d	x8, v0[1]
	ldr	x10, [sp, #11736]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d0
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	fmov	x10, d0
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d6, x9
	mov.d	v6[1], x8
	shl.2d	v0, v6, #5
	ldr	q1, [sp, #12336]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9776]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	d1, [sp, #12376]                ; 8-byte Reload
	fmov	w8, s1
	movi.2d	v4, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w8, #0, LBB0_838
; %bb.837:                              ; %cond.load2985
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x9, d0
	ldr	s4, [x9]
LBB0_838:                               ; %else2989
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w8, #1, LBB0_840
; %bb.839:                              ; %cond.load2991
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v4 }[1], [x9]
LBB0_840:                               ; %else2995
                                        ;   in Loop: Header=BB0_836 Depth=2
	ldr	q0, [sp, #11568]                ; 16-byte Reload
	and.16b	v0, v12, v0
	mov.d	x9, v0[1]
	sdiv	x10, x9, x25
	msub	x9, x10, x25, x9
	fmov	x10, d0
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d5, x10
	mov.d	v5[1], x9
	shl.2d	v0, v5, #5
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9808]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #2, LBB0_842
; %bb.841:                              ; %cond.load2997
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x9, d0
	ld1.s	{ v4 }[2], [x9]
LBB0_842:                               ; %else3001
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w8, #3, LBB0_844
; %bb.843:                              ; %cond.load3003
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v4 }[3], [x9]
LBB0_844:                               ; %else3007
                                        ;   in Loop: Header=BB0_836 Depth=2
	sshll.2d	v0, v26, #0
	ldr	q1, [sp, #11600]                ; 16-byte Reload
	and.16b	v0, v0, v1
	mov.d	x9, v0[1]
	sdiv	x10, x9, x26
	msub	x9, x10, x26, x9
	fmov	x10, d0
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d7, x10
	mov.d	v7[1], x9
	shl.2d	v0, v7, #5
	ldr	q1, [sp, #12352]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9792]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #4, LBB0_846
; %bb.845:                              ; %cond.load3009
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x9, d0
	ld1.s	{ v2 }[0], [x9]
LBB0_846:                               ; %else3013
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w8, #5, LBB0_848
; %bb.847:                              ; %cond.load3015
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_848:                               ; %else3019
                                        ;   in Loop: Header=BB0_836 Depth=2
	ldr	q0, [sp, #11584]                ; 16-byte Reload
	and.16b	v0, v14, v0
	mov.d	x9, v0[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d0
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x12, x10, x11
	msub	x10, x12, x11, x10
	fmov	d18, x10
	mov.d	v18[1], x9
	shl.2d	v0, v18, #5
	ldr	q1, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9824]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_850
; %bb.849:                              ; %cond.load3021
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x9, d0
	ld1.s	{ v2 }[2], [x9]
LBB0_850:                               ; %else3025
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w8, #7, LBB0_852
; %bb.851:                              ; %cond.load3027
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x8, v0[1]
	ld1.s	{ v2 }[3], [x8]
LBB0_852:                               ; %else3031
                                        ;   in Loop: Header=BB0_836 Depth=2
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	and.16b	v23, v14, v18
	and.16b	v18, v1, v7
	and.16b	v6, v0, v6
	mov.d	x8, v6[1]
	ldr	q7, [sp, #12960]                ; 16-byte Reload
	mov.d	x14, v7[1]
	sdiv	x20, x8, x14
	fmov	x8, d6
	fmov	x9, d7
	sdiv	x8, x8, x9
	mul	x10, x8, x9
	fmov	d19, x8
	mov.d	v19[1], x20
	mov.d	x8, v18[1]
	and.16b	v5, v12, v5
	ldr	q7, [sp, #12976]                ; 16-byte Reload
	mov.d	x11, v7[1]
	sdiv	x15, x8, x11
	fmov	x12, d18
	fmov	x21, d7
	mov.d	x8, v5[1]
	ldr	q7, [sp, #12992]                ; 16-byte Reload
	mov.d	x6, v7[1]
	sdiv	x7, x8, x6
	fmov	x8, d5
	fmov	x22, d7
	sdiv	x19, x8, x22
	mov.d	x8, v23[1]
	ldr	q7, [sp, #13008]                ; 16-byte Reload
	mov.d	x23, v7[1]
	sdiv	x8, x8, x23
	fmov	x9, d23
	fmov	x24, d7
	sdiv	x9, x9, x24
	mul	x23, x8, x23
	mul	x24, x9, x24
	fmov	d25, x24
	mov.d	v25[1], x23
	mul	x6, x7, x6
	mul	x22, x19, x22
	fmov	d21, x22
	mov.d	v21[1], x6
	mul	x11, x15, x11
	sdiv	x6, x12, x21
	mul	x12, x6, x21
	fmov	d28, x12
	mov.d	v28[1], x11
	mul	x11, x20, x14
	fmov	d7, x10
	mov.d	v7[1], x11
	sub.2d	v7, v6, v7
	sub.2d	v18, v18, v28
	sub.2d	v21, v5, v21
	sub.2d	v23, v23, v25
	ldr	q5, [sp, #13040]                ; 16-byte Reload
	cmeq.2d	v5, v5, v23
	ldr	q6, [sp, #13056]                ; 16-byte Reload
	cmeq.2d	v6, v6, v18
	uzp1.4s	v5, v6, v5
	ldr	q6, [sp, #13072]                ; 16-byte Reload
	cmeq.2d	v6, v6, v21
	ldr	q25, [sp, #13104]               ; 16-byte Reload
	cmeq.2d	v25, v25, v7
	uzp1.4s	v6, v25, v6
	uzp1.8h	v28, v6, v5
	ldr	q5, [sp, #13328]                ; 16-byte Reload
	and.16b	v5, v5, v28
	xtn.8b	v5, v5
	shl.8b	v6, v5, #7
	cmlt.8b	v6, v6, #0
	ldr	d25, [sp, #13320]               ; 8-byte Reload
	and.8b	v6, v6, v25
	addv.8b	b6, v6
	fmov	w14, s6
	shl.2d	v6, v19, #5
	ldr	q3, [sp, #6416]                 ; 16-byte Reload
	orr.16b	v6, v6, v3
	ldr	q3, [sp, #6368]                 ; 16-byte Reload
	add.2d	v29, v3, v6
	movi.2d	v6, #0000000000000000
	movi.2d	v25, #0000000000000000
	tbz	w14, #0, LBB0_854
; %bb.853:                              ; %cond.load3034
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x10, d29
	ldr	s6, [x10]
LBB0_854:                               ; %else3038
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w14, #1, LBB0_856
; %bb.855:                              ; %cond.load3040
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x10, v29[1]
	ld1.s	{ v6 }[1], [x10]
LBB0_856:                               ; %else3044
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	d19, x19
	mov.d	v19[1], x7
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #6400]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6464]                 ; 16-byte Reload
	add.2d	v29, v3, v19
	tbz	w14, #2, LBB0_858
; %bb.857:                              ; %cond.load3046
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x10, d29
	ld1.s	{ v6 }[2], [x10]
LBB0_858:                               ; %else3050
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w14, #3, LBB0_860
; %bb.859:                              ; %cond.load3052
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x10, v29[1]
	ld1.s	{ v6 }[3], [x10]
LBB0_860:                               ; %else3056
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	d19, x6
	mov.d	v19[1], x15
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #6384]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6448]                 ; 16-byte Reload
	add.2d	v29, v3, v19
	tbz	w14, #4, LBB0_862
; %bb.861:                              ; %cond.load3058
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x10, d29
	ld1.s	{ v25 }[0], [x10]
LBB0_862:                               ; %else3062
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w14, #5, LBB0_864
; %bb.863:                              ; %cond.load3064
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x10, v29[1]
	ld1.s	{ v25 }[1], [x10]
LBB0_864:                               ; %else3068
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	d19, x9
	mov.d	v19[1], x8
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #6480]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6432]                 ; 16-byte Reload
	add.2d	v29, v3, v19
	tbz	w14, #6, LBB0_866
; %bb.865:                              ; %cond.load3070
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x8, d29
	ld1.s	{ v25 }[2], [x8]
LBB0_866:                               ; %else3074
                                        ;   in Loop: Header=BB0_836 Depth=2
	ldr	q19, [sp, #3984]                ; 16-byte Reload
	ldr	q3, [sp, #10624]                ; 16-byte Reload
	bif.16b	v4, v3, v19
	ldr	q19, [sp, #3904]                ; 16-byte Reload
	and.16b	v3, v19, v4
	str	q3, [sp, #10624]                ; 16-byte Spill
	ldr	q3, [sp, #10640]                ; 16-byte Reload
	bit.16b	v3, v23, v14
	str	q3, [sp, #10640]                ; 16-byte Spill
	ldr	q3, [sp, #10592]                ; 16-byte Reload
	bit.16b	v3, v21, v12
	str	q3, [sp, #10592]                ; 16-byte Spill
	ldr	q3, [sp, #10656]                ; 16-byte Reload
	bit.16b	v3, v18, v1
	str	q3, [sp, #10656]                ; 16-byte Spill
	ldr	q1, [sp, #10608]                ; 16-byte Reload
	bit.16b	v1, v7, v0
	str	q1, [sp, #10608]                ; 16-byte Spill
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	bic.16b	v0, v0, v28
	xtn.8b	v0, v0
	tbz	w14, #7, LBB0_868
; %bb.867:                              ; %cond.load3076
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x8, v29[1]
	ld1.s	{ v25 }[3], [x8]
LBB0_868:                               ; %else3080
                                        ;   in Loop: Header=BB0_836 Depth=2
	zip2.8b	v1, v5, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q3, [sp, #6704]                 ; 16-byte Reload
	bsl.16b	v1, v25, v3
	zip1.8b	v4, v5, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q3, [sp, #6752]                 ; 16-byte Reload
	bsl.16b	v4, v6, v3
	zip1.8b	v5, v0, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v3, v5, v4
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v19, v0, v1
	ldr	q0, [sp, #10640]                ; 16-byte Reload
	xtn.2s	v0, v0
	ldr	q1, [sp, #10656]                ; 16-byte Reload
	xtn.2s	v5, v1
	ldr	q1, [sp, #10592]                ; 16-byte Reload
	xtn.2s	v6, v1
	ldr	q1, [sp, #10608]                ; 16-byte Reload
	xtn.2s	v1, v1
	mov.s	w8, v1[1]
	fmov	w9, s1
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	str	d8, [sp, #13896]
	ldrb	w11, [x11]
	and	w11, w16, w11
	stp	q3, q19, [x13, #416]
	ldr	s1, [x28, x9, lsl #2]
	tst	w10, w11
	movi.2d	v21, #0000000000000000
	fcsel	s1, s1, s21, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w17, w8
	stp	q3, q19, [x13, #448]
	ldr	s4, [x30, x10, lsl #2]
	tst	w9, w8
	fcsel	s4, s4, s21, ne
	mov.s	w8, v6[1]
	fmov	w9, s6
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	stp	q3, q19, [x13, #480]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1680
	ldr	s6, [x12, x9, lsl #2]
	and	w9, w0, w11
	tst	w10, w9
	fcsel	s6, s6, s21, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w1, w8
	stp	q3, q19, [x13, #512]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1712
	ldr	s7, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	w8, v5[1]
	fcsel	s18, s7, s21, ne
	fmov	w9, s5
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w2, w11
	stp	q3, q19, [x13, #544]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1744
	ldr	s5, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s5, s5, s21, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w3, w8
	stp	q3, q19, [x13, #576]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1776
	ldr	s7, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s7, s7, s21, ne
	mov.s	w8, v0[1]
	fmov	w9, s0
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w4, w11
	stp	q3, q19, [x13, #608]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1808
	ldr	s0, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s0, s0, s21, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1608
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w5, w8
	str	q19, [sp, #6704]                ; 16-byte Spill
	str	q19, [x13, #656]
	str	q3, [sp, #6752]                 ; 16-byte Spill
	str	q3, [x13, #640]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1840
	ldr	s19, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	v1[1], v4[0]
	mov.s	v1[2], v6[0]
	mov.s	v1[3], v18[0]
	fcsel	s4, s19, s21, ne
	ldr	q3, [sp, #10624]                ; 16-byte Reload
	fmul.4s	v1, v3, v1
	shl.2d	v6, v31, #5
	ldr	q3, [sp, #8528]                 ; 16-byte Reload
	orr.16b	v6, v6, v3
	ldr	q3, [sp, #8464]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	ldr	d18, [sp, #12376]               ; 8-byte Reload
	fmov	w8, s18
	tbz	w8, #0, LBB0_870
; %bb.869:                              ; %cond.store3083
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x9, d6
	str	s1, [x9]
LBB0_870:                               ; %else3086
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w8, #1, LBB0_872
; %bb.871:                              ; %cond.store3087
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v1 }[1], [x9]
LBB0_872:                               ; %else3090
                                        ;   in Loop: Header=BB0_836 Depth=2
	ldr	q3, [sp, #11568]                ; 16-byte Reload
	shl.2d	v6, v3, #5
	ldr	q3, [sp, #8512]                 ; 16-byte Reload
	orr.16b	v6, v6, v3
	ldr	q3, [sp, #8448]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	tbz	w8, #2, LBB0_874
; %bb.873:                              ; %cond.store3091
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x9, d6
	st1.s	{ v1 }[2], [x9]
LBB0_874:                               ; %else3094
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w8, #3, LBB0_876
; %bb.875:                              ; %cond.store3095
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x9, v6[1]
	st1.s	{ v1 }[3], [x9]
LBB0_876:                               ; %else3098
                                        ;   in Loop: Header=BB0_836 Depth=2
	ldr	q1, [sp, #3936]                 ; 16-byte Reload
	ldr	q3, [sp, #6768]                 ; 16-byte Reload
	bsl.16b	v1, v2, v3
	ldr	q2, [sp, #3920]                 ; 16-byte Reload
	and.16b	v1, v2, v1
	mov.s	v5[1], v7[0]
	mov.s	v5[2], v0[0]
	mov.s	v5[3], v4[0]
	str	q1, [sp, #6768]                 ; 16-byte Spill
	fmul.4s	v0, v1, v5
	ldr	q1, [sp, #11600]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q2, [sp, #8496]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #8432]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #4, LBB0_878
; %bb.877:                              ; %cond.store3099
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x9, d1
	str	s0, [x9]
LBB0_878:                               ; %else3102
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w8, #5, LBB0_880
; %bb.879:                              ; %cond.store3103
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
LBB0_880:                               ; %else3106
                                        ;   in Loop: Header=BB0_836 Depth=2
	ldr	q1, [sp, #11584]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q2, [sp, #8480]                 ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #8416]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #6, LBB0_882
; %bb.881:                              ; %cond.store3107
                                        ;   in Loop: Header=BB0_836 Depth=2
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
LBB0_882:                               ; %else3110
                                        ;   in Loop: Header=BB0_836 Depth=2
	tbz	w8, #7, LBB0_835
; %bb.883:                              ; %cond.store3111
                                        ;   in Loop: Header=BB0_836 Depth=2
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
	b	LBB0_835
LBB0_884:                               ; %else3294
                                        ;   in Loop: Header=BB0_885 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v6, v6, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v4, v4, v0
	add.2d	v7, v7, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v5, v5, v0
	fmov	x8, d5
	cmp	x8, #2
	b.ge	LBB0_954
LBB0_885:                               ; %direct.true801
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_904 Depth 3
	shl.2d	v1, v5, #5
	ldr	q0, [sp, #8528]                 ; 16-byte Reload
	str	q1, [sp, #11376]                ; 16-byte Spill
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8464]                 ; 16-byte Reload
	add.2d	v2, v1, v0
	ldr	d0, [sp, #12376]                ; 8-byte Reload
	fmov	w8, s0
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	tbz	w8, #0, LBB0_887
; %bb.886:                              ; %cond.load3116
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x9, d2
	ldr	s0, [x9]
LBB0_887:                               ; %else3120
                                        ;   in Loop: Header=BB0_885 Depth=2
	ldr	q18, [sp, #6688]                ; 16-byte Reload
	ldr	q21, [sp, #6672]                ; 16-byte Reload
	ldr	q23, [sp, #6656]                ; 16-byte Reload
	mov.16b	v19, v3
	tbz	w8, #1, LBB0_889
; %bb.888:                              ; %cond.load3122
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.d	x9, v2[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_889:                               ; %else3126
                                        ;   in Loop: Header=BB0_885 Depth=2
	shl.2d	v3, v6, #5
	ldr	q2, [sp, #8512]                 ; 16-byte Reload
	str	q3, [sp, #11360]                ; 16-byte Spill
	orr.16b	v2, v3, v2
	ldr	q3, [sp, #8448]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w8, #2, LBB0_891
; %bb.890:                              ; %cond.load3128
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x9, d2
	ld1.s	{ v0 }[2], [x9]
LBB0_891:                               ; %else3132
                                        ;   in Loop: Header=BB0_885 Depth=2
	tbz	w8, #3, LBB0_893
; %bb.892:                              ; %cond.load3134
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.d	x9, v2[1]
	ld1.s	{ v0 }[3], [x9]
LBB0_893:                               ; %else3138
                                        ;   in Loop: Header=BB0_885 Depth=2
	shl.2d	v3, v4, #5
	ldr	q2, [sp, #8496]                 ; 16-byte Reload
	str	q3, [sp, #11344]                ; 16-byte Spill
	orr.16b	v2, v3, v2
	ldr	q3, [sp, #8432]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w8, #4, LBB0_895
; %bb.894:                              ; %cond.load3140
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x9, d2
	ld1.s	{ v1 }[0], [x9]
LBB0_895:                               ; %else3144
                                        ;   in Loop: Header=BB0_885 Depth=2
	tbz	w8, #5, LBB0_897
; %bb.896:                              ; %cond.load3146
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.d	x9, v2[1]
	ld1.s	{ v1 }[1], [x9]
LBB0_897:                               ; %else3150
                                        ;   in Loop: Header=BB0_885 Depth=2
	shl.2d	v3, v7, #5
	ldr	q2, [sp, #8480]                 ; 16-byte Reload
	str	q3, [sp, #11328]                ; 16-byte Spill
	orr.16b	v2, v3, v2
	ldr	q3, [sp, #8416]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w8, #6, LBB0_899
; %bb.898:                              ; %cond.load3152
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x9, d2
	ld1.s	{ v1 }[2], [x9]
LBB0_899:                               ; %else3156
                                        ;   in Loop: Header=BB0_885 Depth=2
	tbz	w8, #7, LBB0_901
; %bb.900:                              ; %cond.load3158
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.d	x8, v2[1]
	ld1.s	{ v1 }[3], [x8]
LBB0_901:                               ; %else3162
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.16b	v27, v15
	sshll.2d	v2, v26, #0
	str	q4, [sp, #8256]                 ; 16-byte Spill
	and.16b	v4, v2, v4
	mov.d	x8, v4[1]
	sdiv	x9, x8, x26
	msub	x8, x9, x26, x8
	fmov	x9, d4
	ldr	q4, [sp, #11696]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	bit.16b	v23, v4, v2
	sshll.2d	v2, v24, #0
	str	q5, [sp, #8288]                 ; 16-byte Spill
	and.16b	v4, v2, v5
	mov.d	x8, v4[1]
	ldr	x10, [sp, #11736]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d4
	ldr	q4, [sp, #11712]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	bit.16b	v18, v4, v2
	str	q6, [sp, #8272]                 ; 16-byte Spill
	and.16b	v2, v12, v6
	mov.d	x8, v2[1]
	fmov	x9, d2
	str	q7, [sp, #8240]                 ; 16-byte Spill
	and.16b	v2, v14, v7
	ldr	q4, [sp, #11680]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	mov.d	x10, v2[1]
	fmov	x11, d2
	ldr	q2, [sp, #11664]                ; 16-byte Reload
	fmov	x12, d2
	sdiv	x14, x11, x12
	msub	x11, x14, x12, x11
	sdiv	x12, x8, x25
	msub	x8, x12, x25, x8
	sdiv	x12, x10, x27
	msub	x10, x12, x27, x10
	fmov	d2, x11
	mov.d	v2[1], x10
	ldr	q3, [sp, #6736]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	fmov	d2, x9
	mov.d	v2[1], x8
	bit.16b	v21, v2, v12
	ldr	q2, [sp, #3888]                 ; 16-byte Reload
	ldr	q4, [sp, #6624]                 ; 16-byte Reload
	bif.16b	v1, v4, v2
	ldr	q2, [sp, #3872]                 ; 16-byte Reload
	ldr	q4, [sp, #6640]                 ; 16-byte Reload
	bif.16b	v0, v4, v2
	sshll.2d	v2, v26, #0
	bic.16b	v28, v28, v2
	sshll.2d	v2, v24, #0
	bic.16b	v13, v13, v2
	movi	d2, #0x00000000ffffff
	ldr	q4, [sp, #6720]                 ; 16-byte Reload
	bit.8b	v4, v2, v8
	ldr	q2, [sp, #3856]                 ; 16-byte Reload
	and.16b	v2, v2, v0
	ldr	q0, [sp, #3840]                 ; 16-byte Reload
	and.16b	v0, v0, v1
	bic.16b	v19, v19, v14
	bic.16b	v25, v25, v12
	str	q0, [sp, #6624]                 ; 16-byte Spill
	bit.16b	v10, v0, v26
	str	q2, [sp, #6640]                 ; 16-byte Spill
	bit.16b	v22, v2, v24
	fmov	x8, d13
	cmp	x8, #32
	str	q3, [sp, #6736]                 ; 16-byte Spill
	str	q4, [sp, #6720]                 ; 16-byte Spill
	str	q18, [sp, #6688]                ; 16-byte Spill
	str	q21, [sp, #6672]                ; 16-byte Spill
	str	q23, [sp, #6656]                ; 16-byte Spill
	b.gt	LBB0_936
; %bb.902:                              ; %direct.true810.lr.ph
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x8, d18
	add	x8, x8, x8, lsl #2
	fmov	d6, x8
	mov.d	x8, v18[1]
	add	x8, x8, x8, lsl #2
	mov.d	v6[1], x8
	fmov	x8, d21
	add	x8, x8, x8, lsl #2
	mov.d	x9, v21[1]
	fmov	d29, x8
	add	x8, x9, x9, lsl #2
	mov.d	v29[1], x8
	fmov	x8, d23
	add	x8, x8, x8, lsl #2
	fmov	d2, x8
	mov.d	x8, v23[1]
	add	x8, x8, x8, lsl #2
	mov.d	v2[1], x8
	fmov	x8, d3
	add	x8, x8, x8, lsl #2
	mov.16b	v0, v8
	fmov	d8, x8
	mov.d	x8, v3[1]
	add	x8, x8, x8, lsl #2
	mov.d	v8[1], x8
	bic.8b	v0, v0, v4
	zip1.8b	v1, v0, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v30, v1, #0
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v18, v0, #0
	mov.16b	v3, v19
	b	LBB0_904
LBB0_903:                               ; %else3260
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.s	v7[1], v21[0]
	mov.s	v7[2], v23[0]
	mov.s	v7[3], v28[0]
	mov.s	v0[1], v1[0]
	mov.s	v0[2], v4[0]
	mov.s	v0[3], v5[0]
	ldr	q19, [sp, #12416]               ; 16-byte Reload
	bit.16b	v19, v0, v24
	ldr	q4, [sp, #12512]                ; 16-byte Reload
	bit.16b	v4, v7, v26
	ldr	q0, [sp, #11776]                ; 16-byte Reload
	ldr	q1, [sp, #12400]                ; 16-byte Reload
	bsl.16b	v0, v9, v1
	ldr	q1, [sp, #11760]                ; 16-byte Reload
	ldr	q5, [sp, #12432]                ; 16-byte Reload
	bsl.16b	v1, v25, v5
	and.16b	v1, v30, v1
	and.16b	v0, v18, v0
	str	q4, [sp, #12512]                ; 16-byte Spill
	str	q0, [sp, #12400]                ; 16-byte Spill
	fmul.4s	v0, v0, v4
	str	q1, [sp, #12432]                ; 16-byte Spill
	str	q19, [sp, #12416]               ; 16-byte Spill
	fmul.4s	v1, v1, v19
	fadd.4s	v1, v22, v1
	fadd.4s	v0, v10, v0
	ldr	q4, [sp, #13296]                ; 16-byte Reload
	add.2d	v25, v15, v4
	ldr	q4, [sp, #13280]                ; 16-byte Reload
	add.2d	v28, v17, v4
	add.2d	v3, v3, v11
	ldr	q4, [sp, #13264]                ; 16-byte Reload
	add.2d	v13, v13, v4
	bit.16b	v10, v0, v26
	bit.16b	v22, v1, v24
	fmov	x8, d13
	cmp	x8, #33
	b.ge	LBB0_937
LBB0_904:                               ; %direct.true810
                                        ;   Parent Loop BB0_91 Depth=1
                                        ;     Parent Loop BB0_885 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v0, v26, #0
	sshll.2d	v1, v24, #0
	mov.16b	v11, v13
	and.16b	v4, v1, v13
	mov.16b	v17, v28
	and.16b	v5, v0, v28
	mov.16b	v13, v3
	and.16b	v7, v14, v3
	mov.d	x8, v7[1]
	mov.16b	v15, v25
	and.16b	v21, v12, v25
	ldr	q19, [sp, #13008]               ; 16-byte Reload
	mov.d	x10, v19[1]
	sdiv	x8, x8, x10
	fmov	x9, d7
	fmov	x11, d19
	sdiv	x9, x9, x11
	mov.d	x12, v21[1]
	ldr	q19, [sp, #12992]               ; 16-byte Reload
	mov.d	x15, v19[1]
	sdiv	x6, x12, x15
	fmov	x12, d21
	fmov	x19, d19
	mov.d	x14, v5[1]
	ldr	q19, [sp, #12976]               ; 16-byte Reload
	mov.d	x20, v19[1]
	sdiv	x7, x12, x19
	sdiv	x14, x14, x20
	fmov	x12, d5
	fmov	x21, d19
	mov.d	x22, v4[1]
	ldr	q19, [sp, #12960]               ; 16-byte Reload
	mov.d	x23, v19[1]
	sdiv	x22, x22, x23
	fmov	x24, d4
	fmov	x25, d19
	sdiv	x24, x24, x25
	mul	x25, x24, x25
	fmov	d19, x24
	mov.d	v19[1], x22
	mul	x10, x8, x10
	mul	x11, x9, x11
	fmov	d23, x11
	mov.d	v23[1], x10
	mul	x10, x6, x15
	mul	x11, x7, x19
	fmov	d25, x11
	mov.d	v25[1], x10
	mul	x10, x14, x20
	sdiv	x19, x12, x21
	mul	x11, x19, x21
	fmov	d28, x11
	mov.d	v28[1], x10
	mul	x10, x22, x23
	fmov	d31, x25
	mov.d	v31[1], x10
	add.2d	v19, v19, v6
	sub.2d	v4, v4, v31
	sub.2d	v5, v5, v28
	sub.2d	v21, v21, v25
	sub.2d	v28, v7, v23
	ldr	q7, [sp, #13040]                ; 16-byte Reload
	cmeq.2d	v7, v7, v28
	ldr	q23, [sp, #13056]               ; 16-byte Reload
	cmeq.2d	v23, v23, v5
	uzp1.4s	v7, v23, v7
	ldr	q23, [sp, #13072]               ; 16-byte Reload
	cmeq.2d	v23, v23, v21
	ldr	q25, [sp, #13104]               ; 16-byte Reload
	cmeq.2d	v25, v25, v4
	uzp1.4s	v23, v25, v23
	uzp1.8h	v23, v23, v7
	ldr	q7, [sp, #13328]                ; 16-byte Reload
	and.16b	v7, v7, v23
	xtn.8b	v7, v7
	shl.8b	v25, v7, #7
	cmlt.8b	v25, v25, #0
	ldr	d31, [sp, #13320]               ; 8-byte Reload
	and.8b	v25, v25, v31
	addv.8b	b25, v25
	fmov	w15, s25
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12784]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12736]                ; 16-byte Reload
	add.2d	v31, v3, v19
	movi.2d	v25, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbz	w15, #0, LBB0_906
; %bb.905:                              ; %cond.load3165
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	x10, d31
	ldr	s25, [x10]
LBB0_906:                               ; %else3169
                                        ;   in Loop: Header=BB0_904 Depth=3
	tbz	w15, #1, LBB0_908
; %bb.907:                              ; %cond.load3171
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v25 }[1], [x10]
LBB0_908:                               ; %else3175
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	d19, x7
	mov.d	v19[1], x6
	add.2d	v19, v19, v29
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12768]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12832]                ; 16-byte Reload
	add.2d	v31, v3, v19
	tbz	w15, #2, LBB0_910
; %bb.909:                              ; %cond.load3177
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	x10, d31
	ld1.s	{ v25 }[2], [x10]
LBB0_910:                               ; %else3181
                                        ;   in Loop: Header=BB0_904 Depth=3
	tbz	w15, #3, LBB0_912
; %bb.911:                              ; %cond.load3183
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v25 }[3], [x10]
LBB0_912:                               ; %else3187
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	d19, x19
	mov.d	v19[1], x14
	add.2d	v19, v19, v2
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12752]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12816]                ; 16-byte Reload
	add.2d	v31, v3, v19
	tbz	w15, #4, LBB0_914
; %bb.913:                              ; %cond.load3189
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	x10, d31
	ld1.s	{ v9 }[0], [x10]
LBB0_914:                               ; %else3193
                                        ;   in Loop: Header=BB0_904 Depth=3
	tbz	w15, #5, LBB0_916
; %bb.915:                              ; %cond.load3195
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.d	x10, v31[1]
	ld1.s	{ v9 }[1], [x10]
LBB0_916:                               ; %else3199
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	d19, x9
	mov.d	v19[1], x8
	add.2d	v19, v19, v8
	shl.2d	v19, v19, #5
	ldr	q3, [sp, #12848]                ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #12800]                ; 16-byte Reload
	add.2d	v31, v3, v19
	tbz	w15, #6, LBB0_918
; %bb.917:                              ; %cond.load3201
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	x8, d31
	ld1.s	{ v9 }[2], [x8]
LBB0_918:                               ; %else3205
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.16b	v3, v13
	mov.16b	v13, v11
	tbz	w15, #7, LBB0_920
; %bb.919:                              ; %cond.load3207
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.d	x8, v31[1]
	ld1.s	{ v9 }[3], [x8]
LBB0_920:                               ; %else3211
                                        ;   in Loop: Header=BB0_904 Depth=3
	ldr	q19, [sp, #12528]               ; 16-byte Reload
	bit.16b	v19, v28, v14
	ldr	q31, [sp, #12480]               ; 16-byte Reload
	bit.16b	v31, v21, v12
	ldr	q11, [sp, #12464]               ; 16-byte Reload
	bit.16b	v11, v5, v0
	ldr	q21, [sp, #12496]               ; 16-byte Reload
	bit.16b	v21, v4, v1
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	bic.16b	v0, v0, v23
	xtn.8b	v0, v0
	zip2.8b	v1, v7, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	ldr	q4, [sp, #12384]                ; 16-byte Reload
	bsl.16b	v1, v9, v4
	zip1.8b	v4, v7, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	ldr	q5, [sp, #12448]                ; 16-byte Reload
	bsl.16b	v4, v25, v5
	zip1.8b	v5, v0, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmge.4s	v5, v5, #0
	and.16b	v25, v5, v4
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v9, v0, v1
	str	q19, [sp, #12528]               ; 16-byte Spill
	xtn.2s	v28, v19
	str	q11, [sp, #12464]               ; 16-byte Spill
	xtn.2s	v7, v11
	str	q31, [sp, #12480]               ; 16-byte Spill
	xtn.2s	v4, v31
	str	q21, [sp, #12496]               ; 16-byte Spill
	xtn.2s	v0, v21
	mov.s	w8, v0[1]
	fmov	w9, s0
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldr	q0, [sp, #13136]                ; 16-byte Reload
	str	d0, [sp, #13624]
	ldrb	w11, [x11]
	and	w11, w16, w11
	stp	q25, q9, [x13, #144]
	ldr	s0, [x28, x9, lsl #2]
	tst	w10, w11
	movi.2d	v31, #0000000000000000
	fcsel	s0, s0, s31, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	stp	q25, q9, [x13, #176]
	ldr	s1, [x30, x10, lsl #2]
	and	w8, w17, w8
	tst	w9, w8
	fcsel	s1, s1, s31, ne
	mov.s	w8, v4[1]
	fmov	w9, s4
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w0, w11
	stp	q25, q9, [x13, #208]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1408
	ldr	s4, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s4, s4, s31, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w1, w8
	stp	q25, q9, [x13, #240]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1440
	ldr	s5, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s5, s5, s31, ne
	mov.s	w8, v7[1]
	fmov	w9, s7
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	stp	q25, q9, [x13, #272]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1472
	ldr	s7, [x12, x9, lsl #2]
	and	w9, w2, w11
	tst	w10, w9
	fcsel	s7, s7, s31, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w3, w8
	stp	q25, q9, [x13, #304]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1504
	ldr	s19, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	w8, v28[1]
	fcsel	s21, s19, s31, ne
	fmov	w9, s28
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w4, w11
	stp	q25, q9, [x13, #336]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1536
	ldr	s19, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s23, s19, s31, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1336
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w5, w8
	str	q9, [sp, #12384]                ; 16-byte Spill
	str	q9, [x13, #384]
	str	q25, [sp, #12448]               ; 16-byte Spill
	str	q25, [x13, #368]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1568
	ldr	s19, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s28, s19, s31, ne
	shl.2d	v19, v13, #5
	ldr	q25, [sp, #12032]               ; 16-byte Reload
	orr.16b	v19, v19, v25
	ldr	q25, [sp, #12096]               ; 16-byte Reload
	add.2d	v31, v25, v19
	ldr	d19, [sp, #12376]               ; 8-byte Reload
	fmov	w8, s19
	movi.2d	v25, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbnz	w8, #0, LBB0_928
; %bb.921:                              ; %else3218
                                        ;   in Loop: Header=BB0_904 Depth=3
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	tbnz	w8, #1, LBB0_929
LBB0_922:                               ; %else3224
                                        ;   in Loop: Header=BB0_904 Depth=3
	shl.2d	v19, v15, #5
	ldr	q31, [sp, #12016]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #12080]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbnz	w8, #2, LBB0_930
LBB0_923:                               ; %else3230
                                        ;   in Loop: Header=BB0_904 Depth=3
	tbnz	w8, #3, LBB0_931
LBB0_924:                               ; %else3236
                                        ;   in Loop: Header=BB0_904 Depth=3
	shl.2d	v19, v17, #5
	ldr	q31, [sp, #12000]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #12064]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbnz	w8, #4, LBB0_932
LBB0_925:                               ; %else3242
                                        ;   in Loop: Header=BB0_904 Depth=3
	tbnz	w8, #5, LBB0_933
LBB0_926:                               ; %else3248
                                        ;   in Loop: Header=BB0_904 Depth=3
	shl.2d	v19, v3, #5
	ldr	q31, [sp, #11984]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #12048]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbnz	w8, #6, LBB0_934
LBB0_927:                               ; %else3254
                                        ;   in Loop: Header=BB0_904 Depth=3
	tbz	w8, #7, LBB0_903
	b	LBB0_935
LBB0_928:                               ; %cond.load3214
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	x9, d31
	ldr	s25, [x9]
	ldr	q11, [sp, #13248]               ; 16-byte Reload
	tbz	w8, #1, LBB0_922
LBB0_929:                               ; %cond.load3220
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.d	x9, v31[1]
	ld1.s	{ v25 }[1], [x9]
	shl.2d	v19, v15, #5
	ldr	q31, [sp, #12016]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #12080]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbz	w8, #2, LBB0_923
LBB0_930:                               ; %cond.load3226
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	x9, d31
	ld1.s	{ v25 }[2], [x9]
	tbz	w8, #3, LBB0_924
LBB0_931:                               ; %cond.load3232
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.d	x9, v31[1]
	ld1.s	{ v25 }[3], [x9]
	shl.2d	v19, v17, #5
	ldr	q31, [sp, #12000]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #12064]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbz	w8, #4, LBB0_925
LBB0_932:                               ; %cond.load3238
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	x9, d31
	ld1.s	{ v9 }[0], [x9]
	tbz	w8, #5, LBB0_926
LBB0_933:                               ; %cond.load3244
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.d	x9, v31[1]
	ld1.s	{ v9 }[1], [x9]
	shl.2d	v19, v3, #5
	ldr	q31, [sp, #11984]               ; 16-byte Reload
	orr.16b	v19, v19, v31
	ldr	q31, [sp, #12048]               ; 16-byte Reload
	add.2d	v31, v31, v19
	tbz	w8, #6, LBB0_927
LBB0_934:                               ; %cond.load3250
                                        ;   in Loop: Header=BB0_904 Depth=3
	fmov	x9, d31
	ld1.s	{ v9 }[2], [x9]
	tbz	w8, #7, LBB0_903
LBB0_935:                               ; %cond.load3256
                                        ;   in Loop: Header=BB0_904 Depth=3
	mov.d	x8, v31[1]
	ld1.s	{ v9 }[3], [x8]
	b	LBB0_903
LBB0_936:                               ;   in Loop: Header=BB0_885 Depth=2
	mov.16b	v3, v19
LBB0_937:                               ; %direct.false811
                                        ;   in Loop: Header=BB0_885 Depth=2
	ldr	q0, [sp, #8320]                 ; 16-byte Reload
	ldr	q1, [sp, #11376]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8384]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	d1, [sp, #12376]                ; 8-byte Reload
	fmov	w8, s1
	tbnz	w8, #0, LBB0_946
; %bb.938:                              ; %else3266
                                        ;   in Loop: Header=BB0_885 Depth=2
	ldr	d2, [sp, #11624]                ; 8-byte Reload
	mov.16b	v15, v27
	tbnz	w8, #1, LBB0_947
LBB0_939:                               ; %else3270
                                        ;   in Loop: Header=BB0_885 Depth=2
	ldr	q0, [sp, #8304]                 ; 16-byte Reload
	ldr	q1, [sp, #11360]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8368]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #2, LBB0_941
LBB0_940:                               ; %cond.store3271
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x9, d0
	st1.s	{ v22 }[2], [x9]
LBB0_941:                               ; %else3274
                                        ;   in Loop: Header=BB0_885 Depth=2
	ldr	q8, [sp, #13136]                ; 16-byte Reload
	ldr	x25, [sp, #11640]               ; 8-byte Reload
	ldr	q5, [sp, #8288]                 ; 16-byte Reload
	ldr	q6, [sp, #8272]                 ; 16-byte Reload
	ldr	q4, [sp, #8256]                 ; 16-byte Reload
	ldr	q7, [sp, #8240]                 ; 16-byte Reload
	mov.16b	v27, v2
	tbnz	w8, #3, LBB0_948
; %bb.942:                              ; %else3278
                                        ;   in Loop: Header=BB0_885 Depth=2
	ldr	q0, [sp, #11344]                ; 16-byte Reload
	orr.16b	v0, v0, v15
	ldr	q1, [sp, #8352]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #4, LBB0_949
LBB0_943:                               ; %else3282
                                        ;   in Loop: Header=BB0_885 Depth=2
	tbnz	w8, #5, LBB0_950
LBB0_944:                               ; %else3286
                                        ;   in Loop: Header=BB0_885 Depth=2
	ldr	q0, [sp, #8400]                 ; 16-byte Reload
	ldr	q1, [sp, #11328]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8336]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #6, LBB0_951
LBB0_945:                               ; %else3290
                                        ;   in Loop: Header=BB0_885 Depth=2
	tbz	w8, #7, LBB0_884
	b	LBB0_952
LBB0_946:                               ; %cond.store3263
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x9, d0
	str	s22, [x9]
	ldr	d2, [sp, #11624]                ; 8-byte Reload
	mov.16b	v15, v27
	tbz	w8, #1, LBB0_939
LBB0_947:                               ; %cond.store3267
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v22 }[1], [x9]
	ldr	q0, [sp, #8304]                 ; 16-byte Reload
	ldr	q1, [sp, #11360]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8368]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #2, LBB0_940
	b	LBB0_941
LBB0_948:                               ; %cond.store3275
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v22 }[3], [x9]
	ldr	q0, [sp, #11344]                ; 16-byte Reload
	orr.16b	v0, v0, v15
	ldr	q1, [sp, #8352]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #4, LBB0_943
LBB0_949:                               ; %cond.store3279
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x9, d0
	str	s10, [x9]
	tbz	w8, #5, LBB0_944
LBB0_950:                               ; %cond.store3283
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v10 }[1], [x9]
	ldr	q0, [sp, #8400]                 ; 16-byte Reload
	ldr	q1, [sp, #11328]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #8336]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_945
LBB0_951:                               ; %cond.store3287
                                        ;   in Loop: Header=BB0_885 Depth=2
	fmov	x9, d0
	st1.s	{ v10 }[2], [x9]
	tbz	w8, #7, LBB0_884
LBB0_952:                               ; %cond.store3291
                                        ;   in Loop: Header=BB0_885 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v10 }[3], [x8]
	b	LBB0_884
LBB0_953:                               ;   in Loop: Header=BB0_91 Depth=1
	ldr	q15, [sp, #1968]                ; 16-byte Reload
	ldr	q3, [sp, #864]                  ; 16-byte Reload
	ldr	q22, [sp, #1136]                ; 16-byte Reload
	ldr	q10, [sp, #1120]                ; 16-byte Reload
	ldr	q25, [sp, #1104]                ; 16-byte Reload
	ldr	q28, [sp, #1088]                ; 16-byte Reload
LBB0_954:                               ; %direct.false802
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q28, [sp, #1088]                ; 16-byte Spill
	str	q25, [sp, #1104]                ; 16-byte Spill
	str	q10, [sp, #1120]                ; 16-byte Spill
	str	q22, [sp, #1136]                ; 16-byte Spill
	str	q7, [sp, #8240]                 ; 16-byte Spill
	str	q4, [sp, #8256]                 ; 16-byte Spill
	str	q6, [sp, #8272]                 ; 16-byte Spill
	str	q5, [sp, #8288]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldp	q21, q19, [sp, #816]            ; 32-byte Folded Reload
	bic.16b	v21, v21, v14
	ldr	q18, [sp, #848]                 ; 16-byte Reload
	bic.16b	v18, v18, v12
	bic.16b	v19, v19, v1
	ldr	q1, [sp, #1072]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x8, d0
	cmp	x8, #1
	ldr	q25, [sp, #1888]                ; 16-byte Reload
	ldr	q28, [sp, #1872]                ; 16-byte Reload
	ldr	q29, [sp, #1856]                ; 16-byte Reload
	ldr	q30, [sp, #1840]                ; 16-byte Reload
	ldr	q31, [sp, #224]                 ; 16-byte Reload
	mov.16b	v17, v3
	ldp	q8, q22, [sp, #784]             ; 32-byte Folded Reload
	ldr	q10, [sp, #736]                 ; 16-byte Reload
	b.lt	LBB0_957
LBB0_955:                               ; %direct.false840
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q0, [sp, #1072]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #9968]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #9968]                 ; 16-byte Spill
	bic.16b	v22, v22, v12
	bic.16b	v8, v8, v1
	ldr	q1, [sp, #1056]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	b	LBB0_990
LBB0_956:                               ; %else3376
                                        ;   in Loop: Header=BB0_957 Depth=2
	str	q2, [sp, #4992]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v18, v18, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v19, v19, v0
	ldr	q0, [sp, #13248]                ; 16-byte Reload
	add.2d	v21, v21, v0
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v0, v11, v0
	fmov	x8, d0
	cmp	x8, #1
	b.ge	LBB0_955
LBB0_957:                               ; %direct.true839
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v11, v0
	shl.2d	v1, v0, #5
	ldr	q0, [sp, #10416]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q2, [sp, #10480]                ; 16-byte Reload
	add.2d	v4, v2, v0
	fmov	w8, s27
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w8, #0, LBB0_975
; %bb.958:                              ; %else3300
                                        ;   in Loop: Header=BB0_957 Depth=2
	tbnz	w8, #1, LBB0_976
LBB0_959:                               ; %else3306
                                        ;   in Loop: Header=BB0_957 Depth=2
	shl.2d	v4, v18, #5
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	orr.16b	v5, v4, v3
	ldr	q3, [sp, #10464]                ; 16-byte Reload
	add.2d	v5, v3, v5
	tbnz	w8, #2, LBB0_977
LBB0_960:                               ; %else3312
                                        ;   in Loop: Header=BB0_957 Depth=2
	tbnz	w8, #3, LBB0_978
LBB0_961:                               ; %else3318
                                        ;   in Loop: Header=BB0_957 Depth=2
	shl.2d	v5, v19, #5
	ldr	q3, [sp, #10512]                ; 16-byte Reload
	orr.16b	v6, v5, v3
	ldr	q3, [sp, #10448]                ; 16-byte Reload
	add.2d	v6, v3, v6
	tbnz	w8, #4, LBB0_979
LBB0_962:                               ; %else3324
                                        ;   in Loop: Header=BB0_957 Depth=2
	tbnz	w8, #5, LBB0_980
LBB0_963:                               ; %else3330
                                        ;   in Loop: Header=BB0_957 Depth=2
	shl.2d	v6, v21, #5
	ldr	q3, [sp, #10496]                ; 16-byte Reload
	orr.16b	v7, v6, v3
	ldr	q3, [sp, #10432]                ; 16-byte Reload
	add.2d	v7, v3, v7
	tbnz	w8, #6, LBB0_981
LBB0_964:                               ; %else3336
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.16b	v3, v17
	tbz	w8, #7, LBB0_966
LBB0_965:                               ; %cond.load3338
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_966:                               ; %else3342
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	w8, s27
	ldr	q7, [sp, #2400]                 ; 16-byte Reload
	ldr	q23, [sp, #10576]               ; 16-byte Reload
	bif.16b	v2, v23, v7
	ldr	q7, [sp, #2352]                 ; 16-byte Reload
	and.16b	v2, v7, v2
	str	q2, [sp, #10576]                ; 16-byte Spill
	ldr	q2, [sp, #12336]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #5744]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #0, LBB0_982
; %bb.967:                              ; %else3348
                                        ;   in Loop: Header=BB0_957 Depth=2
	tbnz	w8, #1, LBB0_983
LBB0_968:                               ; %else3352
                                        ;   in Loop: Header=BB0_957 Depth=2
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q2, [sp, #5776]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #2, LBB0_984
LBB0_969:                               ; %else3356
                                        ;   in Loop: Header=BB0_957 Depth=2
	tbz	w8, #3, LBB0_971
LBB0_970:                               ; %cond.store3357
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10576]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_971:                               ; %else3360
                                        ;   in Loop: Header=BB0_957 Depth=2
	ldr	q1, [sp, #2384]                 ; 16-byte Reload
	ldr	q2, [sp, #4992]                 ; 16-byte Reload
	bif.16b	v0, v2, v1
	ldr	q1, [sp, #2368]                 ; 16-byte Reload
	and.16b	v2, v1, v0
	ldr	q0, [sp, #12352]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	ldr	q1, [sp, #5760]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #4, LBB0_985
; %bb.972:                              ; %else3364
                                        ;   in Loop: Header=BB0_957 Depth=2
	tbnz	w8, #5, LBB0_986
LBB0_973:                               ; %else3368
                                        ;   in Loop: Header=BB0_957 Depth=2
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #5792]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #6, LBB0_987
LBB0_974:                               ; %else3372
                                        ;   in Loop: Header=BB0_957 Depth=2
	tbz	w8, #7, LBB0_956
	b	LBB0_988
LBB0_975:                               ; %cond.load3296
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	x9, d4
	ldr	s2, [x9]
	tbz	w8, #1, LBB0_959
LBB0_976:                               ; %cond.load3302
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v2 }[1], [x9]
	shl.2d	v4, v18, #5
	ldr	q3, [sp, #10528]                ; 16-byte Reload
	orr.16b	v5, v4, v3
	ldr	q3, [sp, #10464]                ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w8, #2, LBB0_960
LBB0_977:                               ; %cond.load3308
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	x9, d5
	ld1.s	{ v2 }[2], [x9]
	tbz	w8, #3, LBB0_961
LBB0_978:                               ; %cond.load3314
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v2 }[3], [x9]
	shl.2d	v5, v19, #5
	ldr	q3, [sp, #10512]                ; 16-byte Reload
	orr.16b	v6, v5, v3
	ldr	q3, [sp, #10448]                ; 16-byte Reload
	add.2d	v6, v3, v6
	tbz	w8, #4, LBB0_962
LBB0_979:                               ; %cond.load3320
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
	tbz	w8, #5, LBB0_963
LBB0_980:                               ; %cond.load3326
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
	shl.2d	v6, v21, #5
	ldr	q3, [sp, #10496]                ; 16-byte Reload
	orr.16b	v7, v6, v3
	ldr	q3, [sp, #10432]                ; 16-byte Reload
	add.2d	v7, v3, v7
	tbz	w8, #6, LBB0_964
LBB0_981:                               ; %cond.load3332
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
	mov.16b	v3, v17
	tbnz	w8, #7, LBB0_965
	b	LBB0_966
LBB0_982:                               ; %cond.store3345
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #10576]                ; 16-byte Reload
	str	s2, [x9]
	tbz	w8, #1, LBB0_968
LBB0_983:                               ; %cond.store3349
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10576]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q2, [sp, #5776]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #2, LBB0_969
LBB0_984:                               ; %cond.store3353
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #10576]                ; 16-byte Reload
	st1.s	{ v2 }[2], [x9]
	tbnz	w8, #3, LBB0_970
	b	LBB0_971
LBB0_985:                               ; %cond.store3361
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	x9, d0
	str	s2, [x9]
	tbz	w8, #5, LBB0_973
LBB0_986:                               ; %cond.store3365
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v2 }[1], [x9]
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #5792]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_974
LBB0_987:                               ; %cond.store3369
                                        ;   in Loop: Header=BB0_957 Depth=2
	fmov	x9, d0
	st1.s	{ v2 }[2], [x9]
	tbz	w8, #7, LBB0_956
LBB0_988:                               ; %cond.store3373
                                        ;   in Loop: Header=BB0_957 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v2 }[3], [x8]
	b	LBB0_956
LBB0_989:                               ; %else3458
                                        ;   in Loop: Header=BB0_990 Depth=2
	str	q2, [sp, #4976]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v22, v22, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v8, v8, v0
	ldr	q0, [sp, #9968]                 ; 16-byte Reload
	ldr	q1, [sp, #13248]                ; 16-byte Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #9968]                 ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v0, v11, v0
LBB0_990:                               ; %direct.false840
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	x8, d0
	cmp	x8, #1
	b.ge	LBB0_1023
; %bb.991:                              ; %direct.true851
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.16b	v11, v0
	shl.2d	v1, v0, #5
	ldr	q0, [sp, #5904]                 ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q2, [sp, #5856]                 ; 16-byte Reload
	add.2d	v4, v2, v0
	fmov	w8, s27
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w8, #0, LBB0_1011
; %bb.992:                              ; %else3382
                                        ;   in Loop: Header=BB0_990 Depth=2
	tbnz	w8, #1, LBB0_1012
LBB0_993:                               ; %else3388
                                        ;   in Loop: Header=BB0_990 Depth=2
	shl.2d	v4, v22, #5
	ldr	q3, [sp, #5888]                 ; 16-byte Reload
	orr.16b	v5, v4, v3
	ldr	q3, [sp, #5952]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbnz	w8, #2, LBB0_1013
LBB0_994:                               ; %else3394
                                        ;   in Loop: Header=BB0_990 Depth=2
	tbnz	w8, #3, LBB0_1014
LBB0_995:                               ; %else3400
                                        ;   in Loop: Header=BB0_990 Depth=2
	shl.2d	v5, v8, #5
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	orr.16b	v6, v5, v3
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	tbnz	w8, #4, LBB0_1015
LBB0_996:                               ; %else3406
                                        ;   in Loop: Header=BB0_990 Depth=2
	tbz	w8, #5, LBB0_998
LBB0_997:                               ; %cond.load3408
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_998:                               ; %else3412
                                        ;   in Loop: Header=BB0_990 Depth=2
	ldr	q3, [sp, #9968]                 ; 16-byte Reload
	shl.2d	v6, v3, #5
	ldr	q3, [sp, #5968]                 ; 16-byte Reload
	orr.16b	v7, v6, v3
	ldr	q3, [sp, #5920]                 ; 16-byte Reload
	add.2d	v7, v3, v7
	tbz	w8, #6, LBB0_1000
; %bb.999:                              ; %cond.load3414
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1000:                              ; %else3418
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.16b	v3, v17
	tbz	w8, #7, LBB0_1002
; %bb.1001:                             ; %cond.load3420
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1002:                              ; %else3424
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	w8, s27
	ldr	q7, [sp, #2336]                 ; 16-byte Reload
	ldr	q23, [sp, #10560]               ; 16-byte Reload
	bif.16b	v2, v23, v7
	ldr	q7, [sp, #2288]                 ; 16-byte Reload
	and.16b	v2, v7, v2
	str	q2, [sp, #10560]                ; 16-byte Spill
	ldr	q2, [sp, #12336]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #0, LBB0_1016
; %bb.1003:                             ; %else3430
                                        ;   in Loop: Header=BB0_990 Depth=2
	tbnz	w8, #1, LBB0_1017
LBB0_1004:                              ; %else3434
                                        ;   in Loop: Header=BB0_990 Depth=2
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #2, LBB0_1018
LBB0_1005:                              ; %else3438
                                        ;   in Loop: Header=BB0_990 Depth=2
	tbz	w8, #3, LBB0_1007
LBB0_1006:                              ; %cond.store3439
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10560]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1007:                              ; %else3442
                                        ;   in Loop: Header=BB0_990 Depth=2
	ldr	q1, [sp, #2320]                 ; 16-byte Reload
	ldr	q2, [sp, #4976]                 ; 16-byte Reload
	bif.16b	v0, v2, v1
	ldr	q1, [sp, #2304]                 ; 16-byte Reload
	and.16b	v2, v1, v0
	ldr	q0, [sp, #12352]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	ldr	q1, [sp, #5696]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #4, LBB0_1019
; %bb.1008:                             ; %else3446
                                        ;   in Loop: Header=BB0_990 Depth=2
	tbnz	w8, #5, LBB0_1020
LBB0_1009:                              ; %else3450
                                        ;   in Loop: Header=BB0_990 Depth=2
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #5728]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #6, LBB0_1021
LBB0_1010:                              ; %else3454
                                        ;   in Loop: Header=BB0_990 Depth=2
	tbz	w8, #7, LBB0_989
	b	LBB0_1022
LBB0_1011:                              ; %cond.load3378
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	x9, d4
	ldr	s2, [x9]
	tbz	w8, #1, LBB0_993
LBB0_1012:                              ; %cond.load3384
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v2 }[1], [x9]
	shl.2d	v4, v22, #5
	ldr	q3, [sp, #5888]                 ; 16-byte Reload
	orr.16b	v5, v4, v3
	ldr	q3, [sp, #5952]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w8, #2, LBB0_994
LBB0_1013:                              ; %cond.load3390
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	x9, d5
	ld1.s	{ v2 }[2], [x9]
	tbz	w8, #3, LBB0_995
LBB0_1014:                              ; %cond.load3396
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v2 }[3], [x9]
	shl.2d	v5, v8, #5
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	orr.16b	v6, v5, v3
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	tbz	w8, #4, LBB0_996
LBB0_1015:                              ; %cond.load3402
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
	tbnz	w8, #5, LBB0_997
	b	LBB0_998
LBB0_1016:                              ; %cond.store3427
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #10560]                ; 16-byte Reload
	str	s2, [x9]
	tbz	w8, #1, LBB0_1004
LBB0_1017:                              ; %cond.store3431
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10560]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #2, LBB0_1005
LBB0_1018:                              ; %cond.store3435
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #10560]                ; 16-byte Reload
	st1.s	{ v2 }[2], [x9]
	tbnz	w8, #3, LBB0_1006
	b	LBB0_1007
LBB0_1019:                              ; %cond.store3443
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	x9, d0
	str	s2, [x9]
	tbz	w8, #5, LBB0_1009
LBB0_1020:                              ; %cond.store3447
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v2 }[1], [x9]
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #5728]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_1010
LBB0_1021:                              ; %cond.store3451
                                        ;   in Loop: Header=BB0_990 Depth=2
	fmov	x9, d0
	st1.s	{ v2 }[2], [x9]
	tbz	w8, #7, LBB0_989
LBB0_1022:                              ; %cond.store3455
                                        ;   in Loop: Header=BB0_990 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v2 }[3], [x8]
	b	LBB0_989
LBB0_1023:                              ; %direct.false852
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q0, [sp, #1056]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #10992]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #10992]                ; 16-byte Spill
	ldr	q2, [sp, #11024]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #11024]                ; 16-byte Spill
	ldr	q2, [sp, #11008]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #11008]                ; 16-byte Spill
	ldr	q1, [sp, #1040]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x8, d0
	cmp	x8, #1
	b.le	LBB0_1028
LBB0_1024:                              ; %direct.false864
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q0, [sp, #1040]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #9920]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #9920]                 ; 16-byte Spill
	ldr	q2, [sp, #9952]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #9952]                 ; 16-byte Spill
	ldr	q2, [sp, #9936]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #9936]                 ; 16-byte Spill
	ldr	q1, [sp, #1024]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	fmov	x8, d0
	cmp	x8, #1
	b.lt	LBB0_1433
; %bb.1025:                             ;   in Loop: Header=BB0_91 Depth=1
	ldr	q17, [sp, #8096]                ; 16-byte Reload
LBB0_1026:                              ; %direct.false876
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q0, [sp, #1024]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #9872]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #9872]                 ; 16-byte Spill
	ldr	q2, [sp, #9904]                 ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #9904]                 ; 16-byte Spill
	ldr	q2, [sp, #9888]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #9888]                 ; 16-byte Spill
	ldr	q1, [sp, #1008]                 ; 16-byte Reload
	bic.16b	v0, v1, v0
	b	LBB0_1061
LBB0_1027:                              ; %else3540
                                        ;   in Loop: Header=BB0_1028 Depth=2
	str	q2, [sp, #6608]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #11024]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #11024]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #11008]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #11008]                ; 16-byte Spill
	ldr	q0, [sp, #10992]                ; 16-byte Reload
	ldr	q1, [sp, #13248]                ; 16-byte Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #10992]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v0, v11, v0
	fmov	x8, d0
	cmp	x8, #2
	b.ge	LBB0_1024
LBB0_1028:                              ; %direct.true863
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v11, v0
	shl.2d	v1, v0, #5
	ldr	q0, [sp, #8320]                 ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q2, [sp, #8384]                 ; 16-byte Reload
	add.2d	v4, v2, v0
	ldr	d0, [sp, #12376]                ; 8-byte Reload
	fmov	w8, s0
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_1030
; %bb.1029:                             ; %cond.load3460
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x9, d4
	ldr	s2, [x9]
LBB0_1030:                              ; %else3464
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbz	w8, #1, LBB0_1032
; %bb.1031:                             ; %cond.load3466
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_1032:                              ; %else3470
                                        ;   in Loop: Header=BB0_1028 Depth=2
	ldr	q3, [sp, #11024]                ; 16-byte Reload
	shl.2d	v4, v3, #5
	ldr	q3, [sp, #8304]                 ; 16-byte Reload
	orr.16b	v5, v4, v3
	ldr	q3, [sp, #8368]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbnz	w8, #2, LBB0_1050
; %bb.1033:                             ; %else3476
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbnz	w8, #3, LBB0_1051
LBB0_1034:                              ; %else3482
                                        ;   in Loop: Header=BB0_1028 Depth=2
	ldr	q3, [sp, #11008]                ; 16-byte Reload
	shl.2d	v5, v3, #5
	orr.16b	v6, v5, v15
	ldr	q3, [sp, #8352]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	tbnz	w8, #4, LBB0_1052
LBB0_1035:                              ; %else3488
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbz	w8, #5, LBB0_1037
LBB0_1036:                              ; %cond.load3490
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1037:                              ; %else3494
                                        ;   in Loop: Header=BB0_1028 Depth=2
	ldr	q3, [sp, #10992]                ; 16-byte Reload
	shl.2d	v6, v3, #5
	ldr	q3, [sp, #8400]                 ; 16-byte Reload
	orr.16b	v7, v6, v3
	ldr	q3, [sp, #8336]                 ; 16-byte Reload
	add.2d	v7, v3, v7
	tbz	w8, #6, LBB0_1039
; %bb.1038:                             ; %cond.load3496
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1039:                              ; %else3500
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.16b	v3, v17
	tbz	w8, #7, LBB0_1041
; %bb.1040:                             ; %cond.load3502
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1041:                              ; %else3506
                                        ;   in Loop: Header=BB0_1028 Depth=2
	ldr	d7, [sp, #12376]                ; 8-byte Reload
	fmov	w8, s7
	ldr	q7, [sp, #3824]                 ; 16-byte Reload
	ldr	q23, [sp, #11424]               ; 16-byte Reload
	bif.16b	v2, v23, v7
	ldr	q7, [sp, #3776]                 ; 16-byte Reload
	and.16b	v2, v7, v2
	str	q2, [sp, #11424]                ; 16-byte Spill
	ldr	q2, [sp, #12336]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #7984]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #0, LBB0_1053
; %bb.1042:                             ; %else3512
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbnz	w8, #1, LBB0_1054
LBB0_1043:                              ; %else3516
                                        ;   in Loop: Header=BB0_1028 Depth=2
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q2, [sp, #8016]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #2, LBB0_1055
LBB0_1044:                              ; %else3520
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbz	w8, #3, LBB0_1046
LBB0_1045:                              ; %cond.store3521
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11424]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1046:                              ; %else3524
                                        ;   in Loop: Header=BB0_1028 Depth=2
	ldr	q1, [sp, #3808]                 ; 16-byte Reload
	ldr	q2, [sp, #6608]                 ; 16-byte Reload
	bif.16b	v0, v2, v1
	ldr	q1, [sp, #3792]                 ; 16-byte Reload
	and.16b	v2, v1, v0
	ldr	q0, [sp, #12352]                ; 16-byte Reload
	orr.16b	v0, v5, v0
	ldr	q1, [sp, #8000]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #4, LBB0_1056
; %bb.1047:                             ; %else3528
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbnz	w8, #5, LBB0_1057
LBB0_1048:                              ; %else3532
                                        ;   in Loop: Header=BB0_1028 Depth=2
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #8032]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbnz	w8, #6, LBB0_1058
LBB0_1049:                              ; %else3536
                                        ;   in Loop: Header=BB0_1028 Depth=2
	tbz	w8, #7, LBB0_1027
	b	LBB0_1059
LBB0_1050:                              ; %cond.load3472
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x9, d5
	ld1.s	{ v2 }[2], [x9]
	tbz	w8, #3, LBB0_1034
LBB0_1051:                              ; %cond.load3478
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v2 }[3], [x9]
	ldr	q3, [sp, #11008]                ; 16-byte Reload
	shl.2d	v5, v3, #5
	orr.16b	v6, v5, v15
	ldr	q3, [sp, #8352]                 ; 16-byte Reload
	add.2d	v6, v3, v6
	tbz	w8, #4, LBB0_1035
LBB0_1052:                              ; %cond.load3484
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
	tbnz	w8, #5, LBB0_1036
	b	LBB0_1037
LBB0_1053:                              ; %cond.store3509
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #11424]                ; 16-byte Reload
	str	s2, [x9]
	tbz	w8, #1, LBB0_1043
LBB0_1054:                              ; %cond.store3513
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11424]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v1, v4, v1
	ldr	q2, [sp, #8016]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #2, LBB0_1044
LBB0_1055:                              ; %cond.store3517
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #11424]                ; 16-byte Reload
	st1.s	{ v2 }[2], [x9]
	tbnz	w8, #3, LBB0_1045
	b	LBB0_1046
LBB0_1056:                              ; %cond.store3525
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x9, d0
	str	s2, [x9]
	tbz	w8, #5, LBB0_1048
LBB0_1057:                              ; %cond.store3529
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v2 }[1], [x9]
	ldr	q0, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v6, v0
	ldr	q1, [sp, #8032]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w8, #6, LBB0_1049
LBB0_1058:                              ; %cond.store3533
                                        ;   in Loop: Header=BB0_1028 Depth=2
	fmov	x9, d0
	st1.s	{ v2 }[2], [x9]
	tbz	w8, #7, LBB0_1027
LBB0_1059:                              ; %cond.store3537
                                        ;   in Loop: Header=BB0_1028 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v2 }[3], [x8]
	b	LBB0_1027
LBB0_1060:                              ; %else3704
                                        ;   in Loop: Header=BB0_1061 Depth=2
	str	q1, [sp, #4928]                 ; 16-byte Spill
	str	q2, [sp, #4944]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #9904]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #9904]                 ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #9888]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #9888]                 ; 16-byte Spill
	ldr	q0, [sp, #9872]                 ; 16-byte Reload
	ldr	q1, [sp, #13248]                ; 16-byte Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #9872]                 ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v0, v11, v0
LBB0_1061:                              ; %direct.false876
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	x8, d0
	cmp	x8, #1
	b.ge	LBB0_1094
; %bb.1062:                             ; %direct.true887
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.16b	v11, v0
	shl.2d	v0, v0, #5
	ldr	q1, [sp, #12336]                ; 16-byte Reload
	orr.16b	v1, v0, v1
	ldr	q0, [sp, #5680]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	fmov	w8, s27
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_1064
; %bb.1063:                             ; %cond.load3624
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	x9, d4
	ldr	s2, [x9]
LBB0_1064:                              ; %else3628
                                        ;   in Loop: Header=BB0_1061 Depth=2
	tbz	w8, #1, LBB0_1066
; %bb.1065:                             ; %cond.load3630
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_1066:                              ; %else3634
                                        ;   in Loop: Header=BB0_1061 Depth=2
	ldr	q4, [sp, #9904]                 ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #12304]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #5712]                 ; 16-byte Reload
	add.2d	v5, v5, v4
	tbz	w8, #2, LBB0_1068
; %bb.1067:                             ; %cond.load3636
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	x9, d5
	ld1.s	{ v2 }[2], [x9]
LBB0_1068:                              ; %else3640
                                        ;   in Loop: Header=BB0_1061 Depth=2
	tbz	w8, #3, LBB0_1070
; %bb.1069:                             ; %cond.load3642
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v2 }[3], [x9]
LBB0_1070:                              ; %else3646
                                        ;   in Loop: Header=BB0_1061 Depth=2
	ldr	q5, [sp, #9888]                 ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #12352]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #5696]                 ; 16-byte Reload
	add.2d	v6, v6, v5
	tbz	w8, #4, LBB0_1072
; %bb.1071:                             ; %cond.load3648
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
LBB0_1072:                              ; %else3652
                                        ;   in Loop: Header=BB0_1061 Depth=2
	tbz	w8, #5, LBB0_1074
; %bb.1073:                             ; %cond.load3654
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1074:                              ; %else3658
                                        ;   in Loop: Header=BB0_1061 Depth=2
	ldr	q6, [sp, #9872]                 ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #12320]                ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #5728]                 ; 16-byte Reload
	add.2d	v7, v7, v6
	tbz	w8, #6, LBB0_1076
; %bb.1075:                             ; %cond.load3660
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1076:                              ; %else3664
                                        ;   in Loop: Header=BB0_1061 Depth=2
	tbz	w8, #7, LBB0_1078
; %bb.1077:                             ; %cond.load3666
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1078:                              ; %else3670
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	w8, s27
	ldr	q7, [sp, #2208]                 ; 16-byte Reload
	ldr	q23, [sp, #4944]                ; 16-byte Reload
	bif.16b	v2, v23, v7
	ldr	q7, [sp, #2160]                 ; 16-byte Reload
	and.16b	v2, v7, v2
	add.2d	v1, v30, v1
	tbnz	w8, #0, LBB0_1087
; %bb.1079:                             ; %else3676
                                        ;   in Loop: Header=BB0_1061 Depth=2
	tbnz	w8, #1, LBB0_1088
LBB0_1080:                              ; %else3680
                                        ;   in Loop: Header=BB0_1061 Depth=2
	add.2d	v1, v28, v4
	tbnz	w8, #2, LBB0_1089
LBB0_1081:                              ; %else3684
                                        ;   in Loop: Header=BB0_1061 Depth=2
	tbz	w8, #3, LBB0_1083
LBB0_1082:                              ; %cond.store3685
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v2 }[3], [x9]
LBB0_1083:                              ; %else3688
                                        ;   in Loop: Header=BB0_1061 Depth=2
	ldr	q1, [sp, #2192]                 ; 16-byte Reload
	ldr	q4, [sp, #4928]                 ; 16-byte Reload
	bif.16b	v0, v4, v1
	ldr	q1, [sp, #2176]                 ; 16-byte Reload
	and.16b	v1, v1, v0
	add.2d	v0, v29, v5
	tbnz	w8, #4, LBB0_1090
; %bb.1084:                             ; %else3692
                                        ;   in Loop: Header=BB0_1061 Depth=2
	tbnz	w8, #5, LBB0_1091
LBB0_1085:                              ; %else3696
                                        ;   in Loop: Header=BB0_1061 Depth=2
	add.2d	v0, v25, v6
	tbnz	w8, #6, LBB0_1092
LBB0_1086:                              ; %else3700
                                        ;   in Loop: Header=BB0_1061 Depth=2
	tbz	w8, #7, LBB0_1060
	b	LBB0_1093
LBB0_1087:                              ; %cond.store3673
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	x9, d1
	str	s2, [x9]
	tbz	w8, #1, LBB0_1080
LBB0_1088:                              ; %cond.store3677
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v2 }[1], [x9]
	add.2d	v1, v28, v4
	tbz	w8, #2, LBB0_1081
LBB0_1089:                              ; %cond.store3681
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	x9, d1
	st1.s	{ v2 }[2], [x9]
	tbnz	w8, #3, LBB0_1082
	b	LBB0_1083
LBB0_1090:                              ; %cond.store3689
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	x9, d0
	str	s1, [x9]
	tbz	w8, #5, LBB0_1085
LBB0_1091:                              ; %cond.store3693
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[1], [x9]
	add.2d	v0, v25, v6
	tbz	w8, #6, LBB0_1086
LBB0_1092:                              ; %cond.store3697
                                        ;   in Loop: Header=BB0_1061 Depth=2
	fmov	x9, d0
	st1.s	{ v1 }[2], [x9]
	tbz	w8, #7, LBB0_1060
LBB0_1093:                              ; %cond.store3701
                                        ;   in Loop: Header=BB0_1061 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v1 }[3], [x8]
	b	LBB0_1060
LBB0_1094:                              ; %direct.false888
                                        ;   in Loop: Header=BB0_91 Depth=1
	str	q0, [sp, #1008]                 ; 16-byte Spill
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #10944]                ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #10944]                ; 16-byte Spill
	ldr	q2, [sp, #10976]                ; 16-byte Reload
	bic.16b	v2, v2, v12
	str	q2, [sp, #10976]                ; 16-byte Spill
	ldr	q2, [sp, #10960]                ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #10960]                ; 16-byte Spill
	ldr	q1, [sp, #768]                  ; 16-byte Reload
	bic.16b	v1, v1, v0
	fmov	x8, d1
	cmp	x8, #1
	b.le	LBB0_1097
; %bb.1095:                             ;   in Loop: Header=BB0_91 Depth=1
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	b	LBB0_90
LBB0_1096:                              ; %else3786
                                        ;   in Loop: Header=BB0_1097 Depth=2
	str	q1, [sp, #6592]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #10976]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10976]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #10960]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10960]                ; 16-byte Spill
	ldr	q0, [sp, #10944]                ; 16-byte Reload
	ldr	q1, [sp, #13248]                ; 16-byte Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #10944]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v1, v11, v0
	fmov	x8, d1
	cmp	x8, #2
	b.ge	LBB0_90
LBB0_1097:                              ; %direct.true899
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v11, v1
	shl.2d	v0, v1, #5
	ldr	q1, [sp, #12336]                ; 16-byte Reload
	orr.16b	v1, v0, v1
	ldr	q0, [sp, #7984]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	ldr	d0, [sp, #12376]                ; 8-byte Reload
	fmov	w8, s0
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_1099
; %bb.1098:                             ; %cond.load3706
                                        ;   in Loop: Header=BB0_1097 Depth=2
	fmov	x9, d4
	ldr	s2, [x9]
LBB0_1099:                              ; %else3710
                                        ;   in Loop: Header=BB0_1097 Depth=2
	tbz	w8, #1, LBB0_1101
; %bb.1100:                             ; %cond.load3712
                                        ;   in Loop: Header=BB0_1097 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_1101:                              ; %else3716
                                        ;   in Loop: Header=BB0_1097 Depth=2
	ldr	q4, [sp, #10976]                ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #12304]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #8016]                 ; 16-byte Reload
	add.2d	v5, v5, v4
	tbz	w8, #2, LBB0_1103
; %bb.1102:                             ; %cond.load3718
                                        ;   in Loop: Header=BB0_1097 Depth=2
	fmov	x9, d5
	ld1.s	{ v2 }[2], [x9]
LBB0_1103:                              ; %else3722
                                        ;   in Loop: Header=BB0_1097 Depth=2
	tbz	w8, #3, LBB0_1105
; %bb.1104:                             ; %cond.load3724
                                        ;   in Loop: Header=BB0_1097 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v2 }[3], [x9]
LBB0_1105:                              ; %else3728
                                        ;   in Loop: Header=BB0_1097 Depth=2
	ldr	q5, [sp, #10960]                ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #12352]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #8000]                 ; 16-byte Reload
	add.2d	v6, v6, v5
	tbz	w8, #4, LBB0_1107
; %bb.1106:                             ; %cond.load3730
                                        ;   in Loop: Header=BB0_1097 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
LBB0_1107:                              ; %else3734
                                        ;   in Loop: Header=BB0_1097 Depth=2
	tbz	w8, #5, LBB0_1109
; %bb.1108:                             ; %cond.load3736
                                        ;   in Loop: Header=BB0_1097 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1109:                              ; %else3740
                                        ;   in Loop: Header=BB0_1097 Depth=2
	ldr	q6, [sp, #10944]                ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #12320]                ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #8032]                 ; 16-byte Reload
	add.2d	v7, v7, v6
	tbz	w8, #6, LBB0_1111
; %bb.1110:                             ; %cond.load3742
                                        ;   in Loop: Header=BB0_1097 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1111:                              ; %else3746
                                        ;   in Loop: Header=BB0_1097 Depth=2
	tbz	w8, #7, LBB0_1113
; %bb.1112:                             ; %cond.load3748
                                        ;   in Loop: Header=BB0_1097 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1113:                              ; %else3752
                                        ;   in Loop: Header=BB0_1097 Depth=2
	ldr	d7, [sp, #12376]                ; 8-byte Reload
	fmov	w8, s7
	ldr	q7, [sp, #3760]                 ; 16-byte Reload
	ldr	q23, [sp, #11408]               ; 16-byte Reload
	bif.16b	v2, v23, v7
	ldr	q7, [sp, #3712]                 ; 16-byte Reload
	and.16b	v2, v7, v2
	str	q2, [sp, #11408]                ; 16-byte Spill
	ldr	q2, [sp, #9776]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #0, LBB0_1122
; %bb.1114:                             ; %else3758
                                        ;   in Loop: Header=BB0_1097 Depth=2
	tbnz	w8, #1, LBB0_1123
LBB0_1115:                              ; %else3762
                                        ;   in Loop: Header=BB0_1097 Depth=2
	ldr	q1, [sp, #9808]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbnz	w8, #2, LBB0_1124
LBB0_1116:                              ; %else3766
                                        ;   in Loop: Header=BB0_1097 Depth=2
	tbz	w8, #3, LBB0_1118
LBB0_1117:                              ; %cond.store3767
                                        ;   in Loop: Header=BB0_1097 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11408]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1118:                              ; %else3770
                                        ;   in Loop: Header=BB0_1097 Depth=2
	ldr	q1, [sp, #3744]                 ; 16-byte Reload
	ldr	q2, [sp, #6592]                 ; 16-byte Reload
	bif.16b	v0, v2, v1
	ldr	q1, [sp, #3728]                 ; 16-byte Reload
	and.16b	v1, v1, v0
	ldr	q0, [sp, #9792]                 ; 16-byte Reload
	add.2d	v0, v0, v5
	tbnz	w8, #4, LBB0_1125
; %bb.1119:                             ; %else3774
                                        ;   in Loop: Header=BB0_1097 Depth=2
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	tbnz	w8, #5, LBB0_1126
LBB0_1120:                              ; %else3778
                                        ;   in Loop: Header=BB0_1097 Depth=2
	ldr	q0, [sp, #9824]                 ; 16-byte Reload
	add.2d	v0, v0, v6
	tbnz	w8, #6, LBB0_1127
LBB0_1121:                              ; %else3782
                                        ;   in Loop: Header=BB0_1097 Depth=2
	tbz	w8, #7, LBB0_1096
	b	LBB0_1128
LBB0_1122:                              ; %cond.store3755
                                        ;   in Loop: Header=BB0_1097 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #11408]                ; 16-byte Reload
	str	s2, [x9]
	tbz	w8, #1, LBB0_1115
LBB0_1123:                              ; %cond.store3759
                                        ;   in Loop: Header=BB0_1097 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #11408]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #9808]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbz	w8, #2, LBB0_1116
LBB0_1124:                              ; %cond.store3763
                                        ;   in Loop: Header=BB0_1097 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #11408]                ; 16-byte Reload
	st1.s	{ v2 }[2], [x9]
	tbnz	w8, #3, LBB0_1117
	b	LBB0_1118
LBB0_1125:                              ; %cond.store3771
                                        ;   in Loop: Header=BB0_1097 Depth=2
	fmov	x9, d0
	str	s1, [x9]
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	tbz	w8, #5, LBB0_1120
LBB0_1126:                              ; %cond.store3775
                                        ;   in Loop: Header=BB0_1097 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[1], [x9]
	ldr	q0, [sp, #9824]                 ; 16-byte Reload
	add.2d	v0, v0, v6
	tbz	w8, #6, LBB0_1121
LBB0_1127:                              ; %cond.store3779
                                        ;   in Loop: Header=BB0_1097 Depth=2
	fmov	x9, d0
	st1.s	{ v1 }[2], [x9]
	tbz	w8, #7, LBB0_1096
LBB0_1128:                              ; %cond.store3783
                                        ;   in Loop: Header=BB0_1097 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v1 }[3], [x8]
	b	LBB0_1096
LBB0_1129:                              ; %direct.true490.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldp	q2, q1, [sp, #48]               ; 32-byte Folded Reload
	ldr	q28, [sp, #1552]                ; 16-byte Reload
	ldr	q29, [sp, #1536]                ; 16-byte Reload
	ldr	q8, [sp, #1520]                 ; 16-byte Reload
	ldr	q17, [sp, #144]                 ; 16-byte Reload
	b	LBB0_1131
LBB0_1130:                              ; %else1230
                                        ;   in Loop: Header=BB0_1131 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q3, [sp, #10400]                ; 16-byte Reload
	add.2d	v3, v3, v0
	str	q3, [sp, #10400]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q3, [sp, #10384]                ; 16-byte Reload
	add.2d	v3, v3, v0
	str	q3, [sp, #10384]                ; 16-byte Spill
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	add.2d	v0, v0, v11
	str	q0, [sp, #10368]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v0, v5, v0
	fmov	x9, d0
	cmp	x9, #1
	b.ge	LBB0_350
LBB0_1131:                              ; %direct.true490
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v5, v0
	shl.2d	v0, v0, #6
	ldr	q3, [sp, #3600]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #3664]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	fmov	w9, s27
	tbz	w9, #0, LBB0_1133
; %bb.1132:                             ; %cond.store1199
                                        ;   in Loop: Header=BB0_1131 Depth=2
	fmov	x10, d0
	ldr	q4, [sp, #2864]                 ; 16-byte Reload
	str	d4, [x10]
LBB0_1133:                              ; %else1202
                                        ;   in Loop: Header=BB0_1131 Depth=2
	tbz	w9, #1, LBB0_1135
; %bb.1134:                             ; %cond.store1203
                                        ;   in Loop: Header=BB0_1131 Depth=2
	mov.d	x10, v0[1]
	ldr	q0, [sp, #2864]                 ; 16-byte Reload
	st1.d	{ v0 }[1], [x10]
LBB0_1135:                              ; %else1206
                                        ;   in Loop: Header=BB0_1131 Depth=2
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	shl.2d	v0, v0, #6
	ldr	q3, [sp, #3584]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #3648]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #2, LBB0_1137
; %bb.1136:                             ; %cond.store1207
                                        ;   in Loop: Header=BB0_1131 Depth=2
	fmov	x10, d0
	ldr	q4, [sp, #2880]                 ; 16-byte Reload
	str	d4, [x10]
LBB0_1137:                              ; %else1210
                                        ;   in Loop: Header=BB0_1131 Depth=2
	tbz	w9, #3, LBB0_1139
; %bb.1138:                             ; %cond.store1211
                                        ;   in Loop: Header=BB0_1131 Depth=2
	mov.d	x10, v0[1]
	ldr	q0, [sp, #2880]                 ; 16-byte Reload
	st1.d	{ v0 }[1], [x10]
LBB0_1139:                              ; %else1214
                                        ;   in Loop: Header=BB0_1131 Depth=2
	ldr	q0, [sp, #10384]                ; 16-byte Reload
	shl.2d	v0, v0, #6
	ldr	q3, [sp, #3696]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #3632]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #4, LBB0_1141
; %bb.1140:                             ; %cond.store1215
                                        ;   in Loop: Header=BB0_1131 Depth=2
	fmov	x10, d0
	str	d1, [x10]
LBB0_1141:                              ; %else1218
                                        ;   in Loop: Header=BB0_1131 Depth=2
	tbz	w9, #5, LBB0_1143
; %bb.1142:                             ; %cond.store1219
                                        ;   in Loop: Header=BB0_1131 Depth=2
	mov.d	x10, v0[1]
	st1.d	{ v1 }[1], [x10]
LBB0_1143:                              ; %else1222
                                        ;   in Loop: Header=BB0_1131 Depth=2
	ldr	q0, [sp, #10368]                ; 16-byte Reload
	shl.2d	v0, v0, #6
	ldr	q3, [sp, #3680]                 ; 16-byte Reload
	orr.16b	v0, v0, v3
	ldr	q3, [sp, #3616]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	tbz	w9, #6, LBB0_1145
; %bb.1144:                             ; %cond.store1223
                                        ;   in Loop: Header=BB0_1131 Depth=2
	fmov	x10, d0
	str	d2, [x10]
LBB0_1145:                              ; %else1226
                                        ;   in Loop: Header=BB0_1131 Depth=2
	tbz	w9, #7, LBB0_1130
; %bb.1146:                             ; %cond.store1227
                                        ;   in Loop: Header=BB0_1131 Depth=2
	mov.d	x9, v0[1]
	st1.d	{ v2 }[1], [x9]
	b	LBB0_1130
LBB0_1147:                              ; %direct.true498.lr.ph
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q0, [sp, #3664]                 ; 16-byte Reload
	ldr	q1, [sp, #3600]                 ; 16-byte Reload
	add.2d	v2, v0, v1
	ldr	q0, [sp, #3648]                 ; 16-byte Reload
	ldr	q1, [sp, #3584]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	ldr	q0, [sp, #3696]                 ; 16-byte Reload
	ldr	q1, [sp, #3632]                 ; 16-byte Reload
	add.2d	v6, v1, v0
	ldr	q0, [sp, #3680]                 ; 16-byte Reload
	ldr	q1, [sp, #3616]                 ; 16-byte Reload
	add.2d	v7, v1, v0
	b	LBB0_1149
LBB0_1148:                              ; %else1312
                                        ;   in Loop: Header=BB0_1149 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #10336]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10336]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #10320]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10320]                ; 16-byte Spill
	ldr	q0, [sp, #10304]                ; 16-byte Reload
	add.2d	v0, v0, v11
	str	q0, [sp, #10304]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	ldr	q1, [sp, #10352]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10352]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #1
	b.ge	LBB0_351
LBB0_1149:                              ; %direct.true498
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s27
	tbz	w9, #0, LBB0_1151
; %bb.1150:                             ; %cond.load1232
                                        ;   in Loop: Header=BB0_1149 Depth=2
	fmov	x10, d2
	ldr	d18, [x10]
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w9, #1, LBB0_1152
	b	LBB0_1153
LBB0_1151:                              ;   in Loop: Header=BB0_1149 Depth=2
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w9, #1, LBB0_1153
LBB0_1152:                              ; %cond.load1238
                                        ;   in Loop: Header=BB0_1149 Depth=2
	mov.d	x10, v2[1]
	ld1.d	{ v18 }[1], [x10]
LBB0_1153:                              ; %else1242
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbnz	w9, #2, LBB0_1176
; %bb.1154:                             ; %else1248
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbnz	w9, #3, LBB0_1177
LBB0_1155:                              ; %else1254
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbnz	w9, #4, LBB0_1178
LBB0_1156:                              ; %else1260
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbnz	w9, #5, LBB0_1179
LBB0_1157:                              ; %else1266
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbnz	w9, #6, LBB0_1180
LBB0_1158:                              ; %else1272
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbz	w9, #7, LBB0_1160
LBB0_1159:                              ; %cond.load1274
                                        ;   in Loop: Header=BB0_1149 Depth=2
	mov.d	x9, v7[1]
	ld1.d	{ v0 }[1], [x9]
LBB0_1160:                              ; %else1278
                                        ;   in Loop: Header=BB0_1149 Depth=2
	ldr	q21, [sp, #11648]               ; 16-byte Reload
	mov	b19, v21[0]
	mov.b	v19[4], v21[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q3, [sp, #5616]                 ; 16-byte Reload
	bif.16b	v18, v3, v19
	fmov	w9, s27
	mov	b19, v17[0]
	mov.b	v19[4], v17[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmge.2d	v19, v19, #0
	and.16b	v3, v19, v18
	ldr	q18, [sp, #3056]                ; 16-byte Reload
	str	q3, [sp, #5616]                 ; 16-byte Spill
	add.2d	v18, v3, v18
	ldr	q3, [sp, #10352]                ; 16-byte Reload
	shl.2d	v19, v3, #6
	ldr	q3, [sp, #3472]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #3536]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w9, #0, LBB0_1162
; %bb.1161:                             ; %cond.store1281
                                        ;   in Loop: Header=BB0_1149 Depth=2
	fmov	x10, d21
	str	d18, [x10]
LBB0_1162:                              ; %else1284
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbz	w9, #1, LBB0_1164
; %bb.1163:                             ; %cond.store1285
                                        ;   in Loop: Header=BB0_1149 Depth=2
	mov.d	x10, v21[1]
	st1.d	{ v18 }[1], [x10]
LBB0_1164:                              ; %else1288
                                        ;   in Loop: Header=BB0_1149 Depth=2
	ldr	q19, [sp, #11648]               ; 16-byte Reload
	mov	b18, v19[2]
	mov.b	v18[4], v19[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmlt.2d	v18, v18, #0
	ldr	q3, [sp, #5632]                 ; 16-byte Reload
	bif.16b	v5, v3, v18
	mov	b18, v17[2]
	mov.b	v18[4], v17[3]
	ushll.2d	v18, v18, #0
	shl.2d	v18, v18, #63
	cmge.2d	v18, v18, #0
	and.16b	v3, v18, v5
	ldr	q5, [sp, #3024]                 ; 16-byte Reload
	str	q3, [sp, #5632]                 ; 16-byte Spill
	add.2d	v5, v3, v5
	ldr	q3, [sp, #10336]                ; 16-byte Reload
	shl.2d	v18, v3, #6
	ldr	q3, [sp, #3456]                 ; 16-byte Reload
	orr.16b	v18, v18, v3
	ldr	q3, [sp, #3520]                 ; 16-byte Reload
	add.2d	v18, v3, v18
	tbz	w9, #2, LBB0_1166
; %bb.1165:                             ; %cond.store1289
                                        ;   in Loop: Header=BB0_1149 Depth=2
	fmov	x10, d18
	str	d5, [x10]
LBB0_1166:                              ; %else1292
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbz	w9, #3, LBB0_1168
; %bb.1167:                             ; %cond.store1293
                                        ;   in Loop: Header=BB0_1149 Depth=2
	mov.d	x10, v18[1]
	st1.d	{ v5 }[1], [x10]
LBB0_1168:                              ; %else1296
                                        ;   in Loop: Header=BB0_1149 Depth=2
	ldr	q18, [sp, #11648]               ; 16-byte Reload
	mov	b5, v18[4]
	mov.b	v5[4], v18[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q3, [sp, #5664]                 ; 16-byte Reload
	bif.16b	v1, v3, v5
	mov	b5, v17[4]
	mov.b	v5[4], v17[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v3, v5, v1
	ldr	q1, [sp, #3040]                 ; 16-byte Reload
	str	q3, [sp, #5664]                 ; 16-byte Spill
	add.2d	v1, v3, v1
	ldr	q3, [sp, #10320]                ; 16-byte Reload
	shl.2d	v5, v3, #6
	ldr	q3, [sp, #3568]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #3504]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #4, LBB0_1170
; %bb.1169:                             ; %cond.store1297
                                        ;   in Loop: Header=BB0_1149 Depth=2
	fmov	x10, d5
	str	d1, [x10]
LBB0_1170:                              ; %else1300
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbz	w9, #5, LBB0_1172
; %bb.1171:                             ; %cond.store1301
                                        ;   in Loop: Header=BB0_1149 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v1 }[1], [x10]
LBB0_1172:                              ; %else1304
                                        ;   in Loop: Header=BB0_1149 Depth=2
	ldr	q5, [sp, #11648]                ; 16-byte Reload
	mov	b1, v5[6]
	mov.b	v1[4], v5[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q3, [sp, #5648]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	mov	b1, v17[6]
	mov.b	v1[4], v17[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v1, v1, v0
	ldr	q0, [sp, #3008]                 ; 16-byte Reload
	str	q1, [sp, #5648]                 ; 16-byte Spill
	add.2d	v0, v1, v0
	ldr	q1, [sp, #10304]                ; 16-byte Reload
	shl.2d	v1, v1, #6
	ldr	q3, [sp, #3552]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #3488]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_1174
; %bb.1173:                             ; %cond.store1305
                                        ;   in Loop: Header=BB0_1149 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_1174:                              ; %else1308
                                        ;   in Loop: Header=BB0_1149 Depth=2
	tbz	w9, #7, LBB0_1148
; %bb.1175:                             ; %cond.store1309
                                        ;   in Loop: Header=BB0_1149 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_1148
LBB0_1176:                              ; %cond.load1244
                                        ;   in Loop: Header=BB0_1149 Depth=2
	fmov	x10, d4
	ld1.d	{ v5 }[0], [x10]
	tbz	w9, #3, LBB0_1155
LBB0_1177:                              ; %cond.load1250
                                        ;   in Loop: Header=BB0_1149 Depth=2
	mov.d	x10, v4[1]
	ld1.d	{ v5 }[1], [x10]
	tbz	w9, #4, LBB0_1156
LBB0_1178:                              ; %cond.load1256
                                        ;   in Loop: Header=BB0_1149 Depth=2
	fmov	x10, d6
	ld1.d	{ v1 }[0], [x10]
	tbz	w9, #5, LBB0_1157
LBB0_1179:                              ; %cond.load1262
                                        ;   in Loop: Header=BB0_1149 Depth=2
	mov.d	x10, v6[1]
	ld1.d	{ v1 }[1], [x10]
	tbz	w9, #6, LBB0_1158
LBB0_1180:                              ; %cond.load1268
                                        ;   in Loop: Header=BB0_1149 Depth=2
	fmov	x10, d7
	ld1.d	{ v0 }[0], [x10]
	tbnz	w9, #7, LBB0_1159
	b	LBB0_1160
LBB0_1181:                              ; %direct.true510.lr.ph
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q0, [sp, #3536]                 ; 16-byte Reload
	ldr	q1, [sp, #3472]                 ; 16-byte Reload
	add.2d	v2, v0, v1
	ldr	q0, [sp, #3520]                 ; 16-byte Reload
	ldr	q1, [sp, #3456]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	ldr	q0, [sp, #3568]                 ; 16-byte Reload
	ldr	q1, [sp, #3504]                 ; 16-byte Reload
	add.2d	v6, v1, v0
	ldr	q0, [sp, #3552]                 ; 16-byte Reload
	ldr	q1, [sp, #3488]                 ; 16-byte Reload
	add.2d	v7, v1, v0
	b	LBB0_1183
LBB0_1182:                              ; %else1394
                                        ;   in Loop: Header=BB0_1183 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v8, v8, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v25, v25, v0
	add.2d	v28, v28, v11
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v29, v29, v0
	fmov	x9, d29
	cmp	x9, #1
	b.ge	LBB0_352
LBB0_1183:                              ; %direct.true510
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s27
	tbz	w9, #0, LBB0_1185
; %bb.1184:                             ; %cond.load1314
                                        ;   in Loop: Header=BB0_1183 Depth=2
	fmov	x10, d2
	ldr	d18, [x10]
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w9, #1, LBB0_1186
	b	LBB0_1187
LBB0_1185:                              ;   in Loop: Header=BB0_1183 Depth=2
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w9, #1, LBB0_1187
LBB0_1186:                              ; %cond.load1320
                                        ;   in Loop: Header=BB0_1183 Depth=2
	mov.d	x10, v2[1]
	ld1.d	{ v18 }[1], [x10]
LBB0_1187:                              ; %else1324
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbnz	w9, #2, LBB0_1210
; %bb.1188:                             ; %else1330
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbnz	w9, #3, LBB0_1211
LBB0_1189:                              ; %else1336
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbnz	w9, #4, LBB0_1212
LBB0_1190:                              ; %else1342
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbnz	w9, #5, LBB0_1213
LBB0_1191:                              ; %else1348
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbnz	w9, #6, LBB0_1214
LBB0_1192:                              ; %else1354
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbz	w9, #7, LBB0_1194
LBB0_1193:                              ; %cond.load1356
                                        ;   in Loop: Header=BB0_1183 Depth=2
	mov.d	x9, v7[1]
	ld1.d	{ v0 }[1], [x9]
LBB0_1194:                              ; %else1360
                                        ;   in Loop: Header=BB0_1183 Depth=2
	ldr	q21, [sp, #11648]               ; 16-byte Reload
	mov	b19, v21[0]
	mov.b	v19[4], v21[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q3, [sp, #5584]                 ; 16-byte Reload
	bif.16b	v18, v3, v19
	fmov	w9, s27
	mov	b19, v17[0]
	mov.b	v19[4], v17[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmge.2d	v19, v19, #0
	and.16b	v3, v19, v18
	mov	w10, #35                        ; =0x23
	dup.2d	v18, x10
	str	q3, [sp, #5584]                 ; 16-byte Spill
	add.2d	v21, v3, v18
	shl.2d	v19, v29, #6
	ldr	q3, [sp, #3440]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #3376]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w9, #0, LBB0_1196
; %bb.1195:                             ; %cond.store1363
                                        ;   in Loop: Header=BB0_1183 Depth=2
	fmov	x10, d23
	str	d21, [x10]
LBB0_1196:                              ; %else1366
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbz	w9, #1, LBB0_1198
; %bb.1197:                             ; %cond.store1367
                                        ;   in Loop: Header=BB0_1183 Depth=2
	mov.d	x10, v23[1]
	st1.d	{ v21 }[1], [x10]
LBB0_1198:                              ; %else1370
                                        ;   in Loop: Header=BB0_1183 Depth=2
	ldr	q21, [sp, #11648]               ; 16-byte Reload
	mov	b19, v21[2]
	mov.b	v19[4], v21[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q3, [sp, #5600]                 ; 16-byte Reload
	bif.16b	v5, v3, v19
	mov	b19, v17[2]
	mov.b	v19[4], v17[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmge.2d	v19, v19, #0
	and.16b	v3, v19, v5
	str	q3, [sp, #5600]                 ; 16-byte Spill
	add.2d	v5, v3, v18
	shl.2d	v19, v8, #6
	ldr	q3, [sp, #3424]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #3360]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w9, #2, LBB0_1200
; %bb.1199:                             ; %cond.store1371
                                        ;   in Loop: Header=BB0_1183 Depth=2
	fmov	x10, d21
	str	d5, [x10]
LBB0_1200:                              ; %else1374
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbz	w9, #3, LBB0_1202
; %bb.1201:                             ; %cond.store1375
                                        ;   in Loop: Header=BB0_1183 Depth=2
	mov.d	x10, v21[1]
	st1.d	{ v5 }[1], [x10]
LBB0_1202:                              ; %else1378
                                        ;   in Loop: Header=BB0_1183 Depth=2
	ldr	q19, [sp, #11648]               ; 16-byte Reload
	mov	b5, v19[4]
	mov.b	v5[4], v19[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q3, [sp, #5568]                 ; 16-byte Reload
	bif.16b	v1, v3, v5
	mov	b5, v17[4]
	mov.b	v5[4], v17[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v1, v5, v1
	str	q1, [sp, #5568]                 ; 16-byte Spill
	add.2d	v1, v1, v18
	shl.2d	v5, v25, #6
	ldr	q3, [sp, #3408]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #3344]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #4, LBB0_1204
; %bb.1203:                             ; %cond.store1379
                                        ;   in Loop: Header=BB0_1183 Depth=2
	fmov	x10, d5
	str	d1, [x10]
LBB0_1204:                              ; %else1382
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbz	w9, #5, LBB0_1206
; %bb.1205:                             ; %cond.store1383
                                        ;   in Loop: Header=BB0_1183 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v1 }[1], [x10]
LBB0_1206:                              ; %else1386
                                        ;   in Loop: Header=BB0_1183 Depth=2
	ldr	q5, [sp, #11648]                ; 16-byte Reload
	mov	b1, v5[6]
	mov.b	v1[4], v5[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q3, [sp, #5552]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	mov	b1, v17[6]
	mov.b	v1[4], v17[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #5552]                 ; 16-byte Spill
	add.2d	v0, v0, v18
	shl.2d	v1, v28, #6
	ldr	q3, [sp, #3392]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #3328]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_1208
; %bb.1207:                             ; %cond.store1387
                                        ;   in Loop: Header=BB0_1183 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_1208:                              ; %else1390
                                        ;   in Loop: Header=BB0_1183 Depth=2
	tbz	w9, #7, LBB0_1182
; %bb.1209:                             ; %cond.store1391
                                        ;   in Loop: Header=BB0_1183 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_1182
LBB0_1210:                              ; %cond.load1326
                                        ;   in Loop: Header=BB0_1183 Depth=2
	fmov	x10, d4
	ld1.d	{ v5 }[0], [x10]
	tbz	w9, #3, LBB0_1189
LBB0_1211:                              ; %cond.load1332
                                        ;   in Loop: Header=BB0_1183 Depth=2
	mov.d	x10, v4[1]
	ld1.d	{ v5 }[1], [x10]
	tbz	w9, #4, LBB0_1190
LBB0_1212:                              ; %cond.load1338
                                        ;   in Loop: Header=BB0_1183 Depth=2
	fmov	x10, d6
	ld1.d	{ v1 }[0], [x10]
	tbz	w9, #5, LBB0_1191
LBB0_1213:                              ; %cond.load1344
                                        ;   in Loop: Header=BB0_1183 Depth=2
	mov.d	x10, v6[1]
	ld1.d	{ v1 }[1], [x10]
	tbz	w9, #6, LBB0_1192
LBB0_1214:                              ; %cond.load1350
                                        ;   in Loop: Header=BB0_1183 Depth=2
	fmov	x10, d7
	ld1.d	{ v0 }[0], [x10]
	tbnz	w9, #7, LBB0_1193
	b	LBB0_1194
LBB0_1215:                              ; %direct.true521.lr.ph
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q0, [sp, #3440]                 ; 16-byte Reload
	ldr	q1, [sp, #3376]                 ; 16-byte Reload
	add.2d	v2, v1, v0
	ldr	q0, [sp, #3424]                 ; 16-byte Reload
	ldr	q1, [sp, #3360]                 ; 16-byte Reload
	add.2d	v4, v1, v0
	ldr	q0, [sp, #3408]                 ; 16-byte Reload
	ldr	q1, [sp, #3344]                 ; 16-byte Reload
	add.2d	v6, v1, v0
	ldr	q0, [sp, #3392]                 ; 16-byte Reload
	ldr	q1, [sp, #3328]                 ; 16-byte Reload
	add.2d	v7, v1, v0
	b	LBB0_1217
LBB0_1216:                              ; %else1476
                                        ;   in Loop: Header=BB0_1217 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #10272]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10272]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #10256]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10256]                ; 16-byte Spill
	ldr	q0, [sp, #10240]                ; 16-byte Reload
	add.2d	v0, v0, v11
	str	q0, [sp, #10240]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	ldr	q1, [sp, #10288]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10288]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #1
	b.ge	LBB0_353
LBB0_1217:                              ; %direct.true521
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s27
	tbz	w9, #0, LBB0_1219
; %bb.1218:                             ; %cond.load1396
                                        ;   in Loop: Header=BB0_1217 Depth=2
	fmov	x10, d2
	ldr	d18, [x10]
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w9, #1, LBB0_1220
	b	LBB0_1221
LBB0_1219:                              ;   in Loop: Header=BB0_1217 Depth=2
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w9, #1, LBB0_1221
LBB0_1220:                              ; %cond.load1402
                                        ;   in Loop: Header=BB0_1217 Depth=2
	mov.d	x10, v2[1]
	ld1.d	{ v18 }[1], [x10]
LBB0_1221:                              ; %else1406
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbnz	w9, #2, LBB0_1244
; %bb.1222:                             ; %else1412
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbnz	w9, #3, LBB0_1245
LBB0_1223:                              ; %else1418
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbnz	w9, #4, LBB0_1246
LBB0_1224:                              ; %else1424
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbnz	w9, #5, LBB0_1247
LBB0_1225:                              ; %else1430
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbnz	w9, #6, LBB0_1248
LBB0_1226:                              ; %else1436
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbz	w9, #7, LBB0_1228
LBB0_1227:                              ; %cond.load1438
                                        ;   in Loop: Header=BB0_1217 Depth=2
	mov.d	x9, v7[1]
	ld1.d	{ v0 }[1], [x9]
LBB0_1228:                              ; %else1442
                                        ;   in Loop: Header=BB0_1217 Depth=2
	ldr	q21, [sp, #11648]               ; 16-byte Reload
	mov	b19, v21[0]
	mov.b	v19[4], v21[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q3, [sp, #5520]                 ; 16-byte Reload
	bif.16b	v18, v3, v19
	fmov	w9, s27
	mov	b19, v17[0]
	mov.b	v19[4], v17[1]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmge.2d	v19, v19, #0
	and.16b	v3, v19, v18
	mov	x10, #-3                        ; =0xfffffffffffffffd
	dup.2d	v18, x10
	str	q3, [sp, #5520]                 ; 16-byte Spill
	add.2d	v21, v3, v18
	ldr	q3, [sp, #10288]                ; 16-byte Reload
	shl.2d	v19, v3, #6
	ldr	q3, [sp, #6320]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6256]                 ; 16-byte Reload
	add.2d	v23, v3, v19
	tbz	w9, #0, LBB0_1230
; %bb.1229:                             ; %cond.store1445
                                        ;   in Loop: Header=BB0_1217 Depth=2
	fmov	x10, d23
	str	d21, [x10]
LBB0_1230:                              ; %else1448
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbz	w9, #1, LBB0_1232
; %bb.1231:                             ; %cond.store1449
                                        ;   in Loop: Header=BB0_1217 Depth=2
	mov.d	x10, v23[1]
	st1.d	{ v21 }[1], [x10]
LBB0_1232:                              ; %else1452
                                        ;   in Loop: Header=BB0_1217 Depth=2
	ldr	q21, [sp, #11648]               ; 16-byte Reload
	mov	b19, v21[2]
	mov.b	v19[4], v21[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmlt.2d	v19, v19, #0
	ldr	q3, [sp, #5536]                 ; 16-byte Reload
	bif.16b	v5, v3, v19
	mov	b19, v17[2]
	mov.b	v19[4], v17[3]
	ushll.2d	v19, v19, #0
	shl.2d	v19, v19, #63
	cmge.2d	v19, v19, #0
	and.16b	v3, v19, v5
	str	q3, [sp, #5536]                 ; 16-byte Spill
	add.2d	v5, v3, v18
	ldr	q3, [sp, #10272]                ; 16-byte Reload
	shl.2d	v19, v3, #6
	ldr	q3, [sp, #6304]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6240]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w9, #2, LBB0_1234
; %bb.1233:                             ; %cond.store1453
                                        ;   in Loop: Header=BB0_1217 Depth=2
	fmov	x10, d21
	str	d5, [x10]
LBB0_1234:                              ; %else1456
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbz	w9, #3, LBB0_1236
; %bb.1235:                             ; %cond.store1457
                                        ;   in Loop: Header=BB0_1217 Depth=2
	mov.d	x10, v21[1]
	st1.d	{ v5 }[1], [x10]
LBB0_1236:                              ; %else1460
                                        ;   in Loop: Header=BB0_1217 Depth=2
	ldr	q19, [sp, #11648]               ; 16-byte Reload
	mov	b5, v19[4]
	mov.b	v5[4], v19[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	ldr	q3, [sp, #5504]                 ; 16-byte Reload
	bif.16b	v1, v3, v5
	mov	b5, v17[4]
	mov.b	v5[4], v17[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmge.2d	v5, v5, #0
	and.16b	v1, v5, v1
	str	q1, [sp, #5504]                 ; 16-byte Spill
	add.2d	v1, v1, v18
	ldr	q3, [sp, #10256]                ; 16-byte Reload
	shl.2d	v5, v3, #6
	ldr	q3, [sp, #6288]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #6352]                 ; 16-byte Reload
	add.2d	v5, v3, v5
	tbz	w9, #4, LBB0_1238
; %bb.1237:                             ; %cond.store1461
                                        ;   in Loop: Header=BB0_1217 Depth=2
	fmov	x10, d5
	str	d1, [x10]
LBB0_1238:                              ; %else1464
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbz	w9, #5, LBB0_1240
; %bb.1239:                             ; %cond.store1465
                                        ;   in Loop: Header=BB0_1217 Depth=2
	mov.d	x10, v5[1]
	st1.d	{ v1 }[1], [x10]
LBB0_1240:                              ; %else1468
                                        ;   in Loop: Header=BB0_1217 Depth=2
	ldr	q5, [sp, #11648]                ; 16-byte Reload
	mov	b1, v5[6]
	mov.b	v1[4], v5[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	ldr	q3, [sp, #5488]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	mov	b1, v17[6]
	mov.b	v1[4], v17[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmge.2d	v1, v1, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #5488]                 ; 16-byte Spill
	add.2d	v0, v0, v18
	ldr	q1, [sp, #10240]                ; 16-byte Reload
	shl.2d	v1, v1, #6
	ldr	q3, [sp, #6272]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #6336]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_1242
; %bb.1241:                             ; %cond.store1469
                                        ;   in Loop: Header=BB0_1217 Depth=2
	fmov	x10, d1
	str	d0, [x10]
LBB0_1242:                              ; %else1472
                                        ;   in Loop: Header=BB0_1217 Depth=2
	tbz	w9, #7, LBB0_1216
; %bb.1243:                             ; %cond.store1473
                                        ;   in Loop: Header=BB0_1217 Depth=2
	mov.d	x9, v1[1]
	st1.d	{ v0 }[1], [x9]
	b	LBB0_1216
LBB0_1244:                              ; %cond.load1408
                                        ;   in Loop: Header=BB0_1217 Depth=2
	fmov	x10, d4
	ld1.d	{ v5 }[0], [x10]
	tbz	w9, #3, LBB0_1223
LBB0_1245:                              ; %cond.load1414
                                        ;   in Loop: Header=BB0_1217 Depth=2
	mov.d	x10, v4[1]
	ld1.d	{ v5 }[1], [x10]
	tbz	w9, #4, LBB0_1224
LBB0_1246:                              ; %cond.load1420
                                        ;   in Loop: Header=BB0_1217 Depth=2
	fmov	x10, d6
	ld1.d	{ v1 }[0], [x10]
	tbz	w9, #5, LBB0_1225
LBB0_1247:                              ; %cond.load1426
                                        ;   in Loop: Header=BB0_1217 Depth=2
	mov.d	x10, v6[1]
	ld1.d	{ v1 }[1], [x10]
	tbz	w9, #6, LBB0_1226
LBB0_1248:                              ; %cond.load1432
                                        ;   in Loop: Header=BB0_1217 Depth=2
	fmov	x10, d7
	ld1.d	{ v0 }[0], [x10]
	tbnz	w9, #7, LBB0_1227
	b	LBB0_1228
LBB0_1249:                              ; %direct.true636.lr.ph
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q0, [sp, #10480]                ; 16-byte Reload
	ldr	q1, [sp, #10416]                ; 16-byte Reload
	add.2d	v2, v0, v1
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	ldr	q1, [sp, #10464]                ; 16-byte Reload
	add.2d	v4, v1, v0
	ldr	q0, [sp, #10512]                ; 16-byte Reload
	ldr	q1, [sp, #10448]                ; 16-byte Reload
	add.2d	v6, v1, v0
	ldr	q0, [sp, #10496]                ; 16-byte Reload
	ldr	q1, [sp, #10432]                ; 16-byte Reload
	add.2d	v7, v1, v0
	b	LBB0_1251
LBB0_1250:                              ; %else2213
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #10160]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10160]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #10144]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10144]                ; 16-byte Spill
	ldr	q0, [sp, #10128]                ; 16-byte Reload
	add.2d	v0, v0, v11
	str	q0, [sp, #10128]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	ldr	q1, [sp, #10176]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10176]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #1
	b.ge	LBB0_647
LBB0_1251:                              ; %direct.true636
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s23
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w9, #0, LBB0_1284
; %bb.1252:                             ; %else2088
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #1, LBB0_1285
LBB0_1253:                              ; %else2094
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #2, LBB0_1286
LBB0_1254:                              ; %else2100
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #3, LBB0_1287
LBB0_1255:                              ; %else2106
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #4, LBB0_1288
LBB0_1256:                              ; %else2112
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #5, LBB0_1289
LBB0_1257:                              ; %else2118
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #6, LBB0_1290
LBB0_1258:                              ; %else2124
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #7, LBB0_1291
LBB0_1259:                              ; %else2130
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	w9, s23
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_1292
LBB0_1260:                              ; %else2137
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #1, LBB0_1293
LBB0_1261:                              ; %else2143
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #2, LBB0_1294
LBB0_1262:                              ; %else2149
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #3, LBB0_1295
LBB0_1263:                              ; %else2155
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #4, LBB0_1296
LBB0_1264:                              ; %else2161
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #5, LBB0_1297
LBB0_1265:                              ; %else2167
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbnz	w9, #6, LBB0_1298
LBB0_1266:                              ; %else2173
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbz	w9, #7, LBB0_1268
LBB0_1267:                              ; %cond.load2175
                                        ;   in Loop: Header=BB0_1251 Depth=2
	mov.d	x9, v7[1]
	ld1.s	{ v5 }[3], [x9]
LBB0_1268:                              ; %else2179
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q21, [sp, #5296]                ; 16-byte Reload
	movi	d3, #0x0000000000ffff
	bit.8b	v21, v3, v8
	ldr	q19, [sp, #2752]                ; 16-byte Reload
	ldr	q3, [sp, #5328]                 ; 16-byte Reload
	bif.16b	v1, v3, v19
	ldr	q19, [sp, #2704]                ; 16-byte Reload
	and.16b	v3, v19, v1
	str	q21, [sp, #5296]                ; 16-byte Spill
	bic.8b	v1, v8, v21
	fmov	w9, s23
	ldr	q19, [sp, #2672]                ; 16-byte Reload
	ldr	q21, [sp, #5280]                ; 16-byte Reload
	bif.16b	v18, v21, v19
	zip1.8b	v19, v1, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmge.4s	v19, v19, #0
	and.16b	v18, v19, v18
	str	q3, [sp, #5328]                 ; 16-byte Spill
	str	q18, [sp, #5280]                ; 16-byte Spill
	fsub.4s	v18, v3, v18
	ldr	q3, [sp, #10176]                ; 16-byte Reload
	shl.2d	v19, v3, #5
	ldr	q3, [sp, #3280]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #3216]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w9, #0, LBB0_1270
; %bb.1269:                             ; %cond.store2182
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	x10, d21
	str	s18, [x10]
LBB0_1270:                              ; %else2185
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbz	w9, #1, LBB0_1272
; %bb.1271:                             ; %cond.store2186
                                        ;   in Loop: Header=BB0_1251 Depth=2
	mov.d	x10, v21[1]
	st1.s	{ v18 }[1], [x10]
LBB0_1272:                              ; %else2189
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q3, [sp, #10160]                ; 16-byte Reload
	shl.2d	v19, v3, #5
	ldr	q3, [sp, #3264]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #3200]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w9, #2, LBB0_1274
; %bb.1273:                             ; %cond.store2190
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	x10, d21
	st1.s	{ v18 }[2], [x10]
LBB0_1274:                              ; %else2193
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbz	w9, #3, LBB0_1276
; %bb.1275:                             ; %cond.store2194
                                        ;   in Loop: Header=BB0_1251 Depth=2
	mov.d	x10, v21[1]
	st1.s	{ v18 }[3], [x10]
LBB0_1276:                              ; %else2197
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q18, [sp, #2736]                ; 16-byte Reload
	ldr	q3, [sp, #5312]                 ; 16-byte Reload
	bif.16b	v0, v3, v18
	ldr	q18, [sp, #2720]                ; 16-byte Reload
	and.16b	v3, v18, v0
	ldr	q0, [sp, #2688]                 ; 16-byte Reload
	ldr	q18, [sp, #5264]                ; 16-byte Reload
	bsl.16b	v0, v5, v18
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q3, [sp, #5312]                 ; 16-byte Spill
	str	q0, [sp, #5264]                 ; 16-byte Spill
	fsub.4s	v0, v3, v0
	ldr	q1, [sp, #10144]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #3248]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #3312]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_1278
; %bb.1277:                             ; %cond.store2198
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	x10, d1
	str	s0, [x10]
LBB0_1278:                              ; %else2201
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbz	w9, #5, LBB0_1280
; %bb.1279:                             ; %cond.store2202
                                        ;   in Loop: Header=BB0_1251 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
LBB0_1280:                              ; %else2205
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q1, [sp, #10128]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #3232]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #3296]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_1282
; %bb.1281:                             ; %cond.store2206
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
LBB0_1282:                              ; %else2209
                                        ;   in Loop: Header=BB0_1251 Depth=2
	tbz	w9, #7, LBB0_1250
; %bb.1283:                             ; %cond.store2210
                                        ;   in Loop: Header=BB0_1251 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_1250
LBB0_1284:                              ; %cond.load2084
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q0, [sp, #2944]                 ; 16-byte Reload
	fmov	x10, d0
	ldr	s1, [x10]
	movi.2d	v0, #0000000000000000
	tbz	w9, #1, LBB0_1253
LBB0_1285:                              ; %cond.load2090
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ld1.s	{ v1 }[1], [x19]
	tbz	w9, #2, LBB0_1254
LBB0_1286:                              ; %cond.load2096
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q3, [sp, #2928]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB0_1255
LBB0_1287:                              ; %cond.load2102
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ld1.s	{ v1 }[3], [x6]
	tbz	w9, #4, LBB0_1256
LBB0_1288:                              ; %cond.load2108
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q3, [sp, #2912]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v0 }[0], [x10]
	tbz	w9, #5, LBB0_1257
LBB0_1289:                              ; %cond.load2114
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ld1.s	{ v0 }[1], [x7]
	tbz	w9, #6, LBB0_1258
LBB0_1290:                              ; %cond.load2120
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ldr	q3, [sp, #2896]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_1259
LBB0_1291:                              ; %cond.load2126
                                        ;   in Loop: Header=BB0_1251 Depth=2
	ld1.s	{ v0 }[3], [x15]
	fmov	w9, s23
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbz	w9, #0, LBB0_1260
LBB0_1292:                              ; %cond.load2133
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	x10, d2
	ldr	s18, [x10]
	tbz	w9, #1, LBB0_1261
LBB0_1293:                              ; %cond.load2139
                                        ;   in Loop: Header=BB0_1251 Depth=2
	mov.d	x10, v2[1]
	ld1.s	{ v18 }[1], [x10]
	tbz	w9, #2, LBB0_1262
LBB0_1294:                              ; %cond.load2145
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	x10, d4
	ld1.s	{ v18 }[2], [x10]
	tbz	w9, #3, LBB0_1263
LBB0_1295:                              ; %cond.load2151
                                        ;   in Loop: Header=BB0_1251 Depth=2
	mov.d	x10, v4[1]
	ld1.s	{ v18 }[3], [x10]
	tbz	w9, #4, LBB0_1264
LBB0_1296:                              ; %cond.load2157
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	x10, d6
	ld1.s	{ v5 }[0], [x10]
	tbz	w9, #5, LBB0_1265
LBB0_1297:                              ; %cond.load2163
                                        ;   in Loop: Header=BB0_1251 Depth=2
	mov.d	x10, v6[1]
	ld1.s	{ v5 }[1], [x10]
	tbz	w9, #6, LBB0_1266
LBB0_1298:                              ; %cond.load2169
                                        ;   in Loop: Header=BB0_1251 Depth=2
	fmov	x10, d7
	ld1.s	{ v5 }[2], [x10]
	tbnz	w9, #7, LBB0_1267
	b	LBB0_1268
LBB0_1299:                              ; %direct.true651.lr.ph
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q0, [sp, #3280]                 ; 16-byte Reload
	ldr	q1, [sp, #3216]                 ; 16-byte Reload
	add.2d	v2, v1, v0
	ldr	q0, [sp, #3264]                 ; 16-byte Reload
	ldr	q1, [sp, #3200]                 ; 16-byte Reload
	add.2d	v4, v1, v0
	ldr	q0, [sp, #3312]                 ; 16-byte Reload
	ldr	q1, [sp, #3248]                 ; 16-byte Reload
	add.2d	v5, v0, v1
	ldr	q0, [sp, #3296]                 ; 16-byte Reload
	ldr	q1, [sp, #3232]                 ; 16-byte Reload
	add.2d	v6, v0, v1
	b	LBB0_1301
LBB0_1300:                              ; %else2295
                                        ;   in Loop: Header=BB0_1301 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #10096]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10096]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #10080]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10080]                ; 16-byte Spill
	ldr	q0, [sp, #10064]                ; 16-byte Reload
	add.2d	v0, v0, v11
	str	q0, [sp, #10064]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	ldr	q1, [sp, #10112]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10112]                ; 16-byte Spill
	fmov	x9, d1
	cmp	x9, #1
	b.ge	LBB0_648
LBB0_1301:                              ; %direct.true651
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s23
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w9, #0, LBB0_1326
; %bb.1302:                             ; %else2219
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbnz	w9, #1, LBB0_1327
LBB0_1303:                              ; %else2225
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbnz	w9, #2, LBB0_1328
LBB0_1304:                              ; %else2231
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbnz	w9, #3, LBB0_1329
LBB0_1305:                              ; %else2237
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbnz	w9, #4, LBB0_1330
LBB0_1306:                              ; %else2243
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbnz	w9, #5, LBB0_1331
LBB0_1307:                              ; %else2249
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbnz	w9, #6, LBB0_1332
LBB0_1308:                              ; %else2255
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbz	w9, #7, LBB0_1310
LBB0_1309:                              ; %cond.load2257
                                        ;   in Loop: Header=BB0_1301 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[3], [x9]
LBB0_1310:                              ; %else2261
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	w9, s23
	ldr	q7, [sp, #2640]                 ; 16-byte Reload
	ldr	q3, [sp, #5232]                 ; 16-byte Reload
	bif.16b	v1, v3, v7
	ldr	q7, [sp, #2624]                 ; 16-byte Reload
	and.16b	v1, v7, v1
	str	q1, [sp, #5232]                 ; 16-byte Spill
	and.16b	v1, v24, v1
	fcmge.4s	v7, v1, v27
	ldr	q30, [sp, #11376]               ; 16-byte Reload
	fcmge.4s	v18, v30, v1
	and.16b	v7, v7, v18
	and.16b	v7, v7, v1
	ldr	q3, [sp, #11360]                ; 16-byte Reload
	fmul.4s	v18, v7, v3
	movi.4s	v3, #75, lsl #24
	mvni.4s	v17, #128, lsl #24
	mov.16b	v19, v17
	bsl.16b	v19, v3, v18
	fadd.4s	v18, v18, v19
	fsub.4s	v18, v18, v19
	fcvtzs.4s	v18, v18
	scvtf.4s	v19, v18
	ldr	q3, [sp, #11344]                ; 16-byte Reload
	fmul.4s	v21, v19, v3
	fadd.4s	v7, v7, v21
	ldr	q3, [sp, #11328]                ; 16-byte Reload
	fmul.4s	v19, v19, v3
	fadd.4s	v7, v7, v19
	ldr	q3, [sp, #11312]                ; 16-byte Reload
	fmul.4s	v19, v7, v3
	ldr	q3, [sp, #11296]                ; 16-byte Reload
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v7, v19
	ldr	q3, [sp, #11280]                ; 16-byte Reload
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v7, v19
	ldr	q3, [sp, #11264]                ; 16-byte Reload
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v7, v19
	ldr	q3, [sp, #11248]                ; 16-byte Reload
	fadd.4s	v19, v19, v3
	fmul.4s	v19, v7, v19
	movi.4s	v3, #63, lsl #24
	fadd.4s	v19, v19, v3
	fmul.4s	v21, v7, v7
	fmul.4s	v19, v21, v19
	fadd.4s	v7, v7, v19
	fmov.4s	v3, #1.00000000
	fadd.4s	v7, v7, v3
	sshr.4s	v19, v18, #1
	shl.4s	v21, v19, #23
	add.4s	v21, v21, v3
	fmul.4s	v7, v7, v21
	sub.4s	v18, v18, v19
	shl.4s	v18, v18, #23
	add.4s	v18, v18, v3
	fmul.4s	v7, v7, v18
	fcmgt.4s	v18, v27, v1
	bic.16b	v7, v7, v18
	fcmgt.4s	v18, v1, v30
	ldr	q19, [sp, #11232]               ; 16-byte Reload
	bit.16b	v7, v19, v18
	fcmeq.4s	v1, v1, v1
	ldr	q18, [sp, #11216]               ; 16-byte Reload
	bsl.16b	v1, v7, v18
	ldr	q3, [sp, #10112]                ; 16-byte Reload
	shl.2d	v7, v3, #5
	ldr	q3, [sp, #6416]                 ; 16-byte Reload
	orr.16b	v7, v7, v3
	ldr	q3, [sp, #6368]                 ; 16-byte Reload
	add.2d	v7, v3, v7
	tbz	w9, #0, LBB0_1312
; %bb.1311:                             ; %cond.store2264
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	x10, d7
	str	s1, [x10]
LBB0_1312:                              ; %else2267
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbz	w9, #1, LBB0_1314
; %bb.1313:                             ; %cond.store2268
                                        ;   in Loop: Header=BB0_1301 Depth=2
	mov.d	x10, v7[1]
	st1.s	{ v1 }[1], [x10]
LBB0_1314:                              ; %else2271
                                        ;   in Loop: Header=BB0_1301 Depth=2
	ldr	q3, [sp, #10096]                ; 16-byte Reload
	shl.2d	v7, v3, #5
	ldr	q3, [sp, #6400]                 ; 16-byte Reload
	orr.16b	v7, v7, v3
	ldr	q3, [sp, #6464]                 ; 16-byte Reload
	add.2d	v7, v3, v7
	tbz	w9, #2, LBB0_1316
; %bb.1315:                             ; %cond.store2272
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	x10, d7
	st1.s	{ v1 }[2], [x10]
LBB0_1316:                              ; %else2275
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbz	w9, #3, LBB0_1318
; %bb.1317:                             ; %cond.store2276
                                        ;   in Loop: Header=BB0_1301 Depth=2
	mov.d	x10, v7[1]
	st1.s	{ v1 }[3], [x10]
LBB0_1318:                              ; %else2279
                                        ;   in Loop: Header=BB0_1301 Depth=2
	ldr	q1, [sp, #2656]                 ; 16-byte Reload
	ldr	q3, [sp, #5248]                 ; 16-byte Reload
	bif.16b	v0, v3, v1
	ldr	q1, [sp, #2608]                 ; 16-byte Reload
	and.16b	v0, v1, v0
	str	q0, [sp, #5248]                 ; 16-byte Spill
	and.16b	v0, v26, v0
	fcmge.4s	v1, v0, v27
	ldr	q21, [sp, #11376]               ; 16-byte Reload
	fcmge.4s	v7, v21, v0
	and.16b	v1, v1, v7
	and.16b	v1, v1, v0
	ldr	q3, [sp, #11360]                ; 16-byte Reload
	fmul.4s	v7, v1, v3
	movi.4s	v3, #75, lsl #24
	mov.16b	v18, v17
	bsl.16b	v18, v3, v7
	fadd.4s	v7, v7, v18
	fsub.4s	v7, v7, v18
	fcvtzs.4s	v7, v7
	scvtf.4s	v18, v7
	ldr	q3, [sp, #11344]                ; 16-byte Reload
	fmul.4s	v19, v18, v3
	fadd.4s	v1, v1, v19
	ldr	q3, [sp, #11328]                ; 16-byte Reload
	fmul.4s	v18, v18, v3
	fadd.4s	v1, v1, v18
	ldr	q3, [sp, #11312]                ; 16-byte Reload
	fmul.4s	v18, v1, v3
	ldr	q3, [sp, #11296]                ; 16-byte Reload
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v1, v18
	ldr	q3, [sp, #11280]                ; 16-byte Reload
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v1, v18
	ldr	q3, [sp, #11264]                ; 16-byte Reload
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v1, v18
	ldr	q3, [sp, #11248]                ; 16-byte Reload
	fadd.4s	v18, v18, v3
	fmul.4s	v18, v1, v18
	movi.4s	v3, #63, lsl #24
	fadd.4s	v18, v18, v3
	fmul.4s	v19, v1, v1
	fmul.4s	v18, v19, v18
	fadd.4s	v1, v1, v18
	fmov.4s	v3, #1.00000000
	fadd.4s	v1, v1, v3
	sshr.4s	v18, v7, #1
	shl.4s	v19, v18, #23
	add.4s	v19, v19, v3
	fmul.4s	v1, v1, v19
	sub.4s	v7, v7, v18
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v3
	fmul.4s	v1, v1, v7
	fcmgt.4s	v7, v27, v0
	bic.16b	v1, v1, v7
	fcmgt.4s	v7, v0, v21
	ldr	q18, [sp, #11232]               ; 16-byte Reload
	bit.16b	v1, v18, v7
	fcmeq.4s	v0, v0, v0
	ldr	q7, [sp, #11216]                ; 16-byte Reload
	bsl.16b	v0, v1, v7
	ldr	q1, [sp, #10080]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #6384]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #6448]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_1320
; %bb.1319:                             ; %cond.store2280
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	x10, d1
	str	s0, [x10]
LBB0_1320:                              ; %else2283
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbz	w9, #5, LBB0_1322
; %bb.1321:                             ; %cond.store2284
                                        ;   in Loop: Header=BB0_1301 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
LBB0_1322:                              ; %else2287
                                        ;   in Loop: Header=BB0_1301 Depth=2
	ldr	q1, [sp, #10064]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #6480]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #6432]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_1324
; %bb.1323:                             ; %cond.store2288
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
LBB0_1324:                              ; %else2291
                                        ;   in Loop: Header=BB0_1301 Depth=2
	tbz	w9, #7, LBB0_1300
; %bb.1325:                             ; %cond.store2292
                                        ;   in Loop: Header=BB0_1301 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_1300
LBB0_1326:                              ; %cond.load2215
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	x10, d2
	ldr	s1, [x10]
	tbz	w9, #1, LBB0_1303
LBB0_1327:                              ; %cond.load2221
                                        ;   in Loop: Header=BB0_1301 Depth=2
	mov.d	x10, v2[1]
	ld1.s	{ v1 }[1], [x10]
	tbz	w9, #2, LBB0_1304
LBB0_1328:                              ; %cond.load2227
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	x10, d4
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB0_1305
LBB0_1329:                              ; %cond.load2233
                                        ;   in Loop: Header=BB0_1301 Depth=2
	mov.d	x10, v4[1]
	ld1.s	{ v1 }[3], [x10]
	tbz	w9, #4, LBB0_1306
LBB0_1330:                              ; %cond.load2239
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	x10, d5
	ld1.s	{ v0 }[0], [x10]
	tbz	w9, #5, LBB0_1307
LBB0_1331:                              ; %cond.load2245
                                        ;   in Loop: Header=BB0_1301 Depth=2
	mov.d	x10, v5[1]
	ld1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB0_1308
LBB0_1332:                              ; %cond.load2251
                                        ;   in Loop: Header=BB0_1301 Depth=2
	fmov	x10, d6
	ld1.s	{ v0 }[2], [x10]
	tbnz	w9, #7, LBB0_1309
	b	LBB0_1310
LBB0_1333:                              ; %direct.true716.lr.ph
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q0, [sp, #6416]                 ; 16-byte Reload
	ldr	q1, [sp, #6368]                 ; 16-byte Reload
	add.2d	v2, v1, v0
	ldr	q0, [sp, #6464]                 ; 16-byte Reload
	ldr	q1, [sp, #6400]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	ldr	q0, [sp, #6448]                 ; 16-byte Reload
	ldr	q1, [sp, #6384]                 ; 16-byte Reload
	add.2d	v6, v0, v1
	ldr	q0, [sp, #6480]                 ; 16-byte Reload
	ldr	q1, [sp, #6432]                 ; 16-byte Reload
	add.2d	v7, v1, v0
	ldr	q16, [sp, #880]                 ; 16-byte Reload
	ldr	q25, [sp, #11056]               ; 16-byte Reload
	b	LBB0_1335
LBB0_1334:                              ; %else2770
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #10048]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10048]                ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #10032]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10032]                ; 16-byte Spill
	ldr	q0, [sp, #10016]                ; 16-byte Reload
	add.2d	v0, v0, v11
	str	q0, [sp, #10016]                ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v28, v28, v0
	fmov	x9, d28
	cmp	x9, #1
	b.ge	LBB0_790
LBB0_1335:                              ; %direct.true716
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w9, s27
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w9, #0, LBB0_1368
; %bb.1336:                             ; %else2645
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #1, LBB0_1369
LBB0_1337:                              ; %else2651
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #2, LBB0_1370
LBB0_1338:                              ; %else2657
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #3, LBB0_1371
LBB0_1339:                              ; %else2663
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #4, LBB0_1372
LBB0_1340:                              ; %else2669
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #5, LBB0_1373
LBB0_1341:                              ; %else2675
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #6, LBB0_1374
LBB0_1342:                              ; %else2681
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #7, LBB0_1375
LBB0_1343:                              ; %else2687
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	w9, s27
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbnz	w9, #0, LBB0_1376
LBB0_1344:                              ; %else2694
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #1, LBB0_1377
LBB0_1345:                              ; %else2700
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #2, LBB0_1378
LBB0_1346:                              ; %else2706
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #3, LBB0_1379
LBB0_1347:                              ; %else2712
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #4, LBB0_1380
LBB0_1348:                              ; %else2718
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #5, LBB0_1381
LBB0_1349:                              ; %else2724
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbnz	w9, #6, LBB0_1382
LBB0_1350:                              ; %else2730
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbz	w9, #7, LBB0_1352
LBB0_1351:                              ; %cond.load2732
                                        ;   in Loop: Header=BB0_1335 Depth=2
	mov.d	x9, v7[1]
	ld1.s	{ v5 }[3], [x9]
LBB0_1352:                              ; %else2736
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #5216]                 ; 16-byte Reload
	movi	d17, #0x0000000000ffff
	mov.16b	v21, v8
	bit.8b	v3, v17, v21
	ldr	q19, [sp, #2592]                ; 16-byte Reload
	ldr	q17, [sp, #5200]                ; 16-byte Reload
	bif.16b	v1, v17, v19
	ldr	q19, [sp, #2544]                ; 16-byte Reload
	and.16b	v17, v19, v1
	str	q3, [sp, #5216]                 ; 16-byte Spill
	bic.8b	v1, v21, v3
	fmov	w9, s27
	ldr	q19, [sp, #2512]                ; 16-byte Reload
	ldr	q3, [sp, #5168]                 ; 16-byte Reload
	bif.16b	v18, v3, v19
	zip1.8b	v19, v1, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmge.4s	v19, v19, #0
	and.16b	v3, v19, v18
	str	q17, [sp, #5200]                ; 16-byte Spill
	str	q3, [sp, #5168]                 ; 16-byte Spill
	fmul.4s	v18, v17, v3
	shl.2d	v19, v28, #5
	ldr	q3, [sp, #3120]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w9, #0, LBB0_1354
; %bb.1353:                             ; %cond.store2739
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	x10, d21
	str	s18, [x10]
LBB0_1354:                              ; %else2742
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbz	w9, #1, LBB0_1356
; %bb.1355:                             ; %cond.store2743
                                        ;   in Loop: Header=BB0_1335 Depth=2
	mov.d	x10, v21[1]
	st1.s	{ v18 }[1], [x10]
LBB0_1356:                              ; %else2746
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #10048]                ; 16-byte Reload
	shl.2d	v19, v3, #5
	ldr	q3, [sp, #3104]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #3168]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w9, #2, LBB0_1358
; %bb.1357:                             ; %cond.store2747
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	x10, d21
	st1.s	{ v18 }[2], [x10]
LBB0_1358:                              ; %else2750
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbz	w9, #3, LBB0_1360
; %bb.1359:                             ; %cond.store2751
                                        ;   in Loop: Header=BB0_1335 Depth=2
	mov.d	x10, v21[1]
	st1.s	{ v18 }[3], [x10]
LBB0_1360:                              ; %else2754
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q18, [sp, #2576]                ; 16-byte Reload
	ldr	q3, [sp, #5184]                 ; 16-byte Reload
	bif.16b	v0, v3, v18
	ldr	q18, [sp, #2560]                ; 16-byte Reload
	and.16b	v3, v18, v0
	ldr	q0, [sp, #2528]                 ; 16-byte Reload
	ldr	q17, [sp, #5152]                ; 16-byte Reload
	bsl.16b	v0, v5, v17
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q3, [sp, #5184]                 ; 16-byte Spill
	str	q0, [sp, #5152]                 ; 16-byte Spill
	fmul.4s	v0, v3, v0
	ldr	q1, [sp, #10032]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #3088]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #3152]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #4, LBB0_1362
; %bb.1361:                             ; %cond.store2755
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	x10, d1
	str	s0, [x10]
LBB0_1362:                              ; %else2758
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbz	w9, #5, LBB0_1364
; %bb.1363:                             ; %cond.store2759
                                        ;   in Loop: Header=BB0_1335 Depth=2
	mov.d	x10, v1[1]
	st1.s	{ v0 }[1], [x10]
LBB0_1364:                              ; %else2762
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q1, [sp, #10016]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #3184]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #3136]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w9, #6, LBB0_1366
; %bb.1365:                             ; %cond.store2763
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	x10, d1
	st1.s	{ v0 }[2], [x10]
LBB0_1366:                              ; %else2766
                                        ;   in Loop: Header=BB0_1335 Depth=2
	tbz	w9, #7, LBB0_1334
; %bb.1367:                             ; %cond.store2767
                                        ;   in Loop: Header=BB0_1335 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[3], [x9]
	b	LBB0_1334
LBB0_1368:                              ; %cond.load2641
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q0, [sp, #2144]                 ; 16-byte Reload
	fmov	x10, d0
	ldr	s1, [x10]
	movi.2d	v0, #0000000000000000
	tbz	w9, #1, LBB0_1337
LBB0_1369:                              ; %cond.load2647
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #2144]                 ; 16-byte Reload
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[1], [x10]
	tbz	w9, #2, LBB0_1338
LBB0_1370:                              ; %cond.load2653
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v1 }[2], [x10]
	tbz	w9, #3, LBB0_1339
LBB0_1371:                              ; %cond.load2659
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #2128]                 ; 16-byte Reload
	mov.d	x10, v3[1]
	ld1.s	{ v1 }[3], [x10]
	tbz	w9, #4, LBB0_1340
LBB0_1372:                              ; %cond.load2665
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v0 }[0], [x10]
	tbz	w9, #5, LBB0_1341
LBB0_1373:                              ; %cond.load2671
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #2112]                 ; 16-byte Reload
	mov.d	x10, v3[1]
	ld1.s	{ v0 }[1], [x10]
	tbz	w9, #6, LBB0_1342
LBB0_1374:                              ; %cond.load2677
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	fmov	x10, d3
	ld1.s	{ v0 }[2], [x10]
	tbz	w9, #7, LBB0_1343
LBB0_1375:                              ; %cond.load2683
                                        ;   in Loop: Header=BB0_1335 Depth=2
	ldr	q3, [sp, #2096]                 ; 16-byte Reload
	mov.d	x9, v3[1]
	ld1.s	{ v0 }[3], [x9]
	fmov	w9, s27
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbz	w9, #0, LBB0_1344
LBB0_1376:                              ; %cond.load2690
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	x10, d2
	ldr	s18, [x10]
	tbz	w9, #1, LBB0_1345
LBB0_1377:                              ; %cond.load2696
                                        ;   in Loop: Header=BB0_1335 Depth=2
	mov.d	x10, v2[1]
	ld1.s	{ v18 }[1], [x10]
	tbz	w9, #2, LBB0_1346
LBB0_1378:                              ; %cond.load2702
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	x10, d4
	ld1.s	{ v18 }[2], [x10]
	tbz	w9, #3, LBB0_1347
LBB0_1379:                              ; %cond.load2708
                                        ;   in Loop: Header=BB0_1335 Depth=2
	mov.d	x10, v4[1]
	ld1.s	{ v18 }[3], [x10]
	tbz	w9, #4, LBB0_1348
LBB0_1380:                              ; %cond.load2714
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	x10, d6
	ld1.s	{ v5 }[0], [x10]
	tbz	w9, #5, LBB0_1349
LBB0_1381:                              ; %cond.load2720
                                        ;   in Loop: Header=BB0_1335 Depth=2
	mov.d	x10, v6[1]
	ld1.s	{ v5 }[1], [x10]
	tbz	w9, #6, LBB0_1350
LBB0_1382:                              ; %cond.load2726
                                        ;   in Loop: Header=BB0_1335 Depth=2
	fmov	x10, d7
	ld1.s	{ v5 }[2], [x10]
	tbnz	w9, #7, LBB0_1351
	b	LBB0_1352
LBB0_1383:                              ; %direct.true765.lr.ph
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q0, [sp, #3120]                 ; 16-byte Reload
	ldr	q1, [sp, #3072]                 ; 16-byte Reload
	add.2d	v2, v1, v0
	ldr	q0, [sp, #3168]                 ; 16-byte Reload
	ldr	q1, [sp, #3104]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	ldr	q0, [sp, #3152]                 ; 16-byte Reload
	ldr	q1, [sp, #3088]                 ; 16-byte Reload
	add.2d	v6, v0, v1
	ldr	q0, [sp, #3184]                 ; 16-byte Reload
	ldr	q1, [sp, #3136]                 ; 16-byte Reload
	add.2d	v7, v1, v0
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #1616
	add	x30, sp, #3, lsl #12            ; =12288
	add	x30, x30, #1648
	b	LBB0_1385
LBB0_1384:                              ; %else2983
                                        ;   in Loop: Header=BB0_1385 Depth=2
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v30, v30, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #10000]                ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #10000]                ; 16-byte Spill
	ldr	q0, [sp, #9984]                 ; 16-byte Reload
	add.2d	v0, v0, v11
	str	q0, [sp, #9984]                 ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v17, v17, v0
	fmov	x8, d17
	cmp	x8, #1
	b.ge	LBB0_832
LBB0_1385:                              ; %direct.true765
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	fmov	w8, s27
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w8, #0, LBB0_1423
; %bb.1386:                             ; %else2858
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbnz	w8, #1, LBB0_1424
LBB0_1387:                              ; %else2864
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbnz	w8, #2, LBB0_1425
LBB0_1388:                              ; %else2870
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbnz	w8, #3, LBB0_1426
LBB0_1389:                              ; %else2876
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbnz	w8, #4, LBB0_1427
LBB0_1390:                              ; %else2882
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbnz	w8, #5, LBB0_1428
LBB0_1391:                              ; %else2888
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbnz	w8, #6, LBB0_1429
LBB0_1392:                              ; %else2894
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbz	w8, #7, LBB0_1394
LBB0_1393:                              ; %cond.load2896
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1394:                              ; %else2900
                                        ;   in Loop: Header=BB0_1385 Depth=2
	sshll.2d	v5, v24, #0
	ldr	q18, [sp, #5808]                ; 16-byte Reload
	ldr	q3, [sp, #5088]                 ; 16-byte Reload
	bit.16b	v3, v18, v5
	fmov	w8, s27
	str	q3, [sp, #5088]                 ; 16-byte Spill
	shl.2d	v5, v3, #5
	ldr	q3, [sp, #6000]                 ; 16-byte Reload
	orr.16b	v5, v5, v3
	ldr	q3, [sp, #6064]                 ; 16-byte Reload
	add.2d	v21, v3, v5
	movi.2d	v18, #0000000000000000
	movi.2d	v5, #0000000000000000
	tbz	w8, #0, LBB0_1396
; %bb.1395:                             ; %cond.load2903
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d21
	ldr	s18, [x9]
LBB0_1396:                              ; %else2907
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbz	w8, #1, LBB0_1398
; %bb.1397:                             ; %cond.load2909
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v18 }[1], [x9]
LBB0_1398:                              ; %else2913
                                        ;   in Loop: Header=BB0_1385 Depth=2
	ldr	q3, [sp, #5072]                 ; 16-byte Reload
	bic.16b	v19, v3, v12
	ssubw2.2d	v3, v19, v24
	str	q3, [sp, #5072]                 ; 16-byte Spill
	shl.2d	v19, v3, #5
	ldr	q3, [sp, #5984]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6048]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w8, #2, LBB0_1400
; %bb.1399:                             ; %cond.load2915
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d21
	ld1.s	{ v18 }[2], [x9]
LBB0_1400:                              ; %else2919
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbz	w8, #3, LBB0_1402
; %bb.1401:                             ; %cond.load2921
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v18 }[3], [x9]
LBB0_1402:                              ; %else2925
                                        ;   in Loop: Header=BB0_1385 Depth=2
	sshll.2d	v19, v26, #0
	ldr	q3, [sp, #5056]                 ; 16-byte Reload
	bic.16b	v19, v3, v19
	ssubw.2d	v3, v19, v26
	str	q3, [sp, #5056]                 ; 16-byte Spill
	shl.2d	v19, v3, #5
	ldr	q3, [sp, #6096]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6032]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w8, #4, LBB0_1404
; %bb.1403:                             ; %cond.load2927
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d21
	ld1.s	{ v5 }[0], [x9]
LBB0_1404:                              ; %else2931
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbz	w8, #5, LBB0_1406
; %bb.1405:                             ; %cond.load2933
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v21[1]
	ld1.s	{ v5 }[1], [x9]
LBB0_1406:                              ; %else2937
                                        ;   in Loop: Header=BB0_1385 Depth=2
	ldr	q3, [sp, #5040]                 ; 16-byte Reload
	bic.16b	v19, v3, v14
	ssubw2.2d	v3, v19, v26
	str	q3, [sp, #5040]                 ; 16-byte Spill
	shl.2d	v19, v3, #5
	ldr	q3, [sp, #6080]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #6016]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w8, #6, LBB0_1408
; %bb.1407:                             ; %cond.load2939
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d21
	ld1.s	{ v5 }[2], [x9]
LBB0_1408:                              ; %else2943
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbz	w8, #7, LBB0_1410
; %bb.1409:                             ; %cond.load2945
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x8, v21[1]
	ld1.s	{ v5 }[3], [x8]
LBB0_1410:                              ; %else2949
                                        ;   in Loop: Header=BB0_1385 Depth=2
	ldr	q3, [sp, #5136]                 ; 16-byte Reload
	movi	d19, #0x0000000000ffff
	mov.16b	v23, v8
	bit.8b	v3, v19, v23
	ldr	q19, [sp, #2496]                ; 16-byte Reload
	ldr	q21, [sp, #5120]                ; 16-byte Reload
	bif.16b	v1, v21, v19
	ldr	q19, [sp, #2448]                ; 16-byte Reload
	and.16b	v21, v19, v1
	str	q3, [sp, #5136]                 ; 16-byte Spill
	bic.8b	v1, v23, v3
	fmov	w8, s27
	ldr	q19, [sp, #2416]                ; 16-byte Reload
	ldr	q3, [sp, #5024]                 ; 16-byte Reload
	bif.16b	v18, v3, v19
	zip1.8b	v19, v1, v0
	ushll.4s	v19, v19, #0
	shl.4s	v19, v19, #31
	cmge.4s	v19, v19, #0
	and.16b	v3, v19, v18
	str	q21, [sp, #5120]                ; 16-byte Spill
	str	q3, [sp, #5024]                 ; 16-byte Spill
	fadd.4s	v18, v21, v3
	shl.2d	v19, v17, #5
	ldr	q3, [sp, #5904]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #5856]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbnz	w8, #0, LBB0_1430
; %bb.1411:                             ; %else2955
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbnz	w8, #1, LBB0_1431
LBB0_1412:                              ; %else2959
                                        ;   in Loop: Header=BB0_1385 Depth=2
	shl.2d	v19, v30, #5
	ldr	q3, [sp, #5888]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #5952]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbnz	w8, #2, LBB0_1432
LBB0_1413:                              ; %else2963
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbz	w8, #3, LBB0_1415
LBB0_1414:                              ; %cond.store2964
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v21[1]
	st1.s	{ v18 }[3], [x9]
LBB0_1415:                              ; %else2967
                                        ;   in Loop: Header=BB0_1385 Depth=2
	ldr	q18, [sp, #2480]                ; 16-byte Reload
	ldr	q3, [sp, #5104]                 ; 16-byte Reload
	bif.16b	v0, v3, v18
	ldr	q18, [sp, #2464]                ; 16-byte Reload
	and.16b	v3, v18, v0
	ldr	q0, [sp, #2432]                 ; 16-byte Reload
	ldr	q18, [sp, #5008]                ; 16-byte Reload
	bsl.16b	v0, v5, v18
	zip2.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q3, [sp, #5104]                 ; 16-byte Spill
	str	q0, [sp, #5008]                 ; 16-byte Spill
	fadd.4s	v0, v3, v0
	ldr	q1, [sp, #10000]                ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #5872]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5936]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w8, #4, LBB0_1417
; %bb.1416:                             ; %cond.store2968
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d1
	str	s0, [x9]
LBB0_1417:                              ; %else2971
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbz	w8, #5, LBB0_1419
; %bb.1418:                             ; %cond.store2972
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
LBB0_1419:                              ; %else2975
                                        ;   in Loop: Header=BB0_1385 Depth=2
	ldr	q1, [sp, #9984]                 ; 16-byte Reload
	shl.2d	v1, v1, #5
	ldr	q3, [sp, #5968]                 ; 16-byte Reload
	orr.16b	v1, v1, v3
	ldr	q3, [sp, #5920]                 ; 16-byte Reload
	add.2d	v1, v3, v1
	tbz	w8, #6, LBB0_1421
; %bb.1420:                             ; %cond.store2976
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
LBB0_1421:                              ; %else2979
                                        ;   in Loop: Header=BB0_1385 Depth=2
	tbz	w8, #7, LBB0_1384
; %bb.1422:                             ; %cond.store2980
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
	b	LBB0_1384
LBB0_1423:                              ; %cond.load2854
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d2
	ldr	s1, [x9]
	tbz	w8, #1, LBB0_1387
LBB0_1424:                              ; %cond.load2860
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v2[1]
	ld1.s	{ v1 }[1], [x9]
	tbz	w8, #2, LBB0_1388
LBB0_1425:                              ; %cond.load2866
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d4
	ld1.s	{ v1 }[2], [x9]
	tbz	w8, #3, LBB0_1389
LBB0_1426:                              ; %cond.load2872
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v1 }[3], [x9]
	tbz	w8, #4, LBB0_1390
LBB0_1427:                              ; %cond.load2878
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
	tbz	w8, #5, LBB0_1391
LBB0_1428:                              ; %cond.load2884
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
	tbz	w8, #6, LBB0_1392
LBB0_1429:                              ; %cond.load2890
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
	tbnz	w8, #7, LBB0_1393
	b	LBB0_1394
LBB0_1430:                              ; %cond.store2952
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d21
	str	s18, [x9]
	tbz	w8, #1, LBB0_1412
LBB0_1431:                              ; %cond.store2956
                                        ;   in Loop: Header=BB0_1385 Depth=2
	mov.d	x9, v21[1]
	st1.s	{ v18 }[1], [x9]
	shl.2d	v19, v30, #5
	ldr	q3, [sp, #5888]                 ; 16-byte Reload
	orr.16b	v19, v19, v3
	ldr	q3, [sp, #5952]                 ; 16-byte Reload
	add.2d	v21, v3, v19
	tbz	w8, #2, LBB0_1413
LBB0_1432:                              ; %cond.store2960
                                        ;   in Loop: Header=BB0_1385 Depth=2
	fmov	x9, d21
	st1.s	{ v18 }[2], [x9]
	tbnz	w8, #3, LBB0_1414
	b	LBB0_1415
LBB0_1433:                              ; %direct.true875.preheader
                                        ;   in Loop: Header=BB0_91 Depth=1
	ldr	q17, [sp, #8096]                ; 16-byte Reload
	b	LBB0_1435
LBB0_1434:                              ; %else3622
                                        ;   in Loop: Header=BB0_1435 Depth=2
	str	q1, [sp, #4960]                 ; 16-byte Spill
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	ldr	q1, [sp, #9952]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #9952]                 ; 16-byte Spill
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	ldr	q1, [sp, #9936]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	str	q1, [sp, #9936]                 ; 16-byte Spill
	ldr	q0, [sp, #9920]                 ; 16-byte Reload
	ldr	q1, [sp, #13248]                ; 16-byte Reload
	add.2d	v0, v0, v1
	str	q0, [sp, #9920]                 ; 16-byte Spill
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v0, v11, v0
	fmov	x8, d0
	cmp	x8, #1
	b.ge	LBB0_1026
LBB0_1435:                              ; %direct.true875
                                        ;   Parent Loop BB0_91 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov.16b	v11, v0
	shl.2d	v0, v0, #5
	ldr	q1, [sp, #12336]                ; 16-byte Reload
	orr.16b	v1, v0, v1
	ldr	q0, [sp, #5744]                 ; 16-byte Reload
	add.2d	v4, v0, v1
	fmov	w8, s27
	movi.2d	v2, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbz	w8, #0, LBB0_1437
; %bb.1436:                             ; %cond.load3542
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	x9, d4
	ldr	s2, [x9]
LBB0_1437:                              ; %else3546
                                        ;   in Loop: Header=BB0_1435 Depth=2
	tbz	w8, #1, LBB0_1439
; %bb.1438:                             ; %cond.load3548
                                        ;   in Loop: Header=BB0_1435 Depth=2
	mov.d	x9, v4[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_1439:                              ; %else3552
                                        ;   in Loop: Header=BB0_1435 Depth=2
	ldr	q4, [sp, #9952]                 ; 16-byte Reload
	shl.2d	v4, v4, #5
	ldr	q5, [sp, #12304]                ; 16-byte Reload
	orr.16b	v4, v4, v5
	ldr	q5, [sp, #5776]                 ; 16-byte Reload
	add.2d	v5, v5, v4
	tbz	w8, #2, LBB0_1441
; %bb.1440:                             ; %cond.load3554
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	x9, d5
	ld1.s	{ v2 }[2], [x9]
LBB0_1441:                              ; %else3558
                                        ;   in Loop: Header=BB0_1435 Depth=2
	tbz	w8, #3, LBB0_1443
; %bb.1442:                             ; %cond.load3560
                                        ;   in Loop: Header=BB0_1435 Depth=2
	mov.d	x9, v5[1]
	ld1.s	{ v2 }[3], [x9]
LBB0_1443:                              ; %else3564
                                        ;   in Loop: Header=BB0_1435 Depth=2
	ldr	q5, [sp, #9936]                 ; 16-byte Reload
	shl.2d	v5, v5, #5
	ldr	q6, [sp, #12352]                ; 16-byte Reload
	orr.16b	v5, v5, v6
	ldr	q6, [sp, #5760]                 ; 16-byte Reload
	add.2d	v6, v6, v5
	tbz	w8, #4, LBB0_1445
; %bb.1444:                             ; %cond.load3566
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	x9, d6
	ld1.s	{ v0 }[0], [x9]
LBB0_1445:                              ; %else3570
                                        ;   in Loop: Header=BB0_1435 Depth=2
	tbz	w8, #5, LBB0_1447
; %bb.1446:                             ; %cond.load3572
                                        ;   in Loop: Header=BB0_1435 Depth=2
	mov.d	x9, v6[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_1447:                              ; %else3576
                                        ;   in Loop: Header=BB0_1435 Depth=2
	ldr	q6, [sp, #9920]                 ; 16-byte Reload
	shl.2d	v6, v6, #5
	ldr	q7, [sp, #12320]                ; 16-byte Reload
	orr.16b	v6, v6, v7
	ldr	q7, [sp, #5792]                 ; 16-byte Reload
	add.2d	v7, v7, v6
	tbz	w8, #6, LBB0_1449
; %bb.1448:                             ; %cond.load3578
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	x9, d7
	ld1.s	{ v0 }[2], [x9]
LBB0_1449:                              ; %else3582
                                        ;   in Loop: Header=BB0_1435 Depth=2
	tbz	w8, #7, LBB0_1451
; %bb.1450:                             ; %cond.load3584
                                        ;   in Loop: Header=BB0_1435 Depth=2
	mov.d	x8, v7[1]
	ld1.s	{ v0 }[3], [x8]
LBB0_1451:                              ; %else3588
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	w8, s27
	ldr	q7, [sp, #2272]                 ; 16-byte Reload
	ldr	q23, [sp, #10544]               ; 16-byte Reload
	bif.16b	v2, v23, v7
	ldr	q7, [sp, #2224]                 ; 16-byte Reload
	and.16b	v2, v7, v2
	str	q2, [sp, #10544]                ; 16-byte Spill
	ldr	q2, [sp, #2960]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #0, LBB0_1460
; %bb.1452:                             ; %else3594
                                        ;   in Loop: Header=BB0_1435 Depth=2
	tbnz	w8, #1, LBB0_1461
LBB0_1453:                              ; %else3598
                                        ;   in Loop: Header=BB0_1435 Depth=2
	ldr	q1, [sp, #2992]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbnz	w8, #2, LBB0_1462
LBB0_1454:                              ; %else3602
                                        ;   in Loop: Header=BB0_1435 Depth=2
	tbz	w8, #3, LBB0_1456
LBB0_1455:                              ; %cond.store3603
                                        ;   in Loop: Header=BB0_1435 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10544]                ; 16-byte Reload
	st1.s	{ v1 }[3], [x9]
LBB0_1456:                              ; %else3606
                                        ;   in Loop: Header=BB0_1435 Depth=2
	ldr	q1, [sp, #2256]                 ; 16-byte Reload
	ldr	q2, [sp, #4960]                 ; 16-byte Reload
	bif.16b	v0, v2, v1
	ldr	q1, [sp, #2240]                 ; 16-byte Reload
	and.16b	v1, v1, v0
	ldr	q0, [sp, #2976]                 ; 16-byte Reload
	add.2d	v0, v0, v5
	tbnz	w8, #4, LBB0_1463
; %bb.1457:                             ; %else3610
                                        ;   in Loop: Header=BB0_1435 Depth=2
	tbnz	w8, #5, LBB0_1464
LBB0_1458:                              ; %else3614
                                        ;   in Loop: Header=BB0_1435 Depth=2
	add.2d	v0, v31, v6
	tbnz	w8, #6, LBB0_1465
LBB0_1459:                              ; %else3618
                                        ;   in Loop: Header=BB0_1435 Depth=2
	tbz	w8, #7, LBB0_1434
	b	LBB0_1466
LBB0_1460:                              ; %cond.store3591
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #10544]                ; 16-byte Reload
	str	s2, [x9]
	tbz	w8, #1, LBB0_1453
LBB0_1461:                              ; %cond.store3595
                                        ;   in Loop: Header=BB0_1435 Depth=2
	mov.d	x9, v1[1]
	ldr	q1, [sp, #10544]                ; 16-byte Reload
	st1.s	{ v1 }[1], [x9]
	ldr	q1, [sp, #2992]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	tbz	w8, #2, LBB0_1454
LBB0_1462:                              ; %cond.store3599
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	x9, d1
	ldr	q2, [sp, #10544]                ; 16-byte Reload
	st1.s	{ v2 }[2], [x9]
	tbnz	w8, #3, LBB0_1455
	b	LBB0_1456
LBB0_1463:                              ; %cond.store3607
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	x9, d0
	str	s1, [x9]
	tbz	w8, #5, LBB0_1458
LBB0_1464:                              ; %cond.store3611
                                        ;   in Loop: Header=BB0_1435 Depth=2
	mov.d	x9, v0[1]
	st1.s	{ v1 }[1], [x9]
	add.2d	v0, v31, v6
	tbz	w8, #6, LBB0_1459
LBB0_1465:                              ; %cond.store3615
                                        ;   in Loop: Header=BB0_1435 Depth=2
	fmov	x9, d0
	st1.s	{ v1 }[2], [x9]
	tbz	w8, #7, LBB0_1434
LBB0_1466:                              ; %cond.store3619
                                        ;   in Loop: Header=BB0_1435 Depth=2
	mov.d	x8, v0[1]
	st1.s	{ v1 }[3], [x8]
	b	LBB0_1434
LBB0_1467:                              ; %direct.false363
	sshll.2d	v0, v24, #0
	sshll.2d	v1, v26, #0
	ldr	q2, [sp, #16]                   ; 16-byte Reload
	and.16b	v3, v14, v2
	str	q3, [sp, #13232]                ; 16-byte Spill
	and.16b	v3, v12, v2
	str	q3, [sp, #13216]                ; 16-byte Spill
	and.16b	v4, v1, v2
	and.16b	v5, v0, v2
	movi.2d	v6, #0000000000000000
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	fmov	x8, d0
	str	x8, [sp, #13200]                ; 8-byte Spill
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	fmov	x8, d0
	str	x8, [sp, #13184]                ; 8-byte Spill
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fmov	x15, d0
	ldr	q0, [sp, #11664]                ; 16-byte Reload
	fmov	x6, d0
	ldr	d1, [sp, #4520]                 ; 8-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v27, v0, #0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #13168]                ; 16-byte Spill
	ldr	d1, [sp, #40]                   ; 8-byte Reload
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #13152]                ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	ldr	q1, [sp, #12960]                ; 16-byte Reload
	mov.d	x7, v1[1]
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #13120]                ; 16-byte Spill
	fmov	x19, d1
	ldr	q0, [sp, #12976]                ; 16-byte Reload
	mov.d	x20, v0[1]
	fmov	x21, d0
	ldr	q0, [sp, #12992]                ; 16-byte Reload
	mov.d	x22, v0[1]
	fmov	x23, d0
	ldr	q0, [sp, #13008]                ; 16-byte Reload
	mov.d	x24, v0[1]
	fmov	x25, d0
	movi.2d	v19, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v8, #0000000000000000
	b	LBB0_1469
LBB0_1468:                              ; %else3917
                                        ;   in Loop: Header=BB0_1469 Depth=1
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v29, v29, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v30, v30, v0
	add.2d	v8, v8, v3
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v6, v6, v0
	fmov	x8, d6
	cmp	x8, #2
	b.ge	LBB0_1517
LBB0_1469:                              ; %direct.true912
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v0, v24, #0
	and.16b	v0, v0, v6
	mov.d	x8, v0[1]
	ldr	x10, [sp, #11736]               ; 8-byte Reload
	sdiv	x9, x8, x10
	msub	x8, x9, x10, x8
	fmov	x9, d0
	ldr	x11, [sp, #13200]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	d12, x9
	mov.d	v12[1], x8
	shl.2d	v0, v12, #5
	ldr	q1, [sp, #12336]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9776]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	ldr	d1, [sp, #12376]                ; 8-byte Reload
	fmov	w9, s1
	movi.2d	v11, #0000000000000000
	movi.2d	v10, #0000000000000000
	tbz	w9, #0, LBB0_1471
; %bb.1470:                             ; %cond.load3788
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x8, d0
	ldr	s11, [x8]
LBB0_1471:                              ; %else3792
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbz	w9, #1, LBB0_1473
; %bb.1472:                             ; %cond.load3794
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x8, v0[1]
	ld1.s	{ v11 }[1], [x8]
LBB0_1473:                              ; %else3798
                                        ;   in Loop: Header=BB0_1469 Depth=1
	ldr	q0, [sp, #12864]                ; 16-byte Reload
	and.16b	v0, v0, v29
	mov.d	x8, v0[1]
	ldr	x11, [sp, #11640]               ; 8-byte Reload
	sdiv	x10, x8, x11
	msub	x8, x10, x11, x8
	fmov	x10, d0
	sdiv	x11, x10, x15
	msub	x10, x11, x15, x10
	fmov	d7, x10
	mov.d	v7[1], x8
	shl.2d	v0, v7, #5
	ldr	q1, [sp, #12304]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9808]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w9, #2, LBB0_1475
; %bb.1474:                             ; %cond.load3800
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x8, d0
	ld1.s	{ v11 }[2], [x8]
LBB0_1475:                              ; %else3804
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbz	w9, #3, LBB0_1477
; %bb.1476:                             ; %cond.load3806
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x8, v0[1]
	ld1.s	{ v11 }[3], [x8]
LBB0_1477:                              ; %else3810
                                        ;   in Loop: Header=BB0_1469 Depth=1
	ldr	q0, [sp, #12880]                ; 16-byte Reload
	sshll.2d	v0, v0, #0
	and.16b	v0, v0, v30
	mov.d	x8, v0[1]
	sdiv	x10, x8, x26
	msub	x8, x10, x26, x8
	fmov	x10, d0
	ldr	x12, [sp, #13184]               ; 8-byte Reload
	sdiv	x11, x10, x12
	msub	x10, x11, x12, x10
	fmov	d16, x10
	mov.d	v16[1], x8
	shl.2d	v0, v16, #5
	ldr	q1, [sp, #12352]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9792]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w9, #4, LBB0_1479
; %bb.1478:                             ; %cond.load3812
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x8, d0
	ld1.s	{ v10 }[0], [x8]
LBB0_1479:                              ; %else3816
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbz	w9, #5, LBB0_1481
; %bb.1480:                             ; %cond.load3818
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x8, v0[1]
	ld1.s	{ v10 }[1], [x8]
LBB0_1481:                              ; %else3822
                                        ;   in Loop: Header=BB0_1469 Depth=1
	and.16b	v0, v14, v8
	mov.d	x8, v0[1]
	sdiv	x10, x8, x27
	msub	x8, x10, x27, x8
	fmov	x10, d0
	sdiv	x11, x10, x6
	msub	x10, x11, x6, x10
	fmov	d17, x10
	mov.d	v17[1], x8
	shl.2d	v0, v17, #5
	ldr	q1, [sp, #12320]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #9824]                 ; 16-byte Reload
	add.2d	v0, v1, v0
	tbz	w9, #6, LBB0_1483
; %bb.1482:                             ; %cond.load3824
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x8, d0
	ld1.s	{ v10 }[2], [x8]
LBB0_1483:                              ; %else3828
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbz	w9, #7, LBB0_1485
; %bb.1484:                             ; %cond.load3830
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x8, v0[1]
	ld1.s	{ v10 }[3], [x8]
LBB0_1485:                              ; %else3834
                                        ;   in Loop: Header=BB0_1469 Depth=1
	sshll.2d	v0, v24, #0
	ldr	q1, [sp, #12880]                ; 16-byte Reload
	sshll.2d	v1, v1, #0
	and.16b	v17, v14, v17
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	and.16b	v7, v2, v7
	and.16b	v18, v0, v12
	mov.d	x8, v18[1]
	and.16b	v16, v1, v16
	sdiv	x27, x8, x7
	fmov	x8, d18
	sdiv	x8, x8, x19
	mul	x10, x8, x19
	fmov	d2, x8
	mov.d	v2[1], x27
	mov.d	x8, v16[1]
	sdiv	x28, x8, x20
	fmov	x11, d16
	mov.d	x8, v7[1]
	sdiv	x8, x8, x22
	fmov	x9, d7
	mov.d	x12, v17[1]
	sdiv	x14, x9, x23
	sdiv	x9, x12, x24
	fmov	x12, d17
	sdiv	x26, x12, x25
	mul	x12, x9, x24
	mul	x30, x26, x25
	fmov	d31, x30
	mov.d	v31[1], x12
	mul	x12, x8, x22
	mul	x30, x14, x23
	fmov	d12, x30
	mov.d	v12[1], x12
	mul	x12, x28, x20
	sdiv	x30, x11, x21
	mul	x11, x30, x21
	fmov	d13, x11
	mov.d	v13[1], x12
	mul	x11, x27, x7
	fmov	d14, x10
	mov.d	v14[1], x11
	sub.2d	v14, v18, v14
	sub.2d	v15, v16, v13
	sub.2d	v7, v7, v12
	sub.2d	v16, v17, v31
	ldr	q3, [sp, #13040]                ; 16-byte Reload
	cmeq.2d	v17, v3, v16
	ldr	q3, [sp, #13056]                ; 16-byte Reload
	cmeq.2d	v18, v3, v15
	uzp1.4s	v17, v18, v17
	ldr	q3, [sp, #13072]                ; 16-byte Reload
	cmeq.2d	v18, v3, v7
	ldr	q3, [sp, #13104]                ; 16-byte Reload
	cmeq.2d	v31, v3, v14
	uzp1.4s	v18, v31, v18
	uzp1.8h	v18, v18, v17
	ldr	q3, [sp, #13328]                ; 16-byte Reload
	and.16b	v17, v3, v18
	xtn.8b	v12, v17
	shl.8b	v17, v12, #7
	cmlt.8b	v17, v17, #0
	ldr	d3, [sp, #13320]                ; 8-byte Reload
	and.8b	v17, v17, v3
	addv.8b	b17, v17
	fmov	w27, s17
	shl.2d	v2, v2, #5
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #1840]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	movi.2d	v13, #0000000000000000
	movi.2d	v17, #0000000000000000
	tbz	w27, #0, LBB0_1487
; %bb.1486:                             ; %cond.load3837
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x10, d2
	ldr	s13, [x10]
LBB0_1487:                              ; %else3841
                                        ;   in Loop: Header=BB0_1469 Depth=1
	ldr	q31, [sp, #1888]                ; 16-byte Reload
	tbz	w27, #1, LBB0_1489
; %bb.1488:                             ; %cond.load3843
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x10, v2[1]
	ld1.s	{ v13 }[1], [x10]
LBB0_1489:                              ; %else3847
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	d2, x14
	mov.d	v2[1], x8
	shl.2d	v2, v2, #5
	ldr	q3, [sp, #12304]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #1872]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w27, #2, LBB0_1491
; %bb.1490:                             ; %cond.load3849
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x8, d2
	ld1.s	{ v13 }[2], [x8]
LBB0_1491:                              ; %else3853
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbz	w27, #3, LBB0_1493
; %bb.1492:                             ; %cond.load3855
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x8, v2[1]
	ld1.s	{ v13 }[3], [x8]
LBB0_1493:                              ; %else3859
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	d2, x30
	mov.d	v2[1], x28
	shl.2d	v2, v2, #5
	ldr	q3, [sp, #12352]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #1856]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w27, #4, LBB0_1495
; %bb.1494:                             ; %cond.load3861
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x8, d2
	ld1.s	{ v17 }[0], [x8]
LBB0_1495:                              ; %else3865
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbz	w27, #5, LBB0_1497
; %bb.1496:                             ; %cond.load3867
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x8, v2[1]
	ld1.s	{ v17 }[1], [x8]
LBB0_1497:                              ; %else3871
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	d2, x26
	mov.d	v2[1], x9
	shl.2d	v2, v2, #5
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v31, v2
	tbz	w27, #6, LBB0_1499
; %bb.1498:                             ; %cond.load3873
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x8, d2
	ld1.s	{ v17 }[2], [x8]
LBB0_1499:                              ; %else3877
                                        ;   in Loop: Header=BB0_1469 Depth=1
	ldr	x26, [sp, #11632]               ; 8-byte Reload
	bit.16b	v25, v11, v27
	ldr	q3, [sp, #13120]                ; 16-byte Reload
	and.16b	v25, v3, v25
	ldr	q31, [sp, #13024]               ; 16-byte Reload
	bit.16b	v26, v16, v31
	ldr	q16, [sp, #12864]               ; 16-byte Reload
	bit.16b	v21, v7, v16
	bit.16b	v22, v15, v1
	bit.16b	v20, v14, v0
	ldr	q0, [sp, #13328]                ; 16-byte Reload
	bic.16b	v0, v0, v18
	xtn.8b	v0, v0
	tbz	w27, #7, LBB0_1501
; %bb.1500:                             ; %cond.load3879
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x8, v2[1]
	ld1.s	{ v17 }[3], [x8]
LBB0_1501:                              ; %else3883
                                        ;   in Loop: Header=BB0_1469 Depth=1
	zip2.8b	v1, v12, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bsl.16b	v1, v17, v9
	zip1.8b	v2, v12, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bsl.16b	v2, v13, v23
	zip1.8b	v7, v0, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmge.4s	v7, v7, #0
	and.16b	v23, v7, v2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v9, v0, v1
	xtn.2s	v0, v26
	xtn.2s	v16, v22
	xtn.2s	v17, v21
	xtn.2s	v1, v20
	mov.s	w8, v1[1]
	fmov	w9, s1
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldr	q1, [sp, #13136]                ; 16-byte Reload
	str	d1, [sp, #13352]
	ldrb	w11, [x11]
	and	w11, w16, w11
	str	q9, [sp, #13376]
	str	q23, [sp, #13360]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1072
	ldr	s1, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s1, s1, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w17, w8
	str	q9, [sp, #13408]
	str	q23, [sp, #13392]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1104
	ldr	s2, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s7, s2, s19, ne
	mov.s	w8, v17[1]
	fmov	w9, s17
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	str	q9, [sp, #13440]
	str	q23, [sp, #13424]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1136
	ldr	s2, [x12, x9, lsl #2]
	and	w9, w0, w11
	tst	w10, w9
	fcsel	s17, s2, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w1, w8
	str	q9, [sp, #13472]
	str	q23, [sp, #13456]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1168
	ldr	s2, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	w8, v16[1]
	fcsel	s11, s2, s19, ne
	fmov	w9, s16
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w2, w11
	stp	q23, q9, [x13]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1200
	ldr	s2, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s16, s2, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w3, w8
	stp	q23, q9, [x13, #32]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1232
	ldr	s2, [x11, x10, lsl #2]
	tst	w9, w8
	fcsel	s18, s2, s19, ne
	mov.s	w8, v0[1]
	fmov	w9, s0
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	cset	w10, lo
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w4, w11
	stp	q23, q9, [x13, #64]
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #1264
	ldr	s0, [x12, x9, lsl #2]
	tst	w10, w11
	fcsel	s0, s0, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	and	x10, x8, #0x7
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1064
	bfxil	x11, x8, #0, #3
	ldrb	w8, [x11]
	and	w8, w5, w8
	stp	q23, q9, [x13, #96]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1296
	ldr	s2, [x11, x10, lsl #2]
	tst	w9, w8
	mov.s	v1[1], v7[0]
	mov.s	v1[2], v17[0]
	mov.s	v1[3], v11[0]
	fcsel	s7, s2, s19, ne
	fdiv.4s	v1, v25, v1
	shl.2d	v2, v6, #5
	ldr	q3, [sp, #12336]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v5, v2
	ldr	d3, [sp, #12376]                ; 8-byte Reload
	fmov	w8, s3
	ldr	q14, [sp, #13024]               ; 16-byte Reload
	ldr	x27, [sp, #11400]               ; 8-byte Reload
	tbnz	w8, #0, LBB0_1510
; %bb.1502:                             ; %else3889
                                        ;   in Loop: Header=BB0_1469 Depth=1
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	tbnz	w8, #1, LBB0_1511
LBB0_1503:                              ; %else3893
                                        ;   in Loop: Header=BB0_1469 Depth=1
	shl.2d	v2, v29, #5
	ldr	q17, [sp, #12304]               ; 16-byte Reload
	orr.16b	v2, v2, v17
	ldr	q17, [sp, #13216]               ; 16-byte Reload
	add.2d	v2, v17, v2
	tbnz	w8, #2, LBB0_1512
LBB0_1504:                              ; %else3897
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbz	w8, #3, LBB0_1506
LBB0_1505:                              ; %cond.store3898
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x9, v2[1]
	st1.s	{ v1 }[3], [x9]
LBB0_1506:                              ; %else3901
                                        ;   in Loop: Header=BB0_1469 Depth=1
	ldr	q1, [sp, #13168]                ; 16-byte Reload
	bsl.16b	v1, v10, v28
	ldr	q2, [sp, #13152]                ; 16-byte Reload
	and.16b	v28, v2, v1
	mov.s	v16[1], v18[0]
	mov.s	v16[2], v0[0]
	mov.s	v16[3], v7[0]
	fdiv.4s	v0, v28, v16
	shl.2d	v1, v30, #5
	ldr	q2, [sp, #12352]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	add.2d	v1, v4, v1
	tbnz	w8, #4, LBB0_1513
; %bb.1507:                             ; %else3905
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbnz	w8, #5, LBB0_1514
LBB0_1508:                              ; %else3909
                                        ;   in Loop: Header=BB0_1469 Depth=1
	shl.2d	v1, v8, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #13232]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #6, LBB0_1515
LBB0_1509:                              ; %else3913
                                        ;   in Loop: Header=BB0_1469 Depth=1
	tbz	w8, #7, LBB0_1468
	b	LBB0_1516
LBB0_1510:                              ; %cond.store3886
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x9, d2
	str	s1, [x9]
	ldr	q3, [sp, #13248]                ; 16-byte Reload
	tbz	w8, #1, LBB0_1503
LBB0_1511:                              ; %cond.store3890
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x9, v2[1]
	st1.s	{ v1 }[1], [x9]
	shl.2d	v2, v29, #5
	ldr	q17, [sp, #12304]               ; 16-byte Reload
	orr.16b	v2, v2, v17
	ldr	q17, [sp, #13216]               ; 16-byte Reload
	add.2d	v2, v17, v2
	tbz	w8, #2, LBB0_1504
LBB0_1512:                              ; %cond.store3894
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x9, d2
	st1.s	{ v1 }[2], [x9]
	tbnz	w8, #3, LBB0_1505
	b	LBB0_1506
LBB0_1513:                              ; %cond.store3902
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x9, d1
	str	s0, [x9]
	tbz	w8, #5, LBB0_1508
LBB0_1514:                              ; %cond.store3906
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x9, v1[1]
	st1.s	{ v0 }[1], [x9]
	shl.2d	v1, v8, #5
	ldr	q2, [sp, #12320]                ; 16-byte Reload
	orr.16b	v1, v1, v2
	ldr	q2, [sp, #13232]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #6, LBB0_1509
LBB0_1515:                              ; %cond.store3910
                                        ;   in Loop: Header=BB0_1469 Depth=1
	fmov	x9, d1
	st1.s	{ v0 }[2], [x9]
	tbz	w8, #7, LBB0_1468
LBB0_1516:                              ; %cond.store3914
                                        ;   in Loop: Header=BB0_1469 Depth=1
	mov.d	x8, v1[1]
	st1.s	{ v0 }[3], [x8]
	b	LBB0_1468
LBB0_1517:                              ; %direct.true933.preheader
	movi.2d	v6, #0000000000000000
	sshll.2d	v7, v24, #0
	ldr	q0, [sp, #12880]                ; 16-byte Reload
	sshll.2d	v16, v0, #0
	mov	w8, #2                          ; =0x2
	dup.2d	v18, x8
	ldr	q0, [sp, #11712]                ; 16-byte Reload
	fmov	x8, d0
	ldr	q0, [sp, #11696]                ; 16-byte Reload
	fmov	x13, d0
	ldr	q0, [sp, #11680]                ; 16-byte Reload
	fmov	x14, d0
	ldr	d2, [sp, #4520]                 ; 8-byte Reload
	zip1.8b	v0, v2, v0
	ldr	q1, [sp, #11664]                ; 16-byte Reload
	fmov	x15, d1
	ushll.4s	v0, v0, #0
	ldr	d1, [sp, #12376]                ; 8-byte Reload
	fmov	w16, s1
	shl.4s	v0, v0, #31
	cmlt.4s	v19, v0, #0
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v20, v0, #0
	ldr	d1, [sp, #40]                   ; 8-byte Reload
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v21, v0, #0
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v22, v0, #0
	mov	w17, #3                         ; =0x3
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	movi.2d	v31, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v9, #0000000000000000
	movi.2d	v10, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v12, #0000000000000000
	ldr	x12, [sp, #32]                  ; 8-byte Reload
	ldr	x0, [sp, #11640]                ; 8-byte Reload
	b	LBB0_1519
LBB0_1518:                              ; %else3999
                                        ;   in Loop: Header=BB0_1519 Depth=1
	ldr	q0, [sp, #13296]                ; 16-byte Reload
	add.2d	v10, v10, v0
	ldr	q0, [sp, #13280]                ; 16-byte Reload
	add.2d	v11, v11, v0
	ldr	q0, [sp, #13248]                ; 16-byte Reload
	add.2d	v12, v12, v0
	ldr	q0, [sp, #13264]                ; 16-byte Reload
	add.2d	v6, v6, v0
	fmov	x9, d6
	cmp	x9, #2
	b.ge	LBB0_1551
LBB0_1519:                              ; %direct.true933
                                        ; =>This Inner Loop Header: Depth=1
	shl.2d	v0, v6, #5
	ldr	q1, [sp, #12336]                ; 16-byte Reload
	orr.16b	v0, v0, v1
	add.2d	v2, v5, v0
	movi.2d	v1, #0000000000000000
	movi.2d	v0, #0000000000000000
	tbnz	w16, #0, LBB0_1544
; %bb.1520:                             ; %else3923
                                        ;   in Loop: Header=BB0_1519 Depth=1
	tbnz	w16, #1, LBB0_1545
LBB0_1521:                              ; %else3929
                                        ;   in Loop: Header=BB0_1519 Depth=1
	shl.2d	v2, v10, #5
	ldr	q3, [sp, #12304]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #13216]                ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w16, #2, LBB0_1546
LBB0_1522:                              ; %else3935
                                        ;   in Loop: Header=BB0_1519 Depth=1
	tbnz	w16, #3, LBB0_1547
LBB0_1523:                              ; %else3941
                                        ;   in Loop: Header=BB0_1519 Depth=1
	shl.2d	v2, v11, #5
	ldr	q3, [sp, #12352]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v4, v2
	tbnz	w16, #4, LBB0_1548
LBB0_1524:                              ; %else3947
                                        ;   in Loop: Header=BB0_1519 Depth=1
	tbnz	w16, #5, LBB0_1549
LBB0_1525:                              ; %else3953
                                        ;   in Loop: Header=BB0_1519 Depth=1
	shl.2d	v2, v12, #5
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	add.2d	v2, v3, v2
	tbnz	w16, #6, LBB0_1550
LBB0_1526:                              ; %else3959
                                        ;   in Loop: Header=BB0_1519 Depth=1
	tbz	w16, #7, LBB0_1528
LBB0_1527:                              ; %cond.load3961
                                        ;   in Loop: Header=BB0_1519 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v0 }[3], [x9]
LBB0_1528:                              ; %else3965
                                        ;   in Loop: Header=BB0_1519 Depth=1
	ldr	q17, [sp, #12864]               ; 16-byte Reload
	and.16b	v2, v17, v10
	and.16b	v13, v16, v11
	and.16b	v14, v7, v6
	mov.d	x9, v14[1]
	ldr	x11, [sp, #11736]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d14
	sdiv	x11, x10, x8
	msub	x10, x11, x8, x10
	fmov	d14, x10
	mov.d	v14[1], x9
	mov.d	x9, v13[1]
	sdiv	x10, x9, x26
	msub	x9, x10, x26, x9
	fmov	x10, d13
	sdiv	x11, x10, x13
	msub	x10, x11, x13, x10
	fmov	d13, x10
	mov.d	v13[1], x9
	mov.d	x9, v2[1]
	sdiv	x10, x9, x0
	msub	x9, x10, x0, x9
	fmov	x10, d2
	sdiv	x11, x10, x14
	msub	x10, x11, x14, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	ldr	q3, [sp, #13024]                ; 16-byte Reload
	and.16b	v15, v3, v12
	mov.d	x9, v15[1]
	sdiv	x10, x9, x27
	msub	x9, x10, x27, x9
	fmov	x10, d15
	sdiv	x11, x10, x15
	msub	x10, x11, x15, x10
	fmov	d15, x10
	mov.d	v15[1], x9
	bit.16b	v28, v15, v3
	bit.16b	v26, v2, v17
	bit.16b	v27, v13, v16
	bit.16b	v25, v14, v7
	ldr	q3, [sp, #13136]                ; 16-byte Reload
	movi	d2, #0x00000000ffffff
	bit.8b	v9, v2, v3
	ldr	q2, [sp, #5808]                 ; 16-byte Reload
	bit.16b	v29, v2, v7
	bif.16b	v1, v23, v19
	and.16b	v23, v22, v1
	ldr	q1, [sp, #3008]                 ; 16-byte Reload
	add.2d	v1, v28, v1
	ldr	q2, [sp, #3040]                 ; 16-byte Reload
	add.2d	v2, v27, v2
	ldr	q17, [sp, #3056]                ; 16-byte Reload
	add.2d	v13, v25, v17
	ldr	q17, [sp, #3024]                ; 16-byte Reload
	add.2d	v14, v26, v17
	ldr	q17, [sp, #1904]                ; 16-byte Reload
	add.2d	v15, v25, v17
	dup.2d	v17, x17
	cmhi.2d	v14, v17, v14
	cmhi.2d	v13, v17, v13
	uzp1.4s	v13, v13, v14
	cmhi.2d	v2, v17, v2
	cmhi.2d	v1, v17, v1
	uzp1.4s	v1, v2, v1
	uzp1.8h	v1, v13, v1
	xtn.8b	v1, v1
	mov.d	x9, v15[1]
	fmov	x10, d15
	add	x10, x10, x10, lsl #1
	fmov	d2, x10
	add	x9, x9, x9, lsl #1
	mov.d	v2[1], x9
	add.2d	v2, v2, v29
	and.8b	v17, v3, v9
	and.8b	v1, v17, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	ldr	d3, [sp, #13320]                ; 8-byte Reload
	and.8b	v1, v1, v3
	addv.8b	b1, v1
	fmov	w9, s1
	shl.2d	v2, v2, #2
	dup.2d	v1, x12
	add.2d	v2, v1, v2
	tbz	w9, #0, LBB0_1530
; %bb.1529:                             ; %cond.store3968
                                        ;   in Loop: Header=BB0_1519 Depth=1
	fmov	x10, d2
	str	s23, [x10]
LBB0_1530:                              ; %else3971
                                        ;   in Loop: Header=BB0_1519 Depth=1
	tbz	w9, #1, LBB0_1532
; %bb.1531:                             ; %cond.store3972
                                        ;   in Loop: Header=BB0_1519 Depth=1
	mov.d	x10, v2[1]
	st1.s	{ v23 }[1], [x10]
LBB0_1532:                              ; %else3975
                                        ;   in Loop: Header=BB0_1519 Depth=1
	ldr	q2, [sp, #12864]                ; 16-byte Reload
	bit.16b	v30, v18, v2
	ldr	q2, [sp, #1936]                 ; 16-byte Reload
	add.2d	v2, v26, v2
	mov.d	x10, v2[1]
	fmov	x11, d2
	add	x11, x11, x11, lsl #1
	fmov	d2, x11
	add	x10, x10, x10, lsl #1
	mov.d	v2[1], x10
	add.2d	v2, v2, v30
	shl.2d	v2, v2, #2
	add.2d	v2, v1, v2
	ldr	q17, [sp, #13024]               ; 16-byte Reload
	tbz	w9, #2, LBB0_1534
; %bb.1533:                             ; %cond.store3976
                                        ;   in Loop: Header=BB0_1519 Depth=1
	fmov	x10, d2
	st1.s	{ v23 }[2], [x10]
LBB0_1534:                              ; %else3979
                                        ;   in Loop: Header=BB0_1519 Depth=1
	tbz	w9, #3, LBB0_1536
; %bb.1535:                             ; %cond.store3980
                                        ;   in Loop: Header=BB0_1519 Depth=1
	mov.d	x10, v2[1]
	st1.s	{ v23 }[3], [x10]
LBB0_1536:                              ; %else3983
                                        ;   in Loop: Header=BB0_1519 Depth=1
	bit.16b	v31, v18, v16
	bif.16b	v0, v24, v20
	and.16b	v24, v21, v0
	ldr	q0, [sp, #1920]                 ; 16-byte Reload
	add.2d	v0, v27, v0
	mov.d	x10, v0[1]
	fmov	x11, d0
	add	x11, x11, x11, lsl #1
	fmov	d0, x11
	add	x10, x10, x10, lsl #1
	mov.d	v0[1], x10
	add.2d	v0, v0, v31
	shl.2d	v0, v0, #2
	add.2d	v0, v1, v0
	tbz	w9, #4, LBB0_1538
; %bb.1537:                             ; %cond.store3984
                                        ;   in Loop: Header=BB0_1519 Depth=1
	fmov	x10, d0
	str	s24, [x10]
LBB0_1538:                              ; %else3987
                                        ;   in Loop: Header=BB0_1519 Depth=1
	tbz	w9, #5, LBB0_1540
; %bb.1539:                             ; %cond.store3988
                                        ;   in Loop: Header=BB0_1519 Depth=1
	mov.d	x10, v0[1]
	st1.s	{ v24 }[1], [x10]
LBB0_1540:                              ; %else3991
                                        ;   in Loop: Header=BB0_1519 Depth=1
	bit.16b	v8, v18, v17
	ldr	q0, [sp, #1952]                 ; 16-byte Reload
	add.2d	v0, v28, v0
	mov.d	x10, v0[1]
	fmov	x11, d0
	add	x11, x11, x11, lsl #1
	fmov	d0, x11
	add	x10, x10, x10, lsl #1
	mov.d	v0[1], x10
	add.2d	v0, v0, v8
	shl.2d	v0, v0, #2
	add.2d	v0, v1, v0
	tbz	w9, #6, LBB0_1542
; %bb.1541:                             ; %cond.store3992
                                        ;   in Loop: Header=BB0_1519 Depth=1
	fmov	x10, d0
	st1.s	{ v24 }[2], [x10]
LBB0_1542:                              ; %else3995
                                        ;   in Loop: Header=BB0_1519 Depth=1
	tbz	w9, #7, LBB0_1518
; %bb.1543:                             ; %cond.store3996
                                        ;   in Loop: Header=BB0_1519 Depth=1
	mov.d	x9, v0[1]
	st1.s	{ v24 }[3], [x9]
	b	LBB0_1518
LBB0_1544:                              ; %cond.load3919
                                        ;   in Loop: Header=BB0_1519 Depth=1
	fmov	x9, d2
	ldr	s1, [x9]
	tbz	w16, #1, LBB0_1521
LBB0_1545:                              ; %cond.load3925
                                        ;   in Loop: Header=BB0_1519 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v1 }[1], [x9]
	shl.2d	v2, v10, #5
	ldr	q3, [sp, #12304]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #13216]                ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w16, #2, LBB0_1522
LBB0_1546:                              ; %cond.load3931
                                        ;   in Loop: Header=BB0_1519 Depth=1
	fmov	x9, d2
	ld1.s	{ v1 }[2], [x9]
	tbz	w16, #3, LBB0_1523
LBB0_1547:                              ; %cond.load3937
                                        ;   in Loop: Header=BB0_1519 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v1 }[3], [x9]
	shl.2d	v2, v11, #5
	ldr	q3, [sp, #12352]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	add.2d	v2, v4, v2
	tbz	w16, #4, LBB0_1524
LBB0_1548:                              ; %cond.load3943
                                        ;   in Loop: Header=BB0_1519 Depth=1
	fmov	x9, d2
	ld1.s	{ v0 }[0], [x9]
	tbz	w16, #5, LBB0_1525
LBB0_1549:                              ; %cond.load3949
                                        ;   in Loop: Header=BB0_1519 Depth=1
	mov.d	x9, v2[1]
	ld1.s	{ v0 }[1], [x9]
	shl.2d	v2, v12, #5
	ldr	q3, [sp, #12320]                ; 16-byte Reload
	orr.16b	v2, v2, v3
	ldr	q3, [sp, #13232]                ; 16-byte Reload
	add.2d	v2, v3, v2
	tbz	w16, #6, LBB0_1526
LBB0_1550:                              ; %cond.load3955
                                        ;   in Loop: Header=BB0_1519 Depth=1
	fmov	x9, d2
	ld1.s	{ v0 }[2], [x9]
	tbnz	w16, #7, LBB0_1527
	b	LBB0_1528
LBB0_1551:
	add	sp, sp, #6, lsl #12             ; =24576
	add	sp, sp, #224
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_1552:                              ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh20, Lloh21
	.loh AdrpLdr	Lloh19, Lloh23
	.loh AdrpLdr	Lloh18, Lloh22
	.loh AdrpAdrp	Lloh15, Lloh19
	.loh AdrpLdr	Lloh15, Lloh16
	.loh AdrpLdr	Lloh14, Lloh17
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh37, Lloh38
	.loh AdrpAdrp	Lloh34, Lloh37
	.loh AdrpLdr	Lloh34, Lloh35
	.loh AdrpLdr	Lloh33, Lloh36
	.loh AdrpLdr	Lloh32, Lloh40
	.loh AdrpLdr	Lloh31, Lloh45
	.loh AdrpLdr	Lloh30, Lloh44
	.loh AdrpLdr	Lloh29, Lloh43
	.loh AdrpLdr	Lloh28, Lloh47
	.loh AdrpLdr	Lloh27, Lloh46
	.loh AdrpLdr	Lloh26, Lloh42
	.loh AdrpLdr	Lloh25, Lloh41
	.loh AdrpLdr	Lloh24, Lloh39
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

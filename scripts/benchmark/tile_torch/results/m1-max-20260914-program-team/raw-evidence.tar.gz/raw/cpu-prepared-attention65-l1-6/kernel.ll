; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 2112
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 70752
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 85312
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 89472
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %15 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace17 = load ptr, ptr %15, align 8
  %tile_snapshot.private18 = getelementptr inbounds i8, ptr %private.workspace17, i64 93632
  %.splatinsert19 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private18, i64 0
  %.splat20 = shufflevector <8 x ptr> %.splatinsert19, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat20, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %18 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace21 = load ptr, ptr %18, align 8
  %tile_snapshot.private22 = getelementptr inbounds i8, ptr %private.workspace21, i64 97792
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %19 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %20 = insertvalue { <8 x ptr>, <8 x i64> } %19, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %21 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace25 = load ptr, ptr %21, align 8
  %tile_snapshot.private26 = getelementptr inbounds i8, ptr %private.workspace25, i64 97920
  %.splatinsert27 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private26, i64 0
  %.splat28 = shufflevector <8 x ptr> %.splatinsert27, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat28, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 130, i64 260, i64 390, i64 520, i64 650, i64 780, i64 910>, 1
  %24 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace29 = load ptr, ptr %24, align 8
  %tile_snapshot.private30 = getelementptr inbounds i8, ptr %private.workspace29, i64 98960
  %.splatinsert31 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private30, i64 0
  %.splat32 = shufflevector <8 x ptr> %.splatinsert31, <8 x ptr> poison, <8 x i32> zeroinitializer
  %25 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat32, 0
  %26 = insertvalue { <8 x ptr>, <8 x i64> } %25, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %27 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace33 = load ptr, ptr %27, align 8
  %tile_snapshot.private34 = getelementptr inbounds i8, ptr %private.workspace33, i64 103120
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %30 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace37 = load ptr, ptr %30, align 8
  %tile_snapshot.private38 = getelementptr inbounds i8, ptr %private.workspace37, i64 103184
  %.splatinsert39 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private38, i64 0
  %.splat40 = shufflevector <8 x ptr> %.splatinsert39, <8 x ptr> poison, <8 x i32> zeroinitializer
  %31 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat40, 0
  %32 = insertvalue { <8 x ptr>, <8 x i64> } %31, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill41, align 64
  %.spill42 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill42, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.slot43 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot43, align 32
  %.slot44 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot44, align 64
  %.slot45 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot45, align 32
  %.slot46 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot46, align 32
  %.slot47 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot47, align 32
  %.slot48 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot48, align 32
  %.slot49 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot49, align 32
  %.slot50 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot50, align 32
  %.slot51 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot51, align 32
  %.slot52 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot52, align 32
  %.slot53 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot53, align 32
  %.slot54 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot54, align 32
  %.slot55 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot55, align 32
  %.slot56 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot56, align 32
  %.slot57 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot57, align 32
  %.slot58 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot58, align 32
  %.slot59 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot59, align 32
  %.slot60 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot60, align 32
  %.slot61 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot61, align 32
  %.slot62 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot62, align 32
  %.spill63 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill63, align 64
  %tile_snapshot.spill64 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill64, align 64
  %.slot65 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot65, align 64
  %.slot66 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot66, align 32
  %tile_snapshot.spill67 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill67, align 64
  %.slot68 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot68, align 64
  %.slot69 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot69, align 32
  %tile_snapshot.spill70 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill70, align 64
  %.slot71 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot71, align 64
  %tile_snapshot.spill72 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill72, align 64
  %.slot73 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot73, align 64
  %tile_snapshot.spill74 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill74, align 64
  %.slot75 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot75, align 64
  %tile_snapshot.spill76 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill76, align 64
  %tile_snapshot.spill77 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill77, align 64
  %.slot78 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot78, align 64
  %tile_snapshot.spill79 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill79, align 64
  %.slot80 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot80, align 64
  %.spill81 = alloca i64, align 8
  store i64 0, ptr %.spill81, align 4
  %.spill82 = alloca i64, align 8
  store i64 0, ptr %.spill82, align 4
  %.spill83 = alloca i64, align 8
  store i64 0, ptr %.spill83, align 4
  %.spill84 = alloca i64, align 8
  store i64 0, ptr %.spill84, align 4
  %.spill85 = alloca i64, align 8
  store i64 0, ptr %.spill85, align 4
  %.spill86 = alloca i64, align 8
  store i64 0, ptr %.spill86, align 4
  %.spill87 = alloca i64, align 8
  store i64 0, ptr %.spill87, align 4
  %.spill88 = alloca i64, align 8
  store i64 0, ptr %.spill88, align 4
  %.spill89 = alloca i64, align 8
  store i64 0, ptr %.spill89, align 4
  %.spill90 = alloca i64, align 8
  store i64 0, ptr %.spill90, align 4
  %.slot91 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot91, align 64
  %.slot92 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot92, align 32
  %.slot93 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot93, align 32
  %.slot94 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot94, align 32
  %.slot95 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot95, align 32
  %.spill96 = alloca i64, align 8
  store i64 0, ptr %.spill96, align 4
  %.spill97 = alloca i64, align 8
  store i64 0, ptr %.spill97, align 4
  %.spill98 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill98, align 32
  %.spill99 = alloca i64, align 8
  store i64 0, ptr %.spill99, align 4
  %.spill100 = alloca i64, align 8
  store i64 0, ptr %.spill100, align 4
  %.spill101 = alloca i64, align 8
  store i64 0, ptr %.spill101, align 4
  %.spill102 = alloca i64, align 8
  store i64 0, ptr %.spill102, align 4
  %.spill103 = alloca i64, align 8
  store i64 0, ptr %.spill103, align 4
  %.slot104 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot104, align 64
  %.slot105 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot105, align 32
  %.slot106 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot106, align 32
  %.slot107 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot107, align 32
  %.slot108 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot108, align 32
  %.spill109 = alloca i64, align 8
  store i64 0, ptr %.spill109, align 4
  %.spill110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill110, align 32
  %.spill111 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill111, align 32
  %tile_snapshot.spill112 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill112, align 64
  %.spill113 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill113, align 32
  %.spill114 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill114, align 32
  %tile_snapshot.spill115 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill115, align 64
  %.slot116 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot116, align 64
  %.spill117 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill117, align 32
  %.spill118 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill118, align 32
  %.slot119 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot119, align 64
  %.slot120 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot120, align 32
  %.slot121 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot121, align 32
  %.slot122 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot122, align 32
  %.slot123 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot123, align 32
  %.spill124 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill124, align 32
  %.slot125 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot125, align 64
  %.slot126 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot126, align 32
  %.slot127 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot127, align 32
  %.slot128 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot128, align 32
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %.spill130 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill130, align 32
  %.spill131 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill131, align 32
  %.spill132 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill132, align 32
  %.spill133 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill133, align 32
  %.spill134 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill134, align 32
  %.spill135 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill135, align 32
  %.spill136 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill136, align 32
  %.spill137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill137, align 32
  %.spill138 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill138, align 32
  %.spill139 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill139, align 32
  %.spill140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.spill142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill142, align 32
  %.spill143 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill143, align 32
  %.spill144 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill144, align 32
  %.slot145 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot145, align 64
  %.slot146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot146, align 32
  %.slot147 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot147, align 64
  %.slot148 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot148, align 32
  %.slot149 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot149, align 64
  %.slot150 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot150, align 32
  %.slot151 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot151, align 64
  %.slot152 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot152, align 32
  %.slot153 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot153, align 64
  %.slot154 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot154, align 32
  %.slot155 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot155, align 64
  %.slot156 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot156, align 32
  %.slot157 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot157, align 64
  %.slot158 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot158, align 32
  %.slot159 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot159, align 64
  %.slot160 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot160, align 32
  %.slot161 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot161, align 64
  %.slot162 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot162, align 32
  %.slot163 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot163, align 64
  %.slot164 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot164, align 32
  %.slot165 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot165, align 64
  %.slot166 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot166, align 32
  %.slot167 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot167, align 64
  %.slot168 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot168, align 32
  %.slot169 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot169, align 64
  %.slot170 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot170, align 32
  %.slot171 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot171, align 64
  %.slot172 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot172, align 32
  %.spill173 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill173, align 32
  %.spill174 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill174, align 32
  %.spill175 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill175, align 32
  %.spill176 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill176, align 32
  %.spill177 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill177, align 32
  %.spill178 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill178, align 32
  %.spill179 = alloca i64, align 8
  store i64 0, ptr %.spill179, align 4
  %.spill180 = alloca i64, align 8
  store i64 0, ptr %.spill180, align 4
  %.spill181 = alloca i64, align 8
  store i64 0, ptr %.spill181, align 4
  %.spill182 = alloca i64, align 8
  store i64 0, ptr %.spill182, align 4
  %.spill183 = alloca i64, align 8
  store i64 0, ptr %.spill183, align 4
  %.spill184 = alloca i64, align 8
  store i64 0, ptr %.spill184, align 4
  %.spill185 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill185, align 1
  %.spill186 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill186, align 64
  %33 = getelementptr i8, ptr %argument_buffer, i64 0
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = getelementptr i8, ptr %argument_buffer, i64 16
  %40 = load ptr, ptr %39, align 16
  %41 = getelementptr i8, ptr %39, i64 8
  %42 = load i64, ptr %41, align 8
  %43 = insertvalue { ptr, i64 } poison, ptr %40, 0
  %44 = insertvalue { ptr, i64 } %43, i64 %42, 1
  %45 = getelementptr i8, ptr %argument_buffer, i64 32
  %46 = load ptr, ptr %45, align 16
  %47 = getelementptr i8, ptr %45, i64 8
  %48 = load i64, ptr %47, align 8
  %49 = insertvalue { ptr, i64 } poison, ptr %46, 0
  %50 = insertvalue { ptr, i64 } %49, i64 %48, 1
  %51 = getelementptr i8, ptr %argument_buffer, i64 48
  %52 = load ptr, ptr %51, align 16
  %53 = getelementptr i8, ptr %51, i64 8
  %54 = load i64, ptr %53, align 8
  %55 = insertvalue { ptr, i64 } poison, ptr %52, 0
  %56 = insertvalue { ptr, i64 } %55, i64 %54, 1
  %57 = load i32, ptr %launch_config, align 4
  %58 = getelementptr i8, ptr %launch_config, i64 12
  %59 = load i32, ptr %58, align 4
  %60 = getelementptr i8, ptr %launch_config, i64 4
  %61 = load i32, ptr %60, align 4
  %62 = getelementptr i8, ptr %launch_config, i64 16
  %63 = load i32, ptr %62, align 4
  %64 = getelementptr i8, ptr %launch_config, i64 8
  %65 = load i32, ptr %64, align 4
  %66 = getelementptr i8, ptr %launch_config, i64 20
  %67 = load i32, ptr %66, align 4
  %68 = getelementptr i8, ptr %launch_config, i64 36
  %69 = load i32, ptr %68, align 4
  %.splatinsert187 = insertelement <8 x i32> poison, i32 %69, i64 0
  %.splat188 = shufflevector <8 x i32> %.splatinsert187, <8 x i32> poison, <8 x i32> zeroinitializer
  %70 = add <8 x i32> %.splat188, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %71 = mul i32 %57, 32
  %.splatinsert189 = insertelement <8 x i32> poison, i32 %71, i64 0
  %.splat190 = shufflevector <8 x i32> %.splatinsert189, <8 x i32> poison, <8 x i32> zeroinitializer
  %72 = add <8 x i32> %.splat190, %70
  %73 = mul i32 %61, 1
  %.splatinsert191 = insertelement <8 x i32> poison, i32 %73, i64 0
  %.splat192 = shufflevector <8 x i32> %.splatinsert191, <8 x i32> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i32> %.splat192, zeroinitializer
  %75 = mul i32 %65, 1
  %.splatinsert193 = insertelement <8 x i32> poison, i32 %75, i64 0
  %.splat194 = shufflevector <8 x i32> %.splatinsert193, <8 x i32> poison, <8 x i32> zeroinitializer
  %76 = add <8 x i32> %.splat194, zeroinitializer
  %77 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %72, 0
  %78 = insertvalue [3 x <8 x i32>] %77, <8 x i32> %74, 1
  %79 = insertvalue [3 x <8 x i32>] %78, <8 x i32> %76, 2
  %.splatinsert195 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat196 = shufflevector <8 x i32> %.splatinsert195, <8 x i32> poison, <8 x i32> zeroinitializer
  %80 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat196
  %81 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  br i1 %81, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %82 = extractvalue [3 x <8 x i32>] %79, 0
  %83 = zext <8 x i32> %82 to <8 x i64>
  %84 = select <8 x i1> %80, <8 x i64> %83, <8 x i64> zeroinitializer
  %85 = select <8 x i1> %80, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %86 = sdiv <8 x i64> %84, %85
  %87 = load <8 x i64>, ptr %.spill, align 64
  %88 = select <8 x i1> %80, <8 x i64> %86, <8 x i64> %87
  store <8 x i64> %88, ptr %.spill, align 64
  %89 = select <8 x i1> %80, <8 x i64> %83, <8 x i64> zeroinitializer
  %90 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %91 = sdiv <8 x i64> %89, %90
  %92 = select <8 x i1> %80, <8 x i64> %91, <8 x i64> zeroinitializer
  %93 = select <8 x i1> %80, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %94 = srem <8 x i64> %92, %93
  %95 = mul <8 x i64> %94, splat (i64 2)
  %96 = load <8 x i64>, ptr %.spill41, align 64
  %97 = select <8 x i1> %80, <8 x i64> %95, <8 x i64> %96
  store <8 x i64> %97, ptr %.spill41, align 64
  %98 = select <8 x i1> %80, <8 x i64> %86, <8 x i64> zeroinitializer
  %99 = select <8 x i1> %80, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %100 = sdiv <8 x i64> %98, %99
  %101 = load <8 x i64>, ptr %.spill42, align 64
  %102 = select <8 x i1> %80, <8 x i64> %100, <8 x i64> %101
  store <8 x i64> %102, ptr %.spill42, align 64
  %103 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %103, 0
  %106 = select <8 x i1> %80, <8 x ptr> %104, <8 x ptr> %105
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %103, 1
  %109 = select <8 x i1> %80, <8 x i64> %107, <8 x i64> %108
  %110 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %106, 0
  %111 = insertvalue { <8 x ptr>, <8 x i64> } %110, <8 x i64> %109, 1
  store { <8 x ptr>, <8 x i64> } %111, ptr %tile_snapshot.spill, align 64
  %112 = load <8 x i64>, ptr %.slot, align 64
  %113 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %112
  store <8 x i64> %113, ptr %.slot, align 64
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.4, %direct.schedule.0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %114 = icmp slt <8 x i64> %.state, splat (i64 66)
  %115 = extractelement <8 x i1> %114, i32 0
  br i1 %115, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state197 = load <8 x i64>, ptr %.slot, align 64
  %116 = select <8 x i1> %80, <8 x i64> %.state197, <8 x i64> zeroinitializer
  %117 = select <8 x i1> %80, <8 x i64> splat (i64 33), <8 x i64> splat (i64 1)
  %118 = srem <8 x i64> %116, %117
  %.state198 = load <8 x i64>, ptr %.slot, align 64
  %119 = select <8 x i1> %80, <8 x i64> %.state198, <8 x i64> zeroinitializer
  %120 = select <8 x i1> %80, <8 x i64> splat (i64 33), <8 x i64> splat (i64 1)
  %121 = sdiv <8 x i64> %119, %120
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %122 = add <8 x i64> %.spill.load, zeroinitializer
  %123 = add <8 x i64> zeroinitializer, %122
  %.spill.load199 = load <8 x i64>, ptr %.spill41, align 64
  %124 = add <8 x i64> %.spill.load199, %121
  %125 = mul <8 x i64> %123, splat (i64 3)
  %126 = add <8 x i64> %125, %124
  %127 = icmp sge <8 x i64> %124, zeroinitializer
  %128 = and <8 x i1> splat (i1 true), %127
  %129 = icmp slt <8 x i64> %124, splat (i64 3)
  %130 = and <8 x i1> %128, %129
  %131 = add <8 x i64> zeroinitializer, %118
  %132 = mul <8 x i64> %126, splat (i64 33)
  %133 = add <8 x i64> %132, %131
  %134 = and <8 x i1> %80, %130
  %135 = xor <8 x i1> %130, splat (i1 true)
  %136 = and <8 x i1> %80, %135
  %137 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %134)
  %138 = bitcast <8 x i1> %134 to i8
  %139 = call i8 @llvm.cttz.i8(i8 %138, i1 false)
  %140 = zext i8 %139 to i32
  %141 = select i1 %137, i32 %140, i32 0
  %142 = extractvalue { ptr, i64 } %38, 0
  %143 = select <8 x i1> %134, <8 x i64> %133, <8 x i64> zeroinitializer
  %144 = mul <8 x i64> %143, splat (i64 4)
  %145 = getelementptr i8, ptr %142, <8 x i64> %144
  %146 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %145, <8 x i1> %134, <8 x float> zeroinitializer)
  %147 = load <8 x float>, ptr %.slot43, align 32
  %148 = select <8 x i1> %134, <8 x float> %146, <8 x float> %147
  store <8 x float> %148, ptr %.slot43, align 32
  %149 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %136)
  %150 = bitcast <8 x i1> %136 to i8
  %151 = call i8 @llvm.cttz.i8(i8 %150, i1 false)
  %152 = zext i8 %151 to i32
  %153 = select i1 %149, i32 %152, i32 0
  %154 = load <8 x float>, ptr %.slot43, align 32
  %155 = select <8 x i1> %136, <8 x float> zeroinitializer, <8 x float> %154
  store <8 x float> %155, ptr %.slot43, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.2
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state200 = load <8 x i64>, ptr %.slot, align 64
  %158 = mul <8 x i64> %.state200, splat (i64 32)
  %159 = add <8 x i64> %157, %158
  %160 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %156, 0
  %161 = insertvalue { <8 x ptr>, <8 x i64> } %160, <8 x i64> %159, 1
  %.state201 = load <8 x float>, ptr %.slot43, align 32
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %161, 0
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %161, 1
  %164 = getelementptr i8, <8 x ptr> %162, <8 x i64> %163
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state201, <8 x ptr> align 1 %164, <8 x i1> %80)
  %.state202 = load <8 x i64>, ptr %.slot, align 64
  %165 = add <8 x i64> %.state202, splat (i64 1)
  %166 = load <8 x i64>, ptr %.slot, align 64
  %167 = select <8 x i1> %80, <8 x i64> %165, <8 x i64> %166
  store <8 x i64> %167, ptr %.slot, align 64
  br label %direct.schedule.1

direct.schedule.5:                                ; preds = %direct.false
  %168 = load <8 x i64>, ptr %.slot44, align 64
  %169 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %168
  store <8 x i64> %169, ptr %.slot44, align 64
  %170 = load <8 x float>, ptr %.slot45, align 32
  %171 = select <8 x i1> %80, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %170
  store <8 x float> %171, ptr %.slot45, align 32
  %172 = load <8 x float>, ptr %.slot46, align 32
  %173 = select <8 x i1> %80, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %172
  store <8 x float> %173, ptr %.slot46, align 32
  %174 = load <8 x float>, ptr %.slot47, align 32
  %175 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %174
  store <8 x float> %175, ptr %.slot47, align 32
  %176 = load <8 x float>, ptr %.slot48, align 32
  %177 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %176
  store <8 x float> %177, ptr %.slot48, align 32
  %178 = load <8 x float>, ptr %.slot49, align 32
  %179 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %178
  store <8 x float> %179, ptr %.slot49, align 32
  %180 = load <8 x float>, ptr %.slot50, align 32
  %181 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %180
  store <8 x float> %181, ptr %.slot50, align 32
  %182 = load <8 x float>, ptr %.slot51, align 32
  %183 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %182
  store <8 x float> %183, ptr %.slot51, align 32
  %184 = load <8 x float>, ptr %.slot52, align 32
  %185 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %184
  store <8 x float> %185, ptr %.slot52, align 32
  %186 = load <8 x float>, ptr %.slot53, align 32
  %187 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %186
  store <8 x float> %187, ptr %.slot53, align 32
  %188 = load <8 x float>, ptr %.slot54, align 32
  %189 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %188
  store <8 x float> %189, ptr %.slot54, align 32
  %190 = load <8 x float>, ptr %.slot55, align 32
  %191 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %190
  store <8 x float> %191, ptr %.slot55, align 32
  %192 = load <8 x float>, ptr %.slot56, align 32
  %193 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %192
  store <8 x float> %193, ptr %.slot56, align 32
  %194 = load <8 x float>, ptr %.slot57, align 32
  %195 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %194
  store <8 x float> %195, ptr %.slot57, align 32
  %196 = load <8 x float>, ptr %.slot58, align 32
  %197 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %196
  store <8 x float> %197, ptr %.slot58, align 32
  %198 = load <8 x float>, ptr %.slot59, align 32
  %199 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %198
  store <8 x float> %199, ptr %.slot59, align 32
  %200 = load <8 x float>, ptr %.slot60, align 32
  %201 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %200
  store <8 x float> %201, ptr %.slot60, align 32
  %202 = load <8 x float>, ptr %.slot61, align 32
  %203 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %202
  store <8 x float> %203, ptr %.slot61, align 32
  %204 = load <8 x float>, ptr %.slot62, align 32
  %205 = select <8 x i1> %80, <8 x float> zeroinitializer, <8 x float> %204
  store <8 x float> %205, ptr %.slot62, align 32
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.89, %direct.schedule.5
  %.state203 = load <8 x i64>, ptr %.slot44, align 64
  %206 = icmp slt <8 x i64> %.state203, splat (i64 2)
  %207 = extractelement <8 x i1> %206, i32 0
  br i1 %207, label %direct.true204, label %direct.false205

direct.schedule.7:                                ; preds = %direct.true204
  %.state206 = load <8 x i64>, ptr %.slot44, align 64
  %208 = select <8 x i1> %80, <8 x i64> %.state206, <8 x i64> zeroinitializer
  %209 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %210 = sdiv <8 x i64> %208, %209
  %211 = mul <8 x i64> %210, splat (i64 65)
  %212 = load <8 x i64>, ptr %.spill63, align 64
  %213 = select <8 x i1> %80, <8 x i64> %211, <8 x i64> %212
  store <8 x i64> %213, ptr %.spill63, align 64
  %214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %215 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %214, 0
  %217 = select <8 x i1> %80, <8 x ptr> %215, <8 x ptr> %216
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %219 = extractvalue { <8 x ptr>, <8 x i64> } %214, 1
  %220 = select <8 x i1> %80, <8 x i64> %218, <8 x i64> %219
  %221 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %222 = insertvalue { <8 x ptr>, <8 x i64> } %221, <8 x i64> %220, 1
  store { <8 x ptr>, <8 x i64> } %222, ptr %tile_snapshot.spill64, align 64
  %223 = load <8 x i64>, ptr %.slot65, align 64
  %224 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %223
  store <8 x i64> %224, ptr %.slot65, align 64
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.11, %direct.schedule.7
  %.state207 = load <8 x i64>, ptr %.slot65, align 64
  %225 = icmp slt <8 x i64> %.state207, splat (i64 2145)
  %226 = extractelement <8 x i1> %225, i32 0
  br i1 %226, label %direct.true208, label %direct.false209

direct.schedule.9:                                ; preds = %direct.true208
  %.state210 = load <8 x i64>, ptr %.slot65, align 64
  %227 = select <8 x i1> %80, <8 x i64> %.state210, <8 x i64> zeroinitializer
  %228 = select <8 x i1> %80, <8 x i64> splat (i64 33), <8 x i64> splat (i64 1)
  %229 = srem <8 x i64> %227, %228
  %.state211 = load <8 x i64>, ptr %.slot65, align 64
  %230 = select <8 x i1> %80, <8 x i64> %.state211, <8 x i64> zeroinitializer
  %231 = select <8 x i1> %80, <8 x i64> splat (i64 33), <8 x i64> splat (i64 1)
  %232 = sdiv <8 x i64> %230, %231
  %.spill.load212 = load <8 x i64>, ptr %.spill42, align 64
  %233 = add <8 x i64> %.spill.load212, zeroinitializer
  %234 = add <8 x i64> zeroinitializer, %233
  %.spill.load213 = load <8 x i64>, ptr %.spill63, align 64
  %235 = add <8 x i64> %.spill.load213, %232
  %236 = mul <8 x i64> %234, splat (i64 67)
  %237 = add <8 x i64> %236, %235
  %238 = icmp sge <8 x i64> %235, zeroinitializer
  %239 = and <8 x i1> splat (i1 true), %238
  %240 = icmp slt <8 x i64> %235, splat (i64 67)
  %241 = and <8 x i1> %239, %240
  %242 = add <8 x i64> zeroinitializer, %229
  %243 = mul <8 x i64> %237, splat (i64 33)
  %244 = add <8 x i64> %243, %242
  %245 = and <8 x i1> %80, %241
  %246 = xor <8 x i1> %241, splat (i1 true)
  %247 = and <8 x i1> %80, %246
  %248 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %245)
  %249 = bitcast <8 x i1> %245 to i8
  %250 = call i8 @llvm.cttz.i8(i8 %249, i1 false)
  %251 = zext i8 %250 to i32
  %252 = select i1 %248, i32 %251, i32 0
  %253 = extractvalue { ptr, i64 } %44, 0
  %254 = select <8 x i1> %245, <8 x i64> %244, <8 x i64> zeroinitializer
  %255 = mul <8 x i64> %254, splat (i64 4)
  %256 = getelementptr i8, ptr %253, <8 x i64> %255
  %257 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %256, <8 x i1> %245, <8 x float> zeroinitializer)
  %258 = load <8 x float>, ptr %.slot66, align 32
  %259 = select <8 x i1> %245, <8 x float> %257, <8 x float> %258
  store <8 x float> %259, ptr %.slot66, align 32
  %260 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %247)
  %261 = bitcast <8 x i1> %247 to i8
  %262 = call i8 @llvm.cttz.i8(i8 %261, i1 false)
  %263 = zext i8 %262 to i32
  %264 = select i1 %260, i32 %263, i32 0
  %265 = load <8 x float>, ptr %.slot66, align 32
  %266 = select <8 x i1> %247, <8 x float> zeroinitializer, <8 x float> %265
  store <8 x float> %266, ptr %.slot66, align 32
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.9
  %tile_snapshot.spill.load214 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 0
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load214, 1
  %.state215 = load <8 x i64>, ptr %.slot65, align 64
  %269 = mul <8 x i64> %.state215, splat (i64 32)
  %270 = add <8 x i64> %268, %269
  %271 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %267, 0
  %272 = insertvalue { <8 x ptr>, <8 x i64> } %271, <8 x i64> %270, 1
  %.state216 = load <8 x float>, ptr %.slot66, align 32
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %272, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %272, 1
  %275 = getelementptr i8, <8 x ptr> %273, <8 x i64> %274
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state216, <8 x ptr> align 1 %275, <8 x i1> %80)
  %.state217 = load <8 x i64>, ptr %.slot65, align 64
  %276 = add <8 x i64> %.state217, splat (i64 1)
  %277 = load <8 x i64>, ptr %.slot65, align 64
  %278 = select <8 x i1> %80, <8 x i64> %276, <8 x i64> %277
  store <8 x i64> %278, ptr %.slot65, align 64
  br label %direct.schedule.8

direct.schedule.12:                               ; preds = %direct.false209
  %279 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %279, 0
  %282 = select <8 x i1> %80, <8 x ptr> %280, <8 x ptr> %281
  %283 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %284 = extractvalue { <8 x ptr>, <8 x i64> } %279, 1
  %285 = select <8 x i1> %80, <8 x i64> %283, <8 x i64> %284
  %286 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %282, 0
  %287 = insertvalue { <8 x ptr>, <8 x i64> } %286, <8 x i64> %285, 1
  store { <8 x ptr>, <8 x i64> } %287, ptr %tile_snapshot.spill67, align 64
  %288 = load <8 x i64>, ptr %.slot68, align 64
  %289 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %288
  store <8 x i64> %289, ptr %.slot68, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.16, %direct.schedule.12
  %.state218 = load <8 x i64>, ptr %.slot68, align 64
  %290 = icmp slt <8 x i64> %.state218, splat (i64 455)
  %291 = extractelement <8 x i1> %290, i32 0
  br i1 %291, label %direct.true219, label %direct.false220

direct.schedule.14:                               ; preds = %direct.true219
  %.state221 = load <8 x i64>, ptr %.slot68, align 64
  %292 = select <8 x i1> %80, <8 x i64> %.state221, <8 x i64> zeroinitializer
  %293 = select <8 x i1> %80, <8 x i64> splat (i64 7), <8 x i64> splat (i64 1)
  %294 = srem <8 x i64> %292, %293
  %.state222 = load <8 x i64>, ptr %.slot68, align 64
  %295 = select <8 x i1> %80, <8 x i64> %.state222, <8 x i64> zeroinitializer
  %296 = select <8 x i1> %80, <8 x i64> splat (i64 7), <8 x i64> splat (i64 1)
  %297 = sdiv <8 x i64> %295, %296
  %.spill.load223 = load <8 x i64>, ptr %.spill42, align 64
  %298 = add <8 x i64> %.spill.load223, zeroinitializer
  %299 = add <8 x i64> zeroinitializer, %298
  %.spill.load224 = load <8 x i64>, ptr %.spill63, align 64
  %300 = add <8 x i64> %.spill.load224, %297
  %301 = mul <8 x i64> %299, splat (i64 67)
  %302 = add <8 x i64> %301, %300
  %303 = icmp sge <8 x i64> %300, zeroinitializer
  %304 = and <8 x i1> splat (i1 true), %303
  %305 = icmp slt <8 x i64> %300, splat (i64 67)
  %306 = and <8 x i1> %304, %305
  %307 = add <8 x i64> zeroinitializer, %294
  %308 = mul <8 x i64> %302, splat (i64 7)
  %309 = add <8 x i64> %308, %307
  %310 = and <8 x i1> %80, %306
  %311 = xor <8 x i1> %306, splat (i1 true)
  %312 = and <8 x i1> %80, %311
  %313 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %310)
  %314 = bitcast <8 x i1> %310 to i8
  %315 = call i8 @llvm.cttz.i8(i8 %314, i1 false)
  %316 = zext i8 %315 to i32
  %317 = select i1 %313, i32 %316, i32 0
  %318 = extractvalue { ptr, i64 } %50, 0
  %319 = select <8 x i1> %310, <8 x i64> %309, <8 x i64> zeroinitializer
  %320 = mul <8 x i64> %319, splat (i64 4)
  %321 = getelementptr i8, ptr %318, <8 x i64> %320
  %322 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %321, <8 x i1> %310, <8 x float> zeroinitializer)
  %323 = load <8 x float>, ptr %.slot69, align 32
  %324 = select <8 x i1> %310, <8 x float> %322, <8 x float> %323
  store <8 x float> %324, ptr %.slot69, align 32
  %325 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %312)
  %326 = bitcast <8 x i1> %312 to i8
  %327 = call i8 @llvm.cttz.i8(i8 %326, i1 false)
  %328 = zext i8 %327 to i32
  %329 = select i1 %325, i32 %328, i32 0
  %330 = load <8 x float>, ptr %.slot69, align 32
  %331 = select <8 x i1> %312, <8 x float> zeroinitializer, <8 x float> %330
  store <8 x float> %331, ptr %.slot69, align 32
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.14
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %333 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.state226 = load <8 x i64>, ptr %.slot68, align 64
  %334 = mul <8 x i64> %.state226, splat (i64 32)
  %335 = add <8 x i64> %333, %334
  %336 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %332, 0
  %337 = insertvalue { <8 x ptr>, <8 x i64> } %336, <8 x i64> %335, 1
  %.state227 = load <8 x float>, ptr %.slot69, align 32
  %338 = extractvalue { <8 x ptr>, <8 x i64> } %337, 0
  %339 = extractvalue { <8 x ptr>, <8 x i64> } %337, 1
  %340 = getelementptr i8, <8 x ptr> %338, <8 x i64> %339
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state227, <8 x ptr> align 1 %340, <8 x i1> %80)
  %.state228 = load <8 x i64>, ptr %.slot68, align 64
  %341 = add <8 x i64> %.state228, splat (i64 1)
  %342 = load <8 x i64>, ptr %.slot68, align 64
  %343 = select <8 x i1> %80, <8 x i64> %341, <8 x i64> %342
  store <8 x i64> %343, ptr %.slot68, align 64
  br label %direct.schedule.13

direct.schedule.17:                               ; preds = %direct.false220
  %344 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill70, align 64
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %344, 0
  %347 = select <8 x i1> %80, <8 x ptr> %345, <8 x ptr> %346
  %348 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %349 = extractvalue { <8 x ptr>, <8 x i64> } %344, 1
  %350 = select <8 x i1> %80, <8 x i64> %348, <8 x i64> %349
  %351 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %347, 0
  %352 = insertvalue { <8 x ptr>, <8 x i64> } %351, <8 x i64> %350, 1
  store { <8 x ptr>, <8 x i64> } %352, ptr %tile_snapshot.spill70, align 64
  %353 = load <8 x i64>, ptr %.slot71, align 64
  %354 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %353
  store <8 x i64> %354, ptr %.slot71, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.19, %direct.schedule.17
  %.state229 = load <8 x i64>, ptr %.slot71, align 64
  %355 = icmp slt <8 x i64> %.state229, splat (i64 130)
  %356 = extractelement <8 x i1> %355, i32 0
  br i1 %356, label %direct.true230, label %direct.false231

direct.schedule.19:                               ; preds = %direct.true230
  %.state232 = load <8 x i64>, ptr %.slot71, align 64
  %357 = select <8 x i1> %80, <8 x i64> %.state232, <8 x i64> zeroinitializer
  %358 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %359 = srem <8 x i64> %357, %358
  %.state233 = load <8 x i64>, ptr %.slot71, align 64
  %360 = select <8 x i1> %80, <8 x i64> %.state233, <8 x i64> zeroinitializer
  %361 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %362 = sdiv <8 x i64> %360, %361
  %363 = add <8 x i64> zeroinitializer, %362
  %364 = mul <8 x i64> %363, splat (i64 33)
  %365 = add <8 x i64> %364, zeroinitializer
  %tile_snapshot.spill.load234 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load234, 1
  %368 = mul <8 x i64> %365, splat (i64 32)
  %369 = add <8 x i64> %367, %368
  %370 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %366, 0
  %371 = insertvalue { <8 x ptr>, <8 x i64> } %370, <8 x i64> %369, 1
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %371, 0
  %373 = extractvalue { <8 x ptr>, <8 x i64> } %371, 1
  %374 = getelementptr i8, <8 x ptr> %372, <8 x i64> %373
  %375 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %374, <8 x i1> %80, <8 x float> zeroinitializer)
  %376 = add <8 x i64> zeroinitializer, %359
  %377 = mul <8 x i64> %376, splat (i64 33)
  %378 = add <8 x i64> %377, zeroinitializer
  %tile_snapshot.spill.load235 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 1
  %381 = mul <8 x i64> %378, splat (i64 32)
  %382 = add <8 x i64> %380, %381
  %383 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %379, 0
  %384 = insertvalue { <8 x ptr>, <8 x i64> } %383, <8 x i64> %382, 1
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %384, 0
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %384, 1
  %387 = getelementptr i8, <8 x ptr> %385, <8 x i64> %386
  %388 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %387, <8 x i1> %80, <8 x float> zeroinitializer)
  %389 = fmul <8 x float> %375, %388
  %390 = fadd <8 x float> zeroinitializer, %389
  %391 = add <8 x i64> %364, splat (i64 1)
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %394 = mul <8 x i64> %391, splat (i64 32)
  %395 = add <8 x i64> %393, %394
  %396 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %392, 0
  %397 = insertvalue { <8 x ptr>, <8 x i64> } %396, <8 x i64> %395, 1
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %397, 0
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %397, 1
  %400 = getelementptr i8, <8 x ptr> %398, <8 x i64> %399
  %401 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %400, <8 x i1> %80, <8 x float> zeroinitializer)
  %402 = add <8 x i64> %377, splat (i64 1)
  %tile_snapshot.spill.load237 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %403 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 0
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load237, 1
  %405 = mul <8 x i64> %402, splat (i64 32)
  %406 = add <8 x i64> %404, %405
  %407 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %403, 0
  %408 = insertvalue { <8 x ptr>, <8 x i64> } %407, <8 x i64> %406, 1
  %409 = extractvalue { <8 x ptr>, <8 x i64> } %408, 0
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %408, 1
  %411 = getelementptr i8, <8 x ptr> %409, <8 x i64> %410
  %412 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %411, <8 x i1> %80, <8 x float> zeroinitializer)
  %413 = fmul <8 x float> %401, %412
  %414 = fadd <8 x float> %390, %413
  %415 = add <8 x i64> %364, splat (i64 2)
  %tile_snapshot.spill.load238 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load238, 0
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load238, 1
  %418 = mul <8 x i64> %415, splat (i64 32)
  %419 = add <8 x i64> %417, %418
  %420 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %416, 0
  %421 = insertvalue { <8 x ptr>, <8 x i64> } %420, <8 x i64> %419, 1
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %421, 0
  %423 = extractvalue { <8 x ptr>, <8 x i64> } %421, 1
  %424 = getelementptr i8, <8 x ptr> %422, <8 x i64> %423
  %425 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %424, <8 x i1> %80, <8 x float> zeroinitializer)
  %426 = add <8 x i64> %377, splat (i64 2)
  %tile_snapshot.spill.load239 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load239, 1
  %429 = mul <8 x i64> %426, splat (i64 32)
  %430 = add <8 x i64> %428, %429
  %431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %427, 0
  %432 = insertvalue { <8 x ptr>, <8 x i64> } %431, <8 x i64> %430, 1
  %433 = extractvalue { <8 x ptr>, <8 x i64> } %432, 0
  %434 = extractvalue { <8 x ptr>, <8 x i64> } %432, 1
  %435 = getelementptr i8, <8 x ptr> %433, <8 x i64> %434
  %436 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %435, <8 x i1> %80, <8 x float> zeroinitializer)
  %437 = fmul <8 x float> %425, %436
  %438 = fadd <8 x float> %414, %437
  %439 = add <8 x i64> %364, splat (i64 3)
  %tile_snapshot.spill.load240 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 0
  %441 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load240, 1
  %442 = mul <8 x i64> %439, splat (i64 32)
  %443 = add <8 x i64> %441, %442
  %444 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %440, 0
  %445 = insertvalue { <8 x ptr>, <8 x i64> } %444, <8 x i64> %443, 1
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %445, 0
  %447 = extractvalue { <8 x ptr>, <8 x i64> } %445, 1
  %448 = getelementptr i8, <8 x ptr> %446, <8 x i64> %447
  %449 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %448, <8 x i1> %80, <8 x float> zeroinitializer)
  %450 = add <8 x i64> %377, splat (i64 3)
  %tile_snapshot.spill.load241 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load241, 1
  %453 = mul <8 x i64> %450, splat (i64 32)
  %454 = add <8 x i64> %452, %453
  %455 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %451, 0
  %456 = insertvalue { <8 x ptr>, <8 x i64> } %455, <8 x i64> %454, 1
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %456, 0
  %458 = extractvalue { <8 x ptr>, <8 x i64> } %456, 1
  %459 = getelementptr i8, <8 x ptr> %457, <8 x i64> %458
  %460 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %459, <8 x i1> %80, <8 x float> zeroinitializer)
  %461 = fmul <8 x float> %449, %460
  %462 = fadd <8 x float> %438, %461
  %463 = add <8 x i64> %364, splat (i64 4)
  %tile_snapshot.spill.load242 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 0
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load242, 1
  %466 = mul <8 x i64> %463, splat (i64 32)
  %467 = add <8 x i64> %465, %466
  %468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %469 = insertvalue { <8 x ptr>, <8 x i64> } %468, <8 x i64> %467, 1
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %469, 0
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %469, 1
  %472 = getelementptr i8, <8 x ptr> %470, <8 x i64> %471
  %473 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %472, <8 x i1> %80, <8 x float> zeroinitializer)
  %474 = add <8 x i64> %377, splat (i64 4)
  %tile_snapshot.spill.load243 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 1
  %477 = mul <8 x i64> %474, splat (i64 32)
  %478 = add <8 x i64> %476, %477
  %479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %475, 0
  %480 = insertvalue { <8 x ptr>, <8 x i64> } %479, <8 x i64> %478, 1
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %480, 0
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %480, 1
  %483 = getelementptr i8, <8 x ptr> %481, <8 x i64> %482
  %484 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %483, <8 x i1> %80, <8 x float> zeroinitializer)
  %485 = fmul <8 x float> %473, %484
  %486 = fadd <8 x float> %462, %485
  %487 = add <8 x i64> %364, splat (i64 5)
  %tile_snapshot.spill.load244 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 0
  %489 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load244, 1
  %490 = mul <8 x i64> %487, splat (i64 32)
  %491 = add <8 x i64> %489, %490
  %492 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %488, 0
  %493 = insertvalue { <8 x ptr>, <8 x i64> } %492, <8 x i64> %491, 1
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %493, 0
  %495 = extractvalue { <8 x ptr>, <8 x i64> } %493, 1
  %496 = getelementptr i8, <8 x ptr> %494, <8 x i64> %495
  %497 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %496, <8 x i1> %80, <8 x float> zeroinitializer)
  %498 = add <8 x i64> %377, splat (i64 5)
  %tile_snapshot.spill.load245 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load245, 1
  %501 = mul <8 x i64> %498, splat (i64 32)
  %502 = add <8 x i64> %500, %501
  %503 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %499, 0
  %504 = insertvalue { <8 x ptr>, <8 x i64> } %503, <8 x i64> %502, 1
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %504, 0
  %506 = extractvalue { <8 x ptr>, <8 x i64> } %504, 1
  %507 = getelementptr i8, <8 x ptr> %505, <8 x i64> %506
  %508 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %507, <8 x i1> %80, <8 x float> zeroinitializer)
  %509 = fmul <8 x float> %497, %508
  %510 = fadd <8 x float> %486, %509
  %511 = add <8 x i64> %364, splat (i64 6)
  %tile_snapshot.spill.load246 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load246, 0
  %513 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load246, 1
  %514 = mul <8 x i64> %511, splat (i64 32)
  %515 = add <8 x i64> %513, %514
  %516 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %512, 0
  %517 = insertvalue { <8 x ptr>, <8 x i64> } %516, <8 x i64> %515, 1
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %517, 0
  %519 = extractvalue { <8 x ptr>, <8 x i64> } %517, 1
  %520 = getelementptr i8, <8 x ptr> %518, <8 x i64> %519
  %521 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %520, <8 x i1> %80, <8 x float> zeroinitializer)
  %522 = add <8 x i64> %377, splat (i64 6)
  %tile_snapshot.spill.load247 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 0
  %524 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load247, 1
  %525 = mul <8 x i64> %522, splat (i64 32)
  %526 = add <8 x i64> %524, %525
  %527 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %523, 0
  %528 = insertvalue { <8 x ptr>, <8 x i64> } %527, <8 x i64> %526, 1
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %528, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %528, 1
  %531 = getelementptr i8, <8 x ptr> %529, <8 x i64> %530
  %532 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %531, <8 x i1> %80, <8 x float> zeroinitializer)
  %533 = fmul <8 x float> %521, %532
  %534 = fadd <8 x float> %510, %533
  %535 = add <8 x i64> %364, splat (i64 7)
  %tile_snapshot.spill.load248 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 0
  %537 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load248, 1
  %538 = mul <8 x i64> %535, splat (i64 32)
  %539 = add <8 x i64> %537, %538
  %540 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %536, 0
  %541 = insertvalue { <8 x ptr>, <8 x i64> } %540, <8 x i64> %539, 1
  %542 = extractvalue { <8 x ptr>, <8 x i64> } %541, 0
  %543 = extractvalue { <8 x ptr>, <8 x i64> } %541, 1
  %544 = getelementptr i8, <8 x ptr> %542, <8 x i64> %543
  %545 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %544, <8 x i1> %80, <8 x float> zeroinitializer)
  %546 = add <8 x i64> %377, splat (i64 7)
  %tile_snapshot.spill.load249 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load249, 1
  %549 = mul <8 x i64> %546, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %552, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = getelementptr i8, <8 x ptr> %553, <8 x i64> %554
  %556 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %555, <8 x i1> %80, <8 x float> zeroinitializer)
  %557 = fmul <8 x float> %545, %556
  %558 = fadd <8 x float> %534, %557
  %559 = add <8 x i64> %364, splat (i64 8)
  %tile_snapshot.spill.load250 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 0
  %561 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load250, 1
  %562 = mul <8 x i64> %559, splat (i64 32)
  %563 = add <8 x i64> %561, %562
  %564 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %560, 0
  %565 = insertvalue { <8 x ptr>, <8 x i64> } %564, <8 x i64> %563, 1
  %566 = extractvalue { <8 x ptr>, <8 x i64> } %565, 0
  %567 = extractvalue { <8 x ptr>, <8 x i64> } %565, 1
  %568 = getelementptr i8, <8 x ptr> %566, <8 x i64> %567
  %569 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %568, <8 x i1> %80, <8 x float> zeroinitializer)
  %570 = add <8 x i64> %377, splat (i64 8)
  %tile_snapshot.spill.load251 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %571 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 0
  %572 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load251, 1
  %573 = mul <8 x i64> %570, splat (i64 32)
  %574 = add <8 x i64> %572, %573
  %575 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %571, 0
  %576 = insertvalue { <8 x ptr>, <8 x i64> } %575, <8 x i64> %574, 1
  %577 = extractvalue { <8 x ptr>, <8 x i64> } %576, 0
  %578 = extractvalue { <8 x ptr>, <8 x i64> } %576, 1
  %579 = getelementptr i8, <8 x ptr> %577, <8 x i64> %578
  %580 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %579, <8 x i1> %80, <8 x float> zeroinitializer)
  %581 = fmul <8 x float> %569, %580
  %582 = fadd <8 x float> %558, %581
  %583 = add <8 x i64> %364, splat (i64 9)
  %tile_snapshot.spill.load252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 1
  %586 = mul <8 x i64> %583, splat (i64 32)
  %587 = add <8 x i64> %585, %586
  %588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %589 = insertvalue { <8 x ptr>, <8 x i64> } %588, <8 x i64> %587, 1
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %589, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %589, 1
  %592 = getelementptr i8, <8 x ptr> %590, <8 x i64> %591
  %593 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %592, <8 x i1> %80, <8 x float> zeroinitializer)
  %594 = add <8 x i64> %377, splat (i64 9)
  %tile_snapshot.spill.load253 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %595 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 0
  %596 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load253, 1
  %597 = mul <8 x i64> %594, splat (i64 32)
  %598 = add <8 x i64> %596, %597
  %599 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %595, 0
  %600 = insertvalue { <8 x ptr>, <8 x i64> } %599, <8 x i64> %598, 1
  %601 = extractvalue { <8 x ptr>, <8 x i64> } %600, 0
  %602 = extractvalue { <8 x ptr>, <8 x i64> } %600, 1
  %603 = getelementptr i8, <8 x ptr> %601, <8 x i64> %602
  %604 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %603, <8 x i1> %80, <8 x float> zeroinitializer)
  %605 = fmul <8 x float> %593, %604
  %606 = fadd <8 x float> %582, %605
  %607 = add <8 x i64> %364, splat (i64 10)
  %tile_snapshot.spill.load254 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %608 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 0
  %609 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load254, 1
  %610 = mul <8 x i64> %607, splat (i64 32)
  %611 = add <8 x i64> %609, %610
  %612 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %608, 0
  %613 = insertvalue { <8 x ptr>, <8 x i64> } %612, <8 x i64> %611, 1
  %614 = extractvalue { <8 x ptr>, <8 x i64> } %613, 0
  %615 = extractvalue { <8 x ptr>, <8 x i64> } %613, 1
  %616 = getelementptr i8, <8 x ptr> %614, <8 x i64> %615
  %617 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %616, <8 x i1> %80, <8 x float> zeroinitializer)
  %618 = add <8 x i64> %377, splat (i64 10)
  %tile_snapshot.spill.load255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 0
  %620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load255, 1
  %621 = mul <8 x i64> %618, splat (i64 32)
  %622 = add <8 x i64> %620, %621
  %623 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %619, 0
  %624 = insertvalue { <8 x ptr>, <8 x i64> } %623, <8 x i64> %622, 1
  %625 = extractvalue { <8 x ptr>, <8 x i64> } %624, 0
  %626 = extractvalue { <8 x ptr>, <8 x i64> } %624, 1
  %627 = getelementptr i8, <8 x ptr> %625, <8 x i64> %626
  %628 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %627, <8 x i1> %80, <8 x float> zeroinitializer)
  %629 = fmul <8 x float> %617, %628
  %630 = fadd <8 x float> %606, %629
  %631 = add <8 x i64> %364, splat (i64 11)
  %tile_snapshot.spill.load256 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %632 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 0
  %633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load256, 1
  %634 = mul <8 x i64> %631, splat (i64 32)
  %635 = add <8 x i64> %633, %634
  %636 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %632, 0
  %637 = insertvalue { <8 x ptr>, <8 x i64> } %636, <8 x i64> %635, 1
  %638 = extractvalue { <8 x ptr>, <8 x i64> } %637, 0
  %639 = extractvalue { <8 x ptr>, <8 x i64> } %637, 1
  %640 = getelementptr i8, <8 x ptr> %638, <8 x i64> %639
  %641 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %640, <8 x i1> %80, <8 x float> zeroinitializer)
  %642 = add <8 x i64> %377, splat (i64 11)
  %tile_snapshot.spill.load257 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %643 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 0
  %644 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load257, 1
  %645 = mul <8 x i64> %642, splat (i64 32)
  %646 = add <8 x i64> %644, %645
  %647 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %643, 0
  %648 = insertvalue { <8 x ptr>, <8 x i64> } %647, <8 x i64> %646, 1
  %649 = extractvalue { <8 x ptr>, <8 x i64> } %648, 0
  %650 = extractvalue { <8 x ptr>, <8 x i64> } %648, 1
  %651 = getelementptr i8, <8 x ptr> %649, <8 x i64> %650
  %652 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %651, <8 x i1> %80, <8 x float> zeroinitializer)
  %653 = fmul <8 x float> %641, %652
  %654 = fadd <8 x float> %630, %653
  %655 = add <8 x i64> %364, splat (i64 12)
  %tile_snapshot.spill.load258 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %656 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 0
  %657 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load258, 1
  %658 = mul <8 x i64> %655, splat (i64 32)
  %659 = add <8 x i64> %657, %658
  %660 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %656, 0
  %661 = insertvalue { <8 x ptr>, <8 x i64> } %660, <8 x i64> %659, 1
  %662 = extractvalue { <8 x ptr>, <8 x i64> } %661, 0
  %663 = extractvalue { <8 x ptr>, <8 x i64> } %661, 1
  %664 = getelementptr i8, <8 x ptr> %662, <8 x i64> %663
  %665 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %664, <8 x i1> %80, <8 x float> zeroinitializer)
  %666 = add <8 x i64> %377, splat (i64 12)
  %tile_snapshot.spill.load259 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %667 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 0
  %668 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load259, 1
  %669 = mul <8 x i64> %666, splat (i64 32)
  %670 = add <8 x i64> %668, %669
  %671 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %667, 0
  %672 = insertvalue { <8 x ptr>, <8 x i64> } %671, <8 x i64> %670, 1
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %672, 0
  %674 = extractvalue { <8 x ptr>, <8 x i64> } %672, 1
  %675 = getelementptr i8, <8 x ptr> %673, <8 x i64> %674
  %676 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %675, <8 x i1> %80, <8 x float> zeroinitializer)
  %677 = fmul <8 x float> %665, %676
  %678 = fadd <8 x float> %654, %677
  %679 = add <8 x i64> %364, splat (i64 13)
  %tile_snapshot.spill.load260 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %680 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load260, 0
  %681 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load260, 1
  %682 = mul <8 x i64> %679, splat (i64 32)
  %683 = add <8 x i64> %681, %682
  %684 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %680, 0
  %685 = insertvalue { <8 x ptr>, <8 x i64> } %684, <8 x i64> %683, 1
  %686 = extractvalue { <8 x ptr>, <8 x i64> } %685, 0
  %687 = extractvalue { <8 x ptr>, <8 x i64> } %685, 1
  %688 = getelementptr i8, <8 x ptr> %686, <8 x i64> %687
  %689 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %688, <8 x i1> %80, <8 x float> zeroinitializer)
  %690 = add <8 x i64> %377, splat (i64 13)
  %tile_snapshot.spill.load261 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %691 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load261, 0
  %692 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load261, 1
  %693 = mul <8 x i64> %690, splat (i64 32)
  %694 = add <8 x i64> %692, %693
  %695 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %691, 0
  %696 = insertvalue { <8 x ptr>, <8 x i64> } %695, <8 x i64> %694, 1
  %697 = extractvalue { <8 x ptr>, <8 x i64> } %696, 0
  %698 = extractvalue { <8 x ptr>, <8 x i64> } %696, 1
  %699 = getelementptr i8, <8 x ptr> %697, <8 x i64> %698
  %700 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %699, <8 x i1> %80, <8 x float> zeroinitializer)
  %701 = fmul <8 x float> %689, %700
  %702 = fadd <8 x float> %678, %701
  %703 = add <8 x i64> %364, splat (i64 14)
  %tile_snapshot.spill.load262 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %704 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load262, 0
  %705 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load262, 1
  %706 = mul <8 x i64> %703, splat (i64 32)
  %707 = add <8 x i64> %705, %706
  %708 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %704, 0
  %709 = insertvalue { <8 x ptr>, <8 x i64> } %708, <8 x i64> %707, 1
  %710 = extractvalue { <8 x ptr>, <8 x i64> } %709, 0
  %711 = extractvalue { <8 x ptr>, <8 x i64> } %709, 1
  %712 = getelementptr i8, <8 x ptr> %710, <8 x i64> %711
  %713 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %712, <8 x i1> %80, <8 x float> zeroinitializer)
  %714 = add <8 x i64> %377, splat (i64 14)
  %tile_snapshot.spill.load263 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %715 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load263, 0
  %716 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load263, 1
  %717 = mul <8 x i64> %714, splat (i64 32)
  %718 = add <8 x i64> %716, %717
  %719 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %715, 0
  %720 = insertvalue { <8 x ptr>, <8 x i64> } %719, <8 x i64> %718, 1
  %721 = extractvalue { <8 x ptr>, <8 x i64> } %720, 0
  %722 = extractvalue { <8 x ptr>, <8 x i64> } %720, 1
  %723 = getelementptr i8, <8 x ptr> %721, <8 x i64> %722
  %724 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %723, <8 x i1> %80, <8 x float> zeroinitializer)
  %725 = fmul <8 x float> %713, %724
  %726 = fadd <8 x float> %702, %725
  %727 = add <8 x i64> %364, splat (i64 15)
  %tile_snapshot.spill.load264 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %728 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 0
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load264, 1
  %730 = mul <8 x i64> %727, splat (i64 32)
  %731 = add <8 x i64> %729, %730
  %732 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %728, 0
  %733 = insertvalue { <8 x ptr>, <8 x i64> } %732, <8 x i64> %731, 1
  %734 = extractvalue { <8 x ptr>, <8 x i64> } %733, 0
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %733, 1
  %736 = getelementptr i8, <8 x ptr> %734, <8 x i64> %735
  %737 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %736, <8 x i1> %80, <8 x float> zeroinitializer)
  %738 = add <8 x i64> %377, splat (i64 15)
  %tile_snapshot.spill.load265 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %739 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 0
  %740 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load265, 1
  %741 = mul <8 x i64> %738, splat (i64 32)
  %742 = add <8 x i64> %740, %741
  %743 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %739, 0
  %744 = insertvalue { <8 x ptr>, <8 x i64> } %743, <8 x i64> %742, 1
  %745 = extractvalue { <8 x ptr>, <8 x i64> } %744, 0
  %746 = extractvalue { <8 x ptr>, <8 x i64> } %744, 1
  %747 = getelementptr i8, <8 x ptr> %745, <8 x i64> %746
  %748 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %747, <8 x i1> %80, <8 x float> zeroinitializer)
  %749 = fmul <8 x float> %737, %748
  %750 = fadd <8 x float> %726, %749
  %751 = add <8 x i64> %364, splat (i64 16)
  %tile_snapshot.spill.load266 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %752 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 0
  %753 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load266, 1
  %754 = mul <8 x i64> %751, splat (i64 32)
  %755 = add <8 x i64> %753, %754
  %756 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %752, 0
  %757 = insertvalue { <8 x ptr>, <8 x i64> } %756, <8 x i64> %755, 1
  %758 = extractvalue { <8 x ptr>, <8 x i64> } %757, 0
  %759 = extractvalue { <8 x ptr>, <8 x i64> } %757, 1
  %760 = getelementptr i8, <8 x ptr> %758, <8 x i64> %759
  %761 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %760, <8 x i1> %80, <8 x float> zeroinitializer)
  %762 = add <8 x i64> %377, splat (i64 16)
  %tile_snapshot.spill.load267 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %763 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 0
  %764 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load267, 1
  %765 = mul <8 x i64> %762, splat (i64 32)
  %766 = add <8 x i64> %764, %765
  %767 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %763, 0
  %768 = insertvalue { <8 x ptr>, <8 x i64> } %767, <8 x i64> %766, 1
  %769 = extractvalue { <8 x ptr>, <8 x i64> } %768, 0
  %770 = extractvalue { <8 x ptr>, <8 x i64> } %768, 1
  %771 = getelementptr i8, <8 x ptr> %769, <8 x i64> %770
  %772 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %771, <8 x i1> %80, <8 x float> zeroinitializer)
  %773 = fmul <8 x float> %761, %772
  %774 = fadd <8 x float> %750, %773
  %775 = add <8 x i64> %364, splat (i64 17)
  %tile_snapshot.spill.load268 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 0
  %777 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load268, 1
  %778 = mul <8 x i64> %775, splat (i64 32)
  %779 = add <8 x i64> %777, %778
  %780 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %776, 0
  %781 = insertvalue { <8 x ptr>, <8 x i64> } %780, <8 x i64> %779, 1
  %782 = extractvalue { <8 x ptr>, <8 x i64> } %781, 0
  %783 = extractvalue { <8 x ptr>, <8 x i64> } %781, 1
  %784 = getelementptr i8, <8 x ptr> %782, <8 x i64> %783
  %785 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %784, <8 x i1> %80, <8 x float> zeroinitializer)
  %786 = add <8 x i64> %377, splat (i64 17)
  %tile_snapshot.spill.load269 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %787 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 0
  %788 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load269, 1
  %789 = mul <8 x i64> %786, splat (i64 32)
  %790 = add <8 x i64> %788, %789
  %791 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %787, 0
  %792 = insertvalue { <8 x ptr>, <8 x i64> } %791, <8 x i64> %790, 1
  %793 = extractvalue { <8 x ptr>, <8 x i64> } %792, 0
  %794 = extractvalue { <8 x ptr>, <8 x i64> } %792, 1
  %795 = getelementptr i8, <8 x ptr> %793, <8 x i64> %794
  %796 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %795, <8 x i1> %80, <8 x float> zeroinitializer)
  %797 = fmul <8 x float> %785, %796
  %798 = fadd <8 x float> %774, %797
  %799 = add <8 x i64> %364, splat (i64 18)
  %tile_snapshot.spill.load270 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %800 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 0
  %801 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load270, 1
  %802 = mul <8 x i64> %799, splat (i64 32)
  %803 = add <8 x i64> %801, %802
  %804 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %800, 0
  %805 = insertvalue { <8 x ptr>, <8 x i64> } %804, <8 x i64> %803, 1
  %806 = extractvalue { <8 x ptr>, <8 x i64> } %805, 0
  %807 = extractvalue { <8 x ptr>, <8 x i64> } %805, 1
  %808 = getelementptr i8, <8 x ptr> %806, <8 x i64> %807
  %809 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %808, <8 x i1> %80, <8 x float> zeroinitializer)
  %810 = add <8 x i64> %377, splat (i64 18)
  %tile_snapshot.spill.load271 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 0
  %812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load271, 1
  %813 = mul <8 x i64> %810, splat (i64 32)
  %814 = add <8 x i64> %812, %813
  %815 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %811, 0
  %816 = insertvalue { <8 x ptr>, <8 x i64> } %815, <8 x i64> %814, 1
  %817 = extractvalue { <8 x ptr>, <8 x i64> } %816, 0
  %818 = extractvalue { <8 x ptr>, <8 x i64> } %816, 1
  %819 = getelementptr i8, <8 x ptr> %817, <8 x i64> %818
  %820 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %819, <8 x i1> %80, <8 x float> zeroinitializer)
  %821 = fmul <8 x float> %809, %820
  %822 = fadd <8 x float> %798, %821
  %823 = add <8 x i64> %364, splat (i64 19)
  %tile_snapshot.spill.load272 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %824 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 0
  %825 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load272, 1
  %826 = mul <8 x i64> %823, splat (i64 32)
  %827 = add <8 x i64> %825, %826
  %828 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %824, 0
  %829 = insertvalue { <8 x ptr>, <8 x i64> } %828, <8 x i64> %827, 1
  %830 = extractvalue { <8 x ptr>, <8 x i64> } %829, 0
  %831 = extractvalue { <8 x ptr>, <8 x i64> } %829, 1
  %832 = getelementptr i8, <8 x ptr> %830, <8 x i64> %831
  %833 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %832, <8 x i1> %80, <8 x float> zeroinitializer)
  %834 = add <8 x i64> %377, splat (i64 19)
  %tile_snapshot.spill.load273 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %835 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 0
  %836 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load273, 1
  %837 = mul <8 x i64> %834, splat (i64 32)
  %838 = add <8 x i64> %836, %837
  %839 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %835, 0
  %840 = insertvalue { <8 x ptr>, <8 x i64> } %839, <8 x i64> %838, 1
  %841 = extractvalue { <8 x ptr>, <8 x i64> } %840, 0
  %842 = extractvalue { <8 x ptr>, <8 x i64> } %840, 1
  %843 = getelementptr i8, <8 x ptr> %841, <8 x i64> %842
  %844 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %843, <8 x i1> %80, <8 x float> zeroinitializer)
  %845 = fmul <8 x float> %833, %844
  %846 = fadd <8 x float> %822, %845
  %847 = add <8 x i64> %364, splat (i64 20)
  %tile_snapshot.spill.load274 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %848 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 0
  %849 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load274, 1
  %850 = mul <8 x i64> %847, splat (i64 32)
  %851 = add <8 x i64> %849, %850
  %852 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %848, 0
  %853 = insertvalue { <8 x ptr>, <8 x i64> } %852, <8 x i64> %851, 1
  %854 = extractvalue { <8 x ptr>, <8 x i64> } %853, 0
  %855 = extractvalue { <8 x ptr>, <8 x i64> } %853, 1
  %856 = getelementptr i8, <8 x ptr> %854, <8 x i64> %855
  %857 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %856, <8 x i1> %80, <8 x float> zeroinitializer)
  %858 = add <8 x i64> %377, splat (i64 20)
  %tile_snapshot.spill.load275 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %859 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 0
  %860 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load275, 1
  %861 = mul <8 x i64> %858, splat (i64 32)
  %862 = add <8 x i64> %860, %861
  %863 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %859, 0
  %864 = insertvalue { <8 x ptr>, <8 x i64> } %863, <8 x i64> %862, 1
  %865 = extractvalue { <8 x ptr>, <8 x i64> } %864, 0
  %866 = extractvalue { <8 x ptr>, <8 x i64> } %864, 1
  %867 = getelementptr i8, <8 x ptr> %865, <8 x i64> %866
  %868 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %867, <8 x i1> %80, <8 x float> zeroinitializer)
  %869 = fmul <8 x float> %857, %868
  %870 = fadd <8 x float> %846, %869
  %871 = add <8 x i64> %364, splat (i64 21)
  %tile_snapshot.spill.load276 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %872 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load276, 0
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load276, 1
  %874 = mul <8 x i64> %871, splat (i64 32)
  %875 = add <8 x i64> %873, %874
  %876 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %872, 0
  %877 = insertvalue { <8 x ptr>, <8 x i64> } %876, <8 x i64> %875, 1
  %878 = extractvalue { <8 x ptr>, <8 x i64> } %877, 0
  %879 = extractvalue { <8 x ptr>, <8 x i64> } %877, 1
  %880 = getelementptr i8, <8 x ptr> %878, <8 x i64> %879
  %881 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %880, <8 x i1> %80, <8 x float> zeroinitializer)
  %882 = add <8 x i64> %377, splat (i64 21)
  %tile_snapshot.spill.load277 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 0
  %884 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load277, 1
  %885 = mul <8 x i64> %882, splat (i64 32)
  %886 = add <8 x i64> %884, %885
  %887 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %883, 0
  %888 = insertvalue { <8 x ptr>, <8 x i64> } %887, <8 x i64> %886, 1
  %889 = extractvalue { <8 x ptr>, <8 x i64> } %888, 0
  %890 = extractvalue { <8 x ptr>, <8 x i64> } %888, 1
  %891 = getelementptr i8, <8 x ptr> %889, <8 x i64> %890
  %892 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %891, <8 x i1> %80, <8 x float> zeroinitializer)
  %893 = fmul <8 x float> %881, %892
  %894 = fadd <8 x float> %870, %893
  %895 = add <8 x i64> %364, splat (i64 22)
  %tile_snapshot.spill.load278 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %896 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load278, 0
  %897 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load278, 1
  %898 = mul <8 x i64> %895, splat (i64 32)
  %899 = add <8 x i64> %897, %898
  %900 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %896, 0
  %901 = insertvalue { <8 x ptr>, <8 x i64> } %900, <8 x i64> %899, 1
  %902 = extractvalue { <8 x ptr>, <8 x i64> } %901, 0
  %903 = extractvalue { <8 x ptr>, <8 x i64> } %901, 1
  %904 = getelementptr i8, <8 x ptr> %902, <8 x i64> %903
  %905 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %904, <8 x i1> %80, <8 x float> zeroinitializer)
  %906 = add <8 x i64> %377, splat (i64 22)
  %tile_snapshot.spill.load279 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %907 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 0
  %908 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load279, 1
  %909 = mul <8 x i64> %906, splat (i64 32)
  %910 = add <8 x i64> %908, %909
  %911 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %907, 0
  %912 = insertvalue { <8 x ptr>, <8 x i64> } %911, <8 x i64> %910, 1
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %912, 0
  %914 = extractvalue { <8 x ptr>, <8 x i64> } %912, 1
  %915 = getelementptr i8, <8 x ptr> %913, <8 x i64> %914
  %916 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %915, <8 x i1> %80, <8 x float> zeroinitializer)
  %917 = fmul <8 x float> %905, %916
  %918 = fadd <8 x float> %894, %917
  %919 = add <8 x i64> %364, splat (i64 23)
  %tile_snapshot.spill.load280 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 0
  %921 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load280, 1
  %922 = mul <8 x i64> %919, splat (i64 32)
  %923 = add <8 x i64> %921, %922
  %924 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %920, 0
  %925 = insertvalue { <8 x ptr>, <8 x i64> } %924, <8 x i64> %923, 1
  %926 = extractvalue { <8 x ptr>, <8 x i64> } %925, 0
  %927 = extractvalue { <8 x ptr>, <8 x i64> } %925, 1
  %928 = getelementptr i8, <8 x ptr> %926, <8 x i64> %927
  %929 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %928, <8 x i1> %80, <8 x float> zeroinitializer)
  %930 = add <8 x i64> %377, splat (i64 23)
  %tile_snapshot.spill.load281 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 0
  %932 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load281, 1
  %933 = mul <8 x i64> %930, splat (i64 32)
  %934 = add <8 x i64> %932, %933
  %935 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %931, 0
  %936 = insertvalue { <8 x ptr>, <8 x i64> } %935, <8 x i64> %934, 1
  %937 = extractvalue { <8 x ptr>, <8 x i64> } %936, 0
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %936, 1
  %939 = getelementptr i8, <8 x ptr> %937, <8 x i64> %938
  %940 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %939, <8 x i1> %80, <8 x float> zeroinitializer)
  %941 = fmul <8 x float> %929, %940
  %942 = fadd <8 x float> %918, %941
  %943 = add <8 x i64> %364, splat (i64 24)
  %tile_snapshot.spill.load282 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %944 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 0
  %945 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load282, 1
  %946 = mul <8 x i64> %943, splat (i64 32)
  %947 = add <8 x i64> %945, %946
  %948 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %944, 0
  %949 = insertvalue { <8 x ptr>, <8 x i64> } %948, <8 x i64> %947, 1
  %950 = extractvalue { <8 x ptr>, <8 x i64> } %949, 0
  %951 = extractvalue { <8 x ptr>, <8 x i64> } %949, 1
  %952 = getelementptr i8, <8 x ptr> %950, <8 x i64> %951
  %953 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %952, <8 x i1> %80, <8 x float> zeroinitializer)
  %954 = add <8 x i64> %377, splat (i64 24)
  %tile_snapshot.spill.load283 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %955 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 0
  %956 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load283, 1
  %957 = mul <8 x i64> %954, splat (i64 32)
  %958 = add <8 x i64> %956, %957
  %959 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %955, 0
  %960 = insertvalue { <8 x ptr>, <8 x i64> } %959, <8 x i64> %958, 1
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %960, 0
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %960, 1
  %963 = getelementptr i8, <8 x ptr> %961, <8 x i64> %962
  %964 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %963, <8 x i1> %80, <8 x float> zeroinitializer)
  %965 = fmul <8 x float> %953, %964
  %966 = fadd <8 x float> %942, %965
  %967 = add <8 x i64> %364, splat (i64 25)
  %tile_snapshot.spill.load284 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %968 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load284, 0
  %969 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load284, 1
  %970 = mul <8 x i64> %967, splat (i64 32)
  %971 = add <8 x i64> %969, %970
  %972 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %968, 0
  %973 = insertvalue { <8 x ptr>, <8 x i64> } %972, <8 x i64> %971, 1
  %974 = extractvalue { <8 x ptr>, <8 x i64> } %973, 0
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %973, 1
  %976 = getelementptr i8, <8 x ptr> %974, <8 x i64> %975
  %977 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %976, <8 x i1> %80, <8 x float> zeroinitializer)
  %978 = add <8 x i64> %377, splat (i64 25)
  %tile_snapshot.spill.load285 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %979 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 0
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load285, 1
  %981 = mul <8 x i64> %978, splat (i64 32)
  %982 = add <8 x i64> %980, %981
  %983 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %979, 0
  %984 = insertvalue { <8 x ptr>, <8 x i64> } %983, <8 x i64> %982, 1
  %985 = extractvalue { <8 x ptr>, <8 x i64> } %984, 0
  %986 = extractvalue { <8 x ptr>, <8 x i64> } %984, 1
  %987 = getelementptr i8, <8 x ptr> %985, <8 x i64> %986
  %988 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %987, <8 x i1> %80, <8 x float> zeroinitializer)
  %989 = fmul <8 x float> %977, %988
  %990 = fadd <8 x float> %966, %989
  %991 = add <8 x i64> %364, splat (i64 26)
  %tile_snapshot.spill.load286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %992 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 0
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load286, 1
  %994 = mul <8 x i64> %991, splat (i64 32)
  %995 = add <8 x i64> %993, %994
  %996 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %992, 0
  %997 = insertvalue { <8 x ptr>, <8 x i64> } %996, <8 x i64> %995, 1
  %998 = extractvalue { <8 x ptr>, <8 x i64> } %997, 0
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %997, 1
  %1000 = getelementptr i8, <8 x ptr> %998, <8 x i64> %999
  %1001 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1000, <8 x i1> %80, <8 x float> zeroinitializer)
  %1002 = add <8 x i64> %377, splat (i64 26)
  %tile_snapshot.spill.load287 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %1003 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 0
  %1004 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load287, 1
  %1005 = mul <8 x i64> %1002, splat (i64 32)
  %1006 = add <8 x i64> %1004, %1005
  %1007 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1003, 0
  %1008 = insertvalue { <8 x ptr>, <8 x i64> } %1007, <8 x i64> %1006, 1
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %1008, 1
  %1011 = getelementptr i8, <8 x ptr> %1009, <8 x i64> %1010
  %1012 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1011, <8 x i1> %80, <8 x float> zeroinitializer)
  %1013 = fmul <8 x float> %1001, %1012
  %1014 = fadd <8 x float> %990, %1013
  %1015 = add <8 x i64> %364, splat (i64 27)
  %tile_snapshot.spill.load288 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 0
  %1017 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load288, 1
  %1018 = mul <8 x i64> %1015, splat (i64 32)
  %1019 = add <8 x i64> %1017, %1018
  %1020 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1016, 0
  %1021 = insertvalue { <8 x ptr>, <8 x i64> } %1020, <8 x i64> %1019, 1
  %1022 = extractvalue { <8 x ptr>, <8 x i64> } %1021, 0
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %1021, 1
  %1024 = getelementptr i8, <8 x ptr> %1022, <8 x i64> %1023
  %1025 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1024, <8 x i1> %80, <8 x float> zeroinitializer)
  %1026 = add <8 x i64> %377, splat (i64 27)
  %tile_snapshot.spill.load289 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %1027 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 0
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load289, 1
  %1029 = mul <8 x i64> %1026, splat (i64 32)
  %1030 = add <8 x i64> %1028, %1029
  %1031 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1027, 0
  %1032 = insertvalue { <8 x ptr>, <8 x i64> } %1031, <8 x i64> %1030, 1
  %1033 = extractvalue { <8 x ptr>, <8 x i64> } %1032, 0
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %1032, 1
  %1035 = getelementptr i8, <8 x ptr> %1033, <8 x i64> %1034
  %1036 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1035, <8 x i1> %80, <8 x float> zeroinitializer)
  %1037 = fmul <8 x float> %1025, %1036
  %1038 = fadd <8 x float> %1014, %1037
  %1039 = add <8 x i64> %364, splat (i64 28)
  %tile_snapshot.spill.load290 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1040 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load290, 0
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load290, 1
  %1042 = mul <8 x i64> %1039, splat (i64 32)
  %1043 = add <8 x i64> %1041, %1042
  %1044 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1040, 0
  %1045 = insertvalue { <8 x ptr>, <8 x i64> } %1044, <8 x i64> %1043, 1
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %1045, 0
  %1047 = extractvalue { <8 x ptr>, <8 x i64> } %1045, 1
  %1048 = getelementptr i8, <8 x ptr> %1046, <8 x i64> %1047
  %1049 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1048, <8 x i1> %80, <8 x float> zeroinitializer)
  %1050 = add <8 x i64> %377, splat (i64 28)
  %tile_snapshot.spill.load291 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %1051 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 0
  %1052 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load291, 1
  %1053 = mul <8 x i64> %1050, splat (i64 32)
  %1054 = add <8 x i64> %1052, %1053
  %1055 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1051, 0
  %1056 = insertvalue { <8 x ptr>, <8 x i64> } %1055, <8 x i64> %1054, 1
  %1057 = extractvalue { <8 x ptr>, <8 x i64> } %1056, 0
  %1058 = extractvalue { <8 x ptr>, <8 x i64> } %1056, 1
  %1059 = getelementptr i8, <8 x ptr> %1057, <8 x i64> %1058
  %1060 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1059, <8 x i1> %80, <8 x float> zeroinitializer)
  %1061 = fmul <8 x float> %1049, %1060
  %1062 = fadd <8 x float> %1038, %1061
  %1063 = add <8 x i64> %364, splat (i64 29)
  %tile_snapshot.spill.load292 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1064 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 0
  %1065 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load292, 1
  %1066 = mul <8 x i64> %1063, splat (i64 32)
  %1067 = add <8 x i64> %1065, %1066
  %1068 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1064, 0
  %1069 = insertvalue { <8 x ptr>, <8 x i64> } %1068, <8 x i64> %1067, 1
  %1070 = extractvalue { <8 x ptr>, <8 x i64> } %1069, 0
  %1071 = extractvalue { <8 x ptr>, <8 x i64> } %1069, 1
  %1072 = getelementptr i8, <8 x ptr> %1070, <8 x i64> %1071
  %1073 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1072, <8 x i1> %80, <8 x float> zeroinitializer)
  %1074 = add <8 x i64> %377, splat (i64 29)
  %tile_snapshot.spill.load293 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 0
  %1076 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load293, 1
  %1077 = mul <8 x i64> %1074, splat (i64 32)
  %1078 = add <8 x i64> %1076, %1077
  %1079 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1075, 0
  %1080 = insertvalue { <8 x ptr>, <8 x i64> } %1079, <8 x i64> %1078, 1
  %1081 = extractvalue { <8 x ptr>, <8 x i64> } %1080, 0
  %1082 = extractvalue { <8 x ptr>, <8 x i64> } %1080, 1
  %1083 = getelementptr i8, <8 x ptr> %1081, <8 x i64> %1082
  %1084 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1083, <8 x i1> %80, <8 x float> zeroinitializer)
  %1085 = fmul <8 x float> %1073, %1084
  %1086 = fadd <8 x float> %1062, %1085
  %1087 = add <8 x i64> %364, splat (i64 30)
  %tile_snapshot.spill.load294 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 0
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load294, 1
  %1090 = mul <8 x i64> %1087, splat (i64 32)
  %1091 = add <8 x i64> %1089, %1090
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1093 = insertvalue { <8 x ptr>, <8 x i64> } %1092, <8 x i64> %1091, 1
  %1094 = extractvalue { <8 x ptr>, <8 x i64> } %1093, 0
  %1095 = extractvalue { <8 x ptr>, <8 x i64> } %1093, 1
  %1096 = getelementptr i8, <8 x ptr> %1094, <8 x i64> %1095
  %1097 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1096, <8 x i1> %80, <8 x float> zeroinitializer)
  %1098 = add <8 x i64> %377, splat (i64 30)
  %tile_snapshot.spill.load295 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %1099 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load295, 0
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load295, 1
  %1101 = mul <8 x i64> %1098, splat (i64 32)
  %1102 = add <8 x i64> %1100, %1101
  %1103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1099, 0
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } %1103, <8 x i64> %1102, 1
  %1105 = extractvalue { <8 x ptr>, <8 x i64> } %1104, 0
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %1104, 1
  %1107 = getelementptr i8, <8 x ptr> %1105, <8 x i64> %1106
  %1108 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1107, <8 x i1> %80, <8 x float> zeroinitializer)
  %1109 = fmul <8 x float> %1097, %1108
  %1110 = fadd <8 x float> %1086, %1109
  %1111 = add <8 x i64> %364, splat (i64 31)
  %tile_snapshot.spill.load296 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load296, 0
  %1113 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load296, 1
  %1114 = mul <8 x i64> %1111, splat (i64 32)
  %1115 = add <8 x i64> %1113, %1114
  %1116 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1112, 0
  %1117 = insertvalue { <8 x ptr>, <8 x i64> } %1116, <8 x i64> %1115, 1
  %1118 = extractvalue { <8 x ptr>, <8 x i64> } %1117, 0
  %1119 = extractvalue { <8 x ptr>, <8 x i64> } %1117, 1
  %1120 = getelementptr i8, <8 x ptr> %1118, <8 x i64> %1119
  %1121 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1120, <8 x i1> %80, <8 x float> zeroinitializer)
  %1122 = add <8 x i64> %377, splat (i64 31)
  %tile_snapshot.spill.load297 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %1123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load297, 0
  %1124 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load297, 1
  %1125 = mul <8 x i64> %1122, splat (i64 32)
  %1126 = add <8 x i64> %1124, %1125
  %1127 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1123, 0
  %1128 = insertvalue { <8 x ptr>, <8 x i64> } %1127, <8 x i64> %1126, 1
  %1129 = extractvalue { <8 x ptr>, <8 x i64> } %1128, 0
  %1130 = extractvalue { <8 x ptr>, <8 x i64> } %1128, 1
  %1131 = getelementptr i8, <8 x ptr> %1129, <8 x i64> %1130
  %1132 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1131, <8 x i1> %80, <8 x float> zeroinitializer)
  %1133 = fmul <8 x float> %1121, %1132
  %1134 = fadd <8 x float> %1110, %1133
  %1135 = add <8 x i64> %364, splat (i64 32)
  %tile_snapshot.spill.load298 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %1136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 0
  %1137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load298, 1
  %1138 = mul <8 x i64> %1135, splat (i64 32)
  %1139 = add <8 x i64> %1137, %1138
  %1140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1136, 0
  %1141 = insertvalue { <8 x ptr>, <8 x i64> } %1140, <8 x i64> %1139, 1
  %1142 = extractvalue { <8 x ptr>, <8 x i64> } %1141, 0
  %1143 = extractvalue { <8 x ptr>, <8 x i64> } %1141, 1
  %1144 = getelementptr i8, <8 x ptr> %1142, <8 x i64> %1143
  %1145 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1144, <8 x i1> %80, <8 x float> zeroinitializer)
  %1146 = add <8 x i64> %377, splat (i64 32)
  %tile_snapshot.spill.load299 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill64, align 64
  %1147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 0
  %1148 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load299, 1
  %1149 = mul <8 x i64> %1146, splat (i64 32)
  %1150 = add <8 x i64> %1148, %1149
  %1151 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1147, 0
  %1152 = insertvalue { <8 x ptr>, <8 x i64> } %1151, <8 x i64> %1150, 1
  %1153 = extractvalue { <8 x ptr>, <8 x i64> } %1152, 0
  %1154 = extractvalue { <8 x ptr>, <8 x i64> } %1152, 1
  %1155 = getelementptr i8, <8 x ptr> %1153, <8 x i64> %1154
  %1156 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1155, <8 x i1> %80, <8 x float> zeroinitializer)
  %1157 = fmul <8 x float> %1145, %1156
  %1158 = fadd <8 x float> %1134, %1157
  %tile_snapshot.spill.load300 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill70, align 64
  %1159 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load300, 0
  %1160 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load300, 1
  %.state301 = load <8 x i64>, ptr %.slot71, align 64
  %1161 = mul <8 x i64> %.state301, splat (i64 32)
  %1162 = add <8 x i64> %1160, %1161
  %1163 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1159, 0
  %1164 = insertvalue { <8 x ptr>, <8 x i64> } %1163, <8 x i64> %1162, 1
  %1165 = extractvalue { <8 x ptr>, <8 x i64> } %1164, 0
  %1166 = extractvalue { <8 x ptr>, <8 x i64> } %1164, 1
  %1167 = getelementptr i8, <8 x ptr> %1165, <8 x i64> %1166
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1158, <8 x ptr> align 1 %1167, <8 x i1> %80)
  %.state302 = load <8 x i64>, ptr %.slot71, align 64
  %1168 = add <8 x i64> %.state302, splat (i64 1)
  %1169 = load <8 x i64>, ptr %.slot71, align 64
  %1170 = select <8 x i1> %80, <8 x i64> %1168, <8 x i64> %1169
  store <8 x i64> %1170, ptr %.slot71, align 64
  br label %direct.schedule.18

direct.schedule.20:                               ; preds = %direct.false231
  %1171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %1172 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %1173 = extractvalue { <8 x ptr>, <8 x i64> } %1171, 0
  %1174 = select <8 x i1> %80, <8 x ptr> %1172, <8 x ptr> %1173
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %1176 = extractvalue { <8 x ptr>, <8 x i64> } %1171, 1
  %1177 = select <8 x i1> %80, <8 x i64> %1175, <8 x i64> %1176
  %1178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1174, 0
  %1179 = insertvalue { <8 x ptr>, <8 x i64> } %1178, <8 x i64> %1177, 1
  store { <8 x ptr>, <8 x i64> } %1179, ptr %tile_snapshot.spill72, align 64
  %1180 = load <8 x i64>, ptr %.slot73, align 64
  %1181 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %1180
  store <8 x i64> %1181, ptr %.slot73, align 64
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state303 = load <8 x i64>, ptr %.slot73, align 64
  %1182 = icmp slt <8 x i64> %.state303, splat (i64 65)
  %1183 = extractelement <8 x i1> %1182, i32 0
  br i1 %1183, label %direct.true304, label %direct.false305

direct.schedule.22:                               ; preds = %direct.true304
  %tile_snapshot.spill.load306 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %1184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load306, 0
  %1185 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load306, 1
  %.state307 = load <8 x i64>, ptr %.slot73, align 64
  %1186 = mul <8 x i64> %.state307, splat (i64 64)
  %1187 = add <8 x i64> %1185, %1186
  %1188 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1184, 0
  %1189 = insertvalue { <8 x ptr>, <8 x i64> } %1188, <8 x i64> %1187, 1
  %.state308 = load <8 x i64>, ptr %.slot73, align 64
  %1190 = extractvalue { <8 x ptr>, <8 x i64> } %1189, 0
  %1191 = extractvalue { <8 x ptr>, <8 x i64> } %1189, 1
  %1192 = getelementptr i8, <8 x ptr> %1190, <8 x i64> %1191
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %.state308, <8 x ptr> align 1 %1192, <8 x i1> %80)
  %.state309 = load <8 x i64>, ptr %.slot73, align 64
  %1193 = add <8 x i64> %.state309, splat (i64 1)
  %1194 = load <8 x i64>, ptr %.slot73, align 64
  %1195 = select <8 x i1> %80, <8 x i64> %1193, <8 x i64> %1194
  store <8 x i64> %1195, ptr %.slot73, align 64
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false305
  %1196 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 0
  %1199 = select <8 x i1> %80, <8 x ptr> %1197, <8 x ptr> %1198
  %1200 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %1201 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1202 = select <8 x i1> %80, <8 x i64> %1200, <8 x i64> %1201
  %1203 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1199, 0
  %1204 = insertvalue { <8 x ptr>, <8 x i64> } %1203, <8 x i64> %1202, 1
  store { <8 x ptr>, <8 x i64> } %1204, ptr %tile_snapshot.spill74, align 64
  %1205 = load <8 x i64>, ptr %.slot75, align 64
  %1206 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %1205
  store <8 x i64> %1206, ptr %.slot75, align 64
  br label %direct.schedule.24

direct.schedule.24:                               ; preds = %direct.schedule.25, %direct.schedule.23
  %.state310 = load <8 x i64>, ptr %.slot75, align 64
  %1207 = icmp slt <8 x i64> %.state310, splat (i64 65)
  %1208 = extractelement <8 x i1> %1207, i32 0
  br i1 %1208, label %direct.true311, label %direct.false312

direct.schedule.25:                               ; preds = %direct.true311
  %tile_snapshot.spill.load313 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 0
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load313, 1
  %.state314 = load <8 x i64>, ptr %.slot75, align 64
  %1211 = mul <8 x i64> %.state314, splat (i64 64)
  %1212 = add <8 x i64> %1210, %1211
  %1213 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1209, 0
  %1214 = insertvalue { <8 x ptr>, <8 x i64> } %1213, <8 x i64> %1212, 1
  %.state315 = load <8 x i64>, ptr %.slot75, align 64
  %1215 = extractvalue { <8 x ptr>, <8 x i64> } %1214, 0
  %1216 = extractvalue { <8 x ptr>, <8 x i64> } %1214, 1
  %1217 = getelementptr i8, <8 x ptr> %1215, <8 x i64> %1216
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %.state315, <8 x ptr> align 1 %1217, <8 x i1> %80)
  %.state316 = load <8 x i64>, ptr %.slot75, align 64
  %1218 = add <8 x i64> %.state316, splat (i64 1)
  %1219 = load <8 x i64>, ptr %.slot75, align 64
  %1220 = select <8 x i1> %80, <8 x i64> %1218, <8 x i64> %1219
  store <8 x i64> %1220, ptr %.slot75, align 64
  br label %direct.schedule.24

direct.schedule.26:                               ; preds = %direct.false312
  %.spill.load317 = load <8 x i64>, ptr %.spill41, align 64
  %1221 = add <8 x i64> zeroinitializer, %.spill.load317
  %.spill.load318 = load <8 x i64>, ptr %.spill41, align 64
  %1222 = add <8 x i64> splat (i64 1), %.spill.load318
  %1223 = add <8 x i64> %1221, splat (i64 67)
  %1224 = add <8 x i64> %1222, splat (i64 67)
  %1225 = sub <8 x i64> %1223, splat (i64 3)
  %1226 = sub <8 x i64> %1224, splat (i64 3)
  %1227 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill76, align 64
  %1228 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1229 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 0
  %1230 = select <8 x i1> %80, <8 x ptr> %1228, <8 x ptr> %1229
  %1231 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1232 = extractvalue { <8 x ptr>, <8 x i64> } %1227, 1
  %1233 = select <8 x i1> %80, <8 x i64> %1231, <8 x i64> %1232
  %1234 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1230, 0
  %1235 = insertvalue { <8 x ptr>, <8 x i64> } %1234, <8 x i64> %1233, 1
  store { <8 x ptr>, <8 x i64> } %1235, ptr %tile_snapshot.spill76, align 64
  %1236 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1238 = add <8 x i64> %1237, zeroinitializer
  %1239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1236, 0
  %1240 = insertvalue { <8 x ptr>, <8 x i64> } %1239, <8 x i64> %1238, 1
  %1241 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1242 = extractvalue { <8 x ptr>, <8 x i64> } %1240, 1
  %1243 = extractelement <8 x ptr> %1241, i32 0
  %1244 = extractelement <8 x i64> %1242, i32 0
  %1245 = sub i64 %1244, 0
  %1246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1247 = select i1 %1246, i64 %1245, i64 0
  %private.contiguous.address = getelementptr i8, ptr %1243, i64 %1247
  %private.contiguous.preserve = load <8 x i64>, ptr %private.contiguous.address, align 8
  %1248 = select <8 x i1> %80, <8 x i64> %1225, <8 x i64> %private.contiguous.preserve
  store <8 x i64> %1248, ptr %private.contiguous.address, align 8
  %1249 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1250 = extractvalue { <8 x ptr>, <8 x i64> } %20, 1
  %1251 = add <8 x i64> %1250, splat (i64 64)
  %1252 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1249, 0
  %1253 = insertvalue { <8 x ptr>, <8 x i64> } %1252, <8 x i64> %1251, 1
  %1254 = extractvalue { <8 x ptr>, <8 x i64> } %20, 0
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %1253, 1
  %1256 = extractelement <8 x ptr> %1254, i32 0
  %1257 = extractelement <8 x i64> %1255, i32 0
  %1258 = sub i64 %1257, 0
  %1259 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1260 = select i1 %1259, i64 %1258, i64 0
  %private.contiguous.address319 = getelementptr i8, ptr %1256, i64 %1260
  %private.contiguous.preserve320 = load <8 x i64>, ptr %private.contiguous.address319, align 8
  %1261 = select <8 x i1> %80, <8 x i64> %1226, <8 x i64> %private.contiguous.preserve320
  store <8 x i64> %1261, ptr %private.contiguous.address319, align 8
  %1262 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill77, align 64
  %1263 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1264 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 0
  %1265 = select <8 x i1> %80, <8 x ptr> %1263, <8 x ptr> %1264
  %1266 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1267 = extractvalue { <8 x ptr>, <8 x i64> } %1262, 1
  %1268 = select <8 x i1> %80, <8 x i64> %1266, <8 x i64> %1267
  %1269 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1265, 0
  %1270 = insertvalue { <8 x ptr>, <8 x i64> } %1269, <8 x i64> %1268, 1
  store { <8 x ptr>, <8 x i64> } %1270, ptr %tile_snapshot.spill77, align 64
  %1271 = load <8 x i64>, ptr %.slot78, align 64
  %1272 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %1271
  store <8 x i64> %1272, ptr %.slot78, align 64
  br label %direct.schedule.27

direct.schedule.27:                               ; preds = %direct.schedule.28, %direct.schedule.26
  %.state321 = load <8 x i64>, ptr %.slot78, align 64
  %1273 = icmp slt <8 x i64> %.state321, splat (i64 130)
  %1274 = extractelement <8 x i1> %1273, i32 0
  br i1 %1274, label %direct.true322, label %direct.false323

direct.schedule.28:                               ; preds = %direct.true322
  %.state324 = load <8 x i64>, ptr %.slot78, align 64
  %1275 = select <8 x i1> %80, <8 x i64> %.state324, <8 x i64> zeroinitializer
  %1276 = select <8 x i1> %80, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1277 = srem <8 x i64> %1275, %1276
  %.state325 = load <8 x i64>, ptr %.slot78, align 64
  %1278 = select <8 x i1> %80, <8 x i64> %.state325, <8 x i64> zeroinitializer
  %1279 = select <8 x i1> %80, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1280 = sdiv <8 x i64> %1278, %1279
  %1281 = add <8 x i64> zeroinitializer, %1280
  %1282 = add <8 x i64> zeroinitializer, %1281
  %1283 = add <8 x i64> zeroinitializer, %1282
  %tile_snapshot.spill.load326 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill72, align 64
  %1284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 0
  %1285 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load326, 1
  %1286 = mul <8 x i64> %1283, splat (i64 64)
  %1287 = add <8 x i64> %1285, %1286
  %1288 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1284, 0
  %1289 = insertvalue { <8 x ptr>, <8 x i64> } %1288, <8 x i64> %1287, 1
  %1290 = extractvalue { <8 x ptr>, <8 x i64> } %1289, 0
  %1291 = extractvalue { <8 x ptr>, <8 x i64> } %1289, 1
  %1292 = getelementptr i8, <8 x ptr> %1290, <8 x i64> %1291
  %1293 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1292, <8 x i1> %80, <8 x i64> zeroinitializer)
  %.spill.load327 = load <8 x i64>, ptr %.spill63, align 64
  %1294 = add <8 x i64> %1293, %.spill.load327
  %1295 = icmp slt <8 x i64> %1294, splat (i64 67)
  %1296 = mul <8 x i64> %1281, splat (i64 2)
  %1297 = add <8 x i64> %1296, %1277
  %1298 = select <8 x i1> %80, <8 x i64> %1297, <8 x i64> zeroinitializer
  %1299 = select <8 x i1> %80, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1300 = srem <8 x i64> %1298, %1299
  %1301 = select <8 x i1> %80, <8 x i64> %1297, <8 x i64> zeroinitializer
  %1302 = select <8 x i1> %80, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1303 = sdiv <8 x i64> %1301, %1302
  %1304 = add <8 x i64> zeroinitializer, %1303
  %1305 = add <8 x i64> zeroinitializer, %1304
  %tile_snapshot.spill.load328 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill74, align 64
  %1306 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load328, 0
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load328, 1
  %1308 = mul <8 x i64> %1305, splat (i64 64)
  %1309 = add <8 x i64> %1307, %1308
  %1310 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1306, 0
  %1311 = insertvalue { <8 x ptr>, <8 x i64> } %1310, <8 x i64> %1309, 1
  %1312 = extractvalue { <8 x ptr>, <8 x i64> } %1311, 0
  %1313 = extractvalue { <8 x ptr>, <8 x i64> } %1311, 1
  %1314 = getelementptr i8, <8 x ptr> %1312, <8 x i64> %1313
  %1315 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1314, <8 x i1> %80, <8 x i64> zeroinitializer)
  %.spill.load329 = load <8 x i64>, ptr %.spill63, align 64
  %1316 = add <8 x i64> %1315, %.spill.load329
  %1317 = add <8 x i64> zeroinitializer, %1300
  %tile_snapshot.spill.load330 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill76, align 64
  %1318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load330, 0
  %1319 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load330, 1
  %1320 = mul <8 x i64> %1317, splat (i64 64)
  %1321 = add <8 x i64> %1319, %1320
  %1322 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1318, 0
  %1323 = insertvalue { <8 x ptr>, <8 x i64> } %1322, <8 x i64> %1321, 1
  %1324 = extractvalue { <8 x ptr>, <8 x i64> } %1323, 0
  %1325 = extractvalue { <8 x ptr>, <8 x i64> } %1323, 1
  %1326 = getelementptr i8, <8 x ptr> %1324, <8 x i64> %1325
  %1327 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %1326, <8 x i1> %80, <8 x i64> zeroinitializer)
  %1328 = icmp sle <8 x i64> %1316, %1327
  %1329 = and <8 x i1> %1295, %1328
  %tile_snapshot.spill.load331 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill77, align 64
  %1330 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load331, 0
  %1331 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load331, 1
  %.state332 = load <8 x i64>, ptr %.slot78, align 64
  %1332 = add <8 x i64> %1331, %.state332
  %1333 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1330, 0
  %1334 = insertvalue { <8 x ptr>, <8 x i64> } %1333, <8 x i64> %1332, 1
  %1335 = extractvalue { <8 x ptr>, <8 x i64> } %1334, 0
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %1334, 1
  %1337 = getelementptr i8, <8 x ptr> %1335, <8 x i64> %1336
  %1338 = zext <8 x i1> %1329 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1338, <8 x ptr> align 1 %1337, <8 x i1> %80)
  %.state333 = load <8 x i64>, ptr %.slot78, align 64
  %1339 = add <8 x i64> %.state333, splat (i64 1)
  %1340 = load <8 x i64>, ptr %.slot78, align 64
  %1341 = select <8 x i1> %80, <8 x i64> %1339, <8 x i64> %1340
  store <8 x i64> %1341, ptr %.slot78, align 64
  br label %direct.schedule.27

direct.schedule.29:                               ; preds = %direct.false323
  %1342 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1343 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1344 = extractvalue { <8 x ptr>, <8 x i64> } %1342, 0
  %1345 = select <8 x i1> %80, <8 x ptr> %1343, <8 x ptr> %1344
  %1346 = extractvalue { <8 x ptr>, <8 x i64> } %26, 1
  %1347 = extractvalue { <8 x ptr>, <8 x i64> } %1342, 1
  %1348 = select <8 x i1> %80, <8 x i64> %1346, <8 x i64> %1347
  %1349 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1345, 0
  %1350 = insertvalue { <8 x ptr>, <8 x i64> } %1349, <8 x i64> %1348, 1
  store { <8 x ptr>, <8 x i64> } %1350, ptr %tile_snapshot.spill79, align 64
  %1351 = load <8 x i64>, ptr %.slot80, align 64
  %1352 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %1351
  store <8 x i64> %1352, ptr %.slot80, align 64
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.31, %direct.schedule.29
  %.state334 = load <8 x i64>, ptr %.slot80, align 64
  %1353 = icmp slt <8 x i64> %.state334, splat (i64 130)
  %1354 = extractelement <8 x i1> %1353, i32 0
  br i1 %1354, label %direct.true335, label %direct.false336

direct.schedule.31:                               ; preds = %direct.true335
  %.state337 = load <8 x i64>, ptr %.slot80, align 64
  %1355 = select <8 x i1> %80, <8 x i64> %.state337, <8 x i64> zeroinitializer
  %1356 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1357 = srem <8 x i64> %1355, %1356
  %.state338 = load <8 x i64>, ptr %.slot80, align 64
  %1358 = select <8 x i1> %80, <8 x i64> %.state338, <8 x i64> zeroinitializer
  %1359 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1360 = sdiv <8 x i64> %1358, %1359
  %1361 = add <8 x i64> zeroinitializer, %1357
  %1362 = mul <8 x i64> %1361, splat (i64 2)
  %1363 = add <8 x i64> %1362, %1360
  %tile_snapshot.spill.load339 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill77, align 64
  %1364 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 0
  %1365 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load339, 1
  %1366 = add <8 x i64> %1365, %1363
  %1367 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1364, 0
  %1368 = insertvalue { <8 x ptr>, <8 x i64> } %1367, <8 x i64> %1366, 1
  %1369 = extractvalue { <8 x ptr>, <8 x i64> } %1368, 0
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %1368, 1
  %1371 = getelementptr i8, <8 x ptr> %1369, <8 x i64> %1370
  %1372 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1371, <8 x i1> %80, <8 x i8> zeroinitializer)
  %1373 = icmp ne <8 x i8> %1372, zeroinitializer
  %1374 = add <8 x i64> zeroinitializer, %1360
  %1375 = mul <8 x i64> %1374, splat (i64 65)
  %1376 = add <8 x i64> %1375, %1357
  %1377 = select <8 x i1> %80, <8 x i64> %1376, <8 x i64> zeroinitializer
  %1378 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1379 = srem <8 x i64> %1377, %1378
  %1380 = select <8 x i1> %80, <8 x i64> %1376, <8 x i64> zeroinitializer
  %1381 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1382 = sdiv <8 x i64> %1380, %1381
  %1383 = add <8 x i64> zeroinitializer, %1382
  %1384 = mul <8 x i64> %1383, splat (i64 65)
  %1385 = add <8 x i64> %1384, %1379
  %tile_snapshot.spill.load340 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill70, align 64
  %1386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load340, 0
  %1387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load340, 1
  %1388 = mul <8 x i64> %1385, splat (i64 32)
  %1389 = add <8 x i64> %1387, %1388
  %1390 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1386, 0
  %1391 = insertvalue { <8 x ptr>, <8 x i64> } %1390, <8 x i64> %1389, 1
  %1392 = extractvalue { <8 x ptr>, <8 x i64> } %1391, 0
  %1393 = extractvalue { <8 x ptr>, <8 x i64> } %1391, 1
  %1394 = getelementptr i8, <8 x ptr> %1392, <8 x i64> %1393
  %1395 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1394, <8 x i1> %80, <8 x float> zeroinitializer)
  %1396 = fmul <8 x float> %1395, splat (float 0x3FC6482D40000000)
  %1397 = select <8 x i1> %1373, <8 x float> %1396, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load341 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1398 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load341, 0
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load341, 1
  %.state342 = load <8 x i64>, ptr %.slot80, align 64
  %1400 = mul <8 x i64> %.state342, splat (i64 32)
  %1401 = add <8 x i64> %1399, %1400
  %1402 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1398, 0
  %1403 = insertvalue { <8 x ptr>, <8 x i64> } %1402, <8 x i64> %1401, 1
  %1404 = extractvalue { <8 x ptr>, <8 x i64> } %1403, 0
  %1405 = extractvalue { <8 x ptr>, <8 x i64> } %1403, 1
  %1406 = getelementptr i8, <8 x ptr> %1404, <8 x i64> %1405
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1397, <8 x ptr> align 1 %1406, <8 x i1> %80)
  %.state343 = load <8 x i64>, ptr %.slot80, align 64
  %1407 = add <8 x i64> %.state343, splat (i64 1)
  %1408 = load <8 x i64>, ptr %.slot80, align 64
  %1409 = select <8 x i1> %80, <8 x i64> %1407, <8 x i64> %1408
  store <8 x i64> %1409, ptr %.slot80, align 64
  br label %direct.schedule.30

direct.schedule.32:                               ; preds = %direct.false336
  store i64 0, ptr %.spill81, align 4
  store i64 0, ptr %.spill82, align 4
  store i64 0, ptr %.spill83, align 4
  store i64 0, ptr %.spill84, align 4
  %tile_snapshot.spill.load344 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load344, 0
  %1411 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load344, 1
  %1412 = add <8 x i64> %1411, zeroinitializer
  %1413 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1410, 0
  %1414 = insertvalue { <8 x ptr>, <8 x i64> } %1413, <8 x i64> %1412, 1
  %1415 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1416 = extractvalue { <8 x ptr>, <8 x i64> } %1414, 1
  %1417 = extractelement <8 x ptr> %1415, i32 0
  %1418 = extractelement <8 x i64> %1416, i32 0
  %1419 = sub i64 %1418, 0
  %1420 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1421 = select i1 %1420, i64 %1419, i64 0
  %private.contiguous.address345 = getelementptr i8, ptr %1417, i64 %1421
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address345, align 4
  %1422 = select <8 x i1> %80, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  store i64 1, ptr %.spill85, align 4
  store i64 1, ptr %.spill86, align 4
  %tile_snapshot.spill.load346 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load346, 0
  %1424 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load346, 1
  %1425 = add <8 x i64> %1424, splat (i64 32)
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1423, 0
  %1427 = insertvalue { <8 x ptr>, <8 x i64> } %1426, <8 x i64> %1425, 1
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %1427, 1
  %1430 = extractelement <8 x ptr> %1428, i32 0
  %1431 = extractelement <8 x i64> %1429, i32 0
  %1432 = sub i64 %1431, 0
  %1433 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1434 = select i1 %1433, i64 %1432, i64 0
  %private.contiguous.address347 = getelementptr i8, ptr %1430, i64 %1434
  %private.contiguous.load348 = load <8 x float>, ptr %private.contiguous.address347, align 4
  %1435 = select <8 x i1> %80, <8 x float> %private.contiguous.load348, <8 x float> zeroinitializer
  store i64 2, ptr %.spill87, align 4
  store i64 2, ptr %.spill88, align 4
  %tile_snapshot.spill.load349 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 0
  %1437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load349, 1
  %1438 = add <8 x i64> %1437, splat (i64 64)
  %1439 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1436, 0
  %1440 = insertvalue { <8 x ptr>, <8 x i64> } %1439, <8 x i64> %1438, 1
  %1441 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1442 = extractvalue { <8 x ptr>, <8 x i64> } %1440, 1
  %1443 = extractelement <8 x ptr> %1441, i32 0
  %1444 = extractelement <8 x i64> %1442, i32 0
  %1445 = sub i64 %1444, 0
  %1446 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1447 = select i1 %1446, i64 %1445, i64 0
  %private.contiguous.address350 = getelementptr i8, ptr %1443, i64 %1447
  %private.contiguous.load351 = load <8 x float>, ptr %private.contiguous.address350, align 4
  %1448 = select <8 x i1> %80, <8 x float> %private.contiguous.load351, <8 x float> zeroinitializer
  store i64 3, ptr %.spill89, align 4
  store i64 3, ptr %.spill90, align 4
  %tile_snapshot.spill.load352 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1449 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load352, 0
  %1450 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load352, 1
  %1451 = add <8 x i64> %1450, splat (i64 96)
  %1452 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1449, 0
  %1453 = insertvalue { <8 x ptr>, <8 x i64> } %1452, <8 x i64> %1451, 1
  %1454 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1455 = extractvalue { <8 x ptr>, <8 x i64> } %1453, 1
  %1456 = extractelement <8 x ptr> %1454, i32 0
  %1457 = extractelement <8 x i64> %1455, i32 0
  %1458 = sub i64 %1457, 0
  %1459 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1460 = select i1 %1459, i64 %1458, i64 0
  %private.contiguous.address353 = getelementptr i8, ptr %1456, i64 %1460
  %private.contiguous.load354 = load <8 x float>, ptr %private.contiguous.address353, align 4
  %1461 = select <8 x i1> %80, <8 x float> %private.contiguous.load354, <8 x float> zeroinitializer
  %1462 = load <8 x i64>, ptr %.slot91, align 64
  %1463 = select <8 x i1> %80, <8 x i64> splat (i64 4), <8 x i64> %1462
  store <8 x i64> %1463, ptr %.slot91, align 64
  %1464 = load <8 x float>, ptr %.slot92, align 32
  %1465 = select <8 x i1> %80, <8 x float> %1422, <8 x float> %1464
  store <8 x float> %1465, ptr %.slot92, align 32
  %1466 = load <8 x float>, ptr %.slot93, align 32
  %1467 = select <8 x i1> %80, <8 x float> %1435, <8 x float> %1466
  store <8 x float> %1467, ptr %.slot93, align 32
  %1468 = load <8 x float>, ptr %.slot94, align 32
  %1469 = select <8 x i1> %80, <8 x float> %1448, <8 x float> %1468
  store <8 x float> %1469, ptr %.slot94, align 32
  %1470 = load <8 x float>, ptr %.slot95, align 32
  %1471 = select <8 x i1> %80, <8 x float> %1461, <8 x float> %1470
  store <8 x float> %1471, ptr %.slot95, align 32
  br label %direct.schedule.33

direct.schedule.33:                               ; preds = %direct.schedule.34, %direct.schedule.32
  %.state355 = load <8 x i64>, ptr %.slot91, align 64
  %1472 = icmp slt <8 x i64> %.state355, splat (i64 64)
  %1473 = extractelement <8 x i1> %1472, i32 0
  br i1 %1473, label %direct.true356, label %direct.false357

direct.schedule.34:                               ; preds = %direct.true356
  %.state358 = load <8 x i64>, ptr %.slot91, align 64
  %1474 = add <8 x i64> %.state358, zeroinitializer
  %1475 = select <8 x i1> %80, <8 x i64> %1474, <8 x i64> zeroinitializer
  %1476 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1477 = sdiv <8 x i64> %1475, %1476
  %.spill.load359 = load i64, ptr %.spill83, align 4
  %.splatinsert360 = insertelement <8 x i64> poison, i64 %.spill.load359, i64 0
  %.splat361 = shufflevector <8 x i64> %.splatinsert360, <8 x i64> poison, <8 x i32> zeroinitializer
  %1478 = add <8 x i64> %.splat361, %1477
  %tile_snapshot.spill.load362 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load362, 0
  %1480 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load362, 1
  %1481 = mul <8 x i64> %1478, splat (i64 32)
  %1482 = add <8 x i64> %1480, %1481
  %1483 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1479, 0
  %1484 = insertvalue { <8 x ptr>, <8 x i64> } %1483, <8 x i64> %1482, 1
  %1485 = extractvalue { <8 x ptr>, <8 x i64> } %1484, 0
  %1486 = extractvalue { <8 x ptr>, <8 x i64> } %1484, 1
  %1487 = getelementptr i8, <8 x ptr> %1485, <8 x i64> %1486
  %1488 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1487, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state363 = load <8 x float>, ptr %.slot92, align 32
  %1489 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state363, <8 x float> %1488)
  %.state364 = load <8 x i64>, ptr %.slot91, align 64
  %1490 = add <8 x i64> %.state364, splat (i64 1)
  %1491 = select <8 x i1> %80, <8 x i64> %1490, <8 x i64> zeroinitializer
  %1492 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1493 = sdiv <8 x i64> %1491, %1492
  %.spill.load365 = load i64, ptr %.spill83, align 4
  %.splatinsert366 = insertelement <8 x i64> poison, i64 %.spill.load365, i64 0
  %.splat367 = shufflevector <8 x i64> %.splatinsert366, <8 x i64> poison, <8 x i32> zeroinitializer
  %1494 = add <8 x i64> %.splat367, %1493
  %tile_snapshot.spill.load368 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1495 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load368, 0
  %1496 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load368, 1
  %1497 = mul <8 x i64> %1494, splat (i64 32)
  %1498 = add <8 x i64> %1496, %1497
  %1499 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1495, 0
  %1500 = insertvalue { <8 x ptr>, <8 x i64> } %1499, <8 x i64> %1498, 1
  %1501 = extractvalue { <8 x ptr>, <8 x i64> } %1500, 0
  %1502 = extractvalue { <8 x ptr>, <8 x i64> } %1500, 1
  %1503 = getelementptr i8, <8 x ptr> %1501, <8 x i64> %1502
  %1504 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1503, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state369 = load <8 x float>, ptr %.slot93, align 32
  %1505 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state369, <8 x float> %1504)
  %.state370 = load <8 x i64>, ptr %.slot91, align 64
  %1506 = add <8 x i64> %.state370, splat (i64 2)
  %1507 = select <8 x i1> %80, <8 x i64> %1506, <8 x i64> zeroinitializer
  %1508 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1509 = sdiv <8 x i64> %1507, %1508
  %.spill.load371 = load i64, ptr %.spill83, align 4
  %.splatinsert372 = insertelement <8 x i64> poison, i64 %.spill.load371, i64 0
  %.splat373 = shufflevector <8 x i64> %.splatinsert372, <8 x i64> poison, <8 x i32> zeroinitializer
  %1510 = add <8 x i64> %.splat373, %1509
  %tile_snapshot.spill.load374 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load374, 0
  %1512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load374, 1
  %1513 = mul <8 x i64> %1510, splat (i64 32)
  %1514 = add <8 x i64> %1512, %1513
  %1515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1511, 0
  %1516 = insertvalue { <8 x ptr>, <8 x i64> } %1515, <8 x i64> %1514, 1
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %1516, 0
  %1518 = extractvalue { <8 x ptr>, <8 x i64> } %1516, 1
  %1519 = getelementptr i8, <8 x ptr> %1517, <8 x i64> %1518
  %1520 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1519, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state375 = load <8 x float>, ptr %.slot94, align 32
  %1521 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state375, <8 x float> %1520)
  %.state376 = load <8 x i64>, ptr %.slot91, align 64
  %1522 = add <8 x i64> %.state376, splat (i64 3)
  %1523 = select <8 x i1> %80, <8 x i64> %1522, <8 x i64> zeroinitializer
  %1524 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1525 = sdiv <8 x i64> %1523, %1524
  %.spill.load377 = load i64, ptr %.spill83, align 4
  %.splatinsert378 = insertelement <8 x i64> poison, i64 %.spill.load377, i64 0
  %.splat379 = shufflevector <8 x i64> %.splatinsert378, <8 x i64> poison, <8 x i32> zeroinitializer
  %1526 = add <8 x i64> %.splat379, %1525
  %tile_snapshot.spill.load380 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load380, 0
  %1528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load380, 1
  %1529 = mul <8 x i64> %1526, splat (i64 32)
  %1530 = add <8 x i64> %1528, %1529
  %1531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1527, 0
  %1532 = insertvalue { <8 x ptr>, <8 x i64> } %1531, <8 x i64> %1530, 1
  %1533 = extractvalue { <8 x ptr>, <8 x i64> } %1532, 0
  %1534 = extractvalue { <8 x ptr>, <8 x i64> } %1532, 1
  %1535 = getelementptr i8, <8 x ptr> %1533, <8 x i64> %1534
  %1536 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1535, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state381 = load <8 x float>, ptr %.slot95, align 32
  %1537 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state381, <8 x float> %1536)
  %.state382 = load <8 x i64>, ptr %.slot91, align 64
  %1538 = add <8 x i64> %.state382, splat (i64 4)
  %1539 = load <8 x i64>, ptr %.slot91, align 64
  %1540 = select <8 x i1> %80, <8 x i64> %1538, <8 x i64> %1539
  store <8 x i64> %1540, ptr %.slot91, align 64
  %1541 = load <8 x float>, ptr %.slot92, align 32
  %1542 = select <8 x i1> %80, <8 x float> %1489, <8 x float> %1541
  store <8 x float> %1542, ptr %.slot92, align 32
  %1543 = load <8 x float>, ptr %.slot93, align 32
  %1544 = select <8 x i1> %80, <8 x float> %1505, <8 x float> %1543
  store <8 x float> %1544, ptr %.slot93, align 32
  %1545 = load <8 x float>, ptr %.slot94, align 32
  %1546 = select <8 x i1> %80, <8 x float> %1521, <8 x float> %1545
  store <8 x float> %1546, ptr %.slot94, align 32
  %1547 = load <8 x float>, ptr %.slot95, align 32
  %1548 = select <8 x i1> %80, <8 x float> %1537, <8 x float> %1547
  store <8 x float> %1548, ptr %.slot95, align 32
  br label %direct.schedule.33

direct.schedule.35:                               ; preds = %direct.false357
  store i64 64, ptr %.spill96, align 4
  %.spill.load383 = load i64, ptr %.spill83, align 4
  %1549 = add i64 %.spill.load383, 64
  store i64 %1549, ptr %.spill97, align 4
  %tile_snapshot.spill.load384 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1550 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 0
  %1551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load384, 1
  %.splatinsert385 = insertelement <8 x i64> poison, i64 %1549, i64 0
  %.splat386 = shufflevector <8 x i64> %.splatinsert385, <8 x i64> poison, <8 x i32> zeroinitializer
  %1552 = mul <8 x i64> %.splat386, splat (i64 32)
  %1553 = add <8 x i64> %1551, %1552
  %1554 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1550, 0
  %1555 = insertvalue { <8 x ptr>, <8 x i64> } %1554, <8 x i64> %1553, 1
  %1556 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1557 = extractvalue { <8 x ptr>, <8 x i64> } %1555, 1
  %1558 = extractelement <8 x ptr> %1556, i32 0
  %1559 = extractelement <8 x i64> %1557, i32 0
  %1560 = sub i64 %1559, 0
  %1561 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1562 = select i1 %1561, i64 %1560, i64 0
  %private.contiguous.address387 = getelementptr i8, ptr %1558, i64 %1562
  %private.contiguous.load388 = load <8 x float>, ptr %private.contiguous.address387, align 4
  %1563 = select <8 x i1> %80, <8 x float> %private.contiguous.load388, <8 x float> zeroinitializer
  %.state389 = load <8 x float>, ptr %.slot92, align 32
  %1564 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state389, <8 x float> %1563)
  %1565 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> splat (float 0xFFF0000000000000), <8 x float> %1564)
  %.state390 = load <8 x float>, ptr %.slot93, align 32
  %1566 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %1565, <8 x float> %.state390)
  %.state391 = load <8 x float>, ptr %.slot94, align 32
  %1567 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %1566, <8 x float> %.state391)
  %.state392 = load <8 x float>, ptr %.slot95, align 32
  %1568 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %1567, <8 x float> %.state392)
  %1569 = load <8 x float>, ptr %.spill98, align 32
  %1570 = select <8 x i1> %80, <8 x float> %1568, <8 x float> %1569
  store <8 x float> %1570, ptr %.spill98, align 32
  %.spill.load393 = load i64, ptr %.spill82, align 4
  %1571 = add i64 %.spill.load393, 1
  %1572 = mul i64 %1571, 65
  store i64 %1572, ptr %.spill99, align 4
  %.spill.load394 = load i64, ptr %.spill81, align 4
  %1573 = add i64 %1572, %.spill.load394
  store i64 %1573, ptr %.spill100, align 4
  %tile_snapshot.spill.load395 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1574 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 0
  %1575 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 1
  %.splatinsert396 = insertelement <8 x i64> poison, i64 %1573, i64 0
  %.splat397 = shufflevector <8 x i64> %.splatinsert396, <8 x i64> poison, <8 x i32> zeroinitializer
  %1576 = mul <8 x i64> %.splat397, splat (i64 32)
  %1577 = add <8 x i64> %1575, %1576
  %1578 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1574, 0
  %1579 = insertvalue { <8 x ptr>, <8 x i64> } %1578, <8 x i64> %1577, 1
  %1580 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1581 = extractvalue { <8 x ptr>, <8 x i64> } %1579, 1
  %1582 = extractelement <8 x ptr> %1580, i32 0
  %1583 = extractelement <8 x i64> %1581, i32 0
  %1584 = sub i64 %1583, 0
  %1585 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1586 = select i1 %1585, i64 %1584, i64 0
  %private.contiguous.address398 = getelementptr i8, ptr %1582, i64 %1586
  %private.contiguous.load399 = load <8 x float>, ptr %private.contiguous.address398, align 4
  %1587 = select <8 x i1> %80, <8 x float> %private.contiguous.load399, <8 x float> zeroinitializer
  %.spill.load400 = load i64, ptr %.spill85, align 4
  %1588 = add i64 %1572, %.spill.load400
  store i64 %1588, ptr %.spill101, align 4
  %tile_snapshot.spill.load401 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load401, 0
  %1590 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load401, 1
  %.splatinsert402 = insertelement <8 x i64> poison, i64 %1588, i64 0
  %.splat403 = shufflevector <8 x i64> %.splatinsert402, <8 x i64> poison, <8 x i32> zeroinitializer
  %1591 = mul <8 x i64> %.splat403, splat (i64 32)
  %1592 = add <8 x i64> %1590, %1591
  %1593 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1589, 0
  %1594 = insertvalue { <8 x ptr>, <8 x i64> } %1593, <8 x i64> %1592, 1
  %1595 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1596 = extractvalue { <8 x ptr>, <8 x i64> } %1594, 1
  %1597 = extractelement <8 x ptr> %1595, i32 0
  %1598 = extractelement <8 x i64> %1596, i32 0
  %1599 = sub i64 %1598, 0
  %1600 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1601 = select i1 %1600, i64 %1599, i64 0
  %private.contiguous.address404 = getelementptr i8, ptr %1597, i64 %1601
  %private.contiguous.load405 = load <8 x float>, ptr %private.contiguous.address404, align 4
  %1602 = select <8 x i1> %80, <8 x float> %private.contiguous.load405, <8 x float> zeroinitializer
  %.spill.load406 = load i64, ptr %.spill87, align 4
  %1603 = add i64 %1572, %.spill.load406
  store i64 %1603, ptr %.spill102, align 4
  %tile_snapshot.spill.load407 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load407, 1
  %.splatinsert408 = insertelement <8 x i64> poison, i64 %1603, i64 0
  %.splat409 = shufflevector <8 x i64> %.splatinsert408, <8 x i64> poison, <8 x i32> zeroinitializer
  %1606 = mul <8 x i64> %.splat409, splat (i64 32)
  %1607 = add <8 x i64> %1605, %1606
  %1608 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1604, 0
  %1609 = insertvalue { <8 x ptr>, <8 x i64> } %1608, <8 x i64> %1607, 1
  %1610 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1611 = extractvalue { <8 x ptr>, <8 x i64> } %1609, 1
  %1612 = extractelement <8 x ptr> %1610, i32 0
  %1613 = extractelement <8 x i64> %1611, i32 0
  %1614 = sub i64 %1613, 0
  %1615 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1616 = select i1 %1615, i64 %1614, i64 0
  %private.contiguous.address410 = getelementptr i8, ptr %1612, i64 %1616
  %private.contiguous.load411 = load <8 x float>, ptr %private.contiguous.address410, align 4
  %1617 = select <8 x i1> %80, <8 x float> %private.contiguous.load411, <8 x float> zeroinitializer
  %.spill.load412 = load i64, ptr %.spill89, align 4
  %1618 = add i64 %1572, %.spill.load412
  store i64 %1618, ptr %.spill103, align 4
  %tile_snapshot.spill.load413 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1619 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load413, 0
  %1620 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load413, 1
  %.splatinsert414 = insertelement <8 x i64> poison, i64 %1618, i64 0
  %.splat415 = shufflevector <8 x i64> %.splatinsert414, <8 x i64> poison, <8 x i32> zeroinitializer
  %1621 = mul <8 x i64> %.splat415, splat (i64 32)
  %1622 = add <8 x i64> %1620, %1621
  %1623 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1619, 0
  %1624 = insertvalue { <8 x ptr>, <8 x i64> } %1623, <8 x i64> %1622, 1
  %1625 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %1624, 1
  %1627 = extractelement <8 x ptr> %1625, i32 0
  %1628 = extractelement <8 x i64> %1626, i32 0
  %1629 = sub i64 %1628, 0
  %1630 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1631 = select i1 %1630, i64 %1629, i64 0
  %private.contiguous.address416 = getelementptr i8, ptr %1627, i64 %1631
  %private.contiguous.load417 = load <8 x float>, ptr %private.contiguous.address416, align 4
  %1632 = select <8 x i1> %80, <8 x float> %private.contiguous.load417, <8 x float> zeroinitializer
  %1633 = load <8 x i64>, ptr %.slot104, align 64
  %1634 = select <8 x i1> %80, <8 x i64> splat (i64 4), <8 x i64> %1633
  store <8 x i64> %1634, ptr %.slot104, align 64
  %1635 = load <8 x float>, ptr %.slot105, align 32
  %1636 = select <8 x i1> %80, <8 x float> %1587, <8 x float> %1635
  store <8 x float> %1636, ptr %.slot105, align 32
  %1637 = load <8 x float>, ptr %.slot106, align 32
  %1638 = select <8 x i1> %80, <8 x float> %1602, <8 x float> %1637
  store <8 x float> %1638, ptr %.slot106, align 32
  %1639 = load <8 x float>, ptr %.slot107, align 32
  %1640 = select <8 x i1> %80, <8 x float> %1617, <8 x float> %1639
  store <8 x float> %1640, ptr %.slot107, align 32
  %1641 = load <8 x float>, ptr %.slot108, align 32
  %1642 = select <8 x i1> %80, <8 x float> %1632, <8 x float> %1641
  store <8 x float> %1642, ptr %.slot108, align 32
  br label %direct.schedule.36

direct.schedule.36:                               ; preds = %direct.schedule.37, %direct.schedule.35
  %.state418 = load <8 x i64>, ptr %.slot104, align 64
  %1643 = icmp slt <8 x i64> %.state418, splat (i64 64)
  %1644 = extractelement <8 x i1> %1643, i32 0
  br i1 %1644, label %direct.true419, label %direct.false420

direct.schedule.37:                               ; preds = %direct.true419
  %.state421 = load <8 x i64>, ptr %.slot104, align 64
  %1645 = add <8 x i64> %.state421, zeroinitializer
  %1646 = select <8 x i1> %80, <8 x i64> %1645, <8 x i64> zeroinitializer
  %1647 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1648 = sdiv <8 x i64> %1646, %1647
  %.spill.load422 = load i64, ptr %.spill99, align 4
  %.splatinsert423 = insertelement <8 x i64> poison, i64 %.spill.load422, i64 0
  %.splat424 = shufflevector <8 x i64> %.splatinsert423, <8 x i64> poison, <8 x i32> zeroinitializer
  %1649 = add <8 x i64> %.splat424, %1648
  %tile_snapshot.spill.load425 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1650 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load425, 0
  %1651 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load425, 1
  %1652 = mul <8 x i64> %1649, splat (i64 32)
  %1653 = add <8 x i64> %1651, %1652
  %1654 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1650, 0
  %1655 = insertvalue { <8 x ptr>, <8 x i64> } %1654, <8 x i64> %1653, 1
  %1656 = extractvalue { <8 x ptr>, <8 x i64> } %1655, 0
  %1657 = extractvalue { <8 x ptr>, <8 x i64> } %1655, 1
  %1658 = getelementptr i8, <8 x ptr> %1656, <8 x i64> %1657
  %1659 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1658, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state426 = load <8 x float>, ptr %.slot105, align 32
  %1660 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state426, <8 x float> %1659)
  %.state427 = load <8 x i64>, ptr %.slot104, align 64
  %1661 = add <8 x i64> %.state427, splat (i64 1)
  %1662 = select <8 x i1> %80, <8 x i64> %1661, <8 x i64> zeroinitializer
  %1663 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1664 = sdiv <8 x i64> %1662, %1663
  %.spill.load428 = load i64, ptr %.spill99, align 4
  %.splatinsert429 = insertelement <8 x i64> poison, i64 %.spill.load428, i64 0
  %.splat430 = shufflevector <8 x i64> %.splatinsert429, <8 x i64> poison, <8 x i32> zeroinitializer
  %1665 = add <8 x i64> %.splat430, %1664
  %tile_snapshot.spill.load431 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load431, 0
  %1667 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load431, 1
  %1668 = mul <8 x i64> %1665, splat (i64 32)
  %1669 = add <8 x i64> %1667, %1668
  %1670 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1666, 0
  %1671 = insertvalue { <8 x ptr>, <8 x i64> } %1670, <8 x i64> %1669, 1
  %1672 = extractvalue { <8 x ptr>, <8 x i64> } %1671, 0
  %1673 = extractvalue { <8 x ptr>, <8 x i64> } %1671, 1
  %1674 = getelementptr i8, <8 x ptr> %1672, <8 x i64> %1673
  %1675 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1674, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state432 = load <8 x float>, ptr %.slot106, align 32
  %1676 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state432, <8 x float> %1675)
  %.state433 = load <8 x i64>, ptr %.slot104, align 64
  %1677 = add <8 x i64> %.state433, splat (i64 2)
  %1678 = select <8 x i1> %80, <8 x i64> %1677, <8 x i64> zeroinitializer
  %1679 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1680 = sdiv <8 x i64> %1678, %1679
  %.spill.load434 = load i64, ptr %.spill99, align 4
  %.splatinsert435 = insertelement <8 x i64> poison, i64 %.spill.load434, i64 0
  %.splat436 = shufflevector <8 x i64> %.splatinsert435, <8 x i64> poison, <8 x i32> zeroinitializer
  %1681 = add <8 x i64> %.splat436, %1680
  %tile_snapshot.spill.load437 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1682 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load437, 0
  %1683 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load437, 1
  %1684 = mul <8 x i64> %1681, splat (i64 32)
  %1685 = add <8 x i64> %1683, %1684
  %1686 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1682, 0
  %1687 = insertvalue { <8 x ptr>, <8 x i64> } %1686, <8 x i64> %1685, 1
  %1688 = extractvalue { <8 x ptr>, <8 x i64> } %1687, 0
  %1689 = extractvalue { <8 x ptr>, <8 x i64> } %1687, 1
  %1690 = getelementptr i8, <8 x ptr> %1688, <8 x i64> %1689
  %1691 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1690, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state438 = load <8 x float>, ptr %.slot107, align 32
  %1692 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state438, <8 x float> %1691)
  %.state439 = load <8 x i64>, ptr %.slot104, align 64
  %1693 = add <8 x i64> %.state439, splat (i64 3)
  %1694 = select <8 x i1> %80, <8 x i64> %1693, <8 x i64> zeroinitializer
  %1695 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1696 = sdiv <8 x i64> %1694, %1695
  %.spill.load440 = load i64, ptr %.spill99, align 4
  %.splatinsert441 = insertelement <8 x i64> poison, i64 %.spill.load440, i64 0
  %.splat442 = shufflevector <8 x i64> %.splatinsert441, <8 x i64> poison, <8 x i32> zeroinitializer
  %1697 = add <8 x i64> %.splat442, %1696
  %tile_snapshot.spill.load443 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 0
  %1699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load443, 1
  %1700 = mul <8 x i64> %1697, splat (i64 32)
  %1701 = add <8 x i64> %1699, %1700
  %1702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1698, 0
  %1703 = insertvalue { <8 x ptr>, <8 x i64> } %1702, <8 x i64> %1701, 1
  %1704 = extractvalue { <8 x ptr>, <8 x i64> } %1703, 0
  %1705 = extractvalue { <8 x ptr>, <8 x i64> } %1703, 1
  %1706 = getelementptr i8, <8 x ptr> %1704, <8 x i64> %1705
  %1707 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1706, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state444 = load <8 x float>, ptr %.slot108, align 32
  %1708 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state444, <8 x float> %1707)
  %.state445 = load <8 x i64>, ptr %.slot104, align 64
  %1709 = add <8 x i64> %.state445, splat (i64 4)
  %1710 = load <8 x i64>, ptr %.slot104, align 64
  %1711 = select <8 x i1> %80, <8 x i64> %1709, <8 x i64> %1710
  store <8 x i64> %1711, ptr %.slot104, align 64
  %1712 = load <8 x float>, ptr %.slot105, align 32
  %1713 = select <8 x i1> %80, <8 x float> %1660, <8 x float> %1712
  store <8 x float> %1713, ptr %.slot105, align 32
  %1714 = load <8 x float>, ptr %.slot106, align 32
  %1715 = select <8 x i1> %80, <8 x float> %1676, <8 x float> %1714
  store <8 x float> %1715, ptr %.slot106, align 32
  %1716 = load <8 x float>, ptr %.slot107, align 32
  %1717 = select <8 x i1> %80, <8 x float> %1692, <8 x float> %1716
  store <8 x float> %1717, ptr %.slot107, align 32
  %1718 = load <8 x float>, ptr %.slot108, align 32
  %1719 = select <8 x i1> %80, <8 x float> %1708, <8 x float> %1718
  store <8 x float> %1719, ptr %.slot108, align 32
  br label %direct.schedule.36

direct.schedule.38:                               ; preds = %direct.false420
  %.spill.load446 = load i64, ptr %.spill99, align 4
  %.spill.load447 = load i64, ptr %.spill96, align 4
  %1720 = add i64 %.spill.load446, %.spill.load447
  store i64 %1720, ptr %.spill109, align 4
  %tile_snapshot.spill.load448 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1721 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load448, 0
  %1722 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load448, 1
  %.splatinsert449 = insertelement <8 x i64> poison, i64 %1720, i64 0
  %.splat450 = shufflevector <8 x i64> %.splatinsert449, <8 x i64> poison, <8 x i32> zeroinitializer
  %1723 = mul <8 x i64> %.splat450, splat (i64 32)
  %1724 = add <8 x i64> %1722, %1723
  %1725 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1721, 0
  %1726 = insertvalue { <8 x ptr>, <8 x i64> } %1725, <8 x i64> %1724, 1
  %1727 = extractvalue { <8 x ptr>, <8 x i64> } %26, 0
  %1728 = extractvalue { <8 x ptr>, <8 x i64> } %1726, 1
  %1729 = extractelement <8 x ptr> %1727, i32 0
  %1730 = extractelement <8 x i64> %1728, i32 0
  %1731 = sub i64 %1730, 0
  %1732 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1733 = select i1 %1732, i64 %1731, i64 0
  %private.contiguous.address451 = getelementptr i8, ptr %1729, i64 %1733
  %private.contiguous.load452 = load <8 x float>, ptr %private.contiguous.address451, align 4
  %1734 = select <8 x i1> %80, <8 x float> %private.contiguous.load452, <8 x float> zeroinitializer
  %.state453 = load <8 x float>, ptr %.slot105, align 32
  %1735 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state453, <8 x float> %1734)
  %1736 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> splat (float 0xFFF0000000000000), <8 x float> %1735)
  %.state454 = load <8 x float>, ptr %.slot106, align 32
  %1737 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %1736, <8 x float> %.state454)
  %.state455 = load <8 x float>, ptr %.slot107, align 32
  %1738 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %1737, <8 x float> %.state455)
  %.state456 = load <8 x float>, ptr %.slot108, align 32
  %1739 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %1738, <8 x float> %.state456)
  %.state457 = load <8 x float>, ptr %.slot45, align 32
  %.spill.load458 = load <8 x float>, ptr %.spill98, align 32
  %1740 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state457, <8 x float> %.spill.load458)
  %1741 = load <8 x float>, ptr %.spill110, align 32
  %1742 = select <8 x i1> %80, <8 x float> %1740, <8 x float> %1741
  store <8 x float> %1742, ptr %.spill110, align 32
  %.state459 = load <8 x float>, ptr %.slot46, align 32
  %1743 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state459, <8 x float> %1739)
  %1744 = load <8 x float>, ptr %.spill111, align 32
  %1745 = select <8 x i1> %80, <8 x float> %1743, <8 x float> %1744
  store <8 x float> %1745, ptr %.spill111, align 32
  %1746 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %1747 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %1746, 0
  %1749 = select <8 x i1> %80, <8 x ptr> %1747, <8 x ptr> %1748
  %1750 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %1751 = extractvalue { <8 x ptr>, <8 x i64> } %1746, 1
  %1752 = select <8 x i1> %80, <8 x i64> %1750, <8 x i64> %1751
  %1753 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1749, 0
  %1754 = insertvalue { <8 x ptr>, <8 x i64> } %1753, <8 x i64> %1752, 1
  store { <8 x ptr>, <8 x i64> } %1754, ptr %tile_snapshot.spill112, align 64
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1756 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %1757 = add <8 x i64> %1756, zeroinitializer
  %1758 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1755, 0
  %1759 = insertvalue { <8 x ptr>, <8 x i64> } %1758, <8 x i64> %1757, 1
  %1760 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1761 = extractvalue { <8 x ptr>, <8 x i64> } %1759, 1
  %1762 = extractelement <8 x ptr> %1760, i32 0
  %1763 = extractelement <8 x i64> %1761, i32 0
  %1764 = sub i64 %1763, 0
  %1765 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1766 = select i1 %1765, i64 %1764, i64 0
  %private.contiguous.address460 = getelementptr i8, ptr %1762, i64 %1766
  %private.contiguous.preserve461 = load <8 x float>, ptr %private.contiguous.address460, align 4
  %1767 = select <8 x i1> %80, <8 x float> %1740, <8 x float> %private.contiguous.preserve461
  store <8 x float> %1767, ptr %private.contiguous.address460, align 4
  %1768 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1769 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %1770 = add <8 x i64> %1769, splat (i64 32)
  %1771 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1768, 0
  %1772 = insertvalue { <8 x ptr>, <8 x i64> } %1771, <8 x i64> %1770, 1
  %1773 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1774 = extractvalue { <8 x ptr>, <8 x i64> } %1772, 1
  %1775 = extractelement <8 x ptr> %1773, i32 0
  %1776 = extractelement <8 x i64> %1774, i32 0
  %1777 = sub i64 %1776, 0
  %1778 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1779 = select i1 %1778, i64 %1777, i64 0
  %private.contiguous.address462 = getelementptr i8, ptr %1775, i64 %1779
  %private.contiguous.preserve463 = load <8 x float>, ptr %private.contiguous.address462, align 4
  %1780 = select <8 x i1> %80, <8 x float> %1743, <8 x float> %private.contiguous.preserve463
  store <8 x float> %1780, ptr %private.contiguous.address462, align 4
  %.state464 = load <8 x float>, ptr %.slot45, align 32
  %1781 = fsub <8 x float> %.state464, %1740
  %.state465 = load <8 x float>, ptr %.slot46, align 32
  %1782 = fsub <8 x float> %.state465, %1743
  %1783 = select <8 x i1> %80, <8 x float> %1781, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1783)
  %1784 = load <8 x float>, ptr %.spill113, align 32
  %1785 = select <8 x i1> %80, <8 x float> %native.exp, <8 x float> %1784
  store <8 x float> %1785, ptr %.spill113, align 32
  %1786 = select <8 x i1> %80, <8 x float> %1782, <8 x float> zeroinitializer
  %native.exp466 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1786)
  %1787 = load <8 x float>, ptr %.spill114, align 32
  %1788 = select <8 x i1> %80, <8 x float> %native.exp466, <8 x float> %1787
  store <8 x float> %1788, ptr %.spill114, align 32
  %1789 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1790 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1791 = extractvalue { <8 x ptr>, <8 x i64> } %1789, 0
  %1792 = select <8 x i1> %80, <8 x ptr> %1790, <8 x ptr> %1791
  %1793 = extractvalue { <8 x ptr>, <8 x i64> } %32, 1
  %1794 = extractvalue { <8 x ptr>, <8 x i64> } %1789, 1
  %1795 = select <8 x i1> %80, <8 x i64> %1793, <8 x i64> %1794
  %1796 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1792, 0
  %1797 = insertvalue { <8 x ptr>, <8 x i64> } %1796, <8 x i64> %1795, 1
  store { <8 x ptr>, <8 x i64> } %1797, ptr %tile_snapshot.spill115, align 64
  %1798 = load <8 x i64>, ptr %.slot116, align 64
  %1799 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %1798
  store <8 x i64> %1799, ptr %.slot116, align 64
  br label %direct.schedule.39

direct.schedule.39:                               ; preds = %direct.schedule.40, %direct.schedule.38
  %.state467 = load <8 x i64>, ptr %.slot116, align 64
  %1800 = icmp slt <8 x i64> %.state467, splat (i64 130)
  %1801 = extractelement <8 x i1> %1800, i32 0
  br i1 %1801, label %direct.true468, label %direct.false469

direct.schedule.40:                               ; preds = %direct.true468
  %.state470 = load <8 x i64>, ptr %.slot116, align 64
  %1802 = select <8 x i1> %80, <8 x i64> %.state470, <8 x i64> zeroinitializer
  %1803 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1804 = srem <8 x i64> %1802, %1803
  %.state471 = load <8 x i64>, ptr %.slot116, align 64
  %1805 = select <8 x i1> %80, <8 x i64> %.state471, <8 x i64> zeroinitializer
  %1806 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1807 = sdiv <8 x i64> %1805, %1806
  %1808 = add <8 x i64> zeroinitializer, %1804
  %1809 = mul <8 x i64> %1808, splat (i64 2)
  %1810 = add <8 x i64> %1809, %1807
  %tile_snapshot.spill.load472 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill77, align 64
  %1811 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 0
  %1812 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 1
  %1813 = add <8 x i64> %1812, %1810
  %1814 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1811, 0
  %1815 = insertvalue { <8 x ptr>, <8 x i64> } %1814, <8 x i64> %1813, 1
  %1816 = extractvalue { <8 x ptr>, <8 x i64> } %1815, 0
  %1817 = extractvalue { <8 x ptr>, <8 x i64> } %1815, 1
  %1818 = getelementptr i8, <8 x ptr> %1816, <8 x i64> %1817
  %1819 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1818, <8 x i1> %80, <8 x i8> zeroinitializer)
  %1820 = icmp ne <8 x i8> %1819, zeroinitializer
  %1821 = add <8 x i64> zeroinitializer, %1807
  %1822 = mul <8 x i64> %1821, splat (i64 65)
  %1823 = add <8 x i64> %1822, %1804
  %1824 = select <8 x i1> %80, <8 x i64> %1823, <8 x i64> zeroinitializer
  %1825 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1826 = srem <8 x i64> %1824, %1825
  %1827 = select <8 x i1> %80, <8 x i64> %1823, <8 x i64> zeroinitializer
  %1828 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1829 = sdiv <8 x i64> %1827, %1828
  %1830 = add <8 x i64> zeroinitializer, %1829
  %1831 = mul <8 x i64> %1830, splat (i64 65)
  %1832 = add <8 x i64> %1831, %1826
  %1833 = select <8 x i1> %80, <8 x i64> %1832, <8 x i64> zeroinitializer
  %1834 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1835 = srem <8 x i64> %1833, %1834
  %1836 = select <8 x i1> %80, <8 x i64> %1832, <8 x i64> zeroinitializer
  %1837 = select <8 x i1> %80, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %1838 = sdiv <8 x i64> %1836, %1837
  %1839 = add <8 x i64> zeroinitializer, %1838
  %1840 = mul <8 x i64> %1839, splat (i64 65)
  %1841 = add <8 x i64> %1840, %1835
  %tile_snapshot.spill.load473 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill79, align 64
  %1842 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load473, 0
  %1843 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load473, 1
  %1844 = mul <8 x i64> %1841, splat (i64 32)
  %1845 = add <8 x i64> %1843, %1844
  %1846 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1842, 0
  %1847 = insertvalue { <8 x ptr>, <8 x i64> } %1846, <8 x i64> %1845, 1
  %1848 = extractvalue { <8 x ptr>, <8 x i64> } %1847, 0
  %1849 = extractvalue { <8 x ptr>, <8 x i64> } %1847, 1
  %1850 = getelementptr i8, <8 x ptr> %1848, <8 x i64> %1849
  %1851 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1850, <8 x i1> %80, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load474 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %1852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 0
  %1853 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load474, 1
  %1854 = mul <8 x i64> %1839, splat (i64 32)
  %1855 = add <8 x i64> %1853, %1854
  %1856 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1852, 0
  %1857 = insertvalue { <8 x ptr>, <8 x i64> } %1856, <8 x i64> %1855, 1
  %1858 = extractvalue { <8 x ptr>, <8 x i64> } %1857, 0
  %1859 = extractvalue { <8 x ptr>, <8 x i64> } %1857, 1
  %1860 = getelementptr i8, <8 x ptr> %1858, <8 x i64> %1859
  %1861 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1860, <8 x i1> %80, <8 x float> zeroinitializer)
  %1862 = fsub <8 x float> %1851, %1861
  %1863 = select <8 x i1> %80, <8 x float> %1862, <8 x float> zeroinitializer
  %native.exp475 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1863)
  %1864 = select <8 x i1> %1820, <8 x float> %native.exp475, <8 x float> zeroinitializer
  %tile_snapshot.spill.load476 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1865 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load476, 0
  %1866 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load476, 1
  %.state477 = load <8 x i64>, ptr %.slot116, align 64
  %1867 = mul <8 x i64> %.state477, splat (i64 32)
  %1868 = add <8 x i64> %1866, %1867
  %1869 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1865, 0
  %1870 = insertvalue { <8 x ptr>, <8 x i64> } %1869, <8 x i64> %1868, 1
  %1871 = extractvalue { <8 x ptr>, <8 x i64> } %1870, 0
  %1872 = extractvalue { <8 x ptr>, <8 x i64> } %1870, 1
  %1873 = getelementptr i8, <8 x ptr> %1871, <8 x i64> %1872
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %1864, <8 x ptr> align 1 %1873, <8 x i1> %80)
  %.state478 = load <8 x i64>, ptr %.slot116, align 64
  %1874 = add <8 x i64> %.state478, splat (i64 1)
  %1875 = load <8 x i64>, ptr %.slot116, align 64
  %1876 = select <8 x i1> %80, <8 x i64> %1874, <8 x i64> %1875
  store <8 x i64> %1876, ptr %.slot116, align 64
  br label %direct.schedule.39

direct.schedule.41:                               ; preds = %direct.false469
  %.state479 = load <8 x float>, ptr %.slot47, align 32
  %.spill.load480 = load <8 x float>, ptr %.spill113, align 32
  %1877 = fmul <8 x float> %.state479, %.spill.load480
  %1878 = load <8 x float>, ptr %.spill117, align 32
  %1879 = select <8 x i1> %80, <8 x float> %1877, <8 x float> %1878
  store <8 x float> %1879, ptr %.spill117, align 32
  %.state481 = load <8 x float>, ptr %.slot48, align 32
  %.spill.load482 = load <8 x float>, ptr %.spill114, align 32
  %1880 = fmul <8 x float> %.state481, %.spill.load482
  %1881 = load <8 x float>, ptr %.spill118, align 32
  %1882 = select <8 x i1> %80, <8 x float> %1880, <8 x float> %1881
  store <8 x float> %1882, ptr %.spill118, align 32
  %tile_snapshot.spill.load483 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load483, 0
  %1884 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load483, 1
  %.spill.load484 = load i64, ptr %.spill84, align 4
  %.splatinsert485 = insertelement <8 x i64> poison, i64 %.spill.load484, i64 0
  %.splat486 = shufflevector <8 x i64> %.splatinsert485, <8 x i64> poison, <8 x i32> zeroinitializer
  %1885 = mul <8 x i64> %.splat486, splat (i64 32)
  %1886 = add <8 x i64> %1884, %1885
  %1887 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1883, 0
  %1888 = insertvalue { <8 x ptr>, <8 x i64> } %1887, <8 x i64> %1886, 1
  %1889 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1890 = extractvalue { <8 x ptr>, <8 x i64> } %1888, 1
  %1891 = extractelement <8 x ptr> %1889, i32 0
  %1892 = extractelement <8 x i64> %1890, i32 0
  %1893 = sub i64 %1892, 0
  %1894 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1895 = select i1 %1894, i64 %1893, i64 0
  %private.contiguous.address487 = getelementptr i8, ptr %1891, i64 %1895
  %private.contiguous.load488 = load <8 x float>, ptr %private.contiguous.address487, align 4
  %1896 = select <8 x i1> %80, <8 x float> %private.contiguous.load488, <8 x float> zeroinitializer
  %tile_snapshot.spill.load489 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1897 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 0
  %1898 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load489, 1
  %.spill.load490 = load i64, ptr %.spill86, align 4
  %.splatinsert491 = insertelement <8 x i64> poison, i64 %.spill.load490, i64 0
  %.splat492 = shufflevector <8 x i64> %.splatinsert491, <8 x i64> poison, <8 x i32> zeroinitializer
  %1899 = mul <8 x i64> %.splat492, splat (i64 32)
  %1900 = add <8 x i64> %1898, %1899
  %1901 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1897, 0
  %1902 = insertvalue { <8 x ptr>, <8 x i64> } %1901, <8 x i64> %1900, 1
  %1903 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1904 = extractvalue { <8 x ptr>, <8 x i64> } %1902, 1
  %1905 = extractelement <8 x ptr> %1903, i32 0
  %1906 = extractelement <8 x i64> %1904, i32 0
  %1907 = sub i64 %1906, 0
  %1908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1909 = select i1 %1908, i64 %1907, i64 0
  %private.contiguous.address493 = getelementptr i8, ptr %1905, i64 %1909
  %private.contiguous.load494 = load <8 x float>, ptr %private.contiguous.address493, align 4
  %1910 = select <8 x i1> %80, <8 x float> %private.contiguous.load494, <8 x float> zeroinitializer
  %tile_snapshot.spill.load495 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1911 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load495, 0
  %1912 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load495, 1
  %.spill.load496 = load i64, ptr %.spill88, align 4
  %.splatinsert497 = insertelement <8 x i64> poison, i64 %.spill.load496, i64 0
  %.splat498 = shufflevector <8 x i64> %.splatinsert497, <8 x i64> poison, <8 x i32> zeroinitializer
  %1913 = mul <8 x i64> %.splat498, splat (i64 32)
  %1914 = add <8 x i64> %1912, %1913
  %1915 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1911, 0
  %1916 = insertvalue { <8 x ptr>, <8 x i64> } %1915, <8 x i64> %1914, 1
  %1917 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1918 = extractvalue { <8 x ptr>, <8 x i64> } %1916, 1
  %1919 = extractelement <8 x ptr> %1917, i32 0
  %1920 = extractelement <8 x i64> %1918, i32 0
  %1921 = sub i64 %1920, 0
  %1922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1923 = select i1 %1922, i64 %1921, i64 0
  %private.contiguous.address499 = getelementptr i8, ptr %1919, i64 %1923
  %private.contiguous.load500 = load <8 x float>, ptr %private.contiguous.address499, align 4
  %1924 = select <8 x i1> %80, <8 x float> %private.contiguous.load500, <8 x float> zeroinitializer
  %tile_snapshot.spill.load501 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1925 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load501, 0
  %1926 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load501, 1
  %.spill.load502 = load i64, ptr %.spill90, align 4
  %.splatinsert503 = insertelement <8 x i64> poison, i64 %.spill.load502, i64 0
  %.splat504 = shufflevector <8 x i64> %.splatinsert503, <8 x i64> poison, <8 x i32> zeroinitializer
  %1927 = mul <8 x i64> %.splat504, splat (i64 32)
  %1928 = add <8 x i64> %1926, %1927
  %1929 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1925, 0
  %1930 = insertvalue { <8 x ptr>, <8 x i64> } %1929, <8 x i64> %1928, 1
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %1932 = extractvalue { <8 x ptr>, <8 x i64> } %1930, 1
  %1933 = extractelement <8 x ptr> %1931, i32 0
  %1934 = extractelement <8 x i64> %1932, i32 0
  %1935 = sub i64 %1934, 0
  %1936 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %1937 = select i1 %1936, i64 %1935, i64 0
  %private.contiguous.address505 = getelementptr i8, ptr %1933, i64 %1937
  %private.contiguous.load506 = load <8 x float>, ptr %private.contiguous.address505, align 4
  %1938 = select <8 x i1> %80, <8 x float> %private.contiguous.load506, <8 x float> zeroinitializer
  %1939 = load <8 x i64>, ptr %.slot119, align 64
  %1940 = select <8 x i1> %80, <8 x i64> splat (i64 4), <8 x i64> %1939
  store <8 x i64> %1940, ptr %.slot119, align 64
  %1941 = load <8 x float>, ptr %.slot120, align 32
  %1942 = select <8 x i1> %80, <8 x float> %1896, <8 x float> %1941
  store <8 x float> %1942, ptr %.slot120, align 32
  %1943 = load <8 x float>, ptr %.slot121, align 32
  %1944 = select <8 x i1> %80, <8 x float> %1910, <8 x float> %1943
  store <8 x float> %1944, ptr %.slot121, align 32
  %1945 = load <8 x float>, ptr %.slot122, align 32
  %1946 = select <8 x i1> %80, <8 x float> %1924, <8 x float> %1945
  store <8 x float> %1946, ptr %.slot122, align 32
  %1947 = load <8 x float>, ptr %.slot123, align 32
  %1948 = select <8 x i1> %80, <8 x float> %1938, <8 x float> %1947
  store <8 x float> %1948, ptr %.slot123, align 32
  br label %direct.schedule.42

direct.schedule.42:                               ; preds = %direct.schedule.43, %direct.schedule.41
  %.state507 = load <8 x i64>, ptr %.slot119, align 64
  %1949 = icmp slt <8 x i64> %.state507, splat (i64 64)
  %1950 = extractelement <8 x i1> %1949, i32 0
  br i1 %1950, label %direct.true508, label %direct.false509

direct.schedule.43:                               ; preds = %direct.true508
  %.state510 = load <8 x i64>, ptr %.slot119, align 64
  %1951 = add <8 x i64> %.state510, zeroinitializer
  %1952 = select <8 x i1> %80, <8 x i64> %1951, <8 x i64> zeroinitializer
  %1953 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1954 = sdiv <8 x i64> %1952, %1953
  %.spill.load511 = load i64, ptr %.spill83, align 4
  %.splatinsert512 = insertelement <8 x i64> poison, i64 %.spill.load511, i64 0
  %.splat513 = shufflevector <8 x i64> %.splatinsert512, <8 x i64> poison, <8 x i32> zeroinitializer
  %1955 = add <8 x i64> %.splat513, %1954
  %tile_snapshot.spill.load514 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1956 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load514, 0
  %1957 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load514, 1
  %1958 = mul <8 x i64> %1955, splat (i64 32)
  %1959 = add <8 x i64> %1957, %1958
  %1960 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1956, 0
  %1961 = insertvalue { <8 x ptr>, <8 x i64> } %1960, <8 x i64> %1959, 1
  %1962 = extractvalue { <8 x ptr>, <8 x i64> } %1961, 0
  %1963 = extractvalue { <8 x ptr>, <8 x i64> } %1961, 1
  %1964 = getelementptr i8, <8 x ptr> %1962, <8 x i64> %1963
  %1965 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1964, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state515 = load <8 x float>, ptr %.slot120, align 32
  %1966 = fadd <8 x float> %.state515, %1965
  %.state516 = load <8 x i64>, ptr %.slot119, align 64
  %1967 = add <8 x i64> %.state516, splat (i64 1)
  %1968 = select <8 x i1> %80, <8 x i64> %1967, <8 x i64> zeroinitializer
  %1969 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1970 = sdiv <8 x i64> %1968, %1969
  %.spill.load517 = load i64, ptr %.spill83, align 4
  %.splatinsert518 = insertelement <8 x i64> poison, i64 %.spill.load517, i64 0
  %.splat519 = shufflevector <8 x i64> %.splatinsert518, <8 x i64> poison, <8 x i32> zeroinitializer
  %1971 = add <8 x i64> %.splat519, %1970
  %tile_snapshot.spill.load520 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1972 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 0
  %1973 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load520, 1
  %1974 = mul <8 x i64> %1971, splat (i64 32)
  %1975 = add <8 x i64> %1973, %1974
  %1976 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1972, 0
  %1977 = insertvalue { <8 x ptr>, <8 x i64> } %1976, <8 x i64> %1975, 1
  %1978 = extractvalue { <8 x ptr>, <8 x i64> } %1977, 0
  %1979 = extractvalue { <8 x ptr>, <8 x i64> } %1977, 1
  %1980 = getelementptr i8, <8 x ptr> %1978, <8 x i64> %1979
  %1981 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1980, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state521 = load <8 x float>, ptr %.slot121, align 32
  %1982 = fadd <8 x float> %.state521, %1981
  %.state522 = load <8 x i64>, ptr %.slot119, align 64
  %1983 = add <8 x i64> %.state522, splat (i64 2)
  %1984 = select <8 x i1> %80, <8 x i64> %1983, <8 x i64> zeroinitializer
  %1985 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1986 = sdiv <8 x i64> %1984, %1985
  %.spill.load523 = load i64, ptr %.spill83, align 4
  %.splatinsert524 = insertelement <8 x i64> poison, i64 %.spill.load523, i64 0
  %.splat525 = shufflevector <8 x i64> %.splatinsert524, <8 x i64> poison, <8 x i32> zeroinitializer
  %1987 = add <8 x i64> %.splat525, %1986
  %tile_snapshot.spill.load526 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %1988 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load526, 0
  %1989 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load526, 1
  %1990 = mul <8 x i64> %1987, splat (i64 32)
  %1991 = add <8 x i64> %1989, %1990
  %1992 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1988, 0
  %1993 = insertvalue { <8 x ptr>, <8 x i64> } %1992, <8 x i64> %1991, 1
  %1994 = extractvalue { <8 x ptr>, <8 x i64> } %1993, 0
  %1995 = extractvalue { <8 x ptr>, <8 x i64> } %1993, 1
  %1996 = getelementptr i8, <8 x ptr> %1994, <8 x i64> %1995
  %1997 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1996, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state527 = load <8 x float>, ptr %.slot122, align 32
  %1998 = fadd <8 x float> %.state527, %1997
  %.state528 = load <8 x i64>, ptr %.slot119, align 64
  %1999 = add <8 x i64> %.state528, splat (i64 3)
  %2000 = select <8 x i1> %80, <8 x i64> %1999, <8 x i64> zeroinitializer
  %2001 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2002 = sdiv <8 x i64> %2000, %2001
  %.spill.load529 = load i64, ptr %.spill83, align 4
  %.splatinsert530 = insertelement <8 x i64> poison, i64 %.spill.load529, i64 0
  %.splat531 = shufflevector <8 x i64> %.splatinsert530, <8 x i64> poison, <8 x i32> zeroinitializer
  %2003 = add <8 x i64> %.splat531, %2002
  %tile_snapshot.spill.load532 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2004 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load532, 0
  %2005 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load532, 1
  %2006 = mul <8 x i64> %2003, splat (i64 32)
  %2007 = add <8 x i64> %2005, %2006
  %2008 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2004, 0
  %2009 = insertvalue { <8 x ptr>, <8 x i64> } %2008, <8 x i64> %2007, 1
  %2010 = extractvalue { <8 x ptr>, <8 x i64> } %2009, 0
  %2011 = extractvalue { <8 x ptr>, <8 x i64> } %2009, 1
  %2012 = getelementptr i8, <8 x ptr> %2010, <8 x i64> %2011
  %2013 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2012, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state533 = load <8 x float>, ptr %.slot123, align 32
  %2014 = fadd <8 x float> %.state533, %2013
  %.state534 = load <8 x i64>, ptr %.slot119, align 64
  %2015 = add <8 x i64> %.state534, splat (i64 4)
  %2016 = load <8 x i64>, ptr %.slot119, align 64
  %2017 = select <8 x i1> %80, <8 x i64> %2015, <8 x i64> %2016
  store <8 x i64> %2017, ptr %.slot119, align 64
  %2018 = load <8 x float>, ptr %.slot120, align 32
  %2019 = select <8 x i1> %80, <8 x float> %1966, <8 x float> %2018
  store <8 x float> %2019, ptr %.slot120, align 32
  %2020 = load <8 x float>, ptr %.slot121, align 32
  %2021 = select <8 x i1> %80, <8 x float> %1982, <8 x float> %2020
  store <8 x float> %2021, ptr %.slot121, align 32
  %2022 = load <8 x float>, ptr %.slot122, align 32
  %2023 = select <8 x i1> %80, <8 x float> %1998, <8 x float> %2022
  store <8 x float> %2023, ptr %.slot122, align 32
  %2024 = load <8 x float>, ptr %.slot123, align 32
  %2025 = select <8 x i1> %80, <8 x float> %2014, <8 x float> %2024
  store <8 x float> %2025, ptr %.slot123, align 32
  br label %direct.schedule.42

direct.schedule.44:                               ; preds = %direct.false509
  %tile_snapshot.spill.load535 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2026 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load535, 0
  %2027 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load535, 1
  %.spill.load536 = load i64, ptr %.spill97, align 4
  %.splatinsert537 = insertelement <8 x i64> poison, i64 %.spill.load536, i64 0
  %.splat538 = shufflevector <8 x i64> %.splatinsert537, <8 x i64> poison, <8 x i32> zeroinitializer
  %2028 = mul <8 x i64> %.splat538, splat (i64 32)
  %2029 = add <8 x i64> %2027, %2028
  %2030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2026, 0
  %2031 = insertvalue { <8 x ptr>, <8 x i64> } %2030, <8 x i64> %2029, 1
  %2032 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2033 = extractvalue { <8 x ptr>, <8 x i64> } %2031, 1
  %2034 = extractelement <8 x ptr> %2032, i32 0
  %2035 = extractelement <8 x i64> %2033, i32 0
  %2036 = sub i64 %2035, 0
  %2037 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %2038 = select i1 %2037, i64 %2036, i64 0
  %private.contiguous.address539 = getelementptr i8, ptr %2034, i64 %2038
  %private.contiguous.load540 = load <8 x float>, ptr %private.contiguous.address539, align 4
  %2039 = select <8 x i1> %80, <8 x float> %private.contiguous.load540, <8 x float> zeroinitializer
  %.state541 = load <8 x float>, ptr %.slot120, align 32
  %2040 = fadd <8 x float> %.state541, %2039
  %2041 = fadd <8 x float> zeroinitializer, %2040
  %.state542 = load <8 x float>, ptr %.slot121, align 32
  %2042 = fadd <8 x float> %2041, %.state542
  %.state543 = load <8 x float>, ptr %.slot122, align 32
  %2043 = fadd <8 x float> %2042, %.state543
  %.state544 = load <8 x float>, ptr %.slot123, align 32
  %2044 = fadd <8 x float> %2043, %.state544
  %2045 = load <8 x float>, ptr %.spill124, align 32
  %2046 = select <8 x i1> %80, <8 x float> %2044, <8 x float> %2045
  store <8 x float> %2046, ptr %.spill124, align 32
  %tile_snapshot.spill.load545 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2047 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load545, 0
  %2048 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load545, 1
  %.spill.load546 = load i64, ptr %.spill100, align 4
  %.splatinsert547 = insertelement <8 x i64> poison, i64 %.spill.load546, i64 0
  %.splat548 = shufflevector <8 x i64> %.splatinsert547, <8 x i64> poison, <8 x i32> zeroinitializer
  %2049 = mul <8 x i64> %.splat548, splat (i64 32)
  %2050 = add <8 x i64> %2048, %2049
  %2051 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2047, 0
  %2052 = insertvalue { <8 x ptr>, <8 x i64> } %2051, <8 x i64> %2050, 1
  %2053 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2054 = extractvalue { <8 x ptr>, <8 x i64> } %2052, 1
  %2055 = extractelement <8 x ptr> %2053, i32 0
  %2056 = extractelement <8 x i64> %2054, i32 0
  %2057 = sub i64 %2056, 0
  %2058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %2059 = select i1 %2058, i64 %2057, i64 0
  %private.contiguous.address549 = getelementptr i8, ptr %2055, i64 %2059
  %private.contiguous.load550 = load <8 x float>, ptr %private.contiguous.address549, align 4
  %2060 = select <8 x i1> %80, <8 x float> %private.contiguous.load550, <8 x float> zeroinitializer
  %tile_snapshot.spill.load551 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2061 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load551, 0
  %2062 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load551, 1
  %.spill.load552 = load i64, ptr %.spill101, align 4
  %.splatinsert553 = insertelement <8 x i64> poison, i64 %.spill.load552, i64 0
  %.splat554 = shufflevector <8 x i64> %.splatinsert553, <8 x i64> poison, <8 x i32> zeroinitializer
  %2063 = mul <8 x i64> %.splat554, splat (i64 32)
  %2064 = add <8 x i64> %2062, %2063
  %2065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2061, 0
  %2066 = insertvalue { <8 x ptr>, <8 x i64> } %2065, <8 x i64> %2064, 1
  %2067 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2068 = extractvalue { <8 x ptr>, <8 x i64> } %2066, 1
  %2069 = extractelement <8 x ptr> %2067, i32 0
  %2070 = extractelement <8 x i64> %2068, i32 0
  %2071 = sub i64 %2070, 0
  %2072 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %2073 = select i1 %2072, i64 %2071, i64 0
  %private.contiguous.address555 = getelementptr i8, ptr %2069, i64 %2073
  %private.contiguous.load556 = load <8 x float>, ptr %private.contiguous.address555, align 4
  %2074 = select <8 x i1> %80, <8 x float> %private.contiguous.load556, <8 x float> zeroinitializer
  %tile_snapshot.spill.load557 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2075 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load557, 0
  %2076 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load557, 1
  %.spill.load558 = load i64, ptr %.spill102, align 4
  %.splatinsert559 = insertelement <8 x i64> poison, i64 %.spill.load558, i64 0
  %.splat560 = shufflevector <8 x i64> %.splatinsert559, <8 x i64> poison, <8 x i32> zeroinitializer
  %2077 = mul <8 x i64> %.splat560, splat (i64 32)
  %2078 = add <8 x i64> %2076, %2077
  %2079 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2075, 0
  %2080 = insertvalue { <8 x ptr>, <8 x i64> } %2079, <8 x i64> %2078, 1
  %2081 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2082 = extractvalue { <8 x ptr>, <8 x i64> } %2080, 1
  %2083 = extractelement <8 x ptr> %2081, i32 0
  %2084 = extractelement <8 x i64> %2082, i32 0
  %2085 = sub i64 %2084, 0
  %2086 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %2087 = select i1 %2086, i64 %2085, i64 0
  %private.contiguous.address561 = getelementptr i8, ptr %2083, i64 %2087
  %private.contiguous.load562 = load <8 x float>, ptr %private.contiguous.address561, align 4
  %2088 = select <8 x i1> %80, <8 x float> %private.contiguous.load562, <8 x float> zeroinitializer
  %tile_snapshot.spill.load563 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2089 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load563, 0
  %2090 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load563, 1
  %.spill.load564 = load i64, ptr %.spill103, align 4
  %.splatinsert565 = insertelement <8 x i64> poison, i64 %.spill.load564, i64 0
  %.splat566 = shufflevector <8 x i64> %.splatinsert565, <8 x i64> poison, <8 x i32> zeroinitializer
  %2091 = mul <8 x i64> %.splat566, splat (i64 32)
  %2092 = add <8 x i64> %2090, %2091
  %2093 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2089, 0
  %2094 = insertvalue { <8 x ptr>, <8 x i64> } %2093, <8 x i64> %2092, 1
  %2095 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2096 = extractvalue { <8 x ptr>, <8 x i64> } %2094, 1
  %2097 = extractelement <8 x ptr> %2095, i32 0
  %2098 = extractelement <8 x i64> %2096, i32 0
  %2099 = sub i64 %2098, 0
  %2100 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %2101 = select i1 %2100, i64 %2099, i64 0
  %private.contiguous.address567 = getelementptr i8, ptr %2097, i64 %2101
  %private.contiguous.load568 = load <8 x float>, ptr %private.contiguous.address567, align 4
  %2102 = select <8 x i1> %80, <8 x float> %private.contiguous.load568, <8 x float> zeroinitializer
  %2103 = load <8 x i64>, ptr %.slot125, align 64
  %2104 = select <8 x i1> %80, <8 x i64> splat (i64 4), <8 x i64> %2103
  store <8 x i64> %2104, ptr %.slot125, align 64
  %2105 = load <8 x float>, ptr %.slot126, align 32
  %2106 = select <8 x i1> %80, <8 x float> %2060, <8 x float> %2105
  store <8 x float> %2106, ptr %.slot126, align 32
  %2107 = load <8 x float>, ptr %.slot127, align 32
  %2108 = select <8 x i1> %80, <8 x float> %2074, <8 x float> %2107
  store <8 x float> %2108, ptr %.slot127, align 32
  %2109 = load <8 x float>, ptr %.slot128, align 32
  %2110 = select <8 x i1> %80, <8 x float> %2088, <8 x float> %2109
  store <8 x float> %2110, ptr %.slot128, align 32
  %2111 = load <8 x float>, ptr %.slot129, align 32
  %2112 = select <8 x i1> %80, <8 x float> %2102, <8 x float> %2111
  store <8 x float> %2112, ptr %.slot129, align 32
  br label %direct.schedule.45

direct.schedule.45:                               ; preds = %direct.schedule.46, %direct.schedule.44
  %.state569 = load <8 x i64>, ptr %.slot125, align 64
  %2113 = icmp slt <8 x i64> %.state569, splat (i64 64)
  %2114 = extractelement <8 x i1> %2113, i32 0
  br i1 %2114, label %direct.true570, label %direct.false571

direct.schedule.46:                               ; preds = %direct.true570
  %.state572 = load <8 x i64>, ptr %.slot125, align 64
  %2115 = add <8 x i64> %.state572, zeroinitializer
  %2116 = select <8 x i1> %80, <8 x i64> %2115, <8 x i64> zeroinitializer
  %2117 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2118 = sdiv <8 x i64> %2116, %2117
  %.spill.load573 = load i64, ptr %.spill99, align 4
  %.splatinsert574 = insertelement <8 x i64> poison, i64 %.spill.load573, i64 0
  %.splat575 = shufflevector <8 x i64> %.splatinsert574, <8 x i64> poison, <8 x i32> zeroinitializer
  %2119 = add <8 x i64> %.splat575, %2118
  %tile_snapshot.spill.load576 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2120 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load576, 0
  %2121 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load576, 1
  %2122 = mul <8 x i64> %2119, splat (i64 32)
  %2123 = add <8 x i64> %2121, %2122
  %2124 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2120, 0
  %2125 = insertvalue { <8 x ptr>, <8 x i64> } %2124, <8 x i64> %2123, 1
  %2126 = extractvalue { <8 x ptr>, <8 x i64> } %2125, 0
  %2127 = extractvalue { <8 x ptr>, <8 x i64> } %2125, 1
  %2128 = getelementptr i8, <8 x ptr> %2126, <8 x i64> %2127
  %2129 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2128, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state577 = load <8 x float>, ptr %.slot126, align 32
  %2130 = fadd <8 x float> %.state577, %2129
  %.state578 = load <8 x i64>, ptr %.slot125, align 64
  %2131 = add <8 x i64> %.state578, splat (i64 1)
  %2132 = select <8 x i1> %80, <8 x i64> %2131, <8 x i64> zeroinitializer
  %2133 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2134 = sdiv <8 x i64> %2132, %2133
  %.spill.load579 = load i64, ptr %.spill99, align 4
  %.splatinsert580 = insertelement <8 x i64> poison, i64 %.spill.load579, i64 0
  %.splat581 = shufflevector <8 x i64> %.splatinsert580, <8 x i64> poison, <8 x i32> zeroinitializer
  %2135 = add <8 x i64> %.splat581, %2134
  %tile_snapshot.spill.load582 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load582, 0
  %2137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load582, 1
  %2138 = mul <8 x i64> %2135, splat (i64 32)
  %2139 = add <8 x i64> %2137, %2138
  %2140 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2136, 0
  %2141 = insertvalue { <8 x ptr>, <8 x i64> } %2140, <8 x i64> %2139, 1
  %2142 = extractvalue { <8 x ptr>, <8 x i64> } %2141, 0
  %2143 = extractvalue { <8 x ptr>, <8 x i64> } %2141, 1
  %2144 = getelementptr i8, <8 x ptr> %2142, <8 x i64> %2143
  %2145 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2144, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state583 = load <8 x float>, ptr %.slot127, align 32
  %2146 = fadd <8 x float> %.state583, %2145
  %.state584 = load <8 x i64>, ptr %.slot125, align 64
  %2147 = add <8 x i64> %.state584, splat (i64 2)
  %2148 = select <8 x i1> %80, <8 x i64> %2147, <8 x i64> zeroinitializer
  %2149 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2150 = sdiv <8 x i64> %2148, %2149
  %.spill.load585 = load i64, ptr %.spill99, align 4
  %.splatinsert586 = insertelement <8 x i64> poison, i64 %.spill.load585, i64 0
  %.splat587 = shufflevector <8 x i64> %.splatinsert586, <8 x i64> poison, <8 x i32> zeroinitializer
  %2151 = add <8 x i64> %.splat587, %2150
  %tile_snapshot.spill.load588 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2152 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 0
  %2153 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load588, 1
  %2154 = mul <8 x i64> %2151, splat (i64 32)
  %2155 = add <8 x i64> %2153, %2154
  %2156 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2152, 0
  %2157 = insertvalue { <8 x ptr>, <8 x i64> } %2156, <8 x i64> %2155, 1
  %2158 = extractvalue { <8 x ptr>, <8 x i64> } %2157, 0
  %2159 = extractvalue { <8 x ptr>, <8 x i64> } %2157, 1
  %2160 = getelementptr i8, <8 x ptr> %2158, <8 x i64> %2159
  %2161 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2160, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state589 = load <8 x float>, ptr %.slot128, align 32
  %2162 = fadd <8 x float> %.state589, %2161
  %.state590 = load <8 x i64>, ptr %.slot125, align 64
  %2163 = add <8 x i64> %.state590, splat (i64 3)
  %2164 = select <8 x i1> %80, <8 x i64> %2163, <8 x i64> zeroinitializer
  %2165 = select <8 x i1> %80, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2166 = sdiv <8 x i64> %2164, %2165
  %.spill.load591 = load i64, ptr %.spill99, align 4
  %.splatinsert592 = insertelement <8 x i64> poison, i64 %.spill.load591, i64 0
  %.splat593 = shufflevector <8 x i64> %.splatinsert592, <8 x i64> poison, <8 x i32> zeroinitializer
  %2167 = add <8 x i64> %.splat593, %2166
  %tile_snapshot.spill.load594 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2168 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 0
  %2169 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load594, 1
  %2170 = mul <8 x i64> %2167, splat (i64 32)
  %2171 = add <8 x i64> %2169, %2170
  %2172 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2168, 0
  %2173 = insertvalue { <8 x ptr>, <8 x i64> } %2172, <8 x i64> %2171, 1
  %2174 = extractvalue { <8 x ptr>, <8 x i64> } %2173, 0
  %2175 = extractvalue { <8 x ptr>, <8 x i64> } %2173, 1
  %2176 = getelementptr i8, <8 x ptr> %2174, <8 x i64> %2175
  %2177 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2176, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state595 = load <8 x float>, ptr %.slot129, align 32
  %2178 = fadd <8 x float> %.state595, %2177
  %.state596 = load <8 x i64>, ptr %.slot125, align 64
  %2179 = add <8 x i64> %.state596, splat (i64 4)
  %2180 = load <8 x i64>, ptr %.slot125, align 64
  %2181 = select <8 x i1> %80, <8 x i64> %2179, <8 x i64> %2180
  store <8 x i64> %2181, ptr %.slot125, align 64
  %2182 = load <8 x float>, ptr %.slot126, align 32
  %2183 = select <8 x i1> %80, <8 x float> %2130, <8 x float> %2182
  store <8 x float> %2183, ptr %.slot126, align 32
  %2184 = load <8 x float>, ptr %.slot127, align 32
  %2185 = select <8 x i1> %80, <8 x float> %2146, <8 x float> %2184
  store <8 x float> %2185, ptr %.slot127, align 32
  %2186 = load <8 x float>, ptr %.slot128, align 32
  %2187 = select <8 x i1> %80, <8 x float> %2162, <8 x float> %2186
  store <8 x float> %2187, ptr %.slot128, align 32
  %2188 = load <8 x float>, ptr %.slot129, align 32
  %2189 = select <8 x i1> %80, <8 x float> %2178, <8 x float> %2188
  store <8 x float> %2189, ptr %.slot129, align 32
  br label %direct.schedule.45

direct.schedule.47:                               ; preds = %direct.false571
  %tile_snapshot.spill.load597 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2190 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load597, 0
  %2191 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load597, 1
  %.spill.load598 = load i64, ptr %.spill109, align 4
  %.splatinsert599 = insertelement <8 x i64> poison, i64 %.spill.load598, i64 0
  %.splat600 = shufflevector <8 x i64> %.splatinsert599, <8 x i64> poison, <8 x i32> zeroinitializer
  %2192 = mul <8 x i64> %.splat600, splat (i64 32)
  %2193 = add <8 x i64> %2191, %2192
  %2194 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2190, 0
  %2195 = insertvalue { <8 x ptr>, <8 x i64> } %2194, <8 x i64> %2193, 1
  %2196 = extractvalue { <8 x ptr>, <8 x i64> } %32, 0
  %2197 = extractvalue { <8 x ptr>, <8 x i64> } %2195, 1
  %2198 = extractelement <8 x ptr> %2196, i32 0
  %2199 = extractelement <8 x i64> %2197, i32 0
  %2200 = sub i64 %2199, 0
  %2201 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %80)
  %2202 = select i1 %2201, i64 %2200, i64 0
  %private.contiguous.address601 = getelementptr i8, ptr %2198, i64 %2202
  %private.contiguous.load602 = load <8 x float>, ptr %private.contiguous.address601, align 4
  %2203 = select <8 x i1> %80, <8 x float> %private.contiguous.load602, <8 x float> zeroinitializer
  %.state603 = load <8 x float>, ptr %.slot126, align 32
  %2204 = fadd <8 x float> %.state603, %2203
  %2205 = fadd <8 x float> zeroinitializer, %2204
  %.state604 = load <8 x float>, ptr %.slot127, align 32
  %2206 = fadd <8 x float> %2205, %.state604
  %.state605 = load <8 x float>, ptr %.slot128, align 32
  %2207 = fadd <8 x float> %2206, %.state605
  %.state606 = load <8 x float>, ptr %.slot129, align 32
  %2208 = fadd <8 x float> %2207, %.state606
  %.spill.load607 = load <8 x float>, ptr %.spill117, align 32
  %.spill.load608 = load <8 x float>, ptr %.spill124, align 32
  %2209 = fadd <8 x float> %.spill.load607, %.spill.load608
  %2210 = load <8 x float>, ptr %.spill130, align 32
  %2211 = select <8 x i1> %80, <8 x float> %2209, <8 x float> %2210
  store <8 x float> %2211, ptr %.spill130, align 32
  %.spill.load609 = load <8 x float>, ptr %.spill118, align 32
  %2212 = fadd <8 x float> %.spill.load609, %2208
  %2213 = load <8 x float>, ptr %.spill131, align 32
  %2214 = select <8 x i1> %80, <8 x float> %2212, <8 x float> %2213
  store <8 x float> %2214, ptr %.spill131, align 32
  %.state610 = load <8 x float>, ptr %.slot49, align 32
  %.spill.load611 = load <8 x float>, ptr %.spill113, align 32
  %2215 = fmul <8 x float> %.state610, %.spill.load611
  %.state612 = load <8 x float>, ptr %.slot50, align 32
  %.spill.load613 = load <8 x float>, ptr %.spill113, align 32
  %2216 = fmul <8 x float> %.state612, %.spill.load613
  %2217 = load <8 x float>, ptr %.spill132, align 32
  %2218 = select <8 x i1> %80, <8 x float> %2216, <8 x float> %2217
  store <8 x float> %2218, ptr %.spill132, align 32
  %.state614 = load <8 x float>, ptr %.slot51, align 32
  %.spill.load615 = load <8 x float>, ptr %.spill113, align 32
  %2219 = fmul <8 x float> %.state614, %.spill.load615
  %2220 = load <8 x float>, ptr %.spill133, align 32
  %2221 = select <8 x i1> %80, <8 x float> %2219, <8 x float> %2220
  store <8 x float> %2221, ptr %.spill133, align 32
  %.state616 = load <8 x float>, ptr %.slot52, align 32
  %.spill.load617 = load <8 x float>, ptr %.spill113, align 32
  %2222 = fmul <8 x float> %.state616, %.spill.load617
  %2223 = load <8 x float>, ptr %.spill134, align 32
  %2224 = select <8 x i1> %80, <8 x float> %2222, <8 x float> %2223
  store <8 x float> %2224, ptr %.spill134, align 32
  %.state618 = load <8 x float>, ptr %.slot53, align 32
  %.spill.load619 = load <8 x float>, ptr %.spill113, align 32
  %2225 = fmul <8 x float> %.state618, %.spill.load619
  %2226 = load <8 x float>, ptr %.spill135, align 32
  %2227 = select <8 x i1> %80, <8 x float> %2225, <8 x float> %2226
  store <8 x float> %2227, ptr %.spill135, align 32
  %.state620 = load <8 x float>, ptr %.slot54, align 32
  %.spill.load621 = load <8 x float>, ptr %.spill113, align 32
  %2228 = fmul <8 x float> %.state620, %.spill.load621
  %2229 = load <8 x float>, ptr %.spill136, align 32
  %2230 = select <8 x i1> %80, <8 x float> %2228, <8 x float> %2229
  store <8 x float> %2230, ptr %.spill136, align 32
  %.state622 = load <8 x float>, ptr %.slot55, align 32
  %.spill.load623 = load <8 x float>, ptr %.spill113, align 32
  %2231 = fmul <8 x float> %.state622, %.spill.load623
  %2232 = load <8 x float>, ptr %.spill137, align 32
  %2233 = select <8 x i1> %80, <8 x float> %2231, <8 x float> %2232
  store <8 x float> %2233, ptr %.spill137, align 32
  %.state624 = load <8 x float>, ptr %.slot56, align 32
  %.spill.load625 = load <8 x float>, ptr %.spill114, align 32
  %2234 = fmul <8 x float> %.state624, %.spill.load625
  %2235 = load <8 x float>, ptr %.spill138, align 32
  %2236 = select <8 x i1> %80, <8 x float> %2234, <8 x float> %2235
  store <8 x float> %2236, ptr %.spill138, align 32
  %.state626 = load <8 x float>, ptr %.slot57, align 32
  %.spill.load627 = load <8 x float>, ptr %.spill114, align 32
  %2237 = fmul <8 x float> %.state626, %.spill.load627
  %2238 = load <8 x float>, ptr %.spill139, align 32
  %2239 = select <8 x i1> %80, <8 x float> %2237, <8 x float> %2238
  store <8 x float> %2239, ptr %.spill139, align 32
  %.state628 = load <8 x float>, ptr %.slot58, align 32
  %.spill.load629 = load <8 x float>, ptr %.spill114, align 32
  %2240 = fmul <8 x float> %.state628, %.spill.load629
  %2241 = load <8 x float>, ptr %.spill140, align 32
  %2242 = select <8 x i1> %80, <8 x float> %2240, <8 x float> %2241
  store <8 x float> %2242, ptr %.spill140, align 32
  %.state630 = load <8 x float>, ptr %.slot59, align 32
  %.spill.load631 = load <8 x float>, ptr %.spill114, align 32
  %2243 = fmul <8 x float> %.state630, %.spill.load631
  %2244 = load <8 x float>, ptr %.spill141, align 32
  %2245 = select <8 x i1> %80, <8 x float> %2243, <8 x float> %2244
  store <8 x float> %2245, ptr %.spill141, align 32
  %.state632 = load <8 x float>, ptr %.slot60, align 32
  %.spill.load633 = load <8 x float>, ptr %.spill114, align 32
  %2246 = fmul <8 x float> %.state632, %.spill.load633
  %2247 = load <8 x float>, ptr %.spill142, align 32
  %2248 = select <8 x i1> %80, <8 x float> %2246, <8 x float> %2247
  store <8 x float> %2248, ptr %.spill142, align 32
  %.state634 = load <8 x float>, ptr %.slot61, align 32
  %.spill.load635 = load <8 x float>, ptr %.spill114, align 32
  %2249 = fmul <8 x float> %.state634, %.spill.load635
  %2250 = load <8 x float>, ptr %.spill143, align 32
  %2251 = select <8 x i1> %80, <8 x float> %2249, <8 x float> %2250
  store <8 x float> %2251, ptr %.spill143, align 32
  %.state636 = load <8 x float>, ptr %.slot62, align 32
  %.spill.load637 = load <8 x float>, ptr %.spill114, align 32
  %2252 = fmul <8 x float> %.state636, %.spill.load637
  %2253 = load <8 x float>, ptr %.spill144, align 32
  %2254 = select <8 x i1> %80, <8 x float> %2252, <8 x float> %2253
  store <8 x float> %2254, ptr %.spill144, align 32
  %2255 = load <8 x i64>, ptr %.slot145, align 64
  %2256 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2255
  store <8 x i64> %2256, ptr %.slot145, align 64
  %2257 = load <8 x float>, ptr %.slot146, align 32
  %2258 = select <8 x i1> %80, <8 x float> %2215, <8 x float> %2257
  store <8 x float> %2258, ptr %.slot146, align 32
  br label %direct.schedule.48

direct.schedule.48:                               ; preds = %direct.schedule.49, %direct.schedule.47
  %.state638 = load <8 x i64>, ptr %.slot145, align 64
  %2259 = icmp slt <8 x i64> %.state638, splat (i64 65)
  %2260 = extractelement <8 x i1> %2259, i32 0
  br i1 %2260, label %direct.true639, label %direct.false640

direct.schedule.49:                               ; preds = %direct.true639
  %.state641 = load <8 x i64>, ptr %.slot145, align 64
  %2261 = add <8 x i64> zeroinitializer, %.state641
  %tile_snapshot.spill.load642 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load642, 0
  %2263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load642, 1
  %2264 = mul <8 x i64> %2261, splat (i64 32)
  %2265 = add <8 x i64> %2263, %2264
  %2266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2262, 0
  %2267 = insertvalue { <8 x ptr>, <8 x i64> } %2266, <8 x i64> %2265, 1
  %2268 = extractvalue { <8 x ptr>, <8 x i64> } %2267, 0
  %2269 = extractvalue { <8 x ptr>, <8 x i64> } %2267, 1
  %2270 = getelementptr i8, <8 x ptr> %2268, <8 x i64> %2269
  %2271 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2270, <8 x i1> %80, <8 x float> zeroinitializer)
  %2272 = mul <8 x i64> %2261, splat (i64 7)
  %2273 = add <8 x i64> %2272, zeroinitializer
  %tile_snapshot.spill.load643 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load643, 0
  %2275 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load643, 1
  %2276 = mul <8 x i64> %2273, splat (i64 32)
  %2277 = add <8 x i64> %2275, %2276
  %2278 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2274, 0
  %2279 = insertvalue { <8 x ptr>, <8 x i64> } %2278, <8 x i64> %2277, 1
  %2280 = extractvalue { <8 x ptr>, <8 x i64> } %2279, 0
  %2281 = extractvalue { <8 x ptr>, <8 x i64> } %2279, 1
  %2282 = getelementptr i8, <8 x ptr> %2280, <8 x i64> %2281
  %2283 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2282, <8 x i1> %80, <8 x float> zeroinitializer)
  %2284 = fmul <8 x float> %2271, %2283
  %.state644 = load <8 x float>, ptr %.slot146, align 32
  %2285 = fadd <8 x float> %.state644, %2284
  %.state645 = load <8 x i64>, ptr %.slot145, align 64
  %2286 = add <8 x i64> %.state645, splat (i64 1)
  %2287 = load <8 x i64>, ptr %.slot145, align 64
  %2288 = select <8 x i1> %80, <8 x i64> %2286, <8 x i64> %2287
  store <8 x i64> %2288, ptr %.slot145, align 64
  %2289 = load <8 x float>, ptr %.slot146, align 32
  %2290 = select <8 x i1> %80, <8 x float> %2285, <8 x float> %2289
  store <8 x float> %2290, ptr %.slot146, align 32
  br label %direct.schedule.48

direct.schedule.50:                               ; preds = %direct.false640
  %.spill.load646 = load <8 x float>, ptr %.spill132, align 32
  %2291 = load <8 x i64>, ptr %.slot147, align 64
  %2292 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2291
  store <8 x i64> %2292, ptr %.slot147, align 64
  %2293 = load <8 x float>, ptr %.slot148, align 32
  %2294 = select <8 x i1> %80, <8 x float> %.spill.load646, <8 x float> %2293
  store <8 x float> %2294, ptr %.slot148, align 32
  br label %direct.schedule.51

direct.schedule.51:                               ; preds = %direct.schedule.52, %direct.schedule.50
  %.state647 = load <8 x i64>, ptr %.slot147, align 64
  %2295 = icmp slt <8 x i64> %.state647, splat (i64 65)
  %2296 = extractelement <8 x i1> %2295, i32 0
  br i1 %2296, label %direct.true648, label %direct.false649

direct.schedule.52:                               ; preds = %direct.true648
  %.state650 = load <8 x i64>, ptr %.slot147, align 64
  %2297 = add <8 x i64> zeroinitializer, %.state650
  %tile_snapshot.spill.load651 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2298 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load651, 0
  %2299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load651, 1
  %2300 = mul <8 x i64> %2297, splat (i64 32)
  %2301 = add <8 x i64> %2299, %2300
  %2302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2298, 0
  %2303 = insertvalue { <8 x ptr>, <8 x i64> } %2302, <8 x i64> %2301, 1
  %2304 = extractvalue { <8 x ptr>, <8 x i64> } %2303, 0
  %2305 = extractvalue { <8 x ptr>, <8 x i64> } %2303, 1
  %2306 = getelementptr i8, <8 x ptr> %2304, <8 x i64> %2305
  %2307 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2306, <8 x i1> %80, <8 x float> zeroinitializer)
  %2308 = mul <8 x i64> %2297, splat (i64 7)
  %2309 = add <8 x i64> %2308, splat (i64 1)
  %tile_snapshot.spill.load652 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 0
  %2311 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 1
  %2312 = mul <8 x i64> %2309, splat (i64 32)
  %2313 = add <8 x i64> %2311, %2312
  %2314 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2310, 0
  %2315 = insertvalue { <8 x ptr>, <8 x i64> } %2314, <8 x i64> %2313, 1
  %2316 = extractvalue { <8 x ptr>, <8 x i64> } %2315, 0
  %2317 = extractvalue { <8 x ptr>, <8 x i64> } %2315, 1
  %2318 = getelementptr i8, <8 x ptr> %2316, <8 x i64> %2317
  %2319 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2318, <8 x i1> %80, <8 x float> zeroinitializer)
  %2320 = fmul <8 x float> %2307, %2319
  %.state653 = load <8 x float>, ptr %.slot148, align 32
  %2321 = fadd <8 x float> %.state653, %2320
  %.state654 = load <8 x i64>, ptr %.slot147, align 64
  %2322 = add <8 x i64> %.state654, splat (i64 1)
  %2323 = load <8 x i64>, ptr %.slot147, align 64
  %2324 = select <8 x i1> %80, <8 x i64> %2322, <8 x i64> %2323
  store <8 x i64> %2324, ptr %.slot147, align 64
  %2325 = load <8 x float>, ptr %.slot148, align 32
  %2326 = select <8 x i1> %80, <8 x float> %2321, <8 x float> %2325
  store <8 x float> %2326, ptr %.slot148, align 32
  br label %direct.schedule.51

direct.schedule.53:                               ; preds = %direct.false649
  %.spill.load655 = load <8 x float>, ptr %.spill133, align 32
  %2327 = load <8 x i64>, ptr %.slot149, align 64
  %2328 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2327
  store <8 x i64> %2328, ptr %.slot149, align 64
  %2329 = load <8 x float>, ptr %.slot150, align 32
  %2330 = select <8 x i1> %80, <8 x float> %.spill.load655, <8 x float> %2329
  store <8 x float> %2330, ptr %.slot150, align 32
  br label %direct.schedule.54

direct.schedule.54:                               ; preds = %direct.schedule.55, %direct.schedule.53
  %.state656 = load <8 x i64>, ptr %.slot149, align 64
  %2331 = icmp slt <8 x i64> %.state656, splat (i64 65)
  %2332 = extractelement <8 x i1> %2331, i32 0
  br i1 %2332, label %direct.true657, label %direct.false658

direct.schedule.55:                               ; preds = %direct.true657
  %.state659 = load <8 x i64>, ptr %.slot149, align 64
  %2333 = add <8 x i64> zeroinitializer, %.state659
  %tile_snapshot.spill.load660 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2334 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load660, 0
  %2335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load660, 1
  %2336 = mul <8 x i64> %2333, splat (i64 32)
  %2337 = add <8 x i64> %2335, %2336
  %2338 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2334, 0
  %2339 = insertvalue { <8 x ptr>, <8 x i64> } %2338, <8 x i64> %2337, 1
  %2340 = extractvalue { <8 x ptr>, <8 x i64> } %2339, 0
  %2341 = extractvalue { <8 x ptr>, <8 x i64> } %2339, 1
  %2342 = getelementptr i8, <8 x ptr> %2340, <8 x i64> %2341
  %2343 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2342, <8 x i1> %80, <8 x float> zeroinitializer)
  %2344 = mul <8 x i64> %2333, splat (i64 7)
  %2345 = add <8 x i64> %2344, splat (i64 2)
  %tile_snapshot.spill.load661 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2346 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load661, 0
  %2347 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load661, 1
  %2348 = mul <8 x i64> %2345, splat (i64 32)
  %2349 = add <8 x i64> %2347, %2348
  %2350 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2346, 0
  %2351 = insertvalue { <8 x ptr>, <8 x i64> } %2350, <8 x i64> %2349, 1
  %2352 = extractvalue { <8 x ptr>, <8 x i64> } %2351, 0
  %2353 = extractvalue { <8 x ptr>, <8 x i64> } %2351, 1
  %2354 = getelementptr i8, <8 x ptr> %2352, <8 x i64> %2353
  %2355 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2354, <8 x i1> %80, <8 x float> zeroinitializer)
  %2356 = fmul <8 x float> %2343, %2355
  %.state662 = load <8 x float>, ptr %.slot150, align 32
  %2357 = fadd <8 x float> %.state662, %2356
  %.state663 = load <8 x i64>, ptr %.slot149, align 64
  %2358 = add <8 x i64> %.state663, splat (i64 1)
  %2359 = load <8 x i64>, ptr %.slot149, align 64
  %2360 = select <8 x i1> %80, <8 x i64> %2358, <8 x i64> %2359
  store <8 x i64> %2360, ptr %.slot149, align 64
  %2361 = load <8 x float>, ptr %.slot150, align 32
  %2362 = select <8 x i1> %80, <8 x float> %2357, <8 x float> %2361
  store <8 x float> %2362, ptr %.slot150, align 32
  br label %direct.schedule.54

direct.schedule.56:                               ; preds = %direct.false658
  %.spill.load664 = load <8 x float>, ptr %.spill134, align 32
  %2363 = load <8 x i64>, ptr %.slot151, align 64
  %2364 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2363
  store <8 x i64> %2364, ptr %.slot151, align 64
  %2365 = load <8 x float>, ptr %.slot152, align 32
  %2366 = select <8 x i1> %80, <8 x float> %.spill.load664, <8 x float> %2365
  store <8 x float> %2366, ptr %.slot152, align 32
  br label %direct.schedule.57

direct.schedule.57:                               ; preds = %direct.schedule.58, %direct.schedule.56
  %.state665 = load <8 x i64>, ptr %.slot151, align 64
  %2367 = icmp slt <8 x i64> %.state665, splat (i64 65)
  %2368 = extractelement <8 x i1> %2367, i32 0
  br i1 %2368, label %direct.true666, label %direct.false667

direct.schedule.58:                               ; preds = %direct.true666
  %.state668 = load <8 x i64>, ptr %.slot151, align 64
  %2369 = add <8 x i64> zeroinitializer, %.state668
  %tile_snapshot.spill.load669 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 0
  %2371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load669, 1
  %2372 = mul <8 x i64> %2369, splat (i64 32)
  %2373 = add <8 x i64> %2371, %2372
  %2374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2370, 0
  %2375 = insertvalue { <8 x ptr>, <8 x i64> } %2374, <8 x i64> %2373, 1
  %2376 = extractvalue { <8 x ptr>, <8 x i64> } %2375, 0
  %2377 = extractvalue { <8 x ptr>, <8 x i64> } %2375, 1
  %2378 = getelementptr i8, <8 x ptr> %2376, <8 x i64> %2377
  %2379 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2378, <8 x i1> %80, <8 x float> zeroinitializer)
  %2380 = mul <8 x i64> %2369, splat (i64 7)
  %2381 = add <8 x i64> %2380, splat (i64 3)
  %tile_snapshot.spill.load670 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load670, 0
  %2383 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load670, 1
  %2384 = mul <8 x i64> %2381, splat (i64 32)
  %2385 = add <8 x i64> %2383, %2384
  %2386 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2382, 0
  %2387 = insertvalue { <8 x ptr>, <8 x i64> } %2386, <8 x i64> %2385, 1
  %2388 = extractvalue { <8 x ptr>, <8 x i64> } %2387, 0
  %2389 = extractvalue { <8 x ptr>, <8 x i64> } %2387, 1
  %2390 = getelementptr i8, <8 x ptr> %2388, <8 x i64> %2389
  %2391 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2390, <8 x i1> %80, <8 x float> zeroinitializer)
  %2392 = fmul <8 x float> %2379, %2391
  %.state671 = load <8 x float>, ptr %.slot152, align 32
  %2393 = fadd <8 x float> %.state671, %2392
  %.state672 = load <8 x i64>, ptr %.slot151, align 64
  %2394 = add <8 x i64> %.state672, splat (i64 1)
  %2395 = load <8 x i64>, ptr %.slot151, align 64
  %2396 = select <8 x i1> %80, <8 x i64> %2394, <8 x i64> %2395
  store <8 x i64> %2396, ptr %.slot151, align 64
  %2397 = load <8 x float>, ptr %.slot152, align 32
  %2398 = select <8 x i1> %80, <8 x float> %2393, <8 x float> %2397
  store <8 x float> %2398, ptr %.slot152, align 32
  br label %direct.schedule.57

direct.schedule.59:                               ; preds = %direct.false667
  %.spill.load673 = load <8 x float>, ptr %.spill135, align 32
  %2399 = load <8 x i64>, ptr %.slot153, align 64
  %2400 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2399
  store <8 x i64> %2400, ptr %.slot153, align 64
  %2401 = load <8 x float>, ptr %.slot154, align 32
  %2402 = select <8 x i1> %80, <8 x float> %.spill.load673, <8 x float> %2401
  store <8 x float> %2402, ptr %.slot154, align 32
  br label %direct.schedule.60

direct.schedule.60:                               ; preds = %direct.schedule.61, %direct.schedule.59
  %.state674 = load <8 x i64>, ptr %.slot153, align 64
  %2403 = icmp slt <8 x i64> %.state674, splat (i64 65)
  %2404 = extractelement <8 x i1> %2403, i32 0
  br i1 %2404, label %direct.true675, label %direct.false676

direct.schedule.61:                               ; preds = %direct.true675
  %.state677 = load <8 x i64>, ptr %.slot153, align 64
  %2405 = add <8 x i64> zeroinitializer, %.state677
  %tile_snapshot.spill.load678 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2406 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load678, 0
  %2407 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load678, 1
  %2408 = mul <8 x i64> %2405, splat (i64 32)
  %2409 = add <8 x i64> %2407, %2408
  %2410 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2406, 0
  %2411 = insertvalue { <8 x ptr>, <8 x i64> } %2410, <8 x i64> %2409, 1
  %2412 = extractvalue { <8 x ptr>, <8 x i64> } %2411, 0
  %2413 = extractvalue { <8 x ptr>, <8 x i64> } %2411, 1
  %2414 = getelementptr i8, <8 x ptr> %2412, <8 x i64> %2413
  %2415 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2414, <8 x i1> %80, <8 x float> zeroinitializer)
  %2416 = mul <8 x i64> %2405, splat (i64 7)
  %2417 = add <8 x i64> %2416, splat (i64 4)
  %tile_snapshot.spill.load679 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2418 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 0
  %2419 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load679, 1
  %2420 = mul <8 x i64> %2417, splat (i64 32)
  %2421 = add <8 x i64> %2419, %2420
  %2422 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2418, 0
  %2423 = insertvalue { <8 x ptr>, <8 x i64> } %2422, <8 x i64> %2421, 1
  %2424 = extractvalue { <8 x ptr>, <8 x i64> } %2423, 0
  %2425 = extractvalue { <8 x ptr>, <8 x i64> } %2423, 1
  %2426 = getelementptr i8, <8 x ptr> %2424, <8 x i64> %2425
  %2427 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2426, <8 x i1> %80, <8 x float> zeroinitializer)
  %2428 = fmul <8 x float> %2415, %2427
  %.state680 = load <8 x float>, ptr %.slot154, align 32
  %2429 = fadd <8 x float> %.state680, %2428
  %.state681 = load <8 x i64>, ptr %.slot153, align 64
  %2430 = add <8 x i64> %.state681, splat (i64 1)
  %2431 = load <8 x i64>, ptr %.slot153, align 64
  %2432 = select <8 x i1> %80, <8 x i64> %2430, <8 x i64> %2431
  store <8 x i64> %2432, ptr %.slot153, align 64
  %2433 = load <8 x float>, ptr %.slot154, align 32
  %2434 = select <8 x i1> %80, <8 x float> %2429, <8 x float> %2433
  store <8 x float> %2434, ptr %.slot154, align 32
  br label %direct.schedule.60

direct.schedule.62:                               ; preds = %direct.false676
  %.spill.load682 = load <8 x float>, ptr %.spill136, align 32
  %2435 = load <8 x i64>, ptr %.slot155, align 64
  %2436 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2435
  store <8 x i64> %2436, ptr %.slot155, align 64
  %2437 = load <8 x float>, ptr %.slot156, align 32
  %2438 = select <8 x i1> %80, <8 x float> %.spill.load682, <8 x float> %2437
  store <8 x float> %2438, ptr %.slot156, align 32
  br label %direct.schedule.63

direct.schedule.63:                               ; preds = %direct.schedule.64, %direct.schedule.62
  %.state683 = load <8 x i64>, ptr %.slot155, align 64
  %2439 = icmp slt <8 x i64> %.state683, splat (i64 65)
  %2440 = extractelement <8 x i1> %2439, i32 0
  br i1 %2440, label %direct.true684, label %direct.false685

direct.schedule.64:                               ; preds = %direct.true684
  %.state686 = load <8 x i64>, ptr %.slot155, align 64
  %2441 = add <8 x i64> zeroinitializer, %.state686
  %tile_snapshot.spill.load687 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2442 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load687, 0
  %2443 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load687, 1
  %2444 = mul <8 x i64> %2441, splat (i64 32)
  %2445 = add <8 x i64> %2443, %2444
  %2446 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2442, 0
  %2447 = insertvalue { <8 x ptr>, <8 x i64> } %2446, <8 x i64> %2445, 1
  %2448 = extractvalue { <8 x ptr>, <8 x i64> } %2447, 0
  %2449 = extractvalue { <8 x ptr>, <8 x i64> } %2447, 1
  %2450 = getelementptr i8, <8 x ptr> %2448, <8 x i64> %2449
  %2451 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2450, <8 x i1> %80, <8 x float> zeroinitializer)
  %2452 = mul <8 x i64> %2441, splat (i64 7)
  %2453 = add <8 x i64> %2452, splat (i64 5)
  %tile_snapshot.spill.load688 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2454 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load688, 0
  %2455 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load688, 1
  %2456 = mul <8 x i64> %2453, splat (i64 32)
  %2457 = add <8 x i64> %2455, %2456
  %2458 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2454, 0
  %2459 = insertvalue { <8 x ptr>, <8 x i64> } %2458, <8 x i64> %2457, 1
  %2460 = extractvalue { <8 x ptr>, <8 x i64> } %2459, 0
  %2461 = extractvalue { <8 x ptr>, <8 x i64> } %2459, 1
  %2462 = getelementptr i8, <8 x ptr> %2460, <8 x i64> %2461
  %2463 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2462, <8 x i1> %80, <8 x float> zeroinitializer)
  %2464 = fmul <8 x float> %2451, %2463
  %.state689 = load <8 x float>, ptr %.slot156, align 32
  %2465 = fadd <8 x float> %.state689, %2464
  %.state690 = load <8 x i64>, ptr %.slot155, align 64
  %2466 = add <8 x i64> %.state690, splat (i64 1)
  %2467 = load <8 x i64>, ptr %.slot155, align 64
  %2468 = select <8 x i1> %80, <8 x i64> %2466, <8 x i64> %2467
  store <8 x i64> %2468, ptr %.slot155, align 64
  %2469 = load <8 x float>, ptr %.slot156, align 32
  %2470 = select <8 x i1> %80, <8 x float> %2465, <8 x float> %2469
  store <8 x float> %2470, ptr %.slot156, align 32
  br label %direct.schedule.63

direct.schedule.65:                               ; preds = %direct.false685
  %.spill.load691 = load <8 x float>, ptr %.spill137, align 32
  %2471 = load <8 x i64>, ptr %.slot157, align 64
  %2472 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2471
  store <8 x i64> %2472, ptr %.slot157, align 64
  %2473 = load <8 x float>, ptr %.slot158, align 32
  %2474 = select <8 x i1> %80, <8 x float> %.spill.load691, <8 x float> %2473
  store <8 x float> %2474, ptr %.slot158, align 32
  br label %direct.schedule.66

direct.schedule.66:                               ; preds = %direct.schedule.67, %direct.schedule.65
  %.state692 = load <8 x i64>, ptr %.slot157, align 64
  %2475 = icmp slt <8 x i64> %.state692, splat (i64 65)
  %2476 = extractelement <8 x i1> %2475, i32 0
  br i1 %2476, label %direct.true693, label %direct.false694

direct.schedule.67:                               ; preds = %direct.true693
  %.state695 = load <8 x i64>, ptr %.slot157, align 64
  %2477 = add <8 x i64> zeroinitializer, %.state695
  %tile_snapshot.spill.load696 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2478 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load696, 0
  %2479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load696, 1
  %2480 = mul <8 x i64> %2477, splat (i64 32)
  %2481 = add <8 x i64> %2479, %2480
  %2482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2478, 0
  %2483 = insertvalue { <8 x ptr>, <8 x i64> } %2482, <8 x i64> %2481, 1
  %2484 = extractvalue { <8 x ptr>, <8 x i64> } %2483, 0
  %2485 = extractvalue { <8 x ptr>, <8 x i64> } %2483, 1
  %2486 = getelementptr i8, <8 x ptr> %2484, <8 x i64> %2485
  %2487 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2486, <8 x i1> %80, <8 x float> zeroinitializer)
  %2488 = mul <8 x i64> %2477, splat (i64 7)
  %2489 = add <8 x i64> %2488, splat (i64 6)
  %tile_snapshot.spill.load697 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2490 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load697, 0
  %2491 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load697, 1
  %2492 = mul <8 x i64> %2489, splat (i64 32)
  %2493 = add <8 x i64> %2491, %2492
  %2494 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2490, 0
  %2495 = insertvalue { <8 x ptr>, <8 x i64> } %2494, <8 x i64> %2493, 1
  %2496 = extractvalue { <8 x ptr>, <8 x i64> } %2495, 0
  %2497 = extractvalue { <8 x ptr>, <8 x i64> } %2495, 1
  %2498 = getelementptr i8, <8 x ptr> %2496, <8 x i64> %2497
  %2499 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2498, <8 x i1> %80, <8 x float> zeroinitializer)
  %2500 = fmul <8 x float> %2487, %2499
  %.state698 = load <8 x float>, ptr %.slot158, align 32
  %2501 = fadd <8 x float> %.state698, %2500
  %.state699 = load <8 x i64>, ptr %.slot157, align 64
  %2502 = add <8 x i64> %.state699, splat (i64 1)
  %2503 = load <8 x i64>, ptr %.slot157, align 64
  %2504 = select <8 x i1> %80, <8 x i64> %2502, <8 x i64> %2503
  store <8 x i64> %2504, ptr %.slot157, align 64
  %2505 = load <8 x float>, ptr %.slot158, align 32
  %2506 = select <8 x i1> %80, <8 x float> %2501, <8 x float> %2505
  store <8 x float> %2506, ptr %.slot158, align 32
  br label %direct.schedule.66

direct.schedule.68:                               ; preds = %direct.false694
  %.spill.load700 = load <8 x float>, ptr %.spill138, align 32
  %2507 = load <8 x i64>, ptr %.slot159, align 64
  %2508 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2507
  store <8 x i64> %2508, ptr %.slot159, align 64
  %2509 = load <8 x float>, ptr %.slot160, align 32
  %2510 = select <8 x i1> %80, <8 x float> %.spill.load700, <8 x float> %2509
  store <8 x float> %2510, ptr %.slot160, align 32
  br label %direct.schedule.69

direct.schedule.69:                               ; preds = %direct.schedule.70, %direct.schedule.68
  %.state701 = load <8 x i64>, ptr %.slot159, align 64
  %2511 = icmp slt <8 x i64> %.state701, splat (i64 65)
  %2512 = extractelement <8 x i1> %2511, i32 0
  br i1 %2512, label %direct.true702, label %direct.false703

direct.schedule.70:                               ; preds = %direct.true702
  %.state704 = load <8 x i64>, ptr %.slot159, align 64
  %2513 = add <8 x i64> splat (i64 65), %.state704
  %tile_snapshot.spill.load705 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2514 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load705, 0
  %2515 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load705, 1
  %2516 = mul <8 x i64> %2513, splat (i64 32)
  %2517 = add <8 x i64> %2515, %2516
  %2518 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2514, 0
  %2519 = insertvalue { <8 x ptr>, <8 x i64> } %2518, <8 x i64> %2517, 1
  %2520 = extractvalue { <8 x ptr>, <8 x i64> } %2519, 0
  %2521 = extractvalue { <8 x ptr>, <8 x i64> } %2519, 1
  %2522 = getelementptr i8, <8 x ptr> %2520, <8 x i64> %2521
  %2523 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2522, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state706 = load <8 x i64>, ptr %.slot159, align 64
  %2524 = add <8 x i64> zeroinitializer, %.state706
  %2525 = mul <8 x i64> %2524, splat (i64 7)
  %2526 = add <8 x i64> %2525, zeroinitializer
  %tile_snapshot.spill.load707 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2527 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load707, 0
  %2528 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load707, 1
  %2529 = mul <8 x i64> %2526, splat (i64 32)
  %2530 = add <8 x i64> %2528, %2529
  %2531 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2527, 0
  %2532 = insertvalue { <8 x ptr>, <8 x i64> } %2531, <8 x i64> %2530, 1
  %2533 = extractvalue { <8 x ptr>, <8 x i64> } %2532, 0
  %2534 = extractvalue { <8 x ptr>, <8 x i64> } %2532, 1
  %2535 = getelementptr i8, <8 x ptr> %2533, <8 x i64> %2534
  %2536 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2535, <8 x i1> %80, <8 x float> zeroinitializer)
  %2537 = fmul <8 x float> %2523, %2536
  %.state708 = load <8 x float>, ptr %.slot160, align 32
  %2538 = fadd <8 x float> %.state708, %2537
  %.state709 = load <8 x i64>, ptr %.slot159, align 64
  %2539 = add <8 x i64> %.state709, splat (i64 1)
  %2540 = load <8 x i64>, ptr %.slot159, align 64
  %2541 = select <8 x i1> %80, <8 x i64> %2539, <8 x i64> %2540
  store <8 x i64> %2541, ptr %.slot159, align 64
  %2542 = load <8 x float>, ptr %.slot160, align 32
  %2543 = select <8 x i1> %80, <8 x float> %2538, <8 x float> %2542
  store <8 x float> %2543, ptr %.slot160, align 32
  br label %direct.schedule.69

direct.schedule.71:                               ; preds = %direct.false703
  %.spill.load710 = load <8 x float>, ptr %.spill139, align 32
  %2544 = load <8 x i64>, ptr %.slot161, align 64
  %2545 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2544
  store <8 x i64> %2545, ptr %.slot161, align 64
  %2546 = load <8 x float>, ptr %.slot162, align 32
  %2547 = select <8 x i1> %80, <8 x float> %.spill.load710, <8 x float> %2546
  store <8 x float> %2547, ptr %.slot162, align 32
  br label %direct.schedule.72

direct.schedule.72:                               ; preds = %direct.schedule.73, %direct.schedule.71
  %.state711 = load <8 x i64>, ptr %.slot161, align 64
  %2548 = icmp slt <8 x i64> %.state711, splat (i64 65)
  %2549 = extractelement <8 x i1> %2548, i32 0
  br i1 %2549, label %direct.true712, label %direct.false713

direct.schedule.73:                               ; preds = %direct.true712
  %.state714 = load <8 x i64>, ptr %.slot161, align 64
  %2550 = add <8 x i64> splat (i64 65), %.state714
  %tile_snapshot.spill.load715 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2551 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 0
  %2552 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load715, 1
  %2553 = mul <8 x i64> %2550, splat (i64 32)
  %2554 = add <8 x i64> %2552, %2553
  %2555 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2551, 0
  %2556 = insertvalue { <8 x ptr>, <8 x i64> } %2555, <8 x i64> %2554, 1
  %2557 = extractvalue { <8 x ptr>, <8 x i64> } %2556, 0
  %2558 = extractvalue { <8 x ptr>, <8 x i64> } %2556, 1
  %2559 = getelementptr i8, <8 x ptr> %2557, <8 x i64> %2558
  %2560 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2559, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state716 = load <8 x i64>, ptr %.slot161, align 64
  %2561 = add <8 x i64> zeroinitializer, %.state716
  %2562 = mul <8 x i64> %2561, splat (i64 7)
  %2563 = add <8 x i64> %2562, splat (i64 1)
  %tile_snapshot.spill.load717 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load717, 0
  %2565 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load717, 1
  %2566 = mul <8 x i64> %2563, splat (i64 32)
  %2567 = add <8 x i64> %2565, %2566
  %2568 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2564, 0
  %2569 = insertvalue { <8 x ptr>, <8 x i64> } %2568, <8 x i64> %2567, 1
  %2570 = extractvalue { <8 x ptr>, <8 x i64> } %2569, 0
  %2571 = extractvalue { <8 x ptr>, <8 x i64> } %2569, 1
  %2572 = getelementptr i8, <8 x ptr> %2570, <8 x i64> %2571
  %2573 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2572, <8 x i1> %80, <8 x float> zeroinitializer)
  %2574 = fmul <8 x float> %2560, %2573
  %.state718 = load <8 x float>, ptr %.slot162, align 32
  %2575 = fadd <8 x float> %.state718, %2574
  %.state719 = load <8 x i64>, ptr %.slot161, align 64
  %2576 = add <8 x i64> %.state719, splat (i64 1)
  %2577 = load <8 x i64>, ptr %.slot161, align 64
  %2578 = select <8 x i1> %80, <8 x i64> %2576, <8 x i64> %2577
  store <8 x i64> %2578, ptr %.slot161, align 64
  %2579 = load <8 x float>, ptr %.slot162, align 32
  %2580 = select <8 x i1> %80, <8 x float> %2575, <8 x float> %2579
  store <8 x float> %2580, ptr %.slot162, align 32
  br label %direct.schedule.72

direct.schedule.74:                               ; preds = %direct.false713
  %.spill.load720 = load <8 x float>, ptr %.spill140, align 32
  %2581 = load <8 x i64>, ptr %.slot163, align 64
  %2582 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2581
  store <8 x i64> %2582, ptr %.slot163, align 64
  %2583 = load <8 x float>, ptr %.slot164, align 32
  %2584 = select <8 x i1> %80, <8 x float> %.spill.load720, <8 x float> %2583
  store <8 x float> %2584, ptr %.slot164, align 32
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.76, %direct.schedule.74
  %.state721 = load <8 x i64>, ptr %.slot163, align 64
  %2585 = icmp slt <8 x i64> %.state721, splat (i64 65)
  %2586 = extractelement <8 x i1> %2585, i32 0
  br i1 %2586, label %direct.true722, label %direct.false723

direct.schedule.76:                               ; preds = %direct.true722
  %.state724 = load <8 x i64>, ptr %.slot163, align 64
  %2587 = add <8 x i64> splat (i64 65), %.state724
  %tile_snapshot.spill.load725 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load725, 0
  %2589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load725, 1
  %2590 = mul <8 x i64> %2587, splat (i64 32)
  %2591 = add <8 x i64> %2589, %2590
  %2592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2588, 0
  %2593 = insertvalue { <8 x ptr>, <8 x i64> } %2592, <8 x i64> %2591, 1
  %2594 = extractvalue { <8 x ptr>, <8 x i64> } %2593, 0
  %2595 = extractvalue { <8 x ptr>, <8 x i64> } %2593, 1
  %2596 = getelementptr i8, <8 x ptr> %2594, <8 x i64> %2595
  %2597 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2596, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state726 = load <8 x i64>, ptr %.slot163, align 64
  %2598 = add <8 x i64> zeroinitializer, %.state726
  %2599 = mul <8 x i64> %2598, splat (i64 7)
  %2600 = add <8 x i64> %2599, splat (i64 2)
  %tile_snapshot.spill.load727 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2601 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load727, 0
  %2602 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load727, 1
  %2603 = mul <8 x i64> %2600, splat (i64 32)
  %2604 = add <8 x i64> %2602, %2603
  %2605 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2601, 0
  %2606 = insertvalue { <8 x ptr>, <8 x i64> } %2605, <8 x i64> %2604, 1
  %2607 = extractvalue { <8 x ptr>, <8 x i64> } %2606, 0
  %2608 = extractvalue { <8 x ptr>, <8 x i64> } %2606, 1
  %2609 = getelementptr i8, <8 x ptr> %2607, <8 x i64> %2608
  %2610 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2609, <8 x i1> %80, <8 x float> zeroinitializer)
  %2611 = fmul <8 x float> %2597, %2610
  %.state728 = load <8 x float>, ptr %.slot164, align 32
  %2612 = fadd <8 x float> %.state728, %2611
  %.state729 = load <8 x i64>, ptr %.slot163, align 64
  %2613 = add <8 x i64> %.state729, splat (i64 1)
  %2614 = load <8 x i64>, ptr %.slot163, align 64
  %2615 = select <8 x i1> %80, <8 x i64> %2613, <8 x i64> %2614
  store <8 x i64> %2615, ptr %.slot163, align 64
  %2616 = load <8 x float>, ptr %.slot164, align 32
  %2617 = select <8 x i1> %80, <8 x float> %2612, <8 x float> %2616
  store <8 x float> %2617, ptr %.slot164, align 32
  br label %direct.schedule.75

direct.schedule.77:                               ; preds = %direct.false723
  %.spill.load730 = load <8 x float>, ptr %.spill141, align 32
  %2618 = load <8 x i64>, ptr %.slot165, align 64
  %2619 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2618
  store <8 x i64> %2619, ptr %.slot165, align 64
  %2620 = load <8 x float>, ptr %.slot166, align 32
  %2621 = select <8 x i1> %80, <8 x float> %.spill.load730, <8 x float> %2620
  store <8 x float> %2621, ptr %.slot166, align 32
  br label %direct.schedule.78

direct.schedule.78:                               ; preds = %direct.schedule.79, %direct.schedule.77
  %.state731 = load <8 x i64>, ptr %.slot165, align 64
  %2622 = icmp slt <8 x i64> %.state731, splat (i64 65)
  %2623 = extractelement <8 x i1> %2622, i32 0
  br i1 %2623, label %direct.true732, label %direct.false733

direct.schedule.79:                               ; preds = %direct.true732
  %.state734 = load <8 x i64>, ptr %.slot165, align 64
  %2624 = add <8 x i64> splat (i64 65), %.state734
  %tile_snapshot.spill.load735 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2625 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load735, 0
  %2626 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load735, 1
  %2627 = mul <8 x i64> %2624, splat (i64 32)
  %2628 = add <8 x i64> %2626, %2627
  %2629 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2625, 0
  %2630 = insertvalue { <8 x ptr>, <8 x i64> } %2629, <8 x i64> %2628, 1
  %2631 = extractvalue { <8 x ptr>, <8 x i64> } %2630, 0
  %2632 = extractvalue { <8 x ptr>, <8 x i64> } %2630, 1
  %2633 = getelementptr i8, <8 x ptr> %2631, <8 x i64> %2632
  %2634 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2633, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state736 = load <8 x i64>, ptr %.slot165, align 64
  %2635 = add <8 x i64> zeroinitializer, %.state736
  %2636 = mul <8 x i64> %2635, splat (i64 7)
  %2637 = add <8 x i64> %2636, splat (i64 3)
  %tile_snapshot.spill.load737 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2638 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load737, 0
  %2639 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load737, 1
  %2640 = mul <8 x i64> %2637, splat (i64 32)
  %2641 = add <8 x i64> %2639, %2640
  %2642 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2638, 0
  %2643 = insertvalue { <8 x ptr>, <8 x i64> } %2642, <8 x i64> %2641, 1
  %2644 = extractvalue { <8 x ptr>, <8 x i64> } %2643, 0
  %2645 = extractvalue { <8 x ptr>, <8 x i64> } %2643, 1
  %2646 = getelementptr i8, <8 x ptr> %2644, <8 x i64> %2645
  %2647 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2646, <8 x i1> %80, <8 x float> zeroinitializer)
  %2648 = fmul <8 x float> %2634, %2647
  %.state738 = load <8 x float>, ptr %.slot166, align 32
  %2649 = fadd <8 x float> %.state738, %2648
  %.state739 = load <8 x i64>, ptr %.slot165, align 64
  %2650 = add <8 x i64> %.state739, splat (i64 1)
  %2651 = load <8 x i64>, ptr %.slot165, align 64
  %2652 = select <8 x i1> %80, <8 x i64> %2650, <8 x i64> %2651
  store <8 x i64> %2652, ptr %.slot165, align 64
  %2653 = load <8 x float>, ptr %.slot166, align 32
  %2654 = select <8 x i1> %80, <8 x float> %2649, <8 x float> %2653
  store <8 x float> %2654, ptr %.slot166, align 32
  br label %direct.schedule.78

direct.schedule.80:                               ; preds = %direct.false733
  %.spill.load740 = load <8 x float>, ptr %.spill142, align 32
  %2655 = load <8 x i64>, ptr %.slot167, align 64
  %2656 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2655
  store <8 x i64> %2656, ptr %.slot167, align 64
  %2657 = load <8 x float>, ptr %.slot168, align 32
  %2658 = select <8 x i1> %80, <8 x float> %.spill.load740, <8 x float> %2657
  store <8 x float> %2658, ptr %.slot168, align 32
  br label %direct.schedule.81

direct.schedule.81:                               ; preds = %direct.schedule.82, %direct.schedule.80
  %.state741 = load <8 x i64>, ptr %.slot167, align 64
  %2659 = icmp slt <8 x i64> %.state741, splat (i64 65)
  %2660 = extractelement <8 x i1> %2659, i32 0
  br i1 %2660, label %direct.true742, label %direct.false743

direct.schedule.82:                               ; preds = %direct.true742
  %.state744 = load <8 x i64>, ptr %.slot167, align 64
  %2661 = add <8 x i64> splat (i64 65), %.state744
  %tile_snapshot.spill.load745 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2662 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load745, 0
  %2663 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load745, 1
  %2664 = mul <8 x i64> %2661, splat (i64 32)
  %2665 = add <8 x i64> %2663, %2664
  %2666 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2662, 0
  %2667 = insertvalue { <8 x ptr>, <8 x i64> } %2666, <8 x i64> %2665, 1
  %2668 = extractvalue { <8 x ptr>, <8 x i64> } %2667, 0
  %2669 = extractvalue { <8 x ptr>, <8 x i64> } %2667, 1
  %2670 = getelementptr i8, <8 x ptr> %2668, <8 x i64> %2669
  %2671 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2670, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state746 = load <8 x i64>, ptr %.slot167, align 64
  %2672 = add <8 x i64> zeroinitializer, %.state746
  %2673 = mul <8 x i64> %2672, splat (i64 7)
  %2674 = add <8 x i64> %2673, splat (i64 4)
  %tile_snapshot.spill.load747 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2675 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 0
  %2676 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load747, 1
  %2677 = mul <8 x i64> %2674, splat (i64 32)
  %2678 = add <8 x i64> %2676, %2677
  %2679 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2675, 0
  %2680 = insertvalue { <8 x ptr>, <8 x i64> } %2679, <8 x i64> %2678, 1
  %2681 = extractvalue { <8 x ptr>, <8 x i64> } %2680, 0
  %2682 = extractvalue { <8 x ptr>, <8 x i64> } %2680, 1
  %2683 = getelementptr i8, <8 x ptr> %2681, <8 x i64> %2682
  %2684 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2683, <8 x i1> %80, <8 x float> zeroinitializer)
  %2685 = fmul <8 x float> %2671, %2684
  %.state748 = load <8 x float>, ptr %.slot168, align 32
  %2686 = fadd <8 x float> %.state748, %2685
  %.state749 = load <8 x i64>, ptr %.slot167, align 64
  %2687 = add <8 x i64> %.state749, splat (i64 1)
  %2688 = load <8 x i64>, ptr %.slot167, align 64
  %2689 = select <8 x i1> %80, <8 x i64> %2687, <8 x i64> %2688
  store <8 x i64> %2689, ptr %.slot167, align 64
  %2690 = load <8 x float>, ptr %.slot168, align 32
  %2691 = select <8 x i1> %80, <8 x float> %2686, <8 x float> %2690
  store <8 x float> %2691, ptr %.slot168, align 32
  br label %direct.schedule.81

direct.schedule.83:                               ; preds = %direct.false743
  %.spill.load750 = load <8 x float>, ptr %.spill143, align 32
  %2692 = load <8 x i64>, ptr %.slot169, align 64
  %2693 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2692
  store <8 x i64> %2693, ptr %.slot169, align 64
  %2694 = load <8 x float>, ptr %.slot170, align 32
  %2695 = select <8 x i1> %80, <8 x float> %.spill.load750, <8 x float> %2694
  store <8 x float> %2695, ptr %.slot170, align 32
  br label %direct.schedule.84

direct.schedule.84:                               ; preds = %direct.schedule.85, %direct.schedule.83
  %.state751 = load <8 x i64>, ptr %.slot169, align 64
  %2696 = icmp slt <8 x i64> %.state751, splat (i64 65)
  %2697 = extractelement <8 x i1> %2696, i32 0
  br i1 %2697, label %direct.true752, label %direct.false753

direct.schedule.85:                               ; preds = %direct.true752
  %.state754 = load <8 x i64>, ptr %.slot169, align 64
  %2698 = add <8 x i64> splat (i64 65), %.state754
  %tile_snapshot.spill.load755 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load755, 0
  %2700 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load755, 1
  %2701 = mul <8 x i64> %2698, splat (i64 32)
  %2702 = add <8 x i64> %2700, %2701
  %2703 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2699, 0
  %2704 = insertvalue { <8 x ptr>, <8 x i64> } %2703, <8 x i64> %2702, 1
  %2705 = extractvalue { <8 x ptr>, <8 x i64> } %2704, 0
  %2706 = extractvalue { <8 x ptr>, <8 x i64> } %2704, 1
  %2707 = getelementptr i8, <8 x ptr> %2705, <8 x i64> %2706
  %2708 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2707, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state756 = load <8 x i64>, ptr %.slot169, align 64
  %2709 = add <8 x i64> zeroinitializer, %.state756
  %2710 = mul <8 x i64> %2709, splat (i64 7)
  %2711 = add <8 x i64> %2710, splat (i64 5)
  %tile_snapshot.spill.load757 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2712 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load757, 0
  %2713 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load757, 1
  %2714 = mul <8 x i64> %2711, splat (i64 32)
  %2715 = add <8 x i64> %2713, %2714
  %2716 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2712, 0
  %2717 = insertvalue { <8 x ptr>, <8 x i64> } %2716, <8 x i64> %2715, 1
  %2718 = extractvalue { <8 x ptr>, <8 x i64> } %2717, 0
  %2719 = extractvalue { <8 x ptr>, <8 x i64> } %2717, 1
  %2720 = getelementptr i8, <8 x ptr> %2718, <8 x i64> %2719
  %2721 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2720, <8 x i1> %80, <8 x float> zeroinitializer)
  %2722 = fmul <8 x float> %2708, %2721
  %.state758 = load <8 x float>, ptr %.slot170, align 32
  %2723 = fadd <8 x float> %.state758, %2722
  %.state759 = load <8 x i64>, ptr %.slot169, align 64
  %2724 = add <8 x i64> %.state759, splat (i64 1)
  %2725 = load <8 x i64>, ptr %.slot169, align 64
  %2726 = select <8 x i1> %80, <8 x i64> %2724, <8 x i64> %2725
  store <8 x i64> %2726, ptr %.slot169, align 64
  %2727 = load <8 x float>, ptr %.slot170, align 32
  %2728 = select <8 x i1> %80, <8 x float> %2723, <8 x float> %2727
  store <8 x float> %2728, ptr %.slot170, align 32
  br label %direct.schedule.84

direct.schedule.86:                               ; preds = %direct.false753
  %.spill.load760 = load <8 x float>, ptr %.spill144, align 32
  %2729 = load <8 x i64>, ptr %.slot171, align 64
  %2730 = select <8 x i1> %80, <8 x i64> zeroinitializer, <8 x i64> %2729
  store <8 x i64> %2730, ptr %.slot171, align 64
  %2731 = load <8 x float>, ptr %.slot172, align 32
  %2732 = select <8 x i1> %80, <8 x float> %.spill.load760, <8 x float> %2731
  store <8 x float> %2732, ptr %.slot172, align 32
  br label %direct.schedule.87

direct.schedule.87:                               ; preds = %direct.schedule.88, %direct.schedule.86
  %.state761 = load <8 x i64>, ptr %.slot171, align 64
  %2733 = icmp slt <8 x i64> %.state761, splat (i64 65)
  %2734 = extractelement <8 x i1> %2733, i32 0
  br i1 %2734, label %direct.true762, label %direct.false763

direct.schedule.88:                               ; preds = %direct.true762
  %.state764 = load <8 x i64>, ptr %.slot171, align 64
  %2735 = add <8 x i64> splat (i64 65), %.state764
  %tile_snapshot.spill.load765 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %2736 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load765, 0
  %2737 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load765, 1
  %2738 = mul <8 x i64> %2735, splat (i64 32)
  %2739 = add <8 x i64> %2737, %2738
  %2740 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2736, 0
  %2741 = insertvalue { <8 x ptr>, <8 x i64> } %2740, <8 x i64> %2739, 1
  %2742 = extractvalue { <8 x ptr>, <8 x i64> } %2741, 0
  %2743 = extractvalue { <8 x ptr>, <8 x i64> } %2741, 1
  %2744 = getelementptr i8, <8 x ptr> %2742, <8 x i64> %2743
  %2745 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2744, <8 x i1> %80, <8 x float> zeroinitializer)
  %.state766 = load <8 x i64>, ptr %.slot171, align 64
  %2746 = add <8 x i64> zeroinitializer, %.state766
  %2747 = mul <8 x i64> %2746, splat (i64 7)
  %2748 = add <8 x i64> %2747, splat (i64 6)
  %tile_snapshot.spill.load767 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill67, align 64
  %2749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load767, 0
  %2750 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load767, 1
  %2751 = mul <8 x i64> %2748, splat (i64 32)
  %2752 = add <8 x i64> %2750, %2751
  %2753 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2749, 0
  %2754 = insertvalue { <8 x ptr>, <8 x i64> } %2753, <8 x i64> %2752, 1
  %2755 = extractvalue { <8 x ptr>, <8 x i64> } %2754, 0
  %2756 = extractvalue { <8 x ptr>, <8 x i64> } %2754, 1
  %2757 = getelementptr i8, <8 x ptr> %2755, <8 x i64> %2756
  %2758 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %2757, <8 x i1> %80, <8 x float> zeroinitializer)
  %2759 = fmul <8 x float> %2745, %2758
  %.state768 = load <8 x float>, ptr %.slot172, align 32
  %2760 = fadd <8 x float> %.state768, %2759
  %.state769 = load <8 x i64>, ptr %.slot171, align 64
  %2761 = add <8 x i64> %.state769, splat (i64 1)
  %2762 = load <8 x i64>, ptr %.slot171, align 64
  %2763 = select <8 x i1> %80, <8 x i64> %2761, <8 x i64> %2762
  store <8 x i64> %2763, ptr %.slot171, align 64
  %2764 = load <8 x float>, ptr %.slot172, align 32
  %2765 = select <8 x i1> %80, <8 x float> %2760, <8 x float> %2764
  store <8 x float> %2765, ptr %.slot172, align 32
  br label %direct.schedule.87

direct.schedule.89:                               ; preds = %direct.false763
  %.state770 = load <8 x i64>, ptr %.slot44, align 64
  %2766 = add <8 x i64> %.state770, splat (i64 1)
  %.spill.load771 = load <8 x float>, ptr %.spill110, align 32
  %.spill.load772 = load <8 x float>, ptr %.spill111, align 32
  %.spill.load773 = load <8 x float>, ptr %.spill130, align 32
  %.spill.load774 = load <8 x float>, ptr %.spill131, align 32
  %.state775 = load <8 x float>, ptr %.slot146, align 32
  %.state776 = load <8 x float>, ptr %.slot148, align 32
  %.state777 = load <8 x float>, ptr %.slot150, align 32
  %.state778 = load <8 x float>, ptr %.slot152, align 32
  %.state779 = load <8 x float>, ptr %.slot154, align 32
  %.state780 = load <8 x float>, ptr %.slot156, align 32
  %.state781 = load <8 x float>, ptr %.slot158, align 32
  %.state782 = load <8 x float>, ptr %.slot160, align 32
  %.state783 = load <8 x float>, ptr %.slot162, align 32
  %.state784 = load <8 x float>, ptr %.slot164, align 32
  %.state785 = load <8 x float>, ptr %.slot166, align 32
  %.state786 = load <8 x float>, ptr %.slot168, align 32
  %.state787 = load <8 x float>, ptr %.slot170, align 32
  %.state788 = load <8 x float>, ptr %.slot172, align 32
  %2767 = load <8 x i64>, ptr %.slot44, align 64
  %2768 = select <8 x i1> %80, <8 x i64> %2766, <8 x i64> %2767
  store <8 x i64> %2768, ptr %.slot44, align 64
  %2769 = load <8 x float>, ptr %.slot45, align 32
  %2770 = select <8 x i1> %80, <8 x float> %.spill.load771, <8 x float> %2769
  store <8 x float> %2770, ptr %.slot45, align 32
  %2771 = load <8 x float>, ptr %.slot46, align 32
  %2772 = select <8 x i1> %80, <8 x float> %.spill.load772, <8 x float> %2771
  store <8 x float> %2772, ptr %.slot46, align 32
  %2773 = load <8 x float>, ptr %.slot47, align 32
  %2774 = select <8 x i1> %80, <8 x float> %.spill.load773, <8 x float> %2773
  store <8 x float> %2774, ptr %.slot47, align 32
  %2775 = load <8 x float>, ptr %.slot48, align 32
  %2776 = select <8 x i1> %80, <8 x float> %.spill.load774, <8 x float> %2775
  store <8 x float> %2776, ptr %.slot48, align 32
  %2777 = load <8 x float>, ptr %.slot49, align 32
  %2778 = select <8 x i1> %80, <8 x float> %.state775, <8 x float> %2777
  store <8 x float> %2778, ptr %.slot49, align 32
  %2779 = load <8 x float>, ptr %.slot50, align 32
  %2780 = select <8 x i1> %80, <8 x float> %.state776, <8 x float> %2779
  store <8 x float> %2780, ptr %.slot50, align 32
  %2781 = load <8 x float>, ptr %.slot51, align 32
  %2782 = select <8 x i1> %80, <8 x float> %.state777, <8 x float> %2781
  store <8 x float> %2782, ptr %.slot51, align 32
  %2783 = load <8 x float>, ptr %.slot52, align 32
  %2784 = select <8 x i1> %80, <8 x float> %.state778, <8 x float> %2783
  store <8 x float> %2784, ptr %.slot52, align 32
  %2785 = load <8 x float>, ptr %.slot53, align 32
  %2786 = select <8 x i1> %80, <8 x float> %.state779, <8 x float> %2785
  store <8 x float> %2786, ptr %.slot53, align 32
  %2787 = load <8 x float>, ptr %.slot54, align 32
  %2788 = select <8 x i1> %80, <8 x float> %.state780, <8 x float> %2787
  store <8 x float> %2788, ptr %.slot54, align 32
  %2789 = load <8 x float>, ptr %.slot55, align 32
  %2790 = select <8 x i1> %80, <8 x float> %.state781, <8 x float> %2789
  store <8 x float> %2790, ptr %.slot55, align 32
  %2791 = load <8 x float>, ptr %.slot56, align 32
  %2792 = select <8 x i1> %80, <8 x float> %.state782, <8 x float> %2791
  store <8 x float> %2792, ptr %.slot56, align 32
  %2793 = load <8 x float>, ptr %.slot57, align 32
  %2794 = select <8 x i1> %80, <8 x float> %.state783, <8 x float> %2793
  store <8 x float> %2794, ptr %.slot57, align 32
  %2795 = load <8 x float>, ptr %.slot58, align 32
  %2796 = select <8 x i1> %80, <8 x float> %.state784, <8 x float> %2795
  store <8 x float> %2796, ptr %.slot58, align 32
  %2797 = load <8 x float>, ptr %.slot59, align 32
  %2798 = select <8 x i1> %80, <8 x float> %.state785, <8 x float> %2797
  store <8 x float> %2798, ptr %.slot59, align 32
  %2799 = load <8 x float>, ptr %.slot60, align 32
  %2800 = select <8 x i1> %80, <8 x float> %.state786, <8 x float> %2799
  store <8 x float> %2800, ptr %.slot60, align 32
  %2801 = load <8 x float>, ptr %.slot61, align 32
  %2802 = select <8 x i1> %80, <8 x float> %.state787, <8 x float> %2801
  store <8 x float> %2802, ptr %.slot61, align 32
  %2803 = load <8 x float>, ptr %.slot62, align 32
  %2804 = select <8 x i1> %80, <8 x float> %.state788, <8 x float> %2803
  store <8 x float> %2804, ptr %.slot62, align 32
  br label %direct.schedule.6

direct.schedule.90:                               ; preds = %direct.false205
  %.state789 = load <8 x float>, ptr %.slot49, align 32
  %.state790 = load <8 x float>, ptr %.slot47, align 32
  %2805 = fdiv <8 x float> %.state789, %.state790
  %.state791 = load <8 x float>, ptr %.slot50, align 32
  %.state792 = load <8 x float>, ptr %.slot47, align 32
  %2806 = fdiv <8 x float> %.state791, %.state792
  %.state793 = load <8 x float>, ptr %.slot51, align 32
  %.state794 = load <8 x float>, ptr %.slot47, align 32
  %2807 = fdiv <8 x float> %.state793, %.state794
  %.state795 = load <8 x float>, ptr %.slot52, align 32
  %.state796 = load <8 x float>, ptr %.slot47, align 32
  %2808 = fdiv <8 x float> %.state795, %.state796
  %.state797 = load <8 x float>, ptr %.slot53, align 32
  %.state798 = load <8 x float>, ptr %.slot47, align 32
  %2809 = fdiv <8 x float> %.state797, %.state798
  %.state799 = load <8 x float>, ptr %.slot54, align 32
  %.state800 = load <8 x float>, ptr %.slot47, align 32
  %2810 = fdiv <8 x float> %.state799, %.state800
  %.state801 = load <8 x float>, ptr %.slot55, align 32
  %.state802 = load <8 x float>, ptr %.slot47, align 32
  %2811 = fdiv <8 x float> %.state801, %.state802
  %.state803 = load <8 x float>, ptr %.slot56, align 32
  %.state804 = load <8 x float>, ptr %.slot48, align 32
  %2812 = fdiv <8 x float> %.state803, %.state804
  %.state805 = load <8 x float>, ptr %.slot57, align 32
  %.state806 = load <8 x float>, ptr %.slot48, align 32
  %2813 = fdiv <8 x float> %.state805, %.state806
  %2814 = load <8 x float>, ptr %.spill173, align 32
  %2815 = select <8 x i1> %80, <8 x float> %2813, <8 x float> %2814
  store <8 x float> %2815, ptr %.spill173, align 32
  %.state807 = load <8 x float>, ptr %.slot58, align 32
  %.state808 = load <8 x float>, ptr %.slot48, align 32
  %2816 = fdiv <8 x float> %.state807, %.state808
  %2817 = load <8 x float>, ptr %.spill174, align 32
  %2818 = select <8 x i1> %80, <8 x float> %2816, <8 x float> %2817
  store <8 x float> %2818, ptr %.spill174, align 32
  %.state809 = load <8 x float>, ptr %.slot59, align 32
  %.state810 = load <8 x float>, ptr %.slot48, align 32
  %2819 = fdiv <8 x float> %.state809, %.state810
  %2820 = load <8 x float>, ptr %.spill175, align 32
  %2821 = select <8 x i1> %80, <8 x float> %2819, <8 x float> %2820
  store <8 x float> %2821, ptr %.spill175, align 32
  %.state811 = load <8 x float>, ptr %.slot60, align 32
  %.state812 = load <8 x float>, ptr %.slot48, align 32
  %2822 = fdiv <8 x float> %.state811, %.state812
  %2823 = load <8 x float>, ptr %.spill176, align 32
  %2824 = select <8 x i1> %80, <8 x float> %2822, <8 x float> %2823
  store <8 x float> %2824, ptr %.spill176, align 32
  %.state813 = load <8 x float>, ptr %.slot61, align 32
  %.state814 = load <8 x float>, ptr %.slot48, align 32
  %2825 = fdiv <8 x float> %.state813, %.state814
  %2826 = load <8 x float>, ptr %.spill177, align 32
  %2827 = select <8 x i1> %80, <8 x float> %2825, <8 x float> %2826
  store <8 x float> %2827, ptr %.spill177, align 32
  %.state815 = load <8 x float>, ptr %.slot62, align 32
  %.state816 = load <8 x float>, ptr %.slot48, align 32
  %2828 = fdiv <8 x float> %.state815, %.state816
  %2829 = load <8 x float>, ptr %.spill178, align 32
  %2830 = select <8 x i1> %80, <8 x float> %2828, <8 x float> %2829
  store <8 x float> %2830, ptr %.spill178, align 32
  %.spill.load817 = load <8 x i64>, ptr %.spill, align 64
  %2831 = add <8 x i64> %.spill.load817, zeroinitializer
  %2832 = add <8 x i64> zeroinitializer, %2831
  %.spill.load818 = load <8 x i64>, ptr %.spill41, align 64
  %2833 = add <8 x i64> %.spill.load818, zeroinitializer
  %2834 = mul <8 x i64> %2832, splat (i64 3)
  %2835 = add <8 x i64> %2834, %2833
  %2836 = mul <8 x i64> %2835, splat (i64 7)
  %2837 = add <8 x i64> %2836, zeroinitializer
  %2838 = extractvalue { ptr, i64 } %56, 0
  %2839 = mul <8 x i64> %2837, splat (i64 4)
  %2840 = getelementptr i8, ptr %2838, <8 x i64> %2839
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2805, <8 x ptr> align 1 %2840, <8 x i1> %80)
  store i64 1, ptr %.spill179, align 4
  %2841 = add <8 x i64> %2836, splat (i64 1)
  %2842 = extractvalue { ptr, i64 } %56, 0
  %2843 = mul <8 x i64> %2841, splat (i64 4)
  %2844 = getelementptr i8, ptr %2842, <8 x i64> %2843
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2806, <8 x ptr> align 1 %2844, <8 x i1> %80)
  store i64 2, ptr %.spill180, align 4
  %2845 = add <8 x i64> %2836, splat (i64 2)
  %2846 = extractvalue { ptr, i64 } %56, 0
  %2847 = mul <8 x i64> %2845, splat (i64 4)
  %2848 = getelementptr i8, ptr %2846, <8 x i64> %2847
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2807, <8 x ptr> align 1 %2848, <8 x i1> %80)
  store i64 3, ptr %.spill181, align 4
  %2849 = add <8 x i64> %2836, splat (i64 3)
  %2850 = extractvalue { ptr, i64 } %56, 0
  %2851 = mul <8 x i64> %2849, splat (i64 4)
  %2852 = getelementptr i8, ptr %2850, <8 x i64> %2851
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2808, <8 x ptr> align 1 %2852, <8 x i1> %80)
  store i64 4, ptr %.spill182, align 4
  %2853 = add <8 x i64> %2836, splat (i64 4)
  %2854 = extractvalue { ptr, i64 } %56, 0
  %2855 = mul <8 x i64> %2853, splat (i64 4)
  %2856 = getelementptr i8, ptr %2854, <8 x i64> %2855
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2809, <8 x ptr> align 1 %2856, <8 x i1> %80)
  store i64 5, ptr %.spill183, align 4
  %2857 = add <8 x i64> %2836, splat (i64 5)
  %2858 = extractvalue { ptr, i64 } %56, 0
  %2859 = mul <8 x i64> %2857, splat (i64 4)
  %2860 = getelementptr i8, ptr %2858, <8 x i64> %2859
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2810, <8 x ptr> align 1 %2860, <8 x i1> %80)
  store i64 6, ptr %.spill184, align 4
  %2861 = add <8 x i64> %2836, splat (i64 6)
  %2862 = extractvalue { ptr, i64 } %56, 0
  %2863 = mul <8 x i64> %2861, splat (i64 4)
  %2864 = getelementptr i8, ptr %2862, <8 x i64> %2863
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2811, <8 x ptr> align 1 %2864, <8 x i1> %80)
  %.spill.load819 = load <8 x i64>, ptr %.spill41, align 64
  %2865 = add <8 x i64> %.spill.load819, splat (i64 1)
  %2866 = add <8 x i64> %2834, %2865
  %2867 = icmp sge <8 x i64> %2865, zeroinitializer
  %2868 = and <8 x i1> splat (i1 true), %2867
  %2869 = icmp slt <8 x i64> %2865, splat (i64 3)
  %2870 = and <8 x i1> %2868, %2869
  %2871 = load <8 x i1>, ptr %.spill185, align 1
  %2872 = select <8 x i1> %80, <8 x i1> %2870, <8 x i1> %2871
  store <8 x i1> %2872, ptr %.spill185, align 1
  %2873 = mul <8 x i64> %2866, splat (i64 7)
  %2874 = load <8 x i64>, ptr %.spill186, align 64
  %2875 = select <8 x i1> %80, <8 x i64> %2873, <8 x i64> %2874
  store <8 x i64> %2875, ptr %.spill186, align 64
  %2876 = add <8 x i64> %2873, zeroinitializer
  %2877 = and <8 x i1> %80, %2870
  %2878 = xor <8 x i1> %2870, splat (i1 true)
  %2879 = and <8 x i1> %80, %2878
  %2880 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2877)
  %2881 = bitcast <8 x i1> %2877 to i8
  %2882 = call i8 @llvm.cttz.i8(i8 %2881, i1 false)
  %2883 = zext i8 %2882 to i32
  %2884 = select i1 %2880, i32 %2883, i32 0
  %2885 = extractvalue { ptr, i64 } %56, 0
  %2886 = mul <8 x i64> %2876, splat (i64 4)
  %2887 = getelementptr i8, ptr %2885, <8 x i64> %2886
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %2812, <8 x ptr> align 1 %2887, <8 x i1> %2877)
  %2888 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2879)
  %2889 = bitcast <8 x i1> %2879 to i8
  %2890 = call i8 @llvm.cttz.i8(i8 %2889, i1 false)
  %2891 = zext i8 %2890 to i32
  %2892 = select i1 %2888, i32 %2891, i32 0
  br label %direct.schedule.92

direct.schedule.92:                               ; preds = %direct.schedule.90
  %.spill.load820 = load <8 x i64>, ptr %.spill186, align 64
  %.spill.load821 = load i64, ptr %.spill179, align 4
  %.splatinsert822 = insertelement <8 x i64> poison, i64 %.spill.load821, i64 0
  %.splat823 = shufflevector <8 x i64> %.splatinsert822, <8 x i64> poison, <8 x i32> zeroinitializer
  %2893 = add <8 x i64> %.spill.load820, %.splat823
  %.spill.load824 = load <8 x i1>, ptr %.spill185, align 1
  %2894 = and <8 x i1> %80, %.spill.load824
  %2895 = xor <8 x i1> %.spill.load824, splat (i1 true)
  %2896 = and <8 x i1> %80, %2895
  %2897 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2894)
  %2898 = bitcast <8 x i1> %2894 to i8
  %2899 = call i8 @llvm.cttz.i8(i8 %2898, i1 false)
  %2900 = zext i8 %2899 to i32
  %2901 = select i1 %2897, i32 %2900, i32 0
  %.spill.load825 = load <8 x float>, ptr %.spill173, align 32
  %2902 = extractvalue { ptr, i64 } %56, 0
  %2903 = mul <8 x i64> %2893, splat (i64 4)
  %2904 = getelementptr i8, ptr %2902, <8 x i64> %2903
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load825, <8 x ptr> align 1 %2904, <8 x i1> %2894)
  %2905 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2896)
  %2906 = bitcast <8 x i1> %2896 to i8
  %2907 = call i8 @llvm.cttz.i8(i8 %2906, i1 false)
  %2908 = zext i8 %2907 to i32
  %2909 = select i1 %2905, i32 %2908, i32 0
  br label %direct.schedule.94

direct.schedule.94:                               ; preds = %direct.schedule.92
  %.spill.load826 = load <8 x i64>, ptr %.spill186, align 64
  %.spill.load827 = load i64, ptr %.spill180, align 4
  %.splatinsert828 = insertelement <8 x i64> poison, i64 %.spill.load827, i64 0
  %.splat829 = shufflevector <8 x i64> %.splatinsert828, <8 x i64> poison, <8 x i32> zeroinitializer
  %2910 = add <8 x i64> %.spill.load826, %.splat829
  %.spill.load830 = load <8 x i1>, ptr %.spill185, align 1
  %2911 = and <8 x i1> %80, %.spill.load830
  %2912 = xor <8 x i1> %.spill.load830, splat (i1 true)
  %2913 = and <8 x i1> %80, %2912
  %2914 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2911)
  %2915 = bitcast <8 x i1> %2911 to i8
  %2916 = call i8 @llvm.cttz.i8(i8 %2915, i1 false)
  %2917 = zext i8 %2916 to i32
  %2918 = select i1 %2914, i32 %2917, i32 0
  %.spill.load831 = load <8 x float>, ptr %.spill174, align 32
  %2919 = extractvalue { ptr, i64 } %56, 0
  %2920 = mul <8 x i64> %2910, splat (i64 4)
  %2921 = getelementptr i8, ptr %2919, <8 x i64> %2920
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load831, <8 x ptr> align 1 %2921, <8 x i1> %2911)
  %2922 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2913)
  %2923 = bitcast <8 x i1> %2913 to i8
  %2924 = call i8 @llvm.cttz.i8(i8 %2923, i1 false)
  %2925 = zext i8 %2924 to i32
  %2926 = select i1 %2922, i32 %2925, i32 0
  br label %direct.schedule.96

direct.schedule.96:                               ; preds = %direct.schedule.94
  %.spill.load832 = load <8 x i64>, ptr %.spill186, align 64
  %.spill.load833 = load i64, ptr %.spill181, align 4
  %.splatinsert834 = insertelement <8 x i64> poison, i64 %.spill.load833, i64 0
  %.splat835 = shufflevector <8 x i64> %.splatinsert834, <8 x i64> poison, <8 x i32> zeroinitializer
  %2927 = add <8 x i64> %.spill.load832, %.splat835
  %.spill.load836 = load <8 x i1>, ptr %.spill185, align 1
  %2928 = and <8 x i1> %80, %.spill.load836
  %2929 = xor <8 x i1> %.spill.load836, splat (i1 true)
  %2930 = and <8 x i1> %80, %2929
  %2931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2928)
  %2932 = bitcast <8 x i1> %2928 to i8
  %2933 = call i8 @llvm.cttz.i8(i8 %2932, i1 false)
  %2934 = zext i8 %2933 to i32
  %2935 = select i1 %2931, i32 %2934, i32 0
  %.spill.load837 = load <8 x float>, ptr %.spill175, align 32
  %2936 = extractvalue { ptr, i64 } %56, 0
  %2937 = mul <8 x i64> %2927, splat (i64 4)
  %2938 = getelementptr i8, ptr %2936, <8 x i64> %2937
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load837, <8 x ptr> align 1 %2938, <8 x i1> %2928)
  %2939 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2930)
  %2940 = bitcast <8 x i1> %2930 to i8
  %2941 = call i8 @llvm.cttz.i8(i8 %2940, i1 false)
  %2942 = zext i8 %2941 to i32
  %2943 = select i1 %2939, i32 %2942, i32 0
  br label %direct.schedule.98

direct.schedule.98:                               ; preds = %direct.schedule.96
  %.spill.load838 = load <8 x i64>, ptr %.spill186, align 64
  %.spill.load839 = load i64, ptr %.spill182, align 4
  %.splatinsert840 = insertelement <8 x i64> poison, i64 %.spill.load839, i64 0
  %.splat841 = shufflevector <8 x i64> %.splatinsert840, <8 x i64> poison, <8 x i32> zeroinitializer
  %2944 = add <8 x i64> %.spill.load838, %.splat841
  %.spill.load842 = load <8 x i1>, ptr %.spill185, align 1
  %2945 = and <8 x i1> %80, %.spill.load842
  %2946 = xor <8 x i1> %.spill.load842, splat (i1 true)
  %2947 = and <8 x i1> %80, %2946
  %2948 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2945)
  %2949 = bitcast <8 x i1> %2945 to i8
  %2950 = call i8 @llvm.cttz.i8(i8 %2949, i1 false)
  %2951 = zext i8 %2950 to i32
  %2952 = select i1 %2948, i32 %2951, i32 0
  %.spill.load843 = load <8 x float>, ptr %.spill176, align 32
  %2953 = extractvalue { ptr, i64 } %56, 0
  %2954 = mul <8 x i64> %2944, splat (i64 4)
  %2955 = getelementptr i8, ptr %2953, <8 x i64> %2954
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load843, <8 x ptr> align 1 %2955, <8 x i1> %2945)
  %2956 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2947)
  %2957 = bitcast <8 x i1> %2947 to i8
  %2958 = call i8 @llvm.cttz.i8(i8 %2957, i1 false)
  %2959 = zext i8 %2958 to i32
  %2960 = select i1 %2956, i32 %2959, i32 0
  br label %direct.schedule.100

direct.schedule.100:                              ; preds = %direct.schedule.98
  %.spill.load844 = load <8 x i64>, ptr %.spill186, align 64
  %.spill.load845 = load i64, ptr %.spill183, align 4
  %.splatinsert846 = insertelement <8 x i64> poison, i64 %.spill.load845, i64 0
  %.splat847 = shufflevector <8 x i64> %.splatinsert846, <8 x i64> poison, <8 x i32> zeroinitializer
  %2961 = add <8 x i64> %.spill.load844, %.splat847
  %.spill.load848 = load <8 x i1>, ptr %.spill185, align 1
  %2962 = and <8 x i1> %80, %.spill.load848
  %2963 = xor <8 x i1> %.spill.load848, splat (i1 true)
  %2964 = and <8 x i1> %80, %2963
  %2965 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2962)
  %2966 = bitcast <8 x i1> %2962 to i8
  %2967 = call i8 @llvm.cttz.i8(i8 %2966, i1 false)
  %2968 = zext i8 %2967 to i32
  %2969 = select i1 %2965, i32 %2968, i32 0
  %.spill.load849 = load <8 x float>, ptr %.spill177, align 32
  %2970 = extractvalue { ptr, i64 } %56, 0
  %2971 = mul <8 x i64> %2961, splat (i64 4)
  %2972 = getelementptr i8, ptr %2970, <8 x i64> %2971
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load849, <8 x ptr> align 1 %2972, <8 x i1> %2962)
  %2973 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2964)
  %2974 = bitcast <8 x i1> %2964 to i8
  %2975 = call i8 @llvm.cttz.i8(i8 %2974, i1 false)
  %2976 = zext i8 %2975 to i32
  %2977 = select i1 %2973, i32 %2976, i32 0
  br label %direct.schedule.102

direct.schedule.102:                              ; preds = %direct.schedule.100
  %.spill.load850 = load <8 x i64>, ptr %.spill186, align 64
  %.spill.load851 = load i64, ptr %.spill184, align 4
  %.splatinsert852 = insertelement <8 x i64> poison, i64 %.spill.load851, i64 0
  %.splat853 = shufflevector <8 x i64> %.splatinsert852, <8 x i64> poison, <8 x i32> zeroinitializer
  %2978 = add <8 x i64> %.spill.load850, %.splat853
  %.spill.load854 = load <8 x i1>, ptr %.spill185, align 1
  %2979 = and <8 x i1> %80, %.spill.load854
  %2980 = xor <8 x i1> %.spill.load854, splat (i1 true)
  %2981 = and <8 x i1> %80, %2980
  %2982 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2979)
  %2983 = bitcast <8 x i1> %2979 to i8
  %2984 = call i8 @llvm.cttz.i8(i8 %2983, i1 false)
  %2985 = zext i8 %2984 to i32
  %2986 = select i1 %2982, i32 %2985, i32 0
  %.spill.load855 = load <8 x float>, ptr %.spill178, align 32
  %2987 = extractvalue { ptr, i64 } %56, 0
  %2988 = mul <8 x i64> %2978, splat (i64 4)
  %2989 = getelementptr i8, ptr %2987, <8 x i64> %2988
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.spill.load855, <8 x ptr> align 1 %2989, <8 x i1> %2979)
  %2990 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2981)
  %2991 = bitcast <8 x i1> %2981 to i8
  %2992 = call i8 @llvm.cttz.i8(i8 %2991, i1 false)
  %2993 = zext i8 %2992 to i32
  %2994 = select i1 %2990, i32 %2993, i32 0
  br label %direct.schedule.104

direct.schedule.104:                              ; preds = %direct.schedule.102
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.5

direct.true204:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false205:                                  ; preds = %direct.schedule.6
  br label %direct.schedule.90

direct.true208:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false209:                                  ; preds = %direct.schedule.8
  br label %direct.schedule.12

direct.true219:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false220:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.17

direct.true230:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false231:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.20

direct.true304:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false305:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true311:                                   ; preds = %direct.schedule.24
  br label %direct.schedule.25

direct.false312:                                  ; preds = %direct.schedule.24
  br label %direct.schedule.26

direct.true322:                                   ; preds = %direct.schedule.27
  br label %direct.schedule.28

direct.false323:                                  ; preds = %direct.schedule.27
  br label %direct.schedule.29

direct.true335:                                   ; preds = %direct.schedule.30
  br label %direct.schedule.31

direct.false336:                                  ; preds = %direct.schedule.30
  br label %direct.schedule.32

direct.true356:                                   ; preds = %direct.schedule.33
  br label %direct.schedule.34

direct.false357:                                  ; preds = %direct.schedule.33
  br label %direct.schedule.35

direct.true419:                                   ; preds = %direct.schedule.36
  br label %direct.schedule.37

direct.false420:                                  ; preds = %direct.schedule.36
  br label %direct.schedule.38

direct.true468:                                   ; preds = %direct.schedule.39
  br label %direct.schedule.40

direct.false469:                                  ; preds = %direct.schedule.39
  br label %direct.schedule.41

direct.true508:                                   ; preds = %direct.schedule.42
  br label %direct.schedule.43

direct.false509:                                  ; preds = %direct.schedule.42
  br label %direct.schedule.44

direct.true570:                                   ; preds = %direct.schedule.45
  br label %direct.schedule.46

direct.false571:                                  ; preds = %direct.schedule.45
  br label %direct.schedule.47

direct.true639:                                   ; preds = %direct.schedule.48
  br label %direct.schedule.49

direct.false640:                                  ; preds = %direct.schedule.48
  br label %direct.schedule.50

direct.true648:                                   ; preds = %direct.schedule.51
  br label %direct.schedule.52

direct.false649:                                  ; preds = %direct.schedule.51
  br label %direct.schedule.53

direct.true657:                                   ; preds = %direct.schedule.54
  br label %direct.schedule.55

direct.false658:                                  ; preds = %direct.schedule.54
  br label %direct.schedule.56

direct.true666:                                   ; preds = %direct.schedule.57
  br label %direct.schedule.58

direct.false667:                                  ; preds = %direct.schedule.57
  br label %direct.schedule.59

direct.true675:                                   ; preds = %direct.schedule.60
  br label %direct.schedule.61

direct.false676:                                  ; preds = %direct.schedule.60
  br label %direct.schedule.62

direct.true684:                                   ; preds = %direct.schedule.63
  br label %direct.schedule.64

direct.false685:                                  ; preds = %direct.schedule.63
  br label %direct.schedule.65

direct.true693:                                   ; preds = %direct.schedule.66
  br label %direct.schedule.67

direct.false694:                                  ; preds = %direct.schedule.66
  br label %direct.schedule.68

direct.true702:                                   ; preds = %direct.schedule.69
  br label %direct.schedule.70

direct.false703:                                  ; preds = %direct.schedule.69
  br label %direct.schedule.71

direct.true712:                                   ; preds = %direct.schedule.72
  br label %direct.schedule.73

direct.false713:                                  ; preds = %direct.schedule.72
  br label %direct.schedule.74

direct.true722:                                   ; preds = %direct.schedule.75
  br label %direct.schedule.76

direct.false723:                                  ; preds = %direct.schedule.75
  br label %direct.schedule.77

direct.true732:                                   ; preds = %direct.schedule.78
  br label %direct.schedule.79

direct.false733:                                  ; preds = %direct.schedule.78
  br label %direct.schedule.80

direct.true742:                                   ; preds = %direct.schedule.81
  br label %direct.schedule.82

direct.false743:                                  ; preds = %direct.schedule.81
  br label %direct.schedule.83

direct.true752:                                   ; preds = %direct.schedule.84
  br label %direct.schedule.85

direct.false753:                                  ; preds = %direct.schedule.84
  br label %direct.schedule.86

direct.true762:                                   ; preds = %direct.schedule.87
  br label %direct.schedule.88

direct.false763:                                  ; preds = %direct.schedule.87
  br label %direct.schedule.89
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i64.v8p0(<8 x i64>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, <8 x i1>, <8 x i64>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #3

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_attention(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [64 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [32 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local4 = alloca [32 x i8], align 4
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local7 = alloca [32 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [32 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local13 = alloca [64 x i8], align 4
  %.splatinsert14 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local13, i64 0
  %.splat15 = shufflevector <8 x ptr> %.splatinsert14, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat15, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local16 = alloca [64 x i8], align 4
  %.splatinsert17 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local16, i64 0
  %.splat18 = shufflevector <8 x ptr> %.splatinsert17, <8 x ptr> poison, <8 x i32> zeroinitializer
  %12 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat18, 0
  %13 = insertvalue { <8 x ptr>, <8 x i64> } %12, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local19 = alloca [1120 x i8], align 4
  %.splatinsert20 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local19, i64 0
  %.splat21 = shufflevector <8 x ptr> %.splatinsert20, <8 x ptr> poison, <8 x i32> zeroinitializer
  %14 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat21, 0
  %15 = insertvalue { <8 x ptr>, <8 x i64> } %14, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local22 = alloca [1056 x i8], align 4
  %.splatinsert23 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local22, i64 0
  %.splat24 = shufflevector <8 x ptr> %.splatinsert23, <8 x ptr> poison, <8 x i32> zeroinitializer
  %16 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat24, 0
  %17 = insertvalue { <8 x ptr>, <8 x i64> } %16, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local25 = alloca [320 x i8], align 4
  %.splatinsert26 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local25, i64 0
  %.splat27 = shufflevector <8 x ptr> %.splatinsert26, <8 x ptr> poison, <8 x i32> zeroinitializer
  %18 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat27, 0
  %19 = insertvalue { <8 x ptr>, <8 x i64> } %18, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local28 = alloca [320 x i8], align 4
  %.splatinsert29 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local28, i64 0
  %.splat30 = shufflevector <8 x ptr> %.splatinsert29, <8 x ptr> poison, <8 x i32> zeroinitializer
  %20 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat30, 0
  %21 = insertvalue { <8 x ptr>, <8 x i64> } %20, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local31 = alloca [320 x i8], align 8
  %.splatinsert32 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local31, i64 0
  %.splat33 = shufflevector <8 x ptr> %.splatinsert32, <8 x ptr> poison, <8 x i32> zeroinitializer
  %22 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat33, 0
  %23 = insertvalue { <8 x ptr>, <8 x i64> } %22, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local34 = alloca [320 x i8], align 8
  %.splatinsert35 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local34, i64 0
  %.splat36 = shufflevector <8 x ptr> %.splatinsert35, <8 x ptr> poison, <8 x i32> zeroinitializer
  %24 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat36, 0
  %25 = insertvalue { <8 x ptr>, <8 x i64> } %24, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local37 = alloca [40 x i8], align 1
  %.splatinsert38 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local37, i64 0
  %.splat39 = shufflevector <8 x ptr> %.splatinsert38, <8 x ptr> poison, <8 x i32> zeroinitializer
  %26 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat39, 0
  %27 = insertvalue { <8 x ptr>, <8 x i64> } %26, <8 x i64> <i64 0, i64 5, i64 10, i64 15, i64 20, i64 25, i64 30, i64 35>, 1
  %tile_snapshot.local40 = alloca [320 x i8], align 8
  %.splatinsert41 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local40, i64 0
  %.splat42 = shufflevector <8 x ptr> %.splatinsert41, <8 x ptr> poison, <8 x i32> zeroinitializer
  %28 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat42, 0
  %29 = insertvalue { <8 x ptr>, <8 x i64> } %28, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local43 = alloca [320 x i8], align 8
  %.splatinsert44 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local43, i64 0
  %.splat45 = shufflevector <8 x ptr> %.splatinsert44, <8 x ptr> poison, <8 x i32> zeroinitializer
  %30 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat45, 0
  %31 = insertvalue { <8 x ptr>, <8 x i64> } %30, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local46 = alloca [64 x i8], align 8
  %.splatinsert47 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local46, i64 0
  %.splat48 = shufflevector <8 x ptr> %.splatinsert47, <8 x ptr> poison, <8 x i32> zeroinitializer
  %32 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat48, 0
  %33 = insertvalue { <8 x ptr>, <8 x i64> } %32, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local49 = alloca [64 x i8], align 8
  %.splatinsert50 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local49, i64 0
  %.splat51 = shufflevector <8 x ptr> %.splatinsert50, <8 x ptr> poison, <8 x i32> zeroinitializer
  %34 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat51, 0
  %35 = insertvalue { <8 x ptr>, <8 x i64> } %34, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local52 = alloca [64 x i8], align 8
  %.splatinsert53 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local52, i64 0
  %.splat54 = shufflevector <8 x ptr> %.splatinsert53, <8 x ptr> poison, <8 x i32> zeroinitializer
  %36 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat54, 0
  %37 = insertvalue { <8 x ptr>, <8 x i64> } %36, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local55 = alloca [64 x i8], align 8
  %.splatinsert56 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local55, i64 0
  %.splat57 = shufflevector <8 x ptr> %.splatinsert56, <8 x ptr> poison, <8 x i32> zeroinitializer
  %38 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat57, 0
  %39 = insertvalue { <8 x ptr>, <8 x i64> } %38, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local58 = alloca [80 x i8], align 1
  %.splatinsert59 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local58, i64 0
  %.splat60 = shufflevector <8 x ptr> %.splatinsert59, <8 x ptr> poison, <8 x i32> zeroinitializer
  %40 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat60, 0
  %41 = insertvalue { <8 x ptr>, <8 x i64> } %40, <8 x i64> <i64 0, i64 10, i64 20, i64 30, i64 40, i64 50, i64 60, i64 70>, 1
  %tile_snapshot.local61 = alloca [80 x i8], align 1
  %.splatinsert62 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local61, i64 0
  %.splat63 = shufflevector <8 x ptr> %.splatinsert62, <8 x ptr> poison, <8 x i32> zeroinitializer
  %42 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat63, 0
  %43 = insertvalue { <8 x ptr>, <8 x i64> } %42, <8 x i64> <i64 0, i64 10, i64 20, i64 30, i64 40, i64 50, i64 60, i64 70>, 1
  %tile_snapshot.local64 = alloca [320 x i8], align 4
  %.splatinsert65 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local64, i64 0
  %.splat66 = shufflevector <8 x ptr> %.splatinsert65, <8 x ptr> poison, <8 x i32> zeroinitializer
  %44 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat66, 0
  %45 = insertvalue { <8 x ptr>, <8 x i64> } %44, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local67 = alloca [64 x i8], align 4
  %.splatinsert68 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local67, i64 0
  %.splat69 = shufflevector <8 x ptr> %.splatinsert68, <8 x ptr> poison, <8 x i32> zeroinitializer
  %46 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat69, 0
  %47 = insertvalue { <8 x ptr>, <8 x i64> } %46, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local70 = alloca [32 x i8], align 4
  %.splatinsert71 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local70, i64 0
  %.splat72 = shufflevector <8 x ptr> %.splatinsert71, <8 x ptr> poison, <8 x i32> zeroinitializer
  %48 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat72, 0
  %49 = insertvalue { <8 x ptr>, <8 x i64> } %48, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local73 = alloca [32 x i8], align 4
  %.splatinsert74 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local73, i64 0
  %.splat75 = shufflevector <8 x ptr> %.splatinsert74, <8 x ptr> poison, <8 x i32> zeroinitializer
  %50 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat75, 0
  %51 = insertvalue { <8 x ptr>, <8 x i64> } %50, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local76 = alloca [32 x i8], align 4
  %.splatinsert77 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local76, i64 0
  %.splat78 = shufflevector <8 x ptr> %.splatinsert77, <8 x ptr> poison, <8 x i32> zeroinitializer
  %52 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat78, 0
  %53 = insertvalue { <8 x ptr>, <8 x i64> } %52, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local79 = alloca [320 x i8], align 4
  %.splatinsert80 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local79, i64 0
  %.splat81 = shufflevector <8 x ptr> %.splatinsert80, <8 x ptr> poison, <8 x i32> zeroinitializer
  %54 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat81, 0
  %55 = insertvalue { <8 x ptr>, <8 x i64> } %54, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local82 = alloca [320 x i8], align 4
  %.splatinsert83 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local82, i64 0
  %.splat84 = shufflevector <8 x ptr> %.splatinsert83, <8 x ptr> poison, <8 x i32> zeroinitializer
  %56 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat84, 0
  %57 = insertvalue { <8 x ptr>, <8 x i64> } %56, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local85 = alloca [320 x i8], align 4
  %.splatinsert86 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local85, i64 0
  %.splat87 = shufflevector <8 x ptr> %.splatinsert86, <8 x ptr> poison, <8 x i32> zeroinitializer
  %58 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat87, 0
  %59 = insertvalue { <8 x ptr>, <8 x i64> } %58, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local88 = alloca [32 x i8], align 4
  %.splatinsert89 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local88, i64 0
  %.splat90 = shufflevector <8 x ptr> %.splatinsert89, <8 x ptr> poison, <8 x i32> zeroinitializer
  %60 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat90, 0
  %61 = insertvalue { <8 x ptr>, <8 x i64> } %60, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local91 = alloca [64 x i8], align 4
  %.splatinsert92 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local91, i64 0
  %.splat93 = shufflevector <8 x ptr> %.splatinsert92, <8 x ptr> poison, <8 x i32> zeroinitializer
  %62 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat93, 0
  %63 = insertvalue { <8 x ptr>, <8 x i64> } %62, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local94 = alloca [32 x i8], align 4
  %.splatinsert95 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local94, i64 0
  %.splat96 = shufflevector <8 x ptr> %.splatinsert95, <8 x ptr> poison, <8 x i32> zeroinitializer
  %64 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat96, 0
  %65 = insertvalue { <8 x ptr>, <8 x i64> } %64, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local97 = alloca [64 x i8], align 4
  %.splatinsert98 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local97, i64 0
  %.splat99 = shufflevector <8 x ptr> %.splatinsert98, <8 x ptr> poison, <8 x i32> zeroinitializer
  %66 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat99, 0
  %67 = insertvalue { <8 x ptr>, <8 x i64> } %66, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local100 = alloca [64 x i8], align 4
  %.splatinsert101 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local100, i64 0
  %.splat102 = shufflevector <8 x ptr> %.splatinsert101, <8 x ptr> poison, <8 x i32> zeroinitializer
  %68 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat102, 0
  %69 = insertvalue { <8 x ptr>, <8 x i64> } %68, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local103 = alloca [64 x i8], align 4
  %.splatinsert104 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local103, i64 0
  %.splat105 = shufflevector <8 x ptr> %.splatinsert104, <8 x ptr> poison, <8 x i32> zeroinitializer
  %70 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat105, 0
  %71 = insertvalue { <8 x ptr>, <8 x i64> } %70, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill106 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill106, align 64
  %.spill107 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill107, align 64
  %.spill108 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill108, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot, align 64
  %.spill109 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill109, align 1
  %.slot110 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot110, align 32
  %tile_snapshot.spill111 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill111, align 64
  %tile_snapshot.spill112 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill112, align 64
  %.slot113 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot113, align 64
  %tile_snapshot.spill114 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill114, align 64
  %tile_snapshot.spill115 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill115, align 64
  %.slot116 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot116, align 64
  %tile_snapshot.spill117 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill117, align 64
  %tile_snapshot.spill118 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill118, align 64
  %.slot119 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot119, align 64
  %.slot120 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot120, align 64
  %.spill121 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill121, align 64
  %tile_snapshot.spill122 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill122, align 64
  %.slot123 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot123, align 64
  %.spill124 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill124, align 1
  %.slot125 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot125, align 32
  %tile_snapshot.spill126 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill126, align 64
  %.slot127 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot127, align 64
  %.spill128 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill128, align 1
  %.slot129 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot129, align 32
  %tile_snapshot.spill130 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill130, align 64
  %.slot131 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot131, align 64
  %.spill132 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill132, align 64
  %.spill133 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill133, align 1
  %.spill134 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill134, align 64
  %.spill135 = alloca i64, align 8
  store i64 0, ptr %.spill135, align 4
  %.slot136 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot136, align 64
  %.slot137 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot137, align 32
  %.spill138 = alloca i64, align 8
  store i64 0, ptr %.spill138, align 4
  %.spill139 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill139, align 64
  %.slot140 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot140, align 32
  %.spill141 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill141, align 32
  %.slot142 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot142, align 32
  %tile_snapshot.spill143 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill143, align 64
  %.slot144 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot144, align 64
  %.spill145 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill145, align 1
  %.slot146 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot146, align 32
  %tile_snapshot.spill147 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill147, align 64
  %.slot148 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot148, align 64
  %tile_snapshot.spill149 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill149, align 64
  %.slot150 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot150, align 64
  %.spill151 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill151, align 1
  %.slot152 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot152, align 64
  %tile_snapshot.spill153 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill153, align 64
  %.slot154 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot154, align 64
  %.spill155 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill155, align 1
  %.slot156 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot156, align 64
  %tile_snapshot.spill157 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill157, align 64
  %.slot158 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot158, align 64
  %tile_snapshot.spill159 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill159, align 64
  %.slot160 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot160, align 64
  %.spill161 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill161, align 1
  %.slot162 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot162, align 64
  %tile_snapshot.spill163 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill163, align 64
  %.slot164 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot164, align 64
  %tile_snapshot.spill165 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill165, align 64
  %.slot166 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot166, align 64
  %.spill167 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill167, align 1
  %.slot168 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot168, align 64
  %tile_snapshot.spill169 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill169, align 64
  %.slot170 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot170, align 64
  %.spill171 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill171, align 1
  %.slot172 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot172, align 64
  %tile_snapshot.spill173 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill173, align 64
  %.slot174 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot174, align 64
  %.spill175 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill175, align 1
  %.slot176 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot176, align 64
  %tile_snapshot.spill177 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill177, align 64
  %.slot178 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot178, align 64
  %.spill179 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill179, align 64
  %.spill180 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill180, align 1
  %.slot181 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot181, align 64
  %.spill182 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill182, align 64
  %.slot183 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot183, align 64
  %tile_snapshot.spill184 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill184, align 64
  %.slot185 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot185, align 64
  %.spill186 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill186, align 64
  %.spill187 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill187, align 1
  %.spill188 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill188, align 64
  %.slot189 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot189, align 1
  %.slot190 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot190, align 1
  %tile_snapshot.spill191 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill191, align 64
  %.slot192 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot192, align 64
  %.spill193 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill193, align 64
  %.spill194 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill194, align 1
  %.spill195 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill195, align 64
  %.spill196 = alloca i64, align 8
  store i64 0, ptr %.spill196, align 4
  %.slot197 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot197, align 1
  %.slot198 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot198, align 32
  %tile_snapshot.spill199 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill199, align 64
  %.slot200 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot200, align 64
  %.spill201 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill201, align 64
  %.slot202 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot202, align 64
  %.slot203 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot203, align 32
  %.slot204 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot204, align 1
  %.spill205 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill205, align 1
  %.slot206 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot206, align 32
  %tile_snapshot.spill207 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill207, align 64
  %.slot208 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot208, align 64
  %.spill209 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill209, align 1
  %.spill210 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill210, align 64
  %.slot211 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot211, align 32
  %.slot212 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot212, align 32
  %tile_snapshot.spill213 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill213, align 64
  %.slot214 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot214, align 64
  %.spill215 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill215, align 1
  %.spill216 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill216, align 64
  %.slot217 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot217, align 32
  %.slot218 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot218, align 32
  %tile_snapshot.spill219 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill219, align 64
  %.slot220 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot220, align 64
  %.spill221 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill221, align 1
  %.slot222 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot222, align 32
  %tile_snapshot.spill223 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill223, align 64
  %.slot224 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot224, align 64
  %.spill225 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill225, align 1
  %.spill226 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill226, align 64
  %.spill227 = alloca i64, align 8
  store i64 0, ptr %.spill227, align 4
  %.slot228 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot228, align 32
  %.spill229 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill229, align 64
  %.slot230 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot230, align 32
  %tile_snapshot.spill231 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill231, align 64
  %.slot232 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot232, align 64
  %.spill233 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill233, align 1
  %.slot234 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot234, align 32
  %tile_snapshot.spill235 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill235, align 64
  %.slot236 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot236, align 64
  %.spill237 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill237, align 64
  %.spill238 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill238, align 1
  %.spill239 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill239, align 64
  %.spill240 = alloca i64, align 8
  store i64 0, ptr %.spill240, align 4
  %.slot241 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot241, align 1
  %.slot242 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot242, align 32
  %tile_snapshot.spill243 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill243, align 64
  %.slot244 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot244, align 64
  %.spill245 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill245, align 1
  %.spill246 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill246, align 64
  %.slot247 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot247, align 32
  %.slot248 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot248, align 32
  %tile_snapshot.spill249 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill249, align 64
  %.slot250 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot250, align 64
  %.spill251 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill251, align 64
  %.slot252 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot252, align 64
  %.slot253 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot253, align 32
  %.slot254 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.slot254, align 1
  %.spill255 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill255, align 1
  %.slot256 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot256, align 32
  %tile_snapshot.spill257 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill257, align 64
  %.slot258 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot258, align 64
  %.spill259 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill259, align 1
  %.spill260 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill260, align 64
  %.slot261 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot261, align 32
  %.slot262 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot262, align 32
  %tile_snapshot.spill263 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill263, align 64
  %.slot264 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot264, align 64
  %.spill265 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill265, align 1
  %.spill266 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill266, align 64
  %.spill267 = alloca i64, align 8
  store i64 0, ptr %.spill267, align 4
  %.slot268 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot268, align 32
  %.spill269 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill269, align 64
  %.slot270 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot270, align 32
  %tile_snapshot.spill271 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill271, align 64
  %.slot272 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot272, align 64
  %.spill273 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill273, align 64
  %.spill274 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill274, align 1
  %.spill275 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill275, align 64
  %.spill276 = alloca i64, align 8
  store i64 0, ptr %.spill276, align 4
  %.slot277 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot277, align 32
  %.slot278 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot278, align 64
  %.slot279 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot279, align 32
  %.spill280 = alloca i64, align 8
  store i64 0, ptr %.spill280, align 4
  %.spill281 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill281, align 64
  %.slot282 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot282, align 32
  %.spill283 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill283, align 32
  %.slot284 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot284, align 32
  %.slot285 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot285, align 64
  %.spill286 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill286, align 1
  %.slot287 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot287, align 32
  %.slot288 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot288, align 64
  %.spill289 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill289, align 1
  %.slot290 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot290, align 32
  %.slot291 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot291, align 64
  %.spill292 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill292, align 1
  %.slot293 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot293, align 32
  %.slot294 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot294, align 64
  %.spill295 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill295, align 1
  %.slot296 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot296, align 32
  %.slot297 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot297, align 64
  %.spill298 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill298, align 1
  %.slot299 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot299, align 32
  %.slot300 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot300, align 64
  %.spill301 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill301, align 1
  %.slot302 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot302, align 32
  %tile_snapshot.spill303 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill303, align 64
  %.slot304 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot304, align 64
  %.spill305 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill305, align 1
  %.spill306 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill306, align 64
  %.spill307 = alloca i64, align 8
  store i64 0, ptr %.spill307, align 4
  %.slot308 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot308, align 32
  %.spill309 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill309, align 64
  %.slot310 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot310, align 32
  %.slot311 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot311, align 64
  %.spill312 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill312, align 1
  %.spill313 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill313, align 64
  %.spill314 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill314, align 64
  %.spill315 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill315, align 64
  %.spill316 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill316, align 64
  %.spill317 = alloca i64, align 8
  store i64 0, ptr %.spill317, align 4
  %.slot318 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot318, align 32
  %72 = getelementptr i8, ptr %argument_buffer, i64 0
  %73 = load ptr, ptr %72, align 16
  %74 = getelementptr i8, ptr %72, i64 8
  %75 = load i64, ptr %74, align 8
  %76 = insertvalue { ptr, i64 } poison, ptr %73, 0
  %77 = insertvalue { ptr, i64 } %76, i64 %75, 1
  %78 = getelementptr i8, ptr %argument_buffer, i64 16
  %79 = load ptr, ptr %78, align 16
  %80 = getelementptr i8, ptr %78, i64 8
  %81 = load i64, ptr %80, align 8
  %82 = insertvalue { ptr, i64 } poison, ptr %79, 0
  %83 = insertvalue { ptr, i64 } %82, i64 %81, 1
  %84 = getelementptr i8, ptr %argument_buffer, i64 32
  %85 = load ptr, ptr %84, align 16
  %86 = getelementptr i8, ptr %84, i64 8
  %87 = load i64, ptr %86, align 8
  %88 = insertvalue { ptr, i64 } poison, ptr %85, 0
  %89 = insertvalue { ptr, i64 } %88, i64 %87, 1
  %90 = getelementptr i8, ptr %argument_buffer, i64 48
  %91 = load ptr, ptr %90, align 16
  %92 = getelementptr i8, ptr %90, i64 8
  %93 = load i64, ptr %92, align 8
  %94 = insertvalue { ptr, i64 } poison, ptr %91, 0
  %95 = insertvalue { ptr, i64 } %94, i64 %93, 1
  %96 = load i32, ptr %launch_config, align 4
  %97 = getelementptr i8, ptr %launch_config, i64 12
  %98 = load i32, ptr %97, align 4
  %99 = getelementptr i8, ptr %launch_config, i64 4
  %100 = load i32, ptr %99, align 4
  %101 = getelementptr i8, ptr %launch_config, i64 16
  %102 = load i32, ptr %101, align 4
  %103 = getelementptr i8, ptr %launch_config, i64 8
  %104 = load i32, ptr %103, align 4
  %105 = getelementptr i8, ptr %launch_config, i64 20
  %106 = load i32, ptr %105, align 4
  %107 = getelementptr i8, ptr %launch_config, i64 36
  %108 = load i32, ptr %107, align 4
  %.splatinsert319 = insertelement <8 x i32> poison, i32 %108, i64 0
  %.splat320 = shufflevector <8 x i32> %.splatinsert319, <8 x i32> poison, <8 x i32> zeroinitializer
  %109 = add <8 x i32> %.splat320, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %110 = mul i32 %96, 32
  %.splatinsert321 = insertelement <8 x i32> poison, i32 %110, i64 0
  %.splat322 = shufflevector <8 x i32> %.splatinsert321, <8 x i32> poison, <8 x i32> zeroinitializer
  %111 = add <8 x i32> %.splat322, %109
  %112 = mul i32 %100, 1
  %.splatinsert323 = insertelement <8 x i32> poison, i32 %112, i64 0
  %.splat324 = shufflevector <8 x i32> %.splatinsert323, <8 x i32> poison, <8 x i32> zeroinitializer
  %113 = add <8 x i32> %.splat324, zeroinitializer
  %114 = mul i32 %104, 1
  %.splatinsert325 = insertelement <8 x i32> poison, i32 %114, i64 0
  %.splat326 = shufflevector <8 x i32> %.splatinsert325, <8 x i32> poison, <8 x i32> zeroinitializer
  %115 = add <8 x i32> %.splat326, zeroinitializer
  %116 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %111, 0
  %117 = insertvalue [3 x <8 x i32>] %116, <8 x i32> %113, 1
  %118 = insertvalue [3 x <8 x i32>] %117, <8 x i32> %115, 2
  %.splatinsert327 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat328 = shufflevector <8 x i32> %.splatinsert327, <8 x i32> poison, <8 x i32> zeroinitializer
  %119 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat328
  %120 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  br i1 %120, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %121 = extractvalue [3 x <8 x i32>] %118, 0
  %122 = load <8 x i64>, ptr %.spill, align 64
  %123 = select <8 x i1> %119, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %122
  store <8 x i64> %123, ptr %.spill, align 64
  %124 = sub <8 x i32> %121, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %125 = select <8 x i1> %119, <8 x i32> %124, <8 x i32> zeroinitializer
  %126 = select <8 x i1> %119, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %127 = lshr <8 x i32> %125, %126
  %128 = zext <8 x i32> %127 to <8 x i64>
  %129 = select <8 x i1> %119, <8 x i64> %128, <8 x i64> zeroinitializer
  %130 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %131 = sdiv <8 x i64> %129, %130
  %132 = load <8 x i64>, ptr %.spill106, align 64
  %133 = select <8 x i1> %119, <8 x i64> %131, <8 x i64> %132
  store <8 x i64> %133, ptr %.spill106, align 64
  %134 = select <8 x i1> %119, <8 x i64> %128, <8 x i64> zeroinitializer
  %135 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %136 = sdiv <8 x i64> %134, %135
  %137 = select <8 x i1> %119, <8 x i64> %136, <8 x i64> zeroinitializer
  %138 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %139 = srem <8 x i64> %137, %138
  %140 = mul <8 x i64> %139, splat (i64 2)
  %141 = load <8 x i64>, ptr %.spill107, align 64
  %142 = select <8 x i1> %119, <8 x i64> %140, <8 x i64> %141
  store <8 x i64> %142, ptr %.spill107, align 64
  %143 = select <8 x i1> %119, <8 x i64> %131, <8 x i64> zeroinitializer
  %144 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %145 = sdiv <8 x i64> %143, %144
  %146 = load <8 x i64>, ptr %.spill108, align 64
  %147 = select <8 x i1> %119, <8 x i64> %145, <8 x i64> %146
  store <8 x i64> %147, ptr %.spill108, align 64
  %148 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %149 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %150 = extractvalue { <8 x ptr>, <8 x i64> } %148, 0
  %151 = select <8 x i1> %119, <8 x ptr> %149, <8 x ptr> %150
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %148, 1
  %154 = select <8 x i1> %119, <8 x i64> %152, <8 x i64> %153
  %155 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %151, 0
  %156 = insertvalue { <8 x ptr>, <8 x i64> } %155, <8 x i64> %154, 1
  store { <8 x ptr>, <8 x i64> } %156, ptr %tile_snapshot.spill, align 64
  %157 = load <8 x i64>, ptr %.slot, align 64
  %158 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %157
  store <8 x i64> %158, ptr %.slot, align 64
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.6, %direct.schedule.0
  %.state = load <8 x i64>, ptr %.slot, align 64
  %159 = icmp slt <8 x i64> %.state, splat (i64 2)
  %160 = extractelement <8 x i1> %159, i32 0
  br i1 %160, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state329 = load <8 x i64>, ptr %.slot, align 64
  %161 = select <8 x i1> %119, <8 x i64> %.state329, <8 x i64> zeroinitializer
  %162 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %163 = srem <8 x i64> %161, %162
  %.state330 = load <8 x i64>, ptr %.slot, align 64
  %164 = select <8 x i1> %119, <8 x i64> %.state330, <8 x i64> zeroinitializer
  %165 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %166 = sdiv <8 x i64> %164, %165
  %167 = mul <8 x i64> %163, splat (i64 8)
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %168 = add <8 x i64> %167, %.spill.load
  %169 = icmp slt <8 x i64> %168, splat (i64 7)
  %170 = load <8 x i1>, ptr %.spill109, align 1
  %171 = select <8 x i1> %119, <8 x i1> %169, <8 x i1> %170
  store <8 x i1> %171, ptr %.spill109, align 1
  %172 = select <8 x i1> %169, <8 x i64> %168, <8 x i64> splat (i64 6)
  %173 = select <8 x i1> %119, <8 x i64> %166, <8 x i64> zeroinitializer
  %174 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %175 = srem <8 x i64> %173, %174
  %176 = select <8 x i1> %119, <8 x i64> %166, <8 x i64> zeroinitializer
  %177 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %178 = sdiv <8 x i64> %176, %177
  %179 = select <8 x i1> %119, <8 x i64> %178, <8 x i64> zeroinitializer
  %180 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %181 = srem <8 x i64> %179, %180
  %182 = select <8 x i1> %119, <8 x i64> %178, <8 x i64> zeroinitializer
  %183 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %184 = sdiv <8 x i64> %182, %183
  %185 = select <8 x i1> %119, <8 x i64> %184, <8 x i64> zeroinitializer
  %186 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %187 = srem <8 x i64> %185, %186
  %188 = add <8 x i64> zeroinitializer, %187
  %189 = add <8 x i64> zeroinitializer, %188
  %.spill.load331 = load <8 x i64>, ptr %.spill106, align 64
  %190 = add <8 x i64> %.spill.load331, %181
  %191 = mul <8 x i64> %189, splat (i64 2)
  %192 = add <8 x i64> %191, %190
  %.spill.load332 = load <8 x i64>, ptr %.spill107, align 64
  %193 = add <8 x i64> %.spill.load332, %175
  %194 = mul <8 x i64> %192, splat (i64 3)
  %195 = add <8 x i64> %194, %193
  %196 = icmp sge <8 x i64> %193, zeroinitializer
  %197 = and <8 x i1> splat (i1 true), %196
  %198 = icmp slt <8 x i64> %193, splat (i64 3)
  %199 = and <8 x i1> %197, %198
  %200 = add <8 x i64> zeroinitializer, %172
  %201 = mul <8 x i64> %195, splat (i64 7)
  %202 = add <8 x i64> %201, %200
  %203 = and <8 x i1> %199, %169
  %204 = and <8 x i1> %119, %203
  %205 = xor <8 x i1> %203, splat (i1 true)
  %206 = and <8 x i1> %119, %205
  %207 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %204)
  %208 = bitcast <8 x i1> %204 to i8
  %209 = call i8 @llvm.cttz.i8(i8 %208, i1 false)
  %210 = zext i8 %209 to i32
  %211 = select i1 %207, i32 %210, i32 0
  %212 = extractvalue { ptr, i64 } %77, 0
  %213 = select <8 x i1> %204, <8 x i64> %202, <8 x i64> zeroinitializer
  %214 = mul <8 x i64> %213, splat (i64 4)
  %215 = getelementptr i8, ptr %212, <8 x i64> %214
  %216 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %215, <8 x i1> %204, <8 x float> zeroinitializer)
  %217 = load <8 x float>, ptr %.slot110, align 32
  %218 = select <8 x i1> %204, <8 x float> %216, <8 x float> %217
  store <8 x float> %218, ptr %.slot110, align 32
  %219 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %206)
  %220 = bitcast <8 x i1> %206 to i8
  %221 = call i8 @llvm.cttz.i8(i8 %220, i1 false)
  %222 = zext i8 %221 to i32
  %223 = select i1 %219, i32 %222, i32 0
  %224 = load <8 x float>, ptr %.slot110, align 32
  %225 = select <8 x i1> %206, <8 x float> zeroinitializer, <8 x float> %224
  store <8 x float> %225, ptr %.slot110, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.2
  %.spill.load333 = load <8 x i1>, ptr %.spill109, align 1
  %226 = and <8 x i1> %119, %.spill.load333
  %227 = xor <8 x i1> %.spill.load333, splat (i1 true)
  %228 = and <8 x i1> %119, %227
  %229 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %226)
  %230 = bitcast <8 x i1> %226 to i8
  %231 = call i8 @llvm.cttz.i8(i8 %230, i1 false)
  %232 = zext i8 %231 to i32
  %233 = select i1 %229, i32 %232, i32 0
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %234 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state334 = load <8 x i64>, ptr %.slot, align 64
  %236 = mul <8 x i64> %.state334, splat (i64 32)
  %237 = add <8 x i64> %235, %236
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %234, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %.state335 = load <8 x float>, ptr %.slot110, align 32
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 %233
  %244 = zext i32 %233 to i64
  %245 = mul i64 %244, 4
  %246 = sub i64 %243, %245
  %247 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %226)
  %248 = select i1 %247, i64 %246, i64 0
  %private.contiguous.address = getelementptr i8, ptr %242, i64 %248
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %249 = select <8 x i1> %226, <8 x float> %.state335, <8 x float> %private.contiguous.preserve
  store <8 x float> %249, ptr %private.contiguous.address, align 4
  %250 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %228)
  %251 = bitcast <8 x i1> %228 to i8
  %252 = call i8 @llvm.cttz.i8(i8 %251, i1 false)
  %253 = zext i8 %252 to i32
  %254 = select i1 %250, i32 %253, i32 0
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.4
  %.state336 = load <8 x i64>, ptr %.slot, align 64
  %255 = add <8 x i64> %.state336, splat (i64 1)
  %256 = load <8 x i64>, ptr %.slot, align 64
  %257 = select <8 x i1> %119, <8 x i64> %255, <8 x i64> %256
  store <8 x i64> %257, ptr %.slot, align 64
  br label %direct.schedule.1

direct.schedule.7:                                ; preds = %direct.false
  %258 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %258, 0
  %261 = select <8 x i1> %119, <8 x ptr> %259, <8 x ptr> %260
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %263 = extractvalue { <8 x ptr>, <8 x i64> } %258, 1
  %264 = select <8 x i1> %119, <8 x i64> %262, <8 x i64> %263
  %265 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %266 = insertvalue { <8 x ptr>, <8 x i64> } %265, <8 x i64> %264, 1
  store { <8 x ptr>, <8 x i64> } %266, ptr %tile_snapshot.spill111, align 64
  %267 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %268 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %269 = extractvalue { <8 x ptr>, <8 x i64> } %267, 0
  %270 = select <8 x i1> %119, <8 x ptr> %268, <8 x ptr> %269
  %271 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %267, 1
  %273 = select <8 x i1> %119, <8 x i64> %271, <8 x i64> %272
  %274 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %270, 0
  %275 = insertvalue { <8 x ptr>, <8 x i64> } %274, <8 x i64> %273, 1
  store { <8 x ptr>, <8 x i64> } %275, ptr %tile_snapshot.spill112, align 64
  %276 = load <8 x i64>, ptr %.slot113, align 64
  %277 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %276
  store <8 x i64> %277, ptr %.slot113, align 64
  br label %direct.schedule.8

direct.schedule.8:                                ; preds = %direct.schedule.11, %direct.schedule.7
  %.state337 = load <8 x i64>, ptr %.slot113, align 64
  %278 = icmp slt <8 x i64> %.state337, splat (i64 1)
  %279 = extractelement <8 x i1> %278, i32 0
  br i1 %279, label %direct.true338, label %direct.false339

direct.schedule.9:                                ; preds = %direct.true338
  %.state340 = load <8 x i64>, ptr %.slot113, align 64
  %280 = select <8 x i1> %119, <8 x i64> %.state340, <8 x i64> zeroinitializer
  %281 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %282 = srem <8 x i64> %280, %281
  %283 = mul <8 x i64> %282, splat (i64 8)
  %.spill.load341 = load <8 x i64>, ptr %.spill, align 64
  %284 = add <8 x i64> %283, %.spill.load341
  %285 = icmp slt <8 x i64> %284, splat (i64 2)
  %286 = and <8 x i1> %119, %285
  %287 = xor <8 x i1> %285, splat (i1 true)
  %288 = and <8 x i1> %119, %287
  %289 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %286)
  %290 = bitcast <8 x i1> %286 to i8
  %291 = call i8 @llvm.cttz.i8(i8 %290, i1 false)
  %292 = zext i8 %291 to i32
  %293 = select i1 %289, i32 %292, i32 0
  %tile_snapshot.spill.load342 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %294 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load342, 0
  %295 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load342, 1
  %.state343 = load <8 x i64>, ptr %.slot113, align 64
  %296 = mul <8 x i64> %.state343, splat (i64 32)
  %297 = add <8 x i64> %295, %296
  %298 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %294, 0
  %299 = insertvalue { <8 x ptr>, <8 x i64> } %298, <8 x i64> %297, 1
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %299, 1
  %302 = extractelement <8 x ptr> %300, i32 0
  %303 = extractelement <8 x i64> %301, i32 %293
  %304 = zext i32 %293 to i64
  %305 = mul i64 %304, 4
  %306 = sub i64 %303, %305
  %307 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %286)
  %308 = select i1 %307, i64 %306, i64 0
  %private.contiguous.address344 = getelementptr i8, ptr %302, i64 %308
  %private.contiguous.preserve345 = load <8 x float>, ptr %private.contiguous.address344, align 4
  %309 = select <8 x i1> %286, <8 x float> splat (float 0xC6293E5940000000), <8 x float> %private.contiguous.preserve345
  store <8 x float> %309, ptr %private.contiguous.address344, align 4
  %310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %288)
  %311 = bitcast <8 x i1> %288 to i8
  %312 = call i8 @llvm.cttz.i8(i8 %311, i1 false)
  %313 = zext i8 %312 to i32
  %314 = select i1 %310, i32 %313, i32 0
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.9
  %.state346 = load <8 x i64>, ptr %.slot113, align 64
  %315 = add <8 x i64> %.state346, splat (i64 1)
  %316 = load <8 x i64>, ptr %.slot113, align 64
  %317 = select <8 x i1> %119, <8 x i64> %315, <8 x i64> %316
  store <8 x i64> %317, ptr %.slot113, align 64
  br label %direct.schedule.8

direct.schedule.12:                               ; preds = %direct.false339
  %318 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %319 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %318, 0
  %321 = select <8 x i1> %119, <8 x ptr> %319, <8 x ptr> %320
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %318, 1
  %324 = select <8 x i1> %119, <8 x i64> %322, <8 x i64> %323
  %325 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %321, 0
  %326 = insertvalue { <8 x ptr>, <8 x i64> } %325, <8 x i64> %324, 1
  store { <8 x ptr>, <8 x i64> } %326, ptr %tile_snapshot.spill114, align 64
  %327 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 0
  %330 = select <8 x i1> %119, <8 x ptr> %328, <8 x ptr> %329
  %331 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %332 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %333 = select <8 x i1> %119, <8 x i64> %331, <8 x i64> %332
  %334 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %330, 0
  %335 = insertvalue { <8 x ptr>, <8 x i64> } %334, <8 x i64> %333, 1
  store { <8 x ptr>, <8 x i64> } %335, ptr %tile_snapshot.spill115, align 64
  %336 = load <8 x i64>, ptr %.slot116, align 64
  %337 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %336
  store <8 x i64> %337, ptr %.slot116, align 64
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.16, %direct.schedule.12
  %.state347 = load <8 x i64>, ptr %.slot116, align 64
  %338 = icmp slt <8 x i64> %.state347, splat (i64 1)
  %339 = extractelement <8 x i1> %338, i32 0
  br i1 %339, label %direct.true348, label %direct.false349

direct.schedule.14:                               ; preds = %direct.true348
  %.state350 = load <8 x i64>, ptr %.slot116, align 64
  %340 = select <8 x i1> %119, <8 x i64> %.state350, <8 x i64> zeroinitializer
  %341 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %342 = srem <8 x i64> %340, %341
  %343 = mul <8 x i64> %342, splat (i64 8)
  %.spill.load351 = load <8 x i64>, ptr %.spill, align 64
  %344 = add <8 x i64> %343, %.spill.load351
  %345 = icmp slt <8 x i64> %344, splat (i64 2)
  %346 = and <8 x i1> %119, %345
  %347 = xor <8 x i1> %345, splat (i1 true)
  %348 = and <8 x i1> %119, %347
  %349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %346)
  %350 = bitcast <8 x i1> %346 to i8
  %351 = call i8 @llvm.cttz.i8(i8 %350, i1 false)
  %352 = zext i8 %351 to i32
  %353 = select i1 %349, i32 %352, i32 0
  %tile_snapshot.spill.load352 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %354 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load352, 0
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load352, 1
  %.state353 = load <8 x i64>, ptr %.slot116, align 64
  %356 = mul <8 x i64> %.state353, splat (i64 32)
  %357 = add <8 x i64> %355, %356
  %358 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %354, 0
  %359 = insertvalue { <8 x ptr>, <8 x i64> } %358, <8 x i64> %357, 1
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %359, 1
  %362 = extractelement <8 x ptr> %360, i32 0
  %363 = extractelement <8 x i64> %361, i32 %353
  %364 = zext i32 %353 to i64
  %365 = mul i64 %364, 4
  %366 = sub i64 %363, %365
  %367 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %346)
  %368 = select i1 %367, i64 %366, i64 0
  %private.contiguous.address354 = getelementptr i8, ptr %362, i64 %368
  %private.contiguous.preserve355 = load <8 x float>, ptr %private.contiguous.address354, align 4
  %369 = select <8 x i1> %346, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve355
  store <8 x float> %369, ptr %private.contiguous.address354, align 4
  %370 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %348)
  %371 = bitcast <8 x i1> %348 to i8
  %372 = call i8 @llvm.cttz.i8(i8 %371, i1 false)
  %373 = zext i8 %372 to i32
  %374 = select i1 %370, i32 %373, i32 0
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.14
  %.state356 = load <8 x i64>, ptr %.slot116, align 64
  %375 = add <8 x i64> %.state356, splat (i64 1)
  %376 = load <8 x i64>, ptr %.slot116, align 64
  %377 = select <8 x i1> %119, <8 x i64> %375, <8 x i64> %376
  store <8 x i64> %377, ptr %.slot116, align 64
  br label %direct.schedule.13

direct.schedule.17:                               ; preds = %direct.false349
  %378 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %379 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %380 = extractvalue { <8 x ptr>, <8 x i64> } %378, 0
  %381 = select <8 x i1> %119, <8 x ptr> %379, <8 x ptr> %380
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %378, 1
  %384 = select <8 x i1> %119, <8 x i64> %382, <8 x i64> %383
  %385 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %386 = insertvalue { <8 x ptr>, <8 x i64> } %385, <8 x i64> %384, 1
  store { <8 x ptr>, <8 x i64> } %386, ptr %tile_snapshot.spill117, align 64
  %387 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill118, align 64
  %388 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %389 = extractvalue { <8 x ptr>, <8 x i64> } %387, 0
  %390 = select <8 x i1> %119, <8 x ptr> %388, <8 x ptr> %389
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %13, 1
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %387, 1
  %393 = select <8 x i1> %119, <8 x i64> %391, <8 x i64> %392
  %394 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %390, 0
  %395 = insertvalue { <8 x ptr>, <8 x i64> } %394, <8 x i64> %393, 1
  store { <8 x ptr>, <8 x i64> } %395, ptr %tile_snapshot.spill118, align 64
  %396 = load <8 x i64>, ptr %.slot119, align 64
  %397 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %396
  store <8 x i64> %397, ptr %.slot119, align 64
  br label %direct.schedule.18

direct.schedule.18:                               ; preds = %direct.schedule.21, %direct.schedule.17
  %.state357 = load <8 x i64>, ptr %.slot119, align 64
  %398 = icmp slt <8 x i64> %.state357, splat (i64 2)
  %399 = extractelement <8 x i1> %398, i32 0
  br i1 %399, label %direct.true358, label %direct.false359

direct.schedule.19:                               ; preds = %direct.true358
  %.state360 = load <8 x i64>, ptr %.slot119, align 64
  %400 = select <8 x i1> %119, <8 x i64> %.state360, <8 x i64> zeroinitializer
  %401 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %402 = srem <8 x i64> %400, %401
  %403 = mul <8 x i64> %402, splat (i64 8)
  %.spill.load361 = load <8 x i64>, ptr %.spill, align 64
  %404 = add <8 x i64> %403, %.spill.load361
  %405 = icmp slt <8 x i64> %404, splat (i64 3)
  %406 = and <8 x i1> %119, %405
  %407 = xor <8 x i1> %405, splat (i1 true)
  %408 = and <8 x i1> %119, %407
  %409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %406)
  %410 = bitcast <8 x i1> %406 to i8
  %411 = call i8 @llvm.cttz.i8(i8 %410, i1 false)
  %412 = zext i8 %411 to i32
  %413 = select i1 %409, i32 %412, i32 0
  %tile_snapshot.spill.load362 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load362, 0
  %415 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load362, 1
  %.state363 = load <8 x i64>, ptr %.slot119, align 64
  %416 = mul <8 x i64> %.state363, splat (i64 32)
  %417 = add <8 x i64> %415, %416
  %418 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %414, 0
  %419 = insertvalue { <8 x ptr>, <8 x i64> } %418, <8 x i64> %417, 1
  %420 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %419, 1
  %422 = extractelement <8 x ptr> %420, i32 0
  %423 = extractelement <8 x i64> %421, i32 %413
  %424 = zext i32 %413 to i64
  %425 = mul i64 %424, 4
  %426 = sub i64 %423, %425
  %427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %406)
  %428 = select i1 %427, i64 %426, i64 0
  %private.contiguous.address364 = getelementptr i8, ptr %422, i64 %428
  %private.contiguous.preserve365 = load <8 x float>, ptr %private.contiguous.address364, align 4
  %429 = select <8 x i1> %406, <8 x float> zeroinitializer, <8 x float> %private.contiguous.preserve365
  store <8 x float> %429, ptr %private.contiguous.address364, align 4
  %430 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %408)
  %431 = bitcast <8 x i1> %408 to i8
  %432 = call i8 @llvm.cttz.i8(i8 %431, i1 false)
  %433 = zext i8 %432 to i32
  %434 = select i1 %430, i32 %433, i32 0
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.19
  %.state366 = load <8 x i64>, ptr %.slot119, align 64
  %435 = add <8 x i64> %.state366, splat (i64 1)
  %436 = load <8 x i64>, ptr %.slot119, align 64
  %437 = select <8 x i1> %119, <8 x i64> %435, <8 x i64> %436
  store <8 x i64> %437, ptr %.slot119, align 64
  br label %direct.schedule.18

direct.schedule.22:                               ; preds = %direct.false359
  %438 = load <8 x i64>, ptr %.slot120, align 64
  %439 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %438
  store <8 x i64> %439, ptr %.slot120, align 64
  br label %direct.schedule.23

direct.schedule.23:                               ; preds = %direct.schedule.290, %direct.schedule.22
  %.state367 = load <8 x i64>, ptr %.slot120, align 64
  %440 = icmp slt <8 x i64> %.state367, splat (i64 2)
  %441 = extractelement <8 x i1> %440, i32 0
  br i1 %441, label %direct.true368, label %direct.false369

direct.schedule.24:                               ; preds = %direct.true368
  %.state370 = load <8 x i64>, ptr %.slot120, align 64
  %442 = select <8 x i1> %119, <8 x i64> %.state370, <8 x i64> zeroinitializer
  %443 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %444 = sdiv <8 x i64> %442, %443
  %445 = mul <8 x i64> %444, splat (i64 33)
  %446 = load <8 x i64>, ptr %.spill121, align 64
  %447 = select <8 x i1> %119, <8 x i64> %445, <8 x i64> %446
  store <8 x i64> %447, ptr %.spill121, align 64
  %448 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill122, align 64
  %449 = extractvalue { <8 x ptr>, <8 x i64> } %15, 0
  %450 = extractvalue { <8 x ptr>, <8 x i64> } %448, 0
  %451 = select <8 x i1> %119, <8 x ptr> %449, <8 x ptr> %450
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %15, 1
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %448, 1
  %454 = select <8 x i1> %119, <8 x i64> %452, <8 x i64> %453
  %455 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %451, 0
  %456 = insertvalue { <8 x ptr>, <8 x i64> } %455, <8 x i64> %454, 1
  store { <8 x ptr>, <8 x i64> } %456, ptr %tile_snapshot.spill122, align 64
  %457 = load <8 x i64>, ptr %.slot123, align 64
  %458 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %457
  store <8 x i64> %458, ptr %.slot123, align 64
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.30, %direct.schedule.24
  %.state371 = load <8 x i64>, ptr %.slot123, align 64
  %459 = icmp slt <8 x i64> %.state371, splat (i64 35)
  %460 = extractelement <8 x i1> %459, i32 0
  br i1 %460, label %direct.true372, label %direct.false373

direct.schedule.26:                               ; preds = %direct.true372
  %.state374 = load <8 x i64>, ptr %.slot123, align 64
  %461 = select <8 x i1> %119, <8 x i64> %.state374, <8 x i64> zeroinitializer
  %462 = select <8 x i1> %119, <8 x i64> splat (i64 7), <8 x i64> splat (i64 1)
  %463 = srem <8 x i64> %461, %462
  %.state375 = load <8 x i64>, ptr %.slot123, align 64
  %464 = select <8 x i1> %119, <8 x i64> %.state375, <8 x i64> zeroinitializer
  %465 = select <8 x i1> %119, <8 x i64> splat (i64 7), <8 x i64> splat (i64 1)
  %466 = sdiv <8 x i64> %464, %465
  %467 = select <8 x i1> %119, <8 x i64> %466, <8 x i64> zeroinitializer
  %468 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %469 = srem <8 x i64> %467, %468
  %470 = select <8 x i1> %119, <8 x i64> %466, <8 x i64> zeroinitializer
  %471 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %472 = sdiv <8 x i64> %470, %471
  %473 = mul <8 x i64> %469, splat (i64 8)
  %.spill.load376 = load <8 x i64>, ptr %.spill, align 64
  %474 = add <8 x i64> %473, %.spill.load376
  %475 = icmp slt <8 x i64> %474, splat (i64 33)
  %476 = load <8 x i1>, ptr %.spill124, align 1
  %477 = select <8 x i1> %119, <8 x i1> %475, <8 x i1> %476
  store <8 x i1> %477, ptr %.spill124, align 1
  %478 = select <8 x i1> %475, <8 x i64> %474, <8 x i64> splat (i64 32)
  %479 = select <8 x i1> %119, <8 x i64> %472, <8 x i64> zeroinitializer
  %480 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %481 = srem <8 x i64> %479, %480
  %482 = select <8 x i1> %119, <8 x i64> %472, <8 x i64> zeroinitializer
  %483 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %484 = sdiv <8 x i64> %482, %483
  %485 = select <8 x i1> %119, <8 x i64> %484, <8 x i64> zeroinitializer
  %486 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %487 = srem <8 x i64> %485, %486
  %488 = add <8 x i64> zeroinitializer, %487
  %489 = add <8 x i64> zeroinitializer, %488
  %.spill.load377 = load <8 x i64>, ptr %.spill108, align 64
  %490 = add <8 x i64> %.spill.load377, %481
  %491 = mul <8 x i64> %489, splat (i64 1)
  %492 = add <8 x i64> %491, %490
  %.spill.load378 = load <8 x i64>, ptr %.spill121, align 64
  %493 = add <8 x i64> %.spill.load378, %478
  %494 = mul <8 x i64> %492, splat (i64 35)
  %495 = add <8 x i64> %494, %493
  %496 = icmp sge <8 x i64> %493, zeroinitializer
  %497 = and <8 x i1> splat (i1 true), %496
  %498 = icmp slt <8 x i64> %493, splat (i64 35)
  %499 = and <8 x i1> %497, %498
  %500 = add <8 x i64> zeroinitializer, %463
  %501 = mul <8 x i64> %495, splat (i64 7)
  %502 = add <8 x i64> %501, %500
  %503 = and <8 x i1> %499, %475
  %504 = and <8 x i1> %119, %503
  %505 = xor <8 x i1> %503, splat (i1 true)
  %506 = and <8 x i1> %119, %505
  %507 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %504)
  %508 = bitcast <8 x i1> %504 to i8
  %509 = call i8 @llvm.cttz.i8(i8 %508, i1 false)
  %510 = zext i8 %509 to i32
  %511 = select i1 %507, i32 %510, i32 0
  %512 = extractvalue { ptr, i64 } %83, 0
  %513 = select <8 x i1> %504, <8 x i64> %502, <8 x i64> zeroinitializer
  %514 = mul <8 x i64> %513, splat (i64 4)
  %515 = getelementptr i8, ptr %512, <8 x i64> %514
  %516 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %515, <8 x i1> %504, <8 x float> zeroinitializer)
  %517 = load <8 x float>, ptr %.slot125, align 32
  %518 = select <8 x i1> %504, <8 x float> %516, <8 x float> %517
  store <8 x float> %518, ptr %.slot125, align 32
  %519 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %506)
  %520 = bitcast <8 x i1> %506 to i8
  %521 = call i8 @llvm.cttz.i8(i8 %520, i1 false)
  %522 = zext i8 %521 to i32
  %523 = select i1 %519, i32 %522, i32 0
  %524 = load <8 x float>, ptr %.slot125, align 32
  %525 = select <8 x i1> %506, <8 x float> zeroinitializer, <8 x float> %524
  store <8 x float> %525, ptr %.slot125, align 32
  br label %direct.schedule.28

direct.schedule.28:                               ; preds = %direct.schedule.26
  %.spill.load379 = load <8 x i1>, ptr %.spill124, align 1
  %526 = and <8 x i1> %119, %.spill.load379
  %527 = xor <8 x i1> %.spill.load379, splat (i1 true)
  %528 = and <8 x i1> %119, %527
  %529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %526)
  %530 = bitcast <8 x i1> %526 to i8
  %531 = call i8 @llvm.cttz.i8(i8 %530, i1 false)
  %532 = zext i8 %531 to i32
  %533 = select i1 %529, i32 %532, i32 0
  %tile_snapshot.spill.load380 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill122, align 64
  %534 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load380, 0
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load380, 1
  %.state381 = load <8 x i64>, ptr %.slot123, align 64
  %536 = mul <8 x i64> %.state381, splat (i64 32)
  %537 = add <8 x i64> %535, %536
  %538 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %534, 0
  %539 = insertvalue { <8 x ptr>, <8 x i64> } %538, <8 x i64> %537, 1
  %.state382 = load <8 x float>, ptr %.slot125, align 32
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %15, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %539, 1
  %542 = extractelement <8 x ptr> %540, i32 0
  %543 = extractelement <8 x i64> %541, i32 %533
  %544 = zext i32 %533 to i64
  %545 = mul i64 %544, 4
  %546 = sub i64 %543, %545
  %547 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %526)
  %548 = select i1 %547, i64 %546, i64 0
  %private.contiguous.address383 = getelementptr i8, ptr %542, i64 %548
  %private.contiguous.preserve384 = load <8 x float>, ptr %private.contiguous.address383, align 4
  %549 = select <8 x i1> %526, <8 x float> %.state382, <8 x float> %private.contiguous.preserve384
  store <8 x float> %549, ptr %private.contiguous.address383, align 4
  %550 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %528)
  %551 = bitcast <8 x i1> %528 to i8
  %552 = call i8 @llvm.cttz.i8(i8 %551, i1 false)
  %553 = zext i8 %552 to i32
  %554 = select i1 %550, i32 %553, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  %.state385 = load <8 x i64>, ptr %.slot123, align 64
  %555 = add <8 x i64> %.state385, splat (i64 1)
  %556 = load <8 x i64>, ptr %.slot123, align 64
  %557 = select <8 x i1> %119, <8 x i64> %555, <8 x i64> %556
  store <8 x i64> %557, ptr %.slot123, align 64
  br label %direct.schedule.25

direct.schedule.31:                               ; preds = %direct.false373
  %558 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill126, align 64
  %559 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %560 = extractvalue { <8 x ptr>, <8 x i64> } %558, 0
  %561 = select <8 x i1> %119, <8 x ptr> %559, <8 x ptr> %560
  %562 = extractvalue { <8 x ptr>, <8 x i64> } %17, 1
  %563 = extractvalue { <8 x ptr>, <8 x i64> } %558, 1
  %564 = select <8 x i1> %119, <8 x i64> %562, <8 x i64> %563
  %565 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %561, 0
  %566 = insertvalue { <8 x ptr>, <8 x i64> } %565, <8 x i64> %564, 1
  store { <8 x ptr>, <8 x i64> } %566, ptr %tile_snapshot.spill126, align 64
  %567 = load <8 x i64>, ptr %.slot127, align 64
  %568 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %567
  store <8 x i64> %568, ptr %.slot127, align 64
  br label %direct.schedule.32

direct.schedule.32:                               ; preds = %direct.schedule.37, %direct.schedule.31
  %.state386 = load <8 x i64>, ptr %.slot127, align 64
  %569 = icmp slt <8 x i64> %.state386, splat (i64 33)
  %570 = extractelement <8 x i1> %569, i32 0
  br i1 %570, label %direct.true387, label %direct.false388

direct.schedule.33:                               ; preds = %direct.true387
  %.state389 = load <8 x i64>, ptr %.slot127, align 64
  %571 = select <8 x i1> %119, <8 x i64> %.state389, <8 x i64> zeroinitializer
  %572 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %573 = srem <8 x i64> %571, %572
  %.state390 = load <8 x i64>, ptr %.slot127, align 64
  %574 = select <8 x i1> %119, <8 x i64> %.state390, <8 x i64> zeroinitializer
  %575 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %576 = sdiv <8 x i64> %574, %575
  %577 = mul <8 x i64> %573, splat (i64 8)
  %.spill.load391 = load <8 x i64>, ptr %.spill, align 64
  %578 = add <8 x i64> %577, %.spill.load391
  %579 = icmp slt <8 x i64> %578, splat (i64 3)
  %580 = load <8 x i1>, ptr %.spill128, align 1
  %581 = select <8 x i1> %119, <8 x i1> %579, <8 x i1> %580
  store <8 x i1> %581, ptr %.spill128, align 1
  %582 = select <8 x i1> %579, <8 x i64> %578, <8 x i64> splat (i64 2)
  %583 = select <8 x i1> %119, <8 x i64> %576, <8 x i64> zeroinitializer
  %584 = select <8 x i1> %119, <8 x i64> splat (i64 33), <8 x i64> splat (i64 1)
  %585 = srem <8 x i64> %583, %584
  %586 = select <8 x i1> %119, <8 x i64> %576, <8 x i64> zeroinitializer
  %587 = select <8 x i1> %119, <8 x i64> splat (i64 33), <8 x i64> splat (i64 1)
  %588 = sdiv <8 x i64> %586, %587
  %589 = select <8 x i1> %119, <8 x i64> %588, <8 x i64> zeroinitializer
  %590 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %591 = srem <8 x i64> %589, %590
  %592 = select <8 x i1> %119, <8 x i64> %588, <8 x i64> zeroinitializer
  %593 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %594 = sdiv <8 x i64> %592, %593
  %595 = select <8 x i1> %119, <8 x i64> %594, <8 x i64> zeroinitializer
  %596 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %597 = srem <8 x i64> %595, %596
  %598 = add <8 x i64> zeroinitializer, %597
  %599 = add <8 x i64> zeroinitializer, %598
  %.spill.load392 = load <8 x i64>, ptr %.spill108, align 64
  %600 = add <8 x i64> %.spill.load392, %591
  %601 = mul <8 x i64> %599, splat (i64 1)
  %602 = add <8 x i64> %601, %600
  %.spill.load393 = load <8 x i64>, ptr %.spill121, align 64
  %603 = add <8 x i64> %.spill.load393, %585
  %604 = mul <8 x i64> %602, splat (i64 35)
  %605 = add <8 x i64> %604, %603
  %606 = icmp sge <8 x i64> %603, zeroinitializer
  %607 = and <8 x i1> splat (i1 true), %606
  %608 = icmp slt <8 x i64> %603, splat (i64 35)
  %609 = and <8 x i1> %607, %608
  %610 = add <8 x i64> zeroinitializer, %582
  %611 = mul <8 x i64> %605, splat (i64 3)
  %612 = add <8 x i64> %611, %610
  %613 = and <8 x i1> %609, %579
  %614 = and <8 x i1> %119, %613
  %615 = xor <8 x i1> %613, splat (i1 true)
  %616 = and <8 x i1> %119, %615
  %617 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %614)
  %618 = bitcast <8 x i1> %614 to i8
  %619 = call i8 @llvm.cttz.i8(i8 %618, i1 false)
  %620 = zext i8 %619 to i32
  %621 = select i1 %617, i32 %620, i32 0
  %622 = extractvalue { ptr, i64 } %89, 0
  %623 = select <8 x i1> %614, <8 x i64> %612, <8 x i64> zeroinitializer
  %624 = mul <8 x i64> %623, splat (i64 4)
  %625 = getelementptr i8, ptr %622, <8 x i64> %624
  %626 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %625, <8 x i1> %614, <8 x float> zeroinitializer)
  %627 = load <8 x float>, ptr %.slot129, align 32
  %628 = select <8 x i1> %614, <8 x float> %626, <8 x float> %627
  store <8 x float> %628, ptr %.slot129, align 32
  %629 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %616)
  %630 = bitcast <8 x i1> %616 to i8
  %631 = call i8 @llvm.cttz.i8(i8 %630, i1 false)
  %632 = zext i8 %631 to i32
  %633 = select i1 %629, i32 %632, i32 0
  %634 = load <8 x float>, ptr %.slot129, align 32
  %635 = select <8 x i1> %616, <8 x float> zeroinitializer, <8 x float> %634
  store <8 x float> %635, ptr %.slot129, align 32
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.33
  %.spill.load394 = load <8 x i1>, ptr %.spill128, align 1
  %636 = and <8 x i1> %119, %.spill.load394
  %637 = xor <8 x i1> %.spill.load394, splat (i1 true)
  %638 = and <8 x i1> %119, %637
  %639 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  %640 = bitcast <8 x i1> %636 to i8
  %641 = call i8 @llvm.cttz.i8(i8 %640, i1 false)
  %642 = zext i8 %641 to i32
  %643 = select i1 %639, i32 %642, i32 0
  %tile_snapshot.spill.load395 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill126, align 64
  %644 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 0
  %645 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load395, 1
  %.state396 = load <8 x i64>, ptr %.slot127, align 64
  %646 = mul <8 x i64> %.state396, splat (i64 32)
  %647 = add <8 x i64> %645, %646
  %648 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %644, 0
  %649 = insertvalue { <8 x ptr>, <8 x i64> } %648, <8 x i64> %647, 1
  %.state397 = load <8 x float>, ptr %.slot129, align 32
  %650 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %651 = extractvalue { <8 x ptr>, <8 x i64> } %649, 1
  %652 = extractelement <8 x ptr> %650, i32 0
  %653 = extractelement <8 x i64> %651, i32 %643
  %654 = zext i32 %643 to i64
  %655 = mul i64 %654, 4
  %656 = sub i64 %653, %655
  %657 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %636)
  %658 = select i1 %657, i64 %656, i64 0
  %private.contiguous.address398 = getelementptr i8, ptr %652, i64 %658
  %private.contiguous.preserve399 = load <8 x float>, ptr %private.contiguous.address398, align 4
  %659 = select <8 x i1> %636, <8 x float> %.state397, <8 x float> %private.contiguous.preserve399
  store <8 x float> %659, ptr %private.contiguous.address398, align 4
  %660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %638)
  %661 = bitcast <8 x i1> %638 to i8
  %662 = call i8 @llvm.cttz.i8(i8 %661, i1 false)
  %663 = zext i8 %662 to i32
  %664 = select i1 %660, i32 %663, i32 0
  br label %direct.schedule.37

direct.schedule.37:                               ; preds = %direct.schedule.35
  %.state400 = load <8 x i64>, ptr %.slot127, align 64
  %665 = add <8 x i64> %.state400, splat (i64 1)
  %666 = load <8 x i64>, ptr %.slot127, align 64
  %667 = select <8 x i1> %119, <8 x i64> %665, <8 x i64> %666
  store <8 x i64> %667, ptr %.slot127, align 64
  br label %direct.schedule.32

direct.schedule.38:                               ; preds = %direct.false388
  %668 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill130, align 64
  %669 = extractvalue { <8 x ptr>, <8 x i64> } %19, 0
  %670 = extractvalue { <8 x ptr>, <8 x i64> } %668, 0
  %671 = select <8 x i1> %119, <8 x ptr> %669, <8 x ptr> %670
  %672 = extractvalue { <8 x ptr>, <8 x i64> } %19, 1
  %673 = extractvalue { <8 x ptr>, <8 x i64> } %668, 1
  %674 = select <8 x i1> %119, <8 x i64> %672, <8 x i64> %673
  %675 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %671, 0
  %676 = insertvalue { <8 x ptr>, <8 x i64> } %675, <8 x i64> %674, 1
  store { <8 x ptr>, <8 x i64> } %676, ptr %tile_snapshot.spill130, align 64
  %677 = load <8 x i64>, ptr %.slot131, align 64
  %678 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %677
  store <8 x i64> %678, ptr %.slot131, align 64
  br label %direct.schedule.39

direct.schedule.39:                               ; preds = %direct.schedule.49, %direct.schedule.38
  %.state401 = load <8 x i64>, ptr %.slot131, align 64
  %679 = icmp slt <8 x i64> %.state401, splat (i64 10)
  %680 = extractelement <8 x i1> %679, i32 0
  br i1 %680, label %direct.true402, label %direct.false403

direct.schedule.40:                               ; preds = %direct.true402
  %.state404 = load <8 x i64>, ptr %.slot131, align 64
  %681 = select <8 x i1> %119, <8 x i64> %.state404, <8 x i64> zeroinitializer
  %682 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %683 = srem <8 x i64> %681, %682
  %684 = load <8 x i64>, ptr %.spill132, align 64
  %685 = select <8 x i1> %119, <8 x i64> %683, <8 x i64> %684
  store <8 x i64> %685, ptr %.spill132, align 64
  %.state405 = load <8 x i64>, ptr %.slot131, align 64
  %686 = select <8 x i1> %119, <8 x i64> %.state405, <8 x i64> zeroinitializer
  %687 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %688 = sdiv <8 x i64> %686, %687
  %689 = mul <8 x i64> %683, splat (i64 8)
  %.spill.load406 = load <8 x i64>, ptr %.spill, align 64
  %690 = add <8 x i64> %689, %.spill.load406
  %691 = icmp slt <8 x i64> %690, splat (i64 33)
  %692 = load <8 x i1>, ptr %.spill133, align 1
  %693 = select <8 x i1> %119, <8 x i1> %691, <8 x i1> %692
  store <8 x i1> %693, ptr %.spill133, align 1
  %694 = select <8 x i1> %119, <8 x i64> %688, <8 x i64> zeroinitializer
  %695 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %696 = srem <8 x i64> %694, %695
  %697 = load <8 x i64>, ptr %.spill134, align 64
  %698 = select <8 x i1> %119, <8 x i64> %696, <8 x i64> %697
  store <8 x i64> %698, ptr %.spill134, align 64
  store i64 0, ptr %.spill135, align 4
  %699 = load <8 x i64>, ptr %.slot136, align 64
  %700 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %699
  store <8 x i64> %700, ptr %.slot136, align 64
  %701 = load <8 x float>, ptr %.slot137, align 32
  %702 = select <8 x i1> %119, <8 x float> zeroinitializer, <8 x float> %701
  store <8 x float> %702, ptr %.slot137, align 32
  br label %direct.schedule.41

direct.schedule.41:                               ; preds = %direct.schedule.46, %direct.schedule.40
  %.state407 = load <8 x i64>, ptr %.slot136, align 64
  %703 = icmp slt <8 x i64> %.state407, splat (i64 7)
  %704 = extractelement <8 x i1> %703, i32 0
  br i1 %704, label %direct.true408, label %direct.false409

direct.schedule.42:                               ; preds = %direct.true408
  %.spill.load410 = load i64, ptr %.spill135, align 4
  %705 = add i64 %.spill.load410, 0
  %706 = mul i64 %705, 1
  %707 = add i64 %706, 0
  store i64 %707, ptr %.spill138, align 4
  %708 = mul i64 %707, 2
  %.splatinsert411 = insertelement <8 x i64> poison, i64 %708, i64 0
  %.splat412 = shufflevector <8 x i64> %.splatinsert411, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load413 = load <8 x i64>, ptr %.spill134, align 64
  %709 = add <8 x i64> %.splat412, %.spill.load413
  %.state414 = load <8 x i64>, ptr %.slot136, align 64
  %710 = select <8 x i1> %119, <8 x i64> %.state414, <8 x i64> zeroinitializer
  %711 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %712 = sdiv <8 x i64> %710, %711
  %713 = mul <8 x i64> %709, splat (i64 1)
  %714 = add <8 x i64> %713, %712
  %.state415 = load <8 x i64>, ptr %.slot136, align 64
  %715 = select <8 x i1> %119, <8 x i64> %.state415, <8 x i64> zeroinitializer
  %716 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %717 = srem <8 x i64> %715, %716
  %718 = load <8 x i64>, ptr %.spill139, align 64
  %719 = select <8 x i1> %119, <8 x i64> %717, <8 x i64> %718
  store <8 x i64> %719, ptr %.spill139, align 64
  %.spill.load416 = load <8 x i64>, ptr %.spill, align 64
  %720 = icmp eq <8 x i64> %.spill.load416, %717
  %721 = and <8 x i1> %119, %720
  %722 = xor <8 x i1> %720, splat (i1 true)
  %723 = and <8 x i1> %119, %722
  %724 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %721)
  %725 = bitcast <8 x i1> %721 to i8
  %726 = call i8 @llvm.cttz.i8(i8 %725, i1 false)
  %727 = zext i8 %726 to i32
  %728 = select i1 %724, i32 %727, i32 0
  %tile_snapshot.spill.load417 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %729 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 0
  %730 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load417, 1
  %731 = mul <8 x i64> %714, splat (i64 32)
  %732 = add <8 x i64> %730, %731
  %733 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %729, 0
  %734 = insertvalue { <8 x ptr>, <8 x i64> } %733, <8 x i64> %732, 1
  %735 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %736 = extractvalue { <8 x ptr>, <8 x i64> } %734, 1
  %737 = extractelement <8 x ptr> %735, i32 0
  %738 = extractelement <8 x i64> %736, i32 %728
  %739 = zext i32 %728 to i64
  %740 = mul i64 %739, 4
  %741 = sub i64 %738, %740
  %742 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %721)
  %743 = select i1 %742, i64 %741, i64 0
  %private.contiguous.address418 = getelementptr i8, ptr %737, i64 %743
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address418, align 4
  %744 = select <8 x i1> %721, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %745 = load <8 x float>, ptr %.slot140, align 32
  %746 = select <8 x i1> %721, <8 x float> %744, <8 x float> %745
  store <8 x float> %746, ptr %.slot140, align 32
  %747 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %723)
  %748 = bitcast <8 x i1> %723 to i8
  %749 = call i8 @llvm.cttz.i8(i8 %748, i1 false)
  %750 = zext i8 %749 to i32
  %751 = select i1 %747, i32 %750, i32 0
  %752 = load <8 x float>, ptr %.slot140, align 32
  %753 = select <8 x i1> %723, <8 x float> zeroinitializer, <8 x float> %752
  store <8 x float> %753, ptr %.slot140, align 32
  br label %direct.schedule.44

direct.schedule.44:                               ; preds = %direct.schedule.42
  %.spill.load419 = load <8 x i64>, ptr %.spill139, align 64
  %754 = trunc <8 x i64> %.spill.load419 to <8 x i32>
  %.state420 = load <8 x float>, ptr %.slot140, align 32
  %755 = extractelement <8 x i32> %754, i64 0
  %756 = icmp ult i32 %755, 8
  %757 = select i1 %756, i32 %755, i32 0
  %758 = extractelement <8 x i1> %119, i32 %757
  %759 = extractelement <8 x i1> %119, i64 0
  %760 = and i1 %756, %758
  %761 = and i1 %759, %760
  %762 = extractelement <8 x float> %.state420, i32 %757
  %763 = select i1 %761, float %762, float 0.000000e+00
  %764 = insertelement <8 x float> poison, float %763, i64 0
  %765 = xor i1 %761, true
  %766 = and i1 %759, %765
  %767 = insertelement <8 x i1> poison, i1 %766, i64 0
  %768 = extractelement <8 x i32> %754, i64 1
  %769 = icmp ult i32 %768, 8
  %770 = select i1 %769, i32 %768, i32 0
  %771 = extractelement <8 x i1> %119, i32 %770
  %772 = extractelement <8 x i1> %119, i64 1
  %773 = and i1 %769, %771
  %774 = and i1 %772, %773
  %775 = extractelement <8 x float> %.state420, i32 %770
  %776 = select i1 %774, float %775, float 0.000000e+00
  %777 = insertelement <8 x float> %764, float %776, i64 1
  %778 = xor i1 %774, true
  %779 = and i1 %772, %778
  %780 = insertelement <8 x i1> %767, i1 %779, i64 1
  %781 = extractelement <8 x i32> %754, i64 2
  %782 = icmp ult i32 %781, 8
  %783 = select i1 %782, i32 %781, i32 0
  %784 = extractelement <8 x i1> %119, i32 %783
  %785 = extractelement <8 x i1> %119, i64 2
  %786 = and i1 %782, %784
  %787 = and i1 %785, %786
  %788 = extractelement <8 x float> %.state420, i32 %783
  %789 = select i1 %787, float %788, float 0.000000e+00
  %790 = insertelement <8 x float> %777, float %789, i64 2
  %791 = xor i1 %787, true
  %792 = and i1 %785, %791
  %793 = insertelement <8 x i1> %780, i1 %792, i64 2
  %794 = extractelement <8 x i32> %754, i64 3
  %795 = icmp ult i32 %794, 8
  %796 = select i1 %795, i32 %794, i32 0
  %797 = extractelement <8 x i1> %119, i32 %796
  %798 = extractelement <8 x i1> %119, i64 3
  %799 = and i1 %795, %797
  %800 = and i1 %798, %799
  %801 = extractelement <8 x float> %.state420, i32 %796
  %802 = select i1 %800, float %801, float 0.000000e+00
  %803 = insertelement <8 x float> %790, float %802, i64 3
  %804 = xor i1 %800, true
  %805 = and i1 %798, %804
  %806 = insertelement <8 x i1> %793, i1 %805, i64 3
  %807 = extractelement <8 x i32> %754, i64 4
  %808 = icmp ult i32 %807, 8
  %809 = select i1 %808, i32 %807, i32 0
  %810 = extractelement <8 x i1> %119, i32 %809
  %811 = extractelement <8 x i1> %119, i64 4
  %812 = and i1 %808, %810
  %813 = and i1 %811, %812
  %814 = extractelement <8 x float> %.state420, i32 %809
  %815 = select i1 %813, float %814, float 0.000000e+00
  %816 = insertelement <8 x float> %803, float %815, i64 4
  %817 = xor i1 %813, true
  %818 = and i1 %811, %817
  %819 = insertelement <8 x i1> %806, i1 %818, i64 4
  %820 = extractelement <8 x i32> %754, i64 5
  %821 = icmp ult i32 %820, 8
  %822 = select i1 %821, i32 %820, i32 0
  %823 = extractelement <8 x i1> %119, i32 %822
  %824 = extractelement <8 x i1> %119, i64 5
  %825 = and i1 %821, %823
  %826 = and i1 %824, %825
  %827 = extractelement <8 x float> %.state420, i32 %822
  %828 = select i1 %826, float %827, float 0.000000e+00
  %829 = insertelement <8 x float> %816, float %828, i64 5
  %830 = xor i1 %826, true
  %831 = and i1 %824, %830
  %832 = insertelement <8 x i1> %819, i1 %831, i64 5
  %833 = extractelement <8 x i32> %754, i64 6
  %834 = icmp ult i32 %833, 8
  %835 = select i1 %834, i32 %833, i32 0
  %836 = extractelement <8 x i1> %119, i32 %835
  %837 = extractelement <8 x i1> %119, i64 6
  %838 = and i1 %834, %836
  %839 = and i1 %837, %838
  %840 = extractelement <8 x float> %.state420, i32 %835
  %841 = select i1 %839, float %840, float 0.000000e+00
  %842 = insertelement <8 x float> %829, float %841, i64 6
  %843 = xor i1 %839, true
  %844 = and i1 %837, %843
  %845 = insertelement <8 x i1> %832, i1 %844, i64 6
  %846 = extractelement <8 x i32> %754, i64 7
  %847 = icmp ult i32 %846, 8
  %848 = select i1 %847, i32 %846, i32 0
  %849 = extractelement <8 x i1> %119, i32 %848
  %850 = extractelement <8 x i1> %119, i64 7
  %851 = and i1 %847, %849
  %852 = and i1 %850, %851
  %853 = extractelement <8 x float> %.state420, i32 %848
  %854 = select i1 %852, float %853, float 0.000000e+00
  %855 = insertelement <8 x float> %842, float %854, i64 7
  %856 = xor i1 %852, true
  %857 = and i1 %850, %856
  %858 = insertelement <8 x i1> %845, i1 %857, i64 7
  %859 = load <8 x float>, ptr %.spill141, align 32
  %860 = select <8 x i1> %119, <8 x float> %855, <8 x float> %859
  store <8 x float> %860, ptr %.spill141, align 32
  %.spill.load421 = load i64, ptr %.spill138, align 4
  %861 = mul i64 %.spill.load421, 5
  %.splatinsert422 = insertelement <8 x i64> poison, i64 %861, i64 0
  %.splat423 = shufflevector <8 x i64> %.splatinsert422, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load424 = load <8 x i64>, ptr %.spill132, align 64
  %862 = add <8 x i64> %.splat423, %.spill.load424
  %863 = mul <8 x i64> %862, splat (i64 7)
  %.state425 = load <8 x i64>, ptr %.slot136, align 64
  %864 = add <8 x i64> %863, %.state425
  %.spill.load426 = load <8 x i1>, ptr %.spill133, align 1
  %865 = and <8 x i1> %119, %.spill.load426
  %866 = xor <8 x i1> %.spill.load426, splat (i1 true)
  %867 = and <8 x i1> %119, %866
  %868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %865)
  %869 = bitcast <8 x i1> %865 to i8
  %870 = call i8 @llvm.cttz.i8(i8 %869, i1 false)
  %871 = zext i8 %870 to i32
  %872 = select i1 %868, i32 %871, i32 0
  %tile_snapshot.spill.load427 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill122, align 64
  %873 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 0
  %874 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load427, 1
  %875 = mul <8 x i64> %864, splat (i64 32)
  %876 = add <8 x i64> %874, %875
  %877 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %873, 0
  %878 = insertvalue { <8 x ptr>, <8 x i64> } %877, <8 x i64> %876, 1
  %879 = extractvalue { <8 x ptr>, <8 x i64> } %15, 0
  %880 = extractvalue { <8 x ptr>, <8 x i64> } %878, 1
  %881 = extractelement <8 x ptr> %879, i32 0
  %882 = extractelement <8 x i64> %880, i32 %872
  %883 = zext i32 %872 to i64
  %884 = mul i64 %883, 4
  %885 = sub i64 %882, %884
  %886 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %865)
  %887 = select i1 %886, i64 %885, i64 0
  %private.contiguous.address428 = getelementptr i8, ptr %881, i64 %887
  %private.contiguous.load429 = load <8 x float>, ptr %private.contiguous.address428, align 4
  %888 = select <8 x i1> %865, <8 x float> %private.contiguous.load429, <8 x float> zeroinitializer
  %889 = load <8 x float>, ptr %.slot142, align 32
  %890 = select <8 x i1> %865, <8 x float> %888, <8 x float> %889
  store <8 x float> %890, ptr %.slot142, align 32
  %891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %867)
  %892 = bitcast <8 x i1> %867 to i8
  %893 = call i8 @llvm.cttz.i8(i8 %892, i1 false)
  %894 = zext i8 %893 to i32
  %895 = select i1 %891, i32 %894, i32 0
  %896 = load <8 x float>, ptr %.slot142, align 32
  %897 = select <8 x i1> %867, <8 x float> zeroinitializer, <8 x float> %896
  store <8 x float> %897, ptr %.slot142, align 32
  br label %direct.schedule.46

direct.schedule.46:                               ; preds = %direct.schedule.44
  %.spill.load430 = load <8 x float>, ptr %.spill141, align 32
  %.state431 = load <8 x float>, ptr %.slot142, align 32
  %898 = fmul <8 x float> %.spill.load430, %.state431
  %.state432 = load <8 x float>, ptr %.slot137, align 32
  %899 = fadd <8 x float> %.state432, %898
  %.state433 = load <8 x i64>, ptr %.slot136, align 64
  %900 = add <8 x i64> %.state433, splat (i64 1)
  %901 = load <8 x i64>, ptr %.slot136, align 64
  %902 = select <8 x i1> %119, <8 x i64> %900, <8 x i64> %901
  store <8 x i64> %902, ptr %.slot136, align 64
  %903 = load <8 x float>, ptr %.slot137, align 32
  %904 = select <8 x i1> %119, <8 x float> %899, <8 x float> %903
  store <8 x float> %904, ptr %.slot137, align 32
  br label %direct.schedule.41

direct.schedule.47:                               ; preds = %direct.false409
  %.spill.load434 = load <8 x i1>, ptr %.spill133, align 1
  %905 = and <8 x i1> %119, %.spill.load434
  %906 = xor <8 x i1> %.spill.load434, splat (i1 true)
  %907 = and <8 x i1> %119, %906
  %908 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %905)
  %909 = bitcast <8 x i1> %905 to i8
  %910 = call i8 @llvm.cttz.i8(i8 %909, i1 false)
  %911 = zext i8 %910 to i32
  %912 = select i1 %908, i32 %911, i32 0
  %tile_snapshot.spill.load435 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill130, align 64
  %913 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 0
  %914 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load435, 1
  %.state436 = load <8 x i64>, ptr %.slot131, align 64
  %915 = mul <8 x i64> %.state436, splat (i64 32)
  %916 = add <8 x i64> %914, %915
  %917 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %913, 0
  %918 = insertvalue { <8 x ptr>, <8 x i64> } %917, <8 x i64> %916, 1
  %.state437 = load <8 x float>, ptr %.slot137, align 32
  %919 = extractvalue { <8 x ptr>, <8 x i64> } %19, 0
  %920 = extractvalue { <8 x ptr>, <8 x i64> } %918, 1
  %921 = extractelement <8 x ptr> %919, i32 0
  %922 = extractelement <8 x i64> %920, i32 %912
  %923 = zext i32 %912 to i64
  %924 = mul i64 %923, 4
  %925 = sub i64 %922, %924
  %926 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %905)
  %927 = select i1 %926, i64 %925, i64 0
  %private.contiguous.address438 = getelementptr i8, ptr %921, i64 %927
  %private.contiguous.preserve439 = load <8 x float>, ptr %private.contiguous.address438, align 4
  %928 = select <8 x i1> %905, <8 x float> %.state437, <8 x float> %private.contiguous.preserve439
  store <8 x float> %928, ptr %private.contiguous.address438, align 4
  %929 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %907)
  %930 = bitcast <8 x i1> %907 to i8
  %931 = call i8 @llvm.cttz.i8(i8 %930, i1 false)
  %932 = zext i8 %931 to i32
  %933 = select i1 %929, i32 %932, i32 0
  br label %direct.schedule.49

direct.schedule.49:                               ; preds = %direct.schedule.47
  %.state440 = load <8 x i64>, ptr %.slot131, align 64
  %934 = add <8 x i64> %.state440, splat (i64 1)
  %935 = load <8 x i64>, ptr %.slot131, align 64
  %936 = select <8 x i1> %119, <8 x i64> %934, <8 x i64> %935
  store <8 x i64> %936, ptr %.slot131, align 64
  br label %direct.schedule.39

direct.schedule.50:                               ; preds = %direct.false403
  %937 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %938 = extractvalue { <8 x ptr>, <8 x i64> } %21, 0
  %939 = extractvalue { <8 x ptr>, <8 x i64> } %937, 0
  %940 = select <8 x i1> %119, <8 x ptr> %938, <8 x ptr> %939
  %941 = extractvalue { <8 x ptr>, <8 x i64> } %21, 1
  %942 = extractvalue { <8 x ptr>, <8 x i64> } %937, 1
  %943 = select <8 x i1> %119, <8 x i64> %941, <8 x i64> %942
  %944 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %940, 0
  %945 = insertvalue { <8 x ptr>, <8 x i64> } %944, <8 x i64> %943, 1
  store { <8 x ptr>, <8 x i64> } %945, ptr %tile_snapshot.spill143, align 64
  %946 = load <8 x i64>, ptr %.slot144, align 64
  %947 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %946
  store <8 x i64> %947, ptr %.slot144, align 64
  br label %direct.schedule.51

direct.schedule.51:                               ; preds = %direct.schedule.56, %direct.schedule.50
  %.state441 = load <8 x i64>, ptr %.slot144, align 64
  %948 = icmp slt <8 x i64> %.state441, splat (i64 10)
  %949 = extractelement <8 x i1> %948, i32 0
  br i1 %949, label %direct.true442, label %direct.false443

direct.schedule.52:                               ; preds = %direct.true442
  %.state444 = load <8 x i64>, ptr %.slot144, align 64
  %950 = select <8 x i1> %119, <8 x i64> %.state444, <8 x i64> zeroinitializer
  %951 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %952 = srem <8 x i64> %950, %951
  %.state445 = load <8 x i64>, ptr %.slot144, align 64
  %953 = select <8 x i1> %119, <8 x i64> %.state445, <8 x i64> zeroinitializer
  %954 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %955 = sdiv <8 x i64> %953, %954
  %956 = mul <8 x i64> %952, splat (i64 8)
  %.spill.load446 = load <8 x i64>, ptr %.spill, align 64
  %957 = add <8 x i64> %956, %.spill.load446
  %958 = icmp slt <8 x i64> %957, splat (i64 33)
  %959 = load <8 x i1>, ptr %.spill145, align 1
  %960 = select <8 x i1> %119, <8 x i1> %958, <8 x i1> %959
  store <8 x i1> %960, ptr %.spill145, align 1
  %961 = select <8 x i1> %119, <8 x i64> %955, <8 x i64> zeroinitializer
  %962 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %963 = srem <8 x i64> %961, %962
  %964 = add <8 x i64> zeroinitializer, %963
  %965 = mul <8 x i64> %964, splat (i64 5)
  %966 = add <8 x i64> %965, %952
  %967 = and <8 x i1> %119, %958
  %968 = xor <8 x i1> %958, splat (i1 true)
  %969 = and <8 x i1> %119, %968
  %970 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %967)
  %971 = bitcast <8 x i1> %967 to i8
  %972 = call i8 @llvm.cttz.i8(i8 %971, i1 false)
  %973 = zext i8 %972 to i32
  %974 = select i1 %970, i32 %973, i32 0
  %tile_snapshot.spill.load447 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill130, align 64
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load447, 0
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load447, 1
  %977 = mul <8 x i64> %966, splat (i64 32)
  %978 = add <8 x i64> %976, %977
  %979 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %975, 0
  %980 = insertvalue { <8 x ptr>, <8 x i64> } %979, <8 x i64> %978, 1
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %19, 0
  %982 = extractvalue { <8 x ptr>, <8 x i64> } %980, 1
  %983 = extractelement <8 x ptr> %981, i32 0
  %984 = extractelement <8 x i64> %982, i32 %974
  %985 = zext i32 %974 to i64
  %986 = mul i64 %985, 4
  %987 = sub i64 %984, %986
  %988 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %967)
  %989 = select i1 %988, i64 %987, i64 0
  %private.contiguous.address448 = getelementptr i8, ptr %983, i64 %989
  %private.contiguous.load449 = load <8 x float>, ptr %private.contiguous.address448, align 4
  %990 = select <8 x i1> %967, <8 x float> %private.contiguous.load449, <8 x float> zeroinitializer
  %991 = load <8 x float>, ptr %.slot146, align 32
  %992 = select <8 x i1> %967, <8 x float> %990, <8 x float> %991
  store <8 x float> %992, ptr %.slot146, align 32
  %993 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %969)
  %994 = bitcast <8 x i1> %969 to i8
  %995 = call i8 @llvm.cttz.i8(i8 %994, i1 false)
  %996 = zext i8 %995 to i32
  %997 = select i1 %993, i32 %996, i32 0
  %998 = load <8 x float>, ptr %.slot146, align 32
  %999 = select <8 x i1> %969, <8 x float> zeroinitializer, <8 x float> %998
  store <8 x float> %999, ptr %.slot146, align 32
  br label %direct.schedule.54

direct.schedule.54:                               ; preds = %direct.schedule.52
  %.state450 = load <8 x float>, ptr %.slot146, align 32
  %1000 = fmul <8 x float> %.state450, splat (float 0x3FD8309200000000)
  %.spill.load451 = load <8 x i1>, ptr %.spill145, align 1
  %1001 = and <8 x i1> %119, %.spill.load451
  %1002 = xor <8 x i1> %.spill.load451, splat (i1 true)
  %1003 = and <8 x i1> %119, %1002
  %1004 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1001)
  %1005 = bitcast <8 x i1> %1001 to i8
  %1006 = call i8 @llvm.cttz.i8(i8 %1005, i1 false)
  %1007 = zext i8 %1006 to i32
  %1008 = select i1 %1004, i32 %1007, i32 0
  %tile_snapshot.spill.load452 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %1009 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 0
  %1010 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load452, 1
  %.state453 = load <8 x i64>, ptr %.slot144, align 64
  %1011 = mul <8 x i64> %.state453, splat (i64 32)
  %1012 = add <8 x i64> %1010, %1011
  %1013 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1009, 0
  %1014 = insertvalue { <8 x ptr>, <8 x i64> } %1013, <8 x i64> %1012, 1
  %1015 = extractvalue { <8 x ptr>, <8 x i64> } %21, 0
  %1016 = extractvalue { <8 x ptr>, <8 x i64> } %1014, 1
  %1017 = extractelement <8 x ptr> %1015, i32 0
  %1018 = extractelement <8 x i64> %1016, i32 %1008
  %1019 = zext i32 %1008 to i64
  %1020 = mul i64 %1019, 4
  %1021 = sub i64 %1018, %1020
  %1022 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1001)
  %1023 = select i1 %1022, i64 %1021, i64 0
  %private.contiguous.address454 = getelementptr i8, ptr %1017, i64 %1023
  %private.contiguous.preserve455 = load <8 x float>, ptr %private.contiguous.address454, align 4
  %1024 = select <8 x i1> %1001, <8 x float> %1000, <8 x float> %private.contiguous.preserve455
  store <8 x float> %1024, ptr %private.contiguous.address454, align 4
  %1025 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1003)
  %1026 = bitcast <8 x i1> %1003 to i8
  %1027 = call i8 @llvm.cttz.i8(i8 %1026, i1 false)
  %1028 = zext i8 %1027 to i32
  %1029 = select i1 %1025, i32 %1028, i32 0
  br label %direct.schedule.56

direct.schedule.56:                               ; preds = %direct.schedule.54
  %.state456 = load <8 x i64>, ptr %.slot144, align 64
  %1030 = add <8 x i64> %.state456, splat (i64 1)
  %1031 = load <8 x i64>, ptr %.slot144, align 64
  %1032 = select <8 x i1> %119, <8 x i64> %1030, <8 x i64> %1031
  store <8 x i64> %1032, ptr %.slot144, align 64
  br label %direct.schedule.51

direct.schedule.57:                               ; preds = %direct.false443
  %1033 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill147, align 64
  %1034 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1035 = extractvalue { <8 x ptr>, <8 x i64> } %1033, 0
  %1036 = select <8 x i1> %119, <8 x ptr> %1034, <8 x ptr> %1035
  %1037 = extractvalue { <8 x ptr>, <8 x i64> } %23, 1
  %1038 = extractvalue { <8 x ptr>, <8 x i64> } %1033, 1
  %1039 = select <8 x i1> %119, <8 x i64> %1037, <8 x i64> %1038
  %1040 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1036, 0
  %1041 = insertvalue { <8 x ptr>, <8 x i64> } %1040, <8 x i64> %1039, 1
  store { <8 x ptr>, <8 x i64> } %1041, ptr %tile_snapshot.spill147, align 64
  %1042 = load <8 x i64>, ptr %.slot148, align 64
  %1043 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1042
  store <8 x i64> %1043, ptr %.slot148, align 64
  br label %direct.schedule.58

direct.schedule.58:                               ; preds = %direct.schedule.61, %direct.schedule.57
  %.state457 = load <8 x i64>, ptr %.slot148, align 64
  %1044 = icmp slt <8 x i64> %.state457, splat (i64 5)
  %1045 = extractelement <8 x i1> %1044, i32 0
  br i1 %1045, label %direct.true458, label %direct.false459

direct.schedule.59:                               ; preds = %direct.true458
  %.state460 = load <8 x i64>, ptr %.slot148, align 64
  %1046 = select <8 x i1> %119, <8 x i64> %.state460, <8 x i64> zeroinitializer
  %1047 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1048 = srem <8 x i64> %1046, %1047
  %1049 = mul <8 x i64> %1048, splat (i64 8)
  %.spill.load461 = load <8 x i64>, ptr %.spill, align 64
  %1050 = add <8 x i64> %1049, %.spill.load461
  %1051 = icmp slt <8 x i64> %1050, splat (i64 33)
  %1052 = select <8 x i1> %1051, <8 x i64> %1050, <8 x i64> splat (i64 32)
  %1053 = and <8 x i1> %119, %1051
  %1054 = xor <8 x i1> %1051, splat (i1 true)
  %1055 = and <8 x i1> %119, %1054
  %1056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1057 = bitcast <8 x i1> %1053 to i8
  %1058 = call i8 @llvm.cttz.i8(i8 %1057, i1 false)
  %1059 = zext i8 %1058 to i32
  %1060 = select i1 %1056, i32 %1059, i32 0
  %tile_snapshot.spill.load462 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill147, align 64
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load462, 1
  %.state463 = load <8 x i64>, ptr %.slot148, align 64
  %1063 = mul <8 x i64> %.state463, splat (i64 64)
  %1064 = add <8 x i64> %1062, %1063
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1061, 0
  %1066 = insertvalue { <8 x ptr>, <8 x i64> } %1065, <8 x i64> %1064, 1
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1068 = extractvalue { <8 x ptr>, <8 x i64> } %1066, 1
  %1069 = extractelement <8 x ptr> %1067, i32 0
  %1070 = extractelement <8 x i64> %1068, i32 %1060
  %1071 = zext i32 %1060 to i64
  %1072 = mul i64 %1071, 8
  %1073 = sub i64 %1070, %1072
  %1074 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1053)
  %1075 = select i1 %1074, i64 %1073, i64 0
  %private.contiguous.address464 = getelementptr i8, ptr %1069, i64 %1075
  %private.contiguous.preserve465 = load <8 x i64>, ptr %private.contiguous.address464, align 8
  %1076 = select <8 x i1> %1053, <8 x i64> %1052, <8 x i64> %private.contiguous.preserve465
  store <8 x i64> %1076, ptr %private.contiguous.address464, align 8
  %1077 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1055)
  %1078 = bitcast <8 x i1> %1055 to i8
  %1079 = call i8 @llvm.cttz.i8(i8 %1078, i1 false)
  %1080 = zext i8 %1079 to i32
  %1081 = select i1 %1077, i32 %1080, i32 0
  br label %direct.schedule.61

direct.schedule.61:                               ; preds = %direct.schedule.59
  %.state466 = load <8 x i64>, ptr %.slot148, align 64
  %1082 = add <8 x i64> %.state466, splat (i64 1)
  %1083 = load <8 x i64>, ptr %.slot148, align 64
  %1084 = select <8 x i1> %119, <8 x i64> %1082, <8 x i64> %1083
  store <8 x i64> %1084, ptr %.slot148, align 64
  br label %direct.schedule.58

direct.schedule.62:                               ; preds = %direct.false459
  %1085 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill149, align 64
  %1086 = extractvalue { <8 x ptr>, <8 x i64> } %25, 0
  %1087 = extractvalue { <8 x ptr>, <8 x i64> } %1085, 0
  %1088 = select <8 x i1> %119, <8 x ptr> %1086, <8 x ptr> %1087
  %1089 = extractvalue { <8 x ptr>, <8 x i64> } %25, 1
  %1090 = extractvalue { <8 x ptr>, <8 x i64> } %1085, 1
  %1091 = select <8 x i1> %119, <8 x i64> %1089, <8 x i64> %1090
  %1092 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1088, 0
  %1093 = insertvalue { <8 x ptr>, <8 x i64> } %1092, <8 x i64> %1091, 1
  store { <8 x ptr>, <8 x i64> } %1093, ptr %tile_snapshot.spill149, align 64
  %1094 = load <8 x i64>, ptr %.slot150, align 64
  %1095 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1094
  store <8 x i64> %1095, ptr %.slot150, align 64
  br label %direct.schedule.63

direct.schedule.63:                               ; preds = %direct.schedule.68, %direct.schedule.62
  %.state467 = load <8 x i64>, ptr %.slot150, align 64
  %1096 = icmp slt <8 x i64> %.state467, splat (i64 5)
  %1097 = extractelement <8 x i1> %1096, i32 0
  br i1 %1097, label %direct.true468, label %direct.false469

direct.schedule.64:                               ; preds = %direct.true468
  %.state470 = load <8 x i64>, ptr %.slot150, align 64
  %1098 = select <8 x i1> %119, <8 x i64> %.state470, <8 x i64> zeroinitializer
  %1099 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1100 = srem <8 x i64> %1098, %1099
  %1101 = mul <8 x i64> %1100, splat (i64 8)
  %.spill.load471 = load <8 x i64>, ptr %.spill, align 64
  %1102 = add <8 x i64> %1101, %.spill.load471
  %1103 = icmp slt <8 x i64> %1102, splat (i64 33)
  %1104 = load <8 x i1>, ptr %.spill151, align 1
  %1105 = select <8 x i1> %119, <8 x i1> %1103, <8 x i1> %1104
  store <8 x i1> %1105, ptr %.spill151, align 1
  %1106 = add <8 x i64> zeroinitializer, %1100
  %1107 = and <8 x i1> %119, %1103
  %1108 = xor <8 x i1> %1103, splat (i1 true)
  %1109 = and <8 x i1> %119, %1108
  %1110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1107)
  %1111 = bitcast <8 x i1> %1107 to i8
  %1112 = call i8 @llvm.cttz.i8(i8 %1111, i1 false)
  %1113 = zext i8 %1112 to i32
  %1114 = select i1 %1110, i32 %1113, i32 0
  %tile_snapshot.spill.load472 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill147, align 64
  %1115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 0
  %1116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load472, 1
  %1117 = mul <8 x i64> %1106, splat (i64 64)
  %1118 = add <8 x i64> %1116, %1117
  %1119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1115, 0
  %1120 = insertvalue { <8 x ptr>, <8 x i64> } %1119, <8 x i64> %1118, 1
  %1121 = extractvalue { <8 x ptr>, <8 x i64> } %23, 0
  %1122 = extractvalue { <8 x ptr>, <8 x i64> } %1120, 1
  %1123 = extractelement <8 x ptr> %1121, i32 0
  %1124 = extractelement <8 x i64> %1122, i32 %1114
  %1125 = zext i32 %1114 to i64
  %1126 = mul i64 %1125, 8
  %1127 = sub i64 %1124, %1126
  %1128 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1107)
  %1129 = select i1 %1128, i64 %1127, i64 0
  %private.contiguous.address473 = getelementptr i8, ptr %1123, i64 %1129
  %private.contiguous.load474 = load <8 x i64>, ptr %private.contiguous.address473, align 8
  %1130 = select <8 x i1> %1107, <8 x i64> %private.contiguous.load474, <8 x i64> zeroinitializer
  %1131 = load <8 x i64>, ptr %.slot152, align 64
  %1132 = select <8 x i1> %1107, <8 x i64> %1130, <8 x i64> %1131
  store <8 x i64> %1132, ptr %.slot152, align 64
  %1133 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1109)
  %1134 = bitcast <8 x i1> %1109 to i8
  %1135 = call i8 @llvm.cttz.i8(i8 %1134, i1 false)
  %1136 = zext i8 %1135 to i32
  %1137 = select i1 %1133, i32 %1136, i32 0
  %1138 = load <8 x i64>, ptr %.slot152, align 64
  %1139 = select <8 x i1> %1109, <8 x i64> zeroinitializer, <8 x i64> %1138
  store <8 x i64> %1139, ptr %.slot152, align 64
  br label %direct.schedule.66

direct.schedule.66:                               ; preds = %direct.schedule.64
  %.state475 = load <8 x i64>, ptr %.slot152, align 64
  %.spill.load476 = load <8 x i64>, ptr %.spill121, align 64
  %1140 = add <8 x i64> %.state475, %.spill.load476
  %.spill.load477 = load <8 x i1>, ptr %.spill151, align 1
  %1141 = and <8 x i1> %119, %.spill.load477
  %1142 = xor <8 x i1> %.spill.load477, splat (i1 true)
  %1143 = and <8 x i1> %119, %1142
  %1144 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1141)
  %1145 = bitcast <8 x i1> %1141 to i8
  %1146 = call i8 @llvm.cttz.i8(i8 %1145, i1 false)
  %1147 = zext i8 %1146 to i32
  %1148 = select i1 %1144, i32 %1147, i32 0
  %tile_snapshot.spill.load478 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill149, align 64
  %1149 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 0
  %1150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load478, 1
  %.state479 = load <8 x i64>, ptr %.slot150, align 64
  %1151 = mul <8 x i64> %.state479, splat (i64 64)
  %1152 = add <8 x i64> %1150, %1151
  %1153 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1149, 0
  %1154 = insertvalue { <8 x ptr>, <8 x i64> } %1153, <8 x i64> %1152, 1
  %1155 = extractvalue { <8 x ptr>, <8 x i64> } %25, 0
  %1156 = extractvalue { <8 x ptr>, <8 x i64> } %1154, 1
  %1157 = extractelement <8 x ptr> %1155, i32 0
  %1158 = extractelement <8 x i64> %1156, i32 %1148
  %1159 = zext i32 %1148 to i64
  %1160 = mul i64 %1159, 8
  %1161 = sub i64 %1158, %1160
  %1162 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1141)
  %1163 = select i1 %1162, i64 %1161, i64 0
  %private.contiguous.address480 = getelementptr i8, ptr %1157, i64 %1163
  %private.contiguous.preserve481 = load <8 x i64>, ptr %private.contiguous.address480, align 8
  %1164 = select <8 x i1> %1141, <8 x i64> %1140, <8 x i64> %private.contiguous.preserve481
  store <8 x i64> %1164, ptr %private.contiguous.address480, align 8
  %1165 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1143)
  %1166 = bitcast <8 x i1> %1143 to i8
  %1167 = call i8 @llvm.cttz.i8(i8 %1166, i1 false)
  %1168 = zext i8 %1167 to i32
  %1169 = select i1 %1165, i32 %1168, i32 0
  br label %direct.schedule.68

direct.schedule.68:                               ; preds = %direct.schedule.66
  %.state482 = load <8 x i64>, ptr %.slot150, align 64
  %1170 = add <8 x i64> %.state482, splat (i64 1)
  %1171 = load <8 x i64>, ptr %.slot150, align 64
  %1172 = select <8 x i1> %119, <8 x i64> %1170, <8 x i64> %1171
  store <8 x i64> %1172, ptr %.slot150, align 64
  br label %direct.schedule.63

direct.schedule.69:                               ; preds = %direct.false469
  %1173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1174 = extractvalue { <8 x ptr>, <8 x i64> } %27, 0
  %1175 = extractvalue { <8 x ptr>, <8 x i64> } %1173, 0
  %1176 = select <8 x i1> %119, <8 x ptr> %1174, <8 x ptr> %1175
  %1177 = extractvalue { <8 x ptr>, <8 x i64> } %27, 1
  %1178 = extractvalue { <8 x ptr>, <8 x i64> } %1173, 1
  %1179 = select <8 x i1> %119, <8 x i64> %1177, <8 x i64> %1178
  %1180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1176, 0
  %1181 = insertvalue { <8 x ptr>, <8 x i64> } %1180, <8 x i64> %1179, 1
  store { <8 x ptr>, <8 x i64> } %1181, ptr %tile_snapshot.spill153, align 64
  %1182 = load <8 x i64>, ptr %.slot154, align 64
  %1183 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1182
  store <8 x i64> %1183, ptr %.slot154, align 64
  br label %direct.schedule.70

direct.schedule.70:                               ; preds = %direct.schedule.75, %direct.schedule.69
  %.state483 = load <8 x i64>, ptr %.slot154, align 64
  %1184 = icmp slt <8 x i64> %.state483, splat (i64 5)
  %1185 = extractelement <8 x i1> %1184, i32 0
  br i1 %1185, label %direct.true484, label %direct.false485

direct.schedule.71:                               ; preds = %direct.true484
  %.state486 = load <8 x i64>, ptr %.slot154, align 64
  %1186 = select <8 x i1> %119, <8 x i64> %.state486, <8 x i64> zeroinitializer
  %1187 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1188 = srem <8 x i64> %1186, %1187
  %1189 = mul <8 x i64> %1188, splat (i64 8)
  %.spill.load487 = load <8 x i64>, ptr %.spill, align 64
  %1190 = add <8 x i64> %1189, %.spill.load487
  %1191 = icmp slt <8 x i64> %1190, splat (i64 33)
  %1192 = load <8 x i1>, ptr %.spill155, align 1
  %1193 = select <8 x i1> %119, <8 x i1> %1191, <8 x i1> %1192
  store <8 x i1> %1193, ptr %.spill155, align 1
  %1194 = add <8 x i64> zeroinitializer, %1188
  %1195 = and <8 x i1> %119, %1191
  %1196 = xor <8 x i1> %1191, splat (i1 true)
  %1197 = and <8 x i1> %119, %1196
  %1198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1195)
  %1199 = bitcast <8 x i1> %1195 to i8
  %1200 = call i8 @llvm.cttz.i8(i8 %1199, i1 false)
  %1201 = zext i8 %1200 to i32
  %1202 = select i1 %1198, i32 %1201, i32 0
  %tile_snapshot.spill.load488 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill149, align 64
  %1203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load488, 0
  %1204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load488, 1
  %1205 = mul <8 x i64> %1194, splat (i64 64)
  %1206 = add <8 x i64> %1204, %1205
  %1207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1203, 0
  %1208 = insertvalue { <8 x ptr>, <8 x i64> } %1207, <8 x i64> %1206, 1
  %1209 = extractvalue { <8 x ptr>, <8 x i64> } %25, 0
  %1210 = extractvalue { <8 x ptr>, <8 x i64> } %1208, 1
  %1211 = extractelement <8 x ptr> %1209, i32 0
  %1212 = extractelement <8 x i64> %1210, i32 %1202
  %1213 = zext i32 %1202 to i64
  %1214 = mul i64 %1213, 8
  %1215 = sub i64 %1212, %1214
  %1216 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1195)
  %1217 = select i1 %1216, i64 %1215, i64 0
  %private.contiguous.address489 = getelementptr i8, ptr %1211, i64 %1217
  %private.contiguous.load490 = load <8 x i64>, ptr %private.contiguous.address489, align 8
  %1218 = select <8 x i1> %1195, <8 x i64> %private.contiguous.load490, <8 x i64> zeroinitializer
  %1219 = load <8 x i64>, ptr %.slot156, align 64
  %1220 = select <8 x i1> %1195, <8 x i64> %1218, <8 x i64> %1219
  store <8 x i64> %1220, ptr %.slot156, align 64
  %1221 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1197)
  %1222 = bitcast <8 x i1> %1197 to i8
  %1223 = call i8 @llvm.cttz.i8(i8 %1222, i1 false)
  %1224 = zext i8 %1223 to i32
  %1225 = select i1 %1221, i32 %1224, i32 0
  %1226 = load <8 x i64>, ptr %.slot156, align 64
  %1227 = select <8 x i1> %1197, <8 x i64> zeroinitializer, <8 x i64> %1226
  store <8 x i64> %1227, ptr %.slot156, align 64
  br label %direct.schedule.73

direct.schedule.73:                               ; preds = %direct.schedule.71
  %.state491 = load <8 x i64>, ptr %.slot156, align 64
  %1228 = icmp slt <8 x i64> %.state491, splat (i64 35)
  %.spill.load492 = load <8 x i1>, ptr %.spill155, align 1
  %1229 = and <8 x i1> %119, %.spill.load492
  %1230 = xor <8 x i1> %.spill.load492, splat (i1 true)
  %1231 = and <8 x i1> %119, %1230
  %1232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1229)
  %1233 = bitcast <8 x i1> %1229 to i8
  %1234 = call i8 @llvm.cttz.i8(i8 %1233, i1 false)
  %1235 = zext i8 %1234 to i32
  %1236 = select i1 %1232, i32 %1235, i32 0
  %tile_snapshot.spill.load493 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 0
  %1238 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load493, 1
  %.state494 = load <8 x i64>, ptr %.slot154, align 64
  %1239 = add <8 x i64> %1238, %.state494
  %1240 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1237, 0
  %1241 = insertvalue { <8 x ptr>, <8 x i64> } %1240, <8 x i64> %1239, 1
  %1242 = extractvalue { <8 x ptr>, <8 x i64> } %1241, 0
  %1243 = extractvalue { <8 x ptr>, <8 x i64> } %1241, 1
  %1244 = getelementptr i8, <8 x ptr> %1242, <8 x i64> %1243
  %1245 = zext <8 x i1> %1228 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1245, <8 x ptr> align 1 %1244, <8 x i1> %1229)
  %1246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1231)
  %1247 = bitcast <8 x i1> %1231 to i8
  %1248 = call i8 @llvm.cttz.i8(i8 %1247, i1 false)
  %1249 = zext i8 %1248 to i32
  %1250 = select i1 %1246, i32 %1249, i32 0
  br label %direct.schedule.75

direct.schedule.75:                               ; preds = %direct.schedule.73
  %.state495 = load <8 x i64>, ptr %.slot154, align 64
  %1251 = add <8 x i64> %.state495, splat (i64 1)
  %1252 = load <8 x i64>, ptr %.slot154, align 64
  %1253 = select <8 x i1> %119, <8 x i64> %1251, <8 x i64> %1252
  store <8 x i64> %1253, ptr %.slot154, align 64
  br label %direct.schedule.70

direct.schedule.76:                               ; preds = %direct.false485
  %1254 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill157, align 64
  %1255 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1256 = extractvalue { <8 x ptr>, <8 x i64> } %1254, 0
  %1257 = select <8 x i1> %119, <8 x ptr> %1255, <8 x ptr> %1256
  %1258 = extractvalue { <8 x ptr>, <8 x i64> } %29, 1
  %1259 = extractvalue { <8 x ptr>, <8 x i64> } %1254, 1
  %1260 = select <8 x i1> %119, <8 x i64> %1258, <8 x i64> %1259
  %1261 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1257, 0
  %1262 = insertvalue { <8 x ptr>, <8 x i64> } %1261, <8 x i64> %1260, 1
  store { <8 x ptr>, <8 x i64> } %1262, ptr %tile_snapshot.spill157, align 64
  %1263 = load <8 x i64>, ptr %.slot158, align 64
  %1264 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1263
  store <8 x i64> %1264, ptr %.slot158, align 64
  br label %direct.schedule.77

direct.schedule.77:                               ; preds = %direct.schedule.80, %direct.schedule.76
  %.state496 = load <8 x i64>, ptr %.slot158, align 64
  %1265 = icmp slt <8 x i64> %.state496, splat (i64 5)
  %1266 = extractelement <8 x i1> %1265, i32 0
  br i1 %1266, label %direct.true497, label %direct.false498

direct.schedule.78:                               ; preds = %direct.true497
  %.state499 = load <8 x i64>, ptr %.slot158, align 64
  %1267 = select <8 x i1> %119, <8 x i64> %.state499, <8 x i64> zeroinitializer
  %1268 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1269 = srem <8 x i64> %1267, %1268
  %1270 = mul <8 x i64> %1269, splat (i64 8)
  %.spill.load500 = load <8 x i64>, ptr %.spill, align 64
  %1271 = add <8 x i64> %1270, %.spill.load500
  %1272 = icmp slt <8 x i64> %1271, splat (i64 33)
  %1273 = select <8 x i1> %1272, <8 x i64> %1271, <8 x i64> splat (i64 32)
  %1274 = and <8 x i1> %119, %1272
  %1275 = xor <8 x i1> %1272, splat (i1 true)
  %1276 = and <8 x i1> %119, %1275
  %1277 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1274)
  %1278 = bitcast <8 x i1> %1274 to i8
  %1279 = call i8 @llvm.cttz.i8(i8 %1278, i1 false)
  %1280 = zext i8 %1279 to i32
  %1281 = select i1 %1277, i32 %1280, i32 0
  %tile_snapshot.spill.load501 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill157, align 64
  %1282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load501, 0
  %1283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load501, 1
  %.state502 = load <8 x i64>, ptr %.slot158, align 64
  %1284 = mul <8 x i64> %.state502, splat (i64 64)
  %1285 = add <8 x i64> %1283, %1284
  %1286 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1282, 0
  %1287 = insertvalue { <8 x ptr>, <8 x i64> } %1286, <8 x i64> %1285, 1
  %1288 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1289 = extractvalue { <8 x ptr>, <8 x i64> } %1287, 1
  %1290 = extractelement <8 x ptr> %1288, i32 0
  %1291 = extractelement <8 x i64> %1289, i32 %1281
  %1292 = zext i32 %1281 to i64
  %1293 = mul i64 %1292, 8
  %1294 = sub i64 %1291, %1293
  %1295 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1274)
  %1296 = select i1 %1295, i64 %1294, i64 0
  %private.contiguous.address503 = getelementptr i8, ptr %1290, i64 %1296
  %private.contiguous.preserve504 = load <8 x i64>, ptr %private.contiguous.address503, align 8
  %1297 = select <8 x i1> %1274, <8 x i64> %1273, <8 x i64> %private.contiguous.preserve504
  store <8 x i64> %1297, ptr %private.contiguous.address503, align 8
  %1298 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1276)
  %1299 = bitcast <8 x i1> %1276 to i8
  %1300 = call i8 @llvm.cttz.i8(i8 %1299, i1 false)
  %1301 = zext i8 %1300 to i32
  %1302 = select i1 %1298, i32 %1301, i32 0
  br label %direct.schedule.80

direct.schedule.80:                               ; preds = %direct.schedule.78
  %.state505 = load <8 x i64>, ptr %.slot158, align 64
  %1303 = add <8 x i64> %.state505, splat (i64 1)
  %1304 = load <8 x i64>, ptr %.slot158, align 64
  %1305 = select <8 x i1> %119, <8 x i64> %1303, <8 x i64> %1304
  store <8 x i64> %1305, ptr %.slot158, align 64
  br label %direct.schedule.77

direct.schedule.81:                               ; preds = %direct.false498
  %1306 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill159, align 64
  %1307 = extractvalue { <8 x ptr>, <8 x i64> } %31, 0
  %1308 = extractvalue { <8 x ptr>, <8 x i64> } %1306, 0
  %1309 = select <8 x i1> %119, <8 x ptr> %1307, <8 x ptr> %1308
  %1310 = extractvalue { <8 x ptr>, <8 x i64> } %31, 1
  %1311 = extractvalue { <8 x ptr>, <8 x i64> } %1306, 1
  %1312 = select <8 x i1> %119, <8 x i64> %1310, <8 x i64> %1311
  %1313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1309, 0
  %1314 = insertvalue { <8 x ptr>, <8 x i64> } %1313, <8 x i64> %1312, 1
  store { <8 x ptr>, <8 x i64> } %1314, ptr %tile_snapshot.spill159, align 64
  %1315 = load <8 x i64>, ptr %.slot160, align 64
  %1316 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1315
  store <8 x i64> %1316, ptr %.slot160, align 64
  br label %direct.schedule.82

direct.schedule.82:                               ; preds = %direct.schedule.87, %direct.schedule.81
  %.state506 = load <8 x i64>, ptr %.slot160, align 64
  %1317 = icmp slt <8 x i64> %.state506, splat (i64 5)
  %1318 = extractelement <8 x i1> %1317, i32 0
  br i1 %1318, label %direct.true507, label %direct.false508

direct.schedule.83:                               ; preds = %direct.true507
  %.state509 = load <8 x i64>, ptr %.slot160, align 64
  %1319 = select <8 x i1> %119, <8 x i64> %.state509, <8 x i64> zeroinitializer
  %1320 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1321 = srem <8 x i64> %1319, %1320
  %1322 = mul <8 x i64> %1321, splat (i64 8)
  %.spill.load510 = load <8 x i64>, ptr %.spill, align 64
  %1323 = add <8 x i64> %1322, %.spill.load510
  %1324 = icmp slt <8 x i64> %1323, splat (i64 33)
  %1325 = load <8 x i1>, ptr %.spill161, align 1
  %1326 = select <8 x i1> %119, <8 x i1> %1324, <8 x i1> %1325
  store <8 x i1> %1326, ptr %.spill161, align 1
  %1327 = add <8 x i64> zeroinitializer, %1321
  %1328 = and <8 x i1> %119, %1324
  %1329 = xor <8 x i1> %1324, splat (i1 true)
  %1330 = and <8 x i1> %119, %1329
  %1331 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1328)
  %1332 = bitcast <8 x i1> %1328 to i8
  %1333 = call i8 @llvm.cttz.i8(i8 %1332, i1 false)
  %1334 = zext i8 %1333 to i32
  %1335 = select i1 %1331, i32 %1334, i32 0
  %tile_snapshot.spill.load511 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill157, align 64
  %1336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load511, 0
  %1337 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load511, 1
  %1338 = mul <8 x i64> %1327, splat (i64 64)
  %1339 = add <8 x i64> %1337, %1338
  %1340 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1336, 0
  %1341 = insertvalue { <8 x ptr>, <8 x i64> } %1340, <8 x i64> %1339, 1
  %1342 = extractvalue { <8 x ptr>, <8 x i64> } %29, 0
  %1343 = extractvalue { <8 x ptr>, <8 x i64> } %1341, 1
  %1344 = extractelement <8 x ptr> %1342, i32 0
  %1345 = extractelement <8 x i64> %1343, i32 %1335
  %1346 = zext i32 %1335 to i64
  %1347 = mul i64 %1346, 8
  %1348 = sub i64 %1345, %1347
  %1349 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1328)
  %1350 = select i1 %1349, i64 %1348, i64 0
  %private.contiguous.address512 = getelementptr i8, ptr %1344, i64 %1350
  %private.contiguous.load513 = load <8 x i64>, ptr %private.contiguous.address512, align 8
  %1351 = select <8 x i1> %1328, <8 x i64> %private.contiguous.load513, <8 x i64> zeroinitializer
  %1352 = load <8 x i64>, ptr %.slot162, align 64
  %1353 = select <8 x i1> %1328, <8 x i64> %1351, <8 x i64> %1352
  store <8 x i64> %1353, ptr %.slot162, align 64
  %1354 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1330)
  %1355 = bitcast <8 x i1> %1330 to i8
  %1356 = call i8 @llvm.cttz.i8(i8 %1355, i1 false)
  %1357 = zext i8 %1356 to i32
  %1358 = select i1 %1354, i32 %1357, i32 0
  %1359 = load <8 x i64>, ptr %.slot162, align 64
  %1360 = select <8 x i1> %1330, <8 x i64> zeroinitializer, <8 x i64> %1359
  store <8 x i64> %1360, ptr %.slot162, align 64
  br label %direct.schedule.85

direct.schedule.85:                               ; preds = %direct.schedule.83
  %.state514 = load <8 x i64>, ptr %.slot162, align 64
  %.spill.load515 = load <8 x i64>, ptr %.spill121, align 64
  %1361 = add <8 x i64> %.state514, %.spill.load515
  %.spill.load516 = load <8 x i1>, ptr %.spill161, align 1
  %1362 = and <8 x i1> %119, %.spill.load516
  %1363 = xor <8 x i1> %.spill.load516, splat (i1 true)
  %1364 = and <8 x i1> %119, %1363
  %1365 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1362)
  %1366 = bitcast <8 x i1> %1362 to i8
  %1367 = call i8 @llvm.cttz.i8(i8 %1366, i1 false)
  %1368 = zext i8 %1367 to i32
  %1369 = select i1 %1365, i32 %1368, i32 0
  %tile_snapshot.spill.load517 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill159, align 64
  %1370 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load517, 0
  %1371 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load517, 1
  %.state518 = load <8 x i64>, ptr %.slot160, align 64
  %1372 = mul <8 x i64> %.state518, splat (i64 64)
  %1373 = add <8 x i64> %1371, %1372
  %1374 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1370, 0
  %1375 = insertvalue { <8 x ptr>, <8 x i64> } %1374, <8 x i64> %1373, 1
  %1376 = extractvalue { <8 x ptr>, <8 x i64> } %31, 0
  %1377 = extractvalue { <8 x ptr>, <8 x i64> } %1375, 1
  %1378 = extractelement <8 x ptr> %1376, i32 0
  %1379 = extractelement <8 x i64> %1377, i32 %1369
  %1380 = zext i32 %1369 to i64
  %1381 = mul i64 %1380, 8
  %1382 = sub i64 %1379, %1381
  %1383 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1362)
  %1384 = select i1 %1383, i64 %1382, i64 0
  %private.contiguous.address519 = getelementptr i8, ptr %1378, i64 %1384
  %private.contiguous.preserve520 = load <8 x i64>, ptr %private.contiguous.address519, align 8
  %1385 = select <8 x i1> %1362, <8 x i64> %1361, <8 x i64> %private.contiguous.preserve520
  store <8 x i64> %1385, ptr %private.contiguous.address519, align 8
  %1386 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1364)
  %1387 = bitcast <8 x i1> %1364 to i8
  %1388 = call i8 @llvm.cttz.i8(i8 %1387, i1 false)
  %1389 = zext i8 %1388 to i32
  %1390 = select i1 %1386, i32 %1389, i32 0
  br label %direct.schedule.87

direct.schedule.87:                               ; preds = %direct.schedule.85
  %.state521 = load <8 x i64>, ptr %.slot160, align 64
  %1391 = add <8 x i64> %.state521, splat (i64 1)
  %1392 = load <8 x i64>, ptr %.slot160, align 64
  %1393 = select <8 x i1> %119, <8 x i64> %1391, <8 x i64> %1392
  store <8 x i64> %1393, ptr %.slot160, align 64
  br label %direct.schedule.82

direct.schedule.88:                               ; preds = %direct.false508
  %1394 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill163, align 64
  %1395 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %1396 = extractvalue { <8 x ptr>, <8 x i64> } %1394, 0
  %1397 = select <8 x i1> %119, <8 x ptr> %1395, <8 x ptr> %1396
  %1398 = extractvalue { <8 x ptr>, <8 x i64> } %33, 1
  %1399 = extractvalue { <8 x ptr>, <8 x i64> } %1394, 1
  %1400 = select <8 x i1> %119, <8 x i64> %1398, <8 x i64> %1399
  %1401 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1397, 0
  %1402 = insertvalue { <8 x ptr>, <8 x i64> } %1401, <8 x i64> %1400, 1
  store { <8 x ptr>, <8 x i64> } %1402, ptr %tile_snapshot.spill163, align 64
  %1403 = load <8 x i64>, ptr %.slot164, align 64
  %1404 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1403
  store <8 x i64> %1404, ptr %.slot164, align 64
  br label %direct.schedule.89

direct.schedule.89:                               ; preds = %direct.schedule.92, %direct.schedule.88
  %.state522 = load <8 x i64>, ptr %.slot164, align 64
  %1405 = icmp slt <8 x i64> %.state522, splat (i64 1)
  %1406 = extractelement <8 x i1> %1405, i32 0
  br i1 %1406, label %direct.true523, label %direct.false524

direct.schedule.90:                               ; preds = %direct.true523
  %.state525 = load <8 x i64>, ptr %.slot164, align 64
  %1407 = select <8 x i1> %119, <8 x i64> %.state525, <8 x i64> zeroinitializer
  %1408 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1409 = srem <8 x i64> %1407, %1408
  %1410 = mul <8 x i64> %1409, splat (i64 8)
  %.spill.load526 = load <8 x i64>, ptr %.spill, align 64
  %1411 = add <8 x i64> %1410, %.spill.load526
  %1412 = icmp slt <8 x i64> %1411, splat (i64 2)
  %1413 = select <8 x i1> %1412, <8 x i64> %1411, <8 x i64> splat (i64 1)
  %1414 = and <8 x i1> %119, %1412
  %1415 = xor <8 x i1> %1412, splat (i1 true)
  %1416 = and <8 x i1> %119, %1415
  %1417 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1414)
  %1418 = bitcast <8 x i1> %1414 to i8
  %1419 = call i8 @llvm.cttz.i8(i8 %1418, i1 false)
  %1420 = zext i8 %1419 to i32
  %1421 = select i1 %1417, i32 %1420, i32 0
  %tile_snapshot.spill.load527 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill163, align 64
  %1422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load527, 0
  %1423 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load527, 1
  %.state528 = load <8 x i64>, ptr %.slot164, align 64
  %1424 = mul <8 x i64> %.state528, splat (i64 64)
  %1425 = add <8 x i64> %1423, %1424
  %1426 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1422, 0
  %1427 = insertvalue { <8 x ptr>, <8 x i64> } %1426, <8 x i64> %1425, 1
  %1428 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %1429 = extractvalue { <8 x ptr>, <8 x i64> } %1427, 1
  %1430 = extractelement <8 x ptr> %1428, i32 0
  %1431 = extractelement <8 x i64> %1429, i32 %1421
  %1432 = zext i32 %1421 to i64
  %1433 = mul i64 %1432, 8
  %1434 = sub i64 %1431, %1433
  %1435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1414)
  %1436 = select i1 %1435, i64 %1434, i64 0
  %private.contiguous.address529 = getelementptr i8, ptr %1430, i64 %1436
  %private.contiguous.preserve530 = load <8 x i64>, ptr %private.contiguous.address529, align 8
  %1437 = select <8 x i1> %1414, <8 x i64> %1413, <8 x i64> %private.contiguous.preserve530
  store <8 x i64> %1437, ptr %private.contiguous.address529, align 8
  %1438 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1416)
  %1439 = bitcast <8 x i1> %1416 to i8
  %1440 = call i8 @llvm.cttz.i8(i8 %1439, i1 false)
  %1441 = zext i8 %1440 to i32
  %1442 = select i1 %1438, i32 %1441, i32 0
  br label %direct.schedule.92

direct.schedule.92:                               ; preds = %direct.schedule.90
  %.state531 = load <8 x i64>, ptr %.slot164, align 64
  %1443 = add <8 x i64> %.state531, splat (i64 1)
  %1444 = load <8 x i64>, ptr %.slot164, align 64
  %1445 = select <8 x i1> %119, <8 x i64> %1443, <8 x i64> %1444
  store <8 x i64> %1445, ptr %.slot164, align 64
  br label %direct.schedule.89

direct.schedule.93:                               ; preds = %direct.false524
  %1446 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill165, align 64
  %1447 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %1448 = extractvalue { <8 x ptr>, <8 x i64> } %1446, 0
  %1449 = select <8 x i1> %119, <8 x ptr> %1447, <8 x ptr> %1448
  %1450 = extractvalue { <8 x ptr>, <8 x i64> } %35, 1
  %1451 = extractvalue { <8 x ptr>, <8 x i64> } %1446, 1
  %1452 = select <8 x i1> %119, <8 x i64> %1450, <8 x i64> %1451
  %1453 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1449, 0
  %1454 = insertvalue { <8 x ptr>, <8 x i64> } %1453, <8 x i64> %1452, 1
  store { <8 x ptr>, <8 x i64> } %1454, ptr %tile_snapshot.spill165, align 64
  %1455 = load <8 x i64>, ptr %.slot166, align 64
  %1456 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1455
  store <8 x i64> %1456, ptr %.slot166, align 64
  br label %direct.schedule.94

direct.schedule.94:                               ; preds = %direct.schedule.99, %direct.schedule.93
  %.state532 = load <8 x i64>, ptr %.slot166, align 64
  %1457 = icmp slt <8 x i64> %.state532, splat (i64 1)
  %1458 = extractelement <8 x i1> %1457, i32 0
  br i1 %1458, label %direct.true533, label %direct.false534

direct.schedule.95:                               ; preds = %direct.true533
  %.state535 = load <8 x i64>, ptr %.slot166, align 64
  %1459 = select <8 x i1> %119, <8 x i64> %.state535, <8 x i64> zeroinitializer
  %1460 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1461 = srem <8 x i64> %1459, %1460
  %1462 = mul <8 x i64> %1461, splat (i64 8)
  %.spill.load536 = load <8 x i64>, ptr %.spill, align 64
  %1463 = add <8 x i64> %1462, %.spill.load536
  %1464 = icmp slt <8 x i64> %1463, splat (i64 2)
  %1465 = load <8 x i1>, ptr %.spill167, align 1
  %1466 = select <8 x i1> %119, <8 x i1> %1464, <8 x i1> %1465
  store <8 x i1> %1466, ptr %.spill167, align 1
  %1467 = add <8 x i64> zeroinitializer, %1461
  %1468 = and <8 x i1> %119, %1464
  %1469 = xor <8 x i1> %1464, splat (i1 true)
  %1470 = and <8 x i1> %119, %1469
  %1471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1468)
  %1472 = bitcast <8 x i1> %1468 to i8
  %1473 = call i8 @llvm.cttz.i8(i8 %1472, i1 false)
  %1474 = zext i8 %1473 to i32
  %1475 = select i1 %1471, i32 %1474, i32 0
  %tile_snapshot.spill.load537 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill163, align 64
  %1476 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load537, 0
  %1477 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load537, 1
  %1478 = mul <8 x i64> %1467, splat (i64 64)
  %1479 = add <8 x i64> %1477, %1478
  %1480 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1476, 0
  %1481 = insertvalue { <8 x ptr>, <8 x i64> } %1480, <8 x i64> %1479, 1
  %1482 = extractvalue { <8 x ptr>, <8 x i64> } %33, 0
  %1483 = extractvalue { <8 x ptr>, <8 x i64> } %1481, 1
  %1484 = extractelement <8 x ptr> %1482, i32 0
  %1485 = extractelement <8 x i64> %1483, i32 %1475
  %1486 = zext i32 %1475 to i64
  %1487 = mul i64 %1486, 8
  %1488 = sub i64 %1485, %1487
  %1489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1468)
  %1490 = select i1 %1489, i64 %1488, i64 0
  %private.contiguous.address538 = getelementptr i8, ptr %1484, i64 %1490
  %private.contiguous.load539 = load <8 x i64>, ptr %private.contiguous.address538, align 8
  %1491 = select <8 x i1> %1468, <8 x i64> %private.contiguous.load539, <8 x i64> zeroinitializer
  %1492 = load <8 x i64>, ptr %.slot168, align 64
  %1493 = select <8 x i1> %1468, <8 x i64> %1491, <8 x i64> %1492
  store <8 x i64> %1493, ptr %.slot168, align 64
  %1494 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1470)
  %1495 = bitcast <8 x i1> %1470 to i8
  %1496 = call i8 @llvm.cttz.i8(i8 %1495, i1 false)
  %1497 = zext i8 %1496 to i32
  %1498 = select i1 %1494, i32 %1497, i32 0
  %1499 = load <8 x i64>, ptr %.slot168, align 64
  %1500 = select <8 x i1> %1470, <8 x i64> zeroinitializer, <8 x i64> %1499
  store <8 x i64> %1500, ptr %.slot168, align 64
  br label %direct.schedule.97

direct.schedule.97:                               ; preds = %direct.schedule.95
  %.state540 = load <8 x i64>, ptr %.slot168, align 64
  %.spill.load541 = load <8 x i64>, ptr %.spill107, align 64
  %1501 = add <8 x i64> %.state540, %.spill.load541
  %.spill.load542 = load <8 x i1>, ptr %.spill167, align 1
  %1502 = and <8 x i1> %119, %.spill.load542
  %1503 = xor <8 x i1> %.spill.load542, splat (i1 true)
  %1504 = and <8 x i1> %119, %1503
  %1505 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1502)
  %1506 = bitcast <8 x i1> %1502 to i8
  %1507 = call i8 @llvm.cttz.i8(i8 %1506, i1 false)
  %1508 = zext i8 %1507 to i32
  %1509 = select i1 %1505, i32 %1508, i32 0
  %tile_snapshot.spill.load543 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill165, align 64
  %1510 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load543, 0
  %1511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load543, 1
  %.state544 = load <8 x i64>, ptr %.slot166, align 64
  %1512 = mul <8 x i64> %.state544, splat (i64 64)
  %1513 = add <8 x i64> %1511, %1512
  %1514 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1510, 0
  %1515 = insertvalue { <8 x ptr>, <8 x i64> } %1514, <8 x i64> %1513, 1
  %1516 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %1517 = extractvalue { <8 x ptr>, <8 x i64> } %1515, 1
  %1518 = extractelement <8 x ptr> %1516, i32 0
  %1519 = extractelement <8 x i64> %1517, i32 %1509
  %1520 = zext i32 %1509 to i64
  %1521 = mul i64 %1520, 8
  %1522 = sub i64 %1519, %1521
  %1523 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1502)
  %1524 = select i1 %1523, i64 %1522, i64 0
  %private.contiguous.address545 = getelementptr i8, ptr %1518, i64 %1524
  %private.contiguous.preserve546 = load <8 x i64>, ptr %private.contiguous.address545, align 8
  %1525 = select <8 x i1> %1502, <8 x i64> %1501, <8 x i64> %private.contiguous.preserve546
  store <8 x i64> %1525, ptr %private.contiguous.address545, align 8
  %1526 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1504)
  %1527 = bitcast <8 x i1> %1504 to i8
  %1528 = call i8 @llvm.cttz.i8(i8 %1527, i1 false)
  %1529 = zext i8 %1528 to i32
  %1530 = select i1 %1526, i32 %1529, i32 0
  br label %direct.schedule.99

direct.schedule.99:                               ; preds = %direct.schedule.97
  %.state547 = load <8 x i64>, ptr %.slot166, align 64
  %1531 = add <8 x i64> %.state547, splat (i64 1)
  %1532 = load <8 x i64>, ptr %.slot166, align 64
  %1533 = select <8 x i1> %119, <8 x i64> %1531, <8 x i64> %1532
  store <8 x i64> %1533, ptr %.slot166, align 64
  br label %direct.schedule.94

direct.schedule.100:                              ; preds = %direct.false534
  %1534 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill169, align 64
  %1535 = extractvalue { <8 x ptr>, <8 x i64> } %37, 0
  %1536 = extractvalue { <8 x ptr>, <8 x i64> } %1534, 0
  %1537 = select <8 x i1> %119, <8 x ptr> %1535, <8 x ptr> %1536
  %1538 = extractvalue { <8 x ptr>, <8 x i64> } %37, 1
  %1539 = extractvalue { <8 x ptr>, <8 x i64> } %1534, 1
  %1540 = select <8 x i1> %119, <8 x i64> %1538, <8 x i64> %1539
  %1541 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1537, 0
  %1542 = insertvalue { <8 x ptr>, <8 x i64> } %1541, <8 x i64> %1540, 1
  store { <8 x ptr>, <8 x i64> } %1542, ptr %tile_snapshot.spill169, align 64
  %1543 = load <8 x i64>, ptr %.slot170, align 64
  %1544 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1543
  store <8 x i64> %1544, ptr %.slot170, align 64
  br label %direct.schedule.101

direct.schedule.101:                              ; preds = %direct.schedule.106, %direct.schedule.100
  %.state548 = load <8 x i64>, ptr %.slot170, align 64
  %1545 = icmp slt <8 x i64> %.state548, splat (i64 1)
  %1546 = extractelement <8 x i1> %1545, i32 0
  br i1 %1546, label %direct.true549, label %direct.false550

direct.schedule.102:                              ; preds = %direct.true549
  %.state551 = load <8 x i64>, ptr %.slot170, align 64
  %1547 = select <8 x i1> %119, <8 x i64> %.state551, <8 x i64> zeroinitializer
  %1548 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1549 = srem <8 x i64> %1547, %1548
  %1550 = mul <8 x i64> %1549, splat (i64 8)
  %.spill.load552 = load <8 x i64>, ptr %.spill, align 64
  %1551 = add <8 x i64> %1550, %.spill.load552
  %1552 = icmp slt <8 x i64> %1551, splat (i64 2)
  %1553 = load <8 x i1>, ptr %.spill171, align 1
  %1554 = select <8 x i1> %119, <8 x i1> %1552, <8 x i1> %1553
  store <8 x i1> %1554, ptr %.spill171, align 1
  %1555 = add <8 x i64> zeroinitializer, %1549
  %1556 = and <8 x i1> %119, %1552
  %1557 = xor <8 x i1> %1552, splat (i1 true)
  %1558 = and <8 x i1> %119, %1557
  %1559 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1556)
  %1560 = bitcast <8 x i1> %1556 to i8
  %1561 = call i8 @llvm.cttz.i8(i8 %1560, i1 false)
  %1562 = zext i8 %1561 to i32
  %1563 = select i1 %1559, i32 %1562, i32 0
  %tile_snapshot.spill.load553 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill165, align 64
  %1564 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load553, 0
  %1565 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load553, 1
  %1566 = mul <8 x i64> %1555, splat (i64 64)
  %1567 = add <8 x i64> %1565, %1566
  %1568 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1564, 0
  %1569 = insertvalue { <8 x ptr>, <8 x i64> } %1568, <8 x i64> %1567, 1
  %1570 = extractvalue { <8 x ptr>, <8 x i64> } %35, 0
  %1571 = extractvalue { <8 x ptr>, <8 x i64> } %1569, 1
  %1572 = extractelement <8 x ptr> %1570, i32 0
  %1573 = extractelement <8 x i64> %1571, i32 %1563
  %1574 = zext i32 %1563 to i64
  %1575 = mul i64 %1574, 8
  %1576 = sub i64 %1573, %1575
  %1577 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1556)
  %1578 = select i1 %1577, i64 %1576, i64 0
  %private.contiguous.address554 = getelementptr i8, ptr %1572, i64 %1578
  %private.contiguous.load555 = load <8 x i64>, ptr %private.contiguous.address554, align 8
  %1579 = select <8 x i1> %1556, <8 x i64> %private.contiguous.load555, <8 x i64> zeroinitializer
  %1580 = load <8 x i64>, ptr %.slot172, align 64
  %1581 = select <8 x i1> %1556, <8 x i64> %1579, <8 x i64> %1580
  store <8 x i64> %1581, ptr %.slot172, align 64
  %1582 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1558)
  %1583 = bitcast <8 x i1> %1558 to i8
  %1584 = call i8 @llvm.cttz.i8(i8 %1583, i1 false)
  %1585 = zext i8 %1584 to i32
  %1586 = select i1 %1582, i32 %1585, i32 0
  %1587 = load <8 x i64>, ptr %.slot172, align 64
  %1588 = select <8 x i1> %1558, <8 x i64> zeroinitializer, <8 x i64> %1587
  store <8 x i64> %1588, ptr %.slot172, align 64
  br label %direct.schedule.104

direct.schedule.104:                              ; preds = %direct.schedule.102
  %.state556 = load <8 x i64>, ptr %.slot172, align 64
  %1589 = add <8 x i64> %.state556, splat (i64 35)
  %.spill.load557 = load <8 x i1>, ptr %.spill171, align 1
  %1590 = and <8 x i1> %119, %.spill.load557
  %1591 = xor <8 x i1> %.spill.load557, splat (i1 true)
  %1592 = and <8 x i1> %119, %1591
  %1593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1590)
  %1594 = bitcast <8 x i1> %1590 to i8
  %1595 = call i8 @llvm.cttz.i8(i8 %1594, i1 false)
  %1596 = zext i8 %1595 to i32
  %1597 = select i1 %1593, i32 %1596, i32 0
  %tile_snapshot.spill.load558 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill169, align 64
  %1598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load558, 0
  %1599 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load558, 1
  %.state559 = load <8 x i64>, ptr %.slot170, align 64
  %1600 = mul <8 x i64> %.state559, splat (i64 64)
  %1601 = add <8 x i64> %1599, %1600
  %1602 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1598, 0
  %1603 = insertvalue { <8 x ptr>, <8 x i64> } %1602, <8 x i64> %1601, 1
  %1604 = extractvalue { <8 x ptr>, <8 x i64> } %37, 0
  %1605 = extractvalue { <8 x ptr>, <8 x i64> } %1603, 1
  %1606 = extractelement <8 x ptr> %1604, i32 0
  %1607 = extractelement <8 x i64> %1605, i32 %1597
  %1608 = zext i32 %1597 to i64
  %1609 = mul i64 %1608, 8
  %1610 = sub i64 %1607, %1609
  %1611 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1590)
  %1612 = select i1 %1611, i64 %1610, i64 0
  %private.contiguous.address560 = getelementptr i8, ptr %1606, i64 %1612
  %private.contiguous.preserve561 = load <8 x i64>, ptr %private.contiguous.address560, align 8
  %1613 = select <8 x i1> %1590, <8 x i64> %1589, <8 x i64> %private.contiguous.preserve561
  store <8 x i64> %1613, ptr %private.contiguous.address560, align 8
  %1614 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1592)
  %1615 = bitcast <8 x i1> %1592 to i8
  %1616 = call i8 @llvm.cttz.i8(i8 %1615, i1 false)
  %1617 = zext i8 %1616 to i32
  %1618 = select i1 %1614, i32 %1617, i32 0
  br label %direct.schedule.106

direct.schedule.106:                              ; preds = %direct.schedule.104
  %.state562 = load <8 x i64>, ptr %.slot170, align 64
  %1619 = add <8 x i64> %.state562, splat (i64 1)
  %1620 = load <8 x i64>, ptr %.slot170, align 64
  %1621 = select <8 x i1> %119, <8 x i64> %1619, <8 x i64> %1620
  store <8 x i64> %1621, ptr %.slot170, align 64
  br label %direct.schedule.101

direct.schedule.107:                              ; preds = %direct.false550
  %1622 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill173, align 64
  %1623 = extractvalue { <8 x ptr>, <8 x i64> } %39, 0
  %1624 = extractvalue { <8 x ptr>, <8 x i64> } %1622, 0
  %1625 = select <8 x i1> %119, <8 x ptr> %1623, <8 x ptr> %1624
  %1626 = extractvalue { <8 x ptr>, <8 x i64> } %39, 1
  %1627 = extractvalue { <8 x ptr>, <8 x i64> } %1622, 1
  %1628 = select <8 x i1> %119, <8 x i64> %1626, <8 x i64> %1627
  %1629 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1625, 0
  %1630 = insertvalue { <8 x ptr>, <8 x i64> } %1629, <8 x i64> %1628, 1
  store { <8 x ptr>, <8 x i64> } %1630, ptr %tile_snapshot.spill173, align 64
  %1631 = load <8 x i64>, ptr %.slot174, align 64
  %1632 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1631
  store <8 x i64> %1632, ptr %.slot174, align 64
  br label %direct.schedule.108

direct.schedule.108:                              ; preds = %direct.schedule.113, %direct.schedule.107
  %.state563 = load <8 x i64>, ptr %.slot174, align 64
  %1633 = icmp slt <8 x i64> %.state563, splat (i64 1)
  %1634 = extractelement <8 x i1> %1633, i32 0
  br i1 %1634, label %direct.true564, label %direct.false565

direct.schedule.109:                              ; preds = %direct.true564
  %.state566 = load <8 x i64>, ptr %.slot174, align 64
  %1635 = select <8 x i1> %119, <8 x i64> %.state566, <8 x i64> zeroinitializer
  %1636 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %1637 = srem <8 x i64> %1635, %1636
  %1638 = mul <8 x i64> %1637, splat (i64 8)
  %.spill.load567 = load <8 x i64>, ptr %.spill, align 64
  %1639 = add <8 x i64> %1638, %.spill.load567
  %1640 = icmp slt <8 x i64> %1639, splat (i64 2)
  %1641 = load <8 x i1>, ptr %.spill175, align 1
  %1642 = select <8 x i1> %119, <8 x i1> %1640, <8 x i1> %1641
  store <8 x i1> %1642, ptr %.spill175, align 1
  %1643 = add <8 x i64> zeroinitializer, %1637
  %1644 = and <8 x i1> %119, %1640
  %1645 = xor <8 x i1> %1640, splat (i1 true)
  %1646 = and <8 x i1> %119, %1645
  %1647 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1644)
  %1648 = bitcast <8 x i1> %1644 to i8
  %1649 = call i8 @llvm.cttz.i8(i8 %1648, i1 false)
  %1650 = zext i8 %1649 to i32
  %1651 = select i1 %1647, i32 %1650, i32 0
  %tile_snapshot.spill.load568 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill169, align 64
  %1652 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load568, 0
  %1653 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load568, 1
  %1654 = mul <8 x i64> %1643, splat (i64 64)
  %1655 = add <8 x i64> %1653, %1654
  %1656 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1652, 0
  %1657 = insertvalue { <8 x ptr>, <8 x i64> } %1656, <8 x i64> %1655, 1
  %1658 = extractvalue { <8 x ptr>, <8 x i64> } %37, 0
  %1659 = extractvalue { <8 x ptr>, <8 x i64> } %1657, 1
  %1660 = extractelement <8 x ptr> %1658, i32 0
  %1661 = extractelement <8 x i64> %1659, i32 %1651
  %1662 = zext i32 %1651 to i64
  %1663 = mul i64 %1662, 8
  %1664 = sub i64 %1661, %1663
  %1665 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1644)
  %1666 = select i1 %1665, i64 %1664, i64 0
  %private.contiguous.address569 = getelementptr i8, ptr %1660, i64 %1666
  %private.contiguous.load570 = load <8 x i64>, ptr %private.contiguous.address569, align 8
  %1667 = select <8 x i1> %1644, <8 x i64> %private.contiguous.load570, <8 x i64> zeroinitializer
  %1668 = load <8 x i64>, ptr %.slot176, align 64
  %1669 = select <8 x i1> %1644, <8 x i64> %1667, <8 x i64> %1668
  store <8 x i64> %1669, ptr %.slot176, align 64
  %1670 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1646)
  %1671 = bitcast <8 x i1> %1646 to i8
  %1672 = call i8 @llvm.cttz.i8(i8 %1671, i1 false)
  %1673 = zext i8 %1672 to i32
  %1674 = select i1 %1670, i32 %1673, i32 0
  %1675 = load <8 x i64>, ptr %.slot176, align 64
  %1676 = select <8 x i1> %1646, <8 x i64> zeroinitializer, <8 x i64> %1675
  store <8 x i64> %1676, ptr %.slot176, align 64
  br label %direct.schedule.111

direct.schedule.111:                              ; preds = %direct.schedule.109
  %.state571 = load <8 x i64>, ptr %.slot176, align 64
  %1677 = sub <8 x i64> %.state571, splat (i64 3)
  %.spill.load572 = load <8 x i1>, ptr %.spill175, align 1
  %1678 = and <8 x i1> %119, %.spill.load572
  %1679 = xor <8 x i1> %.spill.load572, splat (i1 true)
  %1680 = and <8 x i1> %119, %1679
  %1681 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1678)
  %1682 = bitcast <8 x i1> %1678 to i8
  %1683 = call i8 @llvm.cttz.i8(i8 %1682, i1 false)
  %1684 = zext i8 %1683 to i32
  %1685 = select i1 %1681, i32 %1684, i32 0
  %tile_snapshot.spill.load573 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill173, align 64
  %1686 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load573, 0
  %1687 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load573, 1
  %.state574 = load <8 x i64>, ptr %.slot174, align 64
  %1688 = mul <8 x i64> %.state574, splat (i64 64)
  %1689 = add <8 x i64> %1687, %1688
  %1690 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1686, 0
  %1691 = insertvalue { <8 x ptr>, <8 x i64> } %1690, <8 x i64> %1689, 1
  %1692 = extractvalue { <8 x ptr>, <8 x i64> } %39, 0
  %1693 = extractvalue { <8 x ptr>, <8 x i64> } %1691, 1
  %1694 = extractelement <8 x ptr> %1692, i32 0
  %1695 = extractelement <8 x i64> %1693, i32 %1685
  %1696 = zext i32 %1685 to i64
  %1697 = mul i64 %1696, 8
  %1698 = sub i64 %1695, %1697
  %1699 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1678)
  %1700 = select i1 %1699, i64 %1698, i64 0
  %private.contiguous.address575 = getelementptr i8, ptr %1694, i64 %1700
  %private.contiguous.preserve576 = load <8 x i64>, ptr %private.contiguous.address575, align 8
  %1701 = select <8 x i1> %1678, <8 x i64> %1677, <8 x i64> %private.contiguous.preserve576
  store <8 x i64> %1701, ptr %private.contiguous.address575, align 8
  %1702 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1680)
  %1703 = bitcast <8 x i1> %1680 to i8
  %1704 = call i8 @llvm.cttz.i8(i8 %1703, i1 false)
  %1705 = zext i8 %1704 to i32
  %1706 = select i1 %1702, i32 %1705, i32 0
  br label %direct.schedule.113

direct.schedule.113:                              ; preds = %direct.schedule.111
  %.state577 = load <8 x i64>, ptr %.slot174, align 64
  %1707 = add <8 x i64> %.state577, splat (i64 1)
  %1708 = load <8 x i64>, ptr %.slot174, align 64
  %1709 = select <8 x i1> %119, <8 x i64> %1707, <8 x i64> %1708
  store <8 x i64> %1709, ptr %.slot174, align 64
  br label %direct.schedule.108

direct.schedule.114:                              ; preds = %direct.false565
  %1710 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill177, align 64
  %1711 = extractvalue { <8 x ptr>, <8 x i64> } %41, 0
  %1712 = extractvalue { <8 x ptr>, <8 x i64> } %1710, 0
  %1713 = select <8 x i1> %119, <8 x ptr> %1711, <8 x ptr> %1712
  %1714 = extractvalue { <8 x ptr>, <8 x i64> } %41, 1
  %1715 = extractvalue { <8 x ptr>, <8 x i64> } %1710, 1
  %1716 = select <8 x i1> %119, <8 x i64> %1714, <8 x i64> %1715
  %1717 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1713, 0
  %1718 = insertvalue { <8 x ptr>, <8 x i64> } %1717, <8 x i64> %1716, 1
  store { <8 x ptr>, <8 x i64> } %1718, ptr %tile_snapshot.spill177, align 64
  %1719 = load <8 x i64>, ptr %.slot178, align 64
  %1720 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1719
  store <8 x i64> %1720, ptr %.slot178, align 64
  br label %direct.schedule.115

direct.schedule.115:                              ; preds = %direct.schedule.122, %direct.schedule.114
  %.state578 = load <8 x i64>, ptr %.slot178, align 64
  %1721 = icmp slt <8 x i64> %.state578, splat (i64 10)
  %1722 = extractelement <8 x i1> %1721, i32 0
  br i1 %1722, label %direct.true579, label %direct.false580

direct.schedule.116:                              ; preds = %direct.true579
  %.state581 = load <8 x i64>, ptr %.slot178, align 64
  %1723 = select <8 x i1> %119, <8 x i64> %.state581, <8 x i64> zeroinitializer
  %1724 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1725 = srem <8 x i64> %1723, %1724
  %1726 = load <8 x i64>, ptr %.spill179, align 64
  %1727 = select <8 x i1> %119, <8 x i64> %1725, <8 x i64> %1726
  store <8 x i64> %1727, ptr %.spill179, align 64
  %.state582 = load <8 x i64>, ptr %.slot178, align 64
  %1728 = select <8 x i1> %119, <8 x i64> %.state582, <8 x i64> zeroinitializer
  %1729 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1730 = sdiv <8 x i64> %1728, %1729
  %1731 = select <8 x i1> %119, <8 x i64> %1730, <8 x i64> zeroinitializer
  %1732 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1733 = srem <8 x i64> %1731, %1732
  %1734 = mul <8 x i64> %1733, splat (i64 8)
  %.spill.load583 = load <8 x i64>, ptr %.spill, align 64
  %1735 = add <8 x i64> %1734, %.spill.load583
  %1736 = icmp slt <8 x i64> %1735, splat (i64 33)
  %1737 = load <8 x i1>, ptr %.spill180, align 1
  %1738 = select <8 x i1> %119, <8 x i1> %1736, <8 x i1> %1737
  store <8 x i1> %1738, ptr %.spill180, align 1
  %1739 = add <8 x i64> zeroinitializer, %1733
  %1740 = and <8 x i1> %119, %1736
  %1741 = xor <8 x i1> %1736, splat (i1 true)
  %1742 = and <8 x i1> %119, %1741
  %1743 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1740)
  %1744 = bitcast <8 x i1> %1740 to i8
  %1745 = call i8 @llvm.cttz.i8(i8 %1744, i1 false)
  %1746 = zext i8 %1745 to i32
  %1747 = select i1 %1743, i32 %1746, i32 0
  %tile_snapshot.spill.load584 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill159, align 64
  %1748 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load584, 0
  %1749 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load584, 1
  %1750 = mul <8 x i64> %1739, splat (i64 64)
  %1751 = add <8 x i64> %1749, %1750
  %1752 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1748, 0
  %1753 = insertvalue { <8 x ptr>, <8 x i64> } %1752, <8 x i64> %1751, 1
  %1754 = extractvalue { <8 x ptr>, <8 x i64> } %31, 0
  %1755 = extractvalue { <8 x ptr>, <8 x i64> } %1753, 1
  %1756 = extractelement <8 x ptr> %1754, i32 0
  %1757 = extractelement <8 x i64> %1755, i32 %1747
  %1758 = zext i32 %1747 to i64
  %1759 = mul i64 %1758, 8
  %1760 = sub i64 %1757, %1759
  %1761 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1740)
  %1762 = select i1 %1761, i64 %1760, i64 0
  %private.contiguous.address585 = getelementptr i8, ptr %1756, i64 %1762
  %private.contiguous.load586 = load <8 x i64>, ptr %private.contiguous.address585, align 8
  %1763 = select <8 x i1> %1740, <8 x i64> %private.contiguous.load586, <8 x i64> zeroinitializer
  %1764 = load <8 x i64>, ptr %.slot181, align 64
  %1765 = select <8 x i1> %1740, <8 x i64> %1763, <8 x i64> %1764
  store <8 x i64> %1765, ptr %.slot181, align 64
  %1766 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1742)
  %1767 = bitcast <8 x i1> %1742 to i8
  %1768 = call i8 @llvm.cttz.i8(i8 %1767, i1 false)
  %1769 = zext i8 %1768 to i32
  %1770 = select i1 %1766, i32 %1769, i32 0
  %1771 = load <8 x i64>, ptr %.slot181, align 64
  %1772 = select <8 x i1> %1742, <8 x i64> zeroinitializer, <8 x i64> %1771
  store <8 x i64> %1772, ptr %.slot181, align 64
  br label %direct.schedule.118

direct.schedule.118:                              ; preds = %direct.schedule.116
  %.spill.load587 = load <8 x i64>, ptr %.spill179, align 64
  %1773 = select <8 x i1> %119, <8 x i64> %.spill.load587, <8 x i64> zeroinitializer
  %1774 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %1775 = sdiv <8 x i64> %1773, %1774
  %1776 = add <8 x i64> zeroinitializer, %1775
  %.spill.load588 = load <8 x i64>, ptr %.spill179, align 64
  %1777 = select <8 x i1> %119, <8 x i64> %.spill.load588, <8 x i64> zeroinitializer
  %1778 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %1779 = srem <8 x i64> %1777, %1778
  %1780 = load <8 x i64>, ptr %.spill182, align 64
  %1781 = select <8 x i1> %119, <8 x i64> %1779, <8 x i64> %1780
  store <8 x i64> %1781, ptr %.spill182, align 64
  %.spill.load589 = load <8 x i64>, ptr %.spill, align 64
  %1782 = icmp eq <8 x i64> %.spill.load589, %1779
  %1783 = and <8 x i1> %119, %1782
  %1784 = xor <8 x i1> %1782, splat (i1 true)
  %1785 = and <8 x i1> %119, %1784
  %1786 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1783)
  %1787 = bitcast <8 x i1> %1783 to i8
  %1788 = call i8 @llvm.cttz.i8(i8 %1787, i1 false)
  %1789 = zext i8 %1788 to i32
  %1790 = select i1 %1786, i32 %1789, i32 0
  %tile_snapshot.spill.load590 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill173, align 64
  %1791 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load590, 0
  %1792 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load590, 1
  %1793 = mul <8 x i64> %1776, splat (i64 64)
  %1794 = add <8 x i64> %1792, %1793
  %1795 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1791, 0
  %1796 = insertvalue { <8 x ptr>, <8 x i64> } %1795, <8 x i64> %1794, 1
  %1797 = extractvalue { <8 x ptr>, <8 x i64> } %39, 0
  %1798 = extractvalue { <8 x ptr>, <8 x i64> } %1796, 1
  %1799 = extractelement <8 x ptr> %1797, i32 0
  %1800 = extractelement <8 x i64> %1798, i32 %1790
  %1801 = zext i32 %1790 to i64
  %1802 = mul i64 %1801, 8
  %1803 = sub i64 %1800, %1802
  %1804 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1783)
  %1805 = select i1 %1804, i64 %1803, i64 0
  %private.contiguous.address591 = getelementptr i8, ptr %1799, i64 %1805
  %private.contiguous.load592 = load <8 x i64>, ptr %private.contiguous.address591, align 8
  %1806 = select <8 x i1> %1783, <8 x i64> %private.contiguous.load592, <8 x i64> zeroinitializer
  %1807 = load <8 x i64>, ptr %.slot183, align 64
  %1808 = select <8 x i1> %1783, <8 x i64> %1806, <8 x i64> %1807
  store <8 x i64> %1808, ptr %.slot183, align 64
  %1809 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1785)
  %1810 = bitcast <8 x i1> %1785 to i8
  %1811 = call i8 @llvm.cttz.i8(i8 %1810, i1 false)
  %1812 = zext i8 %1811 to i32
  %1813 = select i1 %1809, i32 %1812, i32 0
  %1814 = load <8 x i64>, ptr %.slot183, align 64
  %1815 = select <8 x i1> %1785, <8 x i64> zeroinitializer, <8 x i64> %1814
  store <8 x i64> %1815, ptr %.slot183, align 64
  br label %direct.schedule.120

direct.schedule.120:                              ; preds = %direct.schedule.118
  %.spill.load593 = load <8 x i64>, ptr %.spill182, align 64
  %1816 = trunc <8 x i64> %.spill.load593 to <8 x i32>
  %.state594 = load <8 x i64>, ptr %.slot183, align 64
  %1817 = extractelement <8 x i32> %1816, i64 0
  %1818 = icmp ult i32 %1817, 8
  %1819 = select i1 %1818, i32 %1817, i32 0
  %1820 = extractelement <8 x i1> %119, i32 %1819
  %1821 = extractelement <8 x i1> %119, i64 0
  %1822 = and i1 %1818, %1820
  %1823 = and i1 %1821, %1822
  %1824 = extractelement <8 x i64> %.state594, i32 %1819
  %1825 = select i1 %1823, i64 %1824, i64 0
  %1826 = insertelement <8 x i64> poison, i64 %1825, i64 0
  %1827 = xor i1 %1823, true
  %1828 = and i1 %1821, %1827
  %1829 = insertelement <8 x i1> poison, i1 %1828, i64 0
  %1830 = extractelement <8 x i32> %1816, i64 1
  %1831 = icmp ult i32 %1830, 8
  %1832 = select i1 %1831, i32 %1830, i32 0
  %1833 = extractelement <8 x i1> %119, i32 %1832
  %1834 = extractelement <8 x i1> %119, i64 1
  %1835 = and i1 %1831, %1833
  %1836 = and i1 %1834, %1835
  %1837 = extractelement <8 x i64> %.state594, i32 %1832
  %1838 = select i1 %1836, i64 %1837, i64 0
  %1839 = insertelement <8 x i64> %1826, i64 %1838, i64 1
  %1840 = xor i1 %1836, true
  %1841 = and i1 %1834, %1840
  %1842 = insertelement <8 x i1> %1829, i1 %1841, i64 1
  %1843 = extractelement <8 x i32> %1816, i64 2
  %1844 = icmp ult i32 %1843, 8
  %1845 = select i1 %1844, i32 %1843, i32 0
  %1846 = extractelement <8 x i1> %119, i32 %1845
  %1847 = extractelement <8 x i1> %119, i64 2
  %1848 = and i1 %1844, %1846
  %1849 = and i1 %1847, %1848
  %1850 = extractelement <8 x i64> %.state594, i32 %1845
  %1851 = select i1 %1849, i64 %1850, i64 0
  %1852 = insertelement <8 x i64> %1839, i64 %1851, i64 2
  %1853 = xor i1 %1849, true
  %1854 = and i1 %1847, %1853
  %1855 = insertelement <8 x i1> %1842, i1 %1854, i64 2
  %1856 = extractelement <8 x i32> %1816, i64 3
  %1857 = icmp ult i32 %1856, 8
  %1858 = select i1 %1857, i32 %1856, i32 0
  %1859 = extractelement <8 x i1> %119, i32 %1858
  %1860 = extractelement <8 x i1> %119, i64 3
  %1861 = and i1 %1857, %1859
  %1862 = and i1 %1860, %1861
  %1863 = extractelement <8 x i64> %.state594, i32 %1858
  %1864 = select i1 %1862, i64 %1863, i64 0
  %1865 = insertelement <8 x i64> %1852, i64 %1864, i64 3
  %1866 = xor i1 %1862, true
  %1867 = and i1 %1860, %1866
  %1868 = insertelement <8 x i1> %1855, i1 %1867, i64 3
  %1869 = extractelement <8 x i32> %1816, i64 4
  %1870 = icmp ult i32 %1869, 8
  %1871 = select i1 %1870, i32 %1869, i32 0
  %1872 = extractelement <8 x i1> %119, i32 %1871
  %1873 = extractelement <8 x i1> %119, i64 4
  %1874 = and i1 %1870, %1872
  %1875 = and i1 %1873, %1874
  %1876 = extractelement <8 x i64> %.state594, i32 %1871
  %1877 = select i1 %1875, i64 %1876, i64 0
  %1878 = insertelement <8 x i64> %1865, i64 %1877, i64 4
  %1879 = xor i1 %1875, true
  %1880 = and i1 %1873, %1879
  %1881 = insertelement <8 x i1> %1868, i1 %1880, i64 4
  %1882 = extractelement <8 x i32> %1816, i64 5
  %1883 = icmp ult i32 %1882, 8
  %1884 = select i1 %1883, i32 %1882, i32 0
  %1885 = extractelement <8 x i1> %119, i32 %1884
  %1886 = extractelement <8 x i1> %119, i64 5
  %1887 = and i1 %1883, %1885
  %1888 = and i1 %1886, %1887
  %1889 = extractelement <8 x i64> %.state594, i32 %1884
  %1890 = select i1 %1888, i64 %1889, i64 0
  %1891 = insertelement <8 x i64> %1878, i64 %1890, i64 5
  %1892 = xor i1 %1888, true
  %1893 = and i1 %1886, %1892
  %1894 = insertelement <8 x i1> %1881, i1 %1893, i64 5
  %1895 = extractelement <8 x i32> %1816, i64 6
  %1896 = icmp ult i32 %1895, 8
  %1897 = select i1 %1896, i32 %1895, i32 0
  %1898 = extractelement <8 x i1> %119, i32 %1897
  %1899 = extractelement <8 x i1> %119, i64 6
  %1900 = and i1 %1896, %1898
  %1901 = and i1 %1899, %1900
  %1902 = extractelement <8 x i64> %.state594, i32 %1897
  %1903 = select i1 %1901, i64 %1902, i64 0
  %1904 = insertelement <8 x i64> %1891, i64 %1903, i64 6
  %1905 = xor i1 %1901, true
  %1906 = and i1 %1899, %1905
  %1907 = insertelement <8 x i1> %1894, i1 %1906, i64 6
  %1908 = extractelement <8 x i32> %1816, i64 7
  %1909 = icmp ult i32 %1908, 8
  %1910 = select i1 %1909, i32 %1908, i32 0
  %1911 = extractelement <8 x i1> %119, i32 %1910
  %1912 = extractelement <8 x i1> %119, i64 7
  %1913 = and i1 %1909, %1911
  %1914 = and i1 %1912, %1913
  %1915 = extractelement <8 x i64> %.state594, i32 %1910
  %1916 = select i1 %1914, i64 %1915, i64 0
  %1917 = insertelement <8 x i64> %1904, i64 %1916, i64 7
  %1918 = xor i1 %1914, true
  %1919 = and i1 %1912, %1918
  %1920 = insertelement <8 x i1> %1907, i1 %1919, i64 7
  %.state595 = load <8 x i64>, ptr %.slot181, align 64
  %1921 = icmp sle <8 x i64> %.state595, %1917
  %.spill.load596 = load <8 x i1>, ptr %.spill180, align 1
  %1922 = and <8 x i1> %119, %.spill.load596
  %1923 = xor <8 x i1> %.spill.load596, splat (i1 true)
  %1924 = and <8 x i1> %119, %1923
  %1925 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1922)
  %1926 = bitcast <8 x i1> %1922 to i8
  %1927 = call i8 @llvm.cttz.i8(i8 %1926, i1 false)
  %1928 = zext i8 %1927 to i32
  %1929 = select i1 %1925, i32 %1928, i32 0
  %tile_snapshot.spill.load597 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill177, align 64
  %1930 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load597, 0
  %1931 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load597, 1
  %.state598 = load <8 x i64>, ptr %.slot178, align 64
  %1932 = add <8 x i64> %1931, %.state598
  %1933 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1930, 0
  %1934 = insertvalue { <8 x ptr>, <8 x i64> } %1933, <8 x i64> %1932, 1
  %1935 = extractvalue { <8 x ptr>, <8 x i64> } %1934, 0
  %1936 = extractvalue { <8 x ptr>, <8 x i64> } %1934, 1
  %1937 = getelementptr i8, <8 x ptr> %1935, <8 x i64> %1936
  %1938 = zext <8 x i1> %1921 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %1938, <8 x ptr> align 1 %1937, <8 x i1> %1922)
  %1939 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1924)
  %1940 = bitcast <8 x i1> %1924 to i8
  %1941 = call i8 @llvm.cttz.i8(i8 %1940, i1 false)
  %1942 = zext i8 %1941 to i32
  %1943 = select i1 %1939, i32 %1942, i32 0
  br label %direct.schedule.122

direct.schedule.122:                              ; preds = %direct.schedule.120
  %.state599 = load <8 x i64>, ptr %.slot178, align 64
  %1944 = add <8 x i64> %.state599, splat (i64 1)
  %1945 = load <8 x i64>, ptr %.slot178, align 64
  %1946 = select <8 x i1> %119, <8 x i64> %1944, <8 x i64> %1945
  store <8 x i64> %1946, ptr %.slot178, align 64
  br label %direct.schedule.115

direct.schedule.123:                              ; preds = %direct.false580
  %1947 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill184, align 64
  %1948 = extractvalue { <8 x ptr>, <8 x i64> } %43, 0
  %1949 = extractvalue { <8 x ptr>, <8 x i64> } %1947, 0
  %1950 = select <8 x i1> %119, <8 x ptr> %1948, <8 x ptr> %1949
  %1951 = extractvalue { <8 x ptr>, <8 x i64> } %43, 1
  %1952 = extractvalue { <8 x ptr>, <8 x i64> } %1947, 1
  %1953 = select <8 x i1> %119, <8 x i64> %1951, <8 x i64> %1952
  %1954 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1950, 0
  %1955 = insertvalue { <8 x ptr>, <8 x i64> } %1954, <8 x i64> %1953, 1
  store { <8 x ptr>, <8 x i64> } %1955, ptr %tile_snapshot.spill184, align 64
  %1956 = load <8 x i64>, ptr %.slot185, align 64
  %1957 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %1956
  store <8 x i64> %1957, ptr %.slot185, align 64
  br label %direct.schedule.124

direct.schedule.124:                              ; preds = %direct.schedule.131, %direct.schedule.123
  %.state600 = load <8 x i64>, ptr %.slot185, align 64
  %1958 = icmp slt <8 x i64> %.state600, splat (i64 10)
  %1959 = extractelement <8 x i1> %1958, i32 0
  br i1 %1959, label %direct.true601, label %direct.false602

direct.schedule.125:                              ; preds = %direct.true601
  %.state603 = load <8 x i64>, ptr %.slot185, align 64
  %1960 = select <8 x i1> %119, <8 x i64> %.state603, <8 x i64> zeroinitializer
  %1961 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1962 = srem <8 x i64> %1960, %1961
  %1963 = load <8 x i64>, ptr %.spill186, align 64
  %1964 = select <8 x i1> %119, <8 x i64> %1962, <8 x i64> %1963
  store <8 x i64> %1964, ptr %.spill186, align 64
  %.state604 = load <8 x i64>, ptr %.slot185, align 64
  %1965 = select <8 x i1> %119, <8 x i64> %.state604, <8 x i64> zeroinitializer
  %1966 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %1967 = sdiv <8 x i64> %1965, %1966
  %1968 = select <8 x i1> %119, <8 x i64> %1967, <8 x i64> zeroinitializer
  %1969 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %1970 = srem <8 x i64> %1968, %1969
  %1971 = mul <8 x i64> %1970, splat (i64 8)
  %.spill.load605 = load <8 x i64>, ptr %.spill, align 64
  %1972 = add <8 x i64> %1971, %.spill.load605
  %1973 = icmp slt <8 x i64> %1972, splat (i64 33)
  %1974 = load <8 x i1>, ptr %.spill187, align 1
  %1975 = select <8 x i1> %119, <8 x i1> %1973, <8 x i1> %1974
  store <8 x i1> %1975, ptr %.spill187, align 1
  %1976 = add <8 x i64> zeroinitializer, %1970
  %1977 = load <8 x i64>, ptr %.spill188, align 64
  %1978 = select <8 x i1> %119, <8 x i64> %1976, <8 x i64> %1977
  store <8 x i64> %1978, ptr %.spill188, align 64
  %1979 = and <8 x i1> %119, %1973
  %1980 = xor <8 x i1> %1973, splat (i1 true)
  %1981 = and <8 x i1> %119, %1980
  %1982 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1979)
  %1983 = bitcast <8 x i1> %1979 to i8
  %1984 = call i8 @llvm.cttz.i8(i8 %1983, i1 false)
  %1985 = zext i8 %1984 to i32
  %1986 = select i1 %1982, i32 %1985, i32 0
  %tile_snapshot.spill.load606 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill153, align 64
  %1987 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load606, 0
  %1988 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load606, 1
  %1989 = add <8 x i64> %1988, %1976
  %1990 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1987, 0
  %1991 = insertvalue { <8 x ptr>, <8 x i64> } %1990, <8 x i64> %1989, 1
  %1992 = extractvalue { <8 x ptr>, <8 x i64> } %1991, 0
  %1993 = extractvalue { <8 x ptr>, <8 x i64> } %1991, 1
  %1994 = getelementptr i8, <8 x ptr> %1992, <8 x i64> %1993
  %1995 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1994, <8 x i1> %1979, <8 x i8> zeroinitializer)
  %1996 = icmp ne <8 x i8> %1995, zeroinitializer
  %1997 = load <8 x i1>, ptr %.slot189, align 1
  %1998 = select <8 x i1> %1979, <8 x i1> %1996, <8 x i1> %1997
  store <8 x i1> %1998, ptr %.slot189, align 1
  %1999 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1981)
  %2000 = bitcast <8 x i1> %1981 to i8
  %2001 = call i8 @llvm.cttz.i8(i8 %2000, i1 false)
  %2002 = zext i8 %2001 to i32
  %2003 = select i1 %1999, i32 %2002, i32 0
  %2004 = load <8 x i1>, ptr %.slot189, align 1
  %2005 = select <8 x i1> %1981, <8 x i1> zeroinitializer, <8 x i1> %2004
  store <8 x i1> %2005, ptr %.slot189, align 1
  br label %direct.schedule.127

direct.schedule.127:                              ; preds = %direct.schedule.125
  %.spill.load607 = load <8 x i64>, ptr %.spill188, align 64
  %2006 = mul <8 x i64> %.spill.load607, splat (i64 2)
  %.spill.load608 = load <8 x i64>, ptr %.spill186, align 64
  %2007 = add <8 x i64> %2006, %.spill.load608
  %.spill.load609 = load <8 x i1>, ptr %.spill187, align 1
  %2008 = and <8 x i1> %119, %.spill.load609
  %2009 = xor <8 x i1> %.spill.load609, splat (i1 true)
  %2010 = and <8 x i1> %119, %2009
  %2011 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2008)
  %2012 = bitcast <8 x i1> %2008 to i8
  %2013 = call i8 @llvm.cttz.i8(i8 %2012, i1 false)
  %2014 = zext i8 %2013 to i32
  %2015 = select i1 %2011, i32 %2014, i32 0
  %tile_snapshot.spill.load610 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill177, align 64
  %2016 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load610, 0
  %2017 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load610, 1
  %2018 = add <8 x i64> %2017, %2007
  %2019 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2016, 0
  %2020 = insertvalue { <8 x ptr>, <8 x i64> } %2019, <8 x i64> %2018, 1
  %2021 = extractvalue { <8 x ptr>, <8 x i64> } %2020, 0
  %2022 = extractvalue { <8 x ptr>, <8 x i64> } %2020, 1
  %2023 = getelementptr i8, <8 x ptr> %2021, <8 x i64> %2022
  %2024 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %2023, <8 x i1> %2008, <8 x i8> zeroinitializer)
  %2025 = icmp ne <8 x i8> %2024, zeroinitializer
  %2026 = load <8 x i1>, ptr %.slot190, align 1
  %2027 = select <8 x i1> %2008, <8 x i1> %2025, <8 x i1> %2026
  store <8 x i1> %2027, ptr %.slot190, align 1
  %2028 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2010)
  %2029 = bitcast <8 x i1> %2010 to i8
  %2030 = call i8 @llvm.cttz.i8(i8 %2029, i1 false)
  %2031 = zext i8 %2030 to i32
  %2032 = select i1 %2028, i32 %2031, i32 0
  %2033 = load <8 x i1>, ptr %.slot190, align 1
  %2034 = select <8 x i1> %2010, <8 x i1> zeroinitializer, <8 x i1> %2033
  store <8 x i1> %2034, ptr %.slot190, align 1
  br label %direct.schedule.129

direct.schedule.129:                              ; preds = %direct.schedule.127
  %.state611 = load <8 x i1>, ptr %.slot189, align 1
  %.state612 = load <8 x i1>, ptr %.slot190, align 1
  %2035 = and <8 x i1> %.state611, %.state612
  %.spill.load613 = load <8 x i1>, ptr %.spill187, align 1
  %2036 = and <8 x i1> %119, %.spill.load613
  %2037 = xor <8 x i1> %.spill.load613, splat (i1 true)
  %2038 = and <8 x i1> %119, %2037
  %2039 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2036)
  %2040 = bitcast <8 x i1> %2036 to i8
  %2041 = call i8 @llvm.cttz.i8(i8 %2040, i1 false)
  %2042 = zext i8 %2041 to i32
  %2043 = select i1 %2039, i32 %2042, i32 0
  %tile_snapshot.spill.load614 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill184, align 64
  %2044 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 0
  %2045 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load614, 1
  %.state615 = load <8 x i64>, ptr %.slot185, align 64
  %2046 = add <8 x i64> %2045, %.state615
  %2047 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2044, 0
  %2048 = insertvalue { <8 x ptr>, <8 x i64> } %2047, <8 x i64> %2046, 1
  %2049 = extractvalue { <8 x ptr>, <8 x i64> } %2048, 0
  %2050 = extractvalue { <8 x ptr>, <8 x i64> } %2048, 1
  %2051 = getelementptr i8, <8 x ptr> %2049, <8 x i64> %2050
  %2052 = zext <8 x i1> %2035 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %2052, <8 x ptr> align 1 %2051, <8 x i1> %2036)
  %2053 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2038)
  %2054 = bitcast <8 x i1> %2038 to i8
  %2055 = call i8 @llvm.cttz.i8(i8 %2054, i1 false)
  %2056 = zext i8 %2055 to i32
  %2057 = select i1 %2053, i32 %2056, i32 0
  br label %direct.schedule.131

direct.schedule.131:                              ; preds = %direct.schedule.129
  %.state616 = load <8 x i64>, ptr %.slot185, align 64
  %2058 = add <8 x i64> %.state616, splat (i64 1)
  %2059 = load <8 x i64>, ptr %.slot185, align 64
  %2060 = select <8 x i1> %119, <8 x i64> %2058, <8 x i64> %2059
  store <8 x i64> %2060, ptr %.slot185, align 64
  br label %direct.schedule.124

direct.schedule.132:                              ; preds = %direct.false602
  %2061 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill191, align 64
  %2062 = extractvalue { <8 x ptr>, <8 x i64> } %45, 0
  %2063 = extractvalue { <8 x ptr>, <8 x i64> } %2061, 0
  %2064 = select <8 x i1> %119, <8 x ptr> %2062, <8 x ptr> %2063
  %2065 = extractvalue { <8 x ptr>, <8 x i64> } %45, 1
  %2066 = extractvalue { <8 x ptr>, <8 x i64> } %2061, 1
  %2067 = select <8 x i1> %119, <8 x i64> %2065, <8 x i64> %2066
  %2068 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2064, 0
  %2069 = insertvalue { <8 x ptr>, <8 x i64> } %2068, <8 x i64> %2067, 1
  store { <8 x ptr>, <8 x i64> } %2069, ptr %tile_snapshot.spill191, align 64
  %2070 = load <8 x i64>, ptr %.slot192, align 64
  %2071 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %2070
  store <8 x i64> %2071, ptr %.slot192, align 64
  br label %direct.schedule.133

direct.schedule.133:                              ; preds = %direct.schedule.140, %direct.schedule.132
  %.state617 = load <8 x i64>, ptr %.slot192, align 64
  %2072 = icmp slt <8 x i64> %.state617, splat (i64 10)
  %2073 = extractelement <8 x i1> %2072, i32 0
  br i1 %2073, label %direct.true618, label %direct.false619

direct.schedule.134:                              ; preds = %direct.true618
  %.state620 = load <8 x i64>, ptr %.slot192, align 64
  %2074 = select <8 x i1> %119, <8 x i64> %.state620, <8 x i64> zeroinitializer
  %2075 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %2076 = srem <8 x i64> %2074, %2075
  %2077 = load <8 x i64>, ptr %.spill193, align 64
  %2078 = select <8 x i1> %119, <8 x i64> %2076, <8 x i64> %2077
  store <8 x i64> %2078, ptr %.spill193, align 64
  %.state621 = load <8 x i64>, ptr %.slot192, align 64
  %2079 = select <8 x i1> %119, <8 x i64> %.state621, <8 x i64> zeroinitializer
  %2080 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %2081 = sdiv <8 x i64> %2079, %2080
  %2082 = mul <8 x i64> %2076, splat (i64 8)
  %.spill.load622 = load <8 x i64>, ptr %.spill, align 64
  %2083 = add <8 x i64> %2082, %.spill.load622
  %2084 = icmp slt <8 x i64> %2083, splat (i64 33)
  %2085 = load <8 x i1>, ptr %.spill194, align 1
  %2086 = select <8 x i1> %119, <8 x i1> %2084, <8 x i1> %2085
  store <8 x i1> %2086, ptr %.spill194, align 1
  %2087 = select <8 x i1> %119, <8 x i64> %2081, <8 x i64> zeroinitializer
  %2088 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %2089 = srem <8 x i64> %2087, %2088
  %2090 = load <8 x i64>, ptr %.spill195, align 64
  %2091 = select <8 x i1> %119, <8 x i64> %2089, <8 x i64> %2090
  store <8 x i64> %2091, ptr %.spill195, align 64
  store i64 0, ptr %.spill196, align 4
  %2092 = add <8 x i64> zeroinitializer, %2076
  %2093 = mul <8 x i64> %2092, splat (i64 2)
  %2094 = add <8 x i64> %2093, %2089
  %2095 = and <8 x i1> %119, %2084
  %2096 = xor <8 x i1> %2084, splat (i1 true)
  %2097 = and <8 x i1> %119, %2096
  %2098 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2095)
  %2099 = bitcast <8 x i1> %2095 to i8
  %2100 = call i8 @llvm.cttz.i8(i8 %2099, i1 false)
  %2101 = zext i8 %2100 to i32
  %2102 = select i1 %2098, i32 %2101, i32 0
  %tile_snapshot.spill.load623 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill184, align 64
  %2103 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load623, 0
  %2104 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load623, 1
  %2105 = add <8 x i64> %2104, %2094
  %2106 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2103, 0
  %2107 = insertvalue { <8 x ptr>, <8 x i64> } %2106, <8 x i64> %2105, 1
  %2108 = extractvalue { <8 x ptr>, <8 x i64> } %2107, 0
  %2109 = extractvalue { <8 x ptr>, <8 x i64> } %2107, 1
  %2110 = getelementptr i8, <8 x ptr> %2108, <8 x i64> %2109
  %2111 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %2110, <8 x i1> %2095, <8 x i8> zeroinitializer)
  %2112 = icmp ne <8 x i8> %2111, zeroinitializer
  %2113 = load <8 x i1>, ptr %.slot197, align 1
  %2114 = select <8 x i1> %2095, <8 x i1> %2112, <8 x i1> %2113
  store <8 x i1> %2114, ptr %.slot197, align 1
  %2115 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2097)
  %2116 = bitcast <8 x i1> %2097 to i8
  %2117 = call i8 @llvm.cttz.i8(i8 %2116, i1 false)
  %2118 = zext i8 %2117 to i32
  %2119 = select i1 %2115, i32 %2118, i32 0
  %2120 = load <8 x i1>, ptr %.slot197, align 1
  %2121 = select <8 x i1> %2097, <8 x i1> zeroinitializer, <8 x i1> %2120
  store <8 x i1> %2121, ptr %.slot197, align 1
  br label %direct.schedule.136

direct.schedule.136:                              ; preds = %direct.schedule.134
  %.spill.load624 = load i64, ptr %.spill196, align 4
  %2122 = add i64 %.spill.load624, 0
  %2123 = mul i64 %2122, 1
  %2124 = add i64 %2123, 0
  %2125 = mul i64 %2124, 2
  %.splatinsert625 = insertelement <8 x i64> poison, i64 %2125, i64 0
  %.splat626 = shufflevector <8 x i64> %.splatinsert625, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load627 = load <8 x i64>, ptr %.spill195, align 64
  %2126 = add <8 x i64> %.splat626, %.spill.load627
  %2127 = mul <8 x i64> %2126, splat (i64 5)
  %.spill.load628 = load <8 x i64>, ptr %.spill193, align 64
  %2128 = add <8 x i64> %2127, %.spill.load628
  %.spill.load629 = load <8 x i1>, ptr %.spill194, align 1
  %2129 = and <8 x i1> %119, %.spill.load629
  %2130 = xor <8 x i1> %.spill.load629, splat (i1 true)
  %2131 = and <8 x i1> %119, %2130
  %2132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2129)
  %2133 = bitcast <8 x i1> %2129 to i8
  %2134 = call i8 @llvm.cttz.i8(i8 %2133, i1 false)
  %2135 = zext i8 %2134 to i32
  %2136 = select i1 %2132, i32 %2135, i32 0
  %tile_snapshot.spill.load630 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill143, align 64
  %2137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load630, 0
  %2138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load630, 1
  %2139 = mul <8 x i64> %2128, splat (i64 32)
  %2140 = add <8 x i64> %2138, %2139
  %2141 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2137, 0
  %2142 = insertvalue { <8 x ptr>, <8 x i64> } %2141, <8 x i64> %2140, 1
  %2143 = extractvalue { <8 x ptr>, <8 x i64> } %21, 0
  %2144 = extractvalue { <8 x ptr>, <8 x i64> } %2142, 1
  %2145 = extractelement <8 x ptr> %2143, i32 0
  %2146 = extractelement <8 x i64> %2144, i32 %2136
  %2147 = zext i32 %2136 to i64
  %2148 = mul i64 %2147, 4
  %2149 = sub i64 %2146, %2148
  %2150 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2129)
  %2151 = select i1 %2150, i64 %2149, i64 0
  %private.contiguous.address631 = getelementptr i8, ptr %2145, i64 %2151
  %private.contiguous.load632 = load <8 x float>, ptr %private.contiguous.address631, align 4
  %2152 = select <8 x i1> %2129, <8 x float> %private.contiguous.load632, <8 x float> zeroinitializer
  %2153 = load <8 x float>, ptr %.slot198, align 32
  %2154 = select <8 x i1> %2129, <8 x float> %2152, <8 x float> %2153
  store <8 x float> %2154, ptr %.slot198, align 32
  %2155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2131)
  %2156 = bitcast <8 x i1> %2131 to i8
  %2157 = call i8 @llvm.cttz.i8(i8 %2156, i1 false)
  %2158 = zext i8 %2157 to i32
  %2159 = select i1 %2155, i32 %2158, i32 0
  %2160 = load <8 x float>, ptr %.slot198, align 32
  %2161 = select <8 x i1> %2131, <8 x float> zeroinitializer, <8 x float> %2160
  store <8 x float> %2161, ptr %.slot198, align 32
  br label %direct.schedule.138

direct.schedule.138:                              ; preds = %direct.schedule.136
  %.state633 = load <8 x float>, ptr %.slot198, align 32
  %.state634 = load <8 x i1>, ptr %.slot197, align 1
  %2162 = select <8 x i1> %.state634, <8 x float> %.state633, <8 x float> splat (float 0xC6293E5940000000)
  %.spill.load635 = load <8 x i1>, ptr %.spill194, align 1
  %2163 = and <8 x i1> %119, %.spill.load635
  %2164 = xor <8 x i1> %.spill.load635, splat (i1 true)
  %2165 = and <8 x i1> %119, %2164
  %2166 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2163)
  %2167 = bitcast <8 x i1> %2163 to i8
  %2168 = call i8 @llvm.cttz.i8(i8 %2167, i1 false)
  %2169 = zext i8 %2168 to i32
  %2170 = select i1 %2166, i32 %2169, i32 0
  %tile_snapshot.spill.load636 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill191, align 64
  %2171 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load636, 0
  %2172 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load636, 1
  %.state637 = load <8 x i64>, ptr %.slot192, align 64
  %2173 = mul <8 x i64> %.state637, splat (i64 32)
  %2174 = add <8 x i64> %2172, %2173
  %2175 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2171, 0
  %2176 = insertvalue { <8 x ptr>, <8 x i64> } %2175, <8 x i64> %2174, 1
  %2177 = extractvalue { <8 x ptr>, <8 x i64> } %45, 0
  %2178 = extractvalue { <8 x ptr>, <8 x i64> } %2176, 1
  %2179 = extractelement <8 x ptr> %2177, i32 0
  %2180 = extractelement <8 x i64> %2178, i32 %2170
  %2181 = zext i32 %2170 to i64
  %2182 = mul i64 %2181, 4
  %2183 = sub i64 %2180, %2182
  %2184 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2163)
  %2185 = select i1 %2184, i64 %2183, i64 0
  %private.contiguous.address638 = getelementptr i8, ptr %2179, i64 %2185
  %private.contiguous.preserve639 = load <8 x float>, ptr %private.contiguous.address638, align 4
  %2186 = select <8 x i1> %2163, <8 x float> %2162, <8 x float> %private.contiguous.preserve639
  store <8 x float> %2186, ptr %private.contiguous.address638, align 4
  %2187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2165)
  %2188 = bitcast <8 x i1> %2165 to i8
  %2189 = call i8 @llvm.cttz.i8(i8 %2188, i1 false)
  %2190 = zext i8 %2189 to i32
  %2191 = select i1 %2187, i32 %2190, i32 0
  br label %direct.schedule.140

direct.schedule.140:                              ; preds = %direct.schedule.138
  %.state640 = load <8 x i64>, ptr %.slot192, align 64
  %2192 = add <8 x i64> %.state640, splat (i64 1)
  %2193 = load <8 x i64>, ptr %.slot192, align 64
  %2194 = select <8 x i1> %119, <8 x i64> %2192, <8 x i64> %2193
  store <8 x i64> %2194, ptr %.slot192, align 64
  br label %direct.schedule.133

direct.schedule.141:                              ; preds = %direct.false619
  %2195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill199, align 64
  %2196 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %2197 = extractvalue { <8 x ptr>, <8 x i64> } %2195, 0
  %2198 = select <8 x i1> %119, <8 x ptr> %2196, <8 x ptr> %2197
  %2199 = extractvalue { <8 x ptr>, <8 x i64> } %47, 1
  %2200 = extractvalue { <8 x ptr>, <8 x i64> } %2195, 1
  %2201 = select <8 x i1> %119, <8 x i64> %2199, <8 x i64> %2200
  %2202 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2198, 0
  %2203 = insertvalue { <8 x ptr>, <8 x i64> } %2202, <8 x i64> %2201, 1
  store { <8 x ptr>, <8 x i64> } %2203, ptr %tile_snapshot.spill199, align 64
  %2204 = load <8 x i64>, ptr %.slot200, align 64
  %2205 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %2204
  store <8 x i64> %2205, ptr %.slot200, align 64
  br label %direct.schedule.142

direct.schedule.142:                              ; preds = %direct.schedule.148, %direct.schedule.141
  %.state641 = load <8 x i64>, ptr %.slot200, align 64
  %2206 = icmp slt <8 x i64> %.state641, splat (i64 2)
  %2207 = extractelement <8 x i1> %2206, i32 0
  br i1 %2207, label %direct.true642, label %direct.false643

direct.schedule.143:                              ; preds = %direct.true642
  %.state644 = load <8 x i64>, ptr %.slot200, align 64
  %2208 = select <8 x i1> %119, <8 x i64> %.state644, <8 x i64> zeroinitializer
  %2209 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %2210 = srem <8 x i64> %2208, %2209
  %.state645 = load <8 x i64>, ptr %.slot200, align 64
  %2211 = select <8 x i1> %119, <8 x i64> %.state645, <8 x i64> zeroinitializer
  %2212 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %2213 = sdiv <8 x i64> %2211, %2212
  %2214 = select <8 x i1> %119, <8 x i64> %2213, <8 x i64> zeroinitializer
  %2215 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2216 = srem <8 x i64> %2214, %2215
  %2217 = select <8 x i1> %119, <8 x i64> %2213, <8 x i64> zeroinitializer
  %2218 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2219 = sdiv <8 x i64> %2217, %2218
  %2220 = select <8 x i1> %119, <8 x i64> %2219, <8 x i64> zeroinitializer
  %2221 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %2222 = srem <8 x i64> %2220, %2221
  %2223 = add <8 x i64> zeroinitializer, %2222
  %2224 = mul <8 x i64> %2223, splat (i64 1)
  %2225 = add <8 x i64> %2224, %2216
  %2226 = mul <8 x i64> %2225, splat (i64 2)
  %2227 = add <8 x i64> %2226, %2210
  %2228 = load <8 x i64>, ptr %.spill201, align 64
  %2229 = select <8 x i1> %119, <8 x i64> %2227, <8 x i64> %2228
  store <8 x i64> %2229, ptr %.spill201, align 64
  %2230 = load <8 x i64>, ptr %.slot202, align 64
  %2231 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %2230
  store <8 x i64> %2231, ptr %.slot202, align 64
  %2232 = load <8 x float>, ptr %.slot203, align 32
  %2233 = select <8 x i1> %119, <8 x float> zeroinitializer, <8 x float> %2232
  store <8 x float> %2233, ptr %.slot203, align 32
  %2234 = load <8 x i1>, ptr %.slot204, align 1
  %2235 = select <8 x i1> %119, <8 x i1> zeroinitializer, <8 x i1> %2234
  store <8 x i1> %2235, ptr %.slot204, align 1
  br label %direct.schedule.144

direct.schedule.144:                              ; preds = %direct.schedule.147, %direct.schedule.143
  %.state646 = load <8 x i64>, ptr %.slot202, align 64
  %2236 = icmp slt <8 x i64> %.state646, splat (i64 5)
  %2237 = extractelement <8 x i1> %2236, i32 0
  br i1 %2237, label %direct.true647, label %direct.false648

direct.schedule.145:                              ; preds = %direct.true647
  %.state649 = load <8 x i64>, ptr %.slot202, align 64
  %2238 = select <8 x i1> %119, <8 x i64> %.state649, <8 x i64> zeroinitializer
  %2239 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %2240 = srem <8 x i64> %2238, %2239
  %2241 = mul <8 x i64> %2240, splat (i64 8)
  %.spill.load650 = load <8 x i64>, ptr %.spill, align 64
  %2242 = add <8 x i64> %2241, %.spill.load650
  %2243 = icmp slt <8 x i64> %2242, splat (i64 33)
  %2244 = load <8 x i1>, ptr %.spill205, align 1
  %2245 = select <8 x i1> %119, <8 x i1> %2243, <8 x i1> %2244
  store <8 x i1> %2245, ptr %.spill205, align 1
  %.spill.load651 = load <8 x i64>, ptr %.spill201, align 64
  %2246 = mul <8 x i64> %.spill.load651, splat (i64 5)
  %2247 = add <8 x i64> %2246, %2240
  %2248 = and <8 x i1> %119, %2243
  %2249 = xor <8 x i1> %2243, splat (i1 true)
  %2250 = and <8 x i1> %119, %2249
  %2251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2248)
  %2252 = bitcast <8 x i1> %2248 to i8
  %2253 = call i8 @llvm.cttz.i8(i8 %2252, i1 false)
  %2254 = zext i8 %2253 to i32
  %2255 = select i1 %2251, i32 %2254, i32 0
  %tile_snapshot.spill.load652 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill191, align 64
  %2256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 0
  %2257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load652, 1
  %2258 = mul <8 x i64> %2247, splat (i64 32)
  %2259 = add <8 x i64> %2257, %2258
  %2260 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %2256, 0
  %2261 = insertvalue { <8 x ptr>, <8 x i64> } %2260, <8 x i64> %2259, 1
  %2262 = extractvalue { <8 x ptr>, <8 x i64> } %45, 0
  %2263 = extractvalue { <8 x ptr>, <8 x i64> } %2261, 1
  %2264 = extractelement <8 x ptr> %2262, i32 0
  %2265 = extractelement <8 x i64> %2263, i32 %2255
  %2266 = zext i32 %2255 to i64
  %2267 = mul i64 %2266, 4
  %2268 = sub i64 %2265, %2267
  %2269 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2248)
  %2270 = select i1 %2269, i64 %2268, i64 0
  %private.contiguous.address653 = getelementptr i8, ptr %2264, i64 %2270
  %private.contiguous.load654 = load <8 x float>, ptr %private.contiguous.address653, align 4
  %2271 = select <8 x i1> %2248, <8 x float> %private.contiguous.load654, <8 x float> zeroinitializer
  %2272 = load <8 x float>, ptr %.slot206, align 32
  %2273 = select <8 x i1> %2248, <8 x float> %2271, <8 x float> %2272
  store <8 x float> %2273, ptr %.slot206, align 32
  %2274 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %2250)
  %2275 = bitcast <8 x i1> %2250 to i8
  %2276 = call i8 @llvm.cttz.i8(i8 %2275, i1 false)
  %2277 = zext i8 %2276 to i32
  %2278 = select i1 %2274, i32 %2277, i32 0
  %2279 = load <8 x float>, ptr %.slot206, align 32
  %2280 = select <8 x i1> %2250, <8 x float> zeroinitializer, <8 x float> %2279
  store <8 x float> %2280, ptr %.slot206, align 32
  br label %direct.schedule.147

direct.schedule.147:                              ; preds = %direct.schedule.145
  %.state655 = load <8 x float>, ptr %.slot203, align 32
  %.state656 = load <8 x float>, ptr %.slot206, align 32
  %2281 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state655, <8 x float> %.state656)
  %.state657 = load <8 x float>, ptr %.slot206, align 32
  %.state658 = load <8 x i1>, ptr %.slot204, align 1
  %2282 = select <8 x i1> %.state658, <8 x float> %2281, <8 x float> %.state657
  %.state659 = load <8 x float>, ptr %.slot203, align 32
  %.spill.load660 = load <8 x i1>, ptr %.spill205, align 1
  %2283 = select <8 x i1> %.spill.load660, <8 x float> %2282, <8 x float> %.state659
  %.state661 = load <8 x i1>, ptr %.slot204, align 1
  %.spill.load662 = load <8 x i1>, ptr %.spill205, align 1
  %2284 = or <8 x i1> %.state661, %.spill.load662
  %.state663 = load <8 x i64>, ptr %.slot202, align 64
  %2285 = add <8 x i64> %.state663, splat (i64 1)
  %2286 = load <8 x i64>, ptr %.slot202, align 64
  %2287 = select <8 x i1> %119, <8 x i64> %2285, <8 x i64> %2286
  store <8 x i64> %2287, ptr %.slot202, align 64
  %2288 = load <8 x float>, ptr %.slot203, align 32
  %2289 = select <8 x i1> %119, <8 x float> %2283, <8 x float> %2288
  store <8 x float> %2289, ptr %.slot203, align 32
  %2290 = load <8 x i1>, ptr %.slot204, align 1
  %2291 = select <8 x i1> %119, <8 x i1> %2284, <8 x i1> %2290
  store <8 x i1> %2291, ptr %.slot204, align 1
  br label %direct.schedule.144

direct.schedule.148:                              ; preds = %direct.false648
  %.spill.load664 = load <8 x i64>, ptr %.spill, align 64
  %2292 = trunc <8 x i64> %.spill.load664 to <8 x i32>
  %2293 = xor <8 x i32> %2292, splat (i32 1)
  %.state665 = load <8 x float>, ptr %.slot203, align 32
  %2294 = extractelement <8 x i32> %2293, i64 0
  %2295 = icmp ult i32 %2294, 8
  %2296 = select i1 %2295, i32 %2294, i32 0
  %2297 = extractelement <8 x i1> %119, i32 %2296
  %2298 = extractelement <8 x i1> %119, i64 0
  %2299 = and i1 %2295, %2297
  %2300 = and i1 %2298, %2299
  %2301 = extractelement <8 x float> %.state665, i32 %2296
  %2302 = select i1 %2300, float %2301, float 0.000000e+00
  %2303 = insertelement <8 x float> poison, float %2302, i64 0
  %2304 = xor i1 %2300, true
  %2305 = and i1 %2298, %2304
  %2306 = insertelement <8 x i1> poison, i1 %2305, i64 0
  %2307 = extractelement <8 x i32> %2293, i64 1
  %2308 = icmp ult i32 %2307, 8
  %2309 = select i1 %2308, i32 %2307, i32 0
  %2310 = extractelement <8 x i1> %119, i32 %2309
  %2311 = extractelement <8 x i1> %119, i64 1
  %2312 = and i1 %2308, %2310
  %2313 = and i1 %2311, %2312
  %2314 = extractelement <8 x float> %.state665, i32 %2309
  %2315 = select i1 %2313, float %2314, float 0.000000e+00
  %2316 = insertelement <8 x float> %2303, float %2315, i64 1
  %2317 = xor i1 %2313, true
  %2318 = and i1 %2311, %2317
  %2319 = insertelement <8 x i1> %2306, i1 %2318, i64 1
  %2320 = extractelement <8 x i32> %2293, i64 2
  %2321 = icmp ult i32 %2320, 8
  %2322 = select i1 %2321, i32 %2320, i32 0
  %2323 = extractelement <8 x i1> %119, i32 %2322
  %2324 = extractelement <8 x i1> %119, i64 2
  %2325 = and i1 %2321, %2323
  %2326 = and i1 %2324, %2325
  %2327 = extractelement <8 x float> %.state665, i32 %2322
  %2328 = select i1 %2326, float %2327, float 0.000000e+00
  %2329 = insertelement <8 x float> %2316, float %2328, i64 2
  %2330 = xor i1 %2326, true
  %2331 = and i1 %2324, %2330
  %2332 = insertelement <8 x i1> %2319, i1 %2331, i64 2
  %2333 = extractelement <8 x i32> %2293, i64 3
  %2334 = icmp ult i32 %2333, 8
  %2335 = select i1 %2334, i32 %2333, i32 0
  %2336 = extractelement <8 x i1> %119, i32 %2335
  %2337 = extractelement <8 x i1> %119, i64 3
  %2338 = and i1 %2334, %2336
  %2339 = and i1 %2337, %2338
  %2340 = extractelement <8 x float> %.state665, i32 %2335
  %2341 = select i1 %2339, float %2340, float 0.000000e+00
  %2342 = insertelement <8 x float> %2329, float %2341, i64 3
  %2343 = xor i1 %2339, true
  %2344 = and i1 %2337, %2343
  %2345 = insertelement <8 x i1> %2332, i1 %2344, i64 3
  %2346 = extractelement <8 x i32> %2293, i64 4
  %2347 = icmp ult i32 %2346, 8
  %2348 = select i1 %2347, i32 %2346, i32 0
  %2349 = extractelement <8 x i1> %119, i32 %2348
  %2350 = extractelement <8 x i1> %119, i64 4
  %2351 = and i1 %2347, %2349
  %2352 = and i1 %2350, %2351
  %2353 = extractelement <8 x float> %.state665, i32 %2348
  %2354 = select i1 %2352, float %2353, float 0.000000e+00
  %2355 = insertelement <8 x float> %2342, float %2354, i64 4
  %2356 = xor i1 %2352, true
  %2357 = and i1 %2350, %2356
  %2358 = insertelement <8 x i1> %2345, i1 %2357, i64 4
  %2359 = extractelement <8 x i32> %2293, i64 5
  %2360 = icmp ult i32 %2359, 8
  %2361 = select i1 %2360, i32 %2359, i32 0
  %2362 = extractelement <8 x i1> %119, i32 %2361
  %2363 = extractelement <8 x i1> %119, i64 5
  %2364 = and i1 %2360, %2362
  %2365 = and i1 %2363, %2364
  %2366 = extractelement <8 x float> %.state665, i32 %2361
  %2367 = select i1 %2365, float %2366, float 0.000000e+00
  %2368 = insertelement <8 x float> %2355, float %2367, i64 5
  %2369 = xor i1 %2365, true
  %2370 = and i1 %2363, %2369
  %2371 = insertelement <8 x i1> %2358, i1 %2370, i64 5
  %2372 = extractelement <8 x i32> %2293, i64 6
  %2373 = icmp ult i32 %2372, 8
  %2374 = select i1 %2373, i32 %2372, i32 0
  %2375 = extractelement <8 x i1> %119, i32 %2374
  %2376 = extractelement <8 x i1> %119, i64 6
  %2377 = and i1 %2373, %2375
  %2378 = and i1 %2376, %2377
  %2379 = extractelement <8 x float> %.state665, i32 %2374
  %2380 = select i1 %2378, float %2379, float 0.000000e+00
  %2381 = insertelement <8 x float> %2368, float %2380, i64 6
  %2382 = xor i1 %2378, true
  %2383 = and i1 %2376, %2382
  %2384 = insertelement <8 x i1> %2371, i1 %2383, i64 6
  %2385 = extractelement <8 x i32> %2293, i64 7
  %2386 = icmp ult i32 %2385, 8
  %2387 = select i1 %2386, i32 %2385, i32 0
  %2388 = extractelement <8 x i1> %119, i32 %2387
  %2389 = extractelement <8 x i1> %119, i64 7
  %2390 = and i1 %2386, %2388
  %2391 = and i1 %2389, %2390
  %2392 = extractelement <8 x float> %.state665, i32 %2387
  %2393 = select i1 %2391, float %2392, float 0.000000e+00
  %2394 = insertelement <8 x float> %2381, float %2393, i64 7
  %2395 = xor i1 %2391, true
  %2396 = and i1 %2389, %2395
  %2397 = insertelement <8 x i1> %2384, i1 %2396, i64 7
  %.state666 = load <8 x float>, ptr %.slot203, align 32
  %2398 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state666, <8 x float> %2394)
  %.state667 = load <8 x i1>, ptr %.slot204, align 1
  %2399 = zext <8 x i1> %.state667 to <8 x i32>
  %2400 = extractelement <8 x i32> %2293, i64 0
  %2401 = icmp ult i32 %2400, 8
  %2402 = select i1 %2401, i32 %2400, i32 0
  %2403 = extractelement <8 x i1> %119, i32 %2402
  %2404 = extractelement <8 x i1> %119, i64 0
  %2405 = and i1 %2401, %2403
  %2406 = and i1 %2404, %2405
  %2407 = extractelement <8 x i32> %2399, i32 %2402
  %2408 = select i1 %2406, i32 %2407, i32 0
  %2409 = insertelement <8 x i32> poison, i32 %2408, i64 0
  %2410 = xor i1 %2406, true
  %2411 = and i1 %2404, %2410
  %2412 = insertelement <8 x i1> poison, i1 %2411, i64 0
  %2413 = extractelement <8 x i32> %2293, i64 1
  %2414 = icmp ult i32 %2413, 8
  %2415 = select i1 %2414, i32 %2413, i32 0
  %2416 = extractelement <8 x i1> %119, i32 %2415
  %2417 = extractelement <8 x i1> %119, i64 1
  %2418 = and i1 %2414, %2416
  %2419 = and i1 %2417, %2418
  %2420 = extractelement <8 x i32> %2399, i32 %2415
  %2421 = select i1 %2419, i32 %2420, i32 0
  %2422 = insertelement <8 x i32> %2409, i32 %2421, i64 1
  %2423 = xor i1 %2419, true
  %2424 = and i1 %2417, %2423
  %2425 = insertelement <8 x i1> %2412, i1 %2424, i64 1
  %2426 = extractelement <8 x i32> %2293, i64 2
  %2427 = icmp ult i32 %2426, 8
  %2428 = select i1 %2427, i32 %2426, i32 0
  %2429 = extractelement <8 x i1> %119, i32 %2428
  %2430 = extractelement <8 x i1> %119, i64 2
  %2431 = and i1 %2427, %2429
  %2432 = and i1 %2430, %2431
  %2433 = extractelement <8 x i32> %2399, i32 %2428
  %2434 = select i1 %2432, i32 %2433, i32 0
  %2435 = insertelement <8 x i32> %2422, i32 %2434, i64 2
  %2436 = xor i1 %2432, true
  %2437 = and i1 %2430, %2436
  %2438 = insertelement <8 x i1> %2425, i1 %2437, i64 2
  %2439 = extractelement <8 x i32> %2293, i64 3
  %2440 = icmp ult i32 %2439, 8
  %2441 = select i1 %2440, i32 %2439, i32 0
  %2442 = extractelement <8 x i1> %119, i32 %2441
  %2443 = extractelement <8 x i1> %119, i64 3
  %2444 = and i1 %2440, %2442
  %2445 = and i1 %2443, %2444
  %2446 = extractelement <8 x i32> %2399, i32 %2441
  %2447 = select i1 %2445, i32 %2446, i32 0
  %2448 = insertelement <8 x i32> %2435, i32 %2447, i64 3
  %2449 = xor i1 %2445, true
  %2450 = and i1 %2443, %2449
  %2451 = insertelement <8 x i1> %2438, i1 %2450, i64 3
  %2452 = extractelement <8 x i32> %2293, i64 4
  %2453 = icmp ult i32 %2452, 8
  %2454 = select i1 %2453, i32 %2452, i32 0
  %2455 = extractelement <8 x i1> %119, i32 %2454
  %2456 = extractelement <8 x i1> %119, i64 4
  %2457 = and i1 %2453, %2455
  %2458 = and i1 %2456, %2457
  %2459 = extractelement <8 x i32> %2399, i32 %2454
  %2460 = select i1 %2458, i32 %2459, i32 0
  %2461 = insertelement <8 x i32> %2448, i32 %2460, i64 4
  %2462 = xor i1 %2458, true
  %2463 = and i1 %2456, %2462
  %2464 = insertelement <8 x i1> %2451, i1 %2463, i64 4
  %2465 = extractelement <8 x i32> %2293, i64 5
  %2466 = icmp ult i32 %2465, 8
  %2467 = select i1 %2466, i32 %2465, i32 0
  %2468 = extractelement <8 x i1> %119, i32 %2467
  %2469 = extractelement <8 x i1> %119, i64 5
  %2470 = and i1 %2466, %2468
  %2471 = and i1 %2469, %2470
  %2472 = extractelement <8 x i32> %2399, i32 %2467
  %2473 = select i1 %2471, i32 %2472, i32 0
  %2474 = insertelement <8 x i32> %2461, i32 %2473, i64 5
  %2475 = xor i1 %2471, true
  %2476 = and i1 %2469, %2475
  %2477 = insertelement <8 x i1> %2464, i1 %2476, i64 5
  %2478 = extractelement <8 x i32> %2293, i64 6
  %2479 = icmp ult i32 %2478, 8
  %2480 = select i1 %2479, i32 %2478, i32 0
  %2481 = extractelement <8 x i1> %119, i32 %2480
  %2482 = extractelement <8 x i1> %119, i64 6
  %2483 = and i1 %2479, %2481
  %2484 = and i1 %2482, %2483
  %2485 = extractelement <8 x i32> %2399, i32 %2480
  %2486 = select i1 %2484, i32 %2485, i32 0
  %2487 = insertelement <8 x i32> %2474, i32 %2486, i64 6
  %2488 = xor i1 %2484, true
  %2489 = and i1 %2482, %2488
  %2490 = insertelement <8 x i1> %2477, i1 %2489, i64 6
  %2491 = extractelement <8 x i32> %2293, i64 7
  %2492 = icmp ult i32 %2491, 8
  %2493 = select i1 %2492, i32 %2491, i32 0
  %2494 = extractelement <8 x i1> %119, i32 %2493
  %2495 = extractelement <8 x i1> %119, i64 7
  %2496 = and i1 %2492, %2494
  %2497 = and i1 %2495, %2496
  %2498 = extractelement <8 x i32> %2399, i32 %2493
  %2499 = select i1 %2497, i32 %2498, i32 0
  %2500 = insertelement <8 x i32> %2487, i32 %2499, i64 7
  %2501 = xor i1 %2497, true
  %2502 = and i1 %2495, %2501
  %2503 = insertelement <8 x i1> %2490, i1 %2502, i64 7
  %2504 = icmp ne <8 x i32> %2500, zeroinitializer
  %.state668 = load <8 x float>, ptr %.slot203, align 32
  %.state669 = load <8 x i1>, ptr %.slot204, align 1
  %2505 = select <8 x i1> %.state669, <8 x float> %.state668, <8 x float> %2394
  %.state670 = load <8 x i1>, ptr %.slot204, align 1
  %2506 = and <8 x i1> %.state670, %2504
  %2507 = select <8 x i1> %2506, <8 x float> %2398, <8 x float> %2505
  %.state671 = load <8 x i1>, ptr %.slot204, align 1
  %2508 = or <8 x i1> %.state671, %2504
  %2509 = xor <8 x i32> %2292, splat (i32 2)
  %2510 = extractelement <8 x i32> %2509, i64 0
  %2511 = icmp ult i32 %2510, 8
  %2512 = select i1 %2511, i32 %2510, i32 0
  %2513 = extractelement <8 x i1> %119, i32 %2512
  %2514 = extractelement <8 x i1> %119, i64 0
  %2515 = and i1 %2511, %2513
  %2516 = and i1 %2514, %2515
  %2517 = extractelement <8 x float> %2507, i32 %2512
  %2518 = select i1 %2516, float %2517, float 0.000000e+00
  %2519 = insertelement <8 x float> poison, float %2518, i64 0
  %2520 = xor i1 %2516, true
  %2521 = and i1 %2514, %2520
  %2522 = insertelement <8 x i1> poison, i1 %2521, i64 0
  %2523 = extractelement <8 x i32> %2509, i64 1
  %2524 = icmp ult i32 %2523, 8
  %2525 = select i1 %2524, i32 %2523, i32 0
  %2526 = extractelement <8 x i1> %119, i32 %2525
  %2527 = extractelement <8 x i1> %119, i64 1
  %2528 = and i1 %2524, %2526
  %2529 = and i1 %2527, %2528
  %2530 = extractelement <8 x float> %2507, i32 %2525
  %2531 = select i1 %2529, float %2530, float 0.000000e+00
  %2532 = insertelement <8 x float> %2519, float %2531, i64 1
  %2533 = xor i1 %2529, true
  %2534 = and i1 %2527, %2533
  %2535 = insertelement <8 x i1> %2522, i1 %2534, i64 1
  %2536 = extractelement <8 x i32> %2509, i64 2
  %2537 = icmp ult i32 %2536, 8
  %2538 = select i1 %2537, i32 %2536, i32 0
  %2539 = extractelement <8 x i1> %119, i32 %2538
  %2540 = extractelement <8 x i1> %119, i64 2
  %2541 = and i1 %2537, %2539
  %2542 = and i1 %2540, %2541
  %2543 = extractelement <8 x float> %2507, i32 %2538
  %2544 = select i1 %2542, float %2543, float 0.000000e+00
  %2545 = insertelement <8 x float> %2532, float %2544, i64 2
  %2546 = xor i1 %2542, true
  %2547 = and i1 %2540, %2546
  %2548 = insertelement <8 x i1> %2535, i1 %2547, i64 2
  %2549 = extractelement <8 x i32> %2509, i64 3
  %2550 = icmp ult i32 %2549, 8
  %2551 = select i1 %2550, i32 %2549, i32 0
  %2552 = extractelement <8 x i1> %119, i32 %2551
  %2553 = extractelement <8 x i1> %119, i64 3
  %2554 = and i1 %2550, %2552
  %2555 = and i1 %2553, %2554
  %2556 = extractelement <8 x float> %2507, i32 %2551
  %2557 = select i1 %2555, float %2556, float 0.000000e+00
  %2558 = insertelement <8 x float> %2545, float %2557, i64 3
  %2559 = xor i1 %2555, true
  %2560 = and i1 %2553, %2559
  %2561 = insertelement <8 x i1> %2548, i1 %2560, i64 3
  %2562 = extractelement <8 x i32> %2509, i64 4
  %2563 = icmp ult i32 %2562, 8
  %2564 = select i1 %2563, i32 %2562, i32 0
  %2565 = extractelement <8 x i1> %119, i32 %2564
  %2566 = extractelement <8 x i1> %119, i64 4
  %2567 = and i1 %2563, %2565
  %2568 = and i1 %2566, %2567
  %2569 = extractelement <8 x float> %2507, i32 %2564
  %2570 = select i1 %2568, float %2569, float 0.000000e+00
  %2571 = insertelement <8 x float> %2558, float %2570, i64 4
  %2572 = xor i1 %2568, true
  %2573 = and i1 %2566, %2572
  %2574 = insertelement <8 x i1> %2561, i1 %2573, i64 4
  %2575 = extractelement <8 x i32> %2509, i64 5
  %2576 = icmp ult i32 %2575, 8
  %2577 = select i1 %2576, i32 %2575, i32 0
  %2578 = extractelement <8 x i1> %119, i32 %2577
  %2579 = extractelement <8 x i1> %119, i64 5
  %2580 = and i1 %2576, %2578
  %2581 = and i1 %2579, %2580
  %2582 = extractelement <8 x float> %2507, i32 %2577
  %2583 = select i1 %2581, float %2582, float 0.000000e+00
  %2584 = insertelement <8 x float> %2571, float %2583, i64 5
  %2585 = xor i1 %2581, true
  %2586 = and i1 %2579, %2585
  %2587 = insertelement <8 x i1> %2574, i1 %2586, i64 5
  %2588 = extractelement <8 x i32> %2509, i64 6
  %2589 = icmp ult i32 %2588, 8
  %2590 = select i1 %2589, i32 %2588, i32 0
  %2591 = extractelement <8 x i1> %119, i32 %2590
  %2592 = extractelement <8 x i1> %119, i64 6
  %2593 = and i1 %2589, %2591
  %2594 = and i1 %2592, %2593
  %2595 = extractelement <8 x float> %2507, i32 %2590
  %2596 = select i1 %2594, float %2595, float 0.000000e+00
  %2597 = insertelement <8 x float> %2584, float %2596, i64 6
  %2598 = xor i1 %2594, true
  %2599 = and i1 %2592, %2598
  %2600 = insertelement <8 x i1> %2587, i1 %2599, i64 6
  %2601 = extractelement <8 x i32> %2509, i64 7
  %2602 = icmp ult i32 %2601, 8
  %2603 = select i1 %2602, i32 %2601, i32 0
  %2604 = extractelement <8 x i1> %119, i32 %2603
  %2605 = extractelement <8 x i1> %119, i64 7
  %2606 = and i1 %2602, %2604
  %2607 = and i1 %2605, %2606
  %2608 = extractelement <8 x float> %2507, i32 %2603
  %2609 = select i1 %2607, float %2608, float 0.000000e+00
  %2610 = insertelement <8 x float> %2597, float %2609, i64 7
  %2611 = xor i1 %2607, true
  %2612 = and i1 %2605, %2611
  %2613 = insertelement <8 x i1> %2600, i1 %2612, i64 7
  %2614 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2507, <8 x float> %2610)
  %2615 = zext <8 x i1> %2508 to <8 x i32>
  %2616 = extractelement <8 x i32> %2509, i64 0
  %2617 = icmp ult i32 %2616, 8
  %2618 = select i1 %2617, i32 %2616, i32 0
  %2619 = extractelement <8 x i1> %119, i32 %2618
  %2620 = extractelement <8 x i1> %119, i64 0
  %2621 = and i1 %2617, %2619
  %2622 = and i1 %2620, %2621
  %2623 = extractelement <8 x i32> %2615, i32 %2618
  %2624 = select i1 %2622, i32 %2623, i32 0
  %2625 = insertelement <8 x i32> poison, i32 %2624, i64 0
  %2626 = xor i1 %2622, true
  %2627 = and i1 %2620, %2626
  %2628 = insertelement <8 x i1> poison, i1 %2627, i64 0
  %2629 = extractelement <8 x i32> %2509, i64 1
  %2630 = icmp ult i32 %2629, 8
  %2631 = select i1 %2630, i32 %2629, i32 0
  %2632 = extractelement <8 x i1> %119, i32 %2631
  %2633 = extractelement <8 x i1> %119, i64 1
  %2634 = and i1 %2630, %2632
  %2635 = and i1 %2633, %2634
  %2636 = extractelement <8 x i32> %2615, i32 %2631
  %2637 = select i1 %2635, i32 %2636, i32 0
  %2638 = insertelement <8 x i32> %2625, i32 %2637, i64 1
  %2639 = xor i1 %2635, true
  %2640 = and i1 %2633, %2639
  %2641 = insertelement <8 x i1> %2628, i1 %2640, i64 1
  %2642 = extractelement <8 x i32> %2509, i64 2
  %2643 = icmp ult i32 %2642, 8
  %2644 = select i1 %2643, i32 %2642, i32 0
  %2645 = extractelement <8 x i1> %119, i32 %2644
  %2646 = extractelement <8 x i1> %119, i64 2
  %2647 = and i1 %2643, %2645
  %2648 = and i1 %2646, %2647
  %2649 = extractelement <8 x i32> %2615, i32 %2644
  %2650 = select i1 %2648, i32 %2649, i32 0
  %2651 = insertelement <8 x i32> %2638, i32 %2650, i64 2
  %2652 = xor i1 %2648, true
  %2653 = and i1 %2646, %2652
  %2654 = insertelement <8 x i1> %2641, i1 %2653, i64 2
  %2655 = extractelement <8 x i32> %2509, i64 3
  %2656 = icmp ult i32 %2655, 8
  %2657 = select i1 %2656, i32 %2655, i32 0
  %2658 = extractelement <8 x i1> %119, i32 %2657
  %2659 = extractelement <8 x i1> %119, i64 3
  %2660 = and i1 %2656, %2658
  %2661 = and i1 %2659, %2660
  %2662 = extractelement <8 x i32> %2615, i32 %2657
  %2663 = select i1 %2661, i32 %2662, i32 0
  %2664 = insertelement <8 x i32> %2651, i32 %2663, i64 3
  %2665 = xor i1 %2661, true
  %2666 = and i1 %2659, %2665
  %2667 = insertelement <8 x i1> %2654, i1 %2666, i64 3
  %2668 = extractelement <8 x i32> %2509, i64 4
  %2669 = icmp ult i32 %2668, 8
  %2670 = select i1 %2669, i32 %2668, i32 0
  %2671 = extractelement <8 x i1> %119, i32 %2670
  %2672 = extractelement <8 x i1> %119, i64 4
  %2673 = and i1 %2669, %2671
  %2674 = and i1 %2672, %2673
  %2675 = extractelement <8 x i32> %2615, i32 %2670
  %2676 = select i1 %2674, i32 %2675, i32 0
  %2677 = insertelement <8 x i32> %2664, i32 %2676, i64 4
  %2678 = xor i1 %2674, true
  %2679 = and i1 %2672, %2678
  %2680 = insertelement <8 x i1> %2667, i1 %2679, i64 4
  %2681 = extractelement <8 x i32> %2509, i64 5
  %2682 = icmp ult i32 %2681, 8
  %2683 = select i1 %2682, i32 %2681, i32 0
  %2684 = extractelement <8 x i1> %119, i32 %2683
  %2685 = extractelement <8 x i1> %119, i64 5
  %2686 = and i1 %2682, %2684
  %2687 = and i1 %2685, %2686
  %2688 = extractelement <8 x i32> %2615, i32 %2683
  %2689 = select i1 %2687, i32 %2688, i32 0
  %2690 = insertelement <8 x i32> %2677, i32 %2689, i64 5
  %2691 = xor i1 %2687, true
  %2692 = and i1 %2685, %2691
  %2693 = insertelement <8 x i1> %2680, i1 %2692, i64 5
  %2694 = extractelement <8 x i32> %2509, i64 6
  %2695 = icmp ult i32 %2694, 8
  %2696 = select i1 %2695, i32 %2694, i32 0
  %2697 = extractelement <8 x i1> %119, i32 %2696
  %2698 = extractelement <8 x i1> %119, i64 6
  %2699 = and i1 %2695, %2697
  %2700 = and i1 %2698, %2699
  %2701 = extractelement <8 x i32> %2615, i32 %2696
  %2702 = select i1 %2700, i32 %2701, i32 0
  %2703 = insertelement <8 x i32> %2690, i32 %2702, i64 6
  %2704 = xor i1 %2700, true
  %2705 = and i1 %2698, %2704
  %2706 = insertelement <8 x i1> %2693, i1 %2705, i64 6
  %2707 = extractelement <8 x i32> %2509, i64 7
  %2708 = icmp ult i32 %2707, 8
  %2709 = select i1 %2708, i32 %2707, i32 0
  %2710 = extractelement <8 x i1> %119, i32 %2709
  %2711 = extractelement <8 x i1> %119, i64 7
  %2712 = and i1 %2708, %2710
  %2713 = and i1 %2711, %2712
  %2714 = extractelement <8 x i32> %2615, i32 %2709
  %2715 = select i1 %2713, i32 %2714, i32 0
  %2716 = insertelement <8 x i32> %2703, i32 %2715, i64 7
  %2717 = xor i1 %2713, true
  %2718 = and i1 %2711, %2717
  %2719 = insertelement <8 x i1> %2706, i1 %2718, i64 7
  %2720 = icmp ne <8 x i32> %2716, zeroinitializer
  %2721 = select <8 x i1> %2508, <8 x float> %2507, <8 x float> %2610
  %2722 = and <8 x i1> %2508, %2720
  %2723 = select <8 x i1> %2722, <8 x float> %2614, <8 x float> %2721
  %2724 = or <8 x i1> %2508, %2720
  %2725 = xor <8 x i32> %2292, splat (i32 4)
  %2726 = extractelement <8 x i32> %2725, i64 0
  %2727 = icmp ult i32 %2726, 8
  %2728 = select i1 %2727, i32 %2726, i32 0
  %2729 = extractelement <8 x i1> %119, i32 %2728
  %2730 = extractelement <8 x i1> %119, i64 0
  %2731 = and i1 %2727, %2729
  %2732 = and i1 %2730, %2731
  %2733 = extractelement <8 x float> %2723, i32 %2728
  %2734 = select i1 %2732, float %2733, float 0.000000e+00
  %2735 = insertelement <8 x float> poison, float %2734, i64 0
  %2736 = xor i1 %2732, true
  %2737 = and i1 %2730, %2736
  %2738 = insertelement <8 x i1> poison, i1 %2737, i64 0
  %2739 = extractelement <8 x i32> %2725, i64 1
  %2740 = icmp ult i32 %2739, 8
  %2741 = select i1 %2740, i32 %2739, i32 0
  %2742 = extractelement <8 x i1> %119, i32 %2741
  %2743 = extractelement <8 x i1> %119, i64 1
  %2744 = and i1 %2740, %2742
  %2745 = and i1 %2743, %2744
  %2746 = extractelement <8 x float> %2723, i32 %2741
  %2747 = select i1 %2745, float %2746, float 0.000000e+00
  %2748 = insertelement <8 x float> %2735, float %2747, i64 1
  %2749 = xor i1 %2745, true
  %2750 = and i1 %2743, %2749
  %2751 = insertelement <8 x i1> %2738, i1 %2750, i64 1
  %2752 = extractelement <8 x i32> %2725, i64 2
  %2753 = icmp ult i32 %2752, 8
  %2754 = select i1 %2753, i32 %2752, i32 0
  %2755 = extractelement <8 x i1> %119, i32 %2754
  %2756 = extractelement <8 x i1> %119, i64 2
  %2757 = and i1 %2753, %2755
  %2758 = and i1 %2756, %2757
  %2759 = extractelement <8 x float> %2723, i32 %2754
  %2760 = select i1 %2758, float %2759, float 0.000000e+00
  %2761 = insertelement <8 x float> %2748, float %2760, i64 2
  %2762 = xor i1 %2758, true
  %2763 = and i1 %2756, %2762
  %2764 = insertelement <8 x i1> %2751, i1 %2763, i64 2
  %2765 = extractelement <8 x i32> %2725, i64 3
  %2766 = icmp ult i32 %2765, 8
  %2767 = select i1 %2766, i32 %2765, i32 0
  %2768 = extractelement <8 x i1> %119, i32 %2767
  %2769 = extractelement <8 x i1> %119, i64 3
  %2770 = and i1 %2766, %2768
  %2771 = and i1 %2769, %2770
  %2772 = extractelement <8 x float> %2723, i32 %2767
  %2773 = select i1 %2771, float %2772, float 0.000000e+00
  %2774 = insertelement <8 x float> %2761, float %2773, i64 3
  %2775 = xor i1 %2771, true
  %2776 = and i1 %2769, %2775
  %2777 = insertelement <8 x i1> %2764, i1 %2776, i64 3
  %2778 = extractelement <8 x i32> %2725, i64 4
  %2779 = icmp ult i32 %2778, 8
  %2780 = select i1 %2779, i32 %2778, i32 0
  %2781 = extractelement <8 x i1> %119, i32 %2780
  %2782 = extractelement <8 x i1> %119, i64 4
  %2783 = and i1 %2779, %2781
  %2784 = and i1 %2782, %2783
  %2785 = extractelement <8 x float> %2723, i32 %2780
  %2786 = select i1 %2784, float %2785, float 0.000000e+00
  %2787 = insertelement <8 x float> %2774, float %2786, i64 4
  %2788 = xor i1 %2784, true
  %2789 = and i1 %2782, %2788
  %2790 = insertelement <8 x i1> %2777, i1 %2789, i64 4
  %2791 = extractelement <8 x i32> %2725, i64 5
  %2792 = icmp ult i32 %2791, 8
  %2793 = select i1 %2792, i32 %2791, i32 0
  %2794 = extractelement <8 x i1> %119, i32 %2793
  %2795 = extractelement <8 x i1> %119, i64 5
  %2796 = and i1 %2792, %2794
  %2797 = and i1 %2795, %2796
  %2798 = extractelement <8 x float> %2723, i32 %2793
  %2799 = select i1 %2797, float %2798, float 0.000000e+00
  %2800 = insertelement <8 x float> %2787, float %2799, i64 5
  %2801 = xor i1 %2797, true
  %2802 = and i1 %2795, %2801
  %2803 = insertelement <8 x i1> %2790, i1 %2802, i64 5
  %2804 = extractelement <8 x i32> %2725, i64 6
  %2805 = icmp ult i32 %2804, 8
  %2806 = select i1 %2805, i32 %2804, i32 0
  %2807 = extractelement <8 x i1> %119, i32 %2806
  %2808 = extractelement <8 x i1> %119, i64 6
  %2809 = and i1 %2805, %2807
  %2810 = and i1 %2808, %2809
  %2811 = extractelement <8 x float> %2723, i32 %2806
  %2812 = select i1 %2810, float %2811, float 0.000000e+00
  %2813 = insertelement <8 x float> %2800, float %2812, i64 6
  %2814 = xor i1 %2810, true
  %2815 = and i1 %2808, %2814
  %2816 = insertelement <8 x i1> %2803, i1 %2815, i64 6
  %2817 = extractelement <8 x i32> %2725, i64 7
  %2818 = icmp ult i32 %2817, 8
  %2819 = select i1 %2818, i32 %2817, i32 0
  %2820 = extractelement <8 x i1> %119, i32 %2819
  %2821 = extractelement <8 x i1> %119, i64 7
  %2822 = and i1 %2818, %2820
  %2823 = and i1 %2821, %2822
  %2824 = extractelement <8 x float> %2723, i32 %2819
  %2825 = select i1 %2823, float %2824, float 0.000000e+00
  %2826 = insertelement <8 x float> %2813, float %2825, i64 7
  %2827 = xor i1 %2823, true
  %2828 = and i1 %2821, %2827
  %2829 = insertelement <8 x i1> %2816, i1 %2828, i64 7
  %2830 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %2723, <8 x float> %2826)
  %2831 = zext <8 x i1> %2724 to <8 x i32>
  %2832 = extractelement <8 x i32> %2725, i64 0
  %2833 = icmp ult i32 %2832, 8
  %2834 = select i1 %2833, i32 %2832, i32 0
  %2835 = extractelement <8 x i1> %119, i32 %2834
  %2836 = extractelement <8 x i1> %119, i64 0
  %2837 = and i1 %2833, %2835
  %2838 = and i1 %2836, %2837
  %2839 = extractelement <8 x i32> %2831, i32 %2834
  %2840 = select i1 %2838, i32 %2839, i32 0
  %2841 = insertelement <8 x i32> poison, i32 %2840, i64 0
  %2842 = xor i1 %2838, true
  %2843 = and i1 %2836, %2842
  %2844 = insertelement <8 x i1> poison, i1 %2843, i64 0
  %2845 = extractelement <8 x i32> %2725, i64 1
  %2846 = icmp ult i32 %2845, 8
  %2847 = select i1 %2846, i32 %2845, i32 0
  %2848 = extractelement <8 x i1> %119, i32 %2847
  %2849 = extractelement <8 x i1> %119, i64 1
  %2850 = and i1 %2846, %2848
  %2851 = and i1 %2849, %2850
  %2852 = extractelement <8 x i32> %2831, i32 %2847
  %2853 = select i1 %2851, i32 %2852, i32 0
  %2854 = insertelement <8 x i32> %2841, i32 %2853, i64 1
  %2855 = xor i1 %2851, true
  %2856 = and i1 %2849, %2855
  %2857 = insertelement <8 x i1> %2844, i1 %2856, i64 1
  %2858 = extractelement <8 x i32> %2725, i64 2
  %2859 = icmp ult i32 %2858, 8
  %2860 = select i1 %2859, i32 %2858, i32 0
  %2861 = extractelement <8 x i1> %119, i32 %2860
  %2862 = extractelement <8 x i1> %119, i64 2
  %2863 = and i1 %2859, %2861
  %2864 = and i1 %2862, %2863
  %2865 = extractelement <8 x i32> %2831, i32 %2860
  %2866 = select i1 %2864, i32 %2865, i32 0
  %2867 = insertelement <8 x i32> %2854, i32 %2866, i64 2
  %2868 = xor i1 %2864, true
  %2869 = and i1 %2862, %2868
  %2870 = insertelement <8 x i1> %2857, i1 %2869, i64 2
  %2871 = extractelement <8 x i32> %2725, i64 3
  %2872 = icmp ult i32 %2871, 8
  %2873 = select i1 %2872, i32 %2871, i32 0
  %2874 = extractelement <8 x i1> %119, i32 %2873
  %2875 = extractelement <8 x i1> %119, i64 3
  %2876 = and i1 %2872, %2874
  %2877 = and i1 %2875, %2876
  %2878 = extractelement <8 x i32> %2831, i32 %2873
  %2879 = select i1 %2877, i32 %2878, i32 0
  %2880 = insertelement <8 x i32> %2867, i32 %2879, i64 3
  %2881 = xor i1 %2877, true
  %2882 = and i1 %2875, %2881
  %2883 = insertelement <8 x i1> %2870, i1 %2882, i64 3
  %2884 = extractelement <8 x i32> %2725, i64 4
  %2885 = icmp ult i32 %2884, 8
  %2886 = select i1 %2885, i32 %2884, i32 0
  %2887 = extractelement <8 x i1> %119, i32 %2886
  %2888 = extractelement <8 x i1> %119, i64 4
  %2889 = and i1 %2885, %2887
  %2890 = and i1 %2888, %2889
  %2891 = extractelement <8 x i32> %2831, i32 %2886
  %2892 = select i1 %2890, i32 %2891, i32 0
  %2893 = insertelement <8 x i32> %2880, i32 %2892, i64 4
  %2894 = xor i1 %2890, true
  %2895 = and i1 %2888, %2894
  %2896 = insertelement <8 x i1> %2883, i1 %2895, i64 4
  %2897 = extractelement <8 x i32> %2725, i64 5
  %2898 = icmp ult i32 %2897, 8
  %2899 = select i1 %2898, i32 %2897, i32 0
  %2900 = extractelement <8 x i1> %119, i32 %2899
  %2901 = extractelement <8 x i1> %119, i64 5
  %2902 = and i1 %2898, %2900
  %2903 = and i1 %2901, %2902
  %2904 = extractelement <8 x i32> %2831, i32 %2899
  %2905 = select i1 %2903, i32 %2904, i32 0
  %2906 = insertelement <8 x i32> %2893, i32 %2905, i64 5
  %2907 = xor i1 %2903, true
  %2908 = and i1 %2901, %2907
  %2909 = insertelement <8 x i1> %2896, i1 %2908, i64 5
  %2910 = extractelement <8 x i32> %2725, i64 6
  %2911 = icmp ult i32 %2910, 8
  %2912 = select i1 %2911, i32 %2910, i32 0
  %2913 = extractelement <8 x i1> %119, i32 %2912
  %2914 = extractelement <8 x i1> %119, i64 6
  %2915 = and i1 %2911, %2913
  %2916 = and i1 %2914, %2915
  %2917 = extractelement <8 x i32> %2831, i32 %2912
  %2918 = select i1 %2916, i32 %2917, i32 0
  %2919 = insertelement <8 x i32> %2906, i32 %2918, i64 6
  %2920 = xor i1 %2916, true
  %2921 = and i1 %2914, %2920
  %2922 = insertelement <8 x i1> %2909, i1 %2921, i64 6
  %2923 = extractelement <8 x i32> %2725, i64 7
  %2924 = icmp ult i32 %2923, 8
  %2925 = select i1 %2924, i32 %2923, i32 0
  %2926 = extractelement <8 x i1> %119, i32 %2925
  %2927 = extractelement <8 x i1> %119, i64 7
  %2928 = and i1 %2924, %2926
  %2929 = and i1 %2927, %2928
  %2930 = extractelement <8 x i32> %2831, i32 %2925
  %2931 = select i1 %2929, i32 %2930, i32 0
  %2932 = insertelement <8 x i32> %2919, i32 %2931, i64 7
  %2933 = xor i1 %2929, true
  %2934 = and i1 %2927, %2933
  %2935 = insertelement <8 x i1> %2922, i1 %2934, i64 7
  %2936 = icmp ne <8 x i32> %2932, zeroinitializer
  %2937 = select <8 x i1> %2724, <8 x float> %2723, <8 x float> %2826
  %2938 = and <8 x i1> %2724, %2936
  %2939 = select <8 x i1> %2938, <8 x float> %2830, <8 x float> %2937
  %2940 = extractelement <8 x i1> %119, i32 0
  %2941 = extractelement <8 x i1> %119, i64 0
  %2942 = and i1 true, %2940
  %2943 = and i1 %2941, %2942
  %2944 = extractelement <8 x float> %2939, i32 0
  %2945 = select i1 %2943, float %2944, float 0.000000e+00
  %2946 = insertelement <8 x float> poison, float %2945, i64 0
  %2947 = xor i1 %2943, true
  %2948 = and i1 %2941, %2947
  %2949 = insertelement <8 x i1> poison, i1 %2948, i64 0
  %2950 = extractelement <8 x i1> %119, i32 0
  %2951 = extractelement <8 x i1> %119, i64 1
  %2952 = and i1 true, %2950
  %2953 = and i1 %2951, %2952
  %2954 = extractelement <8 x float> %2939, i32 0
  %2955 = select i1 %2953, float %2954, float 0.000000e+00
  %2956 = insertelement <8 x float> %2946, float %2955, i64 1
  %2957 = xor i1 %2953, true
  %2958 = and i1 %2951, %2957
  %2959 = insertelement <8 x i1> %2949, i1 %2958, i64 1
  %2960 = extractelement <8 x i1> %119, i32 0
  %2961 = extractelement <8 x i1> %119, i64 2
  %2962 = and i1 true, %2960
  %2963 = and i1 %2961, %2962
  %2964 = extractelement <8 x float> %2939, i32 0
  %2965 = select i1 %2963, float %2964, float 0.000000e+00
  %2966 = insertelement <8 x float> %2956, float %2965, i64 2
  %2967 = xor i1 %2963, true
  %2968 = and i1 %2961, %2967
  %2969 = insertelement <8 x i1> %2959, i1 %2968, i64 2
  %2970 = extractelement <8 x i1> %119, i32 0
  %2971 = extractelement <8 x i1> %119, i64 3
  %2972 = and i1 true, %2970
  %2973 = and i1 %2971, %2972
  %2974 = extractelement <8 x float> %2939, i32 0
  %2975 = select i1 %2973, float %2974, float 0.000000e+00
  %2976 = insertelement <8 x float> %2966, float %2975, i64 3
  %2977 = xor i1 %2973, true
  %2978 = and i1 %2971, %2977
  %2979 = insertelement <8 x i1> %2969, i1 %2978, i64 3
  %2980 = extractelement <8 x i1> %119, i32 0
  %2981 = extractelement <8 x i1> %119, i64 4
  %2982 = and i1 true, %2980
  %2983 = and i1 %2981, %2982
  %2984 = extractelement <8 x float> %2939, i32 0
  %2985 = select i1 %2983, float %2984, float 0.000000e+00
  %2986 = insertelement <8 x float> %2976, float %2985, i64 4
  %2987 = xor i1 %2983, true
  %2988 = and i1 %2981, %2987
  %2989 = insertelement <8 x i1> %2979, i1 %2988, i64 4
  %2990 = extractelement <8 x i1> %119, i32 0
  %2991 = extractelement <8 x i1> %119, i64 5
  %2992 = and i1 true, %2990
  %2993 = and i1 %2991, %2992
  %2994 = extractelement <8 x float> %2939, i32 0
  %2995 = select i1 %2993, float %2994, float 0.000000e+00
  %2996 = insertelement <8 x float> %2986, float %2995, i64 5
  %2997 = xor i1 %2993, true
  %2998 = and i1 %2991, %2997
  %2999 = insertelement <8 x i1> %2989, i1 %2998, i64 5
  %3000 = extractelement <8 x i1> %119, i32 0
  %3001 = extractelement <8 x i1> %119, i64 6
  %3002 = and i1 true, %3000
  %3003 = and i1 %3001, %3002
  %3004 = extractelement <8 x float> %2939, i32 0
  %3005 = select i1 %3003, float %3004, float 0.000000e+00
  %3006 = insertelement <8 x float> %2996, float %3005, i64 6
  %3007 = xor i1 %3003, true
  %3008 = and i1 %3001, %3007
  %3009 = insertelement <8 x i1> %2999, i1 %3008, i64 6
  %3010 = extractelement <8 x i1> %119, i32 0
  %3011 = extractelement <8 x i1> %119, i64 7
  %3012 = and i1 true, %3010
  %3013 = and i1 %3011, %3012
  %3014 = extractelement <8 x float> %2939, i32 0
  %3015 = select i1 %3013, float %3014, float 0.000000e+00
  %3016 = insertelement <8 x float> %3006, float %3015, i64 7
  %3017 = xor i1 %3013, true
  %3018 = and i1 %3011, %3017
  %3019 = insertelement <8 x i1> %3009, i1 %3018, i64 7
  %3020 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  %3021 = bitcast <8 x i1> %119 to i8
  %3022 = call i8 @llvm.cttz.i8(i8 %3021, i1 false)
  %3023 = zext i8 %3022 to i32
  %3024 = select i1 %3020, i32 %3023, i32 0
  %3025 = extractelement <8 x float> %3016, i32 %3024
  %3026 = call float @llvm.maxnum.f32(float 0xFFF0000000000000, float %3025)
  %tile_snapshot.spill.load672 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill199, align 64
  %3027 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load672, 0
  %3028 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load672, 1
  %.state673 = load <8 x i64>, ptr %.slot200, align 64
  %3029 = mul <8 x i64> %.state673, splat (i64 32)
  %3030 = add <8 x i64> %3028, %3029
  %3031 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3027, 0
  %3032 = insertvalue { <8 x ptr>, <8 x i64> } %3031, <8 x i64> %3030, 1
  %.splatinsert674 = insertelement <8 x float> poison, float %3026, i64 0
  %.splat675 = shufflevector <8 x float> %.splatinsert674, <8 x float> poison, <8 x i32> zeroinitializer
  %3033 = extractvalue { <8 x ptr>, <8 x i64> } %47, 0
  %3034 = extractvalue { <8 x ptr>, <8 x i64> } %3032, 1
  %3035 = extractelement <8 x ptr> %3033, i32 0
  %3036 = extractelement <8 x i64> %3034, i32 0
  %3037 = sub i64 %3036, 0
  %3038 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  %3039 = select i1 %3038, i64 %3037, i64 0
  %private.contiguous.address676 = getelementptr i8, ptr %3035, i64 %3039
  %private.contiguous.preserve677 = load <8 x float>, ptr %private.contiguous.address676, align 4
  %3040 = select <8 x i1> %119, <8 x float> %.splat675, <8 x float> %private.contiguous.preserve677
  store <8 x float> %3040, ptr %private.contiguous.address676, align 4
  %.state678 = load <8 x i64>, ptr %.slot200, align 64
  %3041 = add <8 x i64> %.state678, splat (i64 1)
  %3042 = load <8 x i64>, ptr %.slot200, align 64
  %3043 = select <8 x i1> %119, <8 x i64> %3041, <8 x i64> %3042
  store <8 x i64> %3043, ptr %.slot200, align 64
  br label %direct.schedule.142

direct.schedule.149:                              ; preds = %direct.false643
  %3044 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %3045 = extractvalue { <8 x ptr>, <8 x i64> } %49, 0
  %3046 = extractvalue { <8 x ptr>, <8 x i64> } %3044, 0
  %3047 = select <8 x i1> %119, <8 x ptr> %3045, <8 x ptr> %3046
  %3048 = extractvalue { <8 x ptr>, <8 x i64> } %49, 1
  %3049 = extractvalue { <8 x ptr>, <8 x i64> } %3044, 1
  %3050 = select <8 x i1> %119, <8 x i64> %3048, <8 x i64> %3049
  %3051 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3047, 0
  %3052 = insertvalue { <8 x ptr>, <8 x i64> } %3051, <8 x i64> %3050, 1
  store { <8 x ptr>, <8 x i64> } %3052, ptr %tile_snapshot.spill207, align 64
  %3053 = load <8 x i64>, ptr %.slot208, align 64
  %3054 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3053
  store <8 x i64> %3054, ptr %.slot208, align 64
  br label %direct.schedule.150

direct.schedule.150:                              ; preds = %direct.schedule.157, %direct.schedule.149
  %.state679 = load <8 x i64>, ptr %.slot208, align 64
  %3055 = icmp slt <8 x i64> %.state679, splat (i64 1)
  %3056 = extractelement <8 x i1> %3055, i32 0
  br i1 %3056, label %direct.true680, label %direct.false681

direct.schedule.151:                              ; preds = %direct.true680
  %.state682 = load <8 x i64>, ptr %.slot208, align 64
  %3057 = select <8 x i1> %119, <8 x i64> %.state682, <8 x i64> zeroinitializer
  %3058 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3059 = srem <8 x i64> %3057, %3058
  %3060 = mul <8 x i64> %3059, splat (i64 8)
  %.spill.load683 = load <8 x i64>, ptr %.spill, align 64
  %3061 = add <8 x i64> %3060, %.spill.load683
  %3062 = icmp slt <8 x i64> %3061, splat (i64 2)
  %3063 = load <8 x i1>, ptr %.spill209, align 1
  %3064 = select <8 x i1> %119, <8 x i1> %3062, <8 x i1> %3063
  store <8 x i1> %3064, ptr %.spill209, align 1
  %3065 = select <8 x i1> %3062, <8 x i64> %3061, <8 x i64> splat (i64 1)
  %3066 = add <8 x i64> zeroinitializer, %3065
  %3067 = load <8 x i64>, ptr %.spill210, align 64
  %3068 = select <8 x i1> %119, <8 x i64> %3066, <8 x i64> %3067
  store <8 x i64> %3068, ptr %.spill210, align 64
  %3069 = add <8 x i64> zeroinitializer, %3059
  %3070 = and <8 x i1> %119, %3062
  %3071 = xor <8 x i1> %3062, splat (i1 true)
  %3072 = and <8 x i1> %119, %3071
  %3073 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3070)
  %3074 = bitcast <8 x i1> %3070 to i8
  %3075 = call i8 @llvm.cttz.i8(i8 %3074, i1 false)
  %3076 = zext i8 %3075 to i32
  %3077 = select i1 %3073, i32 %3076, i32 0
  %tile_snapshot.spill.load684 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %3078 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load684, 0
  %3079 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load684, 1
  %3080 = mul <8 x i64> %3069, splat (i64 32)
  %3081 = add <8 x i64> %3079, %3080
  %3082 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3078, 0
  %3083 = insertvalue { <8 x ptr>, <8 x i64> } %3082, <8 x i64> %3081, 1
  %3084 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3085 = extractvalue { <8 x ptr>, <8 x i64> } %3083, 1
  %3086 = extractelement <8 x ptr> %3084, i32 0
  %3087 = extractelement <8 x i64> %3085, i32 %3077
  %3088 = zext i32 %3077 to i64
  %3089 = mul i64 %3088, 4
  %3090 = sub i64 %3087, %3089
  %3091 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3070)
  %3092 = select i1 %3091, i64 %3090, i64 0
  %private.contiguous.address685 = getelementptr i8, ptr %3086, i64 %3092
  %private.contiguous.load686 = load <8 x float>, ptr %private.contiguous.address685, align 4
  %3093 = select <8 x i1> %3070, <8 x float> %private.contiguous.load686, <8 x float> zeroinitializer
  %3094 = load <8 x float>, ptr %.slot211, align 32
  %3095 = select <8 x i1> %3070, <8 x float> %3093, <8 x float> %3094
  store <8 x float> %3095, ptr %.slot211, align 32
  %3096 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3072)
  %3097 = bitcast <8 x i1> %3072 to i8
  %3098 = call i8 @llvm.cttz.i8(i8 %3097, i1 false)
  %3099 = zext i8 %3098 to i32
  %3100 = select i1 %3096, i32 %3099, i32 0
  %3101 = load <8 x float>, ptr %.slot211, align 32
  %3102 = select <8 x i1> %3072, <8 x float> zeroinitializer, <8 x float> %3101
  store <8 x float> %3102, ptr %.slot211, align 32
  br label %direct.schedule.153

direct.schedule.153:                              ; preds = %direct.schedule.151
  %.spill.load687 = load <8 x i1>, ptr %.spill209, align 1
  %3103 = and <8 x i1> %119, %.spill.load687
  %3104 = xor <8 x i1> %.spill.load687, splat (i1 true)
  %3105 = and <8 x i1> %119, %3104
  %3106 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3103)
  %3107 = bitcast <8 x i1> %3103 to i8
  %3108 = call i8 @llvm.cttz.i8(i8 %3107, i1 false)
  %3109 = zext i8 %3108 to i32
  %3110 = select i1 %3106, i32 %3109, i32 0
  %tile_snapshot.spill.load688 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill199, align 64
  %3111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load688, 0
  %3112 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load688, 1
  %.spill.load689 = load <8 x i64>, ptr %.spill210, align 64
  %3113 = mul <8 x i64> %.spill.load689, splat (i64 32)
  %3114 = add <8 x i64> %3112, %3113
  %3115 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3111, 0
  %3116 = insertvalue { <8 x ptr>, <8 x i64> } %3115, <8 x i64> %3114, 1
  %3117 = extractvalue { <8 x ptr>, <8 x i64> } %3116, 0
  %3118 = extractvalue { <8 x ptr>, <8 x i64> } %3116, 1
  %3119 = getelementptr i8, <8 x ptr> %3117, <8 x i64> %3118
  %3120 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %3119, <8 x i1> %3103, <8 x float> zeroinitializer)
  %3121 = load <8 x float>, ptr %.slot212, align 32
  %3122 = select <8 x i1> %3103, <8 x float> %3120, <8 x float> %3121
  store <8 x float> %3122, ptr %.slot212, align 32
  %3123 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3105)
  %3124 = bitcast <8 x i1> %3105 to i8
  %3125 = call i8 @llvm.cttz.i8(i8 %3124, i1 false)
  %3126 = zext i8 %3125 to i32
  %3127 = select i1 %3123, i32 %3126, i32 0
  %3128 = load <8 x float>, ptr %.slot212, align 32
  %3129 = select <8 x i1> %3105, <8 x float> zeroinitializer, <8 x float> %3128
  store <8 x float> %3129, ptr %.slot212, align 32
  br label %direct.schedule.155

direct.schedule.155:                              ; preds = %direct.schedule.153
  %.state690 = load <8 x float>, ptr %.slot211, align 32
  %.state691 = load <8 x float>, ptr %.slot212, align 32
  %3130 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state690, <8 x float> %.state691)
  %.spill.load692 = load <8 x i1>, ptr %.spill209, align 1
  %3131 = and <8 x i1> %119, %.spill.load692
  %3132 = xor <8 x i1> %.spill.load692, splat (i1 true)
  %3133 = and <8 x i1> %119, %3132
  %3134 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3131)
  %3135 = bitcast <8 x i1> %3131 to i8
  %3136 = call i8 @llvm.cttz.i8(i8 %3135, i1 false)
  %3137 = zext i8 %3136 to i32
  %3138 = select i1 %3134, i32 %3137, i32 0
  %tile_snapshot.spill.load693 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %3139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load693, 0
  %3140 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load693, 1
  %.state694 = load <8 x i64>, ptr %.slot208, align 64
  %3141 = mul <8 x i64> %.state694, splat (i64 32)
  %3142 = add <8 x i64> %3140, %3141
  %3143 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3139, 0
  %3144 = insertvalue { <8 x ptr>, <8 x i64> } %3143, <8 x i64> %3142, 1
  %3145 = extractvalue { <8 x ptr>, <8 x i64> } %49, 0
  %3146 = extractvalue { <8 x ptr>, <8 x i64> } %3144, 1
  %3147 = extractelement <8 x ptr> %3145, i32 0
  %3148 = extractelement <8 x i64> %3146, i32 %3138
  %3149 = zext i32 %3138 to i64
  %3150 = mul i64 %3149, 4
  %3151 = sub i64 %3148, %3150
  %3152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3131)
  %3153 = select i1 %3152, i64 %3151, i64 0
  %private.contiguous.address695 = getelementptr i8, ptr %3147, i64 %3153
  %private.contiguous.preserve696 = load <8 x float>, ptr %private.contiguous.address695, align 4
  %3154 = select <8 x i1> %3131, <8 x float> %3130, <8 x float> %private.contiguous.preserve696
  store <8 x float> %3154, ptr %private.contiguous.address695, align 4
  %3155 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3133)
  %3156 = bitcast <8 x i1> %3133 to i8
  %3157 = call i8 @llvm.cttz.i8(i8 %3156, i1 false)
  %3158 = zext i8 %3157 to i32
  %3159 = select i1 %3155, i32 %3158, i32 0
  br label %direct.schedule.157

direct.schedule.157:                              ; preds = %direct.schedule.155
  %.state697 = load <8 x i64>, ptr %.slot208, align 64
  %3160 = add <8 x i64> %.state697, splat (i64 1)
  %3161 = load <8 x i64>, ptr %.slot208, align 64
  %3162 = select <8 x i1> %119, <8 x i64> %3160, <8 x i64> %3161
  store <8 x i64> %3162, ptr %.slot208, align 64
  br label %direct.schedule.150

direct.schedule.158:                              ; preds = %direct.false681
  %3163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill213, align 64
  %3164 = extractvalue { <8 x ptr>, <8 x i64> } %51, 0
  %3165 = extractvalue { <8 x ptr>, <8 x i64> } %3163, 0
  %3166 = select <8 x i1> %119, <8 x ptr> %3164, <8 x ptr> %3165
  %3167 = extractvalue { <8 x ptr>, <8 x i64> } %51, 1
  %3168 = extractvalue { <8 x ptr>, <8 x i64> } %3163, 1
  %3169 = select <8 x i1> %119, <8 x i64> %3167, <8 x i64> %3168
  %3170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3166, 0
  %3171 = insertvalue { <8 x ptr>, <8 x i64> } %3170, <8 x i64> %3169, 1
  store { <8 x ptr>, <8 x i64> } %3171, ptr %tile_snapshot.spill213, align 64
  %3172 = load <8 x i64>, ptr %.slot214, align 64
  %3173 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3172
  store <8 x i64> %3173, ptr %.slot214, align 64
  br label %direct.schedule.159

direct.schedule.159:                              ; preds = %direct.schedule.166, %direct.schedule.158
  %.state698 = load <8 x i64>, ptr %.slot214, align 64
  %3174 = icmp slt <8 x i64> %.state698, splat (i64 1)
  %3175 = extractelement <8 x i1> %3174, i32 0
  br i1 %3175, label %direct.true699, label %direct.false700

direct.schedule.160:                              ; preds = %direct.true699
  %.state701 = load <8 x i64>, ptr %.slot214, align 64
  %3176 = select <8 x i1> %119, <8 x i64> %.state701, <8 x i64> zeroinitializer
  %3177 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3178 = srem <8 x i64> %3176, %3177
  %3179 = mul <8 x i64> %3178, splat (i64 8)
  %.spill.load702 = load <8 x i64>, ptr %.spill, align 64
  %3180 = add <8 x i64> %3179, %.spill.load702
  %3181 = icmp slt <8 x i64> %3180, splat (i64 2)
  %3182 = load <8 x i1>, ptr %.spill215, align 1
  %3183 = select <8 x i1> %119, <8 x i1> %3181, <8 x i1> %3182
  store <8 x i1> %3183, ptr %.spill215, align 1
  %3184 = add <8 x i64> zeroinitializer, %3178
  %3185 = load <8 x i64>, ptr %.spill216, align 64
  %3186 = select <8 x i1> %119, <8 x i64> %3184, <8 x i64> %3185
  store <8 x i64> %3186, ptr %.spill216, align 64
  %3187 = and <8 x i1> %119, %3181
  %3188 = xor <8 x i1> %3181, splat (i1 true)
  %3189 = and <8 x i1> %119, %3188
  %3190 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3187)
  %3191 = bitcast <8 x i1> %3187 to i8
  %3192 = call i8 @llvm.cttz.i8(i8 %3191, i1 false)
  %3193 = zext i8 %3192 to i32
  %3194 = select i1 %3190, i32 %3193, i32 0
  %tile_snapshot.spill.load703 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %3195 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 0
  %3196 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load703, 1
  %3197 = mul <8 x i64> %3184, splat (i64 32)
  %3198 = add <8 x i64> %3196, %3197
  %3199 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3195, 0
  %3200 = insertvalue { <8 x ptr>, <8 x i64> } %3199, <8 x i64> %3198, 1
  %3201 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %3202 = extractvalue { <8 x ptr>, <8 x i64> } %3200, 1
  %3203 = extractelement <8 x ptr> %3201, i32 0
  %3204 = extractelement <8 x i64> %3202, i32 %3194
  %3205 = zext i32 %3194 to i64
  %3206 = mul i64 %3205, 4
  %3207 = sub i64 %3204, %3206
  %3208 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3187)
  %3209 = select i1 %3208, i64 %3207, i64 0
  %private.contiguous.address704 = getelementptr i8, ptr %3203, i64 %3209
  %private.contiguous.load705 = load <8 x float>, ptr %private.contiguous.address704, align 4
  %3210 = select <8 x i1> %3187, <8 x float> %private.contiguous.load705, <8 x float> zeroinitializer
  %3211 = load <8 x float>, ptr %.slot217, align 32
  %3212 = select <8 x i1> %3187, <8 x float> %3210, <8 x float> %3211
  store <8 x float> %3212, ptr %.slot217, align 32
  %3213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3189)
  %3214 = bitcast <8 x i1> %3189 to i8
  %3215 = call i8 @llvm.cttz.i8(i8 %3214, i1 false)
  %3216 = zext i8 %3215 to i32
  %3217 = select i1 %3213, i32 %3216, i32 0
  %3218 = load <8 x float>, ptr %.slot217, align 32
  %3219 = select <8 x i1> %3189, <8 x float> zeroinitializer, <8 x float> %3218
  store <8 x float> %3219, ptr %.slot217, align 32
  br label %direct.schedule.162

direct.schedule.162:                              ; preds = %direct.schedule.160
  %.spill.load706 = load <8 x i1>, ptr %.spill215, align 1
  %3220 = and <8 x i1> %119, %.spill.load706
  %3221 = xor <8 x i1> %.spill.load706, splat (i1 true)
  %3222 = and <8 x i1> %119, %3221
  %3223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3220)
  %3224 = bitcast <8 x i1> %3220 to i8
  %3225 = call i8 @llvm.cttz.i8(i8 %3224, i1 false)
  %3226 = zext i8 %3225 to i32
  %3227 = select i1 %3223, i32 %3226, i32 0
  %tile_snapshot.spill.load707 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %3228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load707, 0
  %3229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load707, 1
  %.spill.load708 = load <8 x i64>, ptr %.spill216, align 64
  %3230 = mul <8 x i64> %.spill.load708, splat (i64 32)
  %3231 = add <8 x i64> %3229, %3230
  %3232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3228, 0
  %3233 = insertvalue { <8 x ptr>, <8 x i64> } %3232, <8 x i64> %3231, 1
  %3234 = extractvalue { <8 x ptr>, <8 x i64> } %49, 0
  %3235 = extractvalue { <8 x ptr>, <8 x i64> } %3233, 1
  %3236 = extractelement <8 x ptr> %3234, i32 0
  %3237 = extractelement <8 x i64> %3235, i32 %3227
  %3238 = zext i32 %3227 to i64
  %3239 = mul i64 %3238, 4
  %3240 = sub i64 %3237, %3239
  %3241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3220)
  %3242 = select i1 %3241, i64 %3240, i64 0
  %private.contiguous.address709 = getelementptr i8, ptr %3236, i64 %3242
  %private.contiguous.load710 = load <8 x float>, ptr %private.contiguous.address709, align 4
  %3243 = select <8 x i1> %3220, <8 x float> %private.contiguous.load710, <8 x float> zeroinitializer
  %3244 = load <8 x float>, ptr %.slot218, align 32
  %3245 = select <8 x i1> %3220, <8 x float> %3243, <8 x float> %3244
  store <8 x float> %3245, ptr %.slot218, align 32
  %3246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3222)
  %3247 = bitcast <8 x i1> %3222 to i8
  %3248 = call i8 @llvm.cttz.i8(i8 %3247, i1 false)
  %3249 = zext i8 %3248 to i32
  %3250 = select i1 %3246, i32 %3249, i32 0
  %3251 = load <8 x float>, ptr %.slot218, align 32
  %3252 = select <8 x i1> %3222, <8 x float> zeroinitializer, <8 x float> %3251
  store <8 x float> %3252, ptr %.slot218, align 32
  br label %direct.schedule.164

direct.schedule.164:                              ; preds = %direct.schedule.162
  %.state711 = load <8 x float>, ptr %.slot217, align 32
  %.state712 = load <8 x float>, ptr %.slot218, align 32
  %3253 = fsub <8 x float> %.state711, %.state712
  %.spill.load713 = load <8 x i1>, ptr %.spill215, align 1
  %3254 = and <8 x i1> %119, %.spill.load713
  %3255 = xor <8 x i1> %.spill.load713, splat (i1 true)
  %3256 = and <8 x i1> %119, %3255
  %3257 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3254)
  %3258 = bitcast <8 x i1> %3254 to i8
  %3259 = call i8 @llvm.cttz.i8(i8 %3258, i1 false)
  %3260 = zext i8 %3259 to i32
  %3261 = select i1 %3257, i32 %3260, i32 0
  %tile_snapshot.spill.load714 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill213, align 64
  %3262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load714, 0
  %3263 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load714, 1
  %.state715 = load <8 x i64>, ptr %.slot214, align 64
  %3264 = mul <8 x i64> %.state715, splat (i64 32)
  %3265 = add <8 x i64> %3263, %3264
  %3266 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3262, 0
  %3267 = insertvalue { <8 x ptr>, <8 x i64> } %3266, <8 x i64> %3265, 1
  %3268 = extractvalue { <8 x ptr>, <8 x i64> } %51, 0
  %3269 = extractvalue { <8 x ptr>, <8 x i64> } %3267, 1
  %3270 = extractelement <8 x ptr> %3268, i32 0
  %3271 = extractelement <8 x i64> %3269, i32 %3261
  %3272 = zext i32 %3261 to i64
  %3273 = mul i64 %3272, 4
  %3274 = sub i64 %3271, %3273
  %3275 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3254)
  %3276 = select i1 %3275, i64 %3274, i64 0
  %private.contiguous.address716 = getelementptr i8, ptr %3270, i64 %3276
  %private.contiguous.preserve717 = load <8 x float>, ptr %private.contiguous.address716, align 4
  %3277 = select <8 x i1> %3254, <8 x float> %3253, <8 x float> %private.contiguous.preserve717
  store <8 x float> %3277, ptr %private.contiguous.address716, align 4
  %3278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3256)
  %3279 = bitcast <8 x i1> %3256 to i8
  %3280 = call i8 @llvm.cttz.i8(i8 %3279, i1 false)
  %3281 = zext i8 %3280 to i32
  %3282 = select i1 %3278, i32 %3281, i32 0
  br label %direct.schedule.166

direct.schedule.166:                              ; preds = %direct.schedule.164
  %.state718 = load <8 x i64>, ptr %.slot214, align 64
  %3283 = add <8 x i64> %.state718, splat (i64 1)
  %3284 = load <8 x i64>, ptr %.slot214, align 64
  %3285 = select <8 x i1> %119, <8 x i64> %3283, <8 x i64> %3284
  store <8 x i64> %3285, ptr %.slot214, align 64
  br label %direct.schedule.159

direct.schedule.167:                              ; preds = %direct.false700
  %3286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill219, align 64
  %3287 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %3288 = extractvalue { <8 x ptr>, <8 x i64> } %3286, 0
  %3289 = select <8 x i1> %119, <8 x ptr> %3287, <8 x ptr> %3288
  %3290 = extractvalue { <8 x ptr>, <8 x i64> } %53, 1
  %3291 = extractvalue { <8 x ptr>, <8 x i64> } %3286, 1
  %3292 = select <8 x i1> %119, <8 x i64> %3290, <8 x i64> %3291
  %3293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3289, 0
  %3294 = insertvalue { <8 x ptr>, <8 x i64> } %3293, <8 x i64> %3292, 1
  store { <8 x ptr>, <8 x i64> } %3294, ptr %tile_snapshot.spill219, align 64
  %3295 = load <8 x i64>, ptr %.slot220, align 64
  %3296 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3295
  store <8 x i64> %3296, ptr %.slot220, align 64
  br label %direct.schedule.168

direct.schedule.168:                              ; preds = %direct.schedule.173, %direct.schedule.167
  %.state719 = load <8 x i64>, ptr %.slot220, align 64
  %3297 = icmp slt <8 x i64> %.state719, splat (i64 1)
  %3298 = extractelement <8 x i1> %3297, i32 0
  br i1 %3298, label %direct.true720, label %direct.false721

direct.schedule.169:                              ; preds = %direct.true720
  %.state722 = load <8 x i64>, ptr %.slot220, align 64
  %3299 = select <8 x i1> %119, <8 x i64> %.state722, <8 x i64> zeroinitializer
  %3300 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3301 = srem <8 x i64> %3299, %3300
  %3302 = mul <8 x i64> %3301, splat (i64 8)
  %.spill.load723 = load <8 x i64>, ptr %.spill, align 64
  %3303 = add <8 x i64> %3302, %.spill.load723
  %3304 = icmp slt <8 x i64> %3303, splat (i64 2)
  %3305 = load <8 x i1>, ptr %.spill221, align 1
  %3306 = select <8 x i1> %119, <8 x i1> %3304, <8 x i1> %3305
  store <8 x i1> %3306, ptr %.spill221, align 1
  %3307 = add <8 x i64> zeroinitializer, %3301
  %3308 = and <8 x i1> %119, %3304
  %3309 = xor <8 x i1> %3304, splat (i1 true)
  %3310 = and <8 x i1> %119, %3309
  %3311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3308)
  %3312 = bitcast <8 x i1> %3308 to i8
  %3313 = call i8 @llvm.cttz.i8(i8 %3312, i1 false)
  %3314 = zext i8 %3313 to i32
  %3315 = select i1 %3311, i32 %3314, i32 0
  %tile_snapshot.spill.load724 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill213, align 64
  %3316 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load724, 0
  %3317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load724, 1
  %3318 = mul <8 x i64> %3307, splat (i64 32)
  %3319 = add <8 x i64> %3317, %3318
  %3320 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3316, 0
  %3321 = insertvalue { <8 x ptr>, <8 x i64> } %3320, <8 x i64> %3319, 1
  %3322 = extractvalue { <8 x ptr>, <8 x i64> } %51, 0
  %3323 = extractvalue { <8 x ptr>, <8 x i64> } %3321, 1
  %3324 = extractelement <8 x ptr> %3322, i32 0
  %3325 = extractelement <8 x i64> %3323, i32 %3315
  %3326 = zext i32 %3315 to i64
  %3327 = mul i64 %3326, 4
  %3328 = sub i64 %3325, %3327
  %3329 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3308)
  %3330 = select i1 %3329, i64 %3328, i64 0
  %private.contiguous.address725 = getelementptr i8, ptr %3324, i64 %3330
  %private.contiguous.load726 = load <8 x float>, ptr %private.contiguous.address725, align 4
  %3331 = select <8 x i1> %3308, <8 x float> %private.contiguous.load726, <8 x float> zeroinitializer
  %3332 = load <8 x float>, ptr %.slot222, align 32
  %3333 = select <8 x i1> %3308, <8 x float> %3331, <8 x float> %3332
  store <8 x float> %3333, ptr %.slot222, align 32
  %3334 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3310)
  %3335 = bitcast <8 x i1> %3310 to i8
  %3336 = call i8 @llvm.cttz.i8(i8 %3335, i1 false)
  %3337 = zext i8 %3336 to i32
  %3338 = select i1 %3334, i32 %3337, i32 0
  %3339 = load <8 x float>, ptr %.slot222, align 32
  %3340 = select <8 x i1> %3310, <8 x float> zeroinitializer, <8 x float> %3339
  store <8 x float> %3340, ptr %.slot222, align 32
  br label %direct.schedule.171

direct.schedule.171:                              ; preds = %direct.schedule.169
  %.state727 = load <8 x float>, ptr %.slot222, align 32
  %3341 = select <8 x i1> %119, <8 x float> %.state727, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3341)
  %.spill.load728 = load <8 x i1>, ptr %.spill221, align 1
  %3342 = and <8 x i1> %119, %.spill.load728
  %3343 = xor <8 x i1> %.spill.load728, splat (i1 true)
  %3344 = and <8 x i1> %119, %3343
  %3345 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3342)
  %3346 = bitcast <8 x i1> %3342 to i8
  %3347 = call i8 @llvm.cttz.i8(i8 %3346, i1 false)
  %3348 = zext i8 %3347 to i32
  %3349 = select i1 %3345, i32 %3348, i32 0
  %tile_snapshot.spill.load729 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill219, align 64
  %3350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load729, 0
  %3351 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load729, 1
  %.state730 = load <8 x i64>, ptr %.slot220, align 64
  %3352 = mul <8 x i64> %.state730, splat (i64 32)
  %3353 = add <8 x i64> %3351, %3352
  %3354 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3350, 0
  %3355 = insertvalue { <8 x ptr>, <8 x i64> } %3354, <8 x i64> %3353, 1
  %3356 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %3357 = extractvalue { <8 x ptr>, <8 x i64> } %3355, 1
  %3358 = extractelement <8 x ptr> %3356, i32 0
  %3359 = extractelement <8 x i64> %3357, i32 %3349
  %3360 = zext i32 %3349 to i64
  %3361 = mul i64 %3360, 4
  %3362 = sub i64 %3359, %3361
  %3363 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3342)
  %3364 = select i1 %3363, i64 %3362, i64 0
  %private.contiguous.address731 = getelementptr i8, ptr %3358, i64 %3364
  %private.contiguous.preserve732 = load <8 x float>, ptr %private.contiguous.address731, align 4
  %3365 = select <8 x i1> %3342, <8 x float> %native.exp, <8 x float> %private.contiguous.preserve732
  store <8 x float> %3365, ptr %private.contiguous.address731, align 4
  %3366 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3344)
  %3367 = bitcast <8 x i1> %3344 to i8
  %3368 = call i8 @llvm.cttz.i8(i8 %3367, i1 false)
  %3369 = zext i8 %3368 to i32
  %3370 = select i1 %3366, i32 %3369, i32 0
  br label %direct.schedule.173

direct.schedule.173:                              ; preds = %direct.schedule.171
  %.state733 = load <8 x i64>, ptr %.slot220, align 64
  %3371 = add <8 x i64> %.state733, splat (i64 1)
  %3372 = load <8 x i64>, ptr %.slot220, align 64
  %3373 = select <8 x i1> %119, <8 x i64> %3371, <8 x i64> %3372
  store <8 x i64> %3373, ptr %.slot220, align 64
  br label %direct.schedule.168

direct.schedule.174:                              ; preds = %direct.false721
  %3374 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill223, align 64
  %3375 = extractvalue { <8 x ptr>, <8 x i64> } %55, 0
  %3376 = extractvalue { <8 x ptr>, <8 x i64> } %3374, 0
  %3377 = select <8 x i1> %119, <8 x ptr> %3375, <8 x ptr> %3376
  %3378 = extractvalue { <8 x ptr>, <8 x i64> } %55, 1
  %3379 = extractvalue { <8 x ptr>, <8 x i64> } %3374, 1
  %3380 = select <8 x i1> %119, <8 x i64> %3378, <8 x i64> %3379
  %3381 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3377, 0
  %3382 = insertvalue { <8 x ptr>, <8 x i64> } %3381, <8 x i64> %3380, 1
  store { <8 x ptr>, <8 x i64> } %3382, ptr %tile_snapshot.spill223, align 64
  %3383 = load <8 x i64>, ptr %.slot224, align 64
  %3384 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3383
  store <8 x i64> %3384, ptr %.slot224, align 64
  br label %direct.schedule.175

direct.schedule.175:                              ; preds = %direct.schedule.182, %direct.schedule.174
  %.state734 = load <8 x i64>, ptr %.slot224, align 64
  %3385 = icmp slt <8 x i64> %.state734, splat (i64 10)
  %3386 = extractelement <8 x i1> %3385, i32 0
  br i1 %3386, label %direct.true735, label %direct.false736

direct.schedule.176:                              ; preds = %direct.true735
  %.state737 = load <8 x i64>, ptr %.slot224, align 64
  %3387 = select <8 x i1> %119, <8 x i64> %.state737, <8 x i64> zeroinitializer
  %3388 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3389 = srem <8 x i64> %3387, %3388
  %.state738 = load <8 x i64>, ptr %.slot224, align 64
  %3390 = select <8 x i1> %119, <8 x i64> %.state738, <8 x i64> zeroinitializer
  %3391 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3392 = sdiv <8 x i64> %3390, %3391
  %3393 = mul <8 x i64> %3389, splat (i64 8)
  %.spill.load739 = load <8 x i64>, ptr %.spill, align 64
  %3394 = add <8 x i64> %3393, %.spill.load739
  %3395 = icmp slt <8 x i64> %3394, splat (i64 33)
  %3396 = load <8 x i1>, ptr %.spill225, align 1
  %3397 = select <8 x i1> %119, <8 x i1> %3395, <8 x i1> %3396
  store <8 x i1> %3397, ptr %.spill225, align 1
  %3398 = select <8 x i1> %119, <8 x i64> %3392, <8 x i64> zeroinitializer
  %3399 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3400 = srem <8 x i64> %3398, %3399
  %3401 = load <8 x i64>, ptr %.spill226, align 64
  %3402 = select <8 x i1> %119, <8 x i64> %3400, <8 x i64> %3401
  store <8 x i64> %3402, ptr %.spill226, align 64
  store i64 0, ptr %.spill227, align 4
  %3403 = add <8 x i64> zeroinitializer, %3400
  %3404 = mul <8 x i64> %3403, splat (i64 5)
  %3405 = add <8 x i64> %3404, %3389
  %3406 = and <8 x i1> %119, %3395
  %3407 = xor <8 x i1> %3395, splat (i1 true)
  %3408 = and <8 x i1> %119, %3407
  %3409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3406)
  %3410 = bitcast <8 x i1> %3406 to i8
  %3411 = call i8 @llvm.cttz.i8(i8 %3410, i1 false)
  %3412 = zext i8 %3411 to i32
  %3413 = select i1 %3409, i32 %3412, i32 0
  %tile_snapshot.spill.load740 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill191, align 64
  %3414 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load740, 0
  %3415 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load740, 1
  %3416 = mul <8 x i64> %3405, splat (i64 32)
  %3417 = add <8 x i64> %3415, %3416
  %3418 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3414, 0
  %3419 = insertvalue { <8 x ptr>, <8 x i64> } %3418, <8 x i64> %3417, 1
  %3420 = extractvalue { <8 x ptr>, <8 x i64> } %45, 0
  %3421 = extractvalue { <8 x ptr>, <8 x i64> } %3419, 1
  %3422 = extractelement <8 x ptr> %3420, i32 0
  %3423 = extractelement <8 x i64> %3421, i32 %3413
  %3424 = zext i32 %3413 to i64
  %3425 = mul i64 %3424, 4
  %3426 = sub i64 %3423, %3425
  %3427 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3406)
  %3428 = select i1 %3427, i64 %3426, i64 0
  %private.contiguous.address741 = getelementptr i8, ptr %3422, i64 %3428
  %private.contiguous.load742 = load <8 x float>, ptr %private.contiguous.address741, align 4
  %3429 = select <8 x i1> %3406, <8 x float> %private.contiguous.load742, <8 x float> zeroinitializer
  %3430 = load <8 x float>, ptr %.slot228, align 32
  %3431 = select <8 x i1> %3406, <8 x float> %3429, <8 x float> %3430
  store <8 x float> %3431, ptr %.slot228, align 32
  %3432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3408)
  %3433 = bitcast <8 x i1> %3408 to i8
  %3434 = call i8 @llvm.cttz.i8(i8 %3433, i1 false)
  %3435 = zext i8 %3434 to i32
  %3436 = select i1 %3432, i32 %3435, i32 0
  %3437 = load <8 x float>, ptr %.slot228, align 32
  %3438 = select <8 x i1> %3408, <8 x float> zeroinitializer, <8 x float> %3437
  store <8 x float> %3438, ptr %.slot228, align 32
  br label %direct.schedule.178

direct.schedule.178:                              ; preds = %direct.schedule.176
  %.spill.load743 = load <8 x i64>, ptr %.spill226, align 64
  %3439 = select <8 x i1> %119, <8 x i64> %.spill.load743, <8 x i64> zeroinitializer
  %3440 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %3441 = sdiv <8 x i64> %3439, %3440
  %.spill.load744 = load i64, ptr %.spill227, align 4
  %3442 = mul i64 %.spill.load744, 1
  %.splatinsert745 = insertelement <8 x i64> poison, i64 %3442, i64 0
  %.splat746 = shufflevector <8 x i64> %.splatinsert745, <8 x i64> poison, <8 x i32> zeroinitializer
  %3443 = add <8 x i64> %.splat746, %3441
  %.spill.load747 = load <8 x i64>, ptr %.spill226, align 64
  %3444 = select <8 x i1> %119, <8 x i64> %.spill.load747, <8 x i64> zeroinitializer
  %3445 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %3446 = srem <8 x i64> %3444, %3445
  %3447 = load <8 x i64>, ptr %.spill229, align 64
  %3448 = select <8 x i1> %119, <8 x i64> %3446, <8 x i64> %3447
  store <8 x i64> %3448, ptr %.spill229, align 64
  %.spill.load748 = load <8 x i64>, ptr %.spill, align 64
  %3449 = icmp eq <8 x i64> %.spill.load748, %3446
  %3450 = and <8 x i1> %119, %3449
  %3451 = xor <8 x i1> %3449, splat (i1 true)
  %3452 = and <8 x i1> %119, %3451
  %3453 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3450)
  %3454 = bitcast <8 x i1> %3450 to i8
  %3455 = call i8 @llvm.cttz.i8(i8 %3454, i1 false)
  %3456 = zext i8 %3455 to i32
  %3457 = select i1 %3453, i32 %3456, i32 0
  %tile_snapshot.spill.load749 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %3458 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load749, 0
  %3459 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load749, 1
  %3460 = mul <8 x i64> %3443, splat (i64 32)
  %3461 = add <8 x i64> %3459, %3460
  %3462 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3458, 0
  %3463 = insertvalue { <8 x ptr>, <8 x i64> } %3462, <8 x i64> %3461, 1
  %3464 = extractvalue { <8 x ptr>, <8 x i64> } %49, 0
  %3465 = extractvalue { <8 x ptr>, <8 x i64> } %3463, 1
  %3466 = extractelement <8 x ptr> %3464, i32 0
  %3467 = extractelement <8 x i64> %3465, i32 %3457
  %3468 = zext i32 %3457 to i64
  %3469 = mul i64 %3468, 4
  %3470 = sub i64 %3467, %3469
  %3471 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3450)
  %3472 = select i1 %3471, i64 %3470, i64 0
  %private.contiguous.address750 = getelementptr i8, ptr %3466, i64 %3472
  %private.contiguous.load751 = load <8 x float>, ptr %private.contiguous.address750, align 4
  %3473 = select <8 x i1> %3450, <8 x float> %private.contiguous.load751, <8 x float> zeroinitializer
  %3474 = load <8 x float>, ptr %.slot230, align 32
  %3475 = select <8 x i1> %3450, <8 x float> %3473, <8 x float> %3474
  store <8 x float> %3475, ptr %.slot230, align 32
  %3476 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3452)
  %3477 = bitcast <8 x i1> %3452 to i8
  %3478 = call i8 @llvm.cttz.i8(i8 %3477, i1 false)
  %3479 = zext i8 %3478 to i32
  %3480 = select i1 %3476, i32 %3479, i32 0
  %3481 = load <8 x float>, ptr %.slot230, align 32
  %3482 = select <8 x i1> %3452, <8 x float> zeroinitializer, <8 x float> %3481
  store <8 x float> %3482, ptr %.slot230, align 32
  br label %direct.schedule.180

direct.schedule.180:                              ; preds = %direct.schedule.178
  %.spill.load752 = load <8 x i64>, ptr %.spill229, align 64
  %3483 = trunc <8 x i64> %.spill.load752 to <8 x i32>
  %.state753 = load <8 x float>, ptr %.slot230, align 32
  %3484 = extractelement <8 x i32> %3483, i64 0
  %3485 = icmp ult i32 %3484, 8
  %3486 = select i1 %3485, i32 %3484, i32 0
  %3487 = extractelement <8 x i1> %119, i32 %3486
  %3488 = extractelement <8 x i1> %119, i64 0
  %3489 = and i1 %3485, %3487
  %3490 = and i1 %3488, %3489
  %3491 = extractelement <8 x float> %.state753, i32 %3486
  %3492 = select i1 %3490, float %3491, float 0.000000e+00
  %3493 = insertelement <8 x float> poison, float %3492, i64 0
  %3494 = xor i1 %3490, true
  %3495 = and i1 %3488, %3494
  %3496 = insertelement <8 x i1> poison, i1 %3495, i64 0
  %3497 = extractelement <8 x i32> %3483, i64 1
  %3498 = icmp ult i32 %3497, 8
  %3499 = select i1 %3498, i32 %3497, i32 0
  %3500 = extractelement <8 x i1> %119, i32 %3499
  %3501 = extractelement <8 x i1> %119, i64 1
  %3502 = and i1 %3498, %3500
  %3503 = and i1 %3501, %3502
  %3504 = extractelement <8 x float> %.state753, i32 %3499
  %3505 = select i1 %3503, float %3504, float 0.000000e+00
  %3506 = insertelement <8 x float> %3493, float %3505, i64 1
  %3507 = xor i1 %3503, true
  %3508 = and i1 %3501, %3507
  %3509 = insertelement <8 x i1> %3496, i1 %3508, i64 1
  %3510 = extractelement <8 x i32> %3483, i64 2
  %3511 = icmp ult i32 %3510, 8
  %3512 = select i1 %3511, i32 %3510, i32 0
  %3513 = extractelement <8 x i1> %119, i32 %3512
  %3514 = extractelement <8 x i1> %119, i64 2
  %3515 = and i1 %3511, %3513
  %3516 = and i1 %3514, %3515
  %3517 = extractelement <8 x float> %.state753, i32 %3512
  %3518 = select i1 %3516, float %3517, float 0.000000e+00
  %3519 = insertelement <8 x float> %3506, float %3518, i64 2
  %3520 = xor i1 %3516, true
  %3521 = and i1 %3514, %3520
  %3522 = insertelement <8 x i1> %3509, i1 %3521, i64 2
  %3523 = extractelement <8 x i32> %3483, i64 3
  %3524 = icmp ult i32 %3523, 8
  %3525 = select i1 %3524, i32 %3523, i32 0
  %3526 = extractelement <8 x i1> %119, i32 %3525
  %3527 = extractelement <8 x i1> %119, i64 3
  %3528 = and i1 %3524, %3526
  %3529 = and i1 %3527, %3528
  %3530 = extractelement <8 x float> %.state753, i32 %3525
  %3531 = select i1 %3529, float %3530, float 0.000000e+00
  %3532 = insertelement <8 x float> %3519, float %3531, i64 3
  %3533 = xor i1 %3529, true
  %3534 = and i1 %3527, %3533
  %3535 = insertelement <8 x i1> %3522, i1 %3534, i64 3
  %3536 = extractelement <8 x i32> %3483, i64 4
  %3537 = icmp ult i32 %3536, 8
  %3538 = select i1 %3537, i32 %3536, i32 0
  %3539 = extractelement <8 x i1> %119, i32 %3538
  %3540 = extractelement <8 x i1> %119, i64 4
  %3541 = and i1 %3537, %3539
  %3542 = and i1 %3540, %3541
  %3543 = extractelement <8 x float> %.state753, i32 %3538
  %3544 = select i1 %3542, float %3543, float 0.000000e+00
  %3545 = insertelement <8 x float> %3532, float %3544, i64 4
  %3546 = xor i1 %3542, true
  %3547 = and i1 %3540, %3546
  %3548 = insertelement <8 x i1> %3535, i1 %3547, i64 4
  %3549 = extractelement <8 x i32> %3483, i64 5
  %3550 = icmp ult i32 %3549, 8
  %3551 = select i1 %3550, i32 %3549, i32 0
  %3552 = extractelement <8 x i1> %119, i32 %3551
  %3553 = extractelement <8 x i1> %119, i64 5
  %3554 = and i1 %3550, %3552
  %3555 = and i1 %3553, %3554
  %3556 = extractelement <8 x float> %.state753, i32 %3551
  %3557 = select i1 %3555, float %3556, float 0.000000e+00
  %3558 = insertelement <8 x float> %3545, float %3557, i64 5
  %3559 = xor i1 %3555, true
  %3560 = and i1 %3553, %3559
  %3561 = insertelement <8 x i1> %3548, i1 %3560, i64 5
  %3562 = extractelement <8 x i32> %3483, i64 6
  %3563 = icmp ult i32 %3562, 8
  %3564 = select i1 %3563, i32 %3562, i32 0
  %3565 = extractelement <8 x i1> %119, i32 %3564
  %3566 = extractelement <8 x i1> %119, i64 6
  %3567 = and i1 %3563, %3565
  %3568 = and i1 %3566, %3567
  %3569 = extractelement <8 x float> %.state753, i32 %3564
  %3570 = select i1 %3568, float %3569, float 0.000000e+00
  %3571 = insertelement <8 x float> %3558, float %3570, i64 6
  %3572 = xor i1 %3568, true
  %3573 = and i1 %3566, %3572
  %3574 = insertelement <8 x i1> %3561, i1 %3573, i64 6
  %3575 = extractelement <8 x i32> %3483, i64 7
  %3576 = icmp ult i32 %3575, 8
  %3577 = select i1 %3576, i32 %3575, i32 0
  %3578 = extractelement <8 x i1> %119, i32 %3577
  %3579 = extractelement <8 x i1> %119, i64 7
  %3580 = and i1 %3576, %3578
  %3581 = and i1 %3579, %3580
  %3582 = extractelement <8 x float> %.state753, i32 %3577
  %3583 = select i1 %3581, float %3582, float 0.000000e+00
  %3584 = insertelement <8 x float> %3571, float %3583, i64 7
  %3585 = xor i1 %3581, true
  %3586 = and i1 %3579, %3585
  %3587 = insertelement <8 x i1> %3574, i1 %3586, i64 7
  %.state754 = load <8 x float>, ptr %.slot228, align 32
  %3588 = fsub <8 x float> %.state754, %3584
  %.spill.load755 = load <8 x i1>, ptr %.spill225, align 1
  %3589 = and <8 x i1> %119, %.spill.load755
  %3590 = xor <8 x i1> %.spill.load755, splat (i1 true)
  %3591 = and <8 x i1> %119, %3590
  %3592 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3589)
  %3593 = bitcast <8 x i1> %3589 to i8
  %3594 = call i8 @llvm.cttz.i8(i8 %3593, i1 false)
  %3595 = zext i8 %3594 to i32
  %3596 = select i1 %3592, i32 %3595, i32 0
  %tile_snapshot.spill.load756 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill223, align 64
  %3597 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load756, 0
  %3598 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load756, 1
  %.state757 = load <8 x i64>, ptr %.slot224, align 64
  %3599 = mul <8 x i64> %.state757, splat (i64 32)
  %3600 = add <8 x i64> %3598, %3599
  %3601 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3597, 0
  %3602 = insertvalue { <8 x ptr>, <8 x i64> } %3601, <8 x i64> %3600, 1
  %3603 = extractvalue { <8 x ptr>, <8 x i64> } %55, 0
  %3604 = extractvalue { <8 x ptr>, <8 x i64> } %3602, 1
  %3605 = extractelement <8 x ptr> %3603, i32 0
  %3606 = extractelement <8 x i64> %3604, i32 %3596
  %3607 = zext i32 %3596 to i64
  %3608 = mul i64 %3607, 4
  %3609 = sub i64 %3606, %3608
  %3610 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3589)
  %3611 = select i1 %3610, i64 %3609, i64 0
  %private.contiguous.address758 = getelementptr i8, ptr %3605, i64 %3611
  %private.contiguous.preserve759 = load <8 x float>, ptr %private.contiguous.address758, align 4
  %3612 = select <8 x i1> %3589, <8 x float> %3588, <8 x float> %private.contiguous.preserve759
  store <8 x float> %3612, ptr %private.contiguous.address758, align 4
  %3613 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3591)
  %3614 = bitcast <8 x i1> %3591 to i8
  %3615 = call i8 @llvm.cttz.i8(i8 %3614, i1 false)
  %3616 = zext i8 %3615 to i32
  %3617 = select i1 %3613, i32 %3616, i32 0
  br label %direct.schedule.182

direct.schedule.182:                              ; preds = %direct.schedule.180
  %.state760 = load <8 x i64>, ptr %.slot224, align 64
  %3618 = add <8 x i64> %.state760, splat (i64 1)
  %3619 = load <8 x i64>, ptr %.slot224, align 64
  %3620 = select <8 x i1> %119, <8 x i64> %3618, <8 x i64> %3619
  store <8 x i64> %3620, ptr %.slot224, align 64
  br label %direct.schedule.175

direct.schedule.183:                              ; preds = %direct.false736
  %3621 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill231, align 64
  %3622 = extractvalue { <8 x ptr>, <8 x i64> } %57, 0
  %3623 = extractvalue { <8 x ptr>, <8 x i64> } %3621, 0
  %3624 = select <8 x i1> %119, <8 x ptr> %3622, <8 x ptr> %3623
  %3625 = extractvalue { <8 x ptr>, <8 x i64> } %57, 1
  %3626 = extractvalue { <8 x ptr>, <8 x i64> } %3621, 1
  %3627 = select <8 x i1> %119, <8 x i64> %3625, <8 x i64> %3626
  %3628 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3624, 0
  %3629 = insertvalue { <8 x ptr>, <8 x i64> } %3628, <8 x i64> %3627, 1
  store { <8 x ptr>, <8 x i64> } %3629, ptr %tile_snapshot.spill231, align 64
  %3630 = load <8 x i64>, ptr %.slot232, align 64
  %3631 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3630
  store <8 x i64> %3631, ptr %.slot232, align 64
  br label %direct.schedule.184

direct.schedule.184:                              ; preds = %direct.schedule.189, %direct.schedule.183
  %.state761 = load <8 x i64>, ptr %.slot232, align 64
  %3632 = icmp slt <8 x i64> %.state761, splat (i64 10)
  %3633 = extractelement <8 x i1> %3632, i32 0
  br i1 %3633, label %direct.true762, label %direct.false763

direct.schedule.185:                              ; preds = %direct.true762
  %.state764 = load <8 x i64>, ptr %.slot232, align 64
  %3634 = select <8 x i1> %119, <8 x i64> %.state764, <8 x i64> zeroinitializer
  %3635 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3636 = srem <8 x i64> %3634, %3635
  %.state765 = load <8 x i64>, ptr %.slot232, align 64
  %3637 = select <8 x i1> %119, <8 x i64> %.state765, <8 x i64> zeroinitializer
  %3638 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3639 = sdiv <8 x i64> %3637, %3638
  %3640 = mul <8 x i64> %3636, splat (i64 8)
  %.spill.load766 = load <8 x i64>, ptr %.spill, align 64
  %3641 = add <8 x i64> %3640, %.spill.load766
  %3642 = icmp slt <8 x i64> %3641, splat (i64 33)
  %3643 = load <8 x i1>, ptr %.spill233, align 1
  %3644 = select <8 x i1> %119, <8 x i1> %3642, <8 x i1> %3643
  store <8 x i1> %3644, ptr %.spill233, align 1
  %3645 = select <8 x i1> %119, <8 x i64> %3639, <8 x i64> zeroinitializer
  %3646 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3647 = srem <8 x i64> %3645, %3646
  %3648 = add <8 x i64> zeroinitializer, %3647
  %3649 = mul <8 x i64> %3648, splat (i64 5)
  %3650 = add <8 x i64> %3649, %3636
  %3651 = and <8 x i1> %119, %3642
  %3652 = xor <8 x i1> %3642, splat (i1 true)
  %3653 = and <8 x i1> %119, %3652
  %3654 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3651)
  %3655 = bitcast <8 x i1> %3651 to i8
  %3656 = call i8 @llvm.cttz.i8(i8 %3655, i1 false)
  %3657 = zext i8 %3656 to i32
  %3658 = select i1 %3654, i32 %3657, i32 0
  %tile_snapshot.spill.load767 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill223, align 64
  %3659 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load767, 0
  %3660 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load767, 1
  %3661 = mul <8 x i64> %3650, splat (i64 32)
  %3662 = add <8 x i64> %3660, %3661
  %3663 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3659, 0
  %3664 = insertvalue { <8 x ptr>, <8 x i64> } %3663, <8 x i64> %3662, 1
  %3665 = extractvalue { <8 x ptr>, <8 x i64> } %55, 0
  %3666 = extractvalue { <8 x ptr>, <8 x i64> } %3664, 1
  %3667 = extractelement <8 x ptr> %3665, i32 0
  %3668 = extractelement <8 x i64> %3666, i32 %3658
  %3669 = zext i32 %3658 to i64
  %3670 = mul i64 %3669, 4
  %3671 = sub i64 %3668, %3670
  %3672 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3651)
  %3673 = select i1 %3672, i64 %3671, i64 0
  %private.contiguous.address768 = getelementptr i8, ptr %3667, i64 %3673
  %private.contiguous.load769 = load <8 x float>, ptr %private.contiguous.address768, align 4
  %3674 = select <8 x i1> %3651, <8 x float> %private.contiguous.load769, <8 x float> zeroinitializer
  %3675 = load <8 x float>, ptr %.slot234, align 32
  %3676 = select <8 x i1> %3651, <8 x float> %3674, <8 x float> %3675
  store <8 x float> %3676, ptr %.slot234, align 32
  %3677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3653)
  %3678 = bitcast <8 x i1> %3653 to i8
  %3679 = call i8 @llvm.cttz.i8(i8 %3678, i1 false)
  %3680 = zext i8 %3679 to i32
  %3681 = select i1 %3677, i32 %3680, i32 0
  %3682 = load <8 x float>, ptr %.slot234, align 32
  %3683 = select <8 x i1> %3653, <8 x float> zeroinitializer, <8 x float> %3682
  store <8 x float> %3683, ptr %.slot234, align 32
  br label %direct.schedule.187

direct.schedule.187:                              ; preds = %direct.schedule.185
  %.state770 = load <8 x float>, ptr %.slot234, align 32
  %3684 = select <8 x i1> %119, <8 x float> %.state770, <8 x float> zeroinitializer
  %native.exp771 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %3684)
  %.spill.load772 = load <8 x i1>, ptr %.spill233, align 1
  %3685 = and <8 x i1> %119, %.spill.load772
  %3686 = xor <8 x i1> %.spill.load772, splat (i1 true)
  %3687 = and <8 x i1> %119, %3686
  %3688 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3685)
  %3689 = bitcast <8 x i1> %3685 to i8
  %3690 = call i8 @llvm.cttz.i8(i8 %3689, i1 false)
  %3691 = zext i8 %3690 to i32
  %3692 = select i1 %3688, i32 %3691, i32 0
  %tile_snapshot.spill.load773 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill231, align 64
  %3693 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load773, 0
  %3694 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load773, 1
  %.state774 = load <8 x i64>, ptr %.slot232, align 64
  %3695 = mul <8 x i64> %.state774, splat (i64 32)
  %3696 = add <8 x i64> %3694, %3695
  %3697 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3693, 0
  %3698 = insertvalue { <8 x ptr>, <8 x i64> } %3697, <8 x i64> %3696, 1
  %3699 = extractvalue { <8 x ptr>, <8 x i64> } %57, 0
  %3700 = extractvalue { <8 x ptr>, <8 x i64> } %3698, 1
  %3701 = extractelement <8 x ptr> %3699, i32 0
  %3702 = extractelement <8 x i64> %3700, i32 %3692
  %3703 = zext i32 %3692 to i64
  %3704 = mul i64 %3703, 4
  %3705 = sub i64 %3702, %3704
  %3706 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3685)
  %3707 = select i1 %3706, i64 %3705, i64 0
  %private.contiguous.address775 = getelementptr i8, ptr %3701, i64 %3707
  %private.contiguous.preserve776 = load <8 x float>, ptr %private.contiguous.address775, align 4
  %3708 = select <8 x i1> %3685, <8 x float> %native.exp771, <8 x float> %private.contiguous.preserve776
  store <8 x float> %3708, ptr %private.contiguous.address775, align 4
  %3709 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3687)
  %3710 = bitcast <8 x i1> %3687 to i8
  %3711 = call i8 @llvm.cttz.i8(i8 %3710, i1 false)
  %3712 = zext i8 %3711 to i32
  %3713 = select i1 %3709, i32 %3712, i32 0
  br label %direct.schedule.189

direct.schedule.189:                              ; preds = %direct.schedule.187
  %.state777 = load <8 x i64>, ptr %.slot232, align 64
  %3714 = add <8 x i64> %.state777, splat (i64 1)
  %3715 = load <8 x i64>, ptr %.slot232, align 64
  %3716 = select <8 x i1> %119, <8 x i64> %3714, <8 x i64> %3715
  store <8 x i64> %3716, ptr %.slot232, align 64
  br label %direct.schedule.184

direct.schedule.190:                              ; preds = %direct.false763
  %3717 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill235, align 64
  %3718 = extractvalue { <8 x ptr>, <8 x i64> } %59, 0
  %3719 = extractvalue { <8 x ptr>, <8 x i64> } %3717, 0
  %3720 = select <8 x i1> %119, <8 x ptr> %3718, <8 x ptr> %3719
  %3721 = extractvalue { <8 x ptr>, <8 x i64> } %59, 1
  %3722 = extractvalue { <8 x ptr>, <8 x i64> } %3717, 1
  %3723 = select <8 x i1> %119, <8 x i64> %3721, <8 x i64> %3722
  %3724 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3720, 0
  %3725 = insertvalue { <8 x ptr>, <8 x i64> } %3724, <8 x i64> %3723, 1
  store { <8 x ptr>, <8 x i64> } %3725, ptr %tile_snapshot.spill235, align 64
  %3726 = load <8 x i64>, ptr %.slot236, align 64
  %3727 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3726
  store <8 x i64> %3727, ptr %.slot236, align 64
  br label %direct.schedule.191

direct.schedule.191:                              ; preds = %direct.schedule.198, %direct.schedule.190
  %.state778 = load <8 x i64>, ptr %.slot236, align 64
  %3728 = icmp slt <8 x i64> %.state778, splat (i64 10)
  %3729 = extractelement <8 x i1> %3728, i32 0
  br i1 %3729, label %direct.true779, label %direct.false780

direct.schedule.192:                              ; preds = %direct.true779
  %.state781 = load <8 x i64>, ptr %.slot236, align 64
  %3730 = select <8 x i1> %119, <8 x i64> %.state781, <8 x i64> zeroinitializer
  %3731 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3732 = srem <8 x i64> %3730, %3731
  %3733 = load <8 x i64>, ptr %.spill237, align 64
  %3734 = select <8 x i1> %119, <8 x i64> %3732, <8 x i64> %3733
  store <8 x i64> %3734, ptr %.spill237, align 64
  %.state782 = load <8 x i64>, ptr %.slot236, align 64
  %3735 = select <8 x i1> %119, <8 x i64> %.state782, <8 x i64> zeroinitializer
  %3736 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %3737 = sdiv <8 x i64> %3735, %3736
  %3738 = mul <8 x i64> %3732, splat (i64 8)
  %.spill.load783 = load <8 x i64>, ptr %.spill, align 64
  %3739 = add <8 x i64> %3738, %.spill.load783
  %3740 = icmp slt <8 x i64> %3739, splat (i64 33)
  %3741 = load <8 x i1>, ptr %.spill238, align 1
  %3742 = select <8 x i1> %119, <8 x i1> %3740, <8 x i1> %3741
  store <8 x i1> %3742, ptr %.spill238, align 1
  %3743 = select <8 x i1> %119, <8 x i64> %3737, <8 x i64> zeroinitializer
  %3744 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3745 = srem <8 x i64> %3743, %3744
  %3746 = load <8 x i64>, ptr %.spill239, align 64
  %3747 = select <8 x i1> %119, <8 x i64> %3745, <8 x i64> %3746
  store <8 x i64> %3747, ptr %.spill239, align 64
  store i64 0, ptr %.spill240, align 4
  %3748 = add <8 x i64> zeroinitializer, %3732
  %3749 = mul <8 x i64> %3748, splat (i64 2)
  %3750 = add <8 x i64> %3749, %3745
  %3751 = and <8 x i1> %119, %3740
  %3752 = xor <8 x i1> %3740, splat (i1 true)
  %3753 = and <8 x i1> %119, %3752
  %3754 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3751)
  %3755 = bitcast <8 x i1> %3751 to i8
  %3756 = call i8 @llvm.cttz.i8(i8 %3755, i1 false)
  %3757 = zext i8 %3756 to i32
  %3758 = select i1 %3754, i32 %3757, i32 0
  %tile_snapshot.spill.load784 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill184, align 64
  %3759 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 0
  %3760 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load784, 1
  %3761 = add <8 x i64> %3760, %3750
  %3762 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3759, 0
  %3763 = insertvalue { <8 x ptr>, <8 x i64> } %3762, <8 x i64> %3761, 1
  %3764 = extractvalue { <8 x ptr>, <8 x i64> } %3763, 0
  %3765 = extractvalue { <8 x ptr>, <8 x i64> } %3763, 1
  %3766 = getelementptr i8, <8 x ptr> %3764, <8 x i64> %3765
  %3767 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %3766, <8 x i1> %3751, <8 x i8> zeroinitializer)
  %3768 = icmp ne <8 x i8> %3767, zeroinitializer
  %3769 = load <8 x i1>, ptr %.slot241, align 1
  %3770 = select <8 x i1> %3751, <8 x i1> %3768, <8 x i1> %3769
  store <8 x i1> %3770, ptr %.slot241, align 1
  %3771 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3753)
  %3772 = bitcast <8 x i1> %3753 to i8
  %3773 = call i8 @llvm.cttz.i8(i8 %3772, i1 false)
  %3774 = zext i8 %3773 to i32
  %3775 = select i1 %3771, i32 %3774, i32 0
  %3776 = load <8 x i1>, ptr %.slot241, align 1
  %3777 = select <8 x i1> %3753, <8 x i1> zeroinitializer, <8 x i1> %3776
  store <8 x i1> %3777, ptr %.slot241, align 1
  br label %direct.schedule.194

direct.schedule.194:                              ; preds = %direct.schedule.192
  %.spill.load785 = load i64, ptr %.spill240, align 4
  %3778 = add i64 %.spill.load785, 0
  %3779 = mul i64 %3778, 1
  %3780 = add i64 %3779, 0
  %3781 = mul i64 %3780, 2
  %.splatinsert786 = insertelement <8 x i64> poison, i64 %3781, i64 0
  %.splat787 = shufflevector <8 x i64> %.splatinsert786, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load788 = load <8 x i64>, ptr %.spill239, align 64
  %3782 = add <8 x i64> %.splat787, %.spill.load788
  %3783 = mul <8 x i64> %3782, splat (i64 5)
  %.spill.load789 = load <8 x i64>, ptr %.spill237, align 64
  %3784 = add <8 x i64> %3783, %.spill.load789
  %.spill.load790 = load <8 x i1>, ptr %.spill238, align 1
  %3785 = and <8 x i1> %119, %.spill.load790
  %3786 = xor <8 x i1> %.spill.load790, splat (i1 true)
  %3787 = and <8 x i1> %119, %3786
  %3788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3785)
  %3789 = bitcast <8 x i1> %3785 to i8
  %3790 = call i8 @llvm.cttz.i8(i8 %3789, i1 false)
  %3791 = zext i8 %3790 to i32
  %3792 = select i1 %3788, i32 %3791, i32 0
  %tile_snapshot.spill.load791 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill231, align 64
  %3793 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load791, 0
  %3794 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load791, 1
  %3795 = mul <8 x i64> %3784, splat (i64 32)
  %3796 = add <8 x i64> %3794, %3795
  %3797 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3793, 0
  %3798 = insertvalue { <8 x ptr>, <8 x i64> } %3797, <8 x i64> %3796, 1
  %3799 = extractvalue { <8 x ptr>, <8 x i64> } %57, 0
  %3800 = extractvalue { <8 x ptr>, <8 x i64> } %3798, 1
  %3801 = extractelement <8 x ptr> %3799, i32 0
  %3802 = extractelement <8 x i64> %3800, i32 %3792
  %3803 = zext i32 %3792 to i64
  %3804 = mul i64 %3803, 4
  %3805 = sub i64 %3802, %3804
  %3806 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3785)
  %3807 = select i1 %3806, i64 %3805, i64 0
  %private.contiguous.address792 = getelementptr i8, ptr %3801, i64 %3807
  %private.contiguous.load793 = load <8 x float>, ptr %private.contiguous.address792, align 4
  %3808 = select <8 x i1> %3785, <8 x float> %private.contiguous.load793, <8 x float> zeroinitializer
  %3809 = load <8 x float>, ptr %.slot242, align 32
  %3810 = select <8 x i1> %3785, <8 x float> %3808, <8 x float> %3809
  store <8 x float> %3810, ptr %.slot242, align 32
  %3811 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3787)
  %3812 = bitcast <8 x i1> %3787 to i8
  %3813 = call i8 @llvm.cttz.i8(i8 %3812, i1 false)
  %3814 = zext i8 %3813 to i32
  %3815 = select i1 %3811, i32 %3814, i32 0
  %3816 = load <8 x float>, ptr %.slot242, align 32
  %3817 = select <8 x i1> %3787, <8 x float> zeroinitializer, <8 x float> %3816
  store <8 x float> %3817, ptr %.slot242, align 32
  br label %direct.schedule.196

direct.schedule.196:                              ; preds = %direct.schedule.194
  %.state794 = load <8 x float>, ptr %.slot242, align 32
  %.state795 = load <8 x i1>, ptr %.slot241, align 1
  %3818 = select <8 x i1> %.state795, <8 x float> %.state794, <8 x float> zeroinitializer
  %.spill.load796 = load <8 x i1>, ptr %.spill238, align 1
  %3819 = and <8 x i1> %119, %.spill.load796
  %3820 = xor <8 x i1> %.spill.load796, splat (i1 true)
  %3821 = and <8 x i1> %119, %3820
  %3822 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3819)
  %3823 = bitcast <8 x i1> %3819 to i8
  %3824 = call i8 @llvm.cttz.i8(i8 %3823, i1 false)
  %3825 = zext i8 %3824 to i32
  %3826 = select i1 %3822, i32 %3825, i32 0
  %tile_snapshot.spill.load797 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill235, align 64
  %3827 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 0
  %3828 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load797, 1
  %.state798 = load <8 x i64>, ptr %.slot236, align 64
  %3829 = mul <8 x i64> %.state798, splat (i64 32)
  %3830 = add <8 x i64> %3828, %3829
  %3831 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3827, 0
  %3832 = insertvalue { <8 x ptr>, <8 x i64> } %3831, <8 x i64> %3830, 1
  %3833 = extractvalue { <8 x ptr>, <8 x i64> } %59, 0
  %3834 = extractvalue { <8 x ptr>, <8 x i64> } %3832, 1
  %3835 = extractelement <8 x ptr> %3833, i32 0
  %3836 = extractelement <8 x i64> %3834, i32 %3826
  %3837 = zext i32 %3826 to i64
  %3838 = mul i64 %3837, 4
  %3839 = sub i64 %3836, %3838
  %3840 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3819)
  %3841 = select i1 %3840, i64 %3839, i64 0
  %private.contiguous.address799 = getelementptr i8, ptr %3835, i64 %3841
  %private.contiguous.preserve800 = load <8 x float>, ptr %private.contiguous.address799, align 4
  %3842 = select <8 x i1> %3819, <8 x float> %3818, <8 x float> %private.contiguous.preserve800
  store <8 x float> %3842, ptr %private.contiguous.address799, align 4
  %3843 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3821)
  %3844 = bitcast <8 x i1> %3821 to i8
  %3845 = call i8 @llvm.cttz.i8(i8 %3844, i1 false)
  %3846 = zext i8 %3845 to i32
  %3847 = select i1 %3843, i32 %3846, i32 0
  br label %direct.schedule.198

direct.schedule.198:                              ; preds = %direct.schedule.196
  %.state801 = load <8 x i64>, ptr %.slot236, align 64
  %3848 = add <8 x i64> %.state801, splat (i64 1)
  %3849 = load <8 x i64>, ptr %.slot236, align 64
  %3850 = select <8 x i1> %119, <8 x i64> %3848, <8 x i64> %3849
  store <8 x i64> %3850, ptr %.slot236, align 64
  br label %direct.schedule.191

direct.schedule.199:                              ; preds = %direct.false780
  %3851 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill243, align 64
  %3852 = extractvalue { <8 x ptr>, <8 x i64> } %61, 0
  %3853 = extractvalue { <8 x ptr>, <8 x i64> } %3851, 0
  %3854 = select <8 x i1> %119, <8 x ptr> %3852, <8 x ptr> %3853
  %3855 = extractvalue { <8 x ptr>, <8 x i64> } %61, 1
  %3856 = extractvalue { <8 x ptr>, <8 x i64> } %3851, 1
  %3857 = select <8 x i1> %119, <8 x i64> %3855, <8 x i64> %3856
  %3858 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3854, 0
  %3859 = insertvalue { <8 x ptr>, <8 x i64> } %3858, <8 x i64> %3857, 1
  store { <8 x ptr>, <8 x i64> } %3859, ptr %tile_snapshot.spill243, align 64
  %3860 = load <8 x i64>, ptr %.slot244, align 64
  %3861 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3860
  store <8 x i64> %3861, ptr %.slot244, align 64
  br label %direct.schedule.200

direct.schedule.200:                              ; preds = %direct.schedule.207, %direct.schedule.199
  %.state802 = load <8 x i64>, ptr %.slot244, align 64
  %3862 = icmp slt <8 x i64> %.state802, splat (i64 1)
  %3863 = extractelement <8 x i1> %3862, i32 0
  br i1 %3863, label %direct.true803, label %direct.false804

direct.schedule.201:                              ; preds = %direct.true803
  %.state805 = load <8 x i64>, ptr %.slot244, align 64
  %3864 = select <8 x i1> %119, <8 x i64> %.state805, <8 x i64> zeroinitializer
  %3865 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3866 = srem <8 x i64> %3864, %3865
  %3867 = mul <8 x i64> %3866, splat (i64 8)
  %.spill.load806 = load <8 x i64>, ptr %.spill, align 64
  %3868 = add <8 x i64> %3867, %.spill.load806
  %3869 = icmp slt <8 x i64> %3868, splat (i64 2)
  %3870 = load <8 x i1>, ptr %.spill245, align 1
  %3871 = select <8 x i1> %119, <8 x i1> %3869, <8 x i1> %3870
  store <8 x i1> %3871, ptr %.spill245, align 1
  %3872 = add <8 x i64> zeroinitializer, %3866
  %3873 = load <8 x i64>, ptr %.spill246, align 64
  %3874 = select <8 x i1> %119, <8 x i64> %3872, <8 x i64> %3873
  store <8 x i64> %3874, ptr %.spill246, align 64
  %3875 = and <8 x i1> %119, %3869
  %3876 = xor <8 x i1> %3869, splat (i1 true)
  %3877 = and <8 x i1> %119, %3876
  %3878 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3875)
  %3879 = bitcast <8 x i1> %3875 to i8
  %3880 = call i8 @llvm.cttz.i8(i8 %3879, i1 false)
  %3881 = zext i8 %3880 to i32
  %3882 = select i1 %3878, i32 %3881, i32 0
  %tile_snapshot.spill.load807 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %3883 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load807, 0
  %3884 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load807, 1
  %3885 = mul <8 x i64> %3872, splat (i64 32)
  %3886 = add <8 x i64> %3884, %3885
  %3887 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3883, 0
  %3888 = insertvalue { <8 x ptr>, <8 x i64> } %3887, <8 x i64> %3886, 1
  %3889 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %3890 = extractvalue { <8 x ptr>, <8 x i64> } %3888, 1
  %3891 = extractelement <8 x ptr> %3889, i32 0
  %3892 = extractelement <8 x i64> %3890, i32 %3882
  %3893 = zext i32 %3882 to i64
  %3894 = mul i64 %3893, 4
  %3895 = sub i64 %3892, %3894
  %3896 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3875)
  %3897 = select i1 %3896, i64 %3895, i64 0
  %private.contiguous.address808 = getelementptr i8, ptr %3891, i64 %3897
  %private.contiguous.load809 = load <8 x float>, ptr %private.contiguous.address808, align 4
  %3898 = select <8 x i1> %3875, <8 x float> %private.contiguous.load809, <8 x float> zeroinitializer
  %3899 = load <8 x float>, ptr %.slot247, align 32
  %3900 = select <8 x i1> %3875, <8 x float> %3898, <8 x float> %3899
  store <8 x float> %3900, ptr %.slot247, align 32
  %3901 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3877)
  %3902 = bitcast <8 x i1> %3877 to i8
  %3903 = call i8 @llvm.cttz.i8(i8 %3902, i1 false)
  %3904 = zext i8 %3903 to i32
  %3905 = select i1 %3901, i32 %3904, i32 0
  %3906 = load <8 x float>, ptr %.slot247, align 32
  %3907 = select <8 x i1> %3877, <8 x float> zeroinitializer, <8 x float> %3906
  store <8 x float> %3907, ptr %.slot247, align 32
  br label %direct.schedule.203

direct.schedule.203:                              ; preds = %direct.schedule.201
  %.spill.load810 = load <8 x i1>, ptr %.spill245, align 1
  %3908 = and <8 x i1> %119, %.spill.load810
  %3909 = xor <8 x i1> %.spill.load810, splat (i1 true)
  %3910 = and <8 x i1> %119, %3909
  %3911 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3908)
  %3912 = bitcast <8 x i1> %3908 to i8
  %3913 = call i8 @llvm.cttz.i8(i8 %3912, i1 false)
  %3914 = zext i8 %3913 to i32
  %3915 = select i1 %3911, i32 %3914, i32 0
  %tile_snapshot.spill.load811 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill219, align 64
  %3916 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 0
  %3917 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load811, 1
  %.spill.load812 = load <8 x i64>, ptr %.spill246, align 64
  %3918 = mul <8 x i64> %.spill.load812, splat (i64 32)
  %3919 = add <8 x i64> %3917, %3918
  %3920 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3916, 0
  %3921 = insertvalue { <8 x ptr>, <8 x i64> } %3920, <8 x i64> %3919, 1
  %3922 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %3923 = extractvalue { <8 x ptr>, <8 x i64> } %3921, 1
  %3924 = extractelement <8 x ptr> %3922, i32 0
  %3925 = extractelement <8 x i64> %3923, i32 %3915
  %3926 = zext i32 %3915 to i64
  %3927 = mul i64 %3926, 4
  %3928 = sub i64 %3925, %3927
  %3929 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3908)
  %3930 = select i1 %3929, i64 %3928, i64 0
  %private.contiguous.address813 = getelementptr i8, ptr %3924, i64 %3930
  %private.contiguous.load814 = load <8 x float>, ptr %private.contiguous.address813, align 4
  %3931 = select <8 x i1> %3908, <8 x float> %private.contiguous.load814, <8 x float> zeroinitializer
  %3932 = load <8 x float>, ptr %.slot248, align 32
  %3933 = select <8 x i1> %3908, <8 x float> %3931, <8 x float> %3932
  store <8 x float> %3933, ptr %.slot248, align 32
  %3934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3910)
  %3935 = bitcast <8 x i1> %3910 to i8
  %3936 = call i8 @llvm.cttz.i8(i8 %3935, i1 false)
  %3937 = zext i8 %3936 to i32
  %3938 = select i1 %3934, i32 %3937, i32 0
  %3939 = load <8 x float>, ptr %.slot248, align 32
  %3940 = select <8 x i1> %3910, <8 x float> zeroinitializer, <8 x float> %3939
  store <8 x float> %3940, ptr %.slot248, align 32
  br label %direct.schedule.205

direct.schedule.205:                              ; preds = %direct.schedule.203
  %.state815 = load <8 x float>, ptr %.slot247, align 32
  %.state816 = load <8 x float>, ptr %.slot248, align 32
  %3941 = fmul <8 x float> %.state815, %.state816
  %.spill.load817 = load <8 x i1>, ptr %.spill245, align 1
  %3942 = and <8 x i1> %119, %.spill.load817
  %3943 = xor <8 x i1> %.spill.load817, splat (i1 true)
  %3944 = and <8 x i1> %119, %3943
  %3945 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3942)
  %3946 = bitcast <8 x i1> %3942 to i8
  %3947 = call i8 @llvm.cttz.i8(i8 %3946, i1 false)
  %3948 = zext i8 %3947 to i32
  %3949 = select i1 %3945, i32 %3948, i32 0
  %tile_snapshot.spill.load818 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill243, align 64
  %3950 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 0
  %3951 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load818, 1
  %.state819 = load <8 x i64>, ptr %.slot244, align 64
  %3952 = mul <8 x i64> %.state819, splat (i64 32)
  %3953 = add <8 x i64> %3951, %3952
  %3954 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3950, 0
  %3955 = insertvalue { <8 x ptr>, <8 x i64> } %3954, <8 x i64> %3953, 1
  %3956 = extractvalue { <8 x ptr>, <8 x i64> } %61, 0
  %3957 = extractvalue { <8 x ptr>, <8 x i64> } %3955, 1
  %3958 = extractelement <8 x ptr> %3956, i32 0
  %3959 = extractelement <8 x i64> %3957, i32 %3949
  %3960 = zext i32 %3949 to i64
  %3961 = mul i64 %3960, 4
  %3962 = sub i64 %3959, %3961
  %3963 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3942)
  %3964 = select i1 %3963, i64 %3962, i64 0
  %private.contiguous.address820 = getelementptr i8, ptr %3958, i64 %3964
  %private.contiguous.preserve821 = load <8 x float>, ptr %private.contiguous.address820, align 4
  %3965 = select <8 x i1> %3942, <8 x float> %3941, <8 x float> %private.contiguous.preserve821
  store <8 x float> %3965, ptr %private.contiguous.address820, align 4
  %3966 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %3944)
  %3967 = bitcast <8 x i1> %3944 to i8
  %3968 = call i8 @llvm.cttz.i8(i8 %3967, i1 false)
  %3969 = zext i8 %3968 to i32
  %3970 = select i1 %3966, i32 %3969, i32 0
  br label %direct.schedule.207

direct.schedule.207:                              ; preds = %direct.schedule.205
  %.state822 = load <8 x i64>, ptr %.slot244, align 64
  %3971 = add <8 x i64> %.state822, splat (i64 1)
  %3972 = load <8 x i64>, ptr %.slot244, align 64
  %3973 = select <8 x i1> %119, <8 x i64> %3971, <8 x i64> %3972
  store <8 x i64> %3973, ptr %.slot244, align 64
  br label %direct.schedule.200

direct.schedule.208:                              ; preds = %direct.false804
  %3974 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill249, align 64
  %3975 = extractvalue { <8 x ptr>, <8 x i64> } %63, 0
  %3976 = extractvalue { <8 x ptr>, <8 x i64> } %3974, 0
  %3977 = select <8 x i1> %119, <8 x ptr> %3975, <8 x ptr> %3976
  %3978 = extractvalue { <8 x ptr>, <8 x i64> } %63, 1
  %3979 = extractvalue { <8 x ptr>, <8 x i64> } %3974, 1
  %3980 = select <8 x i1> %119, <8 x i64> %3978, <8 x i64> %3979
  %3981 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %3977, 0
  %3982 = insertvalue { <8 x ptr>, <8 x i64> } %3981, <8 x i64> %3980, 1
  store { <8 x ptr>, <8 x i64> } %3982, ptr %tile_snapshot.spill249, align 64
  %3983 = load <8 x i64>, ptr %.slot250, align 64
  %3984 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %3983
  store <8 x i64> %3984, ptr %.slot250, align 64
  br label %direct.schedule.209

direct.schedule.209:                              ; preds = %direct.schedule.215, %direct.schedule.208
  %.state823 = load <8 x i64>, ptr %.slot250, align 64
  %3985 = icmp slt <8 x i64> %.state823, splat (i64 2)
  %3986 = extractelement <8 x i1> %3985, i32 0
  br i1 %3986, label %direct.true824, label %direct.false825

direct.schedule.210:                              ; preds = %direct.true824
  %.state826 = load <8 x i64>, ptr %.slot250, align 64
  %3987 = select <8 x i1> %119, <8 x i64> %.state826, <8 x i64> zeroinitializer
  %3988 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3989 = srem <8 x i64> %3987, %3988
  %.state827 = load <8 x i64>, ptr %.slot250, align 64
  %3990 = select <8 x i1> %119, <8 x i64> %.state827, <8 x i64> zeroinitializer
  %3991 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %3992 = sdiv <8 x i64> %3990, %3991
  %3993 = select <8 x i1> %119, <8 x i64> %3992, <8 x i64> zeroinitializer
  %3994 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3995 = srem <8 x i64> %3993, %3994
  %3996 = select <8 x i1> %119, <8 x i64> %3992, <8 x i64> zeroinitializer
  %3997 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %3998 = sdiv <8 x i64> %3996, %3997
  %3999 = select <8 x i1> %119, <8 x i64> %3998, <8 x i64> zeroinitializer
  %4000 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4001 = srem <8 x i64> %3999, %4000
  %4002 = add <8 x i64> zeroinitializer, %4001
  %4003 = mul <8 x i64> %4002, splat (i64 1)
  %4004 = add <8 x i64> %4003, %3995
  %4005 = mul <8 x i64> %4004, splat (i64 2)
  %4006 = add <8 x i64> %4005, %3989
  %4007 = load <8 x i64>, ptr %.spill251, align 64
  %4008 = select <8 x i1> %119, <8 x i64> %4006, <8 x i64> %4007
  store <8 x i64> %4008, ptr %.spill251, align 64
  %4009 = load <8 x i64>, ptr %.slot252, align 64
  %4010 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %4009
  store <8 x i64> %4010, ptr %.slot252, align 64
  %4011 = load <8 x float>, ptr %.slot253, align 32
  %4012 = select <8 x i1> %119, <8 x float> zeroinitializer, <8 x float> %4011
  store <8 x float> %4012, ptr %.slot253, align 32
  %4013 = load <8 x i1>, ptr %.slot254, align 1
  %4014 = select <8 x i1> %119, <8 x i1> zeroinitializer, <8 x i1> %4013
  store <8 x i1> %4014, ptr %.slot254, align 1
  br label %direct.schedule.211

direct.schedule.211:                              ; preds = %direct.schedule.214, %direct.schedule.210
  %.state828 = load <8 x i64>, ptr %.slot252, align 64
  %4015 = icmp slt <8 x i64> %.state828, splat (i64 5)
  %4016 = extractelement <8 x i1> %4015, i32 0
  br i1 %4016, label %direct.true829, label %direct.false830

direct.schedule.212:                              ; preds = %direct.true829
  %.state831 = load <8 x i64>, ptr %.slot252, align 64
  %4017 = select <8 x i1> %119, <8 x i64> %.state831, <8 x i64> zeroinitializer
  %4018 = select <8 x i1> %119, <8 x i64> splat (i64 5), <8 x i64> splat (i64 1)
  %4019 = srem <8 x i64> %4017, %4018
  %4020 = mul <8 x i64> %4019, splat (i64 8)
  %.spill.load832 = load <8 x i64>, ptr %.spill, align 64
  %4021 = add <8 x i64> %4020, %.spill.load832
  %4022 = icmp slt <8 x i64> %4021, splat (i64 33)
  %4023 = load <8 x i1>, ptr %.spill255, align 1
  %4024 = select <8 x i1> %119, <8 x i1> %4022, <8 x i1> %4023
  store <8 x i1> %4024, ptr %.spill255, align 1
  %.spill.load833 = load <8 x i64>, ptr %.spill251, align 64
  %4025 = mul <8 x i64> %.spill.load833, splat (i64 5)
  %4026 = add <8 x i64> %4025, %4019
  %4027 = and <8 x i1> %119, %4022
  %4028 = xor <8 x i1> %4022, splat (i1 true)
  %4029 = and <8 x i1> %119, %4028
  %4030 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4027)
  %4031 = bitcast <8 x i1> %4027 to i8
  %4032 = call i8 @llvm.cttz.i8(i8 %4031, i1 false)
  %4033 = zext i8 %4032 to i32
  %4034 = select i1 %4030, i32 %4033, i32 0
  %tile_snapshot.spill.load834 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill235, align 64
  %4035 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load834, 0
  %4036 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load834, 1
  %4037 = mul <8 x i64> %4026, splat (i64 32)
  %4038 = add <8 x i64> %4036, %4037
  %4039 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4035, 0
  %4040 = insertvalue { <8 x ptr>, <8 x i64> } %4039, <8 x i64> %4038, 1
  %4041 = extractvalue { <8 x ptr>, <8 x i64> } %59, 0
  %4042 = extractvalue { <8 x ptr>, <8 x i64> } %4040, 1
  %4043 = extractelement <8 x ptr> %4041, i32 0
  %4044 = extractelement <8 x i64> %4042, i32 %4034
  %4045 = zext i32 %4034 to i64
  %4046 = mul i64 %4045, 4
  %4047 = sub i64 %4044, %4046
  %4048 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4027)
  %4049 = select i1 %4048, i64 %4047, i64 0
  %private.contiguous.address835 = getelementptr i8, ptr %4043, i64 %4049
  %private.contiguous.load836 = load <8 x float>, ptr %private.contiguous.address835, align 4
  %4050 = select <8 x i1> %4027, <8 x float> %private.contiguous.load836, <8 x float> zeroinitializer
  %4051 = load <8 x float>, ptr %.slot256, align 32
  %4052 = select <8 x i1> %4027, <8 x float> %4050, <8 x float> %4051
  store <8 x float> %4052, ptr %.slot256, align 32
  %4053 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4029)
  %4054 = bitcast <8 x i1> %4029 to i8
  %4055 = call i8 @llvm.cttz.i8(i8 %4054, i1 false)
  %4056 = zext i8 %4055 to i32
  %4057 = select i1 %4053, i32 %4056, i32 0
  %4058 = load <8 x float>, ptr %.slot256, align 32
  %4059 = select <8 x i1> %4029, <8 x float> zeroinitializer, <8 x float> %4058
  store <8 x float> %4059, ptr %.slot256, align 32
  br label %direct.schedule.214

direct.schedule.214:                              ; preds = %direct.schedule.212
  %.state837 = load <8 x float>, ptr %.slot253, align 32
  %.state838 = load <8 x float>, ptr %.slot256, align 32
  %4060 = fadd <8 x float> %.state837, %.state838
  %.state839 = load <8 x float>, ptr %.slot256, align 32
  %.state840 = load <8 x i1>, ptr %.slot254, align 1
  %4061 = select <8 x i1> %.state840, <8 x float> %4060, <8 x float> %.state839
  %.state841 = load <8 x float>, ptr %.slot253, align 32
  %.spill.load842 = load <8 x i1>, ptr %.spill255, align 1
  %4062 = select <8 x i1> %.spill.load842, <8 x float> %4061, <8 x float> %.state841
  %.state843 = load <8 x i1>, ptr %.slot254, align 1
  %.spill.load844 = load <8 x i1>, ptr %.spill255, align 1
  %4063 = or <8 x i1> %.state843, %.spill.load844
  %.state845 = load <8 x i64>, ptr %.slot252, align 64
  %4064 = add <8 x i64> %.state845, splat (i64 1)
  %4065 = load <8 x i64>, ptr %.slot252, align 64
  %4066 = select <8 x i1> %119, <8 x i64> %4064, <8 x i64> %4065
  store <8 x i64> %4066, ptr %.slot252, align 64
  %4067 = load <8 x float>, ptr %.slot253, align 32
  %4068 = select <8 x i1> %119, <8 x float> %4062, <8 x float> %4067
  store <8 x float> %4068, ptr %.slot253, align 32
  %4069 = load <8 x i1>, ptr %.slot254, align 1
  %4070 = select <8 x i1> %119, <8 x i1> %4063, <8 x i1> %4069
  store <8 x i1> %4070, ptr %.slot254, align 1
  br label %direct.schedule.211

direct.schedule.215:                              ; preds = %direct.false830
  %.spill.load846 = load <8 x i64>, ptr %.spill, align 64
  %4071 = trunc <8 x i64> %.spill.load846 to <8 x i32>
  %4072 = xor <8 x i32> %4071, splat (i32 1)
  %.state847 = load <8 x float>, ptr %.slot253, align 32
  %4073 = extractelement <8 x i32> %4072, i64 0
  %4074 = icmp ult i32 %4073, 8
  %4075 = select i1 %4074, i32 %4073, i32 0
  %4076 = extractelement <8 x i1> %119, i32 %4075
  %4077 = extractelement <8 x i1> %119, i64 0
  %4078 = and i1 %4074, %4076
  %4079 = and i1 %4077, %4078
  %4080 = extractelement <8 x float> %.state847, i32 %4075
  %4081 = select i1 %4079, float %4080, float 0.000000e+00
  %4082 = insertelement <8 x float> poison, float %4081, i64 0
  %4083 = xor i1 %4079, true
  %4084 = and i1 %4077, %4083
  %4085 = insertelement <8 x i1> poison, i1 %4084, i64 0
  %4086 = extractelement <8 x i32> %4072, i64 1
  %4087 = icmp ult i32 %4086, 8
  %4088 = select i1 %4087, i32 %4086, i32 0
  %4089 = extractelement <8 x i1> %119, i32 %4088
  %4090 = extractelement <8 x i1> %119, i64 1
  %4091 = and i1 %4087, %4089
  %4092 = and i1 %4090, %4091
  %4093 = extractelement <8 x float> %.state847, i32 %4088
  %4094 = select i1 %4092, float %4093, float 0.000000e+00
  %4095 = insertelement <8 x float> %4082, float %4094, i64 1
  %4096 = xor i1 %4092, true
  %4097 = and i1 %4090, %4096
  %4098 = insertelement <8 x i1> %4085, i1 %4097, i64 1
  %4099 = extractelement <8 x i32> %4072, i64 2
  %4100 = icmp ult i32 %4099, 8
  %4101 = select i1 %4100, i32 %4099, i32 0
  %4102 = extractelement <8 x i1> %119, i32 %4101
  %4103 = extractelement <8 x i1> %119, i64 2
  %4104 = and i1 %4100, %4102
  %4105 = and i1 %4103, %4104
  %4106 = extractelement <8 x float> %.state847, i32 %4101
  %4107 = select i1 %4105, float %4106, float 0.000000e+00
  %4108 = insertelement <8 x float> %4095, float %4107, i64 2
  %4109 = xor i1 %4105, true
  %4110 = and i1 %4103, %4109
  %4111 = insertelement <8 x i1> %4098, i1 %4110, i64 2
  %4112 = extractelement <8 x i32> %4072, i64 3
  %4113 = icmp ult i32 %4112, 8
  %4114 = select i1 %4113, i32 %4112, i32 0
  %4115 = extractelement <8 x i1> %119, i32 %4114
  %4116 = extractelement <8 x i1> %119, i64 3
  %4117 = and i1 %4113, %4115
  %4118 = and i1 %4116, %4117
  %4119 = extractelement <8 x float> %.state847, i32 %4114
  %4120 = select i1 %4118, float %4119, float 0.000000e+00
  %4121 = insertelement <8 x float> %4108, float %4120, i64 3
  %4122 = xor i1 %4118, true
  %4123 = and i1 %4116, %4122
  %4124 = insertelement <8 x i1> %4111, i1 %4123, i64 3
  %4125 = extractelement <8 x i32> %4072, i64 4
  %4126 = icmp ult i32 %4125, 8
  %4127 = select i1 %4126, i32 %4125, i32 0
  %4128 = extractelement <8 x i1> %119, i32 %4127
  %4129 = extractelement <8 x i1> %119, i64 4
  %4130 = and i1 %4126, %4128
  %4131 = and i1 %4129, %4130
  %4132 = extractelement <8 x float> %.state847, i32 %4127
  %4133 = select i1 %4131, float %4132, float 0.000000e+00
  %4134 = insertelement <8 x float> %4121, float %4133, i64 4
  %4135 = xor i1 %4131, true
  %4136 = and i1 %4129, %4135
  %4137 = insertelement <8 x i1> %4124, i1 %4136, i64 4
  %4138 = extractelement <8 x i32> %4072, i64 5
  %4139 = icmp ult i32 %4138, 8
  %4140 = select i1 %4139, i32 %4138, i32 0
  %4141 = extractelement <8 x i1> %119, i32 %4140
  %4142 = extractelement <8 x i1> %119, i64 5
  %4143 = and i1 %4139, %4141
  %4144 = and i1 %4142, %4143
  %4145 = extractelement <8 x float> %.state847, i32 %4140
  %4146 = select i1 %4144, float %4145, float 0.000000e+00
  %4147 = insertelement <8 x float> %4134, float %4146, i64 5
  %4148 = xor i1 %4144, true
  %4149 = and i1 %4142, %4148
  %4150 = insertelement <8 x i1> %4137, i1 %4149, i64 5
  %4151 = extractelement <8 x i32> %4072, i64 6
  %4152 = icmp ult i32 %4151, 8
  %4153 = select i1 %4152, i32 %4151, i32 0
  %4154 = extractelement <8 x i1> %119, i32 %4153
  %4155 = extractelement <8 x i1> %119, i64 6
  %4156 = and i1 %4152, %4154
  %4157 = and i1 %4155, %4156
  %4158 = extractelement <8 x float> %.state847, i32 %4153
  %4159 = select i1 %4157, float %4158, float 0.000000e+00
  %4160 = insertelement <8 x float> %4147, float %4159, i64 6
  %4161 = xor i1 %4157, true
  %4162 = and i1 %4155, %4161
  %4163 = insertelement <8 x i1> %4150, i1 %4162, i64 6
  %4164 = extractelement <8 x i32> %4072, i64 7
  %4165 = icmp ult i32 %4164, 8
  %4166 = select i1 %4165, i32 %4164, i32 0
  %4167 = extractelement <8 x i1> %119, i32 %4166
  %4168 = extractelement <8 x i1> %119, i64 7
  %4169 = and i1 %4165, %4167
  %4170 = and i1 %4168, %4169
  %4171 = extractelement <8 x float> %.state847, i32 %4166
  %4172 = select i1 %4170, float %4171, float 0.000000e+00
  %4173 = insertelement <8 x float> %4160, float %4172, i64 7
  %4174 = xor i1 %4170, true
  %4175 = and i1 %4168, %4174
  %4176 = insertelement <8 x i1> %4163, i1 %4175, i64 7
  %.state848 = load <8 x float>, ptr %.slot253, align 32
  %4177 = fadd <8 x float> %.state848, %4173
  %.state849 = load <8 x i1>, ptr %.slot254, align 1
  %4178 = zext <8 x i1> %.state849 to <8 x i32>
  %4179 = extractelement <8 x i32> %4072, i64 0
  %4180 = icmp ult i32 %4179, 8
  %4181 = select i1 %4180, i32 %4179, i32 0
  %4182 = extractelement <8 x i1> %119, i32 %4181
  %4183 = extractelement <8 x i1> %119, i64 0
  %4184 = and i1 %4180, %4182
  %4185 = and i1 %4183, %4184
  %4186 = extractelement <8 x i32> %4178, i32 %4181
  %4187 = select i1 %4185, i32 %4186, i32 0
  %4188 = insertelement <8 x i32> poison, i32 %4187, i64 0
  %4189 = xor i1 %4185, true
  %4190 = and i1 %4183, %4189
  %4191 = insertelement <8 x i1> poison, i1 %4190, i64 0
  %4192 = extractelement <8 x i32> %4072, i64 1
  %4193 = icmp ult i32 %4192, 8
  %4194 = select i1 %4193, i32 %4192, i32 0
  %4195 = extractelement <8 x i1> %119, i32 %4194
  %4196 = extractelement <8 x i1> %119, i64 1
  %4197 = and i1 %4193, %4195
  %4198 = and i1 %4196, %4197
  %4199 = extractelement <8 x i32> %4178, i32 %4194
  %4200 = select i1 %4198, i32 %4199, i32 0
  %4201 = insertelement <8 x i32> %4188, i32 %4200, i64 1
  %4202 = xor i1 %4198, true
  %4203 = and i1 %4196, %4202
  %4204 = insertelement <8 x i1> %4191, i1 %4203, i64 1
  %4205 = extractelement <8 x i32> %4072, i64 2
  %4206 = icmp ult i32 %4205, 8
  %4207 = select i1 %4206, i32 %4205, i32 0
  %4208 = extractelement <8 x i1> %119, i32 %4207
  %4209 = extractelement <8 x i1> %119, i64 2
  %4210 = and i1 %4206, %4208
  %4211 = and i1 %4209, %4210
  %4212 = extractelement <8 x i32> %4178, i32 %4207
  %4213 = select i1 %4211, i32 %4212, i32 0
  %4214 = insertelement <8 x i32> %4201, i32 %4213, i64 2
  %4215 = xor i1 %4211, true
  %4216 = and i1 %4209, %4215
  %4217 = insertelement <8 x i1> %4204, i1 %4216, i64 2
  %4218 = extractelement <8 x i32> %4072, i64 3
  %4219 = icmp ult i32 %4218, 8
  %4220 = select i1 %4219, i32 %4218, i32 0
  %4221 = extractelement <8 x i1> %119, i32 %4220
  %4222 = extractelement <8 x i1> %119, i64 3
  %4223 = and i1 %4219, %4221
  %4224 = and i1 %4222, %4223
  %4225 = extractelement <8 x i32> %4178, i32 %4220
  %4226 = select i1 %4224, i32 %4225, i32 0
  %4227 = insertelement <8 x i32> %4214, i32 %4226, i64 3
  %4228 = xor i1 %4224, true
  %4229 = and i1 %4222, %4228
  %4230 = insertelement <8 x i1> %4217, i1 %4229, i64 3
  %4231 = extractelement <8 x i32> %4072, i64 4
  %4232 = icmp ult i32 %4231, 8
  %4233 = select i1 %4232, i32 %4231, i32 0
  %4234 = extractelement <8 x i1> %119, i32 %4233
  %4235 = extractelement <8 x i1> %119, i64 4
  %4236 = and i1 %4232, %4234
  %4237 = and i1 %4235, %4236
  %4238 = extractelement <8 x i32> %4178, i32 %4233
  %4239 = select i1 %4237, i32 %4238, i32 0
  %4240 = insertelement <8 x i32> %4227, i32 %4239, i64 4
  %4241 = xor i1 %4237, true
  %4242 = and i1 %4235, %4241
  %4243 = insertelement <8 x i1> %4230, i1 %4242, i64 4
  %4244 = extractelement <8 x i32> %4072, i64 5
  %4245 = icmp ult i32 %4244, 8
  %4246 = select i1 %4245, i32 %4244, i32 0
  %4247 = extractelement <8 x i1> %119, i32 %4246
  %4248 = extractelement <8 x i1> %119, i64 5
  %4249 = and i1 %4245, %4247
  %4250 = and i1 %4248, %4249
  %4251 = extractelement <8 x i32> %4178, i32 %4246
  %4252 = select i1 %4250, i32 %4251, i32 0
  %4253 = insertelement <8 x i32> %4240, i32 %4252, i64 5
  %4254 = xor i1 %4250, true
  %4255 = and i1 %4248, %4254
  %4256 = insertelement <8 x i1> %4243, i1 %4255, i64 5
  %4257 = extractelement <8 x i32> %4072, i64 6
  %4258 = icmp ult i32 %4257, 8
  %4259 = select i1 %4258, i32 %4257, i32 0
  %4260 = extractelement <8 x i1> %119, i32 %4259
  %4261 = extractelement <8 x i1> %119, i64 6
  %4262 = and i1 %4258, %4260
  %4263 = and i1 %4261, %4262
  %4264 = extractelement <8 x i32> %4178, i32 %4259
  %4265 = select i1 %4263, i32 %4264, i32 0
  %4266 = insertelement <8 x i32> %4253, i32 %4265, i64 6
  %4267 = xor i1 %4263, true
  %4268 = and i1 %4261, %4267
  %4269 = insertelement <8 x i1> %4256, i1 %4268, i64 6
  %4270 = extractelement <8 x i32> %4072, i64 7
  %4271 = icmp ult i32 %4270, 8
  %4272 = select i1 %4271, i32 %4270, i32 0
  %4273 = extractelement <8 x i1> %119, i32 %4272
  %4274 = extractelement <8 x i1> %119, i64 7
  %4275 = and i1 %4271, %4273
  %4276 = and i1 %4274, %4275
  %4277 = extractelement <8 x i32> %4178, i32 %4272
  %4278 = select i1 %4276, i32 %4277, i32 0
  %4279 = insertelement <8 x i32> %4266, i32 %4278, i64 7
  %4280 = xor i1 %4276, true
  %4281 = and i1 %4274, %4280
  %4282 = insertelement <8 x i1> %4269, i1 %4281, i64 7
  %4283 = icmp ne <8 x i32> %4279, zeroinitializer
  %.state850 = load <8 x float>, ptr %.slot253, align 32
  %.state851 = load <8 x i1>, ptr %.slot254, align 1
  %4284 = select <8 x i1> %.state851, <8 x float> %.state850, <8 x float> %4173
  %.state852 = load <8 x i1>, ptr %.slot254, align 1
  %4285 = and <8 x i1> %.state852, %4283
  %4286 = select <8 x i1> %4285, <8 x float> %4177, <8 x float> %4284
  %.state853 = load <8 x i1>, ptr %.slot254, align 1
  %4287 = or <8 x i1> %.state853, %4283
  %4288 = xor <8 x i32> %4071, splat (i32 2)
  %4289 = extractelement <8 x i32> %4288, i64 0
  %4290 = icmp ult i32 %4289, 8
  %4291 = select i1 %4290, i32 %4289, i32 0
  %4292 = extractelement <8 x i1> %119, i32 %4291
  %4293 = extractelement <8 x i1> %119, i64 0
  %4294 = and i1 %4290, %4292
  %4295 = and i1 %4293, %4294
  %4296 = extractelement <8 x float> %4286, i32 %4291
  %4297 = select i1 %4295, float %4296, float 0.000000e+00
  %4298 = insertelement <8 x float> poison, float %4297, i64 0
  %4299 = xor i1 %4295, true
  %4300 = and i1 %4293, %4299
  %4301 = insertelement <8 x i1> poison, i1 %4300, i64 0
  %4302 = extractelement <8 x i32> %4288, i64 1
  %4303 = icmp ult i32 %4302, 8
  %4304 = select i1 %4303, i32 %4302, i32 0
  %4305 = extractelement <8 x i1> %119, i32 %4304
  %4306 = extractelement <8 x i1> %119, i64 1
  %4307 = and i1 %4303, %4305
  %4308 = and i1 %4306, %4307
  %4309 = extractelement <8 x float> %4286, i32 %4304
  %4310 = select i1 %4308, float %4309, float 0.000000e+00
  %4311 = insertelement <8 x float> %4298, float %4310, i64 1
  %4312 = xor i1 %4308, true
  %4313 = and i1 %4306, %4312
  %4314 = insertelement <8 x i1> %4301, i1 %4313, i64 1
  %4315 = extractelement <8 x i32> %4288, i64 2
  %4316 = icmp ult i32 %4315, 8
  %4317 = select i1 %4316, i32 %4315, i32 0
  %4318 = extractelement <8 x i1> %119, i32 %4317
  %4319 = extractelement <8 x i1> %119, i64 2
  %4320 = and i1 %4316, %4318
  %4321 = and i1 %4319, %4320
  %4322 = extractelement <8 x float> %4286, i32 %4317
  %4323 = select i1 %4321, float %4322, float 0.000000e+00
  %4324 = insertelement <8 x float> %4311, float %4323, i64 2
  %4325 = xor i1 %4321, true
  %4326 = and i1 %4319, %4325
  %4327 = insertelement <8 x i1> %4314, i1 %4326, i64 2
  %4328 = extractelement <8 x i32> %4288, i64 3
  %4329 = icmp ult i32 %4328, 8
  %4330 = select i1 %4329, i32 %4328, i32 0
  %4331 = extractelement <8 x i1> %119, i32 %4330
  %4332 = extractelement <8 x i1> %119, i64 3
  %4333 = and i1 %4329, %4331
  %4334 = and i1 %4332, %4333
  %4335 = extractelement <8 x float> %4286, i32 %4330
  %4336 = select i1 %4334, float %4335, float 0.000000e+00
  %4337 = insertelement <8 x float> %4324, float %4336, i64 3
  %4338 = xor i1 %4334, true
  %4339 = and i1 %4332, %4338
  %4340 = insertelement <8 x i1> %4327, i1 %4339, i64 3
  %4341 = extractelement <8 x i32> %4288, i64 4
  %4342 = icmp ult i32 %4341, 8
  %4343 = select i1 %4342, i32 %4341, i32 0
  %4344 = extractelement <8 x i1> %119, i32 %4343
  %4345 = extractelement <8 x i1> %119, i64 4
  %4346 = and i1 %4342, %4344
  %4347 = and i1 %4345, %4346
  %4348 = extractelement <8 x float> %4286, i32 %4343
  %4349 = select i1 %4347, float %4348, float 0.000000e+00
  %4350 = insertelement <8 x float> %4337, float %4349, i64 4
  %4351 = xor i1 %4347, true
  %4352 = and i1 %4345, %4351
  %4353 = insertelement <8 x i1> %4340, i1 %4352, i64 4
  %4354 = extractelement <8 x i32> %4288, i64 5
  %4355 = icmp ult i32 %4354, 8
  %4356 = select i1 %4355, i32 %4354, i32 0
  %4357 = extractelement <8 x i1> %119, i32 %4356
  %4358 = extractelement <8 x i1> %119, i64 5
  %4359 = and i1 %4355, %4357
  %4360 = and i1 %4358, %4359
  %4361 = extractelement <8 x float> %4286, i32 %4356
  %4362 = select i1 %4360, float %4361, float 0.000000e+00
  %4363 = insertelement <8 x float> %4350, float %4362, i64 5
  %4364 = xor i1 %4360, true
  %4365 = and i1 %4358, %4364
  %4366 = insertelement <8 x i1> %4353, i1 %4365, i64 5
  %4367 = extractelement <8 x i32> %4288, i64 6
  %4368 = icmp ult i32 %4367, 8
  %4369 = select i1 %4368, i32 %4367, i32 0
  %4370 = extractelement <8 x i1> %119, i32 %4369
  %4371 = extractelement <8 x i1> %119, i64 6
  %4372 = and i1 %4368, %4370
  %4373 = and i1 %4371, %4372
  %4374 = extractelement <8 x float> %4286, i32 %4369
  %4375 = select i1 %4373, float %4374, float 0.000000e+00
  %4376 = insertelement <8 x float> %4363, float %4375, i64 6
  %4377 = xor i1 %4373, true
  %4378 = and i1 %4371, %4377
  %4379 = insertelement <8 x i1> %4366, i1 %4378, i64 6
  %4380 = extractelement <8 x i32> %4288, i64 7
  %4381 = icmp ult i32 %4380, 8
  %4382 = select i1 %4381, i32 %4380, i32 0
  %4383 = extractelement <8 x i1> %119, i32 %4382
  %4384 = extractelement <8 x i1> %119, i64 7
  %4385 = and i1 %4381, %4383
  %4386 = and i1 %4384, %4385
  %4387 = extractelement <8 x float> %4286, i32 %4382
  %4388 = select i1 %4386, float %4387, float 0.000000e+00
  %4389 = insertelement <8 x float> %4376, float %4388, i64 7
  %4390 = xor i1 %4386, true
  %4391 = and i1 %4384, %4390
  %4392 = insertelement <8 x i1> %4379, i1 %4391, i64 7
  %4393 = fadd <8 x float> %4286, %4389
  %4394 = zext <8 x i1> %4287 to <8 x i32>
  %4395 = extractelement <8 x i32> %4288, i64 0
  %4396 = icmp ult i32 %4395, 8
  %4397 = select i1 %4396, i32 %4395, i32 0
  %4398 = extractelement <8 x i1> %119, i32 %4397
  %4399 = extractelement <8 x i1> %119, i64 0
  %4400 = and i1 %4396, %4398
  %4401 = and i1 %4399, %4400
  %4402 = extractelement <8 x i32> %4394, i32 %4397
  %4403 = select i1 %4401, i32 %4402, i32 0
  %4404 = insertelement <8 x i32> poison, i32 %4403, i64 0
  %4405 = xor i1 %4401, true
  %4406 = and i1 %4399, %4405
  %4407 = insertelement <8 x i1> poison, i1 %4406, i64 0
  %4408 = extractelement <8 x i32> %4288, i64 1
  %4409 = icmp ult i32 %4408, 8
  %4410 = select i1 %4409, i32 %4408, i32 0
  %4411 = extractelement <8 x i1> %119, i32 %4410
  %4412 = extractelement <8 x i1> %119, i64 1
  %4413 = and i1 %4409, %4411
  %4414 = and i1 %4412, %4413
  %4415 = extractelement <8 x i32> %4394, i32 %4410
  %4416 = select i1 %4414, i32 %4415, i32 0
  %4417 = insertelement <8 x i32> %4404, i32 %4416, i64 1
  %4418 = xor i1 %4414, true
  %4419 = and i1 %4412, %4418
  %4420 = insertelement <8 x i1> %4407, i1 %4419, i64 1
  %4421 = extractelement <8 x i32> %4288, i64 2
  %4422 = icmp ult i32 %4421, 8
  %4423 = select i1 %4422, i32 %4421, i32 0
  %4424 = extractelement <8 x i1> %119, i32 %4423
  %4425 = extractelement <8 x i1> %119, i64 2
  %4426 = and i1 %4422, %4424
  %4427 = and i1 %4425, %4426
  %4428 = extractelement <8 x i32> %4394, i32 %4423
  %4429 = select i1 %4427, i32 %4428, i32 0
  %4430 = insertelement <8 x i32> %4417, i32 %4429, i64 2
  %4431 = xor i1 %4427, true
  %4432 = and i1 %4425, %4431
  %4433 = insertelement <8 x i1> %4420, i1 %4432, i64 2
  %4434 = extractelement <8 x i32> %4288, i64 3
  %4435 = icmp ult i32 %4434, 8
  %4436 = select i1 %4435, i32 %4434, i32 0
  %4437 = extractelement <8 x i1> %119, i32 %4436
  %4438 = extractelement <8 x i1> %119, i64 3
  %4439 = and i1 %4435, %4437
  %4440 = and i1 %4438, %4439
  %4441 = extractelement <8 x i32> %4394, i32 %4436
  %4442 = select i1 %4440, i32 %4441, i32 0
  %4443 = insertelement <8 x i32> %4430, i32 %4442, i64 3
  %4444 = xor i1 %4440, true
  %4445 = and i1 %4438, %4444
  %4446 = insertelement <8 x i1> %4433, i1 %4445, i64 3
  %4447 = extractelement <8 x i32> %4288, i64 4
  %4448 = icmp ult i32 %4447, 8
  %4449 = select i1 %4448, i32 %4447, i32 0
  %4450 = extractelement <8 x i1> %119, i32 %4449
  %4451 = extractelement <8 x i1> %119, i64 4
  %4452 = and i1 %4448, %4450
  %4453 = and i1 %4451, %4452
  %4454 = extractelement <8 x i32> %4394, i32 %4449
  %4455 = select i1 %4453, i32 %4454, i32 0
  %4456 = insertelement <8 x i32> %4443, i32 %4455, i64 4
  %4457 = xor i1 %4453, true
  %4458 = and i1 %4451, %4457
  %4459 = insertelement <8 x i1> %4446, i1 %4458, i64 4
  %4460 = extractelement <8 x i32> %4288, i64 5
  %4461 = icmp ult i32 %4460, 8
  %4462 = select i1 %4461, i32 %4460, i32 0
  %4463 = extractelement <8 x i1> %119, i32 %4462
  %4464 = extractelement <8 x i1> %119, i64 5
  %4465 = and i1 %4461, %4463
  %4466 = and i1 %4464, %4465
  %4467 = extractelement <8 x i32> %4394, i32 %4462
  %4468 = select i1 %4466, i32 %4467, i32 0
  %4469 = insertelement <8 x i32> %4456, i32 %4468, i64 5
  %4470 = xor i1 %4466, true
  %4471 = and i1 %4464, %4470
  %4472 = insertelement <8 x i1> %4459, i1 %4471, i64 5
  %4473 = extractelement <8 x i32> %4288, i64 6
  %4474 = icmp ult i32 %4473, 8
  %4475 = select i1 %4474, i32 %4473, i32 0
  %4476 = extractelement <8 x i1> %119, i32 %4475
  %4477 = extractelement <8 x i1> %119, i64 6
  %4478 = and i1 %4474, %4476
  %4479 = and i1 %4477, %4478
  %4480 = extractelement <8 x i32> %4394, i32 %4475
  %4481 = select i1 %4479, i32 %4480, i32 0
  %4482 = insertelement <8 x i32> %4469, i32 %4481, i64 6
  %4483 = xor i1 %4479, true
  %4484 = and i1 %4477, %4483
  %4485 = insertelement <8 x i1> %4472, i1 %4484, i64 6
  %4486 = extractelement <8 x i32> %4288, i64 7
  %4487 = icmp ult i32 %4486, 8
  %4488 = select i1 %4487, i32 %4486, i32 0
  %4489 = extractelement <8 x i1> %119, i32 %4488
  %4490 = extractelement <8 x i1> %119, i64 7
  %4491 = and i1 %4487, %4489
  %4492 = and i1 %4490, %4491
  %4493 = extractelement <8 x i32> %4394, i32 %4488
  %4494 = select i1 %4492, i32 %4493, i32 0
  %4495 = insertelement <8 x i32> %4482, i32 %4494, i64 7
  %4496 = xor i1 %4492, true
  %4497 = and i1 %4490, %4496
  %4498 = insertelement <8 x i1> %4485, i1 %4497, i64 7
  %4499 = icmp ne <8 x i32> %4495, zeroinitializer
  %4500 = select <8 x i1> %4287, <8 x float> %4286, <8 x float> %4389
  %4501 = and <8 x i1> %4287, %4499
  %4502 = select <8 x i1> %4501, <8 x float> %4393, <8 x float> %4500
  %4503 = or <8 x i1> %4287, %4499
  %4504 = xor <8 x i32> %4071, splat (i32 4)
  %4505 = extractelement <8 x i32> %4504, i64 0
  %4506 = icmp ult i32 %4505, 8
  %4507 = select i1 %4506, i32 %4505, i32 0
  %4508 = extractelement <8 x i1> %119, i32 %4507
  %4509 = extractelement <8 x i1> %119, i64 0
  %4510 = and i1 %4506, %4508
  %4511 = and i1 %4509, %4510
  %4512 = extractelement <8 x float> %4502, i32 %4507
  %4513 = select i1 %4511, float %4512, float 0.000000e+00
  %4514 = insertelement <8 x float> poison, float %4513, i64 0
  %4515 = xor i1 %4511, true
  %4516 = and i1 %4509, %4515
  %4517 = insertelement <8 x i1> poison, i1 %4516, i64 0
  %4518 = extractelement <8 x i32> %4504, i64 1
  %4519 = icmp ult i32 %4518, 8
  %4520 = select i1 %4519, i32 %4518, i32 0
  %4521 = extractelement <8 x i1> %119, i32 %4520
  %4522 = extractelement <8 x i1> %119, i64 1
  %4523 = and i1 %4519, %4521
  %4524 = and i1 %4522, %4523
  %4525 = extractelement <8 x float> %4502, i32 %4520
  %4526 = select i1 %4524, float %4525, float 0.000000e+00
  %4527 = insertelement <8 x float> %4514, float %4526, i64 1
  %4528 = xor i1 %4524, true
  %4529 = and i1 %4522, %4528
  %4530 = insertelement <8 x i1> %4517, i1 %4529, i64 1
  %4531 = extractelement <8 x i32> %4504, i64 2
  %4532 = icmp ult i32 %4531, 8
  %4533 = select i1 %4532, i32 %4531, i32 0
  %4534 = extractelement <8 x i1> %119, i32 %4533
  %4535 = extractelement <8 x i1> %119, i64 2
  %4536 = and i1 %4532, %4534
  %4537 = and i1 %4535, %4536
  %4538 = extractelement <8 x float> %4502, i32 %4533
  %4539 = select i1 %4537, float %4538, float 0.000000e+00
  %4540 = insertelement <8 x float> %4527, float %4539, i64 2
  %4541 = xor i1 %4537, true
  %4542 = and i1 %4535, %4541
  %4543 = insertelement <8 x i1> %4530, i1 %4542, i64 2
  %4544 = extractelement <8 x i32> %4504, i64 3
  %4545 = icmp ult i32 %4544, 8
  %4546 = select i1 %4545, i32 %4544, i32 0
  %4547 = extractelement <8 x i1> %119, i32 %4546
  %4548 = extractelement <8 x i1> %119, i64 3
  %4549 = and i1 %4545, %4547
  %4550 = and i1 %4548, %4549
  %4551 = extractelement <8 x float> %4502, i32 %4546
  %4552 = select i1 %4550, float %4551, float 0.000000e+00
  %4553 = insertelement <8 x float> %4540, float %4552, i64 3
  %4554 = xor i1 %4550, true
  %4555 = and i1 %4548, %4554
  %4556 = insertelement <8 x i1> %4543, i1 %4555, i64 3
  %4557 = extractelement <8 x i32> %4504, i64 4
  %4558 = icmp ult i32 %4557, 8
  %4559 = select i1 %4558, i32 %4557, i32 0
  %4560 = extractelement <8 x i1> %119, i32 %4559
  %4561 = extractelement <8 x i1> %119, i64 4
  %4562 = and i1 %4558, %4560
  %4563 = and i1 %4561, %4562
  %4564 = extractelement <8 x float> %4502, i32 %4559
  %4565 = select i1 %4563, float %4564, float 0.000000e+00
  %4566 = insertelement <8 x float> %4553, float %4565, i64 4
  %4567 = xor i1 %4563, true
  %4568 = and i1 %4561, %4567
  %4569 = insertelement <8 x i1> %4556, i1 %4568, i64 4
  %4570 = extractelement <8 x i32> %4504, i64 5
  %4571 = icmp ult i32 %4570, 8
  %4572 = select i1 %4571, i32 %4570, i32 0
  %4573 = extractelement <8 x i1> %119, i32 %4572
  %4574 = extractelement <8 x i1> %119, i64 5
  %4575 = and i1 %4571, %4573
  %4576 = and i1 %4574, %4575
  %4577 = extractelement <8 x float> %4502, i32 %4572
  %4578 = select i1 %4576, float %4577, float 0.000000e+00
  %4579 = insertelement <8 x float> %4566, float %4578, i64 5
  %4580 = xor i1 %4576, true
  %4581 = and i1 %4574, %4580
  %4582 = insertelement <8 x i1> %4569, i1 %4581, i64 5
  %4583 = extractelement <8 x i32> %4504, i64 6
  %4584 = icmp ult i32 %4583, 8
  %4585 = select i1 %4584, i32 %4583, i32 0
  %4586 = extractelement <8 x i1> %119, i32 %4585
  %4587 = extractelement <8 x i1> %119, i64 6
  %4588 = and i1 %4584, %4586
  %4589 = and i1 %4587, %4588
  %4590 = extractelement <8 x float> %4502, i32 %4585
  %4591 = select i1 %4589, float %4590, float 0.000000e+00
  %4592 = insertelement <8 x float> %4579, float %4591, i64 6
  %4593 = xor i1 %4589, true
  %4594 = and i1 %4587, %4593
  %4595 = insertelement <8 x i1> %4582, i1 %4594, i64 6
  %4596 = extractelement <8 x i32> %4504, i64 7
  %4597 = icmp ult i32 %4596, 8
  %4598 = select i1 %4597, i32 %4596, i32 0
  %4599 = extractelement <8 x i1> %119, i32 %4598
  %4600 = extractelement <8 x i1> %119, i64 7
  %4601 = and i1 %4597, %4599
  %4602 = and i1 %4600, %4601
  %4603 = extractelement <8 x float> %4502, i32 %4598
  %4604 = select i1 %4602, float %4603, float 0.000000e+00
  %4605 = insertelement <8 x float> %4592, float %4604, i64 7
  %4606 = xor i1 %4602, true
  %4607 = and i1 %4600, %4606
  %4608 = insertelement <8 x i1> %4595, i1 %4607, i64 7
  %4609 = fadd <8 x float> %4502, %4605
  %4610 = zext <8 x i1> %4503 to <8 x i32>
  %4611 = extractelement <8 x i32> %4504, i64 0
  %4612 = icmp ult i32 %4611, 8
  %4613 = select i1 %4612, i32 %4611, i32 0
  %4614 = extractelement <8 x i1> %119, i32 %4613
  %4615 = extractelement <8 x i1> %119, i64 0
  %4616 = and i1 %4612, %4614
  %4617 = and i1 %4615, %4616
  %4618 = extractelement <8 x i32> %4610, i32 %4613
  %4619 = select i1 %4617, i32 %4618, i32 0
  %4620 = insertelement <8 x i32> poison, i32 %4619, i64 0
  %4621 = xor i1 %4617, true
  %4622 = and i1 %4615, %4621
  %4623 = insertelement <8 x i1> poison, i1 %4622, i64 0
  %4624 = extractelement <8 x i32> %4504, i64 1
  %4625 = icmp ult i32 %4624, 8
  %4626 = select i1 %4625, i32 %4624, i32 0
  %4627 = extractelement <8 x i1> %119, i32 %4626
  %4628 = extractelement <8 x i1> %119, i64 1
  %4629 = and i1 %4625, %4627
  %4630 = and i1 %4628, %4629
  %4631 = extractelement <8 x i32> %4610, i32 %4626
  %4632 = select i1 %4630, i32 %4631, i32 0
  %4633 = insertelement <8 x i32> %4620, i32 %4632, i64 1
  %4634 = xor i1 %4630, true
  %4635 = and i1 %4628, %4634
  %4636 = insertelement <8 x i1> %4623, i1 %4635, i64 1
  %4637 = extractelement <8 x i32> %4504, i64 2
  %4638 = icmp ult i32 %4637, 8
  %4639 = select i1 %4638, i32 %4637, i32 0
  %4640 = extractelement <8 x i1> %119, i32 %4639
  %4641 = extractelement <8 x i1> %119, i64 2
  %4642 = and i1 %4638, %4640
  %4643 = and i1 %4641, %4642
  %4644 = extractelement <8 x i32> %4610, i32 %4639
  %4645 = select i1 %4643, i32 %4644, i32 0
  %4646 = insertelement <8 x i32> %4633, i32 %4645, i64 2
  %4647 = xor i1 %4643, true
  %4648 = and i1 %4641, %4647
  %4649 = insertelement <8 x i1> %4636, i1 %4648, i64 2
  %4650 = extractelement <8 x i32> %4504, i64 3
  %4651 = icmp ult i32 %4650, 8
  %4652 = select i1 %4651, i32 %4650, i32 0
  %4653 = extractelement <8 x i1> %119, i32 %4652
  %4654 = extractelement <8 x i1> %119, i64 3
  %4655 = and i1 %4651, %4653
  %4656 = and i1 %4654, %4655
  %4657 = extractelement <8 x i32> %4610, i32 %4652
  %4658 = select i1 %4656, i32 %4657, i32 0
  %4659 = insertelement <8 x i32> %4646, i32 %4658, i64 3
  %4660 = xor i1 %4656, true
  %4661 = and i1 %4654, %4660
  %4662 = insertelement <8 x i1> %4649, i1 %4661, i64 3
  %4663 = extractelement <8 x i32> %4504, i64 4
  %4664 = icmp ult i32 %4663, 8
  %4665 = select i1 %4664, i32 %4663, i32 0
  %4666 = extractelement <8 x i1> %119, i32 %4665
  %4667 = extractelement <8 x i1> %119, i64 4
  %4668 = and i1 %4664, %4666
  %4669 = and i1 %4667, %4668
  %4670 = extractelement <8 x i32> %4610, i32 %4665
  %4671 = select i1 %4669, i32 %4670, i32 0
  %4672 = insertelement <8 x i32> %4659, i32 %4671, i64 4
  %4673 = xor i1 %4669, true
  %4674 = and i1 %4667, %4673
  %4675 = insertelement <8 x i1> %4662, i1 %4674, i64 4
  %4676 = extractelement <8 x i32> %4504, i64 5
  %4677 = icmp ult i32 %4676, 8
  %4678 = select i1 %4677, i32 %4676, i32 0
  %4679 = extractelement <8 x i1> %119, i32 %4678
  %4680 = extractelement <8 x i1> %119, i64 5
  %4681 = and i1 %4677, %4679
  %4682 = and i1 %4680, %4681
  %4683 = extractelement <8 x i32> %4610, i32 %4678
  %4684 = select i1 %4682, i32 %4683, i32 0
  %4685 = insertelement <8 x i32> %4672, i32 %4684, i64 5
  %4686 = xor i1 %4682, true
  %4687 = and i1 %4680, %4686
  %4688 = insertelement <8 x i1> %4675, i1 %4687, i64 5
  %4689 = extractelement <8 x i32> %4504, i64 6
  %4690 = icmp ult i32 %4689, 8
  %4691 = select i1 %4690, i32 %4689, i32 0
  %4692 = extractelement <8 x i1> %119, i32 %4691
  %4693 = extractelement <8 x i1> %119, i64 6
  %4694 = and i1 %4690, %4692
  %4695 = and i1 %4693, %4694
  %4696 = extractelement <8 x i32> %4610, i32 %4691
  %4697 = select i1 %4695, i32 %4696, i32 0
  %4698 = insertelement <8 x i32> %4685, i32 %4697, i64 6
  %4699 = xor i1 %4695, true
  %4700 = and i1 %4693, %4699
  %4701 = insertelement <8 x i1> %4688, i1 %4700, i64 6
  %4702 = extractelement <8 x i32> %4504, i64 7
  %4703 = icmp ult i32 %4702, 8
  %4704 = select i1 %4703, i32 %4702, i32 0
  %4705 = extractelement <8 x i1> %119, i32 %4704
  %4706 = extractelement <8 x i1> %119, i64 7
  %4707 = and i1 %4703, %4705
  %4708 = and i1 %4706, %4707
  %4709 = extractelement <8 x i32> %4610, i32 %4704
  %4710 = select i1 %4708, i32 %4709, i32 0
  %4711 = insertelement <8 x i32> %4698, i32 %4710, i64 7
  %4712 = xor i1 %4708, true
  %4713 = and i1 %4706, %4712
  %4714 = insertelement <8 x i1> %4701, i1 %4713, i64 7
  %4715 = icmp ne <8 x i32> %4711, zeroinitializer
  %4716 = select <8 x i1> %4503, <8 x float> %4502, <8 x float> %4605
  %4717 = and <8 x i1> %4503, %4715
  %4718 = select <8 x i1> %4717, <8 x float> %4609, <8 x float> %4716
  %4719 = extractelement <8 x i1> %119, i32 0
  %4720 = extractelement <8 x i1> %119, i64 0
  %4721 = and i1 true, %4719
  %4722 = and i1 %4720, %4721
  %4723 = extractelement <8 x float> %4718, i32 0
  %4724 = select i1 %4722, float %4723, float 0.000000e+00
  %4725 = insertelement <8 x float> poison, float %4724, i64 0
  %4726 = xor i1 %4722, true
  %4727 = and i1 %4720, %4726
  %4728 = insertelement <8 x i1> poison, i1 %4727, i64 0
  %4729 = extractelement <8 x i1> %119, i32 0
  %4730 = extractelement <8 x i1> %119, i64 1
  %4731 = and i1 true, %4729
  %4732 = and i1 %4730, %4731
  %4733 = extractelement <8 x float> %4718, i32 0
  %4734 = select i1 %4732, float %4733, float 0.000000e+00
  %4735 = insertelement <8 x float> %4725, float %4734, i64 1
  %4736 = xor i1 %4732, true
  %4737 = and i1 %4730, %4736
  %4738 = insertelement <8 x i1> %4728, i1 %4737, i64 1
  %4739 = extractelement <8 x i1> %119, i32 0
  %4740 = extractelement <8 x i1> %119, i64 2
  %4741 = and i1 true, %4739
  %4742 = and i1 %4740, %4741
  %4743 = extractelement <8 x float> %4718, i32 0
  %4744 = select i1 %4742, float %4743, float 0.000000e+00
  %4745 = insertelement <8 x float> %4735, float %4744, i64 2
  %4746 = xor i1 %4742, true
  %4747 = and i1 %4740, %4746
  %4748 = insertelement <8 x i1> %4738, i1 %4747, i64 2
  %4749 = extractelement <8 x i1> %119, i32 0
  %4750 = extractelement <8 x i1> %119, i64 3
  %4751 = and i1 true, %4749
  %4752 = and i1 %4750, %4751
  %4753 = extractelement <8 x float> %4718, i32 0
  %4754 = select i1 %4752, float %4753, float 0.000000e+00
  %4755 = insertelement <8 x float> %4745, float %4754, i64 3
  %4756 = xor i1 %4752, true
  %4757 = and i1 %4750, %4756
  %4758 = insertelement <8 x i1> %4748, i1 %4757, i64 3
  %4759 = extractelement <8 x i1> %119, i32 0
  %4760 = extractelement <8 x i1> %119, i64 4
  %4761 = and i1 true, %4759
  %4762 = and i1 %4760, %4761
  %4763 = extractelement <8 x float> %4718, i32 0
  %4764 = select i1 %4762, float %4763, float 0.000000e+00
  %4765 = insertelement <8 x float> %4755, float %4764, i64 4
  %4766 = xor i1 %4762, true
  %4767 = and i1 %4760, %4766
  %4768 = insertelement <8 x i1> %4758, i1 %4767, i64 4
  %4769 = extractelement <8 x i1> %119, i32 0
  %4770 = extractelement <8 x i1> %119, i64 5
  %4771 = and i1 true, %4769
  %4772 = and i1 %4770, %4771
  %4773 = extractelement <8 x float> %4718, i32 0
  %4774 = select i1 %4772, float %4773, float 0.000000e+00
  %4775 = insertelement <8 x float> %4765, float %4774, i64 5
  %4776 = xor i1 %4772, true
  %4777 = and i1 %4770, %4776
  %4778 = insertelement <8 x i1> %4768, i1 %4777, i64 5
  %4779 = extractelement <8 x i1> %119, i32 0
  %4780 = extractelement <8 x i1> %119, i64 6
  %4781 = and i1 true, %4779
  %4782 = and i1 %4780, %4781
  %4783 = extractelement <8 x float> %4718, i32 0
  %4784 = select i1 %4782, float %4783, float 0.000000e+00
  %4785 = insertelement <8 x float> %4775, float %4784, i64 6
  %4786 = xor i1 %4782, true
  %4787 = and i1 %4780, %4786
  %4788 = insertelement <8 x i1> %4778, i1 %4787, i64 6
  %4789 = extractelement <8 x i1> %119, i32 0
  %4790 = extractelement <8 x i1> %119, i64 7
  %4791 = and i1 true, %4789
  %4792 = and i1 %4790, %4791
  %4793 = extractelement <8 x float> %4718, i32 0
  %4794 = select i1 %4792, float %4793, float 0.000000e+00
  %4795 = insertelement <8 x float> %4785, float %4794, i64 7
  %4796 = xor i1 %4792, true
  %4797 = and i1 %4790, %4796
  %4798 = insertelement <8 x i1> %4788, i1 %4797, i64 7
  %4799 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  %4800 = bitcast <8 x i1> %119 to i8
  %4801 = call i8 @llvm.cttz.i8(i8 %4800, i1 false)
  %4802 = zext i8 %4801 to i32
  %4803 = select i1 %4799, i32 %4802, i32 0
  %4804 = extractelement <8 x float> %4795, i32 %4803
  %4805 = fadd float 0.000000e+00, %4804
  %tile_snapshot.spill.load854 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill249, align 64
  %4806 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load854, 0
  %4807 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load854, 1
  %.state855 = load <8 x i64>, ptr %.slot250, align 64
  %4808 = mul <8 x i64> %.state855, splat (i64 32)
  %4809 = add <8 x i64> %4807, %4808
  %4810 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4806, 0
  %4811 = insertvalue { <8 x ptr>, <8 x i64> } %4810, <8 x i64> %4809, 1
  %.splatinsert856 = insertelement <8 x float> poison, float %4805, i64 0
  %.splat857 = shufflevector <8 x float> %.splatinsert856, <8 x float> poison, <8 x i32> zeroinitializer
  %4812 = extractvalue { <8 x ptr>, <8 x i64> } %63, 0
  %4813 = extractvalue { <8 x ptr>, <8 x i64> } %4811, 1
  %4814 = extractelement <8 x ptr> %4812, i32 0
  %4815 = extractelement <8 x i64> %4813, i32 0
  %4816 = sub i64 %4815, 0
  %4817 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %119)
  %4818 = select i1 %4817, i64 %4816, i64 0
  %private.contiguous.address858 = getelementptr i8, ptr %4814, i64 %4818
  %private.contiguous.preserve859 = load <8 x float>, ptr %private.contiguous.address858, align 4
  %4819 = select <8 x i1> %119, <8 x float> %.splat857, <8 x float> %private.contiguous.preserve859
  store <8 x float> %4819, ptr %private.contiguous.address858, align 4
  %.state860 = load <8 x i64>, ptr %.slot250, align 64
  %4820 = add <8 x i64> %.state860, splat (i64 1)
  %4821 = load <8 x i64>, ptr %.slot250, align 64
  %4822 = select <8 x i1> %119, <8 x i64> %4820, <8 x i64> %4821
  store <8 x i64> %4822, ptr %.slot250, align 64
  br label %direct.schedule.209

direct.schedule.216:                              ; preds = %direct.false825
  %4823 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill257, align 64
  %4824 = extractvalue { <8 x ptr>, <8 x i64> } %65, 0
  %4825 = extractvalue { <8 x ptr>, <8 x i64> } %4823, 0
  %4826 = select <8 x i1> %119, <8 x ptr> %4824, <8 x ptr> %4825
  %4827 = extractvalue { <8 x ptr>, <8 x i64> } %65, 1
  %4828 = extractvalue { <8 x ptr>, <8 x i64> } %4823, 1
  %4829 = select <8 x i1> %119, <8 x i64> %4827, <8 x i64> %4828
  %4830 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4826, 0
  %4831 = insertvalue { <8 x ptr>, <8 x i64> } %4830, <8 x i64> %4829, 1
  store { <8 x ptr>, <8 x i64> } %4831, ptr %tile_snapshot.spill257, align 64
  %4832 = load <8 x i64>, ptr %.slot258, align 64
  %4833 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %4832
  store <8 x i64> %4833, ptr %.slot258, align 64
  br label %direct.schedule.217

direct.schedule.217:                              ; preds = %direct.schedule.224, %direct.schedule.216
  %.state861 = load <8 x i64>, ptr %.slot258, align 64
  %4834 = icmp slt <8 x i64> %.state861, splat (i64 1)
  %4835 = extractelement <8 x i1> %4834, i32 0
  br i1 %4835, label %direct.true862, label %direct.false863

direct.schedule.218:                              ; preds = %direct.true862
  %.state864 = load <8 x i64>, ptr %.slot258, align 64
  %4836 = select <8 x i1> %119, <8 x i64> %.state864, <8 x i64> zeroinitializer
  %4837 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4838 = srem <8 x i64> %4836, %4837
  %4839 = mul <8 x i64> %4838, splat (i64 8)
  %.spill.load865 = load <8 x i64>, ptr %.spill, align 64
  %4840 = add <8 x i64> %4839, %.spill.load865
  %4841 = icmp slt <8 x i64> %4840, splat (i64 2)
  %4842 = load <8 x i1>, ptr %.spill259, align 1
  %4843 = select <8 x i1> %119, <8 x i1> %4841, <8 x i1> %4842
  store <8 x i1> %4843, ptr %.spill259, align 1
  %4844 = select <8 x i1> %4841, <8 x i64> %4840, <8 x i64> splat (i64 1)
  %4845 = add <8 x i64> zeroinitializer, %4844
  %4846 = load <8 x i64>, ptr %.spill260, align 64
  %4847 = select <8 x i1> %119, <8 x i64> %4845, <8 x i64> %4846
  store <8 x i64> %4847, ptr %.spill260, align 64
  %4848 = add <8 x i64> zeroinitializer, %4838
  %4849 = and <8 x i1> %119, %4841
  %4850 = xor <8 x i1> %4841, splat (i1 true)
  %4851 = and <8 x i1> %119, %4850
  %4852 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4849)
  %4853 = bitcast <8 x i1> %4849 to i8
  %4854 = call i8 @llvm.cttz.i8(i8 %4853, i1 false)
  %4855 = zext i8 %4854 to i32
  %4856 = select i1 %4852, i32 %4855, i32 0
  %tile_snapshot.spill.load866 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill243, align 64
  %4857 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load866, 0
  %4858 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load866, 1
  %4859 = mul <8 x i64> %4848, splat (i64 32)
  %4860 = add <8 x i64> %4858, %4859
  %4861 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4857, 0
  %4862 = insertvalue { <8 x ptr>, <8 x i64> } %4861, <8 x i64> %4860, 1
  %4863 = extractvalue { <8 x ptr>, <8 x i64> } %61, 0
  %4864 = extractvalue { <8 x ptr>, <8 x i64> } %4862, 1
  %4865 = extractelement <8 x ptr> %4863, i32 0
  %4866 = extractelement <8 x i64> %4864, i32 %4856
  %4867 = zext i32 %4856 to i64
  %4868 = mul i64 %4867, 4
  %4869 = sub i64 %4866, %4868
  %4870 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4849)
  %4871 = select i1 %4870, i64 %4869, i64 0
  %private.contiguous.address867 = getelementptr i8, ptr %4865, i64 %4871
  %private.contiguous.load868 = load <8 x float>, ptr %private.contiguous.address867, align 4
  %4872 = select <8 x i1> %4849, <8 x float> %private.contiguous.load868, <8 x float> zeroinitializer
  %4873 = load <8 x float>, ptr %.slot261, align 32
  %4874 = select <8 x i1> %4849, <8 x float> %4872, <8 x float> %4873
  store <8 x float> %4874, ptr %.slot261, align 32
  %4875 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4851)
  %4876 = bitcast <8 x i1> %4851 to i8
  %4877 = call i8 @llvm.cttz.i8(i8 %4876, i1 false)
  %4878 = zext i8 %4877 to i32
  %4879 = select i1 %4875, i32 %4878, i32 0
  %4880 = load <8 x float>, ptr %.slot261, align 32
  %4881 = select <8 x i1> %4851, <8 x float> zeroinitializer, <8 x float> %4880
  store <8 x float> %4881, ptr %.slot261, align 32
  br label %direct.schedule.220

direct.schedule.220:                              ; preds = %direct.schedule.218
  %.spill.load869 = load <8 x i1>, ptr %.spill259, align 1
  %4882 = and <8 x i1> %119, %.spill.load869
  %4883 = xor <8 x i1> %.spill.load869, splat (i1 true)
  %4884 = and <8 x i1> %119, %4883
  %4885 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4882)
  %4886 = bitcast <8 x i1> %4882 to i8
  %4887 = call i8 @llvm.cttz.i8(i8 %4886, i1 false)
  %4888 = zext i8 %4887 to i32
  %4889 = select i1 %4885, i32 %4888, i32 0
  %tile_snapshot.spill.load870 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill249, align 64
  %4890 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load870, 0
  %4891 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load870, 1
  %.spill.load871 = load <8 x i64>, ptr %.spill260, align 64
  %4892 = mul <8 x i64> %.spill.load871, splat (i64 32)
  %4893 = add <8 x i64> %4891, %4892
  %4894 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4890, 0
  %4895 = insertvalue { <8 x ptr>, <8 x i64> } %4894, <8 x i64> %4893, 1
  %4896 = extractvalue { <8 x ptr>, <8 x i64> } %4895, 0
  %4897 = extractvalue { <8 x ptr>, <8 x i64> } %4895, 1
  %4898 = getelementptr i8, <8 x ptr> %4896, <8 x i64> %4897
  %4899 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %4898, <8 x i1> %4882, <8 x float> zeroinitializer)
  %4900 = load <8 x float>, ptr %.slot262, align 32
  %4901 = select <8 x i1> %4882, <8 x float> %4899, <8 x float> %4900
  store <8 x float> %4901, ptr %.slot262, align 32
  %4902 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4884)
  %4903 = bitcast <8 x i1> %4884 to i8
  %4904 = call i8 @llvm.cttz.i8(i8 %4903, i1 false)
  %4905 = zext i8 %4904 to i32
  %4906 = select i1 %4902, i32 %4905, i32 0
  %4907 = load <8 x float>, ptr %.slot262, align 32
  %4908 = select <8 x i1> %4884, <8 x float> zeroinitializer, <8 x float> %4907
  store <8 x float> %4908, ptr %.slot262, align 32
  br label %direct.schedule.222

direct.schedule.222:                              ; preds = %direct.schedule.220
  %.state872 = load <8 x float>, ptr %.slot261, align 32
  %.state873 = load <8 x float>, ptr %.slot262, align 32
  %4909 = fadd <8 x float> %.state872, %.state873
  %.spill.load874 = load <8 x i1>, ptr %.spill259, align 1
  %4910 = and <8 x i1> %119, %.spill.load874
  %4911 = xor <8 x i1> %.spill.load874, splat (i1 true)
  %4912 = and <8 x i1> %119, %4911
  %4913 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4910)
  %4914 = bitcast <8 x i1> %4910 to i8
  %4915 = call i8 @llvm.cttz.i8(i8 %4914, i1 false)
  %4916 = zext i8 %4915 to i32
  %4917 = select i1 %4913, i32 %4916, i32 0
  %tile_snapshot.spill.load875 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill257, align 64
  %4918 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 0
  %4919 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load875, 1
  %.state876 = load <8 x i64>, ptr %.slot258, align 64
  %4920 = mul <8 x i64> %.state876, splat (i64 32)
  %4921 = add <8 x i64> %4919, %4920
  %4922 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4918, 0
  %4923 = insertvalue { <8 x ptr>, <8 x i64> } %4922, <8 x i64> %4921, 1
  %4924 = extractvalue { <8 x ptr>, <8 x i64> } %65, 0
  %4925 = extractvalue { <8 x ptr>, <8 x i64> } %4923, 1
  %4926 = extractelement <8 x ptr> %4924, i32 0
  %4927 = extractelement <8 x i64> %4925, i32 %4917
  %4928 = zext i32 %4917 to i64
  %4929 = mul i64 %4928, 4
  %4930 = sub i64 %4927, %4929
  %4931 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4910)
  %4932 = select i1 %4931, i64 %4930, i64 0
  %private.contiguous.address877 = getelementptr i8, ptr %4926, i64 %4932
  %private.contiguous.preserve878 = load <8 x float>, ptr %private.contiguous.address877, align 4
  %4933 = select <8 x i1> %4910, <8 x float> %4909, <8 x float> %private.contiguous.preserve878
  store <8 x float> %4933, ptr %private.contiguous.address877, align 4
  %4934 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4912)
  %4935 = bitcast <8 x i1> %4912 to i8
  %4936 = call i8 @llvm.cttz.i8(i8 %4935, i1 false)
  %4937 = zext i8 %4936 to i32
  %4938 = select i1 %4934, i32 %4937, i32 0
  br label %direct.schedule.224

direct.schedule.224:                              ; preds = %direct.schedule.222
  %.state879 = load <8 x i64>, ptr %.slot258, align 64
  %4939 = add <8 x i64> %.state879, splat (i64 1)
  %4940 = load <8 x i64>, ptr %.slot258, align 64
  %4941 = select <8 x i1> %119, <8 x i64> %4939, <8 x i64> %4940
  store <8 x i64> %4941, ptr %.slot258, align 64
  br label %direct.schedule.217

direct.schedule.225:                              ; preds = %direct.false863
  %4942 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %4943 = extractvalue { <8 x ptr>, <8 x i64> } %67, 0
  %4944 = extractvalue { <8 x ptr>, <8 x i64> } %4942, 0
  %4945 = select <8 x i1> %119, <8 x ptr> %4943, <8 x ptr> %4944
  %4946 = extractvalue { <8 x ptr>, <8 x i64> } %67, 1
  %4947 = extractvalue { <8 x ptr>, <8 x i64> } %4942, 1
  %4948 = select <8 x i1> %119, <8 x i64> %4946, <8 x i64> %4947
  %4949 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4945, 0
  %4950 = insertvalue { <8 x ptr>, <8 x i64> } %4949, <8 x i64> %4948, 1
  store { <8 x ptr>, <8 x i64> } %4950, ptr %tile_snapshot.spill263, align 64
  %4951 = load <8 x i64>, ptr %.slot264, align 64
  %4952 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %4951
  store <8 x i64> %4952, ptr %.slot264, align 64
  br label %direct.schedule.226

direct.schedule.226:                              ; preds = %direct.schedule.233, %direct.schedule.225
  %.state880 = load <8 x i64>, ptr %.slot264, align 64
  %4953 = icmp slt <8 x i64> %.state880, splat (i64 2)
  %4954 = extractelement <8 x i1> %4953, i32 0
  br i1 %4954, label %direct.true881, label %direct.false882

direct.schedule.227:                              ; preds = %direct.true881
  %.state883 = load <8 x i64>, ptr %.slot264, align 64
  %4955 = select <8 x i1> %119, <8 x i64> %.state883, <8 x i64> zeroinitializer
  %4956 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4957 = srem <8 x i64> %4955, %4956
  %.state884 = load <8 x i64>, ptr %.slot264, align 64
  %4958 = select <8 x i1> %119, <8 x i64> %.state884, <8 x i64> zeroinitializer
  %4959 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %4960 = sdiv <8 x i64> %4958, %4959
  %4961 = mul <8 x i64> %4957, splat (i64 8)
  %.spill.load885 = load <8 x i64>, ptr %.spill, align 64
  %4962 = add <8 x i64> %4961, %.spill.load885
  %4963 = icmp slt <8 x i64> %4962, splat (i64 3)
  %4964 = load <8 x i1>, ptr %.spill265, align 1
  %4965 = select <8 x i1> %119, <8 x i1> %4963, <8 x i1> %4964
  store <8 x i1> %4965, ptr %.spill265, align 1
  %4966 = select <8 x i1> %119, <8 x i64> %4960, <8 x i64> zeroinitializer
  %4967 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %4968 = srem <8 x i64> %4966, %4967
  %4969 = load <8 x i64>, ptr %.spill266, align 64
  %4970 = select <8 x i1> %119, <8 x i64> %4968, <8 x i64> %4969
  store <8 x i64> %4970, ptr %.spill266, align 64
  store i64 0, ptr %.spill267, align 4
  %4971 = add <8 x i64> zeroinitializer, %4968
  %4972 = mul <8 x i64> %4971, splat (i64 1)
  %4973 = add <8 x i64> %4972, %4957
  %4974 = and <8 x i1> %119, %4963
  %4975 = xor <8 x i1> %4963, splat (i1 true)
  %4976 = and <8 x i1> %119, %4975
  %4977 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4974)
  %4978 = bitcast <8 x i1> %4974 to i8
  %4979 = call i8 @llvm.cttz.i8(i8 %4978, i1 false)
  %4980 = zext i8 %4979 to i32
  %4981 = select i1 %4977, i32 %4980, i32 0
  %tile_snapshot.spill.load886 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %4982 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load886, 0
  %4983 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load886, 1
  %4984 = mul <8 x i64> %4973, splat (i64 32)
  %4985 = add <8 x i64> %4983, %4984
  %4986 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %4982, 0
  %4987 = insertvalue { <8 x ptr>, <8 x i64> } %4986, <8 x i64> %4985, 1
  %4988 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %4989 = extractvalue { <8 x ptr>, <8 x i64> } %4987, 1
  %4990 = extractelement <8 x ptr> %4988, i32 0
  %4991 = extractelement <8 x i64> %4989, i32 %4981
  %4992 = zext i32 %4981 to i64
  %4993 = mul i64 %4992, 4
  %4994 = sub i64 %4991, %4993
  %4995 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4974)
  %4996 = select i1 %4995, i64 %4994, i64 0
  %private.contiguous.address887 = getelementptr i8, ptr %4990, i64 %4996
  %private.contiguous.load888 = load <8 x float>, ptr %private.contiguous.address887, align 4
  %4997 = select <8 x i1> %4974, <8 x float> %private.contiguous.load888, <8 x float> zeroinitializer
  %4998 = load <8 x float>, ptr %.slot268, align 32
  %4999 = select <8 x i1> %4974, <8 x float> %4997, <8 x float> %4998
  store <8 x float> %4999, ptr %.slot268, align 32
  %5000 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %4976)
  %5001 = bitcast <8 x i1> %4976 to i8
  %5002 = call i8 @llvm.cttz.i8(i8 %5001, i1 false)
  %5003 = zext i8 %5002 to i32
  %5004 = select i1 %5000, i32 %5003, i32 0
  %5005 = load <8 x float>, ptr %.slot268, align 32
  %5006 = select <8 x i1> %4976, <8 x float> zeroinitializer, <8 x float> %5005
  store <8 x float> %5006, ptr %.slot268, align 32
  br label %direct.schedule.229

direct.schedule.229:                              ; preds = %direct.schedule.227
  %.spill.load889 = load <8 x i64>, ptr %.spill266, align 64
  %5007 = select <8 x i1> %119, <8 x i64> %.spill.load889, <8 x i64> zeroinitializer
  %5008 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %5009 = sdiv <8 x i64> %5007, %5008
  %.spill.load890 = load i64, ptr %.spill267, align 4
  %5010 = mul i64 %.spill.load890, 1
  %.splatinsert891 = insertelement <8 x i64> poison, i64 %5010, i64 0
  %.splat892 = shufflevector <8 x i64> %.splatinsert891, <8 x i64> poison, <8 x i32> zeroinitializer
  %5011 = add <8 x i64> %.splat892, %5009
  %.spill.load893 = load <8 x i64>, ptr %.spill266, align 64
  %5012 = select <8 x i1> %119, <8 x i64> %.spill.load893, <8 x i64> zeroinitializer
  %5013 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %5014 = srem <8 x i64> %5012, %5013
  %5015 = load <8 x i64>, ptr %.spill269, align 64
  %5016 = select <8 x i1> %119, <8 x i64> %5014, <8 x i64> %5015
  store <8 x i64> %5016, ptr %.spill269, align 64
  %.spill.load894 = load <8 x i64>, ptr %.spill, align 64
  %5017 = icmp eq <8 x i64> %.spill.load894, %5014
  %5018 = and <8 x i1> %119, %5017
  %5019 = xor <8 x i1> %5017, splat (i1 true)
  %5020 = and <8 x i1> %119, %5019
  %5021 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5018)
  %5022 = bitcast <8 x i1> %5018 to i8
  %5023 = call i8 @llvm.cttz.i8(i8 %5022, i1 false)
  %5024 = zext i8 %5023 to i32
  %5025 = select i1 %5021, i32 %5024, i32 0
  %tile_snapshot.spill.load895 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill219, align 64
  %5026 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load895, 0
  %5027 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load895, 1
  %5028 = mul <8 x i64> %5011, splat (i64 32)
  %5029 = add <8 x i64> %5027, %5028
  %5030 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5026, 0
  %5031 = insertvalue { <8 x ptr>, <8 x i64> } %5030, <8 x i64> %5029, 1
  %5032 = extractvalue { <8 x ptr>, <8 x i64> } %53, 0
  %5033 = extractvalue { <8 x ptr>, <8 x i64> } %5031, 1
  %5034 = extractelement <8 x ptr> %5032, i32 0
  %5035 = extractelement <8 x i64> %5033, i32 %5025
  %5036 = zext i32 %5025 to i64
  %5037 = mul i64 %5036, 4
  %5038 = sub i64 %5035, %5037
  %5039 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5018)
  %5040 = select i1 %5039, i64 %5038, i64 0
  %private.contiguous.address896 = getelementptr i8, ptr %5034, i64 %5040
  %private.contiguous.load897 = load <8 x float>, ptr %private.contiguous.address896, align 4
  %5041 = select <8 x i1> %5018, <8 x float> %private.contiguous.load897, <8 x float> zeroinitializer
  %5042 = load <8 x float>, ptr %.slot270, align 32
  %5043 = select <8 x i1> %5018, <8 x float> %5041, <8 x float> %5042
  store <8 x float> %5043, ptr %.slot270, align 32
  %5044 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5020)
  %5045 = bitcast <8 x i1> %5020 to i8
  %5046 = call i8 @llvm.cttz.i8(i8 %5045, i1 false)
  %5047 = zext i8 %5046 to i32
  %5048 = select i1 %5044, i32 %5047, i32 0
  %5049 = load <8 x float>, ptr %.slot270, align 32
  %5050 = select <8 x i1> %5020, <8 x float> zeroinitializer, <8 x float> %5049
  store <8 x float> %5050, ptr %.slot270, align 32
  br label %direct.schedule.231

direct.schedule.231:                              ; preds = %direct.schedule.229
  %.spill.load898 = load <8 x i64>, ptr %.spill269, align 64
  %5051 = trunc <8 x i64> %.spill.load898 to <8 x i32>
  %.state899 = load <8 x float>, ptr %.slot270, align 32
  %5052 = extractelement <8 x i32> %5051, i64 0
  %5053 = icmp ult i32 %5052, 8
  %5054 = select i1 %5053, i32 %5052, i32 0
  %5055 = extractelement <8 x i1> %119, i32 %5054
  %5056 = extractelement <8 x i1> %119, i64 0
  %5057 = and i1 %5053, %5055
  %5058 = and i1 %5056, %5057
  %5059 = extractelement <8 x float> %.state899, i32 %5054
  %5060 = select i1 %5058, float %5059, float 0.000000e+00
  %5061 = insertelement <8 x float> poison, float %5060, i64 0
  %5062 = xor i1 %5058, true
  %5063 = and i1 %5056, %5062
  %5064 = insertelement <8 x i1> poison, i1 %5063, i64 0
  %5065 = extractelement <8 x i32> %5051, i64 1
  %5066 = icmp ult i32 %5065, 8
  %5067 = select i1 %5066, i32 %5065, i32 0
  %5068 = extractelement <8 x i1> %119, i32 %5067
  %5069 = extractelement <8 x i1> %119, i64 1
  %5070 = and i1 %5066, %5068
  %5071 = and i1 %5069, %5070
  %5072 = extractelement <8 x float> %.state899, i32 %5067
  %5073 = select i1 %5071, float %5072, float 0.000000e+00
  %5074 = insertelement <8 x float> %5061, float %5073, i64 1
  %5075 = xor i1 %5071, true
  %5076 = and i1 %5069, %5075
  %5077 = insertelement <8 x i1> %5064, i1 %5076, i64 1
  %5078 = extractelement <8 x i32> %5051, i64 2
  %5079 = icmp ult i32 %5078, 8
  %5080 = select i1 %5079, i32 %5078, i32 0
  %5081 = extractelement <8 x i1> %119, i32 %5080
  %5082 = extractelement <8 x i1> %119, i64 2
  %5083 = and i1 %5079, %5081
  %5084 = and i1 %5082, %5083
  %5085 = extractelement <8 x float> %.state899, i32 %5080
  %5086 = select i1 %5084, float %5085, float 0.000000e+00
  %5087 = insertelement <8 x float> %5074, float %5086, i64 2
  %5088 = xor i1 %5084, true
  %5089 = and i1 %5082, %5088
  %5090 = insertelement <8 x i1> %5077, i1 %5089, i64 2
  %5091 = extractelement <8 x i32> %5051, i64 3
  %5092 = icmp ult i32 %5091, 8
  %5093 = select i1 %5092, i32 %5091, i32 0
  %5094 = extractelement <8 x i1> %119, i32 %5093
  %5095 = extractelement <8 x i1> %119, i64 3
  %5096 = and i1 %5092, %5094
  %5097 = and i1 %5095, %5096
  %5098 = extractelement <8 x float> %.state899, i32 %5093
  %5099 = select i1 %5097, float %5098, float 0.000000e+00
  %5100 = insertelement <8 x float> %5087, float %5099, i64 3
  %5101 = xor i1 %5097, true
  %5102 = and i1 %5095, %5101
  %5103 = insertelement <8 x i1> %5090, i1 %5102, i64 3
  %5104 = extractelement <8 x i32> %5051, i64 4
  %5105 = icmp ult i32 %5104, 8
  %5106 = select i1 %5105, i32 %5104, i32 0
  %5107 = extractelement <8 x i1> %119, i32 %5106
  %5108 = extractelement <8 x i1> %119, i64 4
  %5109 = and i1 %5105, %5107
  %5110 = and i1 %5108, %5109
  %5111 = extractelement <8 x float> %.state899, i32 %5106
  %5112 = select i1 %5110, float %5111, float 0.000000e+00
  %5113 = insertelement <8 x float> %5100, float %5112, i64 4
  %5114 = xor i1 %5110, true
  %5115 = and i1 %5108, %5114
  %5116 = insertelement <8 x i1> %5103, i1 %5115, i64 4
  %5117 = extractelement <8 x i32> %5051, i64 5
  %5118 = icmp ult i32 %5117, 8
  %5119 = select i1 %5118, i32 %5117, i32 0
  %5120 = extractelement <8 x i1> %119, i32 %5119
  %5121 = extractelement <8 x i1> %119, i64 5
  %5122 = and i1 %5118, %5120
  %5123 = and i1 %5121, %5122
  %5124 = extractelement <8 x float> %.state899, i32 %5119
  %5125 = select i1 %5123, float %5124, float 0.000000e+00
  %5126 = insertelement <8 x float> %5113, float %5125, i64 5
  %5127 = xor i1 %5123, true
  %5128 = and i1 %5121, %5127
  %5129 = insertelement <8 x i1> %5116, i1 %5128, i64 5
  %5130 = extractelement <8 x i32> %5051, i64 6
  %5131 = icmp ult i32 %5130, 8
  %5132 = select i1 %5131, i32 %5130, i32 0
  %5133 = extractelement <8 x i1> %119, i32 %5132
  %5134 = extractelement <8 x i1> %119, i64 6
  %5135 = and i1 %5131, %5133
  %5136 = and i1 %5134, %5135
  %5137 = extractelement <8 x float> %.state899, i32 %5132
  %5138 = select i1 %5136, float %5137, float 0.000000e+00
  %5139 = insertelement <8 x float> %5126, float %5138, i64 6
  %5140 = xor i1 %5136, true
  %5141 = and i1 %5134, %5140
  %5142 = insertelement <8 x i1> %5129, i1 %5141, i64 6
  %5143 = extractelement <8 x i32> %5051, i64 7
  %5144 = icmp ult i32 %5143, 8
  %5145 = select i1 %5144, i32 %5143, i32 0
  %5146 = extractelement <8 x i1> %119, i32 %5145
  %5147 = extractelement <8 x i1> %119, i64 7
  %5148 = and i1 %5144, %5146
  %5149 = and i1 %5147, %5148
  %5150 = extractelement <8 x float> %.state899, i32 %5145
  %5151 = select i1 %5149, float %5150, float 0.000000e+00
  %5152 = insertelement <8 x float> %5139, float %5151, i64 7
  %5153 = xor i1 %5149, true
  %5154 = and i1 %5147, %5153
  %5155 = insertelement <8 x i1> %5142, i1 %5154, i64 7
  %.state900 = load <8 x float>, ptr %.slot268, align 32
  %5156 = fmul <8 x float> %.state900, %5152
  %.spill.load901 = load <8 x i1>, ptr %.spill265, align 1
  %5157 = and <8 x i1> %119, %.spill.load901
  %5158 = xor <8 x i1> %.spill.load901, splat (i1 true)
  %5159 = and <8 x i1> %119, %5158
  %5160 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5157)
  %5161 = bitcast <8 x i1> %5157 to i8
  %5162 = call i8 @llvm.cttz.i8(i8 %5161, i1 false)
  %5163 = zext i8 %5162 to i32
  %5164 = select i1 %5160, i32 %5163, i32 0
  %tile_snapshot.spill.load902 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %5165 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load902, 0
  %5166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load902, 1
  %.state903 = load <8 x i64>, ptr %.slot264, align 64
  %5167 = mul <8 x i64> %.state903, splat (i64 32)
  %5168 = add <8 x i64> %5166, %5167
  %5169 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5165, 0
  %5170 = insertvalue { <8 x ptr>, <8 x i64> } %5169, <8 x i64> %5168, 1
  %5171 = extractvalue { <8 x ptr>, <8 x i64> } %67, 0
  %5172 = extractvalue { <8 x ptr>, <8 x i64> } %5170, 1
  %5173 = extractelement <8 x ptr> %5171, i32 0
  %5174 = extractelement <8 x i64> %5172, i32 %5164
  %5175 = zext i32 %5164 to i64
  %5176 = mul i64 %5175, 4
  %5177 = sub i64 %5174, %5176
  %5178 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5157)
  %5179 = select i1 %5178, i64 %5177, i64 0
  %private.contiguous.address904 = getelementptr i8, ptr %5173, i64 %5179
  %private.contiguous.preserve905 = load <8 x float>, ptr %private.contiguous.address904, align 4
  %5180 = select <8 x i1> %5157, <8 x float> %5156, <8 x float> %private.contiguous.preserve905
  store <8 x float> %5180, ptr %private.contiguous.address904, align 4
  %5181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5159)
  %5182 = bitcast <8 x i1> %5159 to i8
  %5183 = call i8 @llvm.cttz.i8(i8 %5182, i1 false)
  %5184 = zext i8 %5183 to i32
  %5185 = select i1 %5181, i32 %5184, i32 0
  br label %direct.schedule.233

direct.schedule.233:                              ; preds = %direct.schedule.231
  %.state906 = load <8 x i64>, ptr %.slot264, align 64
  %5186 = add <8 x i64> %.state906, splat (i64 1)
  %5187 = load <8 x i64>, ptr %.slot264, align 64
  %5188 = select <8 x i1> %119, <8 x i64> %5186, <8 x i64> %5187
  store <8 x i64> %5188, ptr %.slot264, align 64
  br label %direct.schedule.226

direct.schedule.234:                              ; preds = %direct.false882
  %5189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %5190 = extractvalue { <8 x ptr>, <8 x i64> } %69, 0
  %5191 = extractvalue { <8 x ptr>, <8 x i64> } %5189, 0
  %5192 = select <8 x i1> %119, <8 x ptr> %5190, <8 x ptr> %5191
  %5193 = extractvalue { <8 x ptr>, <8 x i64> } %69, 1
  %5194 = extractvalue { <8 x ptr>, <8 x i64> } %5189, 1
  %5195 = select <8 x i1> %119, <8 x i64> %5193, <8 x i64> %5194
  %5196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5192, 0
  %5197 = insertvalue { <8 x ptr>, <8 x i64> } %5196, <8 x i64> %5195, 1
  store { <8 x ptr>, <8 x i64> } %5197, ptr %tile_snapshot.spill271, align 64
  %5198 = load <8 x i64>, ptr %.slot272, align 64
  %5199 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5198
  store <8 x i64> %5199, ptr %.slot272, align 64
  br label %direct.schedule.235

direct.schedule.235:                              ; preds = %direct.schedule.247, %direct.schedule.234
  %.state907 = load <8 x i64>, ptr %.slot272, align 64
  %5200 = icmp slt <8 x i64> %.state907, splat (i64 2)
  %5201 = extractelement <8 x i1> %5200, i32 0
  br i1 %5201, label %direct.true908, label %direct.false909

direct.schedule.236:                              ; preds = %direct.true908
  %.state910 = load <8 x i64>, ptr %.slot272, align 64
  %5202 = select <8 x i1> %119, <8 x i64> %.state910, <8 x i64> zeroinitializer
  %5203 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5204 = srem <8 x i64> %5202, %5203
  %5205 = load <8 x i64>, ptr %.spill273, align 64
  %5206 = select <8 x i1> %119, <8 x i64> %5204, <8 x i64> %5205
  store <8 x i64> %5206, ptr %.spill273, align 64
  %.state911 = load <8 x i64>, ptr %.slot272, align 64
  %5207 = select <8 x i1> %119, <8 x i64> %.state911, <8 x i64> zeroinitializer
  %5208 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5209 = sdiv <8 x i64> %5207, %5208
  %5210 = mul <8 x i64> %5204, splat (i64 8)
  %.spill.load912 = load <8 x i64>, ptr %.spill, align 64
  %5211 = add <8 x i64> %5210, %.spill.load912
  %5212 = icmp slt <8 x i64> %5211, splat (i64 3)
  %5213 = load <8 x i1>, ptr %.spill274, align 1
  %5214 = select <8 x i1> %119, <8 x i1> %5212, <8 x i1> %5213
  store <8 x i1> %5214, ptr %.spill274, align 1
  %5215 = select <8 x i1> %119, <8 x i64> %5209, <8 x i64> zeroinitializer
  %5216 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %5217 = srem <8 x i64> %5215, %5216
  %5218 = load <8 x i64>, ptr %.spill275, align 64
  %5219 = select <8 x i1> %119, <8 x i64> %5217, <8 x i64> %5218
  store <8 x i64> %5219, ptr %.spill275, align 64
  store i64 0, ptr %.spill276, align 4
  %5220 = and <8 x i1> %119, %5212
  %5221 = xor <8 x i1> %5212, splat (i1 true)
  %5222 = and <8 x i1> %119, %5221
  %5223 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5220)
  %5224 = bitcast <8 x i1> %5220 to i8
  %5225 = call i8 @llvm.cttz.i8(i8 %5224, i1 false)
  %5226 = zext i8 %5225 to i32
  %5227 = select i1 %5223, i32 %5226, i32 0
  %tile_snapshot.spill.load913 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill263, align 64
  %5228 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load913, 0
  %5229 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load913, 1
  %.state914 = load <8 x i64>, ptr %.slot272, align 64
  %5230 = mul <8 x i64> %.state914, splat (i64 32)
  %5231 = add <8 x i64> %5229, %5230
  %5232 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5228, 0
  %5233 = insertvalue { <8 x ptr>, <8 x i64> } %5232, <8 x i64> %5231, 1
  %5234 = extractvalue { <8 x ptr>, <8 x i64> } %67, 0
  %5235 = extractvalue { <8 x ptr>, <8 x i64> } %5233, 1
  %5236 = extractelement <8 x ptr> %5234, i32 0
  %5237 = extractelement <8 x i64> %5235, i32 %5227
  %5238 = zext i32 %5227 to i64
  %5239 = mul i64 %5238, 4
  %5240 = sub i64 %5237, %5239
  %5241 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5220)
  %5242 = select i1 %5241, i64 %5240, i64 0
  %private.contiguous.address915 = getelementptr i8, ptr %5236, i64 %5242
  %private.contiguous.load916 = load <8 x float>, ptr %private.contiguous.address915, align 4
  %5243 = select <8 x i1> %5220, <8 x float> %private.contiguous.load916, <8 x float> zeroinitializer
  %5244 = load <8 x float>, ptr %.slot277, align 32
  %5245 = select <8 x i1> %5220, <8 x float> %5243, <8 x float> %5244
  store <8 x float> %5245, ptr %.slot277, align 32
  %5246 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5222)
  %5247 = bitcast <8 x i1> %5222 to i8
  %5248 = call i8 @llvm.cttz.i8(i8 %5247, i1 false)
  %5249 = zext i8 %5248 to i32
  %5250 = select i1 %5246, i32 %5249, i32 0
  %5251 = load <8 x float>, ptr %.slot277, align 32
  %5252 = select <8 x i1> %5222, <8 x float> zeroinitializer, <8 x float> %5251
  store <8 x float> %5252, ptr %.slot277, align 32
  br label %direct.schedule.238

direct.schedule.238:                              ; preds = %direct.schedule.236
  %.state917 = load <8 x float>, ptr %.slot277, align 32
  %5253 = load <8 x i64>, ptr %.slot278, align 64
  %5254 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5253
  store <8 x i64> %5254, ptr %.slot278, align 64
  %5255 = load <8 x float>, ptr %.slot279, align 32
  %5256 = select <8 x i1> %119, <8 x float> %.state917, <8 x float> %5255
  store <8 x float> %5256, ptr %.slot279, align 32
  br label %direct.schedule.239

direct.schedule.239:                              ; preds = %direct.schedule.244, %direct.schedule.238
  %.state918 = load <8 x i64>, ptr %.slot278, align 64
  %5257 = icmp slt <8 x i64> %.state918, splat (i64 33)
  %5258 = extractelement <8 x i1> %5257, i32 0
  br i1 %5258, label %direct.true919, label %direct.false920

direct.schedule.240:                              ; preds = %direct.true919
  %.spill.load921 = load i64, ptr %.spill276, align 4
  %5259 = add i64 %.spill.load921, 0
  %5260 = mul i64 %5259, 1
  %5261 = add i64 %5260, 0
  store i64 %5261, ptr %.spill280, align 4
  %5262 = mul i64 %5261, 2
  %.splatinsert922 = insertelement <8 x i64> poison, i64 %5262, i64 0
  %.splat923 = shufflevector <8 x i64> %.splatinsert922, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load924 = load <8 x i64>, ptr %.spill275, align 64
  %5263 = add <8 x i64> %.splat923, %.spill.load924
  %.state925 = load <8 x i64>, ptr %.slot278, align 64
  %5264 = select <8 x i1> %119, <8 x i64> %.state925, <8 x i64> zeroinitializer
  %5265 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %5266 = sdiv <8 x i64> %5264, %5265
  %5267 = mul <8 x i64> %5263, splat (i64 5)
  %5268 = add <8 x i64> %5267, %5266
  %.state926 = load <8 x i64>, ptr %.slot278, align 64
  %5269 = select <8 x i1> %119, <8 x i64> %.state926, <8 x i64> zeroinitializer
  %5270 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %5271 = srem <8 x i64> %5269, %5270
  %5272 = load <8 x i64>, ptr %.spill281, align 64
  %5273 = select <8 x i1> %119, <8 x i64> %5271, <8 x i64> %5272
  store <8 x i64> %5273, ptr %.spill281, align 64
  %.spill.load927 = load <8 x i64>, ptr %.spill, align 64
  %5274 = icmp eq <8 x i64> %.spill.load927, %5271
  %5275 = and <8 x i1> %119, %5274
  %5276 = xor <8 x i1> %5274, splat (i1 true)
  %5277 = and <8 x i1> %119, %5276
  %5278 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5275)
  %5279 = bitcast <8 x i1> %5275 to i8
  %5280 = call i8 @llvm.cttz.i8(i8 %5279, i1 false)
  %5281 = zext i8 %5280 to i32
  %5282 = select i1 %5278, i32 %5281, i32 0
  %tile_snapshot.spill.load928 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill235, align 64
  %5283 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 0
  %5284 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load928, 1
  %5285 = mul <8 x i64> %5268, splat (i64 32)
  %5286 = add <8 x i64> %5284, %5285
  %5287 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5283, 0
  %5288 = insertvalue { <8 x ptr>, <8 x i64> } %5287, <8 x i64> %5286, 1
  %5289 = extractvalue { <8 x ptr>, <8 x i64> } %59, 0
  %5290 = extractvalue { <8 x ptr>, <8 x i64> } %5288, 1
  %5291 = extractelement <8 x ptr> %5289, i32 0
  %5292 = extractelement <8 x i64> %5290, i32 %5282
  %5293 = zext i32 %5282 to i64
  %5294 = mul i64 %5293, 4
  %5295 = sub i64 %5292, %5294
  %5296 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5275)
  %5297 = select i1 %5296, i64 %5295, i64 0
  %private.contiguous.address929 = getelementptr i8, ptr %5291, i64 %5297
  %private.contiguous.load930 = load <8 x float>, ptr %private.contiguous.address929, align 4
  %5298 = select <8 x i1> %5275, <8 x float> %private.contiguous.load930, <8 x float> zeroinitializer
  %5299 = load <8 x float>, ptr %.slot282, align 32
  %5300 = select <8 x i1> %5275, <8 x float> %5298, <8 x float> %5299
  store <8 x float> %5300, ptr %.slot282, align 32
  %5301 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5277)
  %5302 = bitcast <8 x i1> %5277 to i8
  %5303 = call i8 @llvm.cttz.i8(i8 %5302, i1 false)
  %5304 = zext i8 %5303 to i32
  %5305 = select i1 %5301, i32 %5304, i32 0
  %5306 = load <8 x float>, ptr %.slot282, align 32
  %5307 = select <8 x i1> %5277, <8 x float> zeroinitializer, <8 x float> %5306
  store <8 x float> %5307, ptr %.slot282, align 32
  br label %direct.schedule.242

direct.schedule.242:                              ; preds = %direct.schedule.240
  %.spill.load931 = load <8 x i64>, ptr %.spill281, align 64
  %5308 = trunc <8 x i64> %.spill.load931 to <8 x i32>
  %.state932 = load <8 x float>, ptr %.slot282, align 32
  %5309 = extractelement <8 x i32> %5308, i64 0
  %5310 = icmp ult i32 %5309, 8
  %5311 = select i1 %5310, i32 %5309, i32 0
  %5312 = extractelement <8 x i1> %119, i32 %5311
  %5313 = extractelement <8 x i1> %119, i64 0
  %5314 = and i1 %5310, %5312
  %5315 = and i1 %5313, %5314
  %5316 = extractelement <8 x float> %.state932, i32 %5311
  %5317 = select i1 %5315, float %5316, float 0.000000e+00
  %5318 = insertelement <8 x float> poison, float %5317, i64 0
  %5319 = xor i1 %5315, true
  %5320 = and i1 %5313, %5319
  %5321 = insertelement <8 x i1> poison, i1 %5320, i64 0
  %5322 = extractelement <8 x i32> %5308, i64 1
  %5323 = icmp ult i32 %5322, 8
  %5324 = select i1 %5323, i32 %5322, i32 0
  %5325 = extractelement <8 x i1> %119, i32 %5324
  %5326 = extractelement <8 x i1> %119, i64 1
  %5327 = and i1 %5323, %5325
  %5328 = and i1 %5326, %5327
  %5329 = extractelement <8 x float> %.state932, i32 %5324
  %5330 = select i1 %5328, float %5329, float 0.000000e+00
  %5331 = insertelement <8 x float> %5318, float %5330, i64 1
  %5332 = xor i1 %5328, true
  %5333 = and i1 %5326, %5332
  %5334 = insertelement <8 x i1> %5321, i1 %5333, i64 1
  %5335 = extractelement <8 x i32> %5308, i64 2
  %5336 = icmp ult i32 %5335, 8
  %5337 = select i1 %5336, i32 %5335, i32 0
  %5338 = extractelement <8 x i1> %119, i32 %5337
  %5339 = extractelement <8 x i1> %119, i64 2
  %5340 = and i1 %5336, %5338
  %5341 = and i1 %5339, %5340
  %5342 = extractelement <8 x float> %.state932, i32 %5337
  %5343 = select i1 %5341, float %5342, float 0.000000e+00
  %5344 = insertelement <8 x float> %5331, float %5343, i64 2
  %5345 = xor i1 %5341, true
  %5346 = and i1 %5339, %5345
  %5347 = insertelement <8 x i1> %5334, i1 %5346, i64 2
  %5348 = extractelement <8 x i32> %5308, i64 3
  %5349 = icmp ult i32 %5348, 8
  %5350 = select i1 %5349, i32 %5348, i32 0
  %5351 = extractelement <8 x i1> %119, i32 %5350
  %5352 = extractelement <8 x i1> %119, i64 3
  %5353 = and i1 %5349, %5351
  %5354 = and i1 %5352, %5353
  %5355 = extractelement <8 x float> %.state932, i32 %5350
  %5356 = select i1 %5354, float %5355, float 0.000000e+00
  %5357 = insertelement <8 x float> %5344, float %5356, i64 3
  %5358 = xor i1 %5354, true
  %5359 = and i1 %5352, %5358
  %5360 = insertelement <8 x i1> %5347, i1 %5359, i64 3
  %5361 = extractelement <8 x i32> %5308, i64 4
  %5362 = icmp ult i32 %5361, 8
  %5363 = select i1 %5362, i32 %5361, i32 0
  %5364 = extractelement <8 x i1> %119, i32 %5363
  %5365 = extractelement <8 x i1> %119, i64 4
  %5366 = and i1 %5362, %5364
  %5367 = and i1 %5365, %5366
  %5368 = extractelement <8 x float> %.state932, i32 %5363
  %5369 = select i1 %5367, float %5368, float 0.000000e+00
  %5370 = insertelement <8 x float> %5357, float %5369, i64 4
  %5371 = xor i1 %5367, true
  %5372 = and i1 %5365, %5371
  %5373 = insertelement <8 x i1> %5360, i1 %5372, i64 4
  %5374 = extractelement <8 x i32> %5308, i64 5
  %5375 = icmp ult i32 %5374, 8
  %5376 = select i1 %5375, i32 %5374, i32 0
  %5377 = extractelement <8 x i1> %119, i32 %5376
  %5378 = extractelement <8 x i1> %119, i64 5
  %5379 = and i1 %5375, %5377
  %5380 = and i1 %5378, %5379
  %5381 = extractelement <8 x float> %.state932, i32 %5376
  %5382 = select i1 %5380, float %5381, float 0.000000e+00
  %5383 = insertelement <8 x float> %5370, float %5382, i64 5
  %5384 = xor i1 %5380, true
  %5385 = and i1 %5378, %5384
  %5386 = insertelement <8 x i1> %5373, i1 %5385, i64 5
  %5387 = extractelement <8 x i32> %5308, i64 6
  %5388 = icmp ult i32 %5387, 8
  %5389 = select i1 %5388, i32 %5387, i32 0
  %5390 = extractelement <8 x i1> %119, i32 %5389
  %5391 = extractelement <8 x i1> %119, i64 6
  %5392 = and i1 %5388, %5390
  %5393 = and i1 %5391, %5392
  %5394 = extractelement <8 x float> %.state932, i32 %5389
  %5395 = select i1 %5393, float %5394, float 0.000000e+00
  %5396 = insertelement <8 x float> %5383, float %5395, i64 6
  %5397 = xor i1 %5393, true
  %5398 = and i1 %5391, %5397
  %5399 = insertelement <8 x i1> %5386, i1 %5398, i64 6
  %5400 = extractelement <8 x i32> %5308, i64 7
  %5401 = icmp ult i32 %5400, 8
  %5402 = select i1 %5401, i32 %5400, i32 0
  %5403 = extractelement <8 x i1> %119, i32 %5402
  %5404 = extractelement <8 x i1> %119, i64 7
  %5405 = and i1 %5401, %5403
  %5406 = and i1 %5404, %5405
  %5407 = extractelement <8 x float> %.state932, i32 %5402
  %5408 = select i1 %5406, float %5407, float 0.000000e+00
  %5409 = insertelement <8 x float> %5396, float %5408, i64 7
  %5410 = xor i1 %5406, true
  %5411 = and i1 %5404, %5410
  %5412 = insertelement <8 x i1> %5399, i1 %5411, i64 7
  %5413 = load <8 x float>, ptr %.spill283, align 32
  %5414 = select <8 x i1> %119, <8 x float> %5409, <8 x float> %5413
  store <8 x float> %5414, ptr %.spill283, align 32
  %.spill.load933 = load i64, ptr %.spill280, align 4
  %5415 = mul i64 %.spill.load933, 33
  %.splatinsert934 = insertelement <8 x i64> poison, i64 %5415, i64 0
  %.splat935 = shufflevector <8 x i64> %.splatinsert934, <8 x i64> poison, <8 x i32> zeroinitializer
  %.state936 = load <8 x i64>, ptr %.slot278, align 64
  %5416 = add <8 x i64> %.splat935, %.state936
  %5417 = mul <8 x i64> %5416, splat (i64 1)
  %.spill.load937 = load <8 x i64>, ptr %.spill273, align 64
  %5418 = add <8 x i64> %5417, %.spill.load937
  %.spill.load938 = load <8 x i1>, ptr %.spill274, align 1
  %5419 = and <8 x i1> %119, %.spill.load938
  %5420 = xor <8 x i1> %.spill.load938, splat (i1 true)
  %5421 = and <8 x i1> %119, %5420
  %5422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5419)
  %5423 = bitcast <8 x i1> %5419 to i8
  %5424 = call i8 @llvm.cttz.i8(i8 %5423, i1 false)
  %5425 = zext i8 %5424 to i32
  %5426 = select i1 %5422, i32 %5425, i32 0
  %tile_snapshot.spill.load939 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill126, align 64
  %5427 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load939, 0
  %5428 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load939, 1
  %5429 = mul <8 x i64> %5418, splat (i64 32)
  %5430 = add <8 x i64> %5428, %5429
  %5431 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5427, 0
  %5432 = insertvalue { <8 x ptr>, <8 x i64> } %5431, <8 x i64> %5430, 1
  %5433 = extractvalue { <8 x ptr>, <8 x i64> } %17, 0
  %5434 = extractvalue { <8 x ptr>, <8 x i64> } %5432, 1
  %5435 = extractelement <8 x ptr> %5433, i32 0
  %5436 = extractelement <8 x i64> %5434, i32 %5426
  %5437 = zext i32 %5426 to i64
  %5438 = mul i64 %5437, 4
  %5439 = sub i64 %5436, %5438
  %5440 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5419)
  %5441 = select i1 %5440, i64 %5439, i64 0
  %private.contiguous.address940 = getelementptr i8, ptr %5435, i64 %5441
  %private.contiguous.load941 = load <8 x float>, ptr %private.contiguous.address940, align 4
  %5442 = select <8 x i1> %5419, <8 x float> %private.contiguous.load941, <8 x float> zeroinitializer
  %5443 = load <8 x float>, ptr %.slot284, align 32
  %5444 = select <8 x i1> %5419, <8 x float> %5442, <8 x float> %5443
  store <8 x float> %5444, ptr %.slot284, align 32
  %5445 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5421)
  %5446 = bitcast <8 x i1> %5421 to i8
  %5447 = call i8 @llvm.cttz.i8(i8 %5446, i1 false)
  %5448 = zext i8 %5447 to i32
  %5449 = select i1 %5445, i32 %5448, i32 0
  %5450 = load <8 x float>, ptr %.slot284, align 32
  %5451 = select <8 x i1> %5421, <8 x float> zeroinitializer, <8 x float> %5450
  store <8 x float> %5451, ptr %.slot284, align 32
  br label %direct.schedule.244

direct.schedule.244:                              ; preds = %direct.schedule.242
  %.spill.load942 = load <8 x float>, ptr %.spill283, align 32
  %.state943 = load <8 x float>, ptr %.slot284, align 32
  %5452 = fmul <8 x float> %.spill.load942, %.state943
  %.state944 = load <8 x float>, ptr %.slot279, align 32
  %5453 = fadd <8 x float> %.state944, %5452
  %.state945 = load <8 x i64>, ptr %.slot278, align 64
  %5454 = add <8 x i64> %.state945, splat (i64 1)
  %5455 = load <8 x i64>, ptr %.slot278, align 64
  %5456 = select <8 x i1> %119, <8 x i64> %5454, <8 x i64> %5455
  store <8 x i64> %5456, ptr %.slot278, align 64
  %5457 = load <8 x float>, ptr %.slot279, align 32
  %5458 = select <8 x i1> %119, <8 x float> %5453, <8 x float> %5457
  store <8 x float> %5458, ptr %.slot279, align 32
  br label %direct.schedule.239

direct.schedule.245:                              ; preds = %direct.false920
  %.spill.load946 = load <8 x i1>, ptr %.spill274, align 1
  %5459 = and <8 x i1> %119, %.spill.load946
  %5460 = xor <8 x i1> %.spill.load946, splat (i1 true)
  %5461 = and <8 x i1> %119, %5460
  %5462 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5459)
  %5463 = bitcast <8 x i1> %5459 to i8
  %5464 = call i8 @llvm.cttz.i8(i8 %5463, i1 false)
  %5465 = zext i8 %5464 to i32
  %5466 = select i1 %5462, i32 %5465, i32 0
  %tile_snapshot.spill.load947 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %5467 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load947, 0
  %5468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load947, 1
  %.state948 = load <8 x i64>, ptr %.slot272, align 64
  %5469 = mul <8 x i64> %.state948, splat (i64 32)
  %5470 = add <8 x i64> %5468, %5469
  %5471 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5467, 0
  %5472 = insertvalue { <8 x ptr>, <8 x i64> } %5471, <8 x i64> %5470, 1
  %.state949 = load <8 x float>, ptr %.slot279, align 32
  %5473 = extractvalue { <8 x ptr>, <8 x i64> } %69, 0
  %5474 = extractvalue { <8 x ptr>, <8 x i64> } %5472, 1
  %5475 = extractelement <8 x ptr> %5473, i32 0
  %5476 = extractelement <8 x i64> %5474, i32 %5466
  %5477 = zext i32 %5466 to i64
  %5478 = mul i64 %5477, 4
  %5479 = sub i64 %5476, %5478
  %5480 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5459)
  %5481 = select i1 %5480, i64 %5479, i64 0
  %private.contiguous.address950 = getelementptr i8, ptr %5475, i64 %5481
  %private.contiguous.preserve951 = load <8 x float>, ptr %private.contiguous.address950, align 4
  %5482 = select <8 x i1> %5459, <8 x float> %.state949, <8 x float> %private.contiguous.preserve951
  store <8 x float> %5482, ptr %private.contiguous.address950, align 4
  %5483 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5461)
  %5484 = bitcast <8 x i1> %5461 to i8
  %5485 = call i8 @llvm.cttz.i8(i8 %5484, i1 false)
  %5486 = zext i8 %5485 to i32
  %5487 = select i1 %5483, i32 %5486, i32 0
  br label %direct.schedule.247

direct.schedule.247:                              ; preds = %direct.schedule.245
  %.state952 = load <8 x i64>, ptr %.slot272, align 64
  %5488 = add <8 x i64> %.state952, splat (i64 1)
  %5489 = load <8 x i64>, ptr %.slot272, align 64
  %5490 = select <8 x i1> %119, <8 x i64> %5488, <8 x i64> %5489
  store <8 x i64> %5490, ptr %.slot272, align 64
  br label %direct.schedule.235

direct.schedule.248:                              ; preds = %direct.false909
  %5491 = load <8 x i64>, ptr %.slot285, align 64
  %5492 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5491
  store <8 x i64> %5492, ptr %.slot285, align 64
  br label %direct.schedule.249

direct.schedule.249:                              ; preds = %direct.schedule.254, %direct.schedule.248
  %.state953 = load <8 x i64>, ptr %.slot285, align 64
  %5493 = icmp slt <8 x i64> %.state953, splat (i64 1)
  %5494 = extractelement <8 x i1> %5493, i32 0
  br i1 %5494, label %direct.true954, label %direct.false955

direct.schedule.250:                              ; preds = %direct.true954
  %.state956 = load <8 x i64>, ptr %.slot285, align 64
  %5495 = select <8 x i1> %119, <8 x i64> %.state956, <8 x i64> zeroinitializer
  %5496 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5497 = srem <8 x i64> %5495, %5496
  %5498 = mul <8 x i64> %5497, splat (i64 8)
  %.spill.load957 = load <8 x i64>, ptr %.spill, align 64
  %5499 = add <8 x i64> %5498, %.spill.load957
  %5500 = icmp slt <8 x i64> %5499, splat (i64 2)
  %5501 = load <8 x i1>, ptr %.spill286, align 1
  %5502 = select <8 x i1> %119, <8 x i1> %5500, <8 x i1> %5501
  store <8 x i1> %5502, ptr %.spill286, align 1
  %5503 = and <8 x i1> %119, %5500
  %5504 = xor <8 x i1> %5500, splat (i1 true)
  %5505 = and <8 x i1> %119, %5504
  %5506 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5503)
  %5507 = bitcast <8 x i1> %5503 to i8
  %5508 = call i8 @llvm.cttz.i8(i8 %5507, i1 false)
  %5509 = zext i8 %5508 to i32
  %5510 = select i1 %5506, i32 %5509, i32 0
  %tile_snapshot.spill.load958 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill207, align 64
  %5511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load958, 0
  %5512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load958, 1
  %.state959 = load <8 x i64>, ptr %.slot285, align 64
  %5513 = mul <8 x i64> %.state959, splat (i64 32)
  %5514 = add <8 x i64> %5512, %5513
  %5515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5511, 0
  %5516 = insertvalue { <8 x ptr>, <8 x i64> } %5515, <8 x i64> %5514, 1
  %5517 = extractvalue { <8 x ptr>, <8 x i64> } %49, 0
  %5518 = extractvalue { <8 x ptr>, <8 x i64> } %5516, 1
  %5519 = extractelement <8 x ptr> %5517, i32 0
  %5520 = extractelement <8 x i64> %5518, i32 %5510
  %5521 = zext i32 %5510 to i64
  %5522 = mul i64 %5521, 4
  %5523 = sub i64 %5520, %5522
  %5524 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5503)
  %5525 = select i1 %5524, i64 %5523, i64 0
  %private.contiguous.address960 = getelementptr i8, ptr %5519, i64 %5525
  %private.contiguous.load961 = load <8 x float>, ptr %private.contiguous.address960, align 4
  %5526 = select <8 x i1> %5503, <8 x float> %private.contiguous.load961, <8 x float> zeroinitializer
  %5527 = load <8 x float>, ptr %.slot287, align 32
  %5528 = select <8 x i1> %5503, <8 x float> %5526, <8 x float> %5527
  store <8 x float> %5528, ptr %.slot287, align 32
  %5529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5505)
  %5530 = bitcast <8 x i1> %5505 to i8
  %5531 = call i8 @llvm.cttz.i8(i8 %5530, i1 false)
  %5532 = zext i8 %5531 to i32
  %5533 = select i1 %5529, i32 %5532, i32 0
  %5534 = load <8 x float>, ptr %.slot287, align 32
  %5535 = select <8 x i1> %5505, <8 x float> zeroinitializer, <8 x float> %5534
  store <8 x float> %5535, ptr %.slot287, align 32
  br label %direct.schedule.252

direct.schedule.252:                              ; preds = %direct.schedule.250
  %.spill.load962 = load <8 x i1>, ptr %.spill286, align 1
  %5536 = and <8 x i1> %119, %.spill.load962
  %5537 = xor <8 x i1> %.spill.load962, splat (i1 true)
  %5538 = and <8 x i1> %119, %5537
  %5539 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5536)
  %5540 = bitcast <8 x i1> %5536 to i8
  %5541 = call i8 @llvm.cttz.i8(i8 %5540, i1 false)
  %5542 = zext i8 %5541 to i32
  %5543 = select i1 %5539, i32 %5542, i32 0
  %tile_snapshot.spill.load963 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %5544 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load963, 0
  %5545 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load963, 1
  %.state964 = load <8 x i64>, ptr %.slot285, align 64
  %5546 = mul <8 x i64> %.state964, splat (i64 32)
  %5547 = add <8 x i64> %5545, %5546
  %5548 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5544, 0
  %5549 = insertvalue { <8 x ptr>, <8 x i64> } %5548, <8 x i64> %5547, 1
  %.state965 = load <8 x float>, ptr %.slot287, align 32
  %5550 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %5551 = extractvalue { <8 x ptr>, <8 x i64> } %5549, 1
  %5552 = extractelement <8 x ptr> %5550, i32 0
  %5553 = extractelement <8 x i64> %5551, i32 %5543
  %5554 = zext i32 %5543 to i64
  %5555 = mul i64 %5554, 4
  %5556 = sub i64 %5553, %5555
  %5557 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5536)
  %5558 = select i1 %5557, i64 %5556, i64 0
  %private.contiguous.address966 = getelementptr i8, ptr %5552, i64 %5558
  %private.contiguous.preserve967 = load <8 x float>, ptr %private.contiguous.address966, align 4
  %5559 = select <8 x i1> %5536, <8 x float> %.state965, <8 x float> %private.contiguous.preserve967
  store <8 x float> %5559, ptr %private.contiguous.address966, align 4
  %5560 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5538)
  %5561 = bitcast <8 x i1> %5538 to i8
  %5562 = call i8 @llvm.cttz.i8(i8 %5561, i1 false)
  %5563 = zext i8 %5562 to i32
  %5564 = select i1 %5560, i32 %5563, i32 0
  br label %direct.schedule.254

direct.schedule.254:                              ; preds = %direct.schedule.252
  %.state968 = load <8 x i64>, ptr %.slot285, align 64
  %5565 = add <8 x i64> %.state968, splat (i64 1)
  %5566 = load <8 x i64>, ptr %.slot285, align 64
  %5567 = select <8 x i1> %119, <8 x i64> %5565, <8 x i64> %5566
  store <8 x i64> %5567, ptr %.slot285, align 64
  br label %direct.schedule.249

direct.schedule.255:                              ; preds = %direct.false955
  %5568 = load <8 x i64>, ptr %.slot288, align 64
  %5569 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5568
  store <8 x i64> %5569, ptr %.slot288, align 64
  br label %direct.schedule.256

direct.schedule.256:                              ; preds = %direct.schedule.261, %direct.schedule.255
  %.state969 = load <8 x i64>, ptr %.slot288, align 64
  %5570 = icmp slt <8 x i64> %.state969, splat (i64 1)
  %5571 = extractelement <8 x i1> %5570, i32 0
  br i1 %5571, label %direct.true970, label %direct.false971

direct.schedule.257:                              ; preds = %direct.true970
  %.state972 = load <8 x i64>, ptr %.slot288, align 64
  %5572 = select <8 x i1> %119, <8 x i64> %.state972, <8 x i64> zeroinitializer
  %5573 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5574 = srem <8 x i64> %5572, %5573
  %5575 = mul <8 x i64> %5574, splat (i64 8)
  %.spill.load973 = load <8 x i64>, ptr %.spill, align 64
  %5576 = add <8 x i64> %5575, %.spill.load973
  %5577 = icmp slt <8 x i64> %5576, splat (i64 2)
  %5578 = load <8 x i1>, ptr %.spill289, align 1
  %5579 = select <8 x i1> %119, <8 x i1> %5577, <8 x i1> %5578
  store <8 x i1> %5579, ptr %.spill289, align 1
  %5580 = and <8 x i1> %119, %5577
  %5581 = xor <8 x i1> %5577, splat (i1 true)
  %5582 = and <8 x i1> %119, %5581
  %5583 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5580)
  %5584 = bitcast <8 x i1> %5580 to i8
  %5585 = call i8 @llvm.cttz.i8(i8 %5584, i1 false)
  %5586 = zext i8 %5585 to i32
  %5587 = select i1 %5583, i32 %5586, i32 0
  %tile_snapshot.spill.load974 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill257, align 64
  %5588 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load974, 0
  %5589 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load974, 1
  %.state975 = load <8 x i64>, ptr %.slot288, align 64
  %5590 = mul <8 x i64> %.state975, splat (i64 32)
  %5591 = add <8 x i64> %5589, %5590
  %5592 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5588, 0
  %5593 = insertvalue { <8 x ptr>, <8 x i64> } %5592, <8 x i64> %5591, 1
  %5594 = extractvalue { <8 x ptr>, <8 x i64> } %65, 0
  %5595 = extractvalue { <8 x ptr>, <8 x i64> } %5593, 1
  %5596 = extractelement <8 x ptr> %5594, i32 0
  %5597 = extractelement <8 x i64> %5595, i32 %5587
  %5598 = zext i32 %5587 to i64
  %5599 = mul i64 %5598, 4
  %5600 = sub i64 %5597, %5599
  %5601 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5580)
  %5602 = select i1 %5601, i64 %5600, i64 0
  %private.contiguous.address976 = getelementptr i8, ptr %5596, i64 %5602
  %private.contiguous.load977 = load <8 x float>, ptr %private.contiguous.address976, align 4
  %5603 = select <8 x i1> %5580, <8 x float> %private.contiguous.load977, <8 x float> zeroinitializer
  %5604 = load <8 x float>, ptr %.slot290, align 32
  %5605 = select <8 x i1> %5580, <8 x float> %5603, <8 x float> %5604
  store <8 x float> %5605, ptr %.slot290, align 32
  %5606 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5582)
  %5607 = bitcast <8 x i1> %5582 to i8
  %5608 = call i8 @llvm.cttz.i8(i8 %5607, i1 false)
  %5609 = zext i8 %5608 to i32
  %5610 = select i1 %5606, i32 %5609, i32 0
  %5611 = load <8 x float>, ptr %.slot290, align 32
  %5612 = select <8 x i1> %5582, <8 x float> zeroinitializer, <8 x float> %5611
  store <8 x float> %5612, ptr %.slot290, align 32
  br label %direct.schedule.259

direct.schedule.259:                              ; preds = %direct.schedule.257
  %.spill.load978 = load <8 x i1>, ptr %.spill289, align 1
  %5613 = and <8 x i1> %119, %.spill.load978
  %5614 = xor <8 x i1> %.spill.load978, splat (i1 true)
  %5615 = and <8 x i1> %119, %5614
  %5616 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5613)
  %5617 = bitcast <8 x i1> %5613 to i8
  %5618 = call i8 @llvm.cttz.i8(i8 %5617, i1 false)
  %5619 = zext i8 %5618 to i32
  %5620 = select i1 %5616, i32 %5619, i32 0
  %tile_snapshot.spill.load979 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %5621 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load979, 0
  %5622 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load979, 1
  %.state980 = load <8 x i64>, ptr %.slot288, align 64
  %5623 = mul <8 x i64> %.state980, splat (i64 32)
  %5624 = add <8 x i64> %5622, %5623
  %5625 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5621, 0
  %5626 = insertvalue { <8 x ptr>, <8 x i64> } %5625, <8 x i64> %5624, 1
  %.state981 = load <8 x float>, ptr %.slot290, align 32
  %5627 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %5628 = extractvalue { <8 x ptr>, <8 x i64> } %5626, 1
  %5629 = extractelement <8 x ptr> %5627, i32 0
  %5630 = extractelement <8 x i64> %5628, i32 %5620
  %5631 = zext i32 %5620 to i64
  %5632 = mul i64 %5631, 4
  %5633 = sub i64 %5630, %5632
  %5634 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5613)
  %5635 = select i1 %5634, i64 %5633, i64 0
  %private.contiguous.address982 = getelementptr i8, ptr %5629, i64 %5635
  %private.contiguous.preserve983 = load <8 x float>, ptr %private.contiguous.address982, align 4
  %5636 = select <8 x i1> %5613, <8 x float> %.state981, <8 x float> %private.contiguous.preserve983
  store <8 x float> %5636, ptr %private.contiguous.address982, align 4
  %5637 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5615)
  %5638 = bitcast <8 x i1> %5615 to i8
  %5639 = call i8 @llvm.cttz.i8(i8 %5638, i1 false)
  %5640 = zext i8 %5639 to i32
  %5641 = select i1 %5637, i32 %5640, i32 0
  br label %direct.schedule.261

direct.schedule.261:                              ; preds = %direct.schedule.259
  %.state984 = load <8 x i64>, ptr %.slot288, align 64
  %5642 = add <8 x i64> %.state984, splat (i64 1)
  %5643 = load <8 x i64>, ptr %.slot288, align 64
  %5644 = select <8 x i1> %119, <8 x i64> %5642, <8 x i64> %5643
  store <8 x i64> %5644, ptr %.slot288, align 64
  br label %direct.schedule.256

direct.schedule.262:                              ; preds = %direct.false971
  %5645 = load <8 x i64>, ptr %.slot291, align 64
  %5646 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5645
  store <8 x i64> %5646, ptr %.slot291, align 64
  br label %direct.schedule.263

direct.schedule.263:                              ; preds = %direct.schedule.268, %direct.schedule.262
  %.state985 = load <8 x i64>, ptr %.slot291, align 64
  %5647 = icmp slt <8 x i64> %.state985, splat (i64 2)
  %5648 = extractelement <8 x i1> %5647, i32 0
  br i1 %5648, label %direct.true986, label %direct.false987

direct.schedule.264:                              ; preds = %direct.true986
  %.state988 = load <8 x i64>, ptr %.slot291, align 64
  %5649 = select <8 x i1> %119, <8 x i64> %.state988, <8 x i64> zeroinitializer
  %5650 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5651 = srem <8 x i64> %5649, %5650
  %5652 = mul <8 x i64> %5651, splat (i64 8)
  %.spill.load989 = load <8 x i64>, ptr %.spill, align 64
  %5653 = add <8 x i64> %5652, %.spill.load989
  %5654 = icmp slt <8 x i64> %5653, splat (i64 3)
  %5655 = load <8 x i1>, ptr %.spill292, align 1
  %5656 = select <8 x i1> %119, <8 x i1> %5654, <8 x i1> %5655
  store <8 x i1> %5656, ptr %.spill292, align 1
  %5657 = and <8 x i1> %119, %5654
  %5658 = xor <8 x i1> %5654, splat (i1 true)
  %5659 = and <8 x i1> %119, %5658
  %5660 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5657)
  %5661 = bitcast <8 x i1> %5657 to i8
  %5662 = call i8 @llvm.cttz.i8(i8 %5661, i1 false)
  %5663 = zext i8 %5662 to i32
  %5664 = select i1 %5660, i32 %5663, i32 0
  %tile_snapshot.spill.load990 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill271, align 64
  %5665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load990, 0
  %5666 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load990, 1
  %.state991 = load <8 x i64>, ptr %.slot291, align 64
  %5667 = mul <8 x i64> %.state991, splat (i64 32)
  %5668 = add <8 x i64> %5666, %5667
  %5669 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5665, 0
  %5670 = insertvalue { <8 x ptr>, <8 x i64> } %5669, <8 x i64> %5668, 1
  %5671 = extractvalue { <8 x ptr>, <8 x i64> } %69, 0
  %5672 = extractvalue { <8 x ptr>, <8 x i64> } %5670, 1
  %5673 = extractelement <8 x ptr> %5671, i32 0
  %5674 = extractelement <8 x i64> %5672, i32 %5664
  %5675 = zext i32 %5664 to i64
  %5676 = mul i64 %5675, 4
  %5677 = sub i64 %5674, %5676
  %5678 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5657)
  %5679 = select i1 %5678, i64 %5677, i64 0
  %private.contiguous.address992 = getelementptr i8, ptr %5673, i64 %5679
  %private.contiguous.load993 = load <8 x float>, ptr %private.contiguous.address992, align 4
  %5680 = select <8 x i1> %5657, <8 x float> %private.contiguous.load993, <8 x float> zeroinitializer
  %5681 = load <8 x float>, ptr %.slot293, align 32
  %5682 = select <8 x i1> %5657, <8 x float> %5680, <8 x float> %5681
  store <8 x float> %5682, ptr %.slot293, align 32
  %5683 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5659)
  %5684 = bitcast <8 x i1> %5659 to i8
  %5685 = call i8 @llvm.cttz.i8(i8 %5684, i1 false)
  %5686 = zext i8 %5685 to i32
  %5687 = select i1 %5683, i32 %5686, i32 0
  %5688 = load <8 x float>, ptr %.slot293, align 32
  %5689 = select <8 x i1> %5659, <8 x float> zeroinitializer, <8 x float> %5688
  store <8 x float> %5689, ptr %.slot293, align 32
  br label %direct.schedule.266

direct.schedule.266:                              ; preds = %direct.schedule.264
  %.spill.load994 = load <8 x i1>, ptr %.spill292, align 1
  %5690 = and <8 x i1> %119, %.spill.load994
  %5691 = xor <8 x i1> %.spill.load994, splat (i1 true)
  %5692 = and <8 x i1> %119, %5691
  %5693 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5690)
  %5694 = bitcast <8 x i1> %5690 to i8
  %5695 = call i8 @llvm.cttz.i8(i8 %5694, i1 false)
  %5696 = zext i8 %5695 to i32
  %5697 = select i1 %5693, i32 %5696, i32 0
  %tile_snapshot.spill.load995 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill118, align 64
  %5698 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load995, 0
  %5699 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load995, 1
  %.state996 = load <8 x i64>, ptr %.slot291, align 64
  %5700 = mul <8 x i64> %.state996, splat (i64 32)
  %5701 = add <8 x i64> %5699, %5700
  %5702 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5698, 0
  %5703 = insertvalue { <8 x ptr>, <8 x i64> } %5702, <8 x i64> %5701, 1
  %.state997 = load <8 x float>, ptr %.slot293, align 32
  %5704 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %5705 = extractvalue { <8 x ptr>, <8 x i64> } %5703, 1
  %5706 = extractelement <8 x ptr> %5704, i32 0
  %5707 = extractelement <8 x i64> %5705, i32 %5697
  %5708 = zext i32 %5697 to i64
  %5709 = mul i64 %5708, 4
  %5710 = sub i64 %5707, %5709
  %5711 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5690)
  %5712 = select i1 %5711, i64 %5710, i64 0
  %private.contiguous.address998 = getelementptr i8, ptr %5706, i64 %5712
  %private.contiguous.preserve999 = load <8 x float>, ptr %private.contiguous.address998, align 4
  %5713 = select <8 x i1> %5690, <8 x float> %.state997, <8 x float> %private.contiguous.preserve999
  store <8 x float> %5713, ptr %private.contiguous.address998, align 4
  %5714 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5692)
  %5715 = bitcast <8 x i1> %5692 to i8
  %5716 = call i8 @llvm.cttz.i8(i8 %5715, i1 false)
  %5717 = zext i8 %5716 to i32
  %5718 = select i1 %5714, i32 %5717, i32 0
  br label %direct.schedule.268

direct.schedule.268:                              ; preds = %direct.schedule.266
  %.state1000 = load <8 x i64>, ptr %.slot291, align 64
  %5719 = add <8 x i64> %.state1000, splat (i64 1)
  %5720 = load <8 x i64>, ptr %.slot291, align 64
  %5721 = select <8 x i1> %119, <8 x i64> %5719, <8 x i64> %5720
  store <8 x i64> %5721, ptr %.slot291, align 64
  br label %direct.schedule.263

direct.schedule.269:                              ; preds = %direct.false987
  %5722 = load <8 x i64>, ptr %.slot294, align 64
  %5723 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5722
  store <8 x i64> %5723, ptr %.slot294, align 64
  br label %direct.schedule.270

direct.schedule.270:                              ; preds = %direct.schedule.275, %direct.schedule.269
  %.state1001 = load <8 x i64>, ptr %.slot294, align 64
  %5724 = icmp slt <8 x i64> %.state1001, splat (i64 1)
  %5725 = extractelement <8 x i1> %5724, i32 0
  br i1 %5725, label %direct.true1002, label %direct.false1003

direct.schedule.271:                              ; preds = %direct.true1002
  %.state1004 = load <8 x i64>, ptr %.slot294, align 64
  %5726 = select <8 x i1> %119, <8 x i64> %.state1004, <8 x i64> zeroinitializer
  %5727 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5728 = srem <8 x i64> %5726, %5727
  %5729 = mul <8 x i64> %5728, splat (i64 8)
  %.spill.load1005 = load <8 x i64>, ptr %.spill, align 64
  %5730 = add <8 x i64> %5729, %.spill.load1005
  %5731 = icmp slt <8 x i64> %5730, splat (i64 2)
  %5732 = load <8 x i1>, ptr %.spill295, align 1
  %5733 = select <8 x i1> %119, <8 x i1> %5731, <8 x i1> %5732
  store <8 x i1> %5733, ptr %.spill295, align 1
  %5734 = and <8 x i1> %119, %5731
  %5735 = xor <8 x i1> %5731, splat (i1 true)
  %5736 = and <8 x i1> %119, %5735
  %5737 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5734)
  %5738 = bitcast <8 x i1> %5734 to i8
  %5739 = call i8 @llvm.cttz.i8(i8 %5738, i1 false)
  %5740 = zext i8 %5739 to i32
  %5741 = select i1 %5737, i32 %5740, i32 0
  %tile_snapshot.spill.load1006 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill112, align 64
  %5742 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 0
  %5743 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1006, 1
  %.state1007 = load <8 x i64>, ptr %.slot294, align 64
  %5744 = mul <8 x i64> %.state1007, splat (i64 32)
  %5745 = add <8 x i64> %5743, %5744
  %5746 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5742, 0
  %5747 = insertvalue { <8 x ptr>, <8 x i64> } %5746, <8 x i64> %5745, 1
  %5748 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %5749 = extractvalue { <8 x ptr>, <8 x i64> } %5747, 1
  %5750 = extractelement <8 x ptr> %5748, i32 0
  %5751 = extractelement <8 x i64> %5749, i32 %5741
  %5752 = zext i32 %5741 to i64
  %5753 = mul i64 %5752, 4
  %5754 = sub i64 %5751, %5753
  %5755 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5734)
  %5756 = select i1 %5755, i64 %5754, i64 0
  %private.contiguous.address1008 = getelementptr i8, ptr %5750, i64 %5756
  %private.contiguous.load1009 = load <8 x float>, ptr %private.contiguous.address1008, align 4
  %5757 = select <8 x i1> %5734, <8 x float> %private.contiguous.load1009, <8 x float> zeroinitializer
  %5758 = load <8 x float>, ptr %.slot296, align 32
  %5759 = select <8 x i1> %5734, <8 x float> %5757, <8 x float> %5758
  store <8 x float> %5759, ptr %.slot296, align 32
  %5760 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5736)
  %5761 = bitcast <8 x i1> %5736 to i8
  %5762 = call i8 @llvm.cttz.i8(i8 %5761, i1 false)
  %5763 = zext i8 %5762 to i32
  %5764 = select i1 %5760, i32 %5763, i32 0
  %5765 = load <8 x float>, ptr %.slot296, align 32
  %5766 = select <8 x i1> %5736, <8 x float> zeroinitializer, <8 x float> %5765
  store <8 x float> %5766, ptr %.slot296, align 32
  br label %direct.schedule.273

direct.schedule.273:                              ; preds = %direct.schedule.271
  %.spill.load1010 = load <8 x i1>, ptr %.spill295, align 1
  %5767 = and <8 x i1> %119, %.spill.load1010
  %5768 = xor <8 x i1> %.spill.load1010, splat (i1 true)
  %5769 = and <8 x i1> %119, %5768
  %5770 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5767)
  %5771 = bitcast <8 x i1> %5767 to i8
  %5772 = call i8 @llvm.cttz.i8(i8 %5771, i1 false)
  %5773 = zext i8 %5772 to i32
  %5774 = select i1 %5770, i32 %5773, i32 0
  %tile_snapshot.spill.load1011 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill111, align 64
  %5775 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1011, 0
  %5776 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1011, 1
  %.state1012 = load <8 x i64>, ptr %.slot294, align 64
  %5777 = mul <8 x i64> %.state1012, splat (i64 32)
  %5778 = add <8 x i64> %5776, %5777
  %5779 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5775, 0
  %5780 = insertvalue { <8 x ptr>, <8 x i64> } %5779, <8 x i64> %5778, 1
  %.state1013 = load <8 x float>, ptr %.slot296, align 32
  %5781 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %5782 = extractvalue { <8 x ptr>, <8 x i64> } %5780, 1
  %5783 = extractelement <8 x ptr> %5781, i32 0
  %5784 = extractelement <8 x i64> %5782, i32 %5774
  %5785 = zext i32 %5774 to i64
  %5786 = mul i64 %5785, 4
  %5787 = sub i64 %5784, %5786
  %5788 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5767)
  %5789 = select i1 %5788, i64 %5787, i64 0
  %private.contiguous.address1014 = getelementptr i8, ptr %5783, i64 %5789
  %private.contiguous.preserve1015 = load <8 x float>, ptr %private.contiguous.address1014, align 4
  %5790 = select <8 x i1> %5767, <8 x float> %.state1013, <8 x float> %private.contiguous.preserve1015
  store <8 x float> %5790, ptr %private.contiguous.address1014, align 4
  %5791 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5769)
  %5792 = bitcast <8 x i1> %5769 to i8
  %5793 = call i8 @llvm.cttz.i8(i8 %5792, i1 false)
  %5794 = zext i8 %5793 to i32
  %5795 = select i1 %5791, i32 %5794, i32 0
  br label %direct.schedule.275

direct.schedule.275:                              ; preds = %direct.schedule.273
  %.state1016 = load <8 x i64>, ptr %.slot294, align 64
  %5796 = add <8 x i64> %.state1016, splat (i64 1)
  %5797 = load <8 x i64>, ptr %.slot294, align 64
  %5798 = select <8 x i1> %119, <8 x i64> %5796, <8 x i64> %5797
  store <8 x i64> %5798, ptr %.slot294, align 64
  br label %direct.schedule.270

direct.schedule.276:                              ; preds = %direct.false1003
  %5799 = load <8 x i64>, ptr %.slot297, align 64
  %5800 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5799
  store <8 x i64> %5800, ptr %.slot297, align 64
  br label %direct.schedule.277

direct.schedule.277:                              ; preds = %direct.schedule.282, %direct.schedule.276
  %.state1017 = load <8 x i64>, ptr %.slot297, align 64
  %5801 = icmp slt <8 x i64> %.state1017, splat (i64 1)
  %5802 = extractelement <8 x i1> %5801, i32 0
  br i1 %5802, label %direct.true1018, label %direct.false1019

direct.schedule.278:                              ; preds = %direct.true1018
  %.state1020 = load <8 x i64>, ptr %.slot297, align 64
  %5803 = select <8 x i1> %119, <8 x i64> %.state1020, <8 x i64> zeroinitializer
  %5804 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5805 = srem <8 x i64> %5803, %5804
  %5806 = mul <8 x i64> %5805, splat (i64 8)
  %.spill.load1021 = load <8 x i64>, ptr %.spill, align 64
  %5807 = add <8 x i64> %5806, %.spill.load1021
  %5808 = icmp slt <8 x i64> %5807, splat (i64 2)
  %5809 = load <8 x i1>, ptr %.spill298, align 1
  %5810 = select <8 x i1> %119, <8 x i1> %5808, <8 x i1> %5809
  store <8 x i1> %5810, ptr %.spill298, align 1
  %5811 = and <8 x i1> %119, %5808
  %5812 = xor <8 x i1> %5808, splat (i1 true)
  %5813 = and <8 x i1> %119, %5812
  %5814 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5811)
  %5815 = bitcast <8 x i1> %5811 to i8
  %5816 = call i8 @llvm.cttz.i8(i8 %5815, i1 false)
  %5817 = zext i8 %5816 to i32
  %5818 = select i1 %5814, i32 %5817, i32 0
  %tile_snapshot.spill.load1022 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill115, align 64
  %5819 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1022, 0
  %5820 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1022, 1
  %.state1023 = load <8 x i64>, ptr %.slot297, align 64
  %5821 = mul <8 x i64> %.state1023, splat (i64 32)
  %5822 = add <8 x i64> %5820, %5821
  %5823 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5819, 0
  %5824 = insertvalue { <8 x ptr>, <8 x i64> } %5823, <8 x i64> %5822, 1
  %5825 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %5826 = extractvalue { <8 x ptr>, <8 x i64> } %5824, 1
  %5827 = extractelement <8 x ptr> %5825, i32 0
  %5828 = extractelement <8 x i64> %5826, i32 %5818
  %5829 = zext i32 %5818 to i64
  %5830 = mul i64 %5829, 4
  %5831 = sub i64 %5828, %5830
  %5832 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5811)
  %5833 = select i1 %5832, i64 %5831, i64 0
  %private.contiguous.address1024 = getelementptr i8, ptr %5827, i64 %5833
  %private.contiguous.load1025 = load <8 x float>, ptr %private.contiguous.address1024, align 4
  %5834 = select <8 x i1> %5811, <8 x float> %private.contiguous.load1025, <8 x float> zeroinitializer
  %5835 = load <8 x float>, ptr %.slot299, align 32
  %5836 = select <8 x i1> %5811, <8 x float> %5834, <8 x float> %5835
  store <8 x float> %5836, ptr %.slot299, align 32
  %5837 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5813)
  %5838 = bitcast <8 x i1> %5813 to i8
  %5839 = call i8 @llvm.cttz.i8(i8 %5838, i1 false)
  %5840 = zext i8 %5839 to i32
  %5841 = select i1 %5837, i32 %5840, i32 0
  %5842 = load <8 x float>, ptr %.slot299, align 32
  %5843 = select <8 x i1> %5813, <8 x float> zeroinitializer, <8 x float> %5842
  store <8 x float> %5843, ptr %.slot299, align 32
  br label %direct.schedule.280

direct.schedule.280:                              ; preds = %direct.schedule.278
  %.spill.load1026 = load <8 x i1>, ptr %.spill298, align 1
  %5844 = and <8 x i1> %119, %.spill.load1026
  %5845 = xor <8 x i1> %.spill.load1026, splat (i1 true)
  %5846 = and <8 x i1> %119, %5845
  %5847 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5844)
  %5848 = bitcast <8 x i1> %5844 to i8
  %5849 = call i8 @llvm.cttz.i8(i8 %5848, i1 false)
  %5850 = zext i8 %5849 to i32
  %5851 = select i1 %5847, i32 %5850, i32 0
  %tile_snapshot.spill.load1027 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %5852 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1027, 0
  %5853 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1027, 1
  %.state1028 = load <8 x i64>, ptr %.slot297, align 64
  %5854 = mul <8 x i64> %.state1028, splat (i64 32)
  %5855 = add <8 x i64> %5853, %5854
  %5856 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5852, 0
  %5857 = insertvalue { <8 x ptr>, <8 x i64> } %5856, <8 x i64> %5855, 1
  %.state1029 = load <8 x float>, ptr %.slot299, align 32
  %5858 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %5859 = extractvalue { <8 x ptr>, <8 x i64> } %5857, 1
  %5860 = extractelement <8 x ptr> %5858, i32 0
  %5861 = extractelement <8 x i64> %5859, i32 %5851
  %5862 = zext i32 %5851 to i64
  %5863 = mul i64 %5862, 4
  %5864 = sub i64 %5861, %5863
  %5865 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5844)
  %5866 = select i1 %5865, i64 %5864, i64 0
  %private.contiguous.address1030 = getelementptr i8, ptr %5860, i64 %5866
  %private.contiguous.preserve1031 = load <8 x float>, ptr %private.contiguous.address1030, align 4
  %5867 = select <8 x i1> %5844, <8 x float> %.state1029, <8 x float> %private.contiguous.preserve1031
  store <8 x float> %5867, ptr %private.contiguous.address1030, align 4
  %5868 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5846)
  %5869 = bitcast <8 x i1> %5846 to i8
  %5870 = call i8 @llvm.cttz.i8(i8 %5869, i1 false)
  %5871 = zext i8 %5870 to i32
  %5872 = select i1 %5868, i32 %5871, i32 0
  br label %direct.schedule.282

direct.schedule.282:                              ; preds = %direct.schedule.280
  %.state1032 = load <8 x i64>, ptr %.slot297, align 64
  %5873 = add <8 x i64> %.state1032, splat (i64 1)
  %5874 = load <8 x i64>, ptr %.slot297, align 64
  %5875 = select <8 x i1> %119, <8 x i64> %5873, <8 x i64> %5874
  store <8 x i64> %5875, ptr %.slot297, align 64
  br label %direct.schedule.277

direct.schedule.283:                              ; preds = %direct.false1019
  %5876 = load <8 x i64>, ptr %.slot300, align 64
  %5877 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5876
  store <8 x i64> %5877, ptr %.slot300, align 64
  br label %direct.schedule.284

direct.schedule.284:                              ; preds = %direct.schedule.289, %direct.schedule.283
  %.state1033 = load <8 x i64>, ptr %.slot300, align 64
  %5878 = icmp slt <8 x i64> %.state1033, splat (i64 2)
  %5879 = extractelement <8 x i1> %5878, i32 0
  br i1 %5879, label %direct.true1034, label %direct.false1035

direct.schedule.285:                              ; preds = %direct.true1034
  %.state1036 = load <8 x i64>, ptr %.slot300, align 64
  %5880 = select <8 x i1> %119, <8 x i64> %.state1036, <8 x i64> zeroinitializer
  %5881 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5882 = srem <8 x i64> %5880, %5881
  %5883 = mul <8 x i64> %5882, splat (i64 8)
  %.spill.load1037 = load <8 x i64>, ptr %.spill, align 64
  %5884 = add <8 x i64> %5883, %.spill.load1037
  %5885 = icmp slt <8 x i64> %5884, splat (i64 3)
  %5886 = load <8 x i1>, ptr %.spill301, align 1
  %5887 = select <8 x i1> %119, <8 x i1> %5885, <8 x i1> %5886
  store <8 x i1> %5887, ptr %.spill301, align 1
  %5888 = and <8 x i1> %119, %5885
  %5889 = xor <8 x i1> %5885, splat (i1 true)
  %5890 = and <8 x i1> %119, %5889
  %5891 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5888)
  %5892 = bitcast <8 x i1> %5888 to i8
  %5893 = call i8 @llvm.cttz.i8(i8 %5892, i1 false)
  %5894 = zext i8 %5893 to i32
  %5895 = select i1 %5891, i32 %5894, i32 0
  %tile_snapshot.spill.load1038 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill118, align 64
  %5896 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1038, 0
  %5897 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1038, 1
  %.state1039 = load <8 x i64>, ptr %.slot300, align 64
  %5898 = mul <8 x i64> %.state1039, splat (i64 32)
  %5899 = add <8 x i64> %5897, %5898
  %5900 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5896, 0
  %5901 = insertvalue { <8 x ptr>, <8 x i64> } %5900, <8 x i64> %5899, 1
  %5902 = extractvalue { <8 x ptr>, <8 x i64> } %13, 0
  %5903 = extractvalue { <8 x ptr>, <8 x i64> } %5901, 1
  %5904 = extractelement <8 x ptr> %5902, i32 0
  %5905 = extractelement <8 x i64> %5903, i32 %5895
  %5906 = zext i32 %5895 to i64
  %5907 = mul i64 %5906, 4
  %5908 = sub i64 %5905, %5907
  %5909 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5888)
  %5910 = select i1 %5909, i64 %5908, i64 0
  %private.contiguous.address1040 = getelementptr i8, ptr %5904, i64 %5910
  %private.contiguous.load1041 = load <8 x float>, ptr %private.contiguous.address1040, align 4
  %5911 = select <8 x i1> %5888, <8 x float> %private.contiguous.load1041, <8 x float> zeroinitializer
  %5912 = load <8 x float>, ptr %.slot302, align 32
  %5913 = select <8 x i1> %5888, <8 x float> %5911, <8 x float> %5912
  store <8 x float> %5913, ptr %.slot302, align 32
  %5914 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5890)
  %5915 = bitcast <8 x i1> %5890 to i8
  %5916 = call i8 @llvm.cttz.i8(i8 %5915, i1 false)
  %5917 = zext i8 %5916 to i32
  %5918 = select i1 %5914, i32 %5917, i32 0
  %5919 = load <8 x float>, ptr %.slot302, align 32
  %5920 = select <8 x i1> %5890, <8 x float> zeroinitializer, <8 x float> %5919
  store <8 x float> %5920, ptr %.slot302, align 32
  br label %direct.schedule.287

direct.schedule.287:                              ; preds = %direct.schedule.285
  %.spill.load1042 = load <8 x i1>, ptr %.spill301, align 1
  %5921 = and <8 x i1> %119, %.spill.load1042
  %5922 = xor <8 x i1> %.spill.load1042, splat (i1 true)
  %5923 = and <8 x i1> %119, %5922
  %5924 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5921)
  %5925 = bitcast <8 x i1> %5921 to i8
  %5926 = call i8 @llvm.cttz.i8(i8 %5925, i1 false)
  %5927 = zext i8 %5926 to i32
  %5928 = select i1 %5924, i32 %5927, i32 0
  %tile_snapshot.spill.load1043 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %5929 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1043, 0
  %5930 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1043, 1
  %.state1044 = load <8 x i64>, ptr %.slot300, align 64
  %5931 = mul <8 x i64> %.state1044, splat (i64 32)
  %5932 = add <8 x i64> %5930, %5931
  %5933 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5929, 0
  %5934 = insertvalue { <8 x ptr>, <8 x i64> } %5933, <8 x i64> %5932, 1
  %.state1045 = load <8 x float>, ptr %.slot302, align 32
  %5935 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %5936 = extractvalue { <8 x ptr>, <8 x i64> } %5934, 1
  %5937 = extractelement <8 x ptr> %5935, i32 0
  %5938 = extractelement <8 x i64> %5936, i32 %5928
  %5939 = zext i32 %5928 to i64
  %5940 = mul i64 %5939, 4
  %5941 = sub i64 %5938, %5940
  %5942 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5921)
  %5943 = select i1 %5942, i64 %5941, i64 0
  %private.contiguous.address1046 = getelementptr i8, ptr %5937, i64 %5943
  %private.contiguous.preserve1047 = load <8 x float>, ptr %private.contiguous.address1046, align 4
  %5944 = select <8 x i1> %5921, <8 x float> %.state1045, <8 x float> %private.contiguous.preserve1047
  store <8 x float> %5944, ptr %private.contiguous.address1046, align 4
  %5945 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5923)
  %5946 = bitcast <8 x i1> %5923 to i8
  %5947 = call i8 @llvm.cttz.i8(i8 %5946, i1 false)
  %5948 = zext i8 %5947 to i32
  %5949 = select i1 %5945, i32 %5948, i32 0
  br label %direct.schedule.289

direct.schedule.289:                              ; preds = %direct.schedule.287
  %.state1048 = load <8 x i64>, ptr %.slot300, align 64
  %5950 = add <8 x i64> %.state1048, splat (i64 1)
  %5951 = load <8 x i64>, ptr %.slot300, align 64
  %5952 = select <8 x i1> %119, <8 x i64> %5950, <8 x i64> %5951
  store <8 x i64> %5952, ptr %.slot300, align 64
  br label %direct.schedule.284

direct.schedule.290:                              ; preds = %direct.false1035
  %.state1049 = load <8 x i64>, ptr %.slot120, align 64
  %5953 = add <8 x i64> %.state1049, splat (i64 1)
  %5954 = load <8 x i64>, ptr %.slot120, align 64
  %5955 = select <8 x i1> %119, <8 x i64> %5953, <8 x i64> %5954
  store <8 x i64> %5955, ptr %.slot120, align 64
  br label %direct.schedule.23

direct.schedule.291:                              ; preds = %direct.false369
  %5956 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill303, align 64
  %5957 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %5958 = extractvalue { <8 x ptr>, <8 x i64> } %5956, 0
  %5959 = select <8 x i1> %119, <8 x ptr> %5957, <8 x ptr> %5958
  %5960 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %5961 = extractvalue { <8 x ptr>, <8 x i64> } %5956, 1
  %5962 = select <8 x i1> %119, <8 x i64> %5960, <8 x i64> %5961
  %5963 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5959, 0
  %5964 = insertvalue { <8 x ptr>, <8 x i64> } %5963, <8 x i64> %5962, 1
  store { <8 x ptr>, <8 x i64> } %5964, ptr %tile_snapshot.spill303, align 64
  %5965 = load <8 x i64>, ptr %.slot304, align 64
  %5966 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %5965
  store <8 x i64> %5966, ptr %.slot304, align 64
  br label %direct.schedule.292

direct.schedule.292:                              ; preds = %direct.schedule.299, %direct.schedule.291
  %.state1050 = load <8 x i64>, ptr %.slot304, align 64
  %5967 = icmp slt <8 x i64> %.state1050, splat (i64 2)
  %5968 = extractelement <8 x i1> %5967, i32 0
  br i1 %5968, label %direct.true1051, label %direct.false1052

direct.schedule.293:                              ; preds = %direct.true1051
  %.state1053 = load <8 x i64>, ptr %.slot304, align 64
  %5969 = select <8 x i1> %119, <8 x i64> %.state1053, <8 x i64> zeroinitializer
  %5970 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5971 = srem <8 x i64> %5969, %5970
  %.state1054 = load <8 x i64>, ptr %.slot304, align 64
  %5972 = select <8 x i1> %119, <8 x i64> %.state1054, <8 x i64> zeroinitializer
  %5973 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %5974 = sdiv <8 x i64> %5972, %5973
  %5975 = mul <8 x i64> %5971, splat (i64 8)
  %.spill.load1055 = load <8 x i64>, ptr %.spill, align 64
  %5976 = add <8 x i64> %5975, %.spill.load1055
  %5977 = icmp slt <8 x i64> %5976, splat (i64 3)
  %5978 = load <8 x i1>, ptr %.spill305, align 1
  %5979 = select <8 x i1> %119, <8 x i1> %5977, <8 x i1> %5978
  store <8 x i1> %5979, ptr %.spill305, align 1
  %5980 = select <8 x i1> %119, <8 x i64> %5974, <8 x i64> zeroinitializer
  %5981 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %5982 = srem <8 x i64> %5980, %5981
  %5983 = load <8 x i64>, ptr %.spill306, align 64
  %5984 = select <8 x i1> %119, <8 x i64> %5982, <8 x i64> %5983
  store <8 x i64> %5984, ptr %.spill306, align 64
  store i64 0, ptr %.spill307, align 4
  %5985 = add <8 x i64> zeroinitializer, %5982
  %5986 = mul <8 x i64> %5985, splat (i64 1)
  %5987 = add <8 x i64> %5986, %5971
  %5988 = and <8 x i1> %119, %5977
  %5989 = xor <8 x i1> %5977, splat (i1 true)
  %5990 = and <8 x i1> %119, %5989
  %5991 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5988)
  %5992 = bitcast <8 x i1> %5988 to i8
  %5993 = call i8 @llvm.cttz.i8(i8 %5992, i1 false)
  %5994 = zext i8 %5993 to i32
  %5995 = select i1 %5991, i32 %5994, i32 0
  %tile_snapshot.spill.load1056 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill117, align 64
  %5996 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1056, 0
  %5997 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1056, 1
  %5998 = mul <8 x i64> %5987, splat (i64 32)
  %5999 = add <8 x i64> %5997, %5998
  %6000 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %5996, 0
  %6001 = insertvalue { <8 x ptr>, <8 x i64> } %6000, <8 x i64> %5999, 1
  %6002 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %6003 = extractvalue { <8 x ptr>, <8 x i64> } %6001, 1
  %6004 = extractelement <8 x ptr> %6002, i32 0
  %6005 = extractelement <8 x i64> %6003, i32 %5995
  %6006 = zext i32 %5995 to i64
  %6007 = mul i64 %6006, 4
  %6008 = sub i64 %6005, %6007
  %6009 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5988)
  %6010 = select i1 %6009, i64 %6008, i64 0
  %private.contiguous.address1057 = getelementptr i8, ptr %6004, i64 %6010
  %private.contiguous.load1058 = load <8 x float>, ptr %private.contiguous.address1057, align 4
  %6011 = select <8 x i1> %5988, <8 x float> %private.contiguous.load1058, <8 x float> zeroinitializer
  %6012 = load <8 x float>, ptr %.slot308, align 32
  %6013 = select <8 x i1> %5988, <8 x float> %6011, <8 x float> %6012
  store <8 x float> %6013, ptr %.slot308, align 32
  %6014 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %5990)
  %6015 = bitcast <8 x i1> %5990 to i8
  %6016 = call i8 @llvm.cttz.i8(i8 %6015, i1 false)
  %6017 = zext i8 %6016 to i32
  %6018 = select i1 %6014, i32 %6017, i32 0
  %6019 = load <8 x float>, ptr %.slot308, align 32
  %6020 = select <8 x i1> %5990, <8 x float> zeroinitializer, <8 x float> %6019
  store <8 x float> %6020, ptr %.slot308, align 32
  br label %direct.schedule.295

direct.schedule.295:                              ; preds = %direct.schedule.293
  %.spill.load1059 = load <8 x i64>, ptr %.spill306, align 64
  %6021 = select <8 x i1> %119, <8 x i64> %.spill.load1059, <8 x i64> zeroinitializer
  %6022 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %6023 = sdiv <8 x i64> %6021, %6022
  %.spill.load1060 = load i64, ptr %.spill307, align 4
  %6024 = mul i64 %.spill.load1060, 1
  %.splatinsert1061 = insertelement <8 x i64> poison, i64 %6024, i64 0
  %.splat1062 = shufflevector <8 x i64> %.splatinsert1061, <8 x i64> poison, <8 x i32> zeroinitializer
  %6025 = add <8 x i64> %.splat1062, %6023
  %.spill.load1063 = load <8 x i64>, ptr %.spill306, align 64
  %6026 = select <8 x i1> %119, <8 x i64> %.spill.load1063, <8 x i64> zeroinitializer
  %6027 = select <8 x i1> %119, <8 x i64> splat (i64 8), <8 x i64> splat (i64 1)
  %6028 = srem <8 x i64> %6026, %6027
  %6029 = load <8 x i64>, ptr %.spill309, align 64
  %6030 = select <8 x i1> %119, <8 x i64> %6028, <8 x i64> %6029
  store <8 x i64> %6030, ptr %.spill309, align 64
  %.spill.load1064 = load <8 x i64>, ptr %.spill, align 64
  %6031 = icmp eq <8 x i64> %.spill.load1064, %6028
  %6032 = and <8 x i1> %119, %6031
  %6033 = xor <8 x i1> %6031, splat (i1 true)
  %6034 = and <8 x i1> %119, %6033
  %6035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6032)
  %6036 = bitcast <8 x i1> %6032 to i8
  %6037 = call i8 @llvm.cttz.i8(i8 %6036, i1 false)
  %6038 = zext i8 %6037 to i32
  %6039 = select i1 %6035, i32 %6038, i32 0
  %tile_snapshot.spill.load1065 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill114, align 64
  %6040 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1065, 0
  %6041 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1065, 1
  %6042 = mul <8 x i64> %6025, splat (i64 32)
  %6043 = add <8 x i64> %6041, %6042
  %6044 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6040, 0
  %6045 = insertvalue { <8 x ptr>, <8 x i64> } %6044, <8 x i64> %6043, 1
  %6046 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %6047 = extractvalue { <8 x ptr>, <8 x i64> } %6045, 1
  %6048 = extractelement <8 x ptr> %6046, i32 0
  %6049 = extractelement <8 x i64> %6047, i32 %6039
  %6050 = zext i32 %6039 to i64
  %6051 = mul i64 %6050, 4
  %6052 = sub i64 %6049, %6051
  %6053 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6032)
  %6054 = select i1 %6053, i64 %6052, i64 0
  %private.contiguous.address1066 = getelementptr i8, ptr %6048, i64 %6054
  %private.contiguous.load1067 = load <8 x float>, ptr %private.contiguous.address1066, align 4
  %6055 = select <8 x i1> %6032, <8 x float> %private.contiguous.load1067, <8 x float> zeroinitializer
  %6056 = load <8 x float>, ptr %.slot310, align 32
  %6057 = select <8 x i1> %6032, <8 x float> %6055, <8 x float> %6056
  store <8 x float> %6057, ptr %.slot310, align 32
  %6058 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6034)
  %6059 = bitcast <8 x i1> %6034 to i8
  %6060 = call i8 @llvm.cttz.i8(i8 %6059, i1 false)
  %6061 = zext i8 %6060 to i32
  %6062 = select i1 %6058, i32 %6061, i32 0
  %6063 = load <8 x float>, ptr %.slot310, align 32
  %6064 = select <8 x i1> %6034, <8 x float> zeroinitializer, <8 x float> %6063
  store <8 x float> %6064, ptr %.slot310, align 32
  br label %direct.schedule.297

direct.schedule.297:                              ; preds = %direct.schedule.295
  %.spill.load1068 = load <8 x i64>, ptr %.spill309, align 64
  %6065 = trunc <8 x i64> %.spill.load1068 to <8 x i32>
  %.state1069 = load <8 x float>, ptr %.slot310, align 32
  %6066 = extractelement <8 x i32> %6065, i64 0
  %6067 = icmp ult i32 %6066, 8
  %6068 = select i1 %6067, i32 %6066, i32 0
  %6069 = extractelement <8 x i1> %119, i32 %6068
  %6070 = extractelement <8 x i1> %119, i64 0
  %6071 = and i1 %6067, %6069
  %6072 = and i1 %6070, %6071
  %6073 = extractelement <8 x float> %.state1069, i32 %6068
  %6074 = select i1 %6072, float %6073, float 0.000000e+00
  %6075 = insertelement <8 x float> poison, float %6074, i64 0
  %6076 = xor i1 %6072, true
  %6077 = and i1 %6070, %6076
  %6078 = insertelement <8 x i1> poison, i1 %6077, i64 0
  %6079 = extractelement <8 x i32> %6065, i64 1
  %6080 = icmp ult i32 %6079, 8
  %6081 = select i1 %6080, i32 %6079, i32 0
  %6082 = extractelement <8 x i1> %119, i32 %6081
  %6083 = extractelement <8 x i1> %119, i64 1
  %6084 = and i1 %6080, %6082
  %6085 = and i1 %6083, %6084
  %6086 = extractelement <8 x float> %.state1069, i32 %6081
  %6087 = select i1 %6085, float %6086, float 0.000000e+00
  %6088 = insertelement <8 x float> %6075, float %6087, i64 1
  %6089 = xor i1 %6085, true
  %6090 = and i1 %6083, %6089
  %6091 = insertelement <8 x i1> %6078, i1 %6090, i64 1
  %6092 = extractelement <8 x i32> %6065, i64 2
  %6093 = icmp ult i32 %6092, 8
  %6094 = select i1 %6093, i32 %6092, i32 0
  %6095 = extractelement <8 x i1> %119, i32 %6094
  %6096 = extractelement <8 x i1> %119, i64 2
  %6097 = and i1 %6093, %6095
  %6098 = and i1 %6096, %6097
  %6099 = extractelement <8 x float> %.state1069, i32 %6094
  %6100 = select i1 %6098, float %6099, float 0.000000e+00
  %6101 = insertelement <8 x float> %6088, float %6100, i64 2
  %6102 = xor i1 %6098, true
  %6103 = and i1 %6096, %6102
  %6104 = insertelement <8 x i1> %6091, i1 %6103, i64 2
  %6105 = extractelement <8 x i32> %6065, i64 3
  %6106 = icmp ult i32 %6105, 8
  %6107 = select i1 %6106, i32 %6105, i32 0
  %6108 = extractelement <8 x i1> %119, i32 %6107
  %6109 = extractelement <8 x i1> %119, i64 3
  %6110 = and i1 %6106, %6108
  %6111 = and i1 %6109, %6110
  %6112 = extractelement <8 x float> %.state1069, i32 %6107
  %6113 = select i1 %6111, float %6112, float 0.000000e+00
  %6114 = insertelement <8 x float> %6101, float %6113, i64 3
  %6115 = xor i1 %6111, true
  %6116 = and i1 %6109, %6115
  %6117 = insertelement <8 x i1> %6104, i1 %6116, i64 3
  %6118 = extractelement <8 x i32> %6065, i64 4
  %6119 = icmp ult i32 %6118, 8
  %6120 = select i1 %6119, i32 %6118, i32 0
  %6121 = extractelement <8 x i1> %119, i32 %6120
  %6122 = extractelement <8 x i1> %119, i64 4
  %6123 = and i1 %6119, %6121
  %6124 = and i1 %6122, %6123
  %6125 = extractelement <8 x float> %.state1069, i32 %6120
  %6126 = select i1 %6124, float %6125, float 0.000000e+00
  %6127 = insertelement <8 x float> %6114, float %6126, i64 4
  %6128 = xor i1 %6124, true
  %6129 = and i1 %6122, %6128
  %6130 = insertelement <8 x i1> %6117, i1 %6129, i64 4
  %6131 = extractelement <8 x i32> %6065, i64 5
  %6132 = icmp ult i32 %6131, 8
  %6133 = select i1 %6132, i32 %6131, i32 0
  %6134 = extractelement <8 x i1> %119, i32 %6133
  %6135 = extractelement <8 x i1> %119, i64 5
  %6136 = and i1 %6132, %6134
  %6137 = and i1 %6135, %6136
  %6138 = extractelement <8 x float> %.state1069, i32 %6133
  %6139 = select i1 %6137, float %6138, float 0.000000e+00
  %6140 = insertelement <8 x float> %6127, float %6139, i64 5
  %6141 = xor i1 %6137, true
  %6142 = and i1 %6135, %6141
  %6143 = insertelement <8 x i1> %6130, i1 %6142, i64 5
  %6144 = extractelement <8 x i32> %6065, i64 6
  %6145 = icmp ult i32 %6144, 8
  %6146 = select i1 %6145, i32 %6144, i32 0
  %6147 = extractelement <8 x i1> %119, i32 %6146
  %6148 = extractelement <8 x i1> %119, i64 6
  %6149 = and i1 %6145, %6147
  %6150 = and i1 %6148, %6149
  %6151 = extractelement <8 x float> %.state1069, i32 %6146
  %6152 = select i1 %6150, float %6151, float 0.000000e+00
  %6153 = insertelement <8 x float> %6140, float %6152, i64 6
  %6154 = xor i1 %6150, true
  %6155 = and i1 %6148, %6154
  %6156 = insertelement <8 x i1> %6143, i1 %6155, i64 6
  %6157 = extractelement <8 x i32> %6065, i64 7
  %6158 = icmp ult i32 %6157, 8
  %6159 = select i1 %6158, i32 %6157, i32 0
  %6160 = extractelement <8 x i1> %119, i32 %6159
  %6161 = extractelement <8 x i1> %119, i64 7
  %6162 = and i1 %6158, %6160
  %6163 = and i1 %6161, %6162
  %6164 = extractelement <8 x float> %.state1069, i32 %6159
  %6165 = select i1 %6163, float %6164, float 0.000000e+00
  %6166 = insertelement <8 x float> %6153, float %6165, i64 7
  %6167 = xor i1 %6163, true
  %6168 = and i1 %6161, %6167
  %6169 = insertelement <8 x i1> %6156, i1 %6168, i64 7
  %.state1070 = load <8 x float>, ptr %.slot308, align 32
  %6170 = fdiv <8 x float> %.state1070, %6166
  %.spill.load1071 = load <8 x i1>, ptr %.spill305, align 1
  %6171 = and <8 x i1> %119, %.spill.load1071
  %6172 = xor <8 x i1> %.spill.load1071, splat (i1 true)
  %6173 = and <8 x i1> %119, %6172
  %6174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6171)
  %6175 = bitcast <8 x i1> %6171 to i8
  %6176 = call i8 @llvm.cttz.i8(i8 %6175, i1 false)
  %6177 = zext i8 %6176 to i32
  %6178 = select i1 %6174, i32 %6177, i32 0
  %tile_snapshot.spill.load1072 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill303, align 64
  %6179 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1072, 0
  %6180 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1072, 1
  %.state1073 = load <8 x i64>, ptr %.slot304, align 64
  %6181 = mul <8 x i64> %.state1073, splat (i64 32)
  %6182 = add <8 x i64> %6180, %6181
  %6183 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6179, 0
  %6184 = insertvalue { <8 x ptr>, <8 x i64> } %6183, <8 x i64> %6182, 1
  %6185 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %6186 = extractvalue { <8 x ptr>, <8 x i64> } %6184, 1
  %6187 = extractelement <8 x ptr> %6185, i32 0
  %6188 = extractelement <8 x i64> %6186, i32 %6178
  %6189 = zext i32 %6178 to i64
  %6190 = mul i64 %6189, 4
  %6191 = sub i64 %6188, %6190
  %6192 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6171)
  %6193 = select i1 %6192, i64 %6191, i64 0
  %private.contiguous.address1074 = getelementptr i8, ptr %6187, i64 %6193
  %private.contiguous.preserve1075 = load <8 x float>, ptr %private.contiguous.address1074, align 4
  %6194 = select <8 x i1> %6171, <8 x float> %6170, <8 x float> %private.contiguous.preserve1075
  store <8 x float> %6194, ptr %private.contiguous.address1074, align 4
  %6195 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6173)
  %6196 = bitcast <8 x i1> %6173 to i8
  %6197 = call i8 @llvm.cttz.i8(i8 %6196, i1 false)
  %6198 = zext i8 %6197 to i32
  %6199 = select i1 %6195, i32 %6198, i32 0
  br label %direct.schedule.299

direct.schedule.299:                              ; preds = %direct.schedule.297
  %.state1076 = load <8 x i64>, ptr %.slot304, align 64
  %6200 = add <8 x i64> %.state1076, splat (i64 1)
  %6201 = load <8 x i64>, ptr %.slot304, align 64
  %6202 = select <8 x i1> %119, <8 x i64> %6200, <8 x i64> %6201
  store <8 x i64> %6202, ptr %.slot304, align 64
  br label %direct.schedule.292

direct.schedule.300:                              ; preds = %direct.false1052
  %6203 = load <8 x i64>, ptr %.slot311, align 64
  %6204 = select <8 x i1> %119, <8 x i64> zeroinitializer, <8 x i64> %6203
  store <8 x i64> %6204, ptr %.slot311, align 64
  br label %direct.schedule.301

direct.schedule.301:                              ; preds = %direct.schedule.306, %direct.schedule.300
  %.state1077 = load <8 x i64>, ptr %.slot311, align 64
  %6205 = icmp slt <8 x i64> %.state1077, splat (i64 2)
  %6206 = extractelement <8 x i1> %6205, i32 0
  br i1 %6206, label %direct.true1078, label %direct.false1079

direct.schedule.302:                              ; preds = %direct.true1078
  %.state1080 = load <8 x i64>, ptr %.slot311, align 64
  %6207 = select <8 x i1> %119, <8 x i64> %.state1080, <8 x i64> zeroinitializer
  %6208 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %6209 = srem <8 x i64> %6207, %6208
  %.state1081 = load <8 x i64>, ptr %.slot311, align 64
  %6210 = select <8 x i1> %119, <8 x i64> %.state1081, <8 x i64> zeroinitializer
  %6211 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %6212 = sdiv <8 x i64> %6210, %6211
  %6213 = mul <8 x i64> %6209, splat (i64 8)
  %.spill.load1082 = load <8 x i64>, ptr %.spill, align 64
  %6214 = add <8 x i64> %6213, %.spill.load1082
  %6215 = icmp slt <8 x i64> %6214, splat (i64 3)
  %6216 = load <8 x i1>, ptr %.spill312, align 1
  %6217 = select <8 x i1> %119, <8 x i1> %6215, <8 x i1> %6216
  store <8 x i1> %6217, ptr %.spill312, align 1
  %6218 = select <8 x i1> %6215, <8 x i64> %6214, <8 x i64> splat (i64 2)
  %6219 = load <8 x i64>, ptr %.spill313, align 64
  %6220 = select <8 x i1> %119, <8 x i64> %6218, <8 x i64> %6219
  store <8 x i64> %6220, ptr %.spill313, align 64
  %6221 = select <8 x i1> %119, <8 x i64> %6212, <8 x i64> zeroinitializer
  %6222 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %6223 = srem <8 x i64> %6221, %6222
  %6224 = load <8 x i64>, ptr %.spill314, align 64
  %6225 = select <8 x i1> %119, <8 x i64> %6223, <8 x i64> %6224
  store <8 x i64> %6225, ptr %.spill314, align 64
  %6226 = select <8 x i1> %119, <8 x i64> %6212, <8 x i64> zeroinitializer
  %6227 = select <8 x i1> %119, <8 x i64> splat (i64 2), <8 x i64> splat (i64 1)
  %6228 = sdiv <8 x i64> %6226, %6227
  %6229 = select <8 x i1> %119, <8 x i64> %6228, <8 x i64> zeroinitializer
  %6230 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %6231 = srem <8 x i64> %6229, %6230
  %6232 = load <8 x i64>, ptr %.spill315, align 64
  %6233 = select <8 x i1> %119, <8 x i64> %6231, <8 x i64> %6232
  store <8 x i64> %6233, ptr %.spill315, align 64
  %6234 = select <8 x i1> %119, <8 x i64> %6228, <8 x i64> zeroinitializer
  %6235 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %6236 = sdiv <8 x i64> %6234, %6235
  %6237 = select <8 x i1> %119, <8 x i64> %6236, <8 x i64> zeroinitializer
  %6238 = select <8 x i1> %119, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %6239 = srem <8 x i64> %6237, %6238
  %6240 = load <8 x i64>, ptr %.spill316, align 64
  %6241 = select <8 x i1> %119, <8 x i64> %6239, <8 x i64> %6240
  store <8 x i64> %6241, ptr %.spill316, align 64
  store i64 0, ptr %.spill317, align 4
  %6242 = and <8 x i1> %119, %6215
  %6243 = xor <8 x i1> %6215, splat (i1 true)
  %6244 = and <8 x i1> %119, %6243
  %6245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6242)
  %6246 = bitcast <8 x i1> %6242 to i8
  %6247 = call i8 @llvm.cttz.i8(i8 %6246, i1 false)
  %6248 = zext i8 %6247 to i32
  %6249 = select i1 %6245, i32 %6248, i32 0
  %tile_snapshot.spill.load1083 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill303, align 64
  %6250 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1083, 0
  %6251 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load1083, 1
  %.state1084 = load <8 x i64>, ptr %.slot311, align 64
  %6252 = mul <8 x i64> %.state1084, splat (i64 32)
  %6253 = add <8 x i64> %6251, %6252
  %6254 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %6250, 0
  %6255 = insertvalue { <8 x ptr>, <8 x i64> } %6254, <8 x i64> %6253, 1
  %6256 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %6257 = extractvalue { <8 x ptr>, <8 x i64> } %6255, 1
  %6258 = extractelement <8 x ptr> %6256, i32 0
  %6259 = extractelement <8 x i64> %6257, i32 %6249
  %6260 = zext i32 %6249 to i64
  %6261 = mul i64 %6260, 4
  %6262 = sub i64 %6259, %6261
  %6263 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6242)
  %6264 = select i1 %6263, i64 %6262, i64 0
  %private.contiguous.address1085 = getelementptr i8, ptr %6258, i64 %6264
  %private.contiguous.load1086 = load <8 x float>, ptr %private.contiguous.address1085, align 4
  %6265 = select <8 x i1> %6242, <8 x float> %private.contiguous.load1086, <8 x float> zeroinitializer
  %6266 = load <8 x float>, ptr %.slot318, align 32
  %6267 = select <8 x i1> %6242, <8 x float> %6265, <8 x float> %6266
  store <8 x float> %6267, ptr %.slot318, align 32
  %6268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6244)
  %6269 = bitcast <8 x i1> %6244 to i8
  %6270 = call i8 @llvm.cttz.i8(i8 %6269, i1 false)
  %6271 = zext i8 %6270 to i32
  %6272 = select i1 %6268, i32 %6271, i32 0
  %6273 = load <8 x float>, ptr %.slot318, align 32
  %6274 = select <8 x i1> %6244, <8 x float> zeroinitializer, <8 x float> %6273
  store <8 x float> %6274, ptr %.slot318, align 32
  br label %direct.schedule.304

direct.schedule.304:                              ; preds = %direct.schedule.302
  %.spill.load1087 = load <8 x i64>, ptr %.spill316, align 64
  %6275 = add <8 x i64> zeroinitializer, %.spill.load1087
  %.spill.load1088 = load i64, ptr %.spill317, align 4
  %.splatinsert1089 = insertelement <8 x i64> poison, i64 %.spill.load1088, i64 0
  %.splat1090 = shufflevector <8 x i64> %.splatinsert1089, <8 x i64> poison, <8 x i32> zeroinitializer
  %6276 = add <8 x i64> %.splat1090, %6275
  %.spill.load1091 = load <8 x i64>, ptr %.spill106, align 64
  %.spill.load1092 = load <8 x i64>, ptr %.spill315, align 64
  %6277 = add <8 x i64> %.spill.load1091, %.spill.load1092
  %6278 = mul <8 x i64> %6276, splat (i64 2)
  %6279 = add <8 x i64> %6278, %6277
  %.spill.load1093 = load <8 x i64>, ptr %.spill107, align 64
  %.spill.load1094 = load <8 x i64>, ptr %.spill314, align 64
  %6280 = add <8 x i64> %.spill.load1093, %.spill.load1094
  %6281 = mul <8 x i64> %6279, splat (i64 3)
  %6282 = add <8 x i64> %6281, %6280
  %6283 = icmp sge <8 x i64> %6280, zeroinitializer
  %6284 = and <8 x i1> splat (i1 true), %6283
  %6285 = icmp slt <8 x i64> %6280, splat (i64 3)
  %6286 = and <8 x i1> %6284, %6285
  %.spill.load1095 = load <8 x i64>, ptr %.spill313, align 64
  %6287 = add <8 x i64> zeroinitializer, %.spill.load1095
  %6288 = mul <8 x i64> %6282, splat (i64 3)
  %6289 = add <8 x i64> %6288, %6287
  %.spill.load1096 = load <8 x i1>, ptr %.spill312, align 1
  %6290 = and <8 x i1> %6286, %.spill.load1096
  %6291 = and <8 x i1> %119, %6290
  %6292 = xor <8 x i1> %6290, splat (i1 true)
  %6293 = and <8 x i1> %119, %6292
  %6294 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6291)
  %6295 = bitcast <8 x i1> %6291 to i8
  %6296 = call i8 @llvm.cttz.i8(i8 %6295, i1 false)
  %6297 = zext i8 %6296 to i32
  %6298 = select i1 %6294, i32 %6297, i32 0
  %.state1097 = load <8 x float>, ptr %.slot318, align 32
  %6299 = extractvalue { ptr, i64 } %95, 0
  %6300 = mul <8 x i64> %6289, splat (i64 4)
  %6301 = getelementptr i8, ptr %6299, <8 x i64> %6300
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %.state1097, <8 x ptr> align 1 %6301, <8 x i1> %6291)
  %6302 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %6293)
  %6303 = bitcast <8 x i1> %6293 to i8
  %6304 = call i8 @llvm.cttz.i8(i8 %6303, i1 false)
  %6305 = zext i8 %6304 to i32
  %6306 = select i1 %6302, i32 %6305, i32 0
  br label %direct.schedule.306

direct.schedule.306:                              ; preds = %direct.schedule.304
  %.state1098 = load <8 x i64>, ptr %.slot311, align 64
  %6307 = add <8 x i64> %.state1098, splat (i64 1)
  %6308 = load <8 x i64>, ptr %.slot311, align 64
  %6309 = select <8 x i1> %119, <8 x i64> %6307, <8 x i64> %6308
  store <8 x i64> %6309, ptr %.slot311, align 64
  br label %direct.schedule.301

direct.schedule.307:                              ; preds = %direct.false1079
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.7

direct.true338:                                   ; preds = %direct.schedule.8
  br label %direct.schedule.9

direct.false339:                                  ; preds = %direct.schedule.8
  br label %direct.schedule.12

direct.true348:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false349:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.17

direct.true358:                                   ; preds = %direct.schedule.18
  br label %direct.schedule.19

direct.false359:                                  ; preds = %direct.schedule.18
  br label %direct.schedule.22

direct.true368:                                   ; preds = %direct.schedule.23
  br label %direct.schedule.24

direct.false369:                                  ; preds = %direct.schedule.23
  br label %direct.schedule.291

direct.true372:                                   ; preds = %direct.schedule.25
  br label %direct.schedule.26

direct.false373:                                  ; preds = %direct.schedule.25
  br label %direct.schedule.31

direct.true387:                                   ; preds = %direct.schedule.32
  br label %direct.schedule.33

direct.false388:                                  ; preds = %direct.schedule.32
  br label %direct.schedule.38

direct.true402:                                   ; preds = %direct.schedule.39
  br label %direct.schedule.40

direct.false403:                                  ; preds = %direct.schedule.39
  br label %direct.schedule.50

direct.true408:                                   ; preds = %direct.schedule.41
  br label %direct.schedule.42

direct.false409:                                  ; preds = %direct.schedule.41
  br label %direct.schedule.47

direct.true442:                                   ; preds = %direct.schedule.51
  br label %direct.schedule.52

direct.false443:                                  ; preds = %direct.schedule.51
  br label %direct.schedule.57

direct.true458:                                   ; preds = %direct.schedule.58
  br label %direct.schedule.59

direct.false459:                                  ; preds = %direct.schedule.58
  br label %direct.schedule.62

direct.true468:                                   ; preds = %direct.schedule.63
  br label %direct.schedule.64

direct.false469:                                  ; preds = %direct.schedule.63
  br label %direct.schedule.69

direct.true484:                                   ; preds = %direct.schedule.70
  br label %direct.schedule.71

direct.false485:                                  ; preds = %direct.schedule.70
  br label %direct.schedule.76

direct.true497:                                   ; preds = %direct.schedule.77
  br label %direct.schedule.78

direct.false498:                                  ; preds = %direct.schedule.77
  br label %direct.schedule.81

direct.true507:                                   ; preds = %direct.schedule.82
  br label %direct.schedule.83

direct.false508:                                  ; preds = %direct.schedule.82
  br label %direct.schedule.88

direct.true523:                                   ; preds = %direct.schedule.89
  br label %direct.schedule.90

direct.false524:                                  ; preds = %direct.schedule.89
  br label %direct.schedule.93

direct.true533:                                   ; preds = %direct.schedule.94
  br label %direct.schedule.95

direct.false534:                                  ; preds = %direct.schedule.94
  br label %direct.schedule.100

direct.true549:                                   ; preds = %direct.schedule.101
  br label %direct.schedule.102

direct.false550:                                  ; preds = %direct.schedule.101
  br label %direct.schedule.107

direct.true564:                                   ; preds = %direct.schedule.108
  br label %direct.schedule.109

direct.false565:                                  ; preds = %direct.schedule.108
  br label %direct.schedule.114

direct.true579:                                   ; preds = %direct.schedule.115
  br label %direct.schedule.116

direct.false580:                                  ; preds = %direct.schedule.115
  br label %direct.schedule.123

direct.true601:                                   ; preds = %direct.schedule.124
  br label %direct.schedule.125

direct.false602:                                  ; preds = %direct.schedule.124
  br label %direct.schedule.132

direct.true618:                                   ; preds = %direct.schedule.133
  br label %direct.schedule.134

direct.false619:                                  ; preds = %direct.schedule.133
  br label %direct.schedule.141

direct.true642:                                   ; preds = %direct.schedule.142
  br label %direct.schedule.143

direct.false643:                                  ; preds = %direct.schedule.142
  br label %direct.schedule.149

direct.true647:                                   ; preds = %direct.schedule.144
  br label %direct.schedule.145

direct.false648:                                  ; preds = %direct.schedule.144
  br label %direct.schedule.148

direct.true680:                                   ; preds = %direct.schedule.150
  br label %direct.schedule.151

direct.false681:                                  ; preds = %direct.schedule.150
  br label %direct.schedule.158

direct.true699:                                   ; preds = %direct.schedule.159
  br label %direct.schedule.160

direct.false700:                                  ; preds = %direct.schedule.159
  br label %direct.schedule.167

direct.true720:                                   ; preds = %direct.schedule.168
  br label %direct.schedule.169

direct.false721:                                  ; preds = %direct.schedule.168
  br label %direct.schedule.174

direct.true735:                                   ; preds = %direct.schedule.175
  br label %direct.schedule.176

direct.false736:                                  ; preds = %direct.schedule.175
  br label %direct.schedule.183

direct.true762:                                   ; preds = %direct.schedule.184
  br label %direct.schedule.185

direct.false763:                                  ; preds = %direct.schedule.184
  br label %direct.schedule.190

direct.true779:                                   ; preds = %direct.schedule.191
  br label %direct.schedule.192

direct.false780:                                  ; preds = %direct.schedule.191
  br label %direct.schedule.199

direct.true803:                                   ; preds = %direct.schedule.200
  br label %direct.schedule.201

direct.false804:                                  ; preds = %direct.schedule.200
  br label %direct.schedule.208

direct.true824:                                   ; preds = %direct.schedule.209
  br label %direct.schedule.210

direct.false825:                                  ; preds = %direct.schedule.209
  br label %direct.schedule.216

direct.true829:                                   ; preds = %direct.schedule.211
  br label %direct.schedule.212

direct.false830:                                  ; preds = %direct.schedule.211
  br label %direct.schedule.215

direct.true862:                                   ; preds = %direct.schedule.217
  br label %direct.schedule.218

direct.false863:                                  ; preds = %direct.schedule.217
  br label %direct.schedule.225

direct.true881:                                   ; preds = %direct.schedule.226
  br label %direct.schedule.227

direct.false882:                                  ; preds = %direct.schedule.226
  br label %direct.schedule.234

direct.true908:                                   ; preds = %direct.schedule.235
  br label %direct.schedule.236

direct.false909:                                  ; preds = %direct.schedule.235
  br label %direct.schedule.248

direct.true919:                                   ; preds = %direct.schedule.239
  br label %direct.schedule.240

direct.false920:                                  ; preds = %direct.schedule.239
  br label %direct.schedule.245

direct.true954:                                   ; preds = %direct.schedule.249
  br label %direct.schedule.250

direct.false955:                                  ; preds = %direct.schedule.249
  br label %direct.schedule.255

direct.true970:                                   ; preds = %direct.schedule.256
  br label %direct.schedule.257

direct.false971:                                  ; preds = %direct.schedule.256
  br label %direct.schedule.262

direct.true986:                                   ; preds = %direct.schedule.263
  br label %direct.schedule.264

direct.false987:                                  ; preds = %direct.schedule.263
  br label %direct.schedule.269

direct.true1002:                                  ; preds = %direct.schedule.270
  br label %direct.schedule.271

direct.false1003:                                 ; preds = %direct.schedule.270
  br label %direct.schedule.276

direct.true1018:                                  ; preds = %direct.schedule.277
  br label %direct.schedule.278

direct.false1019:                                 ; preds = %direct.schedule.277
  br label %direct.schedule.283

direct.true1034:                                  ; preds = %direct.schedule.284
  br label %direct.schedule.285

direct.false1035:                                 ; preds = %direct.schedule.284
  br label %direct.schedule.290

direct.true1051:                                  ; preds = %direct.schedule.292
  br label %direct.schedule.293

direct.false1052:                                 ; preds = %direct.schedule.292
  br label %direct.schedule.300

direct.true1078:                                  ; preds = %direct.schedule.301
  br label %direct.schedule.302

direct.false1079:                                 ; preds = %direct.schedule.301
  br label %direct.schedule.307
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #3

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #3

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

define internal void @llm_attention.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_attention(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_attention.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_attention.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

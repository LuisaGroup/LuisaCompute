"""Prepared fixed-geometry Metal4 attention A/B; root owns post-gate execution.

No build, tuning, retry or cross-framework comparison. Run under external
caffeinate -di. The existing timing helper supplies capture, timestamp checks
and its independent NumPy FP64 oracle, without invoking its fixed-20/10ms CLI.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('program_team_receipts', OUT / 'run.py')
RUN = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUN)
ROOT, SELECTED, BUILD = RUN.ROOT, RUN.SELECTED, RUN.BUILD
BINARY = BUILD / 'bin/benchmark_tile_xir'
HELPERS = ROOT / 'scripts/benchmark/tile_torch'
sys.path.insert(0, str(HELPERS))
import metal4_timing as TIMING

CASES = [
    ('decode-mha-k513', (1, 4, 4, 1, 513, 64, 64), (1, 32)),
    ('prefill-gqa-k129', (1, 4, 2, 32, 129, 64, 64), (4, 32)),
    ('prefill-gqa-b2-k257', (2, 8, 2, 64, 257, 64, 64), (4, 64)),
]
ORDER = [1, 32, 32, 1] * 2
BLOCK, SAMPLES, REPETITIONS, TARGET_MS, WARMUP_MS = 256, 3, 16, 50, 25
TIMEOUT = 180
METRICS = {f'{phase}_{name}': unit for phase in ('throughput', 'latency')
           for name, unit in (('instrumented_dispatch_ns', 'ns'),
                              ('feedback_only_command_buffer_ns_per_dispatch', 'ns'),
                              ('host_wall_us_per_dispatch', 'us'))}
ANSI = re.compile(r'\x1b\[[0-9;]*m')
INVENTORY = r'^\s*"([^"\n]+)"_test ='


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def fingerprint(paths):
    return {str(path): sha(path) for path in sorted(set(map(Path, paths)))}


def field(realization, name):
    values = re.findall(r'(?:^|;)\s*' + re.escape(name) + r'=([^;]+)', realization)
    require(len(values) == 1, f'expected exactly one realization field {name}')
    return values[0]


def receipt(path, frozen):
    path = path.resolve()
    require(path.is_relative_to(OUT) and path.name == 'result.json', 'gate must be a retained local result.json')
    result = json.loads(path.read_text())
    command = json.loads((path.parent / 'command.json').read_text())
    require(result.get('status') == 'passed' and result.get('exit_code') == 0 and
            not result.get('timed_out') and not result.get('interrupted'), f'gate did not pass: {path}')
    for key in ('command', 'cwd', 'source_sha256', 'source_freeze_sha256', 'harness_sha256'):
        require(result.get(key) == command.get(key), f'gate command/result mismatch: {key}')
    require(result['source_sha256'] == frozen['source_sha256'] and
            result['source_freeze_sha256'] == frozen['receipt_sha256'] and
            result['harness_sha256'] == sha(OUT / 'run.py') and result['cwd'] == str(SELECTED),
            'gate does not bind the current frozen selected source/runner')
    require(frozen['finished'] <= result['started'] <= result['finished'] <= time.time(), 'gate chronology invalid')
    for channel in ('stdout', 'stderr'):
        require(sha(path.parent / f'{channel}.txt') == result[f'{channel}_sha256'], 'gate log changed')
    return dict(path=str(path), result=result, files_sha256=fingerprint(
        path.parent / name for name in ('command.json', 'result.json', 'stdout.txt', 'stderr.txt')))


def validate_ctest(path, frozen, expression, count, build_finished, full_runtime=False):
    gate = receipt(path, frozen)
    argv = gate['result']['command']
    require(Path(argv[0]).name == 'ctest' and '--test-dir' in argv and
            argv[argv.index('--test-dir') + 1] == str(BUILD) and '-R' in argv and
            argv[argv.index('-R') + 1] == expression and '-V' in argv and '--output-on-failure' in argv,
            'wrong scoped CTest command')
    require(gate['result']['started'] >= build_finished, 'test predates final full build')
    text = ANSI.sub('', (path.parent / 'stdout.txt').read_text())
    require(re.search(r'^100% tests passed(?:, 0 tests failed)? out of ' + str(count) + '$', text, re.MULTILINE),
            'missing complete CTest success summary')
    summaries = re.findall(r"Suite 'global': all tests passed \((\d+) asserts in (\d+) tests\)", text)
    require(len(summaries) == count and all(int(a) > 0 and int(n) > 0 for a, n in summaries),
            'missing positive actual named-suite assertions')
    if full_runtime:
        names = re.findall(INVENTORY, (SELECTED / 'src/tests/unit/tile/bridge/test_xir_runtime.cpp').read_text(), re.MULTILINE)
        require(int(summaries[0][1]) == len(names) and not re.search(r'\b[1-9]\d* tests skipped\b', text),
                'SIMD runtime gate must run every registered original/new suite')
        gate['registered_runtime_suites'] = names
    return gate


def validate_metal(path, frozen, build):
    """Recheck all actual named isolated logs, not just a successful aggregate flag."""
    path = path.resolve()
    require(path.is_relative_to(OUT), 'Metal isolated results must be retained locally')
    result = json.loads(path.read_text())
    source = SELECTED / 'src/tests/unit/tile/bridge/test_xir_metal.cpp'
    names = re.findall(INVENTORY, source.read_text(), re.MULTILINE)
    require(len(names) == len(set(names)) and names and result.get('complete') is True and
            [row['name'] for row in result['cases']] == names and
            result.get('passed') == len(names) and result.get('failed') == 0 and not result.get('not_run'),
            'Metal isolated inventory is incomplete or differs from the frozen source')
    checked, last_finished = [], build['result']['finished']
    for name, row in zip(names, result['cases']):
        require(row['status'] == 'passed', f'Metal suite not accepted: {name}')
        item = receipt(Path(row['result']), frozen)
        actual = item['result']
        require(actual['command'] == [str(BUILD / 'bin/test_tile_xir_metal'), 'metal4', name, '--success'] and
                actual.get('native') is True and actual['started'] >= last_finished, 'Metal suite command/order drift')
        last_finished = actual['finished']
        folder = Path(item['path']).parent
        stdout, stderr = (folder / 'stdout.txt').read_bytes(), (folder / 'stderr.txt').read_bytes()
        require(not TIMING.gpu_failure_diagnostics(stdout, stderr), 'Metal gate contains a GPU fault')
        text = ANSI.sub('', stdout.decode(errors='replace'))
        summaries = re.findall(r"Suite 'global': all tests passed \((\d+) asserts in (\d+) tests\)", text)
        require(len(summaries) == 1 and int(summaries[0][0]) > 0 and int(summaries[0][1]) == len(names),
                'missing Metal positive assertion summary')
        outcomes = re.findall(r'^Running(?: test)?\s+"([^"\n]+)"\.\.\.\s+(PASSED|SKIPPED)(?=\s|Suite \'global\':|$)',
                              text, re.MULTILINE)
        require(outcomes == [(n, 'PASSED' if n == name else 'SKIPPED') for n in names] and
                re.findall(r'^(\d+) tests skipped$', text, re.MULTILINE) == [str(len(names) - 1)],
                'Metal filter must execute exactly its requested suite, with all others skipped')
        require(not re.search(r'\bFAILED\b|Unexpected exception|early abort for test', text), 'Metal assertion failure')
        item['assertions'] = int(summaries[0][0])
        checked.append(item)
    return dict(path=str(path), files_sha256=fingerprint([path, source]), checked=checked,
                scope='All isolated Metal registrations passed; not a claim about aggregate CTest timeout.')


def verify_power():
    """Retain the attached caffeinate -i assertion; no unrelated global assertion substitute."""
    queries = []
    def query(argv):
        result = subprocess.run(argv, text=True, capture_output=True, timeout=5)
        queries.append(dict(command=argv, exit_code=result.returncode, stdout=result.stdout, stderr=result.stderr))
        require(result.returncode == 0, 'power-state query failed')
        return result.stdout
    try:
        ancestors, pid = [], os.getpid()
        for _ in range(32):
            parent, command = query(['/bin/ps', '-p', str(pid), '-o', 'ppid=', '-o', 'command=']).strip().split(maxsplit=1)
            ancestors.append(dict(pid=pid, ppid=int(parent), command=command))
            pid = int(parent)
            if pid <= 1:
                break
        candidates = []
        for candidate in map(int, query(['/usr/bin/pgrep', '-x', 'caffeinate']).split()):
            parent, command = query(['/bin/ps', '-p', str(candidate), '-o', 'ppid=', '-o', 'command=']).strip().split(maxsplit=1)
            candidates.append(dict(pid=candidate, ppid=int(parent), command=command))
        assertions = query(['/usr/bin/pmset', '-g', 'assertions'])
        ancestor_ids = {entry['pid'] for entry in ancestors}
        attached = [entry for entry in candidates if entry['pid'] in ancestor_ids or entry['ppid'] == os.getpid()]
        active = [entry for entry in attached if any(re.search(r'pid\s+' + str(entry['pid']) + r'\(caffeinate\)', line)
                  and 'PreventUserIdleSystemSleep' in line for line in assertions.splitlines())]
        require(active, 'run directly under external caffeinate -di; attached active -i assertion is required')
        return dict(ancestors=ancestors, attached_active_caffeinate=active, required='-i; -u is not required')
    finally:
        save(OUT / 'probe-power.json', dict(queries=queries, finished=time.time()))


def pair_report(rows, complete):
    indexed = {(row['case'], row['position']): row for row in rows}
    pairs, summaries = [], []
    for case, _, _ in CASES:
        for position in (0, 2, 4, 6):
            if (case, position) not in indexed or (case, position + 1) not in indexed:
                continue
            left, right = indexed[case, position], indexed[case, position + 1]
            baseline, candidate = (left, right) if left['local_lanes'] == 1 else (right, left)
            require((baseline['local_lanes'], candidate['local_lanes']) == (1, 32), 'pair identity drift')
            pairs.append(dict(case=case, positions=[position, position + 1],
                              visit_order=[left['local_lanes'], right['local_lanes']],
                              ratios={metric: candidate['metrics'][metric]['median'] / baseline['metrics'][metric]['median']
                                      for metric in METRICS}))
        selected = [pair for pair in pairs if pair['case'] == case]
        for metric, unit in METRICS.items():
            values = [pair['ratios'][metric] for pair in selected]
            if values:
                summaries.append(dict(case=case, metric=metric, underlying_unit=unit, paired_ratios=values,
                                      pair_count=len(values), median_ratio=statistics.median(values),
                                      min_ratio=min(values), max_ratio=max(values)))
    return dict(cohort_complete=complete, pairs=pairs, summary=summaries,
                ratio='local32 visit median / local1 visit median; <1 means local32 lower time',
                inference='Four predeclared adjacent pairs per case. Descriptive evidence only; no causal '
                          'mechanism, confidence interval, candidate search or MPS/Torch comparison.',
                timing='Six metrics stay separate; instrumented dispatch intervals are not zero-overhead pure kernel time.')


def parse_arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full-build-receipt', type=Path, required=True)
    parser.add_argument('--host-test-receipt', type=Path, default=OUT / 'host-plans/result.json')
    parser.add_argument('--simd-test-receipt', type=Path, default=OUT / 'simd-all/result.json')
    parser.add_argument('--metal-results', type=Path, default=OUT / 'metal-isolated/isolated-metal-results.json')
    parser.add_argument('--host-original-review', type=Path, required=True,
                        help='Retained root review of original host20: 18 pass and exactly 2 baseline-matching budget aborts. '
                             'Attached for provenance, not independently revalidated by this probe.')
    return parser.parse_args()


def main():
    args = parse_arguments()
    require(not any((OUT / name).exists() for name in ('probe-plan.json', 'probe-results.json', 'probe-pairs.json', 'probe-failure.json')),
            'fresh cohort required; no overwrite or retry')
    rows, before, provenance = [], None, []
    case, position = None, None
    try:
        frozen = RUN.check_freeze()
        full_build = receipt(args.full_build_receipt, frozen)
        argv = full_build['result']['command']
        require(Path(argv[0]).name == 'cmake' and argv[1:3] == ['--build', str(BUILD)] and '--target' not in argv,
                'full-build gate must be a complete selected-tree build')
        gates = dict(full_build=full_build,
                     host_plans=validate_ctest(args.host_test_receipt, frozen, '^test_tile_xir_(target_info|program_team)$',
                                               2, full_build['result']['finished']),
                     simd=validate_ctest(args.simd_test_receipt, frozen, '^test_tile_xir_runtime$', 1,
                                         full_build['result']['finished'], full_runtime=True),
                     metal=validate_metal(args.metal_results, frozen, full_build))
        review = args.host_original_review.resolve()
        require(review.is_relative_to(OUT) and review.is_file(), 'root original-host review must be retained locally')
        cache = (BUILD / 'CMakeCache.txt').read_text()
        require('LUISA_COMPUTE_TILE_XIR_TEST_TIRX_COMPARISON:BOOL=OFF' in cache and
                'LUISA_COMPUTE_ENABLE_TILE_TIRX_BRIDGE:BOOL=ON' in cache, 'LLVM linkage isolation configuration changed')
        require(BINARY.is_file() and os.access(BINARY, os.X_OK), 'missing benchmark executable')
        provenance = [SELECTED / path for path in frozen['source_sha256']]
        provenance += [Path(frozen['receipt']), OUT / 'owned.json', OUT / 'run.py', OUT / 'toolchain.json',
                       OUT / 'source-clone.json', review, Path(__file__).resolve(), Path(sys.executable).resolve(), BINARY]
        provenance += [BUILD / name for name in ('CMakeCache.txt', 'compile_commands.json', 'build.ninja')]
        provenance += [SELECTED / path for path in ('src/tests/benchmark/benchmark_tile_xir.cpp',
                                                   'src/tests/common/tile_llm_test_utils.h',
                                                   'src/tests/common/tile_llm_benchmark.h')]
        provenance += [HELPERS / name for name in ('metal4_timing.py', 'compare_llm.py', 'run.py', 'repeat.py')]
        provenance += [path for path in (BUILD / 'bin').iterdir() if path.is_file() and path.suffix == '.dylib']
        for gate in gates.values():
            provenance += list(map(Path, gate['files_sha256']))
            for item in gate.get('checked', []):
                provenance += list(map(Path, item['files_sha256']))
        before = fingerprint(provenance)
        power = verify_power()
        env = {key: value for key, value in os.environ.items() if not key.startswith(('LUISA_', 'MTL_', 'DYLD_'))}
        declared = dict(PYTORCH_ENABLE_MPS_FALLBACK='0', OMP_NUM_THREADS='1', VECLIB_MAXIMUM_THREADS='1',
                        LUISA_TILE_BENCH_METAL4_TIMING='1', LUISA_TILE_BENCH_FIXED_REPETITIONS=str(REPETITIONS),
                        LUISA_TILE_BENCH_XIR_BACKEND='metal4', LUISA_TILE_BENCH_XIR_BLOCK_SIZE=str(BLOCK),
                        LUISA_TILE_BENCH_ATTENTION_QK='mma', LUISA_TILE_BENCH_ATTENTION_PV='mma')
        env.update(declared)
        # NumPy is imported lazily by validate_exports; fix this process's
        # CPU oracle threading before that import as well as the child env.
        for key in ('OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
            os.environ[key] = declared[key]
        save(OUT / 'probe-plan.json', dict(started=time.time(), source_freeze=frozen, gates=gates,
            fingerprints_before=before, power=power, binary=str(BINARY), python_launcher=sys.executable,
            source_fingerprint_scope='Exact current overlay, benchmark source and fixture; other first-party/ext files '
                                     'inherit the immutable prior selected-source clone provenance, not freshly rehashed here.',
            root_original_host_review=dict(path=str(review), sha256=sha(review), validation='root-reviewed, not re-parsed by probe'),
            full_host_suite_passed=False, host_scope='Host target-info/program-team gates pass in full. Original host20 retains '
                '18 passes and two known baseline-matching budget aborts; this is not an all-host-green claim.',
            cases=CASES, order=ORDER, visits=len(CASES) * len(ORDER), block_size=BLOCK, samples=SAMPLES,
            repetitions=REPETITIONS, target_ms=TARGET_MS, warmup_ms=WARMUP_MS,
            timing='Fixed 16-dispatch throughput and single-dispatch latency; 50ms is requested host sample target, '
                   'not guaranteed wall duration with fixed repetitions. Instrumented GPU/control GPU/host remain separate.',
            math='FP32, fast_math=false, relaxed_precision=false, existing DSL QK and PV MMA',
            environment=declared, removed_environment={k: v for k, v in os.environ.items() if k.startswith(('LUISA_', 'MTL_', 'DYLD_'))},
            validation='Two producer full-output/guard checks and an independent NumPy FP64 complete-output oracle each visit. '
                       'Same input hashes across arms; bitwise repeatability only within one local-lanes arm.',
            guard_boundary='Producer reports two checks of 34 guard values; tensor exports contain logical interiors, '
                           'so independent NumPy validation does not independently re-read guard bytes.',
            policy='No simultaneous GPU work, source/build edits, retries, tuning or cross-framework claim. Stop at any failed visit.'))
        inputs_by_case, outputs_by_arm, structures, checksums, settings_by_case = {}, {}, {}, {}, {}
        os.chdir(SELECTED)
        for case, dimensions, attention_block in CASES:
            for position, lanes in enumerate(ORDER):
                require(RUN.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'], 'source freeze changed during cohort')
                folder = OUT / f'probe-{case}-{position:02d}-lanes{lanes}'
                folder.mkdir()
                output, stdout, stderr = folder / 'output.f32', folder / 'stdout.json', folder / 'stderr.log'
                command = [str(BINARY), 'llm', 'attention', ','.join(map(str, dimensions)), *map(str, attention_block),
                           str(SAMPLES), str(TARGET_MS), str(WARMUP_MS), str(output)]
                environment = {**env, 'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(lanes)}
                invocation = dict(command=command, cwd=str(SELECTED), started=time.time(), timeout_seconds=TIMEOUT,
                                  environment={**declared, 'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(lanes)},
                                  source_freeze_sha256=frozen['receipt_sha256'], probe_sha256=sha(__file__))
                save(folder / 'command.json', invocation)
                captured = TIMING.capture(command, environment, TIMEOUT, stdout, stderr)
                captured.update(started=invocation['started'], finished=time.time(), command=command,
                                stdout_sha256=sha(stdout), stderr_sha256=sha(stderr),
                                gpu_failure_diagnostics=TIMING.gpu_failure_diagnostics(stdout.read_bytes(), stderr.read_bytes()))
                if captured['status'] in ('Timeout', 'Interrupted'):
                    captured.update(timed_out=captured['status'] == 'Timeout', termination_reason=captured['status'],
                                    queue_health='Unestablished; root inspection required before further native/GPU execution.')
                save(folder / 'result.json', captured)
                require(captured['status'] == 'OK' and not captured['gpu_failure_diagnostics'], 'capture failed; stop cohort')
                payload = json.loads(stdout.read_text())
                require(TIMING.validate_local_lanes(payload['realization'], lanes) == lanes and
                        TIMING.validate_block_size(payload, BLOCK) == BLOCK, 'mapping request not realized')
                metrics = TIMING.validate(payload, 'attention', dimensions, SAMPLES, REPETITIONS, attention_block)
                oracle = TIMING.validate_exports(output, 'attention', dimensions)
                tensor_paths = [output, *(Path(str(output) + f'.input{i}.f32') for i in range(3))]
                tensors = TIMING.receipts(tensor_paths)
                input_hashes = [tensors[str(path)]['sha256'] for path in tensor_paths[1:]]
                require(inputs_by_case.setdefault(case, input_hashes) == input_hashes, 'input identity drift')
                arm = case, lanes
                output_hash = tensors[str(output)]['sha256']
                require(outputs_by_arm.setdefault(arm, output_hash) == output_hash, 'same-arm output instability')
                programs = dimensions[0] * dimensions[1] * ((dimensions[3] + attention_block[0] - 1) // attention_block[0])
                dispatch = [programs * lanes, 1, 1]
                require(payload['dispatch'] == dispatch, 'expected programs times local lanes dispatch')
                realization = payload['realization']
                require(structures.setdefault(arm, realization) == realization, 'same-arm realization drift')
                checksum = payload['device_timing']['throughput'][0]['dispatches'][0]['shader_checksum']
                require(checksums.setdefault(arm, checksum) == checksum, 'same-arm shader checksum drift')
                settings = {name: field(realization, name) for name in
                            ('max_unrolled_tile_elements', 'max_unrolled_region_work', 'unordered_reduction_partitions',
                             'fast_math', 'ordered_reduction', 'strict_mma')}
                root_order = re.findall(r'; root order (\[[^]]*\])', realization)
                require(len(root_order) == 1, 'missing root order')
                settings['root_order'] = root_order[0]
                require(settings_by_case.setdefault(case, settings) == settings, 'fixed policy inputs changed across arms')
                require(set(metrics) == set(METRICS) and all(len(v['samples']) == SAMPLES and
                        math.isfinite(v['median']) and v['median'] > 0 for v in metrics.values()), 'invalid metric data')
                row = dict(case=case, position=position, local_lanes=lanes, dimensions=dimensions, attention_block=attention_block,
                           programs=programs, dispatch=dispatch, block_size=BLOCK, threadgroups=(dispatch[0] + BLOCK - 1) // BLOCK,
                           realization=realization, checksum=checksum, metrics=metrics, tensor_receipts=tensors,
                           correctness=payload['correctness'], independent_correctness=oracle, payload=str(stdout),
                           command_receipt=str(folder / 'command.json'), result_receipt=str(folder / 'result.json'))
                save(folder / 'validated.json', row)
                rows.append(row)
                print(json.dumps(dict(case=case, position=position, lanes=lanes, completed_visits=len(rows), expected_visits=24)), flush=True)
        after = fingerprint(provenance)
        save(OUT / 'probe-fingerprints-after.json', dict(fingerprints_after=after, unchanged=after == before))
        require(after == before and len(rows) == 24, 'incomplete cohort or provenance drift')
        save(OUT / 'probe-pairs.json', pair_report(rows, True))
        save(OUT / 'probe-results.json', dict(status='complete', finished=time.time(), rows=rows, fingerprints_unchanged=True))
    except BaseException as error:
        save(OUT / 'probe-failure.json', dict(finished=time.time(), case=case, position=position, completed_visits=len(rows),
                                            error=f'{type(error).__name__}: {error}',
                                            queue_health='No automatic resume; root must establish process/GPU health before further work.'))
        if not (OUT / 'probe-results.json').exists():
            save(OUT / 'probe-results.json', dict(status='failed', finished=time.time(), rows=rows, fingerprints_unchanged=None))
        if not (OUT / 'probe-pairs.json').exists():
            save(OUT / 'probe-pairs.json', pair_report(rows, False))
        raise


if __name__ == '__main__':
    main()

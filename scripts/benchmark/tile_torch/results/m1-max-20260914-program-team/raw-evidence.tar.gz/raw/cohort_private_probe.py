"""Same full6 binary, change only the existing cohort-private analysis option.

Run through the frozen full-build receipt runner. Capture/prepare are separated
from replay so native timing never overlaps compilation or another experiment.
"""
import argparse
import json
from pathlib import Path
import sys
import time

import run as receipt
from cpu_probe import CASES

RAW = Path(__file__).resolve().parent
HELPER = receipt.SELECTED / 'scripts/benchmark/tile_torch/native_tile.py'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('capture', 'prepare', 'replay'))
    args = parser.parse_args()
    frozen = receipt.check_freeze()
    for name in ('simd-all-default-6', 'simd-cohort-private-6'):
        path = RAW / name / 'result.json'
        result = json.loads(path.read_text())
        if (result.get('status') != 'passed' or result.get('exit_code') != 0 or
                result.get('source_freeze_sha256') != frozen['receipt_sha256'] or
                receipt.digest(path.parent / 'stdout.txt') != result.get('stdout_sha256')):
            raise ValueError('missing intact same-freeze Tile regression: ' + name)
    files = [receipt.BUILD / 'bin' / name for name in
             ('benchmark_tile_xir', 'libluisa-backend-simd.so', 'libluisa-tile.dylib', 'libluisa-core.dylib')]
    files += [Path(__file__), RAW / 'cpu_probe.py', HELPER, HELPER.with_name('native_tile_replay.cpp'),
              receipt.SELECTED / 'src/backends/simd/llvm/llvm_schedule_codegen.h']
    hashes = {str(path): receipt.digest(path) for path in files}
    identity = dict(started=time.time(), mode=args.mode, cases=CASES,
                    source_freeze_sha256=frozen['receipt_sha256'], critical_files_sha256=hashes,
                    changed_option='LUISA_SIMD_ENABLE_COHORT_PRIVATE_ACCESS=1',
                    baseline='full6 local8 with cohort-private disabled by default',
                    metric='single-thread native entry, common C++ timer',
                    no_torch_comparison=True)
    receipt.save(RAW / f'cohort-private-{args.mode}-6-manifest.json', identity)
    for name, op, dims, bq, bk in CASES:
        prefix = RAW / f'cohort-private-capture-{name}-6/output.f32'
        prepared = RAW / f'cohort-private-prepared-{name}-6'
        if args.mode == 'capture':
            baseline_path = RAW / f'cpu-capture-{name}-l8-6/command.json'
            command = json.loads(baseline_path.read_text())['command']
            old_prefix = str(RAW / f'cpu-capture-{name}-l8-6/output.f32')
            command = [item.replace(old_prefix, str(prefix))
                       .replace(str(Path(old_prefix).parent / 'objects'), str(prefix.parent / 'objects'))
                       for item in command]
            if command[0] != '/usr/bin/env':
                raise ValueError('unexpected baseline launcher')
            command.insert(1, 'LUISA_SIMD_ENABLE_COHORT_PRIVATE_ACCESS=1')
            receipt.run(f'cohort-private-capture-{name}-6', command, 180, native=True)
        elif args.mode == 'prepare':
            receipt.run(f'cohort-private-prepare-{name}-6', [sys.executable, str(HELPER), 'prepare',
                '--capture-kind', 'llm', '--name', 'local8-cohort-private', '--prefix', str(prefix),
                '--log', str(prefix.parent / 'stdout.txt'), '--objects', str(prefix.parent / 'objects'),
                '--llvm', '/opt/homebrew/opt/llvm@22/bin', '--output', str(prepared)], 180)
        else:
            receipt.run(f'cohort-private-replay-{name}-6', [sys.executable, str(HELPER), 'replay',
                '--prepared', str(RAW / f'cpu-prepared-{name}-l8-6/prepared.json'),
                '--prepared', str(prepared / 'prepared.json'), '--cycles', '3', '--samples', '5',
                '--warmup-ms', '40', '--target-ms', '20',
                '--output', str(RAW / f'cohort-private-replayed-{name}-6')], 180, native=True)
    if receipt.check_freeze()['receipt_sha256'] != frozen['receipt_sha256']:
        raise ValueError('source changed during cohort-private experiment')
    if any(receipt.digest(path) != digest for path, digest in hashes.items()):
        raise ValueError('critical file changed during cohort-private experiment')
    identity.update(status='passed', finished=time.time(), critical_files_unchanged=True)
    receipt.save(RAW / f'cohort-private-{args.mode}-6-result.json', identity)


if __name__ == '__main__':
    main()

	.build_version macos, 26, 0
	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0                          ; -- Begin function llm_attention
lCPI0_0:
	.short	1                               ; 0x1
	.short	2                               ; 0x2
	.short	4                               ; 0x4
	.short	8                               ; 0x8
	.short	16                              ; 0x10
	.short	32                              ; 0x20
	.short	64                              ; 0x40
	.short	128                             ; 0x80
lCPI0_1:
	.long	0                               ; 0x0
	.long	1                               ; 0x1
	.long	2                               ; 0x2
	.long	3                               ; 0x3
lCPI0_2:
	.long	4                               ; 0x4
	.long	5                               ; 0x5
	.long	6                               ; 0x6
	.long	7                               ; 0x7
lCPI0_3:
	.quad	6                               ; 0x6
	.quad	7                               ; 0x7
lCPI0_4:
	.quad	2                               ; 0x2
	.quad	3                               ; 0x3
lCPI0_5:
	.quad	4                               ; 0x4
	.quad	5                               ; 0x5
lCPI0_6:
	.quad	0                               ; 0x0
	.quad	1                               ; 0x1
lCPI0_7:
	.quad	24                              ; 0x18
	.quad	28                              ; 0x1c
lCPI0_8:
	.quad	8                               ; 0x8
	.quad	12                              ; 0xc
lCPI0_9:
	.quad	16                              ; 0x10
	.quad	20                              ; 0x14
lCPI0_10:
	.quad	0                               ; 0x0
	.quad	4                               ; 0x4
lCPI0_13:
	.quad	48                              ; 0x30
	.quad	56                              ; 0x38
lCPI0_14:
	.quad	16                              ; 0x10
	.quad	24                              ; 0x18
lCPI0_15:
	.quad	32                              ; 0x20
	.quad	40                              ; 0x28
lCPI0_16:
	.quad	0                               ; 0x0
	.quad	8                               ; 0x8
lCPI0_17:
	.quad	54                              ; 0x36
	.quad	63                              ; 0x3f
lCPI0_18:
	.quad	18                              ; 0x12
	.quad	27                              ; 0x1b
lCPI0_19:
	.quad	36                              ; 0x24
	.quad	45                              ; 0x2d
lCPI0_20:
	.quad	0                               ; 0x0
	.quad	9                               ; 0x9
lCPI0_21:
	.quad	108                             ; 0x6c
	.quad	126                             ; 0x7e
lCPI0_22:
	.quad	36                              ; 0x24
	.quad	54                              ; 0x36
lCPI0_23:
	.quad	72                              ; 0x48
	.quad	90                              ; 0x5a
lCPI0_24:
	.quad	0                               ; 0x0
	.quad	18                              ; 0x12
	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
lCPI0_11:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	4                               ; 0x4
	.byte	8                               ; 0x8
	.byte	16                              ; 0x10
	.byte	32                              ; 0x20
	.byte	64                              ; 0x40
	.byte	128                             ; 0x80
lCPI0_12:
	.byte	1                               ; 0x1
	.byte	2                               ; 0x2
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.byte	0                               ; 0x0
	.section	__TEXT,__text,regular,pure_instructions
	.p2align	2
_llm_attention:                         ; @llm_attention
; %bb.0:                                ; %prologue
	dup.4s	v1, w2
Lloh0:
	adrp	x8, lCPI0_1@PAGE
Lloh1:
	ldr	q2, [x8, lCPI0_1@PAGEOFF]
Lloh2:
	adrp	x8, lCPI0_2@PAGE
Lloh3:
	ldr	q3, [x8, lCPI0_2@PAGEOFF]
	cmhi.4s	v31, v1, v3
	cmhi.4s	v30, v1, v2
	uzp1.8h	v18, v30, v31
	umaxv.8h	h0, v18
	fmov	w8, s0
	tbnz	w8, #0, LBB0_1
	b	LBB0_369
LBB0_1:                                 ; %direct.activate
	stp	d15, d14, [sp, #-160]!          ; 16-byte Folded Spill
	stp	d13, d12, [sp, #16]             ; 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             ; 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               ; 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            ; 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            ; 16-byte Folded Spill
	stp	x29, x30, [sp, #144]            ; 16-byte Folded Spill
	sub	sp, sp, #10, lsl #12            ; =40960
	sub	sp, sp, #2080
	str	q3, [sp, #11104]                ; 16-byte Spill
	str	q2, [sp, #11152]                ; 16-byte Spill
	str	q1, [sp, #11168]                ; 16-byte Spill
	add	x5, sp, #6, lsl #12             ; =24576
	add	x5, x5, #3928
	add	x23, sp, #6, lsl #12            ; =24576
	add	x23, x23, #2376
Lloh4:
	adrp	x8, lCPI0_0@PAGE
Lloh5:
	ldr	q0, [x8, lCPI0_0@PAGEOFF]
	and.16b	v0, v18, v0
	addv.8h	h0, v0
	ldr	w8, [x1]
	ldr	w9, [x1, #36]
	add	w8, w9, w8, lsl #5
Lloh6:
	adrp	x9, lCPI0_3@PAGE
Lloh7:
	ldr	q1, [x9, lCPI0_3@PAGEOFF]
	sshll2.2d	v15, v31, #0
	and.16b	v1, v15, v1
	str	q1, [sp, #11248]                ; 16-byte Spill
	sshll2.2d	v10, v30, #0
Lloh8:
	adrp	x9, lCPI0_5@PAGE
Lloh9:
	ldr	q1, [x9, lCPI0_5@PAGEOFF]
	sshll.2d	v20, v31, #0
	str	q1, [sp, #48]                   ; 16-byte Spill
	and.16b	v1, v20, v1
	str	q1, [sp, #11232]                ; 16-byte Spill
Lloh10:
	adrp	x9, lCPI0_6@PAGE
Lloh11:
	ldr	q1, [x9, lCPI0_6@PAGEOFF]
	sshll.2d	v19, v30, #0
	str	q1, [sp, #4528]                 ; 16-byte Spill
	and.16b	v1, v19, v1
	str	q1, [sp, #11264]                ; 16-byte Spill
	lsr	w8, w8, #3
	dup.4s	v1, w8
	add	x27, sp, #6, lsl #12            ; =24576
	add	x27, x27, #2232
	add	x26, sp, #5, lsl #12            ; =20480
	add	x26, x26, #3768
	and.16b	v3, v30, v1
	and.16b	v1, v31, v1
	ushll2.2d	v2, v1, #0
	ldr	x8, [x0]
	ldr	x9, [x0, #16]
	str	x9, [sp, #6664]                 ; 8-byte Spill
	ldr	x9, [x0, #32]
	str	x9, [sp, #6656]                 ; 8-byte Spill
	ushll2.2d	v25, v3, #0
	ushll.2d	v26, v1, #0
	ushll.2d	v27, v3, #0
	ldr	x9, [x0, #48]
	str	x9, [sp, #40]                   ; 8-byte Spill
	mov	w9, #2                          ; =0x2
	dup.2d	v1, x9
	and.16b	v4, v19, v1
	mvn.16b	v3, v19
	fmov	w9, s0
	and	w9, w9, #0xff
	str	w9, [sp, #11120]                ; 4-byte Spill
Lloh12:
	adrp	x28, lCPI0_4@PAGE
	sub.2d	v16, v4, v3
	and.16b	v0, v20, v1
	mvn.16b	v22, v20
	sub.2d	v7, v0, v22
	and.16b	v0, v10, v1
	mvn.16b	v9, v10
	sub.2d	v17, v0, v9
	and.16b	v0, v15, v1
	mvn.16b	v6, v15
	sub.2d	v8, v0, v6
	mov	w9, #1                          ; =0x1
	dup.2d	v0, x9
	ushr.2d	v4, v27, #1
	ushr.2d	v1, v26, #1
	ushr.2d	v23, v25, #1
	ushr.2d	v24, v2, #1
	str	q2, [sp, #11312]                ; 16-byte Spill
	and.16b	v21, v15, v2
	str	q25, [sp, #11296]               ; 16-byte Spill
	and.16b	v25, v10, v25
	str	q26, [sp, #11136]               ; 16-byte Spill
	and.16b	v26, v20, v26
	str	q27, [sp, #11040]               ; 16-byte Spill
	and.16b	v27, v19, v27
	movi.2d	v28, #0xffffffffffffffff
	add.2d	v29, v16, v28
	and.16b	v27, v27, v29
	add.2d	v29, v7, v28
	and.16b	v26, v26, v29
	add.2d	v29, v8, v28
	add.2d	v28, v17, v28
	and.16b	v25, v25, v28
	and.16b	v21, v21, v29
	mov.16b	v29, v8
	add.2d	v21, v21, v21
	add.2d	v25, v25, v25
	add.2d	v26, v26, v26
	add.2d	v27, v27, v27
	and.16b	v27, v19, v27
	and.16b	v26, v20, v26
	and.16b	v28, v10, v25
	and.16b	v8, v15, v21
Lloh13:
	adrp	x30, lCPI0_7@PAGE
Lloh14:
	adrp	x25, lCPI0_8@PAGE
	mov	w9, #5                          ; =0x5
	dup.2d	v21, x9
	and.16b	v25, v20, v21
	sub.2d	v22, v25, v22
	and.16b	v25, v19, v21
	sub.2d	v3, v25, v3
Lloh15:
	adrp	x9, lCPI0_9@PAGE
Lloh16:
	ldr	q2, [x9, lCPI0_9@PAGEOFF]
	mov.d	x11, v24[1]
	fmov	x12, d24
	mov.d	x9, v23[1]
	fmov	x10, d23
	mov.d	x15, v1[1]
	fmov	x13, d1
	mov.d	x3, v4[1]
	fmov	x1, d4
	ushll2.2d	v1, v31, #0
	and.16b	v25, v1, v0
	ushll2.2d	v1, v30, #0
	and.16b	v1, v1, v0
	str	q1, [sp, #11360]                ; 16-byte Spill
	ushll.2d	v1, v31, #0
	and.16b	v1, v1, v0
	str	q1, [sp, #11440]                ; 16-byte Spill
	ushll.2d	v1, v30, #0
	and.16b	v0, v1, v0
	str	q0, [sp, #11424]                ; 16-byte Spill
	and.16b	v0, v15, v21
	sub.2d	v0, v0, v6
	add	x16, x13, x13, lsl #1
	mov.d	x13, v0[1]
	fmov	x14, d0
	fmov	d0, x16
	add	x15, x15, x15, lsl #1
	mov.d	v0[1], x15
	and.16b	v0, v20, v0
	str	q2, [sp, #5728]                 ; 16-byte Spill
	and.16b	v2, v20, v2
	mov.d	x15, v22[1]
	fmov	x16, d22
Lloh17:
	adrp	x17, lCPI0_10@PAGE
Lloh18:
	ldr	q4, [x17, lCPI0_10@PAGEOFF]
	and.16b	v1, v10, v21
	str	q9, [sp, #11056]                ; 16-byte Spill
	sub.2d	v1, v1, v9
	add	x12, x12, x12, lsl #1
	mov.d	x17, v1[1]
	fmov	x0, d1
	fmov	d1, x12
	add	x11, x11, x11, lsl #1
	mov.d	v1[1], x11
	add	x11, x1, x1, lsl #1
	mov.d	x1, v3[1]
	fmov	x2, d3
	fmov	d3, x11
	add	x11, x3, x3, lsl #1
	mov.d	v3[1], x11
	and.16b	v3, v19, v3
	str	q4, [sp, #5712]                 ; 16-byte Spill
	and.16b	v4, v19, v4
	str	q4, [sp, #11088]                ; 16-byte Spill
	add	x10, x10, x10, lsl #1
	add	x9, x9, x9, lsl #1
	fmov	d4, x10
	mov.d	v4[1], x9
	and.16b	v4, v10, v4
	and.16b	v1, v15, v1
	str	q8, [sp, #4976]                 ; 16-byte Spill
	add.2d	v1, v8, v1
	str	q1, [sp, #4496]                 ; 16-byte Spill
	str	q28, [sp, #4992]                ; 16-byte Spill
	add.2d	v1, v28, v4
	str	q1, [sp, #4480]                 ; 16-byte Spill
	str	q26, [sp, #5008]                ; 16-byte Spill
	add.2d	v0, v26, v0
	str	q0, [sp, #4464]                 ; 16-byte Spill
	str	q27, [sp, #5024]                ; 16-byte Spill
	add.2d	v0, v27, v3
	str	q0, [sp, #4448]                 ; 16-byte Spill
	mov	w10, #3                         ; =0x3
	mov	w4, #33                         ; =0x21
	mov	w11, #32                        ; =0x20
	mov.d	x9, v29[1]
	str	x9, [sp, #9896]                 ; 8-byte Spill
	fmov	x6, d29
	mov.d	x9, v7[1]
	str	x9, [sp, #9888]                 ; 8-byte Spill
	str	q7, [sp, #10560]                ; 16-byte Spill
	fmov	x7, d7
	mov.d	x9, v17[1]
	str	x9, [sp, #10432]                ; 8-byte Spill
	str	q17, [sp, #10528]               ; 16-byte Spill
	fmov	x19, d17
	mov.d	x12, v16[1]
	fmov	x20, d16
Lloh19:
	adrp	x24, lCPI0_11@PAGE
	add	x21, sp, #5, lsl #12            ; =20480
	add	x21, x21, #3472
	add	x22, sp, #5, lsl #12            ; =20480
	add	x22, x22, #3408
	dup.2d	v0, x5
	str	q0, [sp, #1280]                 ; 16-byte Spill
	dup.2d	v0, x23
	str	q0, [sp, #1264]                 ; 16-byte Spill
	dup.2d	v0, x27
	str	q0, [sp, #1248]                 ; 16-byte Spill
	add	x23, sp, #10, lsl #12           ; =40960
	add	x23, x23, #1760
	add	x9, sp, #6, lsl #12             ; =24576
	add	x9, x9, #1592
	dup.2d	v0, x9
	str	q0, [sp, #1232]                 ; 16-byte Spill
	dup.2d	v0, x26
	str	q0, [sp, #1216]                 ; 16-byte Spill
Lloh20:
	ldr	q0, [x28, lCPI0_4@PAGEOFF]
Lloh21:
	ldr	q1, [x30, lCPI0_7@PAGEOFF]
Lloh22:
	ldr	q3, [x25, lCPI0_8@PAGEOFF]
Lloh23:
	ldr	d26, [x24, lCPI0_11@PAGEOFF]
	str	q0, [sp, #16]                   ; 16-byte Spill
	and.16b	v5, v10, v0
	str	q1, [sp, #5696]                 ; 16-byte Spill
	and.16b	v0, v15, v1
	str	q0, [sp, #10656]                ; 16-byte Spill
	str	q3, [sp, #5680]                 ; 16-byte Spill
	and.16b	v0, v10, v3
	str	q0, [sp, #11072]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v23, #0000000000000000
	str	q15, [sp, #11328]               ; 16-byte Spill
	str	q10, [sp, #11344]               ; 16-byte Spill
	str	q16, [sp, #10544]               ; 16-byte Spill
	str	q29, [sp, #10592]               ; 16-byte Spill
	str	q25, [sp, #11408]               ; 16-byte Spill
	str	d26, [sp, #11400]               ; 8-byte Spill
	str	q18, [sp, #11376]               ; 16-byte Spill
	str	q2, [sp, #10736]                ; 16-byte Spill
	b	LBB0_3
LBB0_2:                                 ; %else411
                                        ;   in Loop: Header=BB0_3 Depth=1
	dup.2d	v1, x4
	cmgt.2d	v3, v1, v28
	cmgt.2d	v4, v1, v25
	uzp1.4s	v3, v4, v3
	cmgt.2d	v4, v1, v26
	cmgt.2d	v1, v1, v27
	uzp1.4s	v1, v4, v1
	uzp1.8h	v4, v3, v1
	zip2.8b	v7, v8, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmlt.4s	v7, v7, #0
	bsl.16b	v7, v12, v24
	zip1.8b	v24, v8, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmlt.4s	v24, v24, #0
	bit.16b	v22, v10, v24
	zip1.8b	v24, v0, v0
	ushll.4s	v24, v24, #0
	shl.4s	v24, v24, #31
	cmge.4s	v24, v24, #0
	and.16b	v22, v24, v22
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v24, v0, v7
	and.16b	v0, v18, v4
	xtn.8b	v0, v0
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d26, [sp, #11400]               ; 8-byte Reload
	and.8b	v4, v0, v26
	addv.8b	b4, v4
	fmov	w3, s4
	and.16b	v3, v30, v3
	and.16b	v1, v31, v1
	umaxv.8b	b0, v0
	fmov	w5, s0
	rbit	w24, w3
	clz	w24, w24
	tst	w5, #0x1
	csel	w5, w24, wzr, ne
	ldr	q0, [sp, #11088]                ; 16-byte Reload
	str	q0, [sp, #23952]
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	str	q0, [sp, #23968]
	str	q2, [sp, #23984]
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	str	q0, [sp, #24000]
	ubfiz	x24, x5, #3, #3
	ldr	x25, [x21, x24]
	str	q19, [sp, #23888]
	str	q20, [sp, #23904]
	str	q21, [sp, #23920]
	str	q23, [sp, #23936]
	ldr	x24, [x22, x24]
	lsl	w5, w5, #2
	sub	x5, x25, x5
	add	x5, x5, x24, lsl #5
	tst	w3, #0xff
	csel	x3, xzr, x5, eq
	add	x3, x23, x3
	ldp	q0, q4, [x3]
	bsl.16b	v1, v24, v4
	bit.16b	v0, v22, v3
	stp	q0, q1, [x3]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v20, v20, v0
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v21, v21, v0
	add.2d	v23, v23, v17
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v19, v19, v0
	fmov	x3, d19
	cmp	x3, #10
	ldr	q10, [sp, #11344]               ; 16-byte Reload
	mov.16b	v15, v9
	b.ge	LBB0_19
LBB0_3:                                 ; %direct.true
                                        ; =>This Inner Loop Header: Depth=1
	sshll.2d	v3, v31, #0
	sshll.2d	v8, v30, #0
	and.16b	v0, v8, v19
	and.16b	v4, v10, v20
	and.16b	v25, v3, v21
	mov.16b	v7, v18
	mov.16b	v18, v26
	and.16b	v26, v15, v23
	fmov	x24, d26
	sdiv	x24, x24, x14
	mul	x25, x24, x14
	fmov	d1, x24
	mov.d	x24, v26[1]
	sdiv	x24, x24, x13
	mov.d	v1[1], x24
	fmov	x26, d25
	sdiv	x26, x26, x16
	mul	x27, x26, x16
	fmov	d9, x26
	mov.d	x26, v25[1]
	sdiv	x26, x26, x15
	mov.d	v9[1], x26
	fmov	x28, d4
	sdiv	x28, x28, x0
	mul	x30, x28, x0
	fmov	d11, x28
	mov.d	x28, v4[1]
	sdiv	x28, x28, x17
	mov.d	v11[1], x28
	fmov	x3, d0
	sdiv	x3, x3, x2
	mul	x5, x3, x2
	fmov	d12, x3
	mov.d	x3, v0[1]
	xtn.8b	v2, v7
	sdiv	x3, x3, x1
	mov.d	v12[1], x3
	mul	x24, x24, x13
	fmov	d27, x25
	mov.d	v27[1], x24
	mul	x24, x26, x15
	fmov	d28, x27
	mov.d	v28[1], x24
	mul	x24, x28, x17
	fmov	d29, x30
	mov.d	v29[1], x24
	mul	x3, x3, x1
	mov.16b	v17, v10
	fmov	d10, x5
	mov.d	v10[1], x3
	sub.2d	v0, v0, v10
	sub.2d	v4, v4, v29
	sub.2d	v25, v25, v28
	sub.2d	v26, v26, v27
	shl.2d	v27, v26, #3
	shl.2d	v26, v25, #3
	shl.2d	v4, v4, #3
	shl.2d	v0, v0, #3
	dup.2d	v10, x10
	ldr	q7, [sp, #11264]                ; 16-byte Reload
	orr.16b	v25, v0, v7
	orr.16b	v28, v4, v5
	ldr	q0, [sp, #11232]                ; 16-byte Reload
	orr.16b	v26, v26, v0
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	orr.16b	v27, v27, v0
	dup.2d	v4, x4
	cmgt.2d	v29, v4, v27
	cmgt.2d	v13, v4, v26
	uzp1.4s	v14, v13, v29
	cmgt.2d	v0, v4, v28
	cmgt.2d	v16, v4, v25
	uzp1.4s	v7, v16, v0
	and.16b	v8, v8, v12
	and.16b	v4, v17, v11
	and.16b	v3, v3, v9
	and.16b	v1, v15, v1
	mov.d	x3, v1[1]
	ldr	x9, [sp, #9896]                 ; 8-byte Reload
	sdiv	x5, x3, x9
	msub	x3, x5, x9, x3
	fmov	x5, d1
	sdiv	x24, x5, x6
	msub	x5, x24, x6, x5
	fmov	d9, x5
	mov.d	v9[1], x3
	mov.d	x3, v3[1]
	ldr	x9, [sp, #9888]                 ; 8-byte Reload
	sdiv	x5, x3, x9
	msub	x3, x5, x9, x3
	fmov	x5, d3
	sdiv	x24, x5, x7
	msub	x5, x24, x7, x5
	fmov	d3, x5
	mov.d	v3[1], x3
	mov.d	x3, v4[1]
	ldr	x9, [sp, #10432]                ; 8-byte Reload
	sdiv	x5, x3, x9
	msub	x3, x5, x9, x3
	fmov	x5, d4
	sdiv	x24, x5, x19
	msub	x5, x24, x19, x5
	fmov	d4, x5
	mov.d	v4[1], x3
	mov.d	x3, v8[1]
	uzp1.8h	v1, v7, v14
	sdiv	x5, x3, x12
	msub	x3, x5, x12, x3
	fmov	x5, d8
	sdiv	x24, x5, x20
	msub	x5, x24, x20, x5
	fmov	d7, x5
	mov.d	v7[1], x3
	ldr	q17, [sp, #5024]                ; 16-byte Reload
	add.2d	v8, v7, v17
	ldr	q17, [sp, #5008]                ; 16-byte Reload
	add.2d	v11, v3, v17
	ldr	q17, [sp, #4976]                ; 16-byte Reload
	add.2d	v12, v9, v17
	cmhi.2d	v12, v10, v12
	cmhi.2d	v11, v10, v11
	uzp1.4s	v11, v11, v12
	ldr	q17, [sp, #4992]                ; 16-byte Reload
	add.2d	v12, v4, v17
	cmhi.2d	v12, v10, v12
	cmhi.2d	v8, v10, v8
	dup.2d	v14, x11
	mov.16b	v10, v16
	bsl.16b	v10, v25, v14
	ldr	q16, [sp, #4448]                ; 16-byte Reload
	add.2d	v7, v7, v16
	uzp1.4s	v8, v8, v12
	uzp1.8h	v8, v8, v11
	mov.d	x3, v7[1]
	fmov	x5, d7
	add	x5, x5, x5, lsl #5
	fmov	d7, x5
	add	x3, x3, x3, lsl #5
	mov.d	v7[1], x3
	add.2d	v7, v7, v10
	and.16b	v1, v1, v8
	xtn.8b	v11, v1
	str	q2, [sp, #11280]                ; 16-byte Spill
	and.8b	v8, v2, v11
	shl.8b	v1, v8, #7
	cmlt.8b	v1, v1, #0
	and.8b	v1, v1, v18
	addv.8b	b1, v1
	fmov	w24, s1
	shl.2d	v1, v7, #2
	mov	b7, v8[0]
	mov.b	v7[4], v8[1]
	ushll.2d	v7, v7, #0
	shl.2d	v7, v7, #63
	cmlt.2d	v7, v7, #0
	and.16b	v1, v7, v1
	dup.2d	v15, x8
	add.2d	v1, v15, v1
	movi.2d	v10, #0000000000000000
	movi.2d	v12, #0000000000000000
	tbz	w24, #0, LBB0_5
; %bb.4:                                ; %cond.load
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x3, d1
	ldr	s10, [x3]
LBB0_5:                                 ; %else
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w24, #1, LBB0_7
; %bb.6:                                ; %cond.load392
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x3, v1[1]
	ld1.s	{ v10 }[1], [x3]
LBB0_7:                                 ; %else393
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q18, [sp, #11376]               ; 16-byte Reload
	ldr	q1, [sp, #4480]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	mov.d	x3, v1[1]
	fmov	x5, d1
	add	x5, x5, x5, lsl #5
	fmov	d1, x5
	bsl.16b	v0, v28, v14
	add	x3, x3, x3, lsl #5
	mov.d	v1[1], x3
	add.2d	v0, v1, v0
	mov	b1, v8[2]
	mov.b	v1[4], v8[3]
	shl.2d	v0, v0, #2
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v0, v1, v0
	add.2d	v0, v15, v0
	tbz	w24, #2, LBB0_9
; %bb.8:                                ; %cond.load395
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x3, d0
	ld1.s	{ v10 }[2], [x3]
LBB0_9:                                 ; %else396
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w24, #3, LBB0_11
; %bb.10:                               ; %cond.load398
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x3, v0[1]
	ld1.s	{ v10 }[3], [x3]
LBB0_11:                                ; %else399
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q0, [sp, #4464]                 ; 16-byte Reload
	add.2d	v0, v3, v0
	mov.d	x3, v0[1]
	fmov	x5, d0
	add	x5, x5, x5, lsl #5
	fmov	d0, x5
	mov.16b	v1, v13
	bsl.16b	v1, v26, v14
	add	x3, x3, x3, lsl #5
	mov.d	v0[1], x3
	add.2d	v0, v0, v1
	mov	b1, v8[4]
	mov.b	v1[4], v8[5]
	shl.2d	v0, v0, #2
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v0, v1, v0
	add.2d	v0, v15, v0
	tbz	w24, #4, LBB0_13
; %bb.12:                               ; %cond.load401
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x3, d0
	ld1.s	{ v12 }[0], [x3]
LBB0_13:                                ; %else402
                                        ;   in Loop: Header=BB0_3 Depth=1
	tbz	w24, #5, LBB0_15
; %bb.14:                               ; %cond.load404
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x3, v0[1]
	ld1.s	{ v12 }[1], [x3]
LBB0_15:                                ; %else405
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q0, [sp, #4496]                 ; 16-byte Reload
	add.2d	v0, v9, v0
	mov.d	x3, v0[1]
	fmov	x5, d0
	add	x5, x5, x5, lsl #5
	fmov	d0, x5
	mov.16b	v1, v29
	bsl.16b	v1, v27, v14
	add	x3, x3, x3, lsl #5
	mov.d	v0[1], x3
	add.2d	v0, v0, v1
	mov	b1, v8[6]
	mov.b	v1[4], v8[7]
	shl.2d	v0, v0, #2
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v0, v1, v0
	add.2d	v1, v15, v0
	tbz	w24, #6, LBB0_17
; %bb.16:                               ; %cond.load407
                                        ;   in Loop: Header=BB0_3 Depth=1
	fmov	x3, d1
	ld1.s	{ v12 }[2], [x3]
LBB0_17:                                ; %else408
                                        ;   in Loop: Header=BB0_3 Depth=1
	ldr	q9, [sp, #11328]                ; 16-byte Reload
	ldr	q17, [sp, #11408]               ; 16-byte Reload
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	ldr	q2, [sp, #10736]                ; 16-byte Reload
	bic.8b	v0, v0, v11
	tbz	w24, #7, LBB0_2
; %bb.18:                               ; %cond.load410
                                        ;   in Loop: Header=BB0_3 Depth=1
	mov.d	x3, v1[1]
	ld1.s	{ v12 }[3], [x3]
	b	LBB0_2
LBB0_19:                                ; %direct.schedule.8.preheader
	mov.16b	v25, v17
Lloh24:
	adrp	x8, lCPI0_12@PAGE
Lloh25:
	ldr	d0, [x8, lCPI0_12@PAGEOFF]
	ldr	q23, [sp, #11280]               ; 16-byte Reload
	and.8b	v0, v23, v0
	addv.8b	b0, v0
	fmov	w9, s0
	movi	d0, #0x0000000000ffff
	and.8b	v3, v23, v0
	umaxv.8b	b0, v3
	fmov	w8, s0
	rbit	w13, w9
	clz	w13, w13
	tst	w8, #0x1
	csel	w14, w13, wzr, ne
	ldr	q0, [sp, #11088]                ; 16-byte Reload
	str	q0, [sp, #23824]
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	str	q0, [sp, #23840]
	str	q2, [sp, #23856]
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	str	q0, [sp, #23872]
	and	x8, x14, #0x7
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3344
	ldr	x8, [x13, x8, lsl #3]
	lsl	w10, w14, #2
	str	x10, [sp, #4968]                ; 8-byte Spill
	sub	x10, x8, x10
	movi.2d	v0, #0000000000000000
	and	x8, x14, #0x7
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3280
	add	x15, sp, #10, lsl #12           ; =40960
	add	x15, x15, #1728
	zip2.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	mov	w16, #62154                     ; =0xf2ca
	movk	w16, #61769, lsl #16
	str	q3, [sp, #4512]                 ; 16-byte Spill
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmlt.4s	v3, v3, #0
	movi.2d	v4, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	ldr	q16, [sp, #11360]               ; 16-byte Reload
	ldr	q18, [sp, #11440]               ; 16-byte Reload
	ldr	q17, [sp, #11424]               ; 16-byte Reload
	mov.16b	v24, v25
LBB0_20:                                ; %direct.true338
                                        ; =>This Inner Loop Header: Depth=1
	str	q0, [sp, #23760]
	str	q4, [sp, #23776]
	str	q19, [sp, #23792]
	str	q20, [sp, #23808]
	ldr	x17, [x13, x8, lsl #3]
	add	x17, x10, x17, lsl #5
	tst	w9, #0xff
	csel	x17, xzr, x17, eq
	add	x17, x15, x17
	ldp	q7, q21, [x17]
	dup.4s	v22, w16
	bit.16b	v21, v22, v1
	bit.16b	v7, v22, v3
	stp	q7, q21, [x17]
	add.2d	v4, v4, v16
	add.2d	v19, v19, v18
	add.2d	v20, v20, v24
	add.2d	v0, v0, v17
	fmov	x17, d0
	cmp	x17, #1
	b.lt	LBB0_20
; %bb.21:                               ; %direct.true348.preheader
	movi.2d	v0, #0000000000000000
	and	x8, x14, #0x7
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3216
	add	x15, sp, #10, lsl #12           ; =40960
	add	x15, x15, #1664
	ldr	q3, [sp, #4512]                 ; 16-byte Reload
	zip2.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	movi.2d	v4, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	ldr	q22, [sp, #11248]               ; 16-byte Reload
	ldr	q25, [sp, #11264]               ; 16-byte Reload
	mov.16b	v27, v5
	str	x12, [sp, #7672]                ; 8-byte Spill
LBB0_22:                                ; %direct.true348
                                        ; =>This Inner Loop Header: Depth=1
	str	q0, [sp, #23696]
	str	q4, [sp, #23712]
	str	q19, [sp, #23728]
	str	q20, [sp, #23744]
	ldr	x16, [x13, x8, lsl #3]
	add	x16, x10, x16, lsl #5
	tst	w9, #0xff
	csel	x16, xzr, x16, eq
	add	x16, x15, x16
	ldp	q7, q21, [x16]
	and.16b	v21, v1, v21
	and.16b	v7, v3, v7
	stp	q7, q21, [x16]
	add.2d	v4, v4, v16
	add.2d	v19, v19, v18
	add.2d	v20, v20, v24
	add.2d	v0, v0, v17
	fmov	x16, d0
	cmp	x16, #1
	b.lt	LBB0_22
; %bb.23:                               ; %direct.schedule.18.preheader
	str	x10, [sp, #1296]                ; 8-byte Spill
	str	w9, [sp, #5052]                 ; 4-byte Spill
	mov.16b	v3, v23
	mov.b	v3[7], wzr
	and.8b	v0, v3, v26
	addv.8b	b0, v0
	fmov	w9, s0
	umaxv.8b	b0, v3
	fmov	w8, s0
	rbit	w13, w9
	clz	w13, w13
	tst	w8, #0x1
	csel	w11, w13, wzr, ne
	ldr	q0, [sp, #11088]                ; 16-byte Reload
	str	q0, [sp, #23632]
	ldr	q0, [sp, #11072]                ; 16-byte Reload
	str	q0, [sp, #23648]
	str	q2, [sp, #23664]
	ldr	q0, [sp, #10656]                ; 16-byte Reload
	str	q0, [sp, #23680]
	and	x8, x11, #0x7
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3152
	ldr	x8, [x13, x8, lsl #3]
	lsl	w10, w11, #2
	str	x10, [sp, #6824]                ; 8-byte Spill
	sub	x10, x8, x10
	movi.2d	v0, #0000000000000000
	str	x11, [sp, #80]                  ; 8-byte Spill
	and	x8, x11, #0x7
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3088
	add	x15, sp, #10, lsl #12           ; =40960
	add	x15, x15, #1568
	zip2.8b	v1, v3, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	mov.16b	v26, v3
	zip1.8b	v3, v3, v0
	ushll.4s	v3, v3, #0
	shl.4s	v3, v3, #31
	cmge.4s	v3, v3, #0
	movi.2d	v4, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
LBB0_24:                                ; %direct.true358
                                        ; =>This Inner Loop Header: Depth=1
	str	q0, [sp, #23568]
	str	q4, [sp, #23584]
	str	q19, [sp, #23600]
	str	q20, [sp, #23616]
	ldr	x16, [x13, x8, lsl #3]
	add	x16, x10, x16, lsl #5
	tst	w9, #0xff
	csel	x16, xzr, x16, eq
	add	x16, x15, x16
	ldp	q7, q21, [x16]
	and.16b	v21, v1, v21
	and.16b	v7, v3, v7
	stp	q7, q21, [x16]
	add.2d	v4, v4, v16
	add.2d	v19, v19, v18
	add.2d	v20, v20, v24
	add.2d	v0, v0, v17
	fmov	x16, d0
	cmp	x16, #2
	b.lt	LBB0_24
; %bb.25:                               ; %direct.schedule.23.preheader
	sshll.2d	v0, v30, #0
	sshll.2d	v3, v31, #0
	ldr	q1, [sp, #11040]                ; 16-byte Reload
	ushr.2d	v1, v1, #2
	ldr	q2, [sp, #11296]                ; 16-byte Reload
	ushr.2d	v16, v2, #2
	ldr	q2, [sp, #11136]                ; 16-byte Reload
	ushr.2d	v17, v2, #2
	ldr	q2, [sp, #11312]                ; 16-byte Reload
	ushr.2d	v18, v2, #2
	mov	w8, #33                         ; =0x21
	dup.2d	v4, x8
	and.16b	v7, v9, v4
	sub.2d	v2, v7, v6
	str	q2, [sp, #864]                  ; 16-byte Spill
	ldr	q24, [sp, #11344]               ; 16-byte Reload
	and.16b	v7, v24, v4
	ldr	q28, [sp, #11056]               ; 16-byte Reload
	sub.2d	v2, v7, v28
	str	q2, [sp, #6640]                 ; 16-byte Spill
	and.16b	v19, v3, v4
	mvn.16b	v7, v3
	sub.2d	v2, v19, v7
	str	q2, [sp, #6624]                 ; 16-byte Spill
	and.16b	v19, v0, v4
	mvn.16b	v4, v0
	sub.2d	v2, v19, v4
	str	q2, [sp, #6608]                 ; 16-byte Spill
	mov	w8, #9                          ; =0x9
	dup.2d	v19, x8
	and.16b	v20, v9, v19
	sub.2d	v2, v20, v6
	str	q2, [sp, #11296]                ; 16-byte Spill
	and.16b	v20, v24, v19
	sub.2d	v21, v20, v28
	and.16b	v20, v3, v19
	sub.2d	v2, v20, v7
	str	q2, [sp, #11312]                ; 16-byte Spill
	mov.d	x8, v18[1]
	and.16b	v19, v0, v19
	mov	w11, #67                        ; =0x43
	mul	x8, x8, x11
	fmov	x13, d18
	mul	x13, x13, x11
	fmov	d18, x13
	mov.d	v18[1], x8
	mov.d	x8, v17[1]
	mul	x8, x8, x11
	fmov	x13, d17
	mul	x13, x13, x11
	fmov	d17, x13
	mov.d	v17[1], x8
	mov.d	x8, v16[1]
	mul	x8, x8, x11
	fmov	x13, d16
	mul	x13, x13, x11
	fmov	d16, x13
	mov.d	v16[1], x8
	sub.2d	v10, v19, v4
	mov.d	x8, v1[1]
	mul	x8, x8, x11
	fmov	x13, d1
	mul	x13, x13, x11
	fmov	d1, x13
	mov.d	v1[1], x8
	and.16b	v1, v0, v1
	str	q1, [sp, #1200]                 ; 16-byte Spill
	and.16b	v1, v24, v16
	str	q1, [sp, #1184]                 ; 16-byte Spill
	and.16b	v1, v3, v17
	str	q1, [sp, #1168]                 ; 16-byte Spill
	and.16b	v1, v9, v18
	str	q1, [sp, #1152]                 ; 16-byte Spill
	ldr	q2, [sp, #11168]                ; 16-byte Reload
	ldr	q1, [sp, #11104]                ; 16-byte Reload
	cmhs.4s	v1, v1, v2
	ldr	q5, [sp, #11152]                ; 16-byte Reload
	cmhs.4s	v2, v5, v2
	uzp1.8h	v1, v2, v1
	xtn.8b	v2, v1
	movi	d1, #0xffffffffffffff
	str	d2, [sp, #10424]                ; 8-byte Spill
	orr.8b	v2, v2, v1
	mov	b1, v2[6]
	str	q2, [sp, #6592]                 ; 16-byte Spill
	mov.b	v1[4], v2[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov	w8, #6                          ; =0x6
	dup.2d	v2, x8
	bsl.16b	v1, v22, v2
	str	q1, [sp, #6576]                 ; 16-byte Spill
	mov	w8, #65                         ; =0x41
	dup.2d	v2, x8
	and.16b	v1, v9, v2
	sub.2d	v1, v1, v6
	str	q1, [sp, #6560]                 ; 16-byte Spill
	and.16b	v1, v24, v2
	sub.2d	v1, v1, v28
	str	q1, [sp, #6544]                 ; 16-byte Spill
	and.16b	v1, v3, v2
	sub.2d	v1, v1, v7
	str	q1, [sp, #6528]                 ; 16-byte Spill
	and.16b	v1, v0, v2
	sub.2d	v1, v1, v4
	str	q1, [sp, #6512]                 ; 16-byte Spill
	ldr	q17, [sp, #11232]               ; 16-byte Reload
	sub.2d	v1, v2, v17
	str	q1, [sp, #10512]                ; 16-byte Spill
	sub.2d	v1, v2, v27
	str	q1, [sp, #10496]                ; 16-byte Spill
	sub.2d	v1, v2, v25
	str	q1, [sp, #10576]                ; 16-byte Spill
	mov	w8, #8                          ; =0x8
	dup.2d	v1, x8
	and.16b	v16, v9, v1
	sub.2d	v6, v16, v6
	str	q6, [sp, #11168]                ; 16-byte Spill
	and.16b	v6, v24, v1
	sub.2d	v5, v6, v28
	str	q5, [sp, #11152]                ; 16-byte Spill
	and.16b	v3, v3, v1
	sub.2d	v3, v3, v7
	str	q3, [sp, #11056]                ; 16-byte Spill
	and.16b	v0, v0, v1
	sub.2d	v0, v0, v4
	str	q0, [sp, #11040]                ; 16-byte Spill
	umov.b	w0, v23[0]
	umov.b	w1, v23[1]
	umov.b	w4, v23[2]
	str	q27, [sp, #11200]               ; 16-byte Spill
	uzp1.4s	v0, v25, v27
	uzp1.4s	v1, v17, v22
	movi.4s	v4, #1
	eor.16b	v3, v0, v4
	mov.s	w13, v3[1]
	str	x13, [sp, #11104]               ; 8-byte Spill
	mov.s	w2, v3[2]
	str	x2, [sp, #10976]                ; 8-byte Spill
	mov.s	w15, v3[3]
	str	x15, [sp, #10960]               ; 8-byte Spill
	fmov	w24, s3
	eor.16b	v3, v1, v4
	mov.s	w16, v3[1]
	str	x16, [sp, #10944]               ; 8-byte Spill
	mov.s	w17, v3[2]
	str	x17, [sp, #10928]               ; 8-byte Spill
	mov.s	w3, v3[3]
	str	x3, [sp, #10912]                ; 8-byte Spill
	fmov	w23, s3
	movi.4s	v3, #2
	eor.16b	v1, v1, v3
	eor.16b	v3, v0, v3
	mov.s	w22, v3[1]
	str	x22, [sp, #10896]               ; 8-byte Spill
	sub.2d	v2, v2, v22
	str	q2, [sp, #10480]                ; 16-byte Spill
	mov.s	w20, v3[2]
	str	x20, [sp, #10880]               ; 8-byte Spill
	mov.s	w28, v3[3]
	str	x10, [sp, #5040]                ; 8-byte Spill
	fmov	w6, s3
	mov.16b	v17, v21
	movi	d2, #0xffffffffffff0000
	and.8b	v4, v23, v2
	mov.s	w21, v1[3]
	str	x21, [sp, #10864]               ; 8-byte Spill
	mov.s	w8, v1[1]
	str	x8, [sp, #11008]                ; 8-byte Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	mov.s	w10, v1[2]
	str	x10, [sp, #11024]               ; 8-byte Spill
	str	w9, [sp, #7132]                 ; 4-byte Spill
	fmov	w5, s1
	movi.4s	v1, #4
	eor.16b	v0, v0, v1
	mov.s	w27, v0[1]
	mov.s	w9, v0[2]
	str	x9, [sp, #10992]                ; 8-byte Spill
	mov.s	w26, v0[3]
	movi.2d	v1, #0000000000000000
	mov.b	v1[7], v23[7]
	fmov	w30, s0
	zip2.8b	v0, v26, v0
	bfxil	x8, x24, #0, #3
	ushll.4s	v0, v0, #0
	str	d23, [sp, #23560]
	shl.4s	v0, v0, #31
	ldrb	w8, [x8]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #6496]                 ; 16-byte Spill
	and	w8, w0, w8
	str	w8, [sp, #9036]                 ; 4-byte Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	zip1.8b	v0, v26, v0
	str	q26, [sp, #6672]                ; 16-byte Spill
	ushll.4s	v0, v0, #0
	bfxil	x8, x13, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w8, [x8]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #6480]                 ; 16-byte Spill
	and	w8, w1, w8
	str	w8, [sp, #9032]                 ; 4-byte Spill
	add	x7, sp, #5, lsl #12             ; =20480
	add	x7, x7, #3080
	ldr	q2, [sp, #4512]                 ; 16-byte Reload
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	bfxil	x7, x2, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w8, [x7]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #672]                  ; 16-byte Spill
	and	w8, w4, w8
	str	w8, [sp, #9028]                 ; 4-byte Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	bfxil	x8, x15, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w8, [x8]
	cmlt.4s	v5, v0, #0
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	umov.b	w7, v23[3]
	and	w8, w7, w8
	str	w8, [sp, #9024]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	stp	q0, q5, [sp, #640]              ; 32-byte Folded Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x23, #0, #3
	ldrb	w8, [x8]
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #624]                  ; 16-byte Spill
	umov.b	w9, v23[4]
	and	w8, w9, w8
	str	w8, [sp, #9020]                 ; 4-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x16, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w8, [x8]
	cmlt.4s	v5, v0, #0
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	umov.b	w10, v23[5]
	and	w8, w10, w8
	str	w8, [sp, #9016]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	stp	q0, q5, [sp, #592]              ; 32-byte Folded Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x17, #0, #3
	ldrb	w8, [x8]
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #576]                  ; 16-byte Spill
	umov.b	w2, v23[6]
	and	w8, w2, w8
	str	w8, [sp, #9012]                 ; 4-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x3, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w8, [x8]
	cmlt.4s	v5, v0, #0
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	umov.b	w19, v23[7]
	and	w8, w19, w8
	str	w8, [sp, #9008]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	stp	q0, q5, [sp, #544]              ; 32-byte Folded Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x6, #0, #3
	ldrb	w8, [x8]
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	and	w8, w0, w8
	str	w8, [sp, #9004]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #528]                  ; 16-byte Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x22, #0, #3
	ldrb	w8, [x8]
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	and	w8, w1, w8
	str	w8, [sp, #9000]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #512]                  ; 16-byte Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x20, #0, #3
	ldrb	w8, [x8]
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	and	w8, w4, w8
	str	w8, [sp, #8996]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #496]                  ; 16-byte Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x28, #0, #3
	ldrb	w8, [x8]
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	and	w8, w7, w8
	str	w8, [sp, #8992]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #5456]                 ; 16-byte Spill
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	bfxil	x8, x5, #0, #3
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3080
	bfxil	x13, x21, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w17, [x13]
	cmge.4s	v0, v0, #0
	str	q0, [sp, #5440]                 ; 16-byte Spill
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3080
	bfxil	x13, x30, #0, #3
	mvni.4s	v0, #127, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #6704]                 ; 16-byte Spill
	ldrb	w16, [x13]
	mvni.4s	v0, #63, msl #16
	fneg.4s	v0, v0
	str	q0, [sp, #6688]                 ; 16-byte Spill
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3080
	bfxil	x13, x27, #0, #3
	ldrb	w3, [x13]
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3080
	ldr	x25, [sp, #10992]               ; 8-byte Reload
	bfxil	x13, x25, #0, #3
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #1120]                 ; 16-byte Spill
	ldrb	w15, [x13]
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3080
	bfxil	x13, x26, #0, #3
	shl.4s	v0, v0, #31
	ldrb	w13, [x13]
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #480]                  ; 16-byte Spill
	ldrb	w8, [x8]
	str	w9, [sp, #7356]                 ; 4-byte Spill
	and	w8, w9, w8
	str	w8, [sp, #8988]                 ; 4-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	ldr	x22, [sp, #11008]               ; 8-byte Reload
	bfxil	x8, x22, #0, #3
	cmge.4s	v0, v0, #0
	str	q0, [sp, #464]                  ; 16-byte Spill
	ldrb	w8, [x8]
	str	w10, [sp, #10092]               ; 4-byte Spill
	and	w8, w10, w8
	str	w8, [sp, #8984]                 ; 4-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3080
	ldr	x11, [sp, #11024]               ; 8-byte Reload
	bfxil	x8, x11, #0, #3
	cmge.4s	v0, v0, #0
	str	q0, [sp, #448]                  ; 16-byte Spill
	ldrb	w8, [x8]
	mov	x21, x2
	and	w8, w2, w8
	str	w8, [sp, #8980]                 ; 4-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	mov	x20, x19
	and	w8, w19, w17
	str	w8, [sp, #8976]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	and	w8, w0, w16
	str	w8, [sp, #8972]                 ; 4-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #5424]                 ; 16-byte Spill
	and	w8, w1, w3
	str	w8, [sp, #8968]                 ; 4-byte Spill
	str	w4, [sp, #10316]                ; 4-byte Spill
	and	w8, w4, w15
	str	w8, [sp, #8964]                 ; 4-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	and	w8, w7, w13
	str	w8, [sp, #8960]                 ; 4-byte Spill
	shl.4s	v0, v0, #31
	ldr	w8, [sp, #11120]                ; 4-byte Reload
	rbit	w8, w8
	cmlt.4s	v5, v0, #0
	clz	w8, w8
	ldr	w9, [sp, #5052]                 ; 4-byte Reload
	tst	w9, #0xff
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	mov	x3, x24
                                        ; kill: def $w24 killed $w24 killed $x24 def $x24
	cmge.4s	v0, v0, #0
	stp	q0, q5, [sp, #416]              ; 32-byte Folded Spill
	ubfiz	x9, x24, #2, #3
	str	x9, [sp, #6472]                 ; 8-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	mov	x17, x23
                                        ; kill: def $w23 killed $w23 killed $x23 def $x23
	shl.4s	v0, v0, #31
	ubfiz	x9, x23, #2, #3
	str	x9, [sp, #6464]                 ; 8-byte Spill
	cmge.4s	v5, v0, #0
	mov	x16, x6
                                        ; kill: def $w6 killed $w6 killed $x6 def $x6
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	ubfiz	x9, x6, #2, #3
	str	x9, [sp, #6456]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	stp	q0, q5, [sp, #384]              ; 32-byte Folded Spill
	mov	x15, x5
                                        ; kill: def $w5 killed $w5 killed $x5 def $x5
	ubfiz	x9, x5, #2, #3
	str	x9, [sp, #6448]                 ; 8-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	mov	x13, x30
                                        ; kill: def $w30 killed $w30 killed $lr def $lr
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #368]                  ; 16-byte Spill
	ubfiz	x9, x30, #2, #3
	str	x9, [sp, #6440]                 ; 8-byte Spill
	ubfiz	x9, x3, #2, #3
	str	x9, [sp, #6432]                 ; 8-byte Spill
	zip1.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ldr	x10, [sp, #11104]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6424]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6416]                 ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #6400]                 ; 16-byte Spill
	ldr	x10, [sp, #10976]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6392]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6384]                 ; 8-byte Spill
	zip2.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ldr	x10, [sp, #10960]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6376]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6368]                 ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #6352]                 ; 16-byte Spill
	ubfiz	x9, x17, #2, #3
	str	x9, [sp, #6344]                 ; 8-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	ldr	x10, [sp, #10944]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6336]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6328]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #6304]                 ; 16-byte Spill
	ldr	x10, [sp, #10928]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6296]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6288]                 ; 8-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	ldr	x10, [sp, #10912]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6280]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6272]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	ubfiz	x9, x16, #2, #3
	str	x9, [sp, #6264]                 ; 8-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #6240]                 ; 16-byte Spill
	ldr	x10, [sp, #10896]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6232]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6224]                 ; 8-byte Spill
	zip2.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ldr	x10, [sp, #10880]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6216]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6208]                 ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #6192]                 ; 16-byte Spill
	ubfiz	x9, x28, #2, #3
	str	x9, [sp, #6184]                 ; 8-byte Spill
	ubfiz	x9, x28, #2, #3
	str	x9, [sp, #6176]                 ; 8-byte Spill
	zip1.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	ubfiz	x9, x15, #2, #3
	str	x9, [sp, #6168]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #6144]                 ; 16-byte Spill
	ubfiz	x9, x22, #2, #3
	str	x9, [sp, #6136]                 ; 8-byte Spill
	ubfiz	x9, x22, #2, #3
	str	x9, [sp, #6128]                 ; 8-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	ubfiz	x9, x11, #2, #3
	str	x9, [sp, #6120]                 ; 8-byte Spill
	ubfiz	x9, x11, #2, #3
	str	x9, [sp, #6112]                 ; 8-byte Spill
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #6096]                 ; 16-byte Spill
	ldr	x10, [sp, #10864]               ; 8-byte Reload
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6088]                 ; 8-byte Spill
	ubfiz	x9, x10, #2, #3
	str	x9, [sp, #6080]                 ; 8-byte Spill
	ubfiz	x9, x13, #2, #3
	str	x9, [sp, #6072]                 ; 8-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ubfiz	x9, x27, #2, #3
	str	x9, [sp, #6064]                 ; 8-byte Spill
	and	x9, x27, #0x7
	str	x9, [sp, #6056]                 ; 8-byte Spill
	cmge.4s	v0, v0, #0
	str	q0, [sp, #6032]                 ; 16-byte Spill
	ubfiz	x9, x25, #2, #3
	str	x9, [sp, #6024]                 ; 8-byte Spill
	and	x9, x25, #0x7
	str	x9, [sp, #6016]                 ; 8-byte Spill
	zip2.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	ubfiz	x9, x26, #2, #3
	str	x9, [sp, #6008]                 ; 8-byte Spill
	and	x9, x26, #0x7
	str	x9, [sp, #6000]                 ; 8-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #10640]                ; 16-byte Spill
	and	x9, x8, #0x7
	str	x9, [sp, #5992]                 ; 8-byte Spill
	and	x8, x8, #0x7
	str	x8, [sp, #5984]                 ; 8-byte Spill
	zip1.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #10624]                ; 16-byte Spill
	zip2.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #5968]                 ; 16-byte Spill
	zip1.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #5952]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #5408]                 ; 16-byte Spill
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #1104]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #1088]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #1072]                 ; 16-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v5, v0, #0
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #1056]                 ; 16-byte Spill
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #1040]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	stp	q0, q5, [sp, #336]              ; 32-byte Folded Spill
	zip2.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v5, v0, #0
	zip1.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	stp	q0, q5, [sp, #832]              ; 32-byte Folded Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v5, v0, #0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	stp	q0, q5, [sp, #800]              ; 32-byte Folded Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v20, v0, #0
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v21, v0, #0
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v5, v0, #0
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	stp	q0, q5, [sp, #272]              ; 32-byte Folded Spill
	ubfiz	x8, x14, #3, #5
	str	x8, [sp, #1304]                 ; 8-byte Spill
	and	x9, x14, #0x7
	and	x8, x14, #0x7
	str	x8, [sp, #1032]                 ; 8-byte Spill
	ubfiz	x8, x14, #3, #3
	stp	x8, x9, [sp, #256]              ; 16-byte Folded Spill
	and	x8, x14, #0x7
	str	x8, [sp, #1024]                 ; 8-byte Spill
	ubfiz	x9, x14, #3, #3
	and	x8, x14, #0x7
	stp	x8, x9, [sp, #240]              ; 16-byte Folded Spill
	ubfiz	x9, x14, #3, #3
	and	x8, x14, #0x7
	str	x8, [sp, #1016]                 ; 8-byte Spill
	and	x8, x14, #0x7
	stp	x8, x9, [sp, #224]              ; 16-byte Folded Spill
	and	x9, x14, #0x7
	ubfiz	x8, x14, #3, #3
	stp	x8, x9, [sp, #208]              ; 16-byte Folded Spill
	and	x8, x14, #0x7
	str	x8, [sp, #1008]                 ; 8-byte Spill
	ubfiz	x9, x14, #3, #3
	and	x8, x14, #0x7
	stp	x8, x9, [sp, #192]              ; 16-byte Folded Spill
	ubfiz	x9, x14, #3, #3
	and	x8, x14, #0x7
	stp	x8, x9, [sp, #176]              ; 16-byte Folded Spill
	ubfiz	x9, x14, #3, #3
	and	x8, x14, #0x7
	stp	x8, x9, [sp, #160]              ; 16-byte Folded Spill
	ubfiz	x3, x14, #3, #3
	ubfiz	x8, x14, #3, #3
	str	x8, [sp, #992]                  ; 8-byte Spill
	and	x8, x14, #0x7
	str	x8, [sp, #984]                  ; 8-byte Spill
	and	x8, x14, #0x7
	str	x8, [sp, #152]                  ; 8-byte Spill
	zip2.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v5, v0, #0
	zip1.8b	v0, v2, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v6, v0, #0
	zip1.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	stp	q0, q6, [sp, #944]              ; 32-byte Folded Spill
	str	q4, [sp, #1136]                 ; 16-byte Spill
	zip2.8b	v0, v4, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	stp	q0, q5, [sp, #112]              ; 32-byte Folded Spill
	zip2.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v5, v0, #0
	zip1.8b	v0, v26, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	stp	q0, q5, [sp, #768]              ; 32-byte Folded Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v5, v0, #0
	str	q1, [sp, #64]                   ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	stp	q0, q5, [sp, #736]              ; 32-byte Folded Spill
	ldr	x8, [sp, #1296]                 ; 8-byte Reload
	csel	x10, xzr, x8, eq
	ldr	x9, [sp, #80]                   ; 8-byte Reload
	and	x8, x9, #0x7
	str	x8, [sp, #728]                  ; 8-byte Spill
	and	x8, x9, #0x7
	str	x8, [sp, #5944]                 ; 8-byte Spill
Lloh26:
	adrp	x8, lCPI0_14@PAGE
Lloh27:
	adrp	x14, lCPI0_15@PAGE
Lloh28:
	adrp	x15, lCPI0_16@PAGE
Lloh29:
	adrp	x16, lCPI0_17@PAGE
Lloh30:
	adrp	x17, lCPI0_18@PAGE
Lloh31:
	adrp	x4, lCPI0_19@PAGE
Lloh32:
	adrp	x5, lCPI0_20@PAGE
Lloh33:
	adrp	x6, lCPI0_21@PAGE
Lloh34:
	adrp	x23, lCPI0_22@PAGE
Lloh35:
	adrp	x25, lCPI0_23@PAGE
	add	x11, sp, #10, lsl #12           ; =40960
	add	x11, x11, #1728
	add	x11, x11, x10
	str	x11, [sp, #96]                  ; 8-byte Spill
	movi.2d	v0, #0000000000000000
	movi.2d	v1, #0000000000000000
	movi.2d	v11, #0000000000000000
	movi.2d	v8, #0000000000000000
	movi.2d	v2, #0000000000000000
	str	q2, [sp, #10336]                ; 16-byte Spill
	str	q2, [sp, #9856]                 ; 16-byte Spill
	movi.2d	v5, #0000000000000000
	movi.2d	v3, #0000000000000000
	str	q3, [sp, #4432]                 ; 16-byte Spill
	str	q3, [sp, #4416]                 ; 16-byte Spill
	str	q3, [sp, #7808]                 ; 16-byte Spill
	str	q3, [sp, #7792]                 ; 16-byte Spill
	str	q3, [sp, #7776]                 ; 16-byte Spill
	str	q3, [sp, #7760]                 ; 16-byte Spill
	str	q3, [sp, #4944]                 ; 16-byte Spill
	str	q3, [sp, #4928]                 ; 16-byte Spill
	str	q3, [sp, #8944]                 ; 16-byte Spill
	str	q3, [sp, #8928]                 ; 16-byte Spill
	str	q3, [sp, #4400]                 ; 16-byte Spill
	str	q3, [sp, #4384]                 ; 16-byte Spill
	str	q3, [sp, #4368]                 ; 16-byte Spill
	str	q3, [sp, #4352]                 ; 16-byte Spill
	str	q3, [sp, #4336]                 ; 16-byte Spill
	str	q3, [sp, #4320]                 ; 16-byte Spill
	str	q3, [sp, #4912]                 ; 16-byte Spill
	str	q3, [sp, #4896]                 ; 16-byte Spill
	str	q3, [sp, #5344]                 ; 16-byte Spill
	movi.2d	v16, #0000000000000000
	movi.2d	v18, #0000000000000000
	str	q3, [sp, #5328]                 ; 16-byte Spill
	str	q3, [sp, #4304]                 ; 16-byte Spill
	str	q3, [sp, #4272]                 ; 16-byte Spill
	str	q3, [sp, #7104]                 ; 16-byte Spill
	str	q3, [sp, #7088]                 ; 16-byte Spill
	str	q3, [sp, #7072]                 ; 16-byte Spill
	str	q3, [sp, #7056]                 ; 16-byte Spill
	str	q3, [sp, #7040]                 ; 16-byte Spill
	str	q3, [sp, #7024]                 ; 16-byte Spill
	str	q3, [sp, #10768]                ; 16-byte Spill
	str	q3, [sp, #10816]                ; 16-byte Spill
	str	q3, [sp, #10752]                ; 16-byte Spill
	str	q3, [sp, #8896]                 ; 16-byte Spill
	str	q3, [sp, #8912]                 ; 16-byte Spill
	str	q3, [sp, #9840]                 ; 16-byte Spill
	str	q3, [sp, #4288]                 ; 16-byte Spill
	str	q3, [sp, #8880]                 ; 16-byte Spill
	str	q3, [sp, #8864]                 ; 16-byte Spill
	str	q3, [sp, #10064]                ; 16-byte Spill
	str	q3, [sp, #10048]                ; 16-byte Spill
	str	q3, [sp, #10800]                ; 16-byte Spill
	str	q3, [sp, #5776]                 ; 16-byte Spill
	str	q3, [sp, #5920]                 ; 16-byte Spill
	str	q3, [sp, #5904]                 ; 16-byte Spill
	str	q3, [sp, #5888]                 ; 16-byte Spill
	str	q3, [sp, #5872]                 ; 16-byte Spill
	str	q3, [sp, #4256]                 ; 16-byte Spill
	str	q3, [sp, #9824]                 ; 16-byte Spill
	str	q3, [sp, #5856]                 ; 16-byte Spill
	str	q3, [sp, #5808]                 ; 16-byte Spill
	str	q3, [sp, #5840]                 ; 16-byte Spill
	str	q3, [sp, #5824]                 ; 16-byte Spill
	str	q3, [sp, #5792]                 ; 16-byte Spill
	str	q3, [sp, #4240]                 ; 16-byte Spill
	str	q3, [sp, #4224]                 ; 16-byte Spill
	str	q3, [sp, #4208]                 ; 16-byte Spill
	str	q3, [sp, #9808]                 ; 16-byte Spill
	str	q3, [sp, #9792]                 ; 16-byte Spill
	str	q3, [sp, #9776]                 ; 16-byte Spill
	str	q3, [sp, #7008]                 ; 16-byte Spill
	str	q3, [sp, #6992]                 ; 16-byte Spill
	str	q3, [sp, #7328]                 ; 16-byte Spill
	str	q3, [sp, #4176]                 ; 16-byte Spill
	str	q3, [sp, #4128]                 ; 16-byte Spill
	str	q3, [sp, #4192]                 ; 16-byte Spill
	str	q3, [sp, #9760]                 ; 16-byte Spill
	str	q3, [sp, #4160]                 ; 16-byte Spill
	str	q3, [sp, #4144]                 ; 16-byte Spill
	str	q3, [sp, #4112]                 ; 16-byte Spill
	str	q3, [sp, #4096]                 ; 16-byte Spill
	str	q3, [sp, #7312]                 ; 16-byte Spill
	str	q3, [sp, #4080]                 ; 16-byte Spill
	str	q3, [sp, #4064]                 ; 16-byte Spill
	str	q3, [sp, #5216]                 ; 16-byte Spill
	str	q3, [sp, #9744]                 ; 16-byte Spill
	str	q3, [sp, #7296]                 ; 16-byte Spill
	str	q3, [sp, #7280]                 ; 16-byte Spill
	str	q3, [sp, #9728]                 ; 16-byte Spill
	str	q3, [sp, #4048]                 ; 16-byte Spill
	str	q3, [sp, #4032]                 ; 16-byte Spill
	str	q3, [sp, #4000]                 ; 16-byte Spill
	str	q3, [sp, #3984]                 ; 16-byte Spill
	str	q3, [sp, #4016]                 ; 16-byte Spill
	str	q3, [sp, #9712]                 ; 16-byte Spill
	str	q3, [sp, #9696]                 ; 16-byte Spill
	str	q3, [sp, #9680]                 ; 16-byte Spill
	str	q3, [sp, #9664]                 ; 16-byte Spill
	str	q3, [sp, #9648]                 ; 16-byte Spill
	str	q3, [sp, #9632]                 ; 16-byte Spill
	str	q3, [sp, #8832]                 ; 16-byte Spill
	str	q3, [sp, #3968]                 ; 16-byte Spill
	str	q3, [sp, #3952]                 ; 16-byte Spill
	str	q3, [sp, #3936]                 ; 16-byte Spill
	str	q3, [sp, #3920]                 ; 16-byte Spill
	str	q3, [sp, #9616]                 ; 16-byte Spill
	str	q3, [sp, #7264]                 ; 16-byte Spill
	str	q3, [sp, #6976]                 ; 16-byte Spill
	str	q3, [sp, #6960]                 ; 16-byte Spill
	str	q3, [sp, #3888]                 ; 16-byte Spill
	str	q3, [sp, #8848]                 ; 16-byte Spill
	str	q3, [sp, #8816]                 ; 16-byte Spill
	str	q3, [sp, #9600]                 ; 16-byte Spill
	str	q3, [sp, #3904]                 ; 16-byte Spill
	str	q3, [sp, #5200]                 ; 16-byte Spill
	str	q3, [sp, #3872]                 ; 16-byte Spill
	str	q3, [sp, #6800]                 ; 16-byte Spill
	str	q3, [sp, #9584]                 ; 16-byte Spill
	str	q3, [sp, #3856]                 ; 16-byte Spill
	str	q3, [sp, #3840]                 ; 16-byte Spill
	str	q3, [sp, #3824]                 ; 16-byte Spill
	str	q3, [sp, #9568]                 ; 16-byte Spill
	str	q3, [sp, #9552]                 ; 16-byte Spill
	str	q3, [sp, #9536]                 ; 16-byte Spill
	str	q3, [sp, #3808]                 ; 16-byte Spill
	str	q3, [sp, #3792]                 ; 16-byte Spill
	str	q3, [sp, #3776]                 ; 16-byte Spill
	str	q3, [sp, #3744]                 ; 16-byte Spill
	str	q3, [sp, #3664]                 ; 16-byte Spill
	str	q3, [sp, #3760]                 ; 16-byte Spill
	str	q3, [sp, #3728]                 ; 16-byte Spill
	str	q3, [sp, #3712]                 ; 16-byte Spill
	str	q3, [sp, #3696]                 ; 16-byte Spill
	str	q3, [sp, #3680]                 ; 16-byte Spill
	str	q3, [sp, #4880]                 ; 16-byte Spill
	str	q3, [sp, #4864]                 ; 16-byte Spill
	str	q3, [sp, #3648]                 ; 16-byte Spill
	str	q3, [sp, #4848]                 ; 16-byte Spill
	str	q3, [sp, #4832]                 ; 16-byte Spill
	str	q3, [sp, #4816]                 ; 16-byte Spill
	str	q3, [sp, #4800]                 ; 16-byte Spill
	str	q3, [sp, #3632]                 ; 16-byte Spill
	str	q3, [sp, #3536]                 ; 16-byte Spill
	str	q3, [sp, #3552]                 ; 16-byte Spill
	str	q3, [sp, #3440]                 ; 16-byte Spill
	str	q3, [sp, #3616]                 ; 16-byte Spill
	str	q3, [sp, #3600]                 ; 16-byte Spill
	str	q3, [sp, #3584]                 ; 16-byte Spill
	str	q3, [sp, #3568]                 ; 16-byte Spill
	str	q3, [sp, #4784]                 ; 16-byte Spill
	str	q3, [sp, #4768]                 ; 16-byte Spill
	str	q3, [sp, #4752]                 ; 16-byte Spill
	str	q3, [sp, #4736]                 ; 16-byte Spill
	str	q3, [sp, #3488]                 ; 16-byte Spill
	str	q3, [sp, #3456]                 ; 16-byte Spill
	str	q3, [sp, #3152]                 ; 16-byte Spill
	str	q3, [sp, #3264]                 ; 16-byte Spill
	str	q3, [sp, #3520]                 ; 16-byte Spill
	str	q3, [sp, #3504]                 ; 16-byte Spill
	str	q3, [sp, #3472]                 ; 16-byte Spill
	str	q3, [sp, #3424]                 ; 16-byte Spill
	str	q3, [sp, #6944]                 ; 16-byte Spill
	str	q3, [sp, #6928]                 ; 16-byte Spill
	str	q3, [sp, #6912]                 ; 16-byte Spill
	str	q3, [sp, #6896]                 ; 16-byte Spill
	str	q3, [sp, #3328]                 ; 16-byte Spill
	str	q3, [sp, #3376]                 ; 16-byte Spill
	str	q3, [sp, #3104]                 ; 16-byte Spill
	str	q3, [sp, #3184]                 ; 16-byte Spill
	str	q3, [sp, #3408]                 ; 16-byte Spill
	str	q3, [sp, #5184]                 ; 16-byte Spill
	str	q3, [sp, #3392]                 ; 16-byte Spill
	str	q3, [sp, #9520]                 ; 16-byte Spill
	str	q3, [sp, #9504]                 ; 16-byte Spill
	str	q3, [sp, #9488]                 ; 16-byte Spill
	str	q3, [sp, #9472]                 ; 16-byte Spill
	str	q3, [sp, #9456]                 ; 16-byte Spill
	str	q3, [sp, #3280]                 ; 16-byte Spill
	str	q3, [sp, #3360]                 ; 16-byte Spill
	str	q3, [sp, #9440]                 ; 16-byte Spill
	str	q3, [sp, #9872]                 ; 16-byte Spill
	str	q3, [sp, #9424]                 ; 16-byte Spill
	str	q3, [sp, #9408]                 ; 16-byte Spill
	str	q3, [sp, #9392]                 ; 16-byte Spill
	str	q3, [sp, #8800]                 ; 16-byte Spill
	str	q3, [sp, #3040]                 ; 16-byte Spill
	str	q3, [sp, #7856]                 ; 16-byte Spill
	str	q3, [sp, #7840]                 ; 16-byte Spill
	str	q3, [sp, #1520]                 ; 16-byte Spill
	str	q3, [sp, #3344]                 ; 16-byte Spill
	str	q3, [sp, #8736]                 ; 16-byte Spill
	str	q3, [sp, #8656]                 ; 16-byte Spill
	str	q3, [sp, #8592]                 ; 16-byte Spill
	str	q3, [sp, #8784]                 ; 16-byte Spill
	str	q3, [sp, #8768]                 ; 16-byte Spill
	str	q3, [sp, #8752]                 ; 16-byte Spill
	str	q3, [sp, #10288]                ; 16-byte Spill
	str	q3, [sp, #10272]                ; 16-byte Spill
	str	q3, [sp, #10256]                ; 16-byte Spill
	str	q3, [sp, #10240]                ; 16-byte Spill
	str	q3, [sp, #10224]                ; 16-byte Spill
	str	q3, [sp, #8624]                 ; 16-byte Spill
	str	q3, [sp, #3312]                 ; 16-byte Spill
	str	q3, [sp, #3296]                 ; 16-byte Spill
	str	q3, [sp, #5168]                 ; 16-byte Spill
	str	q3, [sp, #10208]                ; 16-byte Spill
	str	q3, [sp, #10192]                ; 16-byte Spill
	str	q3, [sp, #10176]                ; 16-byte Spill
	str	q3, [sp, #8720]                 ; 16-byte Spill
	str	q3, [sp, #8704]                 ; 16-byte Spill
	str	q3, [sp, #8688]                 ; 16-byte Spill
	str	q3, [sp, #8672]                 ; 16-byte Spill
	str	q3, [sp, #8640]                 ; 16-byte Spill
	str	q3, [sp, #3248]                 ; 16-byte Spill
	str	q3, [sp, #10160]                ; 16-byte Spill
	str	q3, [sp, #8528]                 ; 16-byte Spill
	str	q3, [sp, #8560]                 ; 16-byte Spill
	str	q3, [sp, #8608]                 ; 16-byte Spill
	str	q3, [sp, #8576]                 ; 16-byte Spill
	str	q3, [sp, #8544]                 ; 16-byte Spill
	str	q3, [sp, #3232]                 ; 16-byte Spill
	str	q3, [sp, #3216]                 ; 16-byte Spill
	str	q3, [sp, #3200]                 ; 16-byte Spill
	str	q3, [sp, #10384]                ; 16-byte Spill
	str	q3, [sp, #10144]                ; 16-byte Spill
	str	q3, [sp, #10368]                ; 16-byte Spill
	str	q3, [sp, #8512]                 ; 16-byte Spill
	str	q3, [sp, #10032]                ; 16-byte Spill
	str	q3, [sp, #10016]                ; 16-byte Spill
	str	q3, [sp, #10000]                ; 16-byte Spill
	str	q3, [sp, #9984]                 ; 16-byte Spill
	str	q3, [sp, #3168]                 ; 16-byte Spill
	str	q3, [sp, #8432]                 ; 16-byte Spill
	str	q3, [sp, #8480]                 ; 16-byte Spill
	str	q3, [sp, #8496]                 ; 16-byte Spill
	str	q3, [sp, #9968]                 ; 16-byte Spill
	str	q3, [sp, #8464]                 ; 16-byte Spill
	str	q3, [sp, #9952]                 ; 16-byte Spill
	str	q3, [sp, #3136]                 ; 16-byte Spill
	str	q3, [sp, #5664]                 ; 16-byte Spill
	str	q3, [sp, #5648]                 ; 16-byte Spill
	str	q3, [sp, #3120]                 ; 16-byte Spill
	str	q3, [sp, #5632]                 ; 16-byte Spill
	str	q3, [sp, #8448]                 ; 16-byte Spill
	str	q3, [sp, #9376]                 ; 16-byte Spill
	str	q3, [sp, #9360]                 ; 16-byte Spill
	str	q3, [sp, #9344]                 ; 16-byte Spill
	str	q3, [sp, #5616]                 ; 16-byte Spill
	str	q3, [sp, #5600]                 ; 16-byte Spill
	str	q3, [sp, #5584]                 ; 16-byte Spill
	str	q3, [sp, #8416]                 ; 16-byte Spill
	str	q3, [sp, #11120]                ; 16-byte Spill
	str	q3, [sp, #11104]                ; 16-byte Spill
	str	q3, [sp, #11024]                ; 16-byte Spill
	str	q3, [sp, #11008]                ; 16-byte Spill
	str	q3, [sp, #9328]                 ; 16-byte Spill
	str	q3, [sp, #3088]                 ; 16-byte Spill
	str	q3, [sp, #3072]                 ; 16-byte Spill
	str	q3, [sp, #3056]                 ; 16-byte Spill
	str	q3, [sp, #8400]                 ; 16-byte Spill
	str	q3, [sp, #8384]                 ; 16-byte Spill
	str	q3, [sp, #8368]                 ; 16-byte Spill
	str	q3, [sp, #7360]                 ; 16-byte Spill
	str	q3, [sp, #7392]                 ; 16-byte Spill
	str	q3, [sp, #7376]                 ; 16-byte Spill
	str	q3, [sp, #8352]                 ; 16-byte Spill
	str	q3, [sp, #8336]                 ; 16-byte Spill
	str	q3, [sp, #7648]                 ; 16-byte Spill
	str	q3, [sp, #3024]                 ; 16-byte Spill
	str	q3, [sp, #3008]                 ; 16-byte Spill
	str	q3, [sp, #2992]                 ; 16-byte Spill
	str	q3, [sp, #7744]                 ; 16-byte Spill
	str	q3, [sp, #7728]                 ; 16-byte Spill
	str	q3, [sp, #7584]                 ; 16-byte Spill
	str	q3, [sp, #7600]                 ; 16-byte Spill
	str	q3, [sp, #7632]                 ; 16-byte Spill
	str	q3, [sp, #7616]                 ; 16-byte Spill
	str	q3, [sp, #7568]                 ; 16-byte Spill
	str	q3, [sp, #7552]                 ; 16-byte Spill
	str	q3, [sp, #5488]                 ; 16-byte Spill
	str	q3, [sp, #4720]                 ; 16-byte Spill
	str	q3, [sp, #4704]                 ; 16-byte Spill
	str	q3, [sp, #4688]                 ; 16-byte Spill
	str	q3, [sp, #4672]                 ; 16-byte Spill
	str	q3, [sp, #2896]                 ; 16-byte Spill
	str	q3, [sp, #2944]                 ; 16-byte Spill
	str	q3, [sp, #2976]                 ; 16-byte Spill
	movi.2d	v26, #0000000000000000
	str	q26, [sp, #2960]                ; 16-byte Spill
	str	q26, [sp, #2928]                ; 16-byte Spill
	str	q26, [sp, #2912]                ; 16-byte Spill
	str	q26, [sp, #7184]                ; 16-byte Spill
	str	q26, [sp, #7168]                ; 16-byte Spill
	str	q26, [sp, #7152]                ; 16-byte Spill
	movi.2d	v19, #0000000000000000
	str	q19, [sp, #7136]                ; 16-byte Spill
	str	q26, [sp, #2768]                ; 16-byte Spill
	str	q26, [sp, #2816]                ; 16-byte Spill
	str	q26, [sp, #2832]                ; 16-byte Spill
	str	q26, [sp, #2864]                ; 16-byte Spill
	str	q26, [sp, #2880]                ; 16-byte Spill
	str	q26, [sp, #2848]                ; 16-byte Spill
	str	q26, [sp, #2800]                ; 16-byte Spill
	str	q26, [sp, #2784]                ; 16-byte Spill
	str	q26, [sp, #10128]               ; 16-byte Spill
	str	q26, [sp, #10400]               ; 16-byte Spill
	str	q26, [sp, #9312]                ; 16-byte Spill
	str	q26, [sp, #9296]                ; 16-byte Spill
	str	q26, [sp, #9280]                ; 16-byte Spill
	str	q26, [sp, #9264]                ; 16-byte Spill
	movi.2d	v6, #0000000000000000
	str	q6, [sp, #2752]                 ; 16-byte Spill
	str	q6, [sp, #2736]                 ; 16-byte Spill
	str	q26, [sp, #9232]                ; 16-byte Spill
	str	q19, [sp, #9168]                ; 16-byte Spill
	str	q26, [sp, #10112]               ; 16-byte Spill
	str	q26, [sp, #10096]               ; 16-byte Spill
	str	q6, [sp, #9248]                 ; 16-byte Spill
	str	q26, [sp, #9216]                ; 16-byte Spill
	str	q26, [sp, #2656]                ; 16-byte Spill
	str	q19, [sp, #2528]                ; 16-byte Spill
	movi.2d	v15, #0000000000000000
	movi.2d	v13, #0000000000000000
	str	q26, [sp, #2720]                ; 16-byte Spill
	str	q26, [sp, #2704]                ; 16-byte Spill
	str	q26, [sp, #2688]                ; 16-byte Spill
	str	q26, [sp, #2672]                ; 16-byte Spill
	str	q26, [sp, #9200]                ; 16-byte Spill
	str	q26, [sp, #9184]                ; 16-byte Spill
	str	q26, [sp, #10992]               ; 16-byte Spill
	str	q26, [sp, #10976]               ; 16-byte Spill
	str	q6, [sp, #10960]                ; 16-byte Spill
	str	q6, [sp, #10944]                ; 16-byte Spill
	str	q26, [sp, #2624]                ; 16-byte Spill
	str	q6, [sp, #2640]                 ; 16-byte Spill
	str	q26, [sp, #8320]                ; 16-byte Spill
	str	q26, [sp, #8304]                ; 16-byte Spill
	str	q26, [sp, #2608]                ; 16-byte Spill
	str	q26, [sp, #2592]                ; 16-byte Spill
	str	q26, [sp, #2576]                ; 16-byte Spill
	str	q26, [sp, #2560]                ; 16-byte Spill
	str	q26, [sp, #8288]                ; 16-byte Spill
	str	q26, [sp, #8272]                ; 16-byte Spill
	str	q26, [sp, #2544]                ; 16-byte Spill
	str	q26, [sp, #9920]                ; 16-byte Spill
	str	q26, [sp, #9936]                ; 16-byte Spill
	str	q26, [sp, #9904]                ; 16-byte Spill
	str	q26, [sp, #4656]                ; 16-byte Spill
	str	q26, [sp, #4640]                ; 16-byte Spill
	str	q26, [sp, #8224]                ; 16-byte Spill
	str	q26, [sp, #8208]                ; 16-byte Spill
	str	q26, [sp, #8240]                ; 16-byte Spill
	str	q26, [sp, #8256]                ; 16-byte Spill
	str	q26, [sp, #2512]                ; 16-byte Spill
	str	q26, [sp, #2496]                ; 16-byte Spill
	str	q26, [sp, #2480]                ; 16-byte Spill
	str	q26, [sp, #2464]                ; 16-byte Spill
	str	q26, [sp, #4624]                ; 16-byte Spill
	str	q26, [sp, #4608]                ; 16-byte Spill
	str	q26, [sp, #2448]                ; 16-byte Spill
	str	q26, [sp, #2352]                ; 16-byte Spill
	str	q26, [sp, #2368]                ; 16-byte Spill
	str	q26, [sp, #2400]                ; 16-byte Spill
	str	q26, [sp, #2416]                ; 16-byte Spill
	str	q6, [sp, #2432]                 ; 16-byte Spill
	movi.2d	v29, #0000000000000000
	str	q29, [sp, #5568]                ; 16-byte Spill
	str	q29, [sp, #2384]                ; 16-byte Spill
	str	q29, [sp, #5552]                ; 16-byte Spill
	str	q29, [sp, #5536]                ; 16-byte Spill
	str	q29, [sp, #5520]                ; 16-byte Spill
	str	q29, [sp, #5504]                ; 16-byte Spill
	str	q29, [sp, #10928]               ; 16-byte Spill
	str	q29, [sp, #9152]                ; 16-byte Spill
	str	q29, [sp, #9136]                ; 16-byte Spill
	str	q29, [sp, #9120]                ; 16-byte Spill
	str	q29, [sp, #9104]                ; 16-byte Spill
	str	q29, [sp, #2336]                ; 16-byte Spill
	str	q29, [sp, #8192]                ; 16-byte Spill
	str	q29, [sp, #8176]                ; 16-byte Spill
	str	q29, [sp, #8160]                ; 16-byte Spill
	str	q29, [sp, #10784]               ; 16-byte Spill
	str	q29, [sp, #10912]               ; 16-byte Spill
	str	q29, [sp, #10896]               ; 16-byte Spill
	movi.2d	v27, #0000000000000000
	str	q27, [sp, #8144]                ; 16-byte Spill
	str	q27, [sp, #8112]                ; 16-byte Spill
	str	q27, [sp, #2320]                ; 16-byte Spill
	str	q27, [sp, #2304]                ; 16-byte Spill
	str	q27, [sp, #2288]                ; 16-byte Spill
	str	q27, [sp, #8128]                ; 16-byte Spill
	str	q6, [sp, #2272]                 ; 16-byte Spill
	str	q6, [sp, #2256]                 ; 16-byte Spill
	movi.2d	v9, #0000000000000000
	str	q9, [sp, #4592]                 ; 16-byte Spill
	str	q9, [sp, #4576]                 ; 16-byte Spill
	str	q26, [sp, #4560]                ; 16-byte Spill
	str	q26, [sp, #4544]                ; 16-byte Spill
	str	q26, [sp, #2240]                ; 16-byte Spill
	str	q26, [sp, #7536]                ; 16-byte Spill
	str	q26, [sp, #7520]                ; 16-byte Spill
	str	q26, [sp, #7504]                ; 16-byte Spill
	str	q26, [sp, #7712]                ; 16-byte Spill
	str	q26, [sp, #7696]                ; 16-byte Spill
	str	q26, [sp, #6880]                ; 16-byte Spill
	str	q26, [sp, #7424]                ; 16-byte Spill
	str	q26, [sp, #7440]                ; 16-byte Spill
	str	q26, [sp, #7456]                ; 16-byte Spill
	str	q26, [sp, #7488]                ; 16-byte Spill
	str	q26, [sp, #7472]                ; 16-byte Spill
	str	q26, [sp, #2224]                ; 16-byte Spill
	str	q26, [sp, #2208]                ; 16-byte Spill
	str	q26, [sp, #2192]                ; 16-byte Spill
	str	q26, [sp, #6864]                ; 16-byte Spill
	str	q26, [sp, #6848]                ; 16-byte Spill
	str	q26, [sp, #6832]                ; 16-byte Spill
	movi.2d	v28, #0000000000000000
	str	q6, [sp, #2176]                 ; 16-byte Spill
	str	q6, [sp, #2096]                 ; 16-byte Spill
	str	q9, [sp, #2144]                 ; 16-byte Spill
	str	q9, [sp, #2160]                 ; 16-byte Spill
	str	q9, [sp, #7248]                 ; 16-byte Spill
	str	q9, [sp, #7232]                 ; 16-byte Spill
	str	q9, [sp, #7216]                 ; 16-byte Spill
	str	q27, [sp, #2128]                ; 16-byte Spill
	str	q6, [sp, #1920]                 ; 16-byte Spill
	movi.2d	v12, #0000000000000000
	str	q9, [sp, #8096]                 ; 16-byte Spill
	str	q9, [sp, #9088]                 ; 16-byte Spill
	str	q29, [sp, #9072]                ; 16-byte Spill
	str	q27, [sp, #9056]                ; 16-byte Spill
	str	q27, [sp, #9040]                ; 16-byte Spill
	str	q6, [sp, #7200]                 ; 16-byte Spill
	str	q29, [sp, #8080]                ; 16-byte Spill
	str	q29, [sp, #8032]                ; 16-byte Spill
	str	q6, [sp, #10880]                ; 16-byte Spill
	str	q9, [sp, #10864]                ; 16-byte Spill
	str	q9, [sp, #10848]                ; 16-byte Spill
	str	q9, [sp, #10832]                ; 16-byte Spill
	mov.16b	v9, v31
	mov.16b	v31, v30
	movi.2d	v30, #0000000000000000
	str	q30, [sp, #2112]                ; 16-byte Spill
	mov.16b	v30, v31
	mov.16b	v31, v9
	movi.2d	v9, #0000000000000000
	str	q9, [sp, #2080]                 ; 16-byte Spill
	str	q9, [sp, #2064]                 ; 16-byte Spill
	str	q9, [sp, #2048]                 ; 16-byte Spill
	str	q9, [sp, #8064]                 ; 16-byte Spill
	str	q9, [sp, #8048]                 ; 16-byte Spill
	str	q9, [sp, #8000]                 ; 16-byte Spill
	str	q19, [sp, #7872]                ; 16-byte Spill
	str	q9, [sp, #8016]                 ; 16-byte Spill
	str	q9, [sp, #7984]                 ; 16-byte Spill
	str	q9, [sp, #7968]                 ; 16-byte Spill
	str	q9, [sp, #7952]                 ; 16-byte Spill
	str	q9, [sp, #2032]                 ; 16-byte Spill
	str	q9, [sp, #2016]                 ; 16-byte Spill
	str	q9, [sp, #7936]                 ; 16-byte Spill
	str	q9, [sp, #7888]                 ; 16-byte Spill
	str	q9, [sp, #7920]                 ; 16-byte Spill
	str	q9, [sp, #7904]                 ; 16-byte Spill
	str	q9, [sp, #2000]                 ; 16-byte Spill
	str	q9, [sp, #1984]                 ; 16-byte Spill
	str	q9, [sp, #1968]                 ; 16-byte Spill
	str	q9, [sp, #1904]                 ; 16-byte Spill
	str	q9, [sp, #1952]                 ; 16-byte Spill
	str	q9, [sp, #1936]                 ; 16-byte Spill
	str	q9, [sp, #1888]                 ; 16-byte Spill
	str	q9, [sp, #1872]                 ; 16-byte Spill
	str	q6, [sp, #1856]                 ; 16-byte Spill
	str	q6, [sp, #1808]                 ; 16-byte Spill
	movi.2d	v25, #0000000000000000
	str	q25, [sp, #1840]                ; 16-byte Spill
	movi.2d	v23, #0000000000000000
	str	q23, [sp, #1824]                ; 16-byte Spill
	movi.2d	v22, #0000000000000000
	str	q22, [sp, #1760]                ; 16-byte Spill
	movi.2d	v24, #0000000000000000
	str	q24, [sp, #1792]                ; 16-byte Spill
	str	q22, [sp, #1776]                ; 16-byte Spill
	str	q24, [sp, #1744]                ; 16-byte Spill
	str	q24, [sp, #1728]                ; 16-byte Spill
	str	q24, [sp, #1680]                ; 16-byte Spill
	str	q24, [sp, #1712]                ; 16-byte Spill
	str	q24, [sp, #1696]                ; 16-byte Spill
	str	q24, [sp, #5152]                ; 16-byte Spill
	str	q24, [sp, #5136]                ; 16-byte Spill
	str	q24, [sp, #1664]                ; 16-byte Spill
	movi.2d	v4, #0000000000000000
	str	q24, [sp, #1648]                ; 16-byte Spill
	str	q6, [sp, #1632]                 ; 16-byte Spill
	movi.2d	v7, #0000000000000000
	str	q7, [sp, #1616]                 ; 16-byte Spill
	add	x11, sp, #10, lsl #12           ; =40960
	add	x11, x11, #1664
	str	x10, [sp, #104]                 ; 8-byte Spill
	add	x10, x11, x10
	str	x10, [sp, #88]                  ; 8-byte Spill
	and	x10, x9, #0x7
	str	x10, [sp, #720]                 ; 8-byte Spill
	ubfiz	x10, x9, #3, #3
Lloh36:
	adrp	x13, lCPI0_24@PAGE
Lloh37:
	ldr	q24, [x13, lCPI0_24@PAGEOFF]
	str	q24, [sp, #1600]                ; 16-byte Spill
Lloh38:
	ldr	q24, [x4, lCPI0_19@PAGEOFF]
	str	q24, [sp, #928]                 ; 16-byte Spill
Lloh39:
	ldr	q24, [x5, lCPI0_20@PAGEOFF]
	str	q24, [sp, #912]                 ; 16-byte Spill
Lloh40:
	ldr	q24, [x6, lCPI0_21@PAGEOFF]
	str	q24, [sp, #1584]                ; 16-byte Spill
Lloh41:
	ldr	q24, [x23, lCPI0_22@PAGEOFF]
	str	q24, [sp, #1568]                ; 16-byte Spill
Lloh42:
	ldr	q24, [x25, lCPI0_23@PAGEOFF]
	str	q24, [sp, #1552]                ; 16-byte Spill
Lloh43:
	adrp	x13, lCPI0_13@PAGE
Lloh44:
	ldr	q24, [x13, lCPI0_13@PAGEOFF]
	str	q24, [sp, #5296]                ; 16-byte Spill
Lloh45:
	ldr	q24, [x8, lCPI0_14@PAGEOFF]
	str	q24, [sp, #5280]                ; 16-byte Spill
Lloh46:
	ldr	q24, [x14, lCPI0_15@PAGEOFF]
	str	q24, [sp, #5264]                ; 16-byte Spill
Lloh47:
	ldr	q24, [x15, lCPI0_16@PAGEOFF]
	str	q24, [sp, #5248]                ; 16-byte Spill
Lloh48:
	ldr	q24, [x16, lCPI0_17@PAGEOFF]
	str	q24, [sp, #896]                 ; 16-byte Spill
Lloh49:
	ldr	q24, [x17, lCPI0_18@PAGEOFF]
	str	q24, [sp, #880]                 ; 16-byte Spill
	and	x8, x9, #0x7
	str	x8, [sp, #704]                  ; 8-byte Spill
	and	x8, x9, #0x7
	str	x8, [sp, #5768]                 ; 8-byte Spill
	movi.2d	v24, #0000000000000000
	str	q24, [sp, #1536]                ; 16-byte Spill
	ldr	q9, [sp, #11296]                ; 16-byte Reload
	and	x13, x9, #0x7
	and	x8, x9, #0x7
	str	x8, [sp, #5760]                 ; 8-byte Spill
	ubfiz	x16, x9, #3, #3
	and	x14, x9, #0x7
	ldr	x19, [sp, #10432]               ; 8-byte Reload
	str	q10, [sp, #11136]               ; 16-byte Spill
	str	q17, [sp, #10608]               ; 16-byte Spill
	stp	q21, q20, [sp, #304]            ; 32-byte Folded Spill
	str	x3, [sp, #1000]                 ; 8-byte Spill
	str	q30, [sp, #11216]               ; 16-byte Spill
	str	q31, [sp, #11184]               ; 16-byte Spill
	str	x10, [sp, #712]                 ; 8-byte Spill
	str	w1, [sp, #10420]                ; 4-byte Spill
	str	w7, [sp, #5372]                 ; 4-byte Spill
	str	w2, [sp, #5368]                 ; 4-byte Spill
	str	w20, [sp, #7836]                ; 4-byte Spill
	str	w0, [sp, #5324]                 ; 4-byte Spill
	str	x13, [sp, #5240]                ; 8-byte Spill
	str	x16, [sp, #696]                 ; 8-byte Spill
	str	x14, [sp, #688]                 ; 8-byte Spill
	b	LBB0_28
LBB0_26:                                ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #11424]                ; 16-byte Reload
	ldr	q5, [sp, #5152]                 ; 16-byte Reload
	ldr	q24, [sp, #5136]                ; 16-byte Reload
	ldr	q6, [sp, #1360]                 ; 16-byte Reload
	ldr	q26, [sp, #1616]                ; 16-byte Reload
	mov.16b	v28, v0
	ldr	q27, [sp, #11440]               ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q14, [sp, #11360]               ; 16-byte Reload
LBB0_27:                                ; %direct.false1035
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q28, [sp, #1536]                ; 16-byte Spill
	str	q26, [sp, #1616]                ; 16-byte Spill
	str	q24, [sp, #5136]                ; 16-byte Spill
	str	q5, [sp, #5152]                 ; 16-byte Spill
	ldr	q5, [sp, #1456]                 ; 16-byte Reload
	add.2d	v5, v5, v14
	ldr	q0, [sp, #1504]                 ; 16-byte Reload
	add.2d	v0, v0, v27
	ldr	q1, [sp, #1488]                 ; 16-byte Reload
	add.2d	v1, v1, v9
	ldr	q3, [sp, #1472]                 ; 16-byte Reload
	add.2d	v2, v3, v2
	fmov	x8, d2
	cmp	x8, #2
	ldr	q10, [sp, #11136]               ; 16-byte Reload
	ldr	q11, [sp, #10352]               ; 16-byte Reload
	ldr	q8, [sp, #10320]                ; 16-byte Reload
	ldr	q3, [sp, #5744]                 ; 16-byte Reload
	ldr	q15, [sp, #5120]                ; 16-byte Reload
	ldr	q13, [sp, #5104]                ; 16-byte Reload
	ldr	q26, [sp, #5088]                ; 16-byte Reload
	ldr	q28, [sp, #5072]                ; 16-byte Reload
	ldr	q12, [sp, #5056]                ; 16-byte Reload
	mov.16b	v9, v17
	ldr	q17, [sp, #10608]               ; 16-byte Reload
	b.ge	LBB0_348
LBB0_28:                                ; %direct.true368
                                        ; =>This Loop Header: Depth=1
                                        ;     Child Loop BB0_31 Depth 2
                                        ;     Child Loop BB0_51 Depth 2
                                        ;     Child Loop BB0_72 Depth 2
                                        ;       Child Loop BB0_74 Depth 3
                                        ;     Child Loop BB0_78 Depth 2
                                        ;     Child Loop BB0_81 Depth 2
                                        ;     Child Loop BB0_85 Depth 2
                                        ;     Child Loop BB0_90 Depth 2
                                        ;     Child Loop BB0_109 Depth 2
                                        ;     Child Loop BB0_113 Depth 2
                                        ;     Child Loop BB0_118 Depth 2
                                        ;     Child Loop BB0_122 Depth 2
                                        ;     Child Loop BB0_126 Depth 2
                                        ;     Child Loop BB0_130 Depth 2
                                        ;     Child Loop BB0_134 Depth 2
                                        ;     Child Loop BB0_154 Depth 2
                                        ;     Child Loop BB0_206 Depth 2
                                        ;     Child Loop BB0_226 Depth 2
                                        ;       Child Loop BB0_227 Depth 3
                                        ;     Child Loop BB0_235 Depth 2
                                        ;     Child Loop BB0_252 Depth 2
                                        ;     Child Loop BB0_256 Depth 2
                                        ;     Child Loop BB0_259 Depth 2
                                        ;     Child Loop BB0_263 Depth 2
                                        ;     Child Loop BB0_268 Depth 2
                                        ;     Child Loop BB0_288 Depth 2
                                        ;     Child Loop BB0_292 Depth 2
                                        ;       Child Loop BB0_293 Depth 3
                                        ;     Child Loop BB0_315 Depth 2
                                        ;     Child Loop BB0_299 Depth 2
                                        ;     Child Loop BB0_305 Depth 2
                                        ;       Child Loop BB0_307 Depth 3
                                        ;     Child Loop BB0_310 Depth 2
                                        ;     Child Loop BB0_332 Depth 2
                                        ;     Child Loop BB0_335 Depth 2
                                        ;     Child Loop BB0_340 Depth 2
                                        ;     Child Loop BB0_344 Depth 2
                                        ;     Child Loop BB0_347 Depth 2
	str	q4, [sp, #1376]                 ; 16-byte Spill
	str	q7, [sp, #1344]                 ; 16-byte Spill
	str	q6, [sp, #1360]                 ; 16-byte Spill
	str	q22, [sp, #1392]                ; 16-byte Spill
	str	q23, [sp, #1408]                ; 16-byte Spill
	str	q25, [sp, #1424]                ; 16-byte Spill
	str	q19, [sp, #1440]                ; 16-byte Spill
	str	q12, [sp, #5056]                ; 16-byte Spill
	str	q28, [sp, #5072]                ; 16-byte Spill
	str	q26, [sp, #5088]                ; 16-byte Spill
	str	q13, [sp, #5104]                ; 16-byte Spill
	str	q15, [sp, #5120]                ; 16-byte Spill
	str	q3, [sp, #5744]                 ; 16-byte Spill
	str	q29, [sp, #7408]                ; 16-byte Spill
	str	q18, [sp, #5376]                ; 16-byte Spill
	str	q16, [sp, #5392]                ; 16-byte Spill
	str	q5, [sp, #1456]                 ; 16-byte Spill
	mov.16b	v3, v0
	sshll.2d	v0, v31, #0
	mov.16b	v4, v2
	mov.16b	v2, v1
	sshll.2d	v1, v30, #0
	fmov	x8, d2
	add	x8, x8, x8, lsl #6
	str	q2, [sp, #1488]                 ; 16-byte Spill
	mov.d	x13, v2[1]
	fmov	d2, x8
	add	x8, x13, x13, lsl #6
	mov.d	v2[1], x8
	fmov	x8, d3
	add	x8, x8, x8, lsl #6
	fmov	x13, d5
	add	x13, x13, x13, lsl #6
	fmov	x14, d4
	add	x14, x14, x14, lsl #6
	str	q4, [sp, #1472]                 ; 16-byte Spill
	mov.d	x15, v4[1]
	fmov	d4, x14
	add	x14, x15, x15, lsl #6
	mov.d	v4[1], x14
	bit.16b	v11, v4, v1
	fmov	d4, x13
	mov.d	x13, v5[1]
	add	x13, x13, x13, lsl #6
	mov.d	v4[1], x13
	ldr	q6, [sp, #11344]                ; 16-byte Reload
	bit.16b	v8, v4, v6
	fmov	d4, x8
	str	q3, [sp, #1504]                 ; 16-byte Spill
	mov.d	x8, v3[1]
	add	x8, x8, x8, lsl #6
	mov.d	v4[1], x8
	ldr	q3, [sp, #10336]                ; 16-byte Reload
	bit.16b	v3, v4, v0
	ldr	q5, [sp, #11328]                ; 16-byte Reload
	ldr	q14, [sp, #9856]                ; 16-byte Reload
	bit.16b	v14, v2, v5
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q4, [sp, #7760]                 ; 16-byte Reload
	bit.16b	v4, v2, v5
	str	q4, [sp, #7760]                 ; 16-byte Spill
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q4, [sp, #7792]                 ; 16-byte Reload
	bit.16b	v4, v2, v6
	str	q4, [sp, #7792]                 ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q4, [sp, #7776]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #7776]                 ; 16-byte Spill
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q4, [sp, #7808]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #7808]                 ; 16-byte Spill
	ldr	q20, [sp, #4416]                ; 16-byte Reload
	bic.16b	v20, v20, v5
	ldr	q7, [sp, #4384]                 ; 16-byte Reload
	bic.16b	v7, v7, v6
	ldr	q5, [sp, #4432]                 ; 16-byte Reload
	bic.16b	v5, v5, v0
	ldr	q6, [sp, #4400]                 ; 16-byte Reload
	bic.16b	v6, v6, v1
	fmov	x8, d6
	ldr	q0, [sp, #1200]                 ; 16-byte Reload
	str	q11, [sp, #10352]               ; 16-byte Spill
	add.2d	v0, v11, v0
	str	q0, [sp, #10720]                ; 16-byte Spill
	ldr	q0, [sp, #1184]                 ; 16-byte Reload
	str	q8, [sp, #10320]                ; 16-byte Spill
	add.2d	v0, v8, v0
	str	q0, [sp, #10704]                ; 16-byte Spill
	ldr	q0, [sp, #1168]                 ; 16-byte Reload
	str	q3, [sp, #10336]                ; 16-byte Spill
	add.2d	v0, v3, v0
	str	q0, [sp, #10688]                ; 16-byte Spill
	mov.d	x9, v10[1]
	str	x9, [sp, #10464]                ; 8-byte Spill
	mov.d	x9, v17[1]
	str	x9, [sp, #10440]                ; 8-byte Spill
	ldr	q0, [sp, #1152]                 ; 16-byte Reload
	add.2d	v0, v14, v0
	str	q0, [sp, #10672]                ; 16-byte Spill
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	mov.d	x22, v0[1]
	mov.d	x9, v9[1]
	str	x9, [sp, #10448]                ; 8-byte Spill
	cmp	x8, #296
	b.gt	LBB0_47
; %bb.29:                               ; %direct.true372.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov.16b	v22, v10
	ldr	d19, [sp, #11400]               ; 8-byte Reload
	mov	w12, #65                        ; =0x41
	ldr	q12, [sp, #11200]               ; 16-byte Reload
	add	x14, sp, #7, lsl #12            ; =28672
	add	x14, x14, #1632
	add	x1, sp, #5, lsl #12             ; =20480
	add	x1, x1, #1840
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #1904
	ldr	q11, [sp, #11232]               ; 16-byte Reload
	ldr	q26, [sp, #864]                 ; 16-byte Reload
	ldr	q28, [sp, #11264]               ; 16-byte Reload
	b	LBB0_31
LBB0_30:                                ; %else460
                                        ;   in Loop: Header=BB0_31 Depth=2
	dup.2d	v1, x9
	cmgt.2d	v2, v1, v23
	cmgt.2d	v4, v1, v6
	uzp1.4s	v2, v4, v2
	cmgt.2d	v4, v1, v21
	cmgt.2d	v1, v1, v22
	uzp1.4s	v1, v4, v1
	uzp1.8h	v4, v2, v1
	zip2.8b	v5, v29, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q3, [sp, #8928]                 ; 16-byte Reload
	bsl.16b	v5, v9, v3
	zip1.8b	v6, v29, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmlt.4s	v6, v6, #0
	ldr	q3, [sp, #8944]                 ; 16-byte Reload
	bsl.16b	v6, v7, v3
	zip1.8b	v7, v0, v0
	ushll.4s	v7, v7, #0
	shl.4s	v7, v7, #31
	cmge.4s	v7, v7, #0
	and.16b	v3, v7, v6
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v17, v0, v5
	and.16b	v0, v10, v4
	xtn.8b	v0, v0
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	and.8b	v4, v0, v19
	addv.8b	b4, v4
	fmov	w8, s4
	and.16b	v2, v30, v2
	and.16b	v1, v31, v1
	umaxv.8b	b0, v0
	fmov	w9, s0
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	ldr	q0, [sp, #7808]                 ; 16-byte Reload
	str	q0, [sp, #23488]
	ldr	q0, [sp, #7792]                 ; 16-byte Reload
	str	q0, [sp, #23504]
	ldr	q0, [sp, #7776]                 ; 16-byte Reload
	str	q0, [sp, #23520]
	ldr	q0, [sp, #7760]                 ; 16-byte Reload
	str	q0, [sp, #23536]
	ubfiz	x10, x9, #3, #3
	add	x11, sp, #5, lsl #12            ; =20480
	add	x11, x11, #3008
	ldr	x11, [x11, x10]
	str	q18, [sp, #23424]
	str	q16, [sp, #23440]
	str	q25, [sp, #23456]
	str	q15, [sp, #23472]
	add	x12, sp, #5, lsl #12            ; =20480
	add	x12, x12, #2944
	ldr	x10, [x12, x10]
	lsl	w9, w9, #2
	sub	x9, x11, x9
	add	x9, x9, x10, lsl #5
	tst	w8, #0xff
	csel	x8, xzr, x9, eq
	add	x8, x13, x8
	ldp	q0, q4, [x8]
	str	q17, [sp, #8928]                ; 16-byte Spill
	bsl.16b	v1, v17, v4
	str	q3, [sp, #8944]                 ; 16-byte Spill
	bit.16b	v0, v3, v2
	stp	q0, q1, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v7, v16, v0
	ldr	q13, [sp, #11440]               ; 16-byte Reload
	add.2d	v5, v25, v13
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v20, v15, v0
	add.2d	v6, v18, v24
	fmov	x8, d6
	cmp	x8, #297
	mov	w12, #65                        ; =0x41
	ldr	q12, [sp, #11200]               ; 16-byte Reload
	mov.16b	v22, v27
	b.ge	LBB0_48
LBB0_31:                                ; %direct.true372
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v30, #0
	sshll.2d	v0, v31, #0
	mov.16b	v18, v6
	and.16b	v1, v2, v6
	fmov	x8, d1
	ldr	q3, [sp, #6608]                 ; 16-byte Reload
	fmov	x13, d3
	sdiv	x8, x8, x13
	mov.d	x17, v1[1]
	mul	x30, x8, x13
	fmov	d4, x8
	mov.d	x9, v3[1]
	sdiv	x10, x17, x9
	mov.d	v4[1], x10
	ldr	q21, [sp, #11344]               ; 16-byte Reload
	mov.16b	v16, v7
	and.16b	v10, v21, v7
	fmov	x8, d10
	ldr	q3, [sp, #6640]                 ; 16-byte Reload
	fmov	x3, d3
	sdiv	x24, x8, x3
	mov.d	x8, v10[1]
	fmov	d6, x24
	mov.d	x28, v3[1]
	sdiv	x13, x8, x28
	mov.d	v6[1], x13
	mov.16b	v25, v5
	and.16b	v8, v0, v5
	fmov	x8, d8
	ldr	q3, [sp, #6624]                 ; 16-byte Reload
	fmov	x23, d3
	sdiv	x27, x8, x23
	mov.d	x8, v8[1]
	fmov	d17, x27
	mov.d	x17, v3[1]
	sdiv	x8, x8, x17
	mov.d	v17[1], x8
	mov.16b	v15, v20
	ldr	q3, [sp, #11328]                ; 16-byte Reload
	and.16b	v5, v3, v20
	fmov	x6, d5
	fmov	x5, d26
	sdiv	x6, x6, x5
	mov.d	x26, v5[1]
	fmov	d20, x6
	mov.d	x25, v26[1]
	sdiv	x26, x26, x25
	mov.d	v20[1], x26
	mul	x9, x10, x9
	fmov	d7, x30
	mov.d	v7[1], x9
	sub.2d	v7, v1, v7
	and.16b	v1, v3, v20
	and.16b	v2, v2, v4
	mov.d	x9, v2[1]
	ldr	x11, [sp, #10464]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d2
	mov.16b	v27, v22
	fmov	x30, d22
	sdiv	x11, x10, x30
	msub	x10, x11, x30, x10
	fmov	d2, x10
	mov.d	v2[1], x9
	and.16b	v4, v21, v6
	mov.d	x9, v4[1]
	ldr	x11, [sp, #10440]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d4
	ldr	q3, [sp, #10608]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x30, x10, x11
	msub	x10, x30, x11, x10
	fmov	d4, x10
	mov.d	v4[1], x9
	and.16b	v0, v0, v17
	mov.d	x9, v0[1]
	sdiv	x10, x9, x22
	msub	x9, x10, x22, x9
	fmov	x10, d0
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x30, x10, x11
	msub	x10, x30, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	mov.d	x9, v1[1]
	ldr	x11, [sp, #10448]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d1
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x30, x10, x11
	msub	x10, x30, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	shl.2d	v1, v1, #3
	shl.2d	v0, v0, #3
	shl.2d	v4, v4, #3
	shl.2d	v2, v2, #3
	orr.16b	v6, v2, v28
	orr.16b	v23, v4, v12
	orr.16b	v21, v0, v11
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	orr.16b	v22, v1, v0
	dup.2d	v0, x12
	cmgt.2d	v1, v0, v22
	cmgt.2d	v4, v0, v21
	uzp1.4s	v2, v4, v1
	cmgt.2d	v17, v0, v23
	cmgt.2d	v20, v0, v6
	uzp1.4s	v0, v20, v17
	uzp1.8h	v28, v0, v2
	mov	w9, #64                         ; =0x40
	dup.2d	v29, x9
	mov.16b	v2, v1
	bsl.16b	v2, v22, v29
	mov.16b	v0, v4
	bsl.16b	v0, v21, v29
	bsl.16b	v17, v23, v29
	mov.16b	v1, v20
	bsl.16b	v1, v6, v29
	ldr	q3, [sp, #10352]                ; 16-byte Reload
	add.2d	v4, v1, v3
	ldr	q3, [sp, #10336]                ; 16-byte Reload
	add.2d	v20, v0, v3
	add.2d	v29, v2, v14
	mov	w9, #67                         ; =0x43
	dup.2d	v9, x9
	cmhi.2d	v29, v9, v29
	cmhi.2d	v20, v9, v20
	uzp1.4s	v20, v20, v29
	ldr	q3, [sp, #10320]                ; 16-byte Reload
	add.2d	v29, v17, v3
	cmhi.2d	v29, v9, v29
	cmhi.2d	v4, v9, v4
	ldr	q3, [sp, #10720]                ; 16-byte Reload
	add.2d	v1, v1, v3
	uzp1.4s	v4, v4, v29
	uzp1.8h	v4, v4, v20
	mov.d	x9, v1[1]
	fmov	x10, d1
	add	x10, x10, x10, lsl #5
	fmov	d1, x10
	add	x9, x9, x9, lsl #5
	mov.d	v1[1], x9
	add.2d	v1, v1, v7
	and.16b	v4, v28, v4
	xtn.8b	v20, v4
	ldr	q3, [sp, #11280]                ; 16-byte Reload
	and.8b	v29, v3, v20
	shl.8b	v4, v29, #7
	cmlt.8b	v4, v4, #0
	and.8b	v4, v4, v19
	addv.8b	b4, v4
	fmov	w30, s4
	shl.2d	v1, v1, #2
	mov	b4, v29[0]
	mov.b	v4[4], v29[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v1, v4, v1
	ldr	x9, [sp, #6664]                 ; 8-byte Reload
	dup.2d	v28, x9
	add.2d	v1, v28, v1
	movi.2d	v7, #0000000000000000
	movi.2d	v9, #0000000000000000
	tbz	w30, #0, LBB0_33
; %bb.32:                               ; %cond.load414
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x9, d1
	ldr	s7, [x9]
LBB0_33:                                ; %else418
                                        ;   in Loop: Header=BB0_31 Depth=2
	tbz	w30, #1, LBB0_35
; %bb.34:                               ; %cond.load420
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[1], [x9]
LBB0_35:                                ; %else424
                                        ;   in Loop: Header=BB0_31 Depth=2
	mul	x9, x13, x28
	mul	x10, x24, x3
	fmov	d1, x10
	mov.d	v1[1], x9
	sub.2d	v1, v10, v1
	ldr	q3, [sp, #10704]                ; 16-byte Reload
	add.2d	v4, v17, v3
	mov.d	x9, v4[1]
	fmov	x10, d4
	add	x10, x10, x10, lsl #5
	fmov	d4, x10
	add	x9, x9, x9, lsl #5
	mov.d	v4[1], x9
	add.2d	v1, v4, v1
	mov	b4, v29[2]
	mov.b	v4[4], v29[3]
	shl.2d	v1, v1, #2
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v1, v4, v1
	add.2d	v1, v28, v1
	tbz	w30, #2, LBB0_37
; %bb.36:                               ; %cond.load426
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x9, d1
	ld1.s	{ v7 }[2], [x9]
LBB0_37:                                ; %else430
                                        ;   in Loop: Header=BB0_31 Depth=2
	ldr	q3, [sp, #11280]                ; 16-byte Reload
	ldr	q10, [sp, #11376]               ; 16-byte Reload
	tbz	w30, #3, LBB0_39
; %bb.38:                               ; %cond.load432
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v7 }[3], [x9]
LBB0_39:                                ; %else436
                                        ;   in Loop: Header=BB0_31 Depth=2
	mul	x8, x8, x17
	mul	x9, x27, x23
	fmov	d1, x9
	mov.d	v1[1], x8
	sub.2d	v1, v8, v1
	ldr	q4, [sp, #10688]                ; 16-byte Reload
	add.2d	v0, v0, v4
	mov.d	x8, v0[1]
	fmov	x9, d0
	add	x9, x9, x9, lsl #5
	fmov	d0, x9
	add	x8, x8, x8, lsl #5
	mov.d	v0[1], x8
	add.2d	v0, v0, v1
	mov	b1, v29[4]
	mov.b	v1[4], v29[5]
	shl.2d	v0, v0, #2
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v0, v1, v0
	add.2d	v0, v28, v0
	tbz	w30, #4, LBB0_41
; %bb.40:                               ; %cond.load438
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x8, d0
	ld1.s	{ v9 }[0], [x8]
LBB0_41:                                ; %else442
                                        ;   in Loop: Header=BB0_31 Depth=2
	ldr	q24, [sp, #11424]               ; 16-byte Reload
	ldr	x19, [sp, #10432]               ; 8-byte Reload
	add	x27, sp, #5, lsl #12            ; =20480
	add	x27, x27, #1776
	tbz	w30, #5, LBB0_43
; %bb.42:                               ; %cond.load444
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov.d	x8, v0[1]
	ld1.s	{ v9 }[1], [x8]
LBB0_43:                                ; %else448
                                        ;   in Loop: Header=BB0_31 Depth=2
	mul	x8, x26, x25
	mul	x9, x6, x5
	fmov	d0, x9
	mov.d	v0[1], x8
	sub.2d	v0, v5, v0
	ldr	q1, [sp, #10672]                ; 16-byte Reload
	add.2d	v1, v2, v1
	mov.d	x8, v1[1]
	fmov	x9, d1
	add	x9, x9, x9, lsl #5
	fmov	d1, x9
	add	x8, x8, x8, lsl #5
	mov.d	v1[1], x8
	add.2d	v0, v1, v0
	mov	b1, v29[6]
	mov.b	v1[4], v29[7]
	shl.2d	v0, v0, #2
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v0, v1, v0
	add.2d	v1, v28, v0
	tbz	w30, #6, LBB0_45
; %bb.44:                               ; %cond.load450
                                        ;   in Loop: Header=BB0_31 Depth=2
	fmov	x8, d1
	ld1.s	{ v9 }[2], [x8]
LBB0_45:                                ; %else454
                                        ;   in Loop: Header=BB0_31 Depth=2
	ldr	q28, [sp, #11264]               ; 16-byte Reload
	mov	w9, #65                         ; =0x41
	add	x13, sp, #8, lsl #12            ; =32768
	add	x13, x13, #192
	add	x16, sp, #7, lsl #12            ; =28672
	add	x16, x16, #2208
	bic.8b	v0, v3, v20
	tbz	w30, #7, LBB0_30
; %bb.46:                               ; %cond.load456
                                        ;   in Loop: Header=BB0_31 Depth=2
	mov.d	x8, v1[1]
	ld1.s	{ v9 }[3], [x8]
	b	LBB0_30
LBB0_47:                                ;   in Loop: Header=BB0_28 Depth=1
	ldr	q12, [sp, #11200]               ; 16-byte Reload
	add	x14, sp, #7, lsl #12            ; =28672
	add	x14, x14, #1632
	add	x27, sp, #5, lsl #12            ; =20480
	add	x27, x27, #1776
	add	x1, sp, #5, lsl #12             ; =20480
	add	x1, x1, #1840
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #1904
	ldr	q11, [sp, #11232]               ; 16-byte Reload
	ldr	q13, [sp, #11440]               ; 16-byte Reload
	add	x16, sp, #7, lsl #12            ; =28672
	add	x16, x16, #2208
	ldr	q28, [sp, #11264]               ; 16-byte Reload
LBB0_48:                                ; %direct.false373
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q7, [sp, #4384]                 ; 16-byte Spill
	str	q6, [sp, #4400]                 ; 16-byte Spill
	str	q20, [sp, #4416]                ; 16-byte Spill
	str	q5, [sp, #4432]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q4, [sp, #4928]                 ; 16-byte Reload
	ldr	q23, [sp, #11328]               ; 16-byte Reload
	bit.16b	v4, v2, v23
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q6, [sp, #4896]                 ; 16-byte Reload
	ldr	q7, [sp, #11344]                ; 16-byte Reload
	bit.16b	v6, v2, v7
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q3, [sp, #4944]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q5, [sp, #4912]                 ; 16-byte Reload
	bif.16b	v2, v5, v0
	ldr	q8, [sp, #4320]                 ; 16-byte Reload
	bic.16b	v8, v8, v23
	ldr	q18, [sp, #4352]                ; 16-byte Reload
	bic.16b	v18, v18, v7
	ldr	q25, [sp, #4336]                ; 16-byte Reload
	bic.16b	v25, v25, v1
	ldr	q16, [sp, #4368]                ; 16-byte Reload
	bic.16b	v16, v16, v0
	fmov	x8, d16
	cmp	x8, #64
	ldr	q26, [sp, #4272]                ; 16-byte Reload
	ldr	q9, [sp, #10352]                ; 16-byte Reload
	str	q3, [sp, #4944]                 ; 16-byte Spill
	str	q4, [sp, #4928]                 ; 16-byte Spill
	str	q2, [sp, #4912]                 ; 16-byte Spill
	str	q6, [sp, #4896]                 ; 16-byte Spill
	b.gt	LBB0_67
; %bb.49:                               ; %direct.true387.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q2, [sp, #23360]
	str	q6, [sp, #23376]
	str	q3, [sp, #23392]
	str	q4, [sp, #23408]
	ldr	x8, [sp, #728]                  ; 8-byte Reload
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #2880
	ldr	x8, [x9, x8, lsl #3]
	ldr	x9, [sp, #6824]                 ; 8-byte Reload
	sub	x5, x8, x9
	ldr	q19, [sp, #10544]               ; 16-byte Reload
	ldr	q24, [sp, #10560]               ; 16-byte Reload
	ldr	x28, [sp, #9896]                ; 8-byte Reload
	ldr	x30, [sp, #9888]                ; 8-byte Reload
	ldr	x12, [sp, #7672]                ; 8-byte Reload
	ldr	q29, [sp, #10320]               ; 16-byte Reload
	ldr	q3, [sp, #10336]                ; 16-byte Reload
	ldr	q15, [sp, #4304]                ; 16-byte Reload
	ldr	q22, [sp, #9840]                ; 16-byte Reload
	ldr	q10, [sp, #11280]               ; 16-byte Reload
	ldr	x15, [sp, #10464]               ; 8-byte Reload
	ldr	x2, [sp, #10448]                ; 8-byte Reload
	b	LBB0_51
LBB0_50:                                ; %else509
                                        ;   in Loop: Header=BB0_51 Depth=2
	ldr	q0, [sp, #6592]                 ; 16-byte Reload
	and.8b	v0, v0, v5
	bic.8b	v0, v10, v0
	zip2.8b	v1, v6, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bsl.16b	v1, v20, v26
	zip1.8b	v4, v6, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	bif.16b	v2, v15, v4
	zip1.8b	v4, v0, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v4, v4, #0
	and.16b	v15, v4, v2
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	and.16b	v26, v0, v1
	str	q16, [sp, #23296]
	str	q18, [sp, #23312]
	str	q25, [sp, #23328]
	str	q8, [sp, #23344]
	ldr	x8, [sp, #5944]                 ; 8-byte Reload
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #2816
	ldr	x8, [x9, x8, lsl #3]
	add	x8, x5, x8, lsl #5
	ldr	w9, [sp, #7132]                 ; 4-byte Reload
	tst	w9, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x16, x8
	ldp	q0, q1, [x8]
	ldr	q2, [sp, #6496]                 ; 16-byte Reload
	bit.16b	v1, v26, v2
	ldr	q2, [sp, #6480]                 ; 16-byte Reload
	bit.16b	v0, v15, v2
	stp	q0, q1, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v18, v18, v0
	add.2d	v25, v25, v13
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v8, v8, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v16, v16, v0
	fmov	x8, d16
	cmp	x8, #65
	b.ge	LBB0_68
LBB0_51:                                ; %direct.true387
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v31, #0
	sshll.2d	v1, v30, #0
	and.16b	v1, v1, v16
	ldr	q2, [sp, #11344]                ; 16-byte Reload
	and.16b	v2, v2, v18
	and.16b	v4, v23, v8
	mov.d	x8, v4[1]
	and.16b	v0, v0, v25
	fmov	x9, d4
	ldr	q4, [sp, #6560]                 ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	mov.d	x13, v4[1]
	msub	x9, x11, x10, x9
	sdiv	x10, x8, x13
	msub	x8, x10, x13, x8
	mov.d	x10, v0[1]
	fmov	x11, d0
	ldr	q0, [sp, #6528]                 ; 16-byte Reload
	fmov	x13, d0
	sdiv	x17, x11, x13
	msub	x11, x17, x13, x11
	mov.d	x13, v0[1]
	sdiv	x17, x10, x13
	msub	x10, x17, x13, x10
	mov.d	x13, v2[1]
	fmov	x17, d2
	ldr	q0, [sp, #6544]                 ; 16-byte Reload
	fmov	x3, d0
	sdiv	x6, x17, x3
	msub	x17, x6, x3, x17
	mov.d	x3, v0[1]
	sdiv	x6, x13, x3
	mov.d	x23, v1[1]
	msub	x13, x6, x3, x13
	fmov	x3, d1
	ldr	q2, [sp, #6512]                 ; 16-byte Reload
	fmov	x6, d2
	sdiv	x24, x3, x6
	msub	x3, x24, x6, x3
	fmov	d7, x9
	mov.d	v7[1], x8
	fmov	d0, x11
	mov.d	v0[1], x10
	fmov	d17, x17
	mov.d	v17[1], x13
	fmov	d1, x3
	mov.d	x8, v2[1]
	sdiv	x9, x23, x8
	msub	x8, x9, x8, x23
	mov.d	v1[1], x8
	add.2d	v2, v1, v9
	add.2d	v4, v17, v29
	add.2d	v5, v0, v3
	add.2d	v6, v7, v14
	ldr	q20, [sp, #10720]               ; 16-byte Reload
	add.2d	v1, v1, v20
	mov	w8, #67                         ; =0x43
	dup.2d	v20, x8
	cmhi.2d	v6, v20, v6
	cmhi.2d	v5, v20, v5
	uzp1.4s	v5, v5, v6
	cmhi.2d	v4, v20, v4
	cmhi.2d	v2, v20, v2
	uzp1.4s	v2, v2, v4
	uzp1.8h	v2, v2, v5
	xtn.8b	v5, v2
	mov.d	x8, v1[1]
	lsl	x9, x8, #3
	sub	x8, x9, x8
	fmov	x9, d1
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	d1, x9
	mov.d	v1[1], x8
	add.2d	v1, v1, v28
	ldr	q2, [sp, #6672]                 ; 16-byte Reload
	and.8b	v6, v5, v2
	shl.8b	v2, v6, #7
	cmlt.8b	v2, v2, #0
	ldr	d4, [sp, #11400]                ; 8-byte Reload
	and.8b	v2, v2, v4
	addv.8b	b2, v2
	fmov	w8, s2
	shl.2d	v1, v1, #2
	mov	b2, v6[0]
	mov.b	v2[4], v6[1]
	ushll.2d	v2, v2, #0
	shl.2d	v2, v2, #63
	cmlt.2d	v2, v2, #0
	and.16b	v1, v2, v1
	ldr	x9, [sp, #6656]                 ; 8-byte Reload
	dup.2d	v21, x9
	add.2d	v1, v21, v1
	movi.2d	v2, #0000000000000000
	movi.2d	v20, #0000000000000000
	tbz	w8, #0, LBB0_53
; %bb.52:                               ; %cond.load463
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x9, d1
	ldr	s2, [x9]
LBB0_53:                                ; %else467
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbz	w8, #1, LBB0_55
; %bb.54:                               ; %cond.load469
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_55:                                ; %else473
                                        ;   in Loop: Header=BB0_51 Depth=2
	ldr	q1, [sp, #10704]                ; 16-byte Reload
	add.2d	v1, v17, v1
	mov.d	x9, v1[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d1
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	add.2d	v1, v1, v12
	mov	b4, v6[2]
	mov.b	v4[4], v6[3]
	shl.2d	v1, v1, #2
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	and.16b	v1, v4, v1
	add.2d	v1, v21, v1
	tbz	w8, #2, LBB0_57
; %bb.56:                               ; %cond.load475
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x9, d1
	ld1.s	{ v2 }[2], [x9]
LBB0_57:                                ; %else479
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbz	w8, #3, LBB0_59
; %bb.58:                               ; %cond.load481
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v2 }[3], [x9]
LBB0_59:                                ; %else485
                                        ;   in Loop: Header=BB0_51 Depth=2
	ldr	q1, [sp, #10688]                ; 16-byte Reload
	add.2d	v0, v0, v1
	mov.d	x9, v0[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d0
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	add.2d	v0, v0, v11
	mov	b1, v6[4]
	mov.b	v1[4], v6[5]
	shl.2d	v0, v0, #2
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v0, v1, v0
	add.2d	v0, v21, v0
	tbz	w8, #4, LBB0_61
; %bb.60:                               ; %cond.load487
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x9, d0
	ld1.s	{ v20 }[0], [x9]
LBB0_61:                                ; %else491
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbz	w8, #5, LBB0_63
; %bb.62:                               ; %cond.load493
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x9, v0[1]
	ld1.s	{ v20 }[1], [x9]
LBB0_63:                                ; %else497
                                        ;   in Loop: Header=BB0_51 Depth=2
	ldr	q0, [sp, #10672]                ; 16-byte Reload
	add.2d	v0, v7, v0
	mov.d	x9, v0[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d0
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	ldr	q1, [sp, #6576]                 ; 16-byte Reload
	add.2d	v0, v0, v1
	mov	b1, v6[6]
	mov.b	v1[4], v6[7]
	shl.2d	v0, v0, #2
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	and.16b	v0, v1, v0
	add.2d	v0, v21, v0
	tbz	w8, #6, LBB0_65
; %bb.64:                               ; %cond.load499
                                        ;   in Loop: Header=BB0_51 Depth=2
	fmov	x9, d0
	ld1.s	{ v20 }[2], [x9]
LBB0_65:                                ; %else503
                                        ;   in Loop: Header=BB0_51 Depth=2
	tbz	w8, #7, LBB0_50
; %bb.66:                               ; %cond.load505
                                        ;   in Loop: Header=BB0_51 Depth=2
	mov.d	x8, v0[1]
	ld1.s	{ v20 }[3], [x8]
	b	LBB0_50
LBB0_67:                                ;   in Loop: Header=BB0_28 Depth=1
	ldr	x28, [sp, #9896]                ; 8-byte Reload
	ldr	x30, [sp, #9888]                ; 8-byte Reload
	ldr	x12, [sp, #7672]                ; 8-byte Reload
	ldr	q15, [sp, #4304]                ; 16-byte Reload
	ldr	q22, [sp, #9840]                ; 16-byte Reload
	ldr	q10, [sp, #11280]               ; 16-byte Reload
	ldr	x15, [sp, #10464]               ; 8-byte Reload
	ldr	x2, [sp, #10448]                ; 8-byte Reload
LBB0_68:                                ; %direct.false388
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q15, [sp, #4304]                ; 16-byte Spill
	str	q8, [sp, #4320]                 ; 16-byte Spill
	str	q25, [sp, #4336]                ; 16-byte Spill
	str	q18, [sp, #4352]                ; 16-byte Spill
	str	q16, [sp, #4368]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q12, [sp, #5328]                ; 16-byte Reload
	bit.16b	v12, v2, v23
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q5, [sp, #5392]                 ; 16-byte Reload
	ldr	q19, [sp, #11344]               ; 16-byte Reload
	bit.16b	v5, v2, v19
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q3, [sp, #5376]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q4, [sp, #5344]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	ldr	q15, [sp, #7024]                ; 16-byte Reload
	bic.16b	v15, v15, v23
	ldr	q29, [sp, #7056]                ; 16-byte Reload
	bic.16b	v29, v29, v19
	ldr	q8, [sp, #7040]                 ; 16-byte Reload
	bic.16b	v8, v8, v1
	ldr	q21, [sp, #7072]                ; 16-byte Reload
	bic.16b	v21, v21, v0
	fmov	x8, d21
	cmp	x8, #17
	str	q14, [sp, #9856]                ; 16-byte Spill
	mov.16b	v9, v4
	str	q4, [sp, #5344]                 ; 16-byte Spill
	mov.16b	v27, v5
	str	q5, [sp, #5392]                 ; 16-byte Spill
	str	q3, [sp, #5376]                 ; 16-byte Spill
	str	q12, [sp, #5328]                ; 16-byte Spill
	str	x22, [sp, #5360]                ; 8-byte Spill
	str	q26, [sp, #4272]                ; 16-byte Spill
	b.gt	LBB0_76
; %bb.69:                               ; %direct.true402.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q17, [sp, #7104]                ; 16-byte Reload
	ldr	q20, [sp, #7088]                ; 16-byte Reload
	ldr	q28, [sp, #10768]               ; 16-byte Reload
	ldr	q30, [sp, #10752]               ; 16-byte Reload
	ldr	q25, [sp, #4288]                ; 16-byte Reload
	ldr	q18, [sp, #4256]                ; 16-byte Reload
	ldr	q16, [sp, #11312]               ; 16-byte Reload
	ldr	q26, [sp, #11296]               ; 16-byte Reload
	b	LBB0_72
LBB0_70:                                ; %direct.true402.direct.false409_crit_edge
                                        ;   in Loop: Header=BB0_72 Depth=2
	str	q6, [sp, #8864]                 ; 16-byte Spill
	str	q5, [sp, #8880]                 ; 16-byte Spill
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #11400]                ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w6, s0
	rbit	w8, w6
	clz	w8, w8
	mov.16b	v4, v13
	mov.16b	v26, v24
	mov.16b	v0, v3
	mov.16b	v1, v9
	mov.16b	v2, v12
	mov.16b	v3, v27
	mov.16b	v16, v14
LBB0_71:                                ; %direct.false409
                                        ;   in Loop: Header=BB0_72 Depth=2
	tst	w6, #0xff
	csel	w8, wzr, w8, eq
	mov.16b	v9, v1
	str	q1, [sp, #22576]
	mov.16b	v27, v3
	str	q3, [sp, #22592]
	mov.16b	v3, v0
	str	q0, [sp, #22608]
	mov.16b	v12, v2
	str	q2, [sp, #22624]
	ubfiz	x9, x8, #3, #3
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2096
	ldr	x10, [x10, x9]
	lsl	w8, w8, #2
	sub	x8, x10, x8
	str	q21, [sp, #22512]
	str	q29, [sp, #22528]
	str	q8, [sp, #22544]
	str	q15, [sp, #22560]
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2032
	ldr	x9, [x10, x9]
	tst	w6, #0xff
	add	x8, x8, x9, lsl #5
	csel	x8, xzr, x8, eq
	add	x8, x14, x8
	ldp	q0, q1, [x8]
	zip2.8b	v2, v31, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v1, v7, v2
	zip1.8b	v2, v31, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bit.16b	v0, v18, v2
	stp	q0, q1, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v29, v29, v0
	mov.16b	v13, v4
	add.2d	v8, v8, v4
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v15, v15, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v21, v21, v0
	fmov	x8, d21
	cmp	x8, #18
	ldr	q22, [sp, #9840]                ; 16-byte Reload
	mov.16b	v25, v7
	ldr	x15, [sp, #10464]               ; 8-byte Reload
	b.ge	LBB0_77
LBB0_72:                                ; %direct.true402
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_74 Depth 3
	ldr	q31, [sp, #11216]               ; 16-byte Reload
	sshll.2d	v2, v31, #0
	ldr	q11, [sp, #11184]               ; 16-byte Reload
	sshll.2d	v5, v11, #0
	and.16b	v0, v23, v15
	and.16b	v1, v19, v29
	and.16b	v4, v5, v8
	and.16b	v6, v2, v21
	fmov	x8, d6
	ldr	q7, [sp, #11136]                ; 16-byte Reload
	fmov	x9, d7
	sdiv	x6, x8, x9
	mov.d	x8, v6[1]
	sdiv	x24, x8, x15
	fmov	x8, d4
	mov.16b	v14, v16
	fmov	x10, d16
	sdiv	x5, x8, x10
	mov.d	x8, v4[1]
	sdiv	x23, x8, x22
	fmov	x8, d1
	ldr	q7, [sp, #10608]                ; 16-byte Reload
	fmov	x11, d7
	sdiv	x17, x8, x11
	mov.d	x8, v1[1]
	ldr	x16, [sp, #10440]               ; 8-byte Reload
	sdiv	x3, x8, x16
	fmov	x8, d0
	mov.16b	v24, v26
	fmov	x25, d26
	sdiv	x8, x8, x25
	mov.d	x13, v0[1]
	sdiv	x13, x13, x2
	mul	x9, x6, x9
	fmov	d7, x9
	mul	x9, x24, x15
	mov.d	v7[1], x9
	mul	x9, x13, x2
	mul	x25, x8, x25
	mul	x10, x5, x10
	sub.2d	v6, v6, v7
	fmov	d7, x10
	mul	x10, x23, x22
	mov.d	v7[1], x10
	mul	x10, x3, x16
	mul	x11, x17, x11
	sub.2d	v4, v4, v7
	fmov	d7, x11
	mov.d	v7[1], x10
	sub.2d	v1, v1, v7
	fmov	d7, x25
	mov.d	v7[1], x9
	sub.2d	v0, v0, v7
	bit.16b	v20, v0, v23
	bit.16b	v17, v4, v5
	shl.2d	v4, v4, #3
	shl.2d	v0, v0, #3
	ldr	q7, [sp, #10480]                ; 16-byte Reload
	cmgt.2d	v0, v7, v0
	ldr	q7, [sp, #10512]                ; 16-byte Reload
	cmgt.2d	v4, v7, v4
	uzp1.4s	v0, v4, v0
	fmov	d4, x6
	mov.d	v4[1], x24
	mov.16b	v26, v19
	bsl.16b	v26, v1, v22
	ldr	q22, [sp, #8912]                ; 16-byte Reload
	bit.16b	v22, v6, v2
	shl.2d	v6, v6, #3
	shl.2d	v1, v1, #3
	ldr	q7, [sp, #10496]                ; 16-byte Reload
	cmgt.2d	v1, v7, v1
	ldr	q7, [sp, #10576]                ; 16-byte Reload
	cmgt.2d	v6, v7, v6
	uzp1.4s	v1, v6, v1
	fmov	d6, x5
	mov.d	v6[1], x23
	uzp1.8h	v0, v1, v0
	and.16b	v1, v2, v4
	mov.d	x9, v1[1]
	fmov	x10, d1
	fmov	d1, x17
	mov.d	v1[1], x3
	and.16b	v4, v5, v6
	mov.d	x11, v4[1]
	fmov	x17, d4
	fmov	d4, x8
	mov.d	v4[1], x13
	and.16b	v1, v19, v1
	mov.d	x8, v1[1]
	fmov	x13, d1
	and.16b	v1, v23, v4
	sdiv	x3, x9, x12
	msub	x9, x3, x12, x9
	ldr	q4, [sp, #10544]                ; 16-byte Reload
	fmov	x3, d4
	sdiv	x5, x10, x3
	msub	x10, x5, x3, x10
	sdiv	x3, x11, x30
	msub	x11, x3, x30, x11
	ldr	q4, [sp, #10560]                ; 16-byte Reload
	fmov	x3, d4
	sdiv	x5, x17, x3
	msub	x17, x5, x3, x17
	sdiv	x3, x8, x19
	msub	x8, x3, x19, x8
	ldr	q4, [sp, #10528]                ; 16-byte Reload
	fmov	x3, d4
	sdiv	x5, x13, x3
	mov.d	x6, v1[1]
	msub	x13, x5, x3, x13
	sdiv	x3, x6, x28
	msub	x3, x3, x28, x6
	fmov	x5, d1
	ldr	q1, [sp, #10592]                ; 16-byte Reload
	fmov	x6, d1
	sdiv	x23, x5, x6
	msub	x5, x23, x6, x5
	fmov	d1, x5
	mov.d	v1[1], x3
	bit.16b	v30, v1, v23
	fmov	d1, x13
	mov.d	v1[1], x8
	bit.16b	v28, v1, v19
	fmov	d1, x17
	mov.d	v1[1], x11
	ldr	q4, [sp, #10816]                ; 16-byte Reload
	bit.16b	v4, v1, v5
	fmov	d1, x10
	mov.d	v1[1], x9
	ldr	q6, [sp, #10800]                ; 16-byte Reload
	bit.16b	v6, v1, v2
	str	q6, [sp, #10800]                ; 16-byte Spill
	ldr	q1, [sp, #10064]                ; 16-byte Reload
	bic.16b	v1, v1, v5
	str	q1, [sp, #10064]                ; 16-byte Spill
	ldr	q1, [sp, #8896]                 ; 16-byte Reload
	bic.8b	v1, v1, v10
	ldr	q16, [sp, #11376]               ; 16-byte Reload
	and.16b	v0, v16, v0
	xtn.8b	v7, v0
	orr.8b	v1, v7, v1
	ldr	q0, [sp, #10048]                ; 16-byte Reload
	bic.16b	v0, v0, v23
	str	q0, [sp, #10048]                ; 16-byte Spill
	ldr	q6, [sp, #8864]                 ; 16-byte Reload
	bic.16b	v6, v6, v19
	ldr	q5, [sp, #8880]                 ; 16-byte Reload
	bic.16b	v5, v5, v2
	bic.16b	v25, v25, v11
	bic.16b	v18, v18, v31
	mov.16b	v31, v7
	fmov	x8, d5
	shl.8b	v0, v7, #7
	cmp	x8, #33
	mov.16b	v7, v25
	str	q4, [sp, #10816]                ; 16-byte Spill
	str	q22, [sp, #8912]                ; 16-byte Spill
	str	q26, [sp, #9840]                ; 16-byte Spill
	str	q1, [sp, #8896]                 ; 16-byte Spill
	b.ge	LBB0_70
; %bb.73:                               ; %direct.true408.lr.ph
                                        ;   in Loop: Header=BB0_72 Depth=2
	str	q15, [sp, #7024]                ; 16-byte Spill
	str	q8, [sp, #7040]                 ; 16-byte Spill
	str	q29, [sp, #7056]                ; 16-byte Spill
	str	q21, [sp, #7072]                ; 16-byte Spill
	bic.8b	v1, v10, v1
	cmlt.8b	v0, v0, #0
	ldr	d2, [sp, #11400]                ; 8-byte Reload
	and.8b	v2, v0, v2
	addv.8b	b2, v2
	fmov	w6, s2
	umaxv.8b	b0, v0
	fmov	w8, s0
	rbit	w9, w6
	clz	w9, w9
	tst	w8, #0x1
	str	w9, [sp, #7664]                 ; 4-byte Spill
	csel	w8, w9, wzr, ne
	ldr	q0, [sp, #7808]                 ; 16-byte Reload
	str	q0, [sp, #23232]
	ldr	q0, [sp, #7792]                 ; 16-byte Reload
	str	q0, [sp, #23248]
	ldr	q0, [sp, #7776]                 ; 16-byte Reload
	str	q0, [sp, #23264]
	ldr	q0, [sp, #7760]                 ; 16-byte Reload
	str	q0, [sp, #23280]
	ubfiz	x9, x8, #3, #3
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2752
	ldr	x10, [x10, x9]
	str	q22, [sp, #23168]
	str	q26, [sp, #23184]
	str	q17, [sp, #7104]                ; 16-byte Spill
	str	q17, [sp, #23200]
	str	q20, [sp, #7088]                ; 16-byte Spill
	str	q20, [sp, #23216]
	add	x11, sp, #5, lsl #12            ; =20480
	add	x11, x11, #2688
	ldr	x9, [x11, x9]
	add	x26, x9, x9, lsl #5
	lsl	w9, w8, #2
	sub	x27, x10, x9
	and	x5, x8, #0x7
	zip2.8b	v0, v31, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #10720]                ; 16-byte Spill
	str	d31, [sp, #7680]                ; 8-byte Spill
	zip1.8b	v0, v31, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	str	q30, [sp, #10752]               ; 16-byte Spill
	cmlt.4s	v0, v0, #0
	str	q0, [sp, #10704]                ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #10688]                ; 16-byte Spill
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #10672]                ; 16-byte Spill
	mov.16b	v22, v5
	mov.16b	v14, v23
	mov.16b	v10, v19
	str	q28, [sp, #10768]               ; 16-byte Spill
	ldr	q13, [sp, #11040]               ; 16-byte Reload
	ldr	q25, [sp, #11056]               ; 16-byte Reload
	add	x12, sp, #8, lsl #12            ; =32768
	add	x12, x12, #192
	ldr	w1, [sp, #10420]                ; 4-byte Reload
	ldr	w2, [sp, #10316]                ; 4-byte Reload
	mov	x22, x20
	ldr	w19, [sp, #7356]                ; 4-byte Reload
	ldr	w20, [sp, #10092]               ; 4-byte Reload
	add	x14, sp, #5, lsl #12            ; =20480
	add	x14, x14, #2496
	add	x16, sp, #10, lsl #12           ; =40960
	add	x16, x16, #1760
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #2432
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #2368
	add	x25, sp, #5, lsl #12            ; =20480
	add	x25, x25, #2304
	ldr	q31, [sp, #11216]               ; 16-byte Reload
	mov.16b	v23, v6
	ldr	q6, [sp, #11184]                ; 16-byte Reload
	ldr	q29, [sp, #10064]               ; 16-byte Reload
	ldr	q8, [sp, #10048]                ; 16-byte Reload
	ldr	q5, [sp, #5920]                 ; 16-byte Reload
	ldr	q9, [sp, #5904]                 ; 16-byte Reload
	ldr	q15, [sp, #5888]                ; 16-byte Reload
	ldr	q26, [sp, #5872]                ; 16-byte Reload
	ldr	q27, [sp, #5856]                ; 16-byte Reload
	ldr	q11, [sp, #5840]                ; 16-byte Reload
	ldr	q3, [sp, #5824]                 ; 16-byte Reload
	ldr	q16, [sp, #5808]                ; 16-byte Reload
	ldr	q24, [sp, #5792]                ; 16-byte Reload
	ldr	q21, [sp, #5776]                ; 16-byte Reload
	movi.2d	v19, #0000000000000000
LBB0_74:                                ; %direct.true408
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_72 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v0, v31, #0
	sshll.2d	v2, v6, #0
	and.16b	v1, v14, v8
	and.16b	v17, v10, v23
	and.16b	v28, v2, v29
	and.16b	v20, v0, v22
	mov.d	x9, v20[1]
	mov.d	x10, v13[1]
	fmov	x8, d20
	fmov	x11, d13
	mov.d	x24, v28[1]
	sdiv	x8, x8, x11
	mov.d	x23, v25[1]
	fmov	x13, d28
	fmov	x28, d25
	sdiv	x17, x13, x28
	mov.d	x30, v1[1]
	mul	x11, x8, x11
	fmov	d4, x11
	fmov	x11, d1
	sdiv	x13, x9, x10
	mul	x9, x13, x10
	mov.d	v4[1], x9
	ldr	q12, [sp, #11168]               ; 16-byte Reload
	fmov	x9, d12
	sdiv	x3, x11, x9
	sdiv	x10, x24, x23
	mul	x9, x3, x9
	mov.16b	v30, v7
	fmov	d7, x9
	mov.d	x9, v12[1]
	sdiv	x11, x30, x9
	mul	x9, x11, x9
	mov.d	v7[1], x9
	ldr	q12, [sp, #11152]               ; 16-byte Reload
	mov.d	x9, v12[1]
	mul	x24, x17, x28
	sub.2d	v7, v1, v7
	fmov	d1, x24
	fmov	x24, d12
	mul	x23, x10, x23
	mov.d	v1[1], x23
	fmov	x23, d17
	sdiv	x23, x23, x24
	mul	x24, x23, x24
	sub.2d	v1, v28, v1
	fmov	d28, x24
	mov.d	x24, v17[1]
	sdiv	x24, x24, x9
	mul	x9, x24, x9
	mov.d	v28[1], x9
	sub.2d	v17, v17, v28
	sub.2d	v4, v20, v4
	bit.16b	v5, v4, v0
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	cmeq.2d	v0, v0, v7
	ldr	q20, [sp, #11232]               ; 16-byte Reload
	cmeq.2d	v20, v20, v1
	ldr	q28, [sp, #11200]               ; 16-byte Reload
	cmeq.2d	v28, v28, v17
	ldr	q12, [sp, #11264]               ; 16-byte Reload
	cmeq.2d	v4, v12, v4
	uzp1.4s	v0, v20, v0
	uzp1.4s	v4, v4, v28
	uzp1.8h	v20, v4, v0
	ldr	q28, [sp, #11376]               ; 16-byte Reload
	and.16b	v20, v28, v20
	xtn.8b	v20, v20
	shl.8b	v20, v20, #7
	cmlt.8b	v20, v20, #0
	ldr	d28, [sp, #11400]               ; 8-byte Reload
	and.8b	v28, v20, v28
	addv.8b	b28, v28
	fmov	w9, s28
	fmov	d28, x17
	mov.d	v28[1], x10
	umaxv.8b	b20, v20
	fmov	w10, s20
	fmov	d20, x3
	mov.d	v20[1], x11
	rbit	w11, w9
	clz	w11, w11
	tst	w10, #0x1
	ldr	q12, [sp, #11088]               ; 16-byte Reload
	str	q12, [sp, #23040]
	ldr	q12, [sp, #11072]               ; 16-byte Reload
	str	q12, [sp, #23056]
	ldr	q12, [sp, #10736]               ; 16-byte Reload
	str	q12, [sp, #23072]
	csel	w10, w11, wzr, ne
	ldr	q12, [sp, #10656]               ; 16-byte Reload
	str	q12, [sp, #23088]
	ubfiz	x11, x10, #3, #3
	add	x17, sp, #5, lsl #12            ; =20480
	add	x17, x17, #2560
	ldr	x17, [x17, x11]
	ldr	q12, [sp, #10800]               ; 16-byte Reload
	str	q12, [sp, #22976]
	ldr	q12, [sp, #10768]               ; 16-byte Reload
	str	q12, [sp, #22992]
	ldr	q12, [sp, #10816]               ; 16-byte Reload
	str	q12, [sp, #23008]
	ldr	q12, [sp, #10752]               ; 16-byte Reload
	str	q12, [sp, #23024]
	ldr	x3, [x14, x11]
	str	q20, [sp, #23152]
	fmov	d20, x8
	str	q28, [sp, #23136]
	fmov	d28, x23
	mov.d	v28[1], x24
	mov.d	v20[1], x13
	str	q28, [sp, #23120]
	str	q20, [sp, #23104]
	add	x8, x3, x3, lsl #2
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #2624
	ldr	x11, [x13, x11]
	add	x8, x8, x11
	lsl	w10, w10, #2
	sub	x10, x17, x10
	bit.16b	v15, v1, v2
	add	x8, x10, x8, lsl #5
	tst	w9, #0xff
	and.16b	v1, v6, v0
	csel	x8, xzr, x8, eq
	add	x8, x16, x8
	ldr	q2, [x8, #16]
	bsl.16b	v1, v2, v21
	ldr	q2, [x8]
	and.16b	v20, v31, v4
	bif.16b	v2, v24, v20
	bit.16b	v9, v17, v10
	bic.16b	v0, v6, v0
	bic.16b	v4, v31, v4
	xtn.2s	v17, v5
	bic.16b	v24, v2, v4
	mov.s	w8, v17[1]
	fmov	w9, s17
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	bic.16b	v21, v1, v0
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2168
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	str	d0, [sp, #22648]
	ldrb	w10, [x10]
	str	q21, [sp, #22960]
	str	q24, [sp, #22944]
	add	x11, sp, #5, lsl #12            ; =20480
	add	x11, x11, #2464
	ldr	s0, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w0, w10
	xtn.2s	v1, v9
	tst	w9, w10
	fcsel	s2, s0, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #2168
	cset	w10, lo
	bfxil	x9, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w9, [x9]
	str	q21, [sp, #22928]
	str	q24, [sp, #22912]
	and	w9, w1, w9
	ldr	s0, [x15, x8, lsl #2]
	tst	w10, w9
	mov.s	w8, v1[1]
	fcsel	s0, s0, s19, ne
	fmov	w9, s1
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2168
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q21, [sp, #22896]
	str	q24, [sp, #22880]
	add	x11, sp, #5, lsl #12            ; =20480
	add	x11, x11, #2400
	ldr	s1, [x11, x9, lsl #2]
	bit.16b	v26, v7, v14
	xtn.2s	v4, v15
	cset	w9, lo
	and	w10, w2, w10
	tst	w9, w10
	fcsel	s7, s1, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2168
	bfxil	x10, x8, #0, #3
	and	x11, x8, #0x7
	ldrb	w8, [x10]
	and	w8, w7, w8
	str	q21, [sp, #22864]
	str	q24, [sp, #22848]
	tst	w9, w8
	mov.s	w8, v4[1]
	fmov	w9, s4
	ldr	s1, [x4, x11, lsl #2]
	fcsel	s20, s1, s19, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2168
	bfxil	x10, x9, #0, #3
	and	x17, x9, #0x7
	ldrb	w13, [x10]
	str	q21, [sp, #22832]
	str	q24, [sp, #22816]
	mov.s	v2[1], v0[0]
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #2336
	ldr	s0, [x9, x17, lsl #2]
	mov.s	v2[2], v7[0]
	xtn.2s	v1, v26
	cset	w9, lo
	and	w10, w19, w13
	tst	w9, w10
	fcsel	s0, s0, s19, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2168
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	and	w10, w20, w10
	str	q21, [sp, #22800]
	str	q24, [sp, #22784]
	tst	w9, w10
	mov.s	w9, v1[1]
	fmov	w10, s1
	ldr	s1, [x25, x8, lsl #2]
	fcsel	s1, s1, s19, ne
	mov.s	v0[1], v1[0]
	cmp	w10, #8
	csel	w8, w10, wzr, lo
	add	x10, sp, #5, lsl #12            ; =20480
	add	x10, x10, #2168
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	str	q21, [sp, #22768]
	str	q24, [sp, #22752]
	mov.s	v2[3], v20[0]
	add	x11, sp, #5, lsl #12            ; =20480
	add	x11, x11, #2272
	ldr	s1, [x11, x8, lsl #2]
	cset	w8, lo
	and	w10, w21, w10
	tst	w8, w10
	fcsel	s1, s1, s19, ne
	mov.s	v0[2], v1[0]
	cmp	w9, #8
	csel	w8, w9, wzr, lo
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #2168
	bfxil	x9, x8, #0, #3
	cset	w10, lo
	ldrb	w9, [x9]
	and	w9, w22, w9
	tst	w10, w9
	and	x8, x8, #0x7
	str	q21, [sp, #22736]
	str	q24, [sp, #22720]
	bit.16b	v11, v2, v31
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #2240
	ldr	s1, [x9, x8, lsl #2]
	fcsel	s1, s1, s19, ne
	mov.s	v0[3], v1[0]
	str	q22, [sp, #22656]
	str	q23, [sp, #22672]
	str	q29, [sp, #22688]
	str	q8, [sp, #22704]
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #2176
	ldr	x8, [x8, x5, lsl #3]
	add	x8, x8, x26
	add	x8, x27, x8, lsl #5
	tst	w6, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x12, x8
	bit.16b	v3, v0, v6
	ldr	q0, [x8, #16]
	ldr	q1, [sp, #10720]                ; 16-byte Reload
	bif.16b	v0, v16, v1
	ldr	q1, [x8]
	ldr	q2, [sp, #10704]                ; 16-byte Reload
	bif.16b	v1, v27, v2
	ldr	q2, [sp, #10688]                ; 16-byte Reload
	and.16b	v27, v2, v1
	ldr	q1, [sp, #10672]                ; 16-byte Reload
	and.16b	v16, v1, v0
	fmul.4s	v0, v16, v3
	fadd.4s	v0, v30, v0
	mov.16b	v7, v6
	bsl.16b	v7, v0, v30
	fmul.4s	v0, v27, v11
	fadd.4s	v0, v18, v0
	bit.16b	v18, v0, v31
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v23, v23, v0
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v29, v29, v0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v8, v8, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v22, v22, v0
	fmov	x8, d22
	cmp	x8, #33
	b.lt	LBB0_74
; %bb.75:                               ;   in Loop: Header=BB0_72 Depth=2
	str	q21, [sp, #5776]                ; 16-byte Spill
	str	q24, [sp, #5792]                ; 16-byte Spill
	str	q16, [sp, #5808]                ; 16-byte Spill
	str	q3, [sp, #5824]                 ; 16-byte Spill
	str	q11, [sp, #5840]                ; 16-byte Spill
	str	q27, [sp, #5856]                ; 16-byte Spill
	str	q26, [sp, #5872]                ; 16-byte Spill
	str	q15, [sp, #5888]                ; 16-byte Spill
	str	q9, [sp, #5904]                 ; 16-byte Spill
	str	q5, [sp, #5920]                 ; 16-byte Spill
	str	q8, [sp, #10048]                ; 16-byte Spill
	str	q29, [sp, #10064]               ; 16-byte Spill
	str	q23, [sp, #8864]                ; 16-byte Spill
	str	q22, [sp, #8880]                ; 16-byte Spill
	ldr	q4, [sp, #11440]                ; 16-byte Reload
	ldr	x28, [sp, #9896]                ; 8-byte Reload
	ldr	x30, [sp, #9888]                ; 8-byte Reload
	ldr	x19, [sp, #10432]               ; 8-byte Reload
	mov.16b	v19, v10
	ldr	q10, [sp, #11280]               ; 16-byte Reload
	mov.16b	v23, v14
	ldr	q26, [sp, #11296]               ; 16-byte Reload
	ldr	q16, [sp, #11312]               ; 16-byte Reload
	ldr	x12, [sp, #7672]                ; 8-byte Reload
	mov	x20, x22
	add	x14, sp, #7, lsl #12            ; =28672
	add	x14, x14, #1632
	add	x27, sp, #5, lsl #12            ; =20480
	add	x27, x27, #1776
	add	x1, sp, #5, lsl #12             ; =20480
	add	x1, x1, #1840
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #1904
	ldr	q1, [sp, #5344]                 ; 16-byte Reload
	ldr	q3, [sp, #5392]                 ; 16-byte Reload
	ldr	q0, [sp, #5376]                 ; 16-byte Reload
	ldr	q2, [sp, #5328]                 ; 16-byte Reload
	ldr	q17, [sp, #7104]                ; 16-byte Reload
	ldr	q20, [sp, #7088]                ; 16-byte Reload
	ldr	q21, [sp, #7072]                ; 16-byte Reload
	ldr	q29, [sp, #7056]                ; 16-byte Reload
	ldr	q8, [sp, #7040]                 ; 16-byte Reload
	ldr	q15, [sp, #7024]                ; 16-byte Reload
	ldr	q28, [sp, #10768]               ; 16-byte Reload
	ldr	q30, [sp, #10752]               ; 16-byte Reload
	ldr	x22, [sp, #5360]                ; 8-byte Reload
	ldr	x2, [sp, #10448]                ; 8-byte Reload
	ldr	d31, [sp, #7680]                ; 8-byte Reload
	ldr	w8, [sp, #7664]                 ; 4-byte Reload
	b	LBB0_71
LBB0_76:                                ;   in Loop: Header=BB0_28 Depth=1
	ldr	q17, [sp, #7104]                ; 16-byte Reload
	ldr	q20, [sp, #7088]                ; 16-byte Reload
	ldr	q28, [sp, #10768]               ; 16-byte Reload
	ldr	q30, [sp, #10752]               ; 16-byte Reload
	ldr	q25, [sp, #4288]                ; 16-byte Reload
	ldr	q18, [sp, #4256]                ; 16-byte Reload
LBB0_77:                                ; %direct.false403
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q18, [sp, #4256]                ; 16-byte Spill
	str	q25, [sp, #4288]                ; 16-byte Spill
	str	q22, [sp, #9840]                ; 16-byte Spill
	str	q30, [sp, #10752]               ; 16-byte Spill
	str	q28, [sp, #10768]               ; 16-byte Spill
	str	q15, [sp, #7024]                ; 16-byte Spill
	str	q8, [sp, #7040]                 ; 16-byte Spill
	str	q29, [sp, #7056]                ; 16-byte Spill
	str	q21, [sp, #7072]                ; 16-byte Spill
	str	q20, [sp, #7088]                ; 16-byte Spill
	str	q17, [sp, #7104]                ; 16-byte Spill
	ldr	q30, [sp, #11216]               ; 16-byte Reload
	sshll.2d	v0, v30, #0
	ldr	q31, [sp, #11184]               ; 16-byte Reload
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q4, [sp, #9824]                 ; 16-byte Reload
	bit.16b	v4, v2, v23
	str	q4, [sp, #9824]                 ; 16-byte Spill
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q5, [sp, #9792]                 ; 16-byte Reload
	bit.16b	v5, v2, v19
	str	q5, [sp, #9792]                 ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q5, [sp, #9776]                 ; 16-byte Reload
	bit.16b	v5, v2, v1
	str	q5, [sp, #9776]                 ; 16-byte Spill
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q5, [sp, #9808]                 ; 16-byte Reload
	bit.16b	v5, v2, v0
	str	q5, [sp, #9808]                 ; 16-byte Spill
	ldr	q8, [sp, #4208]                 ; 16-byte Reload
	bic.16b	v8, v8, v23
	ldr	q25, [sp, #4240]                ; 16-byte Reload
	bic.16b	v25, v25, v19
	ldr	q11, [sp, #4224]                ; 16-byte Reload
	bic.16b	v11, v11, v1
	mov.16b	v29, v23
	ldr	q10, [sp, #10480]               ; 16-byte Reload
	ldr	q14, [sp, #10512]               ; 16-byte Reload
	mov.16b	v26, v19
	ldr	q19, [sp, #4176]                ; 16-byte Reload
	ldr	q24, [sp, #4192]                ; 16-byte Reload
	bic.16b	v24, v24, v0
	fmov	x8, d24
	cmp	x8, #17
	ldr	q15, [sp, #10576]               ; 16-byte Reload
	add	x24, sp, #5, lsl #12            ; =20480
	add	x24, x24, #1712
	mov	w25, #16746                     ; =0x416a
	movk	w25, #15922, lsl #16
	mov	x7, x2
	add	x26, sp, #5, lsl #12            ; =20480
	add	x26, x26, #1968
	add	x16, sp, #7, lsl #12            ; =28672
	add	x16, x16, #1056
	ldr	q16, [sp, #4128]                ; 16-byte Reload
	mov.16b	v23, v13
	ldr	x2, [sp, #10440]                ; 8-byte Reload
	ldr	q4, [sp, #10608]                ; 16-byte Reload
	ldr	q13, [sp, #10496]               ; 16-byte Reload
	b.gt	LBB0_79
LBB0_78:                                ; %direct.true442
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v30, #0
	sshll.2d	v23, v31, #0
	and.16b	v7, v29, v8
	and.16b	v2, v26, v25
	and.16b	v6, v23, v11
	and.16b	v5, v0, v24
	fmov	x8, d5
	ldr	q1, [sp, #11136]                ; 16-byte Reload
	fmov	x9, d1
	sdiv	x8, x8, x9
	mov.d	x10, v5[1]
	fmov	x11, d6
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	fmov	x13, d1
	sdiv	x11, x11, x13
	sdiv	x10, x10, x15
	mov.d	x17, v6[1]
	fmov	x3, d2
	fmov	x5, d4
	mul	x9, x8, x9
	mov.16b	v18, v4
	fmov	d4, x8
	sdiv	x8, x3, x5
	mov.d	x3, v2[1]
	mul	x5, x8, x5
	mul	x6, x11, x13
	fmov	d17, x11
	fmov	d1, x8
	sdiv	x11, x3, x2
	mov.d	v1[1], x11
	mov.d	v4[1], x10
	sdiv	x17, x17, x22
	fmov	x8, d7
	ldr	q20, [sp, #11296]               ; 16-byte Reload
	fmov	x3, d20
	sdiv	x8, x8, x3
	mov.d	v17[1], x17
	mov.d	x13, v7[1]
	sdiv	x13, x13, x7
	mul	x10, x10, x15
	mul	x11, x11, x2
	fmov	d22, x9
	fmov	d28, x5
	mov.d	v28[1], x11
	mul	x9, x17, x22
	mov.d	v22[1], x10
	mul	x10, x13, x7
	mul	x11, x8, x3
	fmov	d20, x11
	mov.d	v20[1], x10
	sub.2d	v21, v7, v20
	fmov	d7, x6
	mov.d	v7[1], x9
	sub.2d	v20, v6, v7
	sub.2d	v6, v2, v28
	sub.2d	v7, v5, v22
	shl.2d	v2, v7, #3
	shl.2d	v5, v6, #3
	shl.2d	v22, v21, #3
	and.16b	v17, v23, v17
	and.16b	v0, v0, v4
	shl.2d	v23, v20, #3
	cmgt.2d	v4, v10, v22
	mov.d	x9, v0[1]
	fmov	x10, d0
	cmgt.2d	v0, v14, v23
	uzp1.4s	v28, v0, v4
	cmgt.2d	v0, v13, v5
	mov.d	x11, v17[1]
	fmov	x3, d17
	cmgt.2d	v4, v15, v2
	uzp1.4s	v0, v4, v0
	fmov	d4, x8
	mov.d	v4[1], x13
	and.16b	v4, v29, v4
	and.16b	v1, v26, v1
	sdiv	x8, x9, x12
	ldr	q17, [sp, #10544]               ; 16-byte Reload
	fmov	x13, d17
	sdiv	x17, x10, x13
	mov.d	x5, v1[1]
	fmov	x6, d1
	uzp1.8h	v1, v0, v28
	msub	x17, x17, x13, x10
	sdiv	x10, x11, x30
	ldr	q17, [sp, #10560]               ; 16-byte Reload
	fmov	x13, d17
	sdiv	x23, x3, x13
	msub	x23, x23, x13, x3
	msub	x13, x8, x12, x9
	sdiv	x8, x5, x19
	msub	x3, x8, x19, x5
	ldr	q17, [sp, #10528]               ; 16-byte Reload
	fmov	x8, d17
	sdiv	x9, x6, x8
	msub	x9, x9, x8, x6
	msub	x10, x10, x30, x11
	mov.d	x11, v4[1]
	fmov	x5, d4
	ldr	q4, [sp, #11376]                ; 16-byte Reload
	and.16b	v1, v4, v1
	xtn.8b	v1, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v1, v1, #0
	ldr	d4, [sp, #11400]                ; 8-byte Reload
	and.8b	v4, v1, v4
	addv.8b	b4, v4
	fmov	w8, s4
	sdiv	x6, x11, x28
	fmov	d4, x23
	msub	x11, x6, x28, x11
	ldr	q17, [sp, #10592]               ; 16-byte Reload
	fmov	x6, d17
	sdiv	x23, x5, x6
	msub	x5, x23, x6, x5
	mov.d	v4[1], x10
	umaxv.8b	b1, v1
	fmov	w10, s1
	fmov	d1, x5
	mov.d	v1[1], x11
	rbit	w11, w8
	clz	w11, w11
	tst	w10, #0x1
	str	q9, [sp, #22256]
	str	q27, [sp, #22272]
	str	q3, [sp, #22288]
	csel	w10, w11, wzr, ne
	str	q12, [sp, #22304]
	ubfiz	x11, x10, #3, #3
	ldr	x5, [x27, x11]
	str	q1, [sp, #22368]
	fmov	d1, x17
	str	q4, [sp, #22352]
	fmov	d4, x9
	mov.d	v4[1], x3
	mov.d	v1[1], x13
	str	q4, [sp, #22336]
	str	q1, [sp, #22320]
	cmge.2d	v1, v22, v10
	ldr	x9, [x1, x11]
	cmge.2d	v4, v23, v14
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	uzp1.4s	v1, v4, v1
	str	q21, [sp, #22432]
	and.16b	v4, v31, v28
	and.16b	v1, v31, v1
	str	q20, [sp, #22416]
	add	x9, x9, x9, lsl #3
	str	q6, [sp, #22400]
	str	q7, [sp, #22384]
	ldr	x13, [x4, x11]
	lsl	w10, w10, #2
	add	x9, x9, x13
	sub	x13, x5, x10
	add	x9, x13, x9, lsl #5
	ldr	q6, [sp, #9808]                 ; 16-byte Reload
	str	q6, [sp, #22192]
	ldr	q6, [sp, #9792]                 ; 16-byte Reload
	str	q6, [sp, #22208]
	ldr	q6, [sp, #9776]                 ; 16-byte Reload
	str	q6, [sp, #22224]
	ldr	q6, [sp, #9824]                 ; 16-byte Reload
	str	q6, [sp, #22240]
	ldr	x13, [x24, x11]
	tst	w8, #0xff
	csel	x8, xzr, x9, eq
	add	x8, x14, x8
	sub	x9, x13, x10
	ldp	q7, q6, [x8]
	dup.4s	v17, w25
	str	q24, [sp, #22448]
	bif.16b	v6, v16, v4
	str	q25, [sp, #22464]
	str	q11, [sp, #22480]
	str	q8, [sp, #22496]
	ldr	x8, [x26, x11]
	bic.16b	v16, v6, v1
	fmul.4s	v1, v16, v17
	add	x8, x9, x8, lsl #5
	csel	x8, xzr, x8, eq
	add	x8, x16, x8
	ldr	q6, [x8, #16]
	bif.16b	v1, v6, v4
	cmge.2d	v4, v5, v13
	cmge.2d	v2, v2, v15
	uzp1.4s	v2, v2, v4
	and.16b	v0, v30, v0
	mov.16b	v4, v0
	bsl.16b	v4, v7, v19
	and.16b	v2, v30, v2
	bic.16b	v19, v4, v2
	ldr	q2, [x8]
	fmul.4s	v4, v19, v17
	bsl.16b	v0, v4, v2
	mov.16b	v4, v18
	stp	q0, q1, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v25, v25, v0
	add.2d	v11, v11, v23
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v8, v8, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v24, v24, v0
	fmov	x8, d24
	cmp	x8, #18
	b.lt	LBB0_78
LBB0_79:                                ; %direct.false443
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q16, [sp, #4128]                ; 16-byte Spill
	str	q19, [sp, #4176]                ; 16-byte Spill
	str	q24, [sp, #4192]                ; 16-byte Spill
	str	q8, [sp, #4208]                 ; 16-byte Spill
	str	q11, [sp, #4224]                ; 16-byte Spill
	str	q25, [sp, #4240]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	ldr	q3, [sp, #7328]                 ; 16-byte Reload
	bit.16b	v3, v2, v29
	str	q3, [sp, #7328]                 ; 16-byte Spill
	ldr	q16, [sp, #7008]                ; 16-byte Reload
	ldr	q2, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v16, v2, v26
	ldr	q19, [sp, #6992]                ; 16-byte Reload
	ldr	q2, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v19, v2, v1
	ldr	q2, [sp, #5248]                 ; 16-byte Reload
	ldr	q3, [sp, #7312]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #7312]                 ; 16-byte Spill
	ldr	q13, [sp, #4096]                ; 16-byte Reload
	bic.16b	v13, v13, v29
	ldr	q3, [sp, #4144]                 ; 16-byte Reload
	bic.16b	v3, v3, v26
	ldr	q27, [sp, #4112]                ; 16-byte Reload
	bic.16b	v27, v27, v1
	ldr	q24, [sp, #4160]                ; 16-byte Reload
	bic.16b	v24, v24, v0
	fmov	x8, d24
	cmp	x8, #8
	ldr	w7, [sp, #7356]                 ; 4-byte Reload
	b.gt	LBB0_82
; %bb.80:                               ; %direct.true458.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q29, [sp, #11360]               ; 16-byte Reload
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	ldr	q11, [sp, #11312]               ; 16-byte Reload
	mov	w17, #67                        ; =0x43
	ldr	q12, [sp, #11136]               ; 16-byte Reload
	mov	w3, #65                         ; =0x41
	ldr	q25, [sp, #11200]               ; 16-byte Reload
	ldr	x5, [sp, #1032]                 ; 8-byte Reload
	ldr	x6, [sp, #1024]                 ; 8-byte Reload
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #1584
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #1648
	add	x16, sp, #7, lsl #12            ; =28672
	add	x16, x16, #480
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #1456
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #2584
	ldr	q26, [sp, #7312]                ; 16-byte Reload
	ldr	q14, [sp, #11328]               ; 16-byte Reload
	ldr	q10, [sp, #11344]               ; 16-byte Reload
	ldr	q28, [sp, #11296]               ; 16-byte Reload
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	ldr	x1, [sp, #10440]                ; 8-byte Reload
	ldr	w2, [sp, #5372]                 ; 4-byte Reload
	ldr	x26, [sp, #10448]               ; 8-byte Reload
	ldr	q18, [sp, #7328]                ; 16-byte Reload
	mov.16b	v15, v4
LBB0_81:                                ; %direct.true458
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v30, #0
	sshll.2d	v0, v31, #0
	and.16b	v1, v2, v24
	mov.d	x8, v1[1]
	sdiv	x9, x8, x25
	msub	x8, x9, x25, x8
	fmov	x9, d1
	fmov	x10, d12
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d1, x9
	mov.d	v1[1], x8
	and.16b	v4, v10, v3
	mov.d	x8, v4[1]
	sdiv	x9, x8, x1
	msub	x8, x9, x1, x8
	fmov	x9, d4
	fmov	x10, d15
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	and.16b	v5, v0, v27
	mov.d	x8, v5[1]
	sdiv	x9, x8, x22
	msub	x8, x9, x22, x8
	fmov	x9, d5
	fmov	x10, d11
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d5, x9
	mov.d	v5[1], x8
	and.16b	v6, v14, v13
	mov.d	x8, v6[1]
	sdiv	x9, x8, x26
	msub	x8, x9, x26, x8
	fmov	x9, d6
	fmov	x10, d28
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d6, x9
	mov.d	v6[1], x8
	shl.2d	v6, v6, #3
	shl.2d	v5, v5, #3
	shl.2d	v4, v4, #3
	shl.2d	v1, v1, #3
	ldr	q7, [sp, #11264]                ; 16-byte Reload
	orr.16b	v1, v1, v7
	orr.16b	v4, v4, v25
	ldr	q7, [sp, #11232]                ; 16-byte Reload
	orr.16b	v5, v5, v7
	ldr	q7, [sp, #11248]                ; 16-byte Reload
	orr.16b	v6, v6, v7
	dup.2d	v7, x3
	cmgt.2d	v17, v7, v6
	cmgt.2d	v20, v7, v5
	uzp1.4s	v21, v20, v17
	cmgt.2d	v22, v7, v4
	cmgt.2d	v7, v7, v1
	uzp1.4s	v23, v7, v22
	uzp1.8h	v21, v23, v21
	ldr	q23, [sp, #11376]               ; 16-byte Reload
	and.16b	v21, v23, v21
	xtn.8b	v21, v21
	shl.8b	v21, v21, #7
	cmlt.8b	v21, v21, #0
	ldr	d23, [sp, #11400]               ; 8-byte Reload
	and.8b	v23, v21, v23
	addv.8b	b23, v23
	fmov	w8, s23
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	and.16b	v22, v10, v22
	umaxv.8b	b21, v21
	fmov	w9, s21
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	str	q26, [sp, #22064]
	str	q16, [sp, #22080]
	str	q19, [sp, #22096]
	str	q18, [sp, #22112]
	lsl	w9, w9, #3
	and	x10, x9, #0x38
	ldr	x11, [x13, x10]
	str	q24, [sp, #22128]
	str	q3, [sp, #22144]
	str	q27, [sp, #22160]
	str	q13, [sp, #22176]
	ldr	x10, [x15, x10]
	and	x9, x9, #0xf8
	sub	x9, x11, x9
	add	x9, x9, x10, lsl #6
	tst	w8, #0xff
	csel	x8, xzr, x9, eq
	add	x8, x16, x8
	ldr	q21, [x8, #16]
	bif.16b	v4, v21, v22
	and.16b	v2, v2, v7
	ldr	q7, [x8]
	bif.16b	v1, v7, v2
	and.16b	v2, v14, v17
	ldr	q7, [x8, #48]
	bsl.16b	v2, v6, v7
	and.16b	v0, v0, v20
	ldr	q6, [x8, #32]
	bsl.16b	v0, v5, v6
	stp	q0, q2, [x8, #32]
	stp	q1, q4, [x8]
	add.2d	v3, v3, v29
	add.2d	v27, v27, v23
	add.2d	v13, v13, v9
	add.2d	v24, v24, v8
	fmov	x8, d24
	cmp	x8, #9
	b.lt	LBB0_81
	b	LBB0_83
LBB0_82:                                ;   in Loop: Header=BB0_28 Depth=1
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q29, [sp, #11360]               ; 16-byte Reload
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	mov	w17, #67                        ; =0x43
	mov	w3, #65                         ; =0x41
	ldr	x5, [sp, #1032]                 ; 8-byte Reload
	ldr	x6, [sp, #1024]                 ; 8-byte Reload
	add	x16, sp, #7, lsl #12            ; =28672
	add	x16, x16, #480
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #1456
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #2584
	ldr	q14, [sp, #11328]               ; 16-byte Reload
	ldr	q10, [sp, #11344]               ; 16-byte Reload
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	ldr	w2, [sp, #5372]                 ; 4-byte Reload
	ldr	x26, [sp, #10448]               ; 8-byte Reload
LBB0_83:                                ; %direct.false459
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q13, [sp, #4096]                ; 16-byte Spill
	str	q27, [sp, #4112]                ; 16-byte Spill
	str	q3, [sp, #4144]                 ; 16-byte Spill
	str	q24, [sp, #4160]                ; 16-byte Spill
	str	q19, [sp, #6992]                ; 16-byte Spill
	str	q16, [sp, #7008]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #9760]                 ; 16-byte Reload
	ldr	q3, [sp, #5296]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #9760]                 ; 16-byte Spill
	ldr	q2, [sp, #7296]                 ; 16-byte Reload
	ldr	q3, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v2, v3, v10
	str	q2, [sp, #7296]                 ; 16-byte Spill
	ldr	q2, [sp, #7280]                 ; 16-byte Reload
	ldr	q3, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #7280]                 ; 16-byte Spill
	ldr	q2, [sp, #9744]                 ; 16-byte Reload
	ldr	q3, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9744]                 ; 16-byte Spill
	ldr	q2, [sp, #5216]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #5216]                 ; 16-byte Spill
	ldr	q25, [sp, #4080]                ; 16-byte Reload
	bic.16b	v25, v25, v10
	ldr	q3, [sp, #4064]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	ldr	q13, [sp, #4016]                ; 16-byte Reload
	bic.16b	v13, v13, v0
	fmov	x8, d13
	cmp	x8, #8
	b.gt	LBB0_86
; %bb.84:                               ; %direct.true468.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q20, [sp, #11136]               ; 16-byte Reload
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #1392
	add	x23, sp, #5, lsl #12            ; =20480
	add	x23, x23, #1328
	add	x24, sp, #5, lsl #12            ; =20480
	add	x24, x24, #1520
	ldr	q16, [sp, #5216]                ; 16-byte Reload
	ldr	q26, [sp, #4048]                ; 16-byte Reload
	ldr	q15, [sp, #4032]                ; 16-byte Reload
	ldr	q11, [sp, #4000]                ; 16-byte Reload
	ldr	q19, [sp, #3984]                ; 16-byte Reload
	ldr	q30, [sp, #11328]               ; 16-byte Reload
	ldr	q10, [sp, #11344]               ; 16-byte Reload
	ldr	x1, [sp, #10440]                ; 8-byte Reload
LBB0_85:                                ; %direct.true468
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v31, #0
	ldr	q0, [sp, #11216]                ; 16-byte Reload
	sshll.2d	v0, v0, #0
	and.16b	v5, v0, v13
	and.16b	v1, v30, v16
	mov.d	x8, v1[1]
	and.16b	v4, v2, v3
	sdiv	x9, x8, x26
	msub	x8, x9, x26, x8
	fmov	x9, d1
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	fmov	x10, d1
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d17, x9
	mov.d	v17[1], x8
	mov.d	x8, v4[1]
	and.16b	v6, v10, v25
	sdiv	x9, x8, x22
	msub	x8, x9, x22, x8
	fmov	x9, d4
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	fmov	x10, d1
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d1, x9
	mov.d	v1[1], x8
	mov.d	x8, v6[1]
	sdiv	x9, x8, x1
	msub	x8, x9, x1, x8
	fmov	x9, d6
	ldr	q4, [sp, #10608]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	mov.d	x8, v5[1]
	sdiv	x9, x8, x25
	msub	x8, x9, x25, x8
	fmov	x9, d5
	fmov	x10, d20
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d23, x9
	mov.d	v23[1], x8
	mov.16b	v27, v20
	shl.2d	v20, v23, #3
	shl.2d	v28, v4, #3
	shl.2d	v5, v1, #3
	shl.2d	v7, v17, #3
	ldr	q18, [sp, #10480]               ; 16-byte Reload
	cmgt.2d	v21, v18, v7
	ldr	q14, [sp, #10512]               ; 16-byte Reload
	cmgt.2d	v6, v14, v5
	uzp1.4s	v29, v6, v21
	ldr	q24, [sp, #10496]               ; 16-byte Reload
	cmgt.2d	v8, v24, v28
	ldr	q12, [sp, #10576]               ; 16-byte Reload
	cmgt.2d	v22, v12, v20
	uzp1.4s	v9, v22, v8
	uzp1.8h	v29, v9, v29
	ldr	q9, [sp, #11376]                ; 16-byte Reload
	and.16b	v29, v9, v29
	xtn.8b	v29, v29
	shl.8b	v29, v29, #7
	cmlt.8b	v29, v29, #0
	ldr	d9, [sp, #11400]                ; 8-byte Reload
	and.8b	v9, v29, v9
	addv.8b	b9, v9
	fmov	w8, s9
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	umaxv.8b	b29, v29
	fmov	w9, s29
	cmge.2d	v28, v28, v24
	and.16b	v29, v10, v8
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	ldr	q24, [sp, #7312]                ; 16-byte Reload
	str	q24, [sp, #21872]
	ldr	q24, [sp, #7008]                ; 16-byte Reload
	str	q24, [sp, #21888]
	ldr	q24, [sp, #6992]                ; 16-byte Reload
	str	q24, [sp, #21904]
	ldr	q24, [sp, #7328]                ; 16-byte Reload
	str	q24, [sp, #21920]
	lsl	w9, w9, #3
	and	x10, x9, #0x38
	ldr	x11, [x15, x10]
	str	q17, [sp, #21984]
	str	q1, [sp, #21968]
	str	q4, [sp, #21952]
	str	q23, [sp, #21936]
	ldr	x13, [x4, x10]
	and.16b	v1, v10, v28
	and	x9, x9, #0xf8
	sub	x11, x11, x9
	add	x11, x11, x13, lsl #6
	ldr	q4, [sp, #9744]                 ; 16-byte Reload
	str	q4, [sp, #21808]
	ldr	q4, [sp, #7296]                 ; 16-byte Reload
	str	q4, [sp, #21824]
	ldr	q4, [sp, #7280]                 ; 16-byte Reload
	str	q4, [sp, #21840]
	ldr	q4, [sp, #9760]                 ; 16-byte Reload
	str	q4, [sp, #21856]
	ldr	x13, [x23, x10]
	sub	x9, x13, x9
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #4000
	tst	w8, #0xff
	csel	x8, xzr, x11, eq
	add	x8, x16, x8
	ldp	q17, q4, [x8]
	ldp	q28, q23, [x8, #32]
	bif.16b	v4, v15, v29
	bic.16b	v15, v4, v1
	ldr	q1, [sp, #10320]                ; 16-byte Reload
	add.2d	v1, v15, v1
	str	q13, [sp, #22000]
	str	q25, [sp, #22016]
	str	q3, [sp, #22032]
	str	q16, [sp, #22048]
	ldr	x8, [x24, x10]
	add	x8, x9, x8, lsl #6
	csel	x8, xzr, x8, eq
	add	x8, x13, x8
	ldr	q4, [x8, #16]
	bif.16b	v1, v4, v29
	ldr	q29, [sp, #11360]               ; 16-byte Reload
	cmge.2d	v4, v20, v12
	and.16b	v20, v0, v22
	and.16b	v0, v0, v4
	and.16b	v4, v30, v21
	mov.16b	v21, v4
	bsl.16b	v21, v23, v19
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	bif.16b	v17, v26, v20
	bic.16b	v26, v17, v0
	ldr	q0, [x8]
	cmge.2d	v7, v7, v18
	and.16b	v7, v30, v7
	bic.16b	v19, v21, v7
	ldr	q7, [sp, #10352]                ; 16-byte Reload
	add.2d	v7, v26, v7
	bit.16b	v0, v7, v20
	mov.16b	v20, v27
	ldr	q7, [sp, #9856]                 ; 16-byte Reload
	add.2d	v7, v19, v7
	ldr	q17, [x8, #48]
	bsl.16b	v4, v7, v17
	cmge.2d	v5, v5, v14
	and.16b	v6, v2, v6
	and.16b	v2, v2, v5
	mov.16b	v5, v6
	bsl.16b	v5, v28, v11
	ldr	q7, [x8, #32]
	bic.16b	v11, v5, v2
	ldr	q2, [sp, #10336]                ; 16-byte Reload
	add.2d	v2, v11, v2
	bif.16b	v2, v7, v6
	stp	q2, q4, [x8, #32]
	stp	q0, q1, [x8]
	add.2d	v25, v25, v29
	add.2d	v3, v3, v23
	add.2d	v16, v16, v9
	add.2d	v13, v13, v8
	fmov	x8, d13
	cmp	x8, #9
	b.lt	LBB0_85
	b	LBB0_87
LBB0_86:                                ;   in Loop: Header=BB0_28 Depth=1
	ldr	q20, [sp, #11136]               ; 16-byte Reload
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #4000
	ldr	q16, [sp, #5216]                ; 16-byte Reload
	ldr	q26, [sp, #4048]                ; 16-byte Reload
	ldr	q15, [sp, #4032]                ; 16-byte Reload
	ldr	q11, [sp, #4000]                ; 16-byte Reload
	ldr	q19, [sp, #3984]                ; 16-byte Reload
	ldr	q30, [sp, #11328]               ; 16-byte Reload
	ldr	q10, [sp, #11344]               ; 16-byte Reload
LBB0_87:                                ; %direct.false469
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q18, [sp, #11376]               ; 16-byte Reload
	ldr	q27, [sp, #10480]               ; 16-byte Reload
	str	q19, [sp, #3984]                ; 16-byte Spill
	str	q11, [sp, #4000]                ; 16-byte Spill
	str	q13, [sp, #4016]                ; 16-byte Spill
	str	q15, [sp, #4032]                ; 16-byte Spill
	str	q26, [sp, #4048]                ; 16-byte Spill
	str	q16, [sp, #5216]                ; 16-byte Spill
	str	q3, [sp, #4064]                 ; 16-byte Spill
	str	q25, [sp, #4080]                ; 16-byte Spill
	ldr	q0, [sp, #11216]                ; 16-byte Reload
	sshll.2d	v0, v0, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #1280]                 ; 16-byte Reload
	ldr	q3, [sp, #9680]                 ; 16-byte Reload
	bit.16b	v3, v2, v30
	str	q3, [sp, #9680]                 ; 16-byte Spill
	ldr	q3, [sp, #9712]                 ; 16-byte Reload
	bit.16b	v3, v2, v10
	str	q3, [sp, #9712]                 ; 16-byte Spill
	ldr	q3, [sp, #9696]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9696]                 ; 16-byte Spill
	ldr	q3, [sp, #9616]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9616]                 ; 16-byte Spill
	ldr	q2, [sp, #896]                  ; 16-byte Reload
	ldr	q3, [sp, #9728]                 ; 16-byte Reload
	bit.16b	v3, v2, v30
	str	q3, [sp, #9728]                 ; 16-byte Spill
	ldr	q2, [sp, #9648]                 ; 16-byte Reload
	ldr	q3, [sp, #880]                  ; 16-byte Reload
	bit.16b	v2, v3, v10
	str	q2, [sp, #9648]                 ; 16-byte Spill
	ldr	q2, [sp, #9632]                 ; 16-byte Reload
	ldp	q3, q4, [sp, #912]              ; 32-byte Folded Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #9632]                 ; 16-byte Spill
	ldr	q2, [sp, #9664]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9664]                 ; 16-byte Spill
	ldr	q15, [sp, #3920]                ; 16-byte Reload
	bic.16b	v15, v15, v30
	ldr	q11, [sp, #3952]                ; 16-byte Reload
	bic.16b	v11, v11, v10
	ldr	q12, [sp, #3936]                ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q25, [sp, #3968]                ; 16-byte Reload
	bic.16b	v25, v25, v0
	fmov	x8, d25
	cmp	x8, #8
	b.gt	LBB0_106
; %bb.88:                               ; %direct.true484.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #1200
	add	x16, sp, #5, lsl #12            ; =20480
	add	x16, x16, #1264
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #944
	ldr	q19, [sp, #7296]                ; 16-byte Reload
	ldr	q24, [sp, #7280]                ; 16-byte Reload
	ldr	q13, [sp, #3888]                ; 16-byte Reload
	ldr	x1, [sp, #10440]                ; 8-byte Reload
	ldr	q30, [sp, #11216]               ; 16-byte Reload
	b	LBB0_90
LBB0_89:                                ; %else534
                                        ;   in Loop: Header=BB0_90 Depth=2
	add.2d	v11, v11, v29
	add.2d	v12, v12, v23
	add.2d	v15, v15, v9
	add.2d	v25, v25, v8
	fmov	x8, d25
	cmp	x8, #9
	b.ge	LBB0_107
LBB0_90:                                ; %direct.true484
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v31, #0
	sshll.2d	v2, v30, #0
	ldr	q14, [sp, #11328]               ; 16-byte Reload
	and.16b	v1, v14, v15
	mov.d	x8, v1[1]
	and.16b	v4, v0, v12
	sdiv	x9, x8, x26
	msub	x8, x9, x26, x8
	fmov	x9, d1
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	fmov	x10, d1
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d5, x9
	mov.d	v5[1], x8
	mov.d	x8, v4[1]
	ldr	q1, [sp, #11344]                ; 16-byte Reload
	and.16b	v1, v1, v11
	sdiv	x9, x8, x22
	msub	x8, x9, x22, x8
	fmov	x9, d4
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d7, x9
	mov.d	v7[1], x8
	mov.d	x8, v1[1]
	and.16b	v4, v2, v25
	sdiv	x9, x8, x1
	msub	x8, x9, x1, x8
	fmov	x9, d1
	ldr	q1, [sp, #10608]                ; 16-byte Reload
	fmov	x10, d1
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d21, x9
	mov.d	v21[1], x8
	mov.d	x8, v4[1]
	sdiv	x9, x8, x25
	msub	x8, x9, x25, x8
	fmov	x9, d4
	mov.16b	v16, v20
	fmov	x10, d20
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d22, x9
	mov.d	v22[1], x8
	shl.2d	v4, v22, #3
	shl.2d	v6, v21, #3
	shl.2d	v17, v7, #3
	shl.2d	v1, v5, #3
	cmgt.2d	v23, v27, v1
	ldr	q3, [sp, #10512]                ; 16-byte Reload
	cmgt.2d	v28, v3, v17
	uzp1.4s	v29, v28, v23
	ldr	q10, [sp, #10496]               ; 16-byte Reload
	cmgt.2d	v8, v10, v6
	ldr	q26, [sp, #10576]               ; 16-byte Reload
	cmgt.2d	v20, v26, v4
	uzp1.4s	v9, v20, v8
	uzp1.8h	v29, v9, v29
	and.16b	v29, v18, v29
	xtn.8b	v29, v29
	shl.8b	v29, v29, #7
	cmlt.8b	v29, v29, #0
	ldr	d18, [sp, #11400]               ; 8-byte Reload
	and.8b	v9, v29, v18
	addv.8b	b9, v9
	fmov	w8, s9
	umaxv.8b	b29, v29
	fmov	w9, s29
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	ldr	q18, [sp, #9744]                ; 16-byte Reload
	str	q18, [sp, #21680]
	str	q19, [sp, #21696]
	str	q24, [sp, #21712]
	ldr	q18, [sp, #9760]                ; 16-byte Reload
	str	q18, [sp, #21728]
	lsl	w9, w9, #3
	and	x10, x9, #0x38
	ldr	x11, [x15, x10]
	str	q21, [sp, #21760]
	str	q5, [sp, #21792]
	str	q7, [sp, #21776]
	and.16b	v5, v14, v23
	str	q22, [sp, #21744]
	ldr	x10, [x16, x10]
	and	x9, x9, #0xf8
	sub	x9, x11, x9
	add	x9, x9, x10, lsl #6
	tst	w8, #0xff
	csel	x9, xzr, x9, eq
	add	x9, x13, x9
	ldr	q7, [x9, #48]
	ldr	q18, [sp, #8832]                ; 16-byte Reload
	bsl.16b	v5, v7, v18
	ldp	q22, q7, [x9, #16]
	and.16b	v21, v0, v28
	ldr	q18, [sp, #8816]                ; 16-byte Reload
	bif.16b	v7, v18, v21
	ldr	q18, [sp, #11344]               ; 16-byte Reload
	and.16b	v21, v18, v8
	ldr	q18, [sp, #8848]                ; 16-byte Reload
	bsl.16b	v21, v22, v18
	ldr	q22, [x9]
	and.16b	v20, v2, v20
	bsl.16b	v20, v22, v13
	cmge.2d	v17, v17, v3
	and.16b	v0, v0, v17
	cmge.2d	v4, v4, v26
	and.16b	v2, v2, v4
	bic.16b	v13, v20, v2
	cmge.2d	v2, v6, v10
	cmge.2d	v1, v1, v27
	and.16b	v1, v14, v1
	ldr	q14, [sp, #11344]               ; 16-byte Reload
	and.16b	v2, v14, v2
	bic.16b	v4, v21, v2
	bic.16b	v2, v7, v0
	dup.2d	v0, x17
	bic.16b	v1, v5, v1
	str	q1, [sp, #8832]                 ; 16-byte Spill
	cmgt.2d	v1, v0, v1
	str	q2, [sp, #8816]                 ; 16-byte Spill
	cmgt.2d	v2, v0, v2
	uzp1.4s	v1, v2, v1
	str	q4, [sp, #8848]                 ; 16-byte Spill
	cmgt.2d	v2, v0, v4
	cmgt.2d	v0, v0, v13
	uzp1.4s	v0, v0, v2
	uzp1.8h	v0, v0, v1
	ldr	q1, [sp, #9664]                 ; 16-byte Reload
	add.2d	v1, v25, v1
	ldr	q2, [sp, #9616]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	xtn.8b	v0, v0
	movi.8b	v2, #1
	and.8b	v0, v0, v2
	tbz	w8, #0, LBB0_92
; %bb.91:                               ; %cond.store
                                        ;   in Loop: Header=BB0_90 Depth=2
	fmov	x9, d1
	str	b0, [x9]
LBB0_92:                                ; %else513
                                        ;   in Loop: Header=BB0_90 Depth=2
	tbz	w8, #1, LBB0_94
; %bb.93:                               ; %cond.store514
                                        ;   in Loop: Header=BB0_90 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[1], [x9]
LBB0_94:                                ; %else516
                                        ;   in Loop: Header=BB0_90 Depth=2
	ldr	q1, [sp, #9648]                 ; 16-byte Reload
	add.2d	v1, v11, v1
	ldr	q2, [sp, #9712]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q29, [sp, #11360]               ; 16-byte Reload
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	ldr	q18, [sp, #11376]               ; 16-byte Reload
	ldr	q26, [sp, #6800]                ; 16-byte Reload
	mov.16b	v20, v16
	tbnz	w8, #2, LBB0_100
; %bb.95:                               ; %else519
                                        ;   in Loop: Header=BB0_90 Depth=2
	tbnz	w8, #3, LBB0_101
LBB0_96:                                ; %else522
                                        ;   in Loop: Header=BB0_90 Depth=2
	ldr	q1, [sp, #9632]                 ; 16-byte Reload
	add.2d	v1, v12, v1
	ldr	q2, [sp, #9696]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #4, LBB0_102
LBB0_97:                                ; %else525
                                        ;   in Loop: Header=BB0_90 Depth=2
	tbnz	w8, #5, LBB0_103
LBB0_98:                                ; %else528
                                        ;   in Loop: Header=BB0_90 Depth=2
	ldr	q1, [sp, #9728]                 ; 16-byte Reload
	add.2d	v1, v15, v1
	ldr	q2, [sp, #9680]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #6, LBB0_104
LBB0_99:                                ; %else531
                                        ;   in Loop: Header=BB0_90 Depth=2
	ldr	q2, [sp, #9584]                 ; 16-byte Reload
	tbz	w8, #7, LBB0_89
	b	LBB0_105
LBB0_100:                               ; %cond.store517
                                        ;   in Loop: Header=BB0_90 Depth=2
	fmov	x9, d1
	st1.b	{ v0 }[2], [x9]
	tbz	w8, #3, LBB0_96
LBB0_101:                               ; %cond.store520
                                        ;   in Loop: Header=BB0_90 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[3], [x9]
	ldr	q1, [sp, #9632]                 ; 16-byte Reload
	add.2d	v1, v12, v1
	ldr	q2, [sp, #9696]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #4, LBB0_97
LBB0_102:                               ; %cond.store523
                                        ;   in Loop: Header=BB0_90 Depth=2
	fmov	x9, d1
	st1.b	{ v0 }[4], [x9]
	tbz	w8, #5, LBB0_98
LBB0_103:                               ; %cond.store526
                                        ;   in Loop: Header=BB0_90 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[5], [x9]
	ldr	q1, [sp, #9728]                 ; 16-byte Reload
	add.2d	v1, v15, v1
	ldr	q2, [sp, #9680]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #6, LBB0_99
LBB0_104:                               ; %cond.store529
                                        ;   in Loop: Header=BB0_90 Depth=2
	fmov	x9, d1
	st1.b	{ v0 }[6], [x9]
	ldr	q2, [sp, #9584]                 ; 16-byte Reload
	tbz	w8, #7, LBB0_89
LBB0_105:                               ; %cond.store532
                                        ;   in Loop: Header=BB0_90 Depth=2
	mov.d	x8, v1[1]
	st1.b	{ v0 }[7], [x8]
	b	LBB0_89
LBB0_106:                               ;   in Loop: Header=BB0_28 Depth=1
	mov.16b	v14, v10
	add	x4, sp, #5, lsl #12             ; =20480
	add	x4, x4, #944
	ldr	q13, [sp, #3888]                ; 16-byte Reload
	ldr	q26, [sp, #6800]                ; 16-byte Reload
	ldr	q2, [sp, #9584]                 ; 16-byte Reload
	ldr	x1, [sp, #10440]                ; 8-byte Reload
	ldr	q30, [sp, #11216]               ; 16-byte Reload
LBB0_107:                               ; %direct.false485
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q15, [sp, #3920]                ; 16-byte Spill
	str	q12, [sp, #3936]                ; 16-byte Spill
	str	q11, [sp, #3952]                ; 16-byte Spill
	str	q25, [sp, #3968]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q16, [sp, #6960]                ; 16-byte Reload
	ldr	q4, [sp, #11328]                ; 16-byte Reload
	ldr	q3, [sp, #5296]                 ; 16-byte Reload
	bit.16b	v16, v3, v4
	ldr	q3, [sp, #5280]                 ; 16-byte Reload
	ldr	q5, [sp, #7264]                 ; 16-byte Reload
	bit.16b	v5, v3, v14
	str	q5, [sp, #7264]                 ; 16-byte Spill
	ldr	q3, [sp, #6976]                 ; 16-byte Reload
	ldr	q5, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v3, v5, v1
	ldr	q5, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v2, v5, v0
	str	q2, [sp, #9584]                 ; 16-byte Spill
	bic.16b	v26, v26, v4
	ldr	q2, [sp, #5200]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #5200]                 ; 16-byte Spill
	ldr	q27, [sp, #3872]                ; 16-byte Reload
	bic.16b	v27, v27, v1
	ldr	q24, [sp, #3904]                ; 16-byte Reload
	bic.16b	v24, v24, v0
	fmov	x8, d24
	cmp	x8, #8
	b.gt	LBB0_110
; %bb.108:                              ; %direct.true497.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q12, [sp, #11136]               ; 16-byte Reload
	ldr	q25, [sp, #11200]               ; 16-byte Reload
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #1072
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #1136
	add	x16, sp, #6, lsl #12            ; =24576
	add	x16, x16, #3352
	ldr	q19, [sp, #5200]                ; 16-byte Reload
	ldr	q28, [sp, #9584]                ; 16-byte Reload
	ldr	q10, [sp, #11328]               ; 16-byte Reload
	ldr	q18, [sp, #11296]               ; 16-byte Reload
	ldr	q15, [sp, #7264]                ; 16-byte Reload
	ldr	q11, [sp, #10608]               ; 16-byte Reload
LBB0_109:                               ; %direct.true497
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v30, #0
	sshll.2d	v0, v31, #0
	and.16b	v1, v2, v24
	mov.d	x8, v1[1]
	sdiv	x9, x8, x25
	msub	x8, x9, x25, x8
	fmov	x9, d1
	fmov	x10, d12
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d1, x9
	mov.d	v1[1], x8
	and.16b	v4, v14, v19
	mov.d	x8, v4[1]
	sdiv	x9, x8, x1
	msub	x8, x9, x1, x8
	fmov	x9, d4
	fmov	x10, d11
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	and.16b	v5, v0, v27
	mov.d	x8, v5[1]
	sdiv	x9, x8, x22
	msub	x8, x9, x22, x8
	fmov	x9, d5
	ldr	q5, [sp, #11312]                ; 16-byte Reload
	fmov	x10, d5
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d5, x9
	mov.d	v5[1], x8
	and.16b	v6, v10, v26
	mov.d	x8, v6[1]
	sdiv	x9, x8, x26
	msub	x8, x9, x26, x8
	fmov	x9, d6
	fmov	x10, d18
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d6, x9
	mov.d	v6[1], x8
	shl.2d	v6, v6, #3
	shl.2d	v5, v5, #3
	shl.2d	v4, v4, #3
	shl.2d	v1, v1, #3
	ldr	q7, [sp, #11264]                ; 16-byte Reload
	orr.16b	v1, v1, v7
	orr.16b	v4, v4, v25
	ldr	q7, [sp, #11232]                ; 16-byte Reload
	orr.16b	v5, v5, v7
	ldr	q7, [sp, #11248]                ; 16-byte Reload
	orr.16b	v6, v6, v7
	dup.2d	v7, x3
	cmgt.2d	v17, v7, v6
	cmgt.2d	v20, v7, v5
	uzp1.4s	v21, v20, v17
	cmgt.2d	v22, v7, v4
	cmgt.2d	v7, v7, v1
	uzp1.4s	v23, v7, v22
	uzp1.8h	v21, v23, v21
	ldr	q23, [sp, #11376]               ; 16-byte Reload
	and.16b	v21, v23, v21
	xtn.8b	v21, v21
	shl.8b	v21, v21, #7
	cmlt.8b	v21, v21, #0
	ldr	d23, [sp, #11400]               ; 8-byte Reload
	and.8b	v23, v21, v23
	addv.8b	b23, v23
	fmov	w8, s23
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	and.16b	v22, v14, v22
	umaxv.8b	b21, v21
	fmov	w9, s21
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	str	q28, [sp, #21552]
	str	q15, [sp, #21568]
	str	q3, [sp, #21584]
	str	q16, [sp, #21600]
	lsl	w9, w9, #3
	and	x10, x9, #0x38
	ldr	x11, [x13, x10]
	str	q24, [sp, #21616]
	str	q19, [sp, #21632]
	str	q27, [sp, #21648]
	str	q26, [sp, #21664]
	ldr	x10, [x15, x10]
	and	x9, x9, #0xf8
	sub	x9, x11, x9
	add	x9, x9, x10, lsl #6
	tst	w8, #0xff
	csel	x8, xzr, x9, eq
	add	x8, x16, x8
	ldr	q21, [x8, #16]
	bif.16b	v4, v21, v22
	and.16b	v2, v2, v7
	ldr	q7, [x8]
	bif.16b	v1, v7, v2
	and.16b	v2, v10, v17
	ldr	q7, [x8, #48]
	bsl.16b	v2, v6, v7
	and.16b	v0, v0, v20
	ldr	q6, [x8, #32]
	bsl.16b	v0, v5, v6
	stp	q0, q2, [x8, #32]
	stp	q1, q4, [x8]
	add.2d	v19, v19, v29
	add.2d	v27, v27, v23
	add.2d	v26, v26, v9
	add.2d	v24, v24, v8
	fmov	x8, d24
	cmp	x8, #9
	b.lt	LBB0_109
	b	LBB0_111
LBB0_110:                               ;   in Loop: Header=BB0_28 Depth=1
	add	x16, sp, #6, lsl #12            ; =24576
	add	x16, x16, #3352
	ldr	q19, [sp, #5200]                ; 16-byte Reload
	ldr	q10, [sp, #11328]               ; 16-byte Reload
LBB0_111:                               ; %direct.false498
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q26, [sp, #6800]                ; 16-byte Spill
	str	q27, [sp, #3872]                ; 16-byte Spill
	str	q19, [sp, #5200]                ; 16-byte Spill
	str	q13, [sp, #3888]                ; 16-byte Spill
	str	q24, [sp, #3904]                ; 16-byte Spill
	str	q16, [sp, #6960]                ; 16-byte Spill
	str	q3, [sp, #6976]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	ldr	q3, [sp, #9600]                 ; 16-byte Reload
	bit.16b	v3, v2, v10
	str	q3, [sp, #9600]                 ; 16-byte Spill
	ldr	q2, [sp, #9552]                 ; 16-byte Reload
	ldr	q3, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #9552]                 ; 16-byte Spill
	ldr	q2, [sp, #9536]                 ; 16-byte Reload
	ldr	q3, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9536]                 ; 16-byte Spill
	ldr	q2, [sp, #9568]                 ; 16-byte Reload
	ldr	q3, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	str	q2, [sp, #9568]                 ; 16-byte Spill
	ldr	q16, [sp, #3824]                ; 16-byte Reload
	bic.16b	v16, v16, v10
	ldr	q11, [sp, #3856]                ; 16-byte Reload
	bic.16b	v11, v11, v14
	ldr	q3, [sp, #3840]                 ; 16-byte Reload
	bic.16b	v3, v3, v1
	ldr	q19, [sp, #3760]                ; 16-byte Reload
	bic.16b	v19, v19, v0
	fmov	x8, d19
	cmp	x8, #8
	b.gt	LBB0_114
; %bb.112:                              ; %direct.true507.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q15, [sp, #10576]               ; 16-byte Reload
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #880
	add	x3, sp, #5, lsl #12             ; =20480
	add	x3, x3, #816
	add	x23, sp, #5, lsl #12            ; =20480
	add	x23, x23, #1008
	add	x24, sp, #6, lsl #12            ; =24576
	add	x24, x24, #2776
	ldr	q18, [sp, #10480]               ; 16-byte Reload
	ldr	q12, [sp, #3792]                ; 16-byte Reload
	ldr	q26, [sp, #3776]                ; 16-byte Reload
	ldr	q25, [sp, #3744]                ; 16-byte Reload
	ldr	q13, [sp, #3664]                ; 16-byte Reload
	ldr	q27, [sp, #10496]               ; 16-byte Reload
	ldr	x1, [sp, #10440]                ; 8-byte Reload
	ldr	q24, [sp, #10512]               ; 16-byte Reload
LBB0_113:                               ; %direct.true507
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v31, #0
	sshll.2d	v0, v30, #0
	and.16b	v5, v0, v19
	and.16b	v1, v10, v16
	mov.d	x8, v1[1]
	and.16b	v4, v2, v3
	sdiv	x9, x8, x26
	msub	x8, x9, x26, x8
	fmov	x9, d1
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	fmov	x10, d1
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d17, x9
	mov.d	v17[1], x8
	mov.d	x8, v4[1]
	and.16b	v6, v14, v11
	sdiv	x9, x8, x22
	msub	x8, x9, x22, x8
	fmov	x9, d4
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	fmov	x10, d1
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d1, x9
	mov.d	v1[1], x8
	mov.d	x8, v6[1]
	sdiv	x9, x8, x1
	msub	x8, x9, x1, x8
	fmov	x9, d6
	ldr	q4, [sp, #10608]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	mov.d	x8, v5[1]
	sdiv	x9, x8, x25
	msub	x8, x9, x25, x8
	fmov	x9, d5
	ldr	q5, [sp, #11136]                ; 16-byte Reload
	fmov	x10, d5
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d23, x9
	mov.d	v23[1], x8
	shl.2d	v20, v23, #3
	shl.2d	v28, v4, #3
	shl.2d	v5, v1, #3
	shl.2d	v7, v17, #3
	cmgt.2d	v21, v18, v7
	cmgt.2d	v6, v24, v5
	uzp1.4s	v29, v6, v21
	cmgt.2d	v8, v27, v28
	cmgt.2d	v22, v15, v20
	uzp1.4s	v9, v22, v8
	uzp1.8h	v29, v9, v29
	ldr	q9, [sp, #11376]                ; 16-byte Reload
	and.16b	v29, v9, v29
	xtn.8b	v29, v29
	shl.8b	v29, v29, #7
	cmlt.8b	v29, v29, #0
	ldr	d9, [sp, #11400]                ; 8-byte Reload
	and.8b	v9, v29, v9
	addv.8b	b9, v9
	fmov	w8, s9
	umaxv.8b	b29, v29
	fmov	w9, s29
	cmge.2d	v28, v28, v27
	and.16b	v29, v14, v8
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	ldr	q8, [sp, #9584]                 ; 16-byte Reload
	str	q8, [sp, #21360]
	ldr	q8, [sp, #7264]                 ; 16-byte Reload
	str	q8, [sp, #21376]
	ldr	q8, [sp, #6976]                 ; 16-byte Reload
	str	q8, [sp, #21392]
	ldr	q8, [sp, #6960]                 ; 16-byte Reload
	str	q8, [sp, #21408]
	lsl	w9, w9, #3
	and	x10, x9, #0x38
	ldr	x11, [x15, x10]
	str	q17, [sp, #21472]
	str	q1, [sp, #21456]
	str	q4, [sp, #21440]
	str	q23, [sp, #21424]
	ldr	x13, [x4, x10]
	and.16b	v1, v14, v28
	and	x9, x9, #0xf8
	sub	x11, x11, x9
	add	x11, x11, x13, lsl #6
	ldr	q4, [sp, #9568]                 ; 16-byte Reload
	str	q4, [sp, #21296]
	ldr	q4, [sp, #9552]                 ; 16-byte Reload
	str	q4, [sp, #21312]
	ldr	q4, [sp, #9536]                 ; 16-byte Reload
	str	q4, [sp, #21328]
	ldr	q4, [sp, #9600]                 ; 16-byte Reload
	str	q4, [sp, #21344]
	ldr	x13, [x3, x10]
	sub	x9, x13, x9
	tst	w8, #0xff
	csel	x8, xzr, x11, eq
	add	x8, x16, x8
	ldp	q17, q4, [x8]
	ldp	q28, q23, [x8, #32]
	bif.16b	v4, v26, v29
	bic.16b	v26, v4, v1
	ldr	q1, [sp, #10320]                ; 16-byte Reload
	add.2d	v1, v26, v1
	str	q19, [sp, #21488]
	str	q11, [sp, #21504]
	str	q3, [sp, #21520]
	str	q16, [sp, #21536]
	ldr	x8, [x23, x10]
	add	x8, x9, x8, lsl #6
	csel	x8, xzr, x8, eq
	add	x8, x24, x8
	ldr	q4, [x8, #16]
	bif.16b	v1, v4, v29
	cmge.2d	v4, v20, v15
	and.16b	v20, v0, v22
	and.16b	v0, v0, v4
	and.16b	v4, v10, v21
	mov.16b	v21, v4
	bsl.16b	v21, v23, v13
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	bif.16b	v17, v12, v20
	bic.16b	v12, v17, v0
	ldr	q0, [x8]
	cmge.2d	v7, v7, v18
	and.16b	v7, v10, v7
	bic.16b	v13, v21, v7
	ldr	q7, [sp, #10352]                ; 16-byte Reload
	add.2d	v7, v12, v7
	bit.16b	v0, v7, v20
	ldr	q7, [sp, #9856]                 ; 16-byte Reload
	add.2d	v7, v13, v7
	ldr	q17, [x8, #48]
	bsl.16b	v4, v7, v17
	cmge.2d	v5, v5, v24
	and.16b	v6, v2, v6
	and.16b	v2, v2, v5
	mov.16b	v5, v6
	bsl.16b	v5, v28, v25
	ldr	q7, [x8, #32]
	bic.16b	v25, v5, v2
	ldr	q2, [sp, #10336]                ; 16-byte Reload
	add.2d	v2, v25, v2
	bif.16b	v2, v7, v6
	stp	q2, q4, [x8, #32]
	stp	q0, q1, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v11, v11, v0
	add.2d	v3, v3, v23
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v16, v16, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v19, v19, v0
	fmov	x8, d19
	cmp	x8, #9
	b.lt	LBB0_113
	b	LBB0_115
LBB0_114:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	q12, [sp, #3792]                ; 16-byte Reload
	ldr	q26, [sp, #3776]                ; 16-byte Reload
	ldr	q25, [sp, #3744]                ; 16-byte Reload
	ldr	q13, [sp, #3664]                ; 16-byte Reload
LBB0_115:                               ; %direct.false508
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q13, [sp, #3664]                ; 16-byte Spill
	str	q25, [sp, #3744]                ; 16-byte Spill
	str	q19, [sp, #3760]                ; 16-byte Spill
	str	q26, [sp, #3776]                ; 16-byte Spill
	str	q12, [sp, #3792]                ; 16-byte Spill
	str	q16, [sp, #3824]                ; 16-byte Spill
	str	q3, [sp, #3840]                 ; 16-byte Spill
	str	q11, [sp, #3856]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q21, [sp, #3808]                ; 16-byte Reload
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	bit.16b	v21, v2, v10
	ldr	q2, [sp, #4880]                 ; 16-byte Reload
	ldr	q3, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	ldr	q3, [sp, #4864]                 ; 16-byte Reload
	ldr	q4, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v3, v4, v1
	ldr	q8, [sp, #3680]                 ; 16-byte Reload
	ldr	q4, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v8, v4, v0
	ldr	q29, [sp, #3696]                ; 16-byte Reload
	bic.16b	v29, v29, v10
	ldr	q22, [sp, #3728]                ; 16-byte Reload
	bic.16b	v22, v22, v14
	ldr	q28, [sp, #3712]                ; 16-byte Reload
	bic.16b	v28, v28, v1
	ldr	q15, [sp, #3632]                ; 16-byte Reload
	bic.16b	v15, v15, v0
	fmov	x8, d15
	cmp	x8, #0
	str	q2, [sp, #4880]                 ; 16-byte Spill
	str	q3, [sp, #4864]                 ; 16-byte Spill
	b.le	LBB0_117
; %bb.116:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	q27, [sp, #5024]                ; 16-byte Reload
	ldr	q25, [sp, #5008]                ; 16-byte Reload
	ldr	q12, [sp, #4992]                ; 16-byte Reload
	ldr	q19, [sp, #4976]                ; 16-byte Reload
	ldr	w10, [sp, #5052]                ; 4-byte Reload
	ldr	q3, [sp, #4512]                 ; 16-byte Reload
	ldr	q26, [sp, #1136]                ; 16-byte Reload
	add	x15, sp, #6, lsl #12            ; =24576
	add	x15, x15, #2776
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #2712
	add	x16, sp, #4, lsl #12            ; =16384
	add	x16, x16, #3296
	add	x4, sp, #4, lsl #12             ; =16384
	add	x4, x4, #3232
	ldr	q18, [sp, #3600]                ; 16-byte Reload
	ldr	q11, [sp, #3584]                ; 16-byte Reload
	ldr	x23, [sp, #10440]               ; 8-byte Reload
	ldr	w1, [sp, #10316]                ; 4-byte Reload
	b	LBB0_119
LBB0_117:                               ; %direct.true523.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q8, [sp, #21232]
	str	q2, [sp, #21248]
	str	q3, [sp, #21264]
	str	q21, [sp, #21280]
	ldr	x8, [sp, #264]                  ; 8-byte Reload
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #752
	ldr	x8, [x9, x8, lsl #3]
	ldr	x9, [sp, #1304]                 ; 8-byte Reload
	sub	x8, x8, x9
	ldr	q6, [sp, #4528]                 ; 16-byte Reload
	ldr	q27, [sp, #5024]                ; 16-byte Reload
	ldr	q25, [sp, #5008]                ; 16-byte Reload
	ldr	q12, [sp, #4992]                ; 16-byte Reload
	ldr	q19, [sp, #4976]                ; 16-byte Reload
	ldr	q7, [sp, #11408]                ; 16-byte Reload
	ldr	q17, [sp, #11360]               ; 16-byte Reload
	ldr	q20, [sp, #11424]               ; 16-byte Reload
	ldr	w10, [sp, #5052]                ; 4-byte Reload
	ldr	q3, [sp, #4512]                 ; 16-byte Reload
	ldr	q26, [sp, #1136]                ; 16-byte Reload
	add	x15, sp, #6, lsl #12            ; =24576
	add	x15, x15, #2776
	add	x11, sp, #5, lsl #12            ; =20480
	add	x11, x11, #688
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #2712
	add	x16, sp, #4, lsl #12            ; =16384
	add	x16, x16, #3296
	add	x4, sp, #4, lsl #12             ; =16384
	add	x4, x4, #3232
	ldr	q18, [sp, #3600]                ; 16-byte Reload
	ldr	q11, [sp, #3584]                ; 16-byte Reload
	ldr	x23, [sp, #10440]               ; 8-byte Reload
	ldr	w1, [sp, #10316]                ; 4-byte Reload
LBB0_118:                               ; %direct.true523
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	q15, [sp, #21168]
	str	q22, [sp, #21184]
	str	q28, [sp, #21200]
	str	q29, [sp, #21216]
	ldr	x9, [x11, x5, lsl #3]
	add	x9, x8, x9, lsl #6
	tst	w10, #0xff
	csel	x9, xzr, x9, eq
	add	x9, x13, x9
	ldp	q0, q1, [x9, #32]
	ldp	q2, q4, [x9]
	mov	b5, v3[2]
	mov.b	v5[4], v3[3]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bic.16b	v4, v4, v5
	sub.2d	v4, v4, v5
	mov	b5, v3[6]
	mov.b	v5[4], v3[7]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bic.16b	v1, v1, v5
	sub.2d	v1, v1, v5
	mov	b5, v3[4]
	mov.b	v5[4], v3[5]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bic.16b	v0, v0, v5
	sub.2d	v0, v0, v5
	mov	b5, v3[0]
	mov.b	v5[4], v3[1]
	ushll.2d	v5, v5, #0
	shl.2d	v5, v5, #63
	cmlt.2d	v5, v5, #0
	bit.16b	v2, v6, v5
	stp	q0, q1, [x9, #32]
	stp	q2, q4, [x9]
	add.2d	v22, v22, v17
	add.2d	v28, v28, v23
	add.2d	v29, v29, v7
	add.2d	v15, v15, v20
	fmov	x9, d15
	cmp	x9, #1
	b.lt	LBB0_118
LBB0_119:                               ; %direct.false524
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q15, [sp, #3632]                ; 16-byte Spill
	str	q29, [sp, #3696]                ; 16-byte Spill
	str	q28, [sp, #3712]                ; 16-byte Spill
	str	q22, [sp, #3728]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q28, [sp, #4800]                ; 16-byte Reload
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	bit.16b	v28, v2, v10
	ldr	q17, [sp, #4832]                ; 16-byte Reload
	ldr	q2, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v17, v2, v14
	ldr	q20, [sp, #4816]                ; 16-byte Reload
	ldr	q2, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v20, v2, v1
	ldr	q4, [sp, #4848]                 ; 16-byte Reload
	ldr	q2, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	ldr	q22, [sp, #3648]                ; 16-byte Reload
	bic.16b	v22, v22, v10
	bic.16b	v18, v18, v14
	bic.16b	v11, v11, v1
	ldr	q2, [sp, #3616]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	mov.16b	v1, v2
	fmov	x8, d2
	cmp	x8, #0
	str	q21, [sp, #3808]                ; 16-byte Spill
	str	q8, [sp, #3680]                 ; 16-byte Spill
	str	q4, [sp, #4848]                 ; 16-byte Spill
	str	q17, [sp, #4832]                ; 16-byte Spill
	str	q20, [sp, #4816]                ; 16-byte Spill
	str	q28, [sp, #4800]                ; 16-byte Spill
	b.le	LBB0_121
; %bb.120:                              ;   in Loop: Header=BB0_28 Depth=1
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #2648
	mov.16b	v21, v1
	ldr	q24, [sp, #3552]                ; 16-byte Reload
	ldr	q13, [sp, #3536]                ; 16-byte Reload
	ldr	q9, [sp, #3488]                 ; 16-byte Reload
	ldr	q19, [sp, #3440]                ; 16-byte Reload
	b	LBB0_123
LBB0_121:                               ; %direct.true533.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q8, [sp, #21104]
	ldr	q0, [sp, #4880]                 ; 16-byte Reload
	str	q0, [sp, #21120]
	ldr	q0, [sp, #4864]                 ; 16-byte Reload
	str	q0, [sp, #21136]
	str	q21, [sp, #21152]
	ldr	x11, [sp, #256]                 ; 8-byte Reload
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #624
	ldr	x8, [x8, x11]
	ldr	x9, [sp, #1304]                 ; 8-byte Reload
	sub	x8, x8, x9
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x13, x8
	ldp	q5, q0, [x8, #32]
	str	q0, [sp, #10720]                ; 16-byte Spill
	ldp	q7, q6, [x8]
	str	q4, [sp, #21040]
	str	q17, [sp, #21056]
	str	q20, [sp, #21072]
	str	q28, [sp, #21088]
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #560
	ldr	x8, [x8, x11]
	sub	x8, x8, x9
	ldr	q28, [sp, #11408]               ; 16-byte Reload
	ldr	q29, [sp, #11360]               ; 16-byte Reload
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	add	x11, sp, #5, lsl #12            ; =20480
	add	x11, x11, #496
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #2648
	mov.16b	v21, v1
	ldr	q24, [sp, #3552]                ; 16-byte Reload
	ldr	q13, [sp, #3536]                ; 16-byte Reload
	ldr	q9, [sp, #3488]                 ; 16-byte Reload
	mov.16b	v2, v19
	ldr	q19, [sp, #3440]                ; 16-byte Reload
LBB0_122:                               ; %direct.true533
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	b0, v3[4]
	mov.b	v0[4], v3[5]
	mov	b1, v3[6]
	mov.b	v1[4], v3[7]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v20, v1, #0
	mov	b1, v3[2]
	mov.b	v1[4], v3[3]
	ushll.2d	v1, v1, #0
	shl.2d	v1, v1, #63
	cmlt.2d	v1, v1, #0
	mov.16b	v4, v1
	bsl.16b	v4, v6, v13
	mov	b17, v26[2]
	mov.b	v17[4], v26[3]
	ushll.2d	v17, v17, #0
	shl.2d	v17, v17, #63
	cmge.2d	v17, v17, #0
	and.16b	v13, v17, v4
	add.2d	v4, v13, v12
	str	q21, [sp, #20976]
	str	q18, [sp, #20992]
	str	q11, [sp, #21008]
	str	q22, [sp, #21024]
	ldr	x9, [x11, x6, lsl #3]
	add	x9, x8, x9, lsl #6
	tst	w10, #0xff
	csel	x9, xzr, x9, eq
	add	x9, x13, x9
	mov.16b	v16, v18
	mov.16b	v18, v12
	mov.16b	v12, v21
	ldp	q17, q21, [x9]
	bsl.16b	v1, v4, v21
	mov	b4, v3[0]
	mov.b	v4[4], v3[1]
	ldr	q21, [sp, #10720]               ; 16-byte Reload
	bif.16b	v21, v19, v20
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	mov.16b	v15, v22
	mov.16b	v22, v4
	bsl.16b	v22, v7, v9
	mov	b23, v26[0]
	mov.b	v23[4], v26[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmge.2d	v23, v23, #0
	and.16b	v9, v23, v22
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	mov	b22, v26[6]
	mov.b	v22[4], v26[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmge.2d	v22, v22, #0
	and.16b	v19, v22, v21
	add.2d	v21, v9, v27
	bsl.16b	v4, v21, v17
	add.2d	v17, v19, v2
	ldr	q21, [x9, #48]
	bif.16b	v17, v21, v20
	ldr	q20, [x9, #32]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	mov.16b	v21, v0
	bsl.16b	v21, v5, v24
	mov	b22, v26[4]
	mov.b	v22[4], v26[5]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmge.2d	v22, v22, #0
	and.16b	v24, v22, v21
	add.2d	v21, v24, v25
	bsl.16b	v0, v21, v20
	mov.16b	v21, v12
	mov.16b	v12, v18
	stp	q0, q17, [x9, #32]
	stp	q4, q1, [x9]
	add.2d	v18, v16, v29
	add.2d	v11, v11, v23
	add.2d	v22, v15, v28
	add.2d	v21, v21, v8
	fmov	x9, d21
	cmp	x9, #1
	b.lt	LBB0_122
LBB0_123:                               ; %direct.false534
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q11, [sp, #3584]                ; 16-byte Spill
	str	q18, [sp, #3600]                ; 16-byte Spill
	str	q19, [sp, #3440]                ; 16-byte Spill
	str	q9, [sp, #3488]                 ; 16-byte Spill
	str	q13, [sp, #3536]                ; 16-byte Spill
	str	q24, [sp, #3552]                ; 16-byte Spill
	str	q21, [sp, #3616]                ; 16-byte Spill
	str	q22, [sp, #3648]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q20, [sp, #4736]                ; 16-byte Reload
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	bit.16b	v20, v2, v10
	ldr	q16, [sp, #4768]                ; 16-byte Reload
	ldr	q2, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v16, v2, v14
	ldr	q17, [sp, #4752]                ; 16-byte Reload
	ldr	q2, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v17, v2, v1
	ldr	q4, [sp, #4784]                 ; 16-byte Reload
	ldr	q2, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	ldr	q13, [sp, #3568]                ; 16-byte Reload
	bic.16b	v13, v13, v10
	ldr	q15, [sp, #3504]                ; 16-byte Reload
	bic.16b	v15, v15, v14
	ldr	q24, [sp, #3472]                ; 16-byte Reload
	bic.16b	v24, v24, v1
	ldr	q2, [sp, #3520]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	mov.16b	v1, v2
	fmov	x8, d2
	cmp	x8, #0
	str	q4, [sp, #4784]                 ; 16-byte Spill
	str	q16, [sp, #4768]                ; 16-byte Spill
	str	q17, [sp, #4752]                ; 16-byte Spill
	str	q20, [sp, #4736]                ; 16-byte Spill
	b.le	LBB0_125
; %bb.124:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	q28, [sp, #11360]               ; 16-byte Reload
	ldr	x13, [sp, #1016]                ; 8-byte Reload
	mov	x5, #-3                         ; =0xfffffffffffffffd
	add	x6, sp, #5, lsl #12             ; =20480
	add	x6, x6, #112
	ldr	q12, [sp, #3456]                ; 16-byte Reload
	ldr	q16, [sp, #3328]                ; 16-byte Reload
	ldr	q19, [sp, #3264]                ; 16-byte Reload
	ldr	q11, [sp, #3152]                ; 16-byte Reload
	ldr	q18, [sp, #11312]               ; 16-byte Reload
	mov.16b	v27, v1
	ldr	q25, [sp, #1520]                ; 16-byte Reload
	b	LBB0_127
LBB0_125:                               ; %direct.true549.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q0, [sp, #4848]                 ; 16-byte Reload
	str	q0, [sp, #20912]
	ldr	q0, [sp, #4832]                 ; 16-byte Reload
	str	q0, [sp, #20928]
	ldr	q0, [sp, #4816]                 ; 16-byte Reload
	str	q0, [sp, #20944]
	ldr	q0, [sp, #4800]                 ; 16-byte Reload
	str	q0, [sp, #20960]
	ldr	x11, [sp, #248]                 ; 8-byte Reload
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #432
	ldr	x8, [x8, x11]
	ldr	x9, [sp, #1304]                 ; 8-byte Reload
	sub	x8, x8, x9
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x13, x8
	ldp	q5, q2, [x8, #32]
	ldp	q7, q6, [x8]
	str	q4, [sp, #20848]
	str	q16, [sp, #20864]
	str	q17, [sp, #20880]
	str	q20, [sp, #20896]
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #368
	ldr	x8, [x8, x11]
	sub	x8, x8, x9
	ldr	x11, [sp, #240]                 ; 8-byte Reload
	ldr	x13, [sp, #1016]                ; 8-byte Reload
	add	x3, sp, #5, lsl #12             ; =20480
	add	x3, x3, #304
	mov	x5, #-3                         ; =0xfffffffffffffffd
	add	x6, sp, #5, lsl #12             ; =20480
	add	x6, x6, #112
	ldr	q12, [sp, #3456]                ; 16-byte Reload
	ldr	q16, [sp, #3328]                ; 16-byte Reload
	ldr	q19, [sp, #3264]                ; 16-byte Reload
	ldr	q11, [sp, #3152]                ; 16-byte Reload
	ldr	q18, [sp, #11312]               ; 16-byte Reload
	mov.16b	v27, v1
	ldr	q25, [sp, #1520]                ; 16-byte Reload
LBB0_126:                               ; %direct.true549
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	b0, v3[4]
	mov.b	v0[4], v3[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	mov.16b	v1, v0
	bsl.16b	v1, v5, v11
	mov	b4, v3[6]
	mov.b	v4[4], v3[7]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v20, v4, #0
	mov.16b	v21, v20
	bsl.16b	v21, v2, v19
	mov	b4, v3[0]
	mov.b	v4[4], v3[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v17, v4, #0
	mov.16b	v22, v17
	bsl.16b	v22, v7, v16
	mov	b4, v3[2]
	mov.b	v4[4], v3[3]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	mov	b23, v26[2]
	mov.b	v23[4], v26[3]
	mov.16b	v28, v4
	bsl.16b	v28, v6, v12
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmge.2d	v23, v23, #0
	and.16b	v12, v23, v28
	mov	b23, v26[0]
	mov.b	v23[4], v26[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmge.2d	v23, v23, #0
	and.16b	v16, v23, v22
	mov	b22, v26[6]
	mov.b	v22[4], v26[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmge.2d	v22, v22, #0
	and.16b	v19, v22, v21
	mov	b21, v26[4]
	mov.b	v21[4], v26[5]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmge.2d	v21, v21, #0
	and.16b	v11, v21, v1
	dup.2d	v1, x17
	add.2d	v21, v11, v1
	add.2d	v22, v19, v1
	add.2d	v23, v16, v1
	add.2d	v1, v12, v1
	str	q27, [sp, #20784]
	str	q15, [sp, #20800]
	str	q24, [sp, #20816]
	str	q13, [sp, #20832]
	ldr	x9, [x3, x11, lsl #3]
	add	x9, x8, x9, lsl #6
	tst	w10, #0xff
	csel	x9, xzr, x9, eq
	add	x9, x14, x9
	ldp	q28, q29, [x9, #32]
	ldp	q8, q9, [x9]
	bif.16b	v1, v9, v4
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	mov.16b	v4, v17
	bsl.16b	v4, v23, v8
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	mov.16b	v17, v20
	bsl.16b	v17, v22, v29
	ldr	q20, [sp, #11360]               ; 16-byte Reload
	bsl.16b	v0, v21, v28
	mov.16b	v28, v20
	stp	q0, q17, [x9, #32]
	stp	q4, q1, [x9]
	add.2d	v15, v15, v20
	add.2d	v24, v24, v23
	add.2d	v13, v13, v9
	add.2d	v27, v27, v8
	fmov	x9, d27
	cmp	x9, #1
	b.lt	LBB0_126
LBB0_127:                               ; %direct.false550
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q13, [sp, #3568]                ; 16-byte Spill
	str	q11, [sp, #3152]                ; 16-byte Spill
	str	q19, [sp, #3264]                ; 16-byte Spill
	str	q16, [sp, #3328]                ; 16-byte Spill
	str	q12, [sp, #3456]                ; 16-byte Spill
	str	q24, [sp, #3472]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q20, [sp, #6896]                ; 16-byte Reload
	ldr	q2, [sp, #5296]                 ; 16-byte Reload
	bit.16b	v20, v2, v10
	ldr	q4, [sp, #6928]                 ; 16-byte Reload
	ldr	q2, [sp, #5280]                 ; 16-byte Reload
	bit.16b	v4, v2, v14
	ldr	q17, [sp, #6912]                ; 16-byte Reload
	ldr	q2, [sp, #5264]                 ; 16-byte Reload
	bit.16b	v17, v2, v1
	ldr	q19, [sp, #6944]                ; 16-byte Reload
	ldr	q2, [sp, #5248]                 ; 16-byte Reload
	bit.16b	v19, v2, v0
	ldr	q21, [sp, #3424]                ; 16-byte Reload
	bic.16b	v21, v21, v10
	ldr	q2, [sp, #5184]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	str	q2, [sp, #5184]                 ; 16-byte Spill
	ldr	q16, [sp, #3392]                ; 16-byte Reload
	bic.16b	v16, v16, v1
	ldr	q12, [sp, #3408]                ; 16-byte Reload
	bic.16b	v12, v12, v0
	fmov	x8, d12
	cmp	x8, #0
	str	q27, [sp, #3520]                ; 16-byte Spill
	str	q19, [sp, #6944]                ; 16-byte Spill
	str	q4, [sp, #6928]                 ; 16-byte Spill
	str	q17, [sp, #6912]                ; 16-byte Spill
	str	q20, [sp, #6896]                ; 16-byte Spill
	b.le	LBB0_129
; %bb.128:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	q24, [sp, #5184]                ; 16-byte Reload
	ldr	q11, [sp, #3376]                ; 16-byte Reload
	ldr	q19, [sp, #3280]                ; 16-byte Reload
	ldr	q13, [sp, #3184]                ; 16-byte Reload
	ldr	q2, [sp, #3104]                 ; 16-byte Reload
	mov.16b	v27, v21
	b	LBB0_131
LBB0_129:                               ; %direct.true564.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q0, [sp, #4784]                 ; 16-byte Reload
	str	q0, [sp, #20720]
	ldr	q0, [sp, #4768]                 ; 16-byte Reload
	str	q0, [sp, #20736]
	ldr	q0, [sp, #4752]                 ; 16-byte Reload
	str	q0, [sp, #20752]
	ldr	q0, [sp, #4736]                 ; 16-byte Reload
	str	q0, [sp, #20768]
	ldr	x11, [sp, #232]                 ; 8-byte Reload
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #240
	ldr	x8, [x8, x11]
	ldr	x9, [sp, #1304]                 ; 8-byte Reload
	sub	x8, x8, x9
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x14, x8
	ldp	q5, q0, [x8, #32]
	str	q0, [sp, #10720]                ; 16-byte Spill
	ldp	q7, q6, [x8]
	str	q19, [sp, #20656]
	str	q4, [sp, #20672]
	str	q17, [sp, #20688]
	str	q20, [sp, #20704]
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #176
	ldr	x8, [x8, x11]
	sub	x8, x8, x9
	add	x11, sp, #6, lsl #12            ; =24576
	add	x11, x11, #2520
	ldr	q24, [sp, #5184]                ; 16-byte Reload
	ldr	q11, [sp, #3376]                ; 16-byte Reload
	ldr	q19, [sp, #3280]                ; 16-byte Reload
	ldr	q13, [sp, #3184]                ; 16-byte Reload
	ldr	q2, [sp, #3104]                 ; 16-byte Reload
	mov.16b	v27, v21
LBB0_130:                               ; %direct.true564
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	mov	b0, v3[4]
	mov.b	v0[4], v3[5]
	ushll.2d	v0, v0, #0
	shl.2d	v0, v0, #63
	cmlt.2d	v0, v0, #0
	mov.16b	v1, v0
	bsl.16b	v1, v5, v2
	mov	b4, v3[6]
	mov.b	v4[4], v3[7]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v17, v4, #0
	ldr	q2, [sp, #10720]                ; 16-byte Reload
	mov.16b	v21, v17
	bsl.16b	v21, v2, v13
	mov	b4, v3[0]
	mov.b	v4[4], v3[1]
	ushll.2d	v4, v4, #0
	shl.2d	v4, v4, #63
	cmlt.2d	v4, v4, #0
	mov.16b	v22, v4
	bsl.16b	v22, v7, v19
	mov	b20, v3[2]
	mov.b	v20[4], v3[3]
	ushll.2d	v20, v20, #0
	shl.2d	v20, v20, #63
	cmlt.2d	v20, v20, #0
	mov	b23, v26[2]
	mov.b	v23[4], v26[3]
	mov.16b	v28, v20
	bsl.16b	v28, v6, v11
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmge.2d	v23, v23, #0
	and.16b	v11, v23, v28
	mov	b23, v26[0]
	mov.b	v23[4], v26[1]
	ushll.2d	v23, v23, #0
	shl.2d	v23, v23, #63
	cmge.2d	v23, v23, #0
	and.16b	v19, v23, v22
	mov	b22, v26[6]
	mov.b	v22[4], v26[7]
	ushll.2d	v22, v22, #0
	shl.2d	v22, v22, #63
	cmge.2d	v22, v22, #0
	and.16b	v13, v22, v21
	mov	b21, v26[4]
	mov.b	v21[4], v26[5]
	ushll.2d	v21, v21, #0
	shl.2d	v21, v21, #63
	cmge.2d	v21, v21, #0
	and.16b	v2, v21, v1
	dup.2d	v1, x5
	add.2d	v21, v2, v1
	add.2d	v22, v13, v1
	add.2d	v23, v19, v1
	add.2d	v1, v11, v1
	str	q12, [sp, #20592]
	str	q24, [sp, #20608]
	str	q16, [sp, #20624]
	str	q27, [sp, #20640]
	ldr	x9, [x6, x13, lsl #3]
	add	x9, x8, x9, lsl #6
	tst	w10, #0xff
	csel	x9, xzr, x9, eq
	add	x9, x11, x9
	ldp	q28, q29, [x9, #32]
	ldp	q8, q9, [x9]
	bif.16b	v1, v9, v20
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	bsl.16b	v4, v23, v8
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	bsl.16b	v17, v22, v29
	ldr	q20, [sp, #11360]               ; 16-byte Reload
	bsl.16b	v0, v21, v28
	mov.16b	v28, v20
	stp	q0, q17, [x9, #32]
	stp	q4, q1, [x9]
	add.2d	v24, v24, v20
	add.2d	v16, v16, v23
	add.2d	v27, v27, v9
	add.2d	v12, v12, v8
	fmov	x9, d12
	cmp	x9, #1
	b.lt	LBB0_130
LBB0_131:                               ; %direct.false565
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q27, [sp, #3424]                ; 16-byte Spill
	str	q2, [sp, #3104]                 ; 16-byte Spill
	str	q13, [sp, #3184]                ; 16-byte Spill
	str	q19, [sp, #3280]                ; 16-byte Spill
	str	q11, [sp, #3376]                ; 16-byte Spill
	str	q16, [sp, #3392]                ; 16-byte Spill
	str	q12, [sp, #3408]                ; 16-byte Spill
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #2520
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #1264]                 ; 16-byte Reload
	ldr	q3, [sp, #9520]                 ; 16-byte Reload
	bit.16b	v3, v2, v10
	str	q3, [sp, #9520]                 ; 16-byte Spill
	ldr	q3, [sp, #9408]                 ; 16-byte Reload
	bit.16b	v3, v2, v14
	str	q3, [sp, #9408]                 ; 16-byte Spill
	ldr	q3, [sp, #9392]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #9392]                 ; 16-byte Spill
	ldr	q3, [sp, #9424]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9424]                 ; 16-byte Spill
	ldr	q2, [sp, #9456]                 ; 16-byte Reload
	ldr	q3, [sp, #1584]                 ; 16-byte Reload
	bit.16b	v2, v3, v10
	str	q2, [sp, #9456]                 ; 16-byte Spill
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	ldr	q3, [sp, #1568]                 ; 16-byte Reload
	bit.16b	v2, v3, v14
	str	q2, [sp, #9488]                 ; 16-byte Spill
	ldr	q2, [sp, #9472]                 ; 16-byte Reload
	ldr	q3, [sp, #1552]                 ; 16-byte Reload
	bit.16b	v2, v3, v1
	str	q2, [sp, #9472]                 ; 16-byte Spill
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	ldr	q3, [sp, #9504]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #9504]                 ; 16-byte Spill
	ldr	q2, [sp, #9872]                 ; 16-byte Reload
	bic.16b	v2, v2, v10
	str	q2, [sp, #9872]                 ; 16-byte Spill
	ldr	q2, [sp, #3360]                 ; 16-byte Reload
	bic.16b	v2, v2, v14
	ldr	q26, [sp, #9440]                ; 16-byte Reload
	bic.16b	v26, v26, v1
	ldr	q27, [sp, #3344]                ; 16-byte Reload
	bic.16b	v27, v27, v0
	fmov	x8, d27
	cmp	x8, #17
	str	q15, [sp, #3504]                ; 16-byte Spill
	str	q24, [sp, #5184]                ; 16-byte Spill
	b.gt	LBB0_150
; %bb.132:                              ; %direct.true579.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q4, [sp, #10560]                ; 16-byte Reload
	ldr	q7, [sp, #10592]                ; 16-byte Reload
	ldr	q11, [sp, #9872]                ; 16-byte Reload
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	ldr	q29, [sp, #11136]               ; 16-byte Reload
	b	LBB0_134
LBB0_133:                               ; %else567
                                        ;   in Loop: Header=BB0_134 Depth=2
	add.2d	v2, v2, v28
	add.2d	v26, v26, v23
	add.2d	v11, v11, v9
	add.2d	v27, v27, v8
	fmov	x8, d27
	cmp	x8, #18
	b.ge	LBB0_151
LBB0_134:                               ; %direct.true579
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v23, v31, #0
	sshll.2d	v9, v30, #0
	and.16b	v0, v9, v27
	mov.16b	v12, v27
	mov.16b	v24, v2
	and.16b	v5, v14, v2
	str	q26, [sp, #9440]                ; 16-byte Spill
	and.16b	v2, v23, v26
	str	q11, [sp, #9872]                ; 16-byte Spill
	and.16b	v6, v10, v11
	fmov	x8, d6
	fmov	x9, d7
	sdiv	x8, x8, x9
	mov.d	x10, v6[1]
	mul	x9, x8, x9
	fmov	d1, x8
	sdiv	x8, x10, x28
	mov.d	v1[1], x8
	fmov	x10, d2
	fmov	x11, d4
	sdiv	x10, x10, x11
	mul	x11, x10, x11
	fmov	d4, x10
	mov.d	x10, v2[1]
	sdiv	x10, x10, x30
	mov.d	v4[1], x10
	fmov	x13, d5
	ldr	q7, [sp, #10528]                ; 16-byte Reload
	fmov	x17, d7
	sdiv	x13, x13, x17
	mul	x17, x13, x17
	fmov	d21, x13
	mov.d	x13, v5[1]
	sdiv	x13, x13, x19
	mov.d	v21[1], x13
	fmov	x3, d0
	ldr	q7, [sp, #10544]                ; 16-byte Reload
	fmov	x5, d7
	sdiv	x3, x3, x5
	mov.d	x6, v0[1]
	mul	x5, x3, x5
	fmov	d22, x3
	sdiv	x3, x6, x12
	mov.d	v22[1], x3
	mul	x8, x8, x28
	fmov	d17, x9
	mov.d	v17[1], x8
	mul	x8, x13, x19
	fmov	d7, x17
	mov.d	v7[1], x8
	mul	x8, x10, x30
	fmov	d20, x11
	mov.d	v20[1], x8
	mul	x8, x3, x12
	fmov	d28, x5
	mov.d	v28[1], x8
	sub.2d	v0, v0, v28
	sub.2d	v2, v2, v20
	sub.2d	v7, v5, v7
	sub.2d	v20, v6, v17
	and.16b	v1, v10, v1
	mov.d	x8, v1[1]
	sdiv	x9, x8, x26
	msub	x8, x9, x26, x8
	fmov	x9, d1
	ldr	q1, [sp, #11296]                ; 16-byte Reload
	fmov	x10, d1
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d17, x9
	mov.d	v17[1], x8
	and.16b	v1, v23, v4
	mov.d	x8, v1[1]
	sdiv	x9, x8, x22
	msub	x8, x9, x22, x8
	fmov	x9, d1
	fmov	x10, d18
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d1, x9
	mov.d	v1[1], x8
	and.16b	v4, v14, v21
	mov.d	x8, v4[1]
	sdiv	x9, x8, x23
	msub	x8, x9, x23, x8
	fmov	x9, d4
	ldr	q4, [sp, #10608]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	and.16b	v5, v9, v22
	mov.d	x8, v5[1]
	sdiv	x9, x8, x25
	msub	x8, x9, x25, x8
	fmov	x9, d5
	fmov	x10, d29
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d22, x9
	mov.d	v22[1], x8
	shl.2d	v8, v22, #3
	shl.2d	v11, v4, #3
	shl.2d	v29, v1, #3
	shl.2d	v13, v17, #3
	ldr	q16, [sp, #10480]               ; 16-byte Reload
	cmgt.2d	v10, v16, v13
	ldr	q27, [sp, #10512]               ; 16-byte Reload
	cmgt.2d	v15, v27, v29
	uzp1.4s	v21, v15, v10
	ldr	q19, [sp, #10496]               ; 16-byte Reload
	cmgt.2d	v26, v19, v11
	ldr	q14, [sp, #10576]               ; 16-byte Reload
	cmgt.2d	v28, v14, v8
	uzp1.4s	v5, v28, v26
	uzp1.8h	v5, v5, v21
	ldr	q6, [sp, #11376]                ; 16-byte Reload
	and.16b	v5, v6, v5
	xtn.8b	v5, v5
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	ldr	d18, [sp, #11400]               ; 8-byte Reload
	and.8b	v21, v5, v18
	addv.8b	b21, v21
	fmov	w6, s21
	umaxv.8b	b5, v5
	fmov	w8, s5
	rbit	w9, w6
	clz	w9, w9
	tst	w8, #0x1
	csel	w8, w9, wzr, ne
	ldr	q5, [sp, #9568]                 ; 16-byte Reload
	str	q5, [sp, #20464]
	ldr	q5, [sp, #9552]                 ; 16-byte Reload
	str	q5, [sp, #20480]
	ldr	q5, [sp, #9536]                 ; 16-byte Reload
	str	q5, [sp, #20496]
	ldr	q5, [sp, #9600]                 ; 16-byte Reload
	str	q5, [sp, #20512]
	lsl	w8, w8, #3
	and	x9, x8, #0x38
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #4080
	ldr	x10, [x10, x9]
	str	q17, [sp, #20576]
	and.16b	v28, v9, v28
	ldr	q5, [sp, #11344]                ; 16-byte Reload
	and.16b	v21, v5, v26
	and.16b	v5, v23, v15
	ldr	q17, [sp, #11328]               ; 16-byte Reload
	and.16b	v17, v17, v10
	str	q1, [sp, #20560]
	str	q4, [sp, #20544]
	str	q22, [sp, #20528]
	add	x11, sp, #5, lsl #12            ; =20480
	add	x11, x11, #48
	ldr	x9, [x11, x9]
	and	x8, x8, #0xf8
	sub	x8, x10, x8
	add	x8, x8, x9, lsl #6
	tst	w6, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x15, x8
	ldp	q4, q1, [x8, #32]
	bif.16b	v1, v25, v17
	str	q1, [sp, #10720]                ; 16-byte Spill
	ldp	q10, q1, [x8]
	ldr	q17, [sp, #7840]                ; 16-byte Reload
	bif.16b	v4, v17, v5
	str	q4, [sp, #10704]                ; 16-byte Spill
	ldr	q4, [sp, #11328]                ; 16-byte Reload
	and.16b	v17, v4, v20
	ldr	q4, [sp, #11344]                ; 16-byte Reload
	and.16b	v7, v4, v7
	and.16b	v2, v23, v2
	and.16b	v0, v9, v0
	mov.d	x8, v0[1]
	ldr	q4, [sp, #11040]                ; 16-byte Reload
	mov.d	x9, v4[1]
	sdiv	x8, x8, x9
	fmov	x10, d0
	fmov	x11, d4
	sdiv	x13, x10, x11
	mov.d	x10, v2[1]
	ldr	q4, [sp, #11056]                ; 16-byte Reload
	mov.d	x5, v4[1]
	sdiv	x10, x10, x5
	fmov	x17, d2
	fmov	x3, d4
	sdiv	x17, x17, x3
	mul	x23, x17, x3
	fmov	d20, x17
	mov.d	v20[1], x10
	mov.d	x3, v7[1]
	ldr	q5, [sp, #11152]                ; 16-byte Reload
	mov.d	x24, v5[1]
	fmov	x17, d7
	mul	x11, x13, x11
	fmov	d4, x11
	mov.d	x11, v17[1]
	mul	x9, x8, x9
	mov.d	v4[1], x9
	fmov	x9, d5
	sdiv	x17, x17, x9
	mul	x9, x17, x9
	fmov	d5, x9
	ldr	q22, [sp, #11168]               ; 16-byte Reload
	mov.d	x9, v22[1]
	ldr	q25, [sp, #7856]                ; 16-byte Reload
	bif.16b	v1, v25, v21
	str	q1, [sp, #10688]                ; 16-byte Spill
	sdiv	x3, x3, x24
	mul	x24, x3, x24
	mov.d	v5[1], x24
	fmov	x24, d17
	mul	x10, x10, x5
	fmov	x5, d22
	fmov	d1, x23
	mov.d	v1[1], x10
	sdiv	x10, x11, x9
	mul	x9, x10, x9
	sdiv	x11, x24, x5
	mul	x5, x11, x5
	fmov	d26, x5
	mov.d	v26[1], x9
	bsl.16b	v28, v10, v3
	sub.2d	v17, v17, v26
	sub.2d	v2, v2, v1
	sub.2d	v7, v7, v5
	sub.2d	v1, v0, v4
	ldr	q0, [sp, #11248]                ; 16-byte Reload
	cmeq.2d	v0, v0, v17
	ldr	q4, [sp, #11232]                ; 16-byte Reload
	cmeq.2d	v4, v4, v2
	uzp1.4s	v5, v4, v0
	ldr	q21, [sp, #11200]               ; 16-byte Reload
	cmeq.2d	v10, v21, v7
	ldr	q21, [sp, #11264]               ; 16-byte Reload
	cmeq.2d	v15, v21, v1
	uzp1.4s	v26, v15, v10
	uzp1.8h	v5, v26, v5
	and.16b	v5, v6, v5
	xtn.8b	v5, v5
	shl.8b	v5, v5, #7
	cmlt.8b	v5, v5, #0
	and.8b	v26, v5, v18
	addv.8b	b26, v26
	fmov	w9, s26
	umaxv.8b	b5, v5
	fmov	w5, s5
	fmov	d5, x11
	mov.d	v5[1], x10
	rbit	w10, w9
	clz	w10, w10
	tst	w5, #0x1
	csel	w10, w10, wzr, ne
	ldr	q3, [sp, #6944]                 ; 16-byte Reload
	str	q3, [sp, #20336]
	ldr	q6, [sp, #6928]                 ; 16-byte Reload
	str	q6, [sp, #20352]
	ldr	q6, [sp, #6912]                 ; 16-byte Reload
	str	q6, [sp, #20368]
	ldr	q6, [sp, #6896]                 ; 16-byte Reload
	str	q6, [sp, #20384]
	lsl	w10, w10, #3
	and	x11, x10, #0x38
	add	x5, sp, #4, lsl #12             ; =16384
	add	x5, x5, #3952
	ldr	x5, [x5, x11]
	str	q5, [sp, #20448]
	fmov	d5, x13
	mov.d	v5[1], x8
	str	q20, [sp, #20432]
	fmov	d20, x17
	mov.d	v20[1], x3
	str	q20, [sp, #20416]
	str	q5, [sp, #20400]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #4016
	ldr	x8, [x8, x11]
	ldr	q5, [sp, #11328]                ; 16-byte Reload
	and.16b	v5, v5, v0
	and	x10, x10, #0xf8
	sub	x10, x5, x10
	add	x8, x10, x8, lsl #6
	tst	w9, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x14, x8
	ldp	q20, q3, [x8, #32]
	ldr	q6, [sp, #8592]                 ; 16-byte Reload
	bsl.16b	v5, v3, v6
	and.16b	v26, v23, v4
	ldr	q6, [sp, #8656]                 ; 16-byte Reload
	bif.16b	v20, v6, v26
	ldr	q21, [sp, #11344]               ; 16-byte Reload
	and.16b	v26, v21, v10
	ldr	q22, [x8, #16]
	ldr	q6, [sp, #8736]                 ; 16-byte Reload
	bif.16b	v22, v6, v26
	ldr	q26, [x8]
	and.16b	v21, v9, v15
	ldr	q6, [sp, #8624]                 ; 16-byte Reload
	bsl.16b	v21, v26, v6
	cmge.2d	v26, v8, v14
	and.16b	v26, v9, v26
	bic.16b	v3, v28, v26
	ldr	q18, [sp, #8784]                ; 16-byte Reload
	bit.16b	v18, v1, v9
	ldr	q1, [sp, #11344]                ; 16-byte Reload
	ldr	q25, [sp, #8768]                ; 16-byte Reload
	bit.16b	v25, v7, v1
	ldr	q7, [sp, #8752]                 ; 16-byte Reload
	bit.16b	v7, v2, v23
	ldr	q1, [sp, #11328]                ; 16-byte Reload
	ldr	q6, [sp, #8800]                 ; 16-byte Reload
	bit.16b	v6, v17, v1
	cmge.2d	v1, v29, v27
	and.16b	v2, v23, v1
	bic.16b	v1, v23, v4
	bic.16b	v4, v9, v15
	ldr	q17, [sp, #11328]               ; 16-byte Reload
	bic.16b	v21, v21, v4
	ldr	q4, [sp, #11344]                ; 16-byte Reload
	bic.16b	v4, v4, v10
	mov.16b	v10, v17
	ldr	q14, [sp, #11344]               ; 16-byte Reload
	bic.16b	v4, v22, v4
	bic.16b	v17, v20, v1
	bic.16b	v0, v10, v0
	bic.16b	v5, v5, v0
	str	q18, [sp, #8784]                ; 16-byte Spill
	xtn.2s	v0, v18
	mov.s	w8, v0[1]
	fmov	w3, s0
	str	q25, [sp, #8768]                ; 16-byte Spill
	xtn.2s	v0, v25
	mov.s	w13, v0[1]
	fmov	w23, s0
	str	q7, [sp, #8752]                 ; 16-byte Spill
	xtn.2s	v0, v7
	mov.s	w17, v0[1]
	fmov	w24, s0
	str	q6, [sp, #8800]                 ; 16-byte Spill
	xtn.2s	v0, v6
	mov.s	w5, v0[1]
	fmov	w26, s0
	cmp	w3, #8
	csel	w9, w3, wzr, lo
	cset	w10, lo
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #3432
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	str	d0, [sp, #19816]
	ldrb	w11, [x11]
	and	w11, w0, w11
	str	q5, [sp, #20320]
	str	q17, [sp, #20304]
	str	q4, [sp, #20288]
	str	q21, [sp, #20272]
	add	x3, sp, #4, lsl #12             ; =16384
	add	x3, x3, #3888
	ldr	x9, [x3, x9, lsl #3]
	tst	w10, w11
	csel	x3, x9, xzr, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #3432
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	ldr	w11, [sp, #10420]               ; 4-byte Reload
	and	w10, w11, w10
	str	q5, [sp, #20256]
	str	q17, [sp, #20240]
	str	q4, [sp, #20224]
	str	q21, [sp, #20208]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #3824
	ldr	x8, [x11, x8, lsl #3]
	tst	w9, w10
	csel	x25, x8, xzr, ne
	cmp	w23, #8
	csel	w8, w23, wzr, lo
	cset	w9, lo
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #3432
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	and	w10, w1, w10
	str	q5, [sp, #20192]
	str	q17, [sp, #20176]
	str	q4, [sp, #20160]
	str	q21, [sp, #20144]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #3760
	ldr	x8, [x11, x8, lsl #3]
	tst	w9, w10
	csel	x8, x8, xzr, ne
	cmp	w13, #8
	csel	w9, w13, wzr, lo
	cset	w10, lo
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #3432
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w2, w11
	str	q5, [sp, #20128]
	str	q17, [sp, #20112]
	str	q4, [sp, #20096]
	str	q21, [sp, #20080]
	add	x13, sp, #4, lsl #12            ; =16384
	add	x13, x13, #3696
	ldr	x9, [x13, x9, lsl #3]
	tst	w10, w11
	csel	x13, x9, xzr, ne
	cmp	w24, #8
	csel	w9, w24, wzr, lo
	cset	w10, lo
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #3432
	bfxil	x11, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w11, [x11]
	and	w11, w7, w11
	str	q5, [sp, #20064]
	str	q17, [sp, #20048]
	str	q4, [sp, #20032]
	str	q21, [sp, #20016]
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #3632
	ldr	x9, [x23, x9, lsl #3]
	tst	w10, w11
	csel	x9, x9, xzr, ne
	cmp	w17, #8
	csel	w10, w17, wzr, lo
	cset	w11, lo
	add	x17, sp, #4, lsl #12            ; =16384
	add	x17, x17, #3432
	bfxil	x17, x10, #0, #3
	and	x10, x10, #0x7
	ldrb	w17, [x17]
	ldr	w23, [sp, #10092]               ; 4-byte Reload
	and	w17, w23, w17
	str	q5, [sp, #20000]
	str	q17, [sp, #19984]
	str	q4, [sp, #19968]
	str	q21, [sp, #19952]
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #3568
	ldr	x10, [x23, x10, lsl #3]
	tst	w11, w17
	csel	x10, x10, xzr, ne
	cmp	w26, #8
	csel	w11, w26, wzr, lo
	cset	w17, lo
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #3432
	bfxil	x23, x11, #0, #3
	and	x11, x11, #0x7
	ldrb	w23, [x23]
	and	w23, w21, w23
	str	q5, [sp, #19936]
	str	q17, [sp, #19920]
	str	q4, [sp, #19904]
	str	q21, [sp, #19888]
	add	x24, sp, #4, lsl #12            ; =16384
	add	x24, x24, #3504
	ldr	x11, [x24, x11, lsl #3]
	tst	w17, w23
	csel	x11, x11, xzr, ne
	cmp	w5, #8
	csel	w17, w5, wzr, lo
	cset	w5, lo
	add	x23, sp, #4, lsl #12            ; =16384
	add	x23, x23, #3432
	bfxil	x23, x17, #0, #3
	ldrb	w23, [x23]
	and	w23, w20, w23
	tst	w5, w23
	cmge.2d	v0, v11, v19
	and.16b	v0, v14, v0
	ldr	q1, [sp, #10688]                ; 16-byte Reload
	bic.16b	v7, v1, v0
	fmov	d0, x3
	mov.d	v0[1], x25
	ldr	q1, [sp, #10704]                ; 16-byte Reload
	bic.16b	v6, v1, v2
	fmov	d1, x9
	mov.d	v1[1], x10
	cmge.2d	v2, v13, v16
	and.16b	v2, v10, v2
	ldr	q16, [sp, #10720]               ; 16-byte Reload
	bic.16b	v25, v16, v2
	and	x9, x17, #0x7
	str	q5, [sp, #8592]                 ; 16-byte Spill
	str	q5, [sp, #19872]
	str	q17, [sp, #8656]                ; 16-byte Spill
	str	q17, [sp, #19856]
	str	q4, [sp, #8736]                 ; 16-byte Spill
	str	q4, [sp, #19840]
	str	q21, [sp, #8624]                ; 16-byte Spill
	str	q21, [sp, #19824]
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #3440
	ldr	x9, [x10, x9, lsl #3]
	fmov	d2, x11
	csel	x9, x9, xzr, ne
	mov.d	v2[1], x9
	cmge.2d	v2, v2, v25
	str	q6, [sp, #7840]                 ; 16-byte Spill
	cmge.2d	v1, v1, v6
	uzp1.4s	v1, v1, v2
	fmov	d2, x8
	mov.d	v2[1], x13
	str	q7, [sp, #7856]                 ; 16-byte Spill
	cmge.2d	v2, v2, v7
	cmge.2d	v0, v0, v3
	uzp1.4s	v0, v0, v2
	uzp1.8h	v0, v0, v1
	mov.16b	v5, v12
	ldr	q1, [sp, #9504]                 ; 16-byte Reload
	add.2d	v1, v12, v1
	ldr	q2, [sp, #9424]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	xtn.8b	v0, v0
	movi.8b	v2, #1
	and.8b	v0, v0, v2
	tbz	w6, #0, LBB0_136
; %bb.135:                              ; %cond.store536
                                        ;   in Loop: Header=BB0_134 Depth=2
	fmov	x8, d1
	str	b0, [x8]
LBB0_136:                               ; %else539
                                        ;   in Loop: Header=BB0_134 Depth=2
	tbz	w6, #1, LBB0_138
; %bb.137:                              ; %cond.store540
                                        ;   in Loop: Header=BB0_134 Depth=2
	mov.d	x8, v1[1]
	st1.b	{ v0 }[1], [x8]
LBB0_138:                               ; %else543
                                        ;   in Loop: Header=BB0_134 Depth=2
	mov.16b	v2, v24
	ldr	q1, [sp, #9488]                 ; 16-byte Reload
	add.2d	v1, v24, v1
	ldr	q4, [sp, #9408]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	ldr	q4, [sp, #10560]                ; 16-byte Reload
	ldr	q7, [sp, #10592]                ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q28, [sp, #11360]               ; 16-byte Reload
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	ldr	q18, [sp, #11312]               ; 16-byte Reload
	ldr	q29, [sp, #11136]               ; 16-byte Reload
	ldr	q26, [sp, #9440]                ; 16-byte Reload
	ldr	q11, [sp, #9872]                ; 16-byte Reload
	ldr	q12, [sp, #10384]               ; 16-byte Reload
	ldr	q17, [sp, #11120]               ; 16-byte Reload
	ldr	q20, [sp, #11104]               ; 16-byte Reload
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	ldr	x23, [sp, #10440]               ; 8-byte Reload
	ldr	x26, [sp, #10448]               ; 8-byte Reload
	tbnz	w6, #2, LBB0_144
; %bb.139:                              ; %else547
                                        ;   in Loop: Header=BB0_134 Depth=2
	mov.16b	v27, v5
	ldr	q6, [sp, #10256]                ; 16-byte Reload
	tbnz	w6, #3, LBB0_145
LBB0_140:                               ; %else551
                                        ;   in Loop: Header=BB0_134 Depth=2
	ldr	q1, [sp, #9472]                 ; 16-byte Reload
	add.2d	v1, v26, v1
	ldr	q5, [sp, #9392]                 ; 16-byte Reload
	add.2d	v1, v5, v1
	tbnz	w6, #4, LBB0_146
LBB0_141:                               ; %else555
                                        ;   in Loop: Header=BB0_134 Depth=2
	tbnz	w6, #5, LBB0_147
LBB0_142:                               ; %else559
                                        ;   in Loop: Header=BB0_134 Depth=2
	ldr	q1, [sp, #9456]                 ; 16-byte Reload
	add.2d	v1, v11, v1
	ldr	q5, [sp, #9520]                 ; 16-byte Reload
	add.2d	v1, v5, v1
	tbnz	w6, #6, LBB0_148
LBB0_143:                               ; %else563
                                        ;   in Loop: Header=BB0_134 Depth=2
	tbz	w6, #7, LBB0_133
	b	LBB0_149
LBB0_144:                               ; %cond.store544
                                        ;   in Loop: Header=BB0_134 Depth=2
	fmov	x8, d1
	st1.b	{ v0 }[2], [x8]
	mov.16b	v27, v5
	ldr	q6, [sp, #10256]                ; 16-byte Reload
	tbz	w6, #3, LBB0_140
LBB0_145:                               ; %cond.store548
                                        ;   in Loop: Header=BB0_134 Depth=2
	mov.d	x8, v1[1]
	st1.b	{ v0 }[3], [x8]
	ldr	q1, [sp, #9472]                 ; 16-byte Reload
	add.2d	v1, v26, v1
	ldr	q5, [sp, #9392]                 ; 16-byte Reload
	add.2d	v1, v5, v1
	tbz	w6, #4, LBB0_141
LBB0_146:                               ; %cond.store552
                                        ;   in Loop: Header=BB0_134 Depth=2
	fmov	x8, d1
	st1.b	{ v0 }[4], [x8]
	tbz	w6, #5, LBB0_142
LBB0_147:                               ; %cond.store556
                                        ;   in Loop: Header=BB0_134 Depth=2
	mov.d	x8, v1[1]
	st1.b	{ v0 }[5], [x8]
	ldr	q1, [sp, #9456]                 ; 16-byte Reload
	add.2d	v1, v11, v1
	ldr	q5, [sp, #9520]                 ; 16-byte Reload
	add.2d	v1, v5, v1
	tbz	w6, #6, LBB0_143
LBB0_148:                               ; %cond.store560
                                        ;   in Loop: Header=BB0_134 Depth=2
	fmov	x8, d1
	st1.b	{ v0 }[6], [x8]
	tbz	w6, #7, LBB0_133
LBB0_149:                               ; %cond.store564
                                        ;   in Loop: Header=BB0_134 Depth=2
	mov.d	x8, v1[1]
	st1.b	{ v0 }[7], [x8]
	b	LBB0_133
LBB0_150:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	q7, [sp, #10592]                ; 16-byte Reload
	ldr	q11, [sp, #9872]                ; 16-byte Reload
	ldr	q6, [sp, #10256]                ; 16-byte Reload
	ldr	q12, [sp, #10384]               ; 16-byte Reload
	ldr	q17, [sp, #11120]               ; 16-byte Reload
	ldr	q20, [sp, #11104]               ; 16-byte Reload
	ldr	q3, [sp, #3040]                 ; 16-byte Reload
	ldr	q29, [sp, #11136]               ; 16-byte Reload
LBB0_151:                               ; %direct.false580
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q11, [sp, #9872]                ; 16-byte Spill
	str	q2, [sp, #3360]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #1248]                 ; 16-byte Reload
	ldr	q4, [sp, #10288]                ; 16-byte Reload
	bit.16b	v4, v2, v10
	str	q4, [sp, #10288]                ; 16-byte Spill
	ldr	q4, [sp, #10192]                ; 16-byte Reload
	bit.16b	v4, v2, v14
	str	q4, [sp, #10192]                ; 16-byte Spill
	ldr	q4, [sp, #10176]                ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #10176]                ; 16-byte Spill
	ldr	q4, [sp, #10208]                ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #10208]                ; 16-byte Spill
	ldr	q2, [sp, #10224]                ; 16-byte Reload
	ldr	q4, [sp, #1584]                 ; 16-byte Reload
	bit.16b	v2, v4, v10
	str	q2, [sp, #10224]                ; 16-byte Spill
	ldr	q2, [sp, #1568]                 ; 16-byte Reload
	bit.16b	v6, v2, v14
	str	q6, [sp, #10256]                ; 16-byte Spill
	ldr	q2, [sp, #10240]                ; 16-byte Reload
	ldr	q4, [sp, #1552]                 ; 16-byte Reload
	bit.16b	v2, v4, v1
	str	q2, [sp, #10240]                ; 16-byte Spill
	ldr	q2, [sp, #1600]                 ; 16-byte Reload
	ldr	q4, [sp, #10272]                ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #10272]                ; 16-byte Spill
	ldr	q2, [sp, #5168]                 ; 16-byte Reload
	bic.16b	v2, v2, v10
	str	q2, [sp, #5168]                 ; 16-byte Spill
	ldr	q4, [sp, #3312]                 ; 16-byte Reload
	bic.16b	v4, v4, v14
	ldr	q2, [sp, #3296]                 ; 16-byte Reload
	bic.16b	v1, v2, v1
	ldr	q2, [sp, #3248]                 ; 16-byte Reload
	bic.16b	v2, v2, v0
	fmov	x8, d2
	cmp	x8, #17
	str	q25, [sp, #1520]                ; 16-byte Spill
	b.gt	LBB0_202
; %bb.152:                              ; %direct.true601.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q18, [sp, #10544]               ; 16-byte Reload
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #3360
	mov	w14, #62154                     ; =0xf2ca
	movk	w14, #61769, lsl #16
	ldr	q0, [sp, #5168]                 ; 16-byte Reload
	b	LBB0_154
LBB0_153:                               ; %else698
                                        ;   in Loop: Header=BB0_154 Depth=2
	add.2d	v4, v4, v28
	add.2d	v1, v11, v23
	add.2d	v0, v24, v9
	add.2d	v2, v2, v8
	fmov	x8, d2
	cmp	x8, #18
	b.ge	LBB0_203
LBB0_154:                               ; %direct.true601
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v6, v31, #0
	sshll.2d	v20, v30, #0
	mov.16b	v19, v2
	and.16b	v2, v20, v2
	mov.16b	v16, v4
	and.16b	v8, v14, v4
	mov.16b	v11, v1
	and.16b	v21, v6, v1
	mov.16b	v24, v0
	and.16b	v5, v10, v0
	fmov	x8, d5
	fmov	x5, d7
	sdiv	x6, x8, x5
	fmov	d0, x6
	mov.d	x8, v5[1]
	sdiv	x25, x8, x28
	mov.d	v0[1], x25
	fmov	x8, d21
	ldr	q1, [sp, #10560]                ; 16-byte Reload
	fmov	x26, d1
	sdiv	x27, x8, x26
	fmov	d1, x27
	mov.d	x8, v21[1]
	sdiv	x23, x8, x30
	mov.d	v1[1], x23
	fmov	x8, d8
	ldr	q4, [sp, #10528]                ; 16-byte Reload
	fmov	x30, d4
	sdiv	x17, x8, x30
	fmov	d4, x17
	mov.d	x8, v8[1]
	ldr	x9, [sp, #10432]                ; 8-byte Reload
	sdiv	x8, x8, x9
	mov.d	v4[1], x8
	fmov	x9, d2
	fmov	x24, d18
	sdiv	x3, x9, x24
	fmov	d17, x3
	mov.d	x9, v2[1]
	sdiv	x28, x9, x12
	mov.d	v17[1], x28
	mov.16b	v15, v10
	and.16b	v0, v10, v0
	mov.d	x9, v0[1]
	and.16b	v1, v6, v1
	ldr	x11, [sp, #10448]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d0
	ldr	q0, [sp, #11296]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	fmov	d22, x10
	mov.d	v22[1], x9
	mov.d	x9, v1[1]
	and.16b	v0, v14, v4
	sdiv	x10, x9, x22
	msub	x9, x10, x22, x9
	fmov	x10, d1
	ldr	q1, [sp, #11312]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	fmov	d7, x10
	mov.d	v7[1], x9
	mov.d	x9, v0[1]
	and.16b	v1, v20, v17
	ldr	x11, [sp, #10440]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d0
	ldr	q0, [sp, #10608]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	fmov	d28, x10
	mov.d	v28[1], x9
	mov.d	x9, v1[1]
	ldr	x11, [sp, #10464]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	fmov	x10, d1
	fmov	x11, d29
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	shl.2d	v1, v0, #3
	shl.2d	v4, v28, #3
	shl.2d	v17, v7, #3
	shl.2d	v23, v22, #3
	ldr	q18, [sp, #10480]               ; 16-byte Reload
	cmgt.2d	v23, v18, v23
	ldr	q18, [sp, #10512]               ; 16-byte Reload
	cmgt.2d	v17, v18, v17
	uzp1.4s	v17, v17, v23
	ldr	q18, [sp, #10496]               ; 16-byte Reload
	cmgt.2d	v4, v18, v4
	ldr	q23, [sp, #10576]               ; 16-byte Reload
	cmgt.2d	v1, v23, v1
	uzp1.4s	v1, v1, v4
	uzp1.8h	v10, v1, v17
	ldr	q1, [sp, #11376]                ; 16-byte Reload
	and.16b	v1, v1, v10
	xtn.8b	v1, v1
	shl.8b	v1, v1, #7
	cmlt.8b	v23, v1, #0
	ldr	d1, [sp, #11400]                ; 8-byte Reload
	and.8b	v1, v23, v1
	addv.8b	b9, v1
	fmov	w13, s9
	ldr	q1, [sp, #9664]                 ; 16-byte Reload
	ldr	q4, [sp, #9616]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	add.2d	v1, v1, v0
	tbz	w13, #0, LBB0_156
; %bb.155:                              ; %cond.load569
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	ldr	b29, [x9]
	ldr	q17, [sp, #11120]               ; 16-byte Reload
	tbnz	w13, #1, LBB0_157
	b	LBB0_158
LBB0_156:                               ;   in Loop: Header=BB0_154 Depth=2
	movi.2d	v29, #0000000000000000
	ldr	q17, [sp, #11120]               ; 16-byte Reload
	tbz	w13, #1, LBB0_158
LBB0_157:                               ; %cond.load575
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x9, v1[1]
	ld1.b	{ v29 }[1], [x9]
LBB0_158:                               ; %else579
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q1, [sp, #9712]                 ; 16-byte Reload
	ldr	q4, [sp, #9648]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	add.2d	v1, v1, v28
	tbnz	w13, #2, LBB0_167
; %bb.159:                              ; %else585
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w13, #3, LBB0_168
LBB0_160:                               ; %else591
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q1, [sp, #9696]                 ; 16-byte Reload
	ldr	q4, [sp, #9632]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	add.2d	v1, v1, v7
	tbnz	w13, #4, LBB0_169
LBB0_161:                               ; %else597
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w13, #5, LBB0_170
LBB0_162:                               ; %else603
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q1, [sp, #9680]                 ; 16-byte Reload
	ldr	q4, [sp, #9728]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	add.2d	v1, v1, v22
	tbnz	w13, #6, LBB0_171
LBB0_163:                               ; %else609
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbz	w13, #7, LBB0_165
LBB0_164:                               ; %cond.load611
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x9, v1[1]
	ld1.b	{ v29 }[7], [x9]
LBB0_165:                               ; %else615
                                        ;   in Loop: Header=BB0_154 Depth=2
	mul	x9, x28, x12
	mul	x10, x3, x24
	fmov	d1, x10
	mov.d	v1[1], x9
	sub.2d	v1, v2, v1
	ldr	q2, [sp, #8704]                 ; 16-byte Reload
	bit.16b	v2, v1, v20
	ldr	q1, [sp, #8608]                 ; 16-byte Reload
	bit.16b	v1, v0, v20
	str	q1, [sp, #8608]                 ; 16-byte Spill
	add.2d	v0, v1, v1
	fmov	w13, s9
	str	q2, [sp, #8704]                 ; 16-byte Spill
	ldr	q1, [sp, #9504]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	ldr	q2, [sp, #9424]                 ; 16-byte Reload
	add.2d	v1, v2, v1
	add.2d	v1, v1, v0
	tbz	w13, #0, LBB0_172
; %bb.166:                              ; %cond.load618
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	ldr	b0, [x9]
	ldr	x28, [sp, #9896]                ; 8-byte Reload
	ldr	q20, [sp, #11104]               ; 16-byte Reload
	tbnz	w13, #1, LBB0_173
	b	LBB0_174
LBB0_167:                               ; %cond.load581
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	ld1.b	{ v29 }[2], [x9]
	tbz	w13, #3, LBB0_160
LBB0_168:                               ; %cond.load587
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x9, v1[1]
	ld1.b	{ v29 }[3], [x9]
	ldr	q1, [sp, #9696]                 ; 16-byte Reload
	ldr	q4, [sp, #9632]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	add.2d	v1, v1, v7
	tbz	w13, #4, LBB0_161
LBB0_169:                               ; %cond.load593
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	ld1.b	{ v29 }[4], [x9]
	tbz	w13, #5, LBB0_162
LBB0_170:                               ; %cond.load599
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x9, v1[1]
	ld1.b	{ v29 }[5], [x9]
	ldr	q1, [sp, #9680]                 ; 16-byte Reload
	ldr	q4, [sp, #9728]                 ; 16-byte Reload
	add.2d	v1, v1, v4
	add.2d	v1, v1, v22
	tbz	w13, #6, LBB0_163
LBB0_171:                               ; %cond.load605
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	ld1.b	{ v29 }[6], [x9]
	tbnz	w13, #7, LBB0_164
	b	LBB0_165
LBB0_172:                               ;   in Loop: Header=BB0_154 Depth=2
	movi.2d	v0, #0000000000000000
	ldr	x28, [sp, #9896]                ; 8-byte Reload
	ldr	q20, [sp, #11104]               ; 16-byte Reload
	tbz	w13, #1, LBB0_174
LBB0_173:                               ; %cond.load624
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x9, v1[1]
	ld1.b	{ v0 }[1], [x9]
LBB0_174:                               ; %else628
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	x9, [sp, #10432]                ; 8-byte Reload
	mul	x8, x8, x9
	mul	x9, x17, x30
	fmov	d1, x9
	mov.d	v1[1], x8
	sub.2d	v1, v8, v1
	ldr	q2, [sp, #11344]                ; 16-byte Reload
	ldr	q4, [sp, #8688]                 ; 16-byte Reload
	bit.16b	v4, v1, v2
	ldr	q1, [sp, #8576]                 ; 16-byte Reload
	bit.16b	v1, v28, v2
	str	q1, [sp, #8576]                 ; 16-byte Spill
	add.2d	v1, v1, v1
	str	q4, [sp, #8688]                 ; 16-byte Spill
	ldr	q2, [sp, #9488]                 ; 16-byte Reload
	add.2d	v2, v4, v2
	ldr	q4, [sp, #9408]                 ; 16-byte Reload
	add.2d	v2, v4, v2
	add.2d	v1, v2, v1
	tbz	w13, #2, LBB0_176
; %bb.175:                              ; %cond.load630
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d1
	ld1.b	{ v0 }[2], [x8]
LBB0_176:                               ; %else634
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	ldr	x30, [sp, #9888]                ; 8-byte Reload
	tbz	w13, #3, LBB0_178
; %bb.177:                              ; %cond.load636
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v1[1]
	ld1.b	{ v0 }[3], [x8]
LBB0_178:                               ; %else640
                                        ;   in Loop: Header=BB0_154 Depth=2
	mul	x8, x23, x30
	mul	x9, x27, x26
	fmov	d1, x9
	mov.d	v1[1], x8
	sub.2d	v1, v21, v1
	ldr	q4, [sp, #8672]                 ; 16-byte Reload
	bit.16b	v4, v1, v6
	ldr	q1, [sp, #8544]                 ; 16-byte Reload
	bit.16b	v1, v7, v6
	str	q1, [sp, #8544]                 ; 16-byte Spill
	add.2d	v1, v1, v1
	ldr	q2, [sp, #9472]                 ; 16-byte Reload
	str	q4, [sp, #8672]                 ; 16-byte Spill
	add.2d	v2, v4, v2
	ldr	q4, [sp, #9392]                 ; 16-byte Reload
	add.2d	v2, v4, v2
	add.2d	v1, v2, v1
	tbz	w13, #4, LBB0_180
; %bb.179:                              ; %cond.load642
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d1
	ld1.b	{ v0 }[4], [x8]
LBB0_180:                               ; %else646
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q6, [sp, #10368]                ; 16-byte Reload
	tbz	w13, #5, LBB0_182
; %bb.181:                              ; %cond.load648
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v1[1]
	ld1.b	{ v0 }[5], [x8]
LBB0_182:                               ; %else652
                                        ;   in Loop: Header=BB0_154 Depth=2
	mul	x8, x25, x28
	mul	x9, x6, x5
	fmov	d1, x9
	mov.d	v1[1], x8
	sub.2d	v1, v5, v1
	ldr	q4, [sp, #8640]                 ; 16-byte Reload
	bit.16b	v4, v1, v15
	ldr	q1, [sp, #8720]                 ; 16-byte Reload
	bit.16b	v1, v22, v15
	str	q1, [sp, #8720]                 ; 16-byte Spill
	add.2d	v1, v1, v1
	ldr	q2, [sp, #9456]                 ; 16-byte Reload
	str	q4, [sp, #8640]                 ; 16-byte Spill
	add.2d	v2, v4, v2
	ldr	q4, [sp, #9520]                 ; 16-byte Reload
	add.2d	v2, v4, v2
	add.2d	v1, v2, v1
	tbz	w13, #6, LBB0_184
; %bb.183:                              ; %cond.load654
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x8, d1
	ld1.b	{ v0 }[6], [x8]
LBB0_184:                               ; %else658
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbz	w13, #7, LBB0_186
; %bb.185:                              ; %cond.load660
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v1[1]
	ld1.b	{ v0 }[7], [x8]
LBB0_186:                               ; %else664
                                        ;   in Loop: Header=BB0_154 Depth=2
	xtn.8b	v1, v10
	cmtst.8b	v2, v29, v29
	ldr	q4, [sp, #8560]                 ; 16-byte Reload
	bif.8b	v2, v4, v23
	ldr	d5, [sp, #10424]                ; 8-byte Reload
	orr.8b	v4, v1, v5
	and.8b	v2, v4, v2
	cmtst.8b	v0, v0, v0
	ldr	q4, [sp, #8528]                 ; 16-byte Reload
	bif.8b	v0, v4, v23
	fmov	w8, s9
	orr.8b	v1, v5, v1
	and.8b	v0, v1, v0
	str	q2, [sp, #8560]                 ; 16-byte Spill
	str	q0, [sp, #8528]                 ; 16-byte Spill
	and.8b	v0, v2, v0
	ldr	q1, [sp, #10272]                ; 16-byte Reload
	add.2d	v1, v19, v1
	ldr	q2, [sp, #10208]                ; 16-byte Reload
	add.2d	v1, v2, v1
	movi.8b	v2, #1
	and.8b	v0, v0, v2
	tbz	w8, #0, LBB0_188
; %bb.187:                              ; %cond.store667
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	str	b0, [x9]
LBB0_188:                               ; %else670
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q14, [sp, #11344]               ; 16-byte Reload
	ldr	q18, [sp, #10544]               ; 16-byte Reload
	ldr	q7, [sp, #10592]                ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q28, [sp, #11360]               ; 16-byte Reload
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	mov.16b	v4, v16
	mov.16b	v10, v15
	ldr	q29, [sp, #11136]               ; 16-byte Reload
	tbnz	w8, #1, LBB0_195
; %bb.189:                              ; %else674
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q1, [sp, #10256]                ; 16-byte Reload
	add.2d	v1, v4, v1
	ldr	q2, [sp, #10192]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #2, LBB0_196
LBB0_190:                               ; %else678
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbnz	w8, #3, LBB0_197
LBB0_191:                               ; %else682
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q1, [sp, #10240]                ; 16-byte Reload
	add.2d	v1, v11, v1
	ldr	q2, [sp, #10176]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbnz	w8, #4, LBB0_198
LBB0_192:                               ; %else686
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.16b	v2, v19
	tbnz	w8, #5, LBB0_199
LBB0_193:                               ; %else690
                                        ;   in Loop: Header=BB0_154 Depth=2
	ldr	q1, [sp, #10224]                ; 16-byte Reload
	add.2d	v1, v24, v1
	ldr	q5, [sp, #10288]                ; 16-byte Reload
	add.2d	v1, v5, v1
	tbnz	w8, #6, LBB0_200
LBB0_194:                               ; %else694
                                        ;   in Loop: Header=BB0_154 Depth=2
	tbz	w8, #7, LBB0_153
	b	LBB0_201
LBB0_195:                               ; %cond.store671
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[1], [x9]
	ldr	q1, [sp, #10256]                ; 16-byte Reload
	add.2d	v1, v4, v1
	ldr	q2, [sp, #10192]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #2, LBB0_190
LBB0_196:                               ; %cond.store675
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	st1.b	{ v0 }[2], [x9]
	tbz	w8, #3, LBB0_191
LBB0_197:                               ; %cond.store679
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[3], [x9]
	ldr	q1, [sp, #10240]                ; 16-byte Reload
	add.2d	v1, v11, v1
	ldr	q2, [sp, #10176]                ; 16-byte Reload
	add.2d	v1, v2, v1
	tbz	w8, #4, LBB0_192
LBB0_198:                               ; %cond.store683
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	st1.b	{ v0 }[4], [x9]
	mov.16b	v2, v19
	tbz	w8, #5, LBB0_193
LBB0_199:                               ; %cond.store687
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x9, v1[1]
	st1.b	{ v0 }[5], [x9]
	ldr	q1, [sp, #10224]                ; 16-byte Reload
	add.2d	v1, v24, v1
	ldr	q5, [sp, #10288]                ; 16-byte Reload
	add.2d	v1, v5, v1
	tbz	w8, #6, LBB0_194
LBB0_200:                               ; %cond.store691
                                        ;   in Loop: Header=BB0_154 Depth=2
	fmov	x9, d1
	st1.b	{ v0 }[6], [x9]
	tbz	w8, #7, LBB0_153
LBB0_201:                               ; %cond.store695
                                        ;   in Loop: Header=BB0_154 Depth=2
	mov.d	x8, v1[1]
	st1.b	{ v0 }[7], [x8]
	b	LBB0_153
LBB0_202:                               ;   in Loop: Header=BB0_28 Depth=1
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #3360
	mov	w14, #62154                     ; =0xf2ca
	movk	w14, #61769, lsl #16
	ldr	q0, [sp, #5168]                 ; 16-byte Reload
	ldr	q6, [sp, #10368]                ; 16-byte Reload
LBB0_203:                               ; %direct.false602
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q3, [sp, #3040]                 ; 16-byte Spill
	str	q2, [sp, #3248]                 ; 16-byte Spill
	str	q0, [sp, #5168]                 ; 16-byte Spill
	str	q1, [sp, #3296]                 ; 16-byte Spill
	str	q4, [sp, #3312]                 ; 16-byte Spill
	str	q26, [sp, #9440]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q4, [sp, #10160]                ; 16-byte Reload
	bit.16b	v4, v2, v10
	str	q4, [sp, #10160]                ; 16-byte Spill
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q4, [sp, #10144]                ; 16-byte Reload
	bit.16b	v4, v2, v14
	str	q4, [sp, #10144]                ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	bit.16b	v6, v2, v1
	str	q6, [sp, #10368]                ; 16-byte Spill
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	bit.16b	v12, v2, v0
	str	q12, [sp, #10384]               ; 16-byte Spill
	ldr	q2, [sp, #3200]                 ; 16-byte Reload
	bic.16b	v2, v2, v10
	ldr	q21, [sp, #3232]                ; 16-byte Reload
	bic.16b	v21, v21, v14
	ldr	q22, [sp, #3216]                ; 16-byte Reload
	bic.16b	v22, v22, v1
	ldr	q1, [sp, #3168]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	fmov	x8, d1
	cmp	x8, #17
	b.gt	LBB0_222
; %bb.204:                              ; %direct.true618.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	x19, [sp, #10432]               ; 8-byte Reload
	ldr	d26, [sp, #11400]               ; 8-byte Reload
	ldr	q19, [sp, #10576]               ; 16-byte Reload
	ldr	q9, [sp, #11024]                ; 16-byte Reload
	ldr	q24, [sp, #11008]               ; 16-byte Reload
	ldr	q18, [sp, #11296]               ; 16-byte Reload
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	ldr	x26, [sp, #10448]               ; 8-byte Reload
	ldr	q11, [sp, #10256]               ; 16-byte Reload
	ldr	q13, [sp, #10528]               ; 16-byte Reload
	b	LBB0_206
LBB0_205:                               ; %else746
                                        ;   in Loop: Header=BB0_206 Depth=2
	ldr	q28, [sp, #11360]               ; 16-byte Reload
	ldr	q19, [sp, #10576]               ; 16-byte Reload
	ldr	q4, [sp, #9776]                 ; 16-byte Reload
	ldr	q17, [sp, #11120]               ; 16-byte Reload
	ldr	q20, [sp, #11104]               ; 16-byte Reload
	ldr	q29, [sp, #11136]               ; 16-byte Reload
	xtn.8b	v0, v2
	cmtst.8b	v1, v8, v8
	ldr	q2, [sp, #8480]                 ; 16-byte Reload
	bif.8b	v1, v2, v23
	ldr	d2, [sp, #10424]                ; 8-byte Reload
	orr.8b	v2, v0, v2
	and.8b	v16, v2, v1
	ldr	q21, [sp, #11280]               ; 16-byte Reload
	and.8b	v0, v21, v0
	shl.8b	v1, v0, #7
	cmlt.8b	v1, v1, #0
	ldr	d26, [sp, #11400]               ; 8-byte Reload
	and.8b	v2, v1, v26
	addv.8b	b2, v2
	fmov	w9, s2
	str	q7, [sp, #8512]                 ; 16-byte Spill
	bic.8b	v2, v21, v7
	umaxv.8b	b1, v1
	fmov	w8, s1
	rbit	w10, w9
	clz	w10, w10
	tst	w8, #0x1
	csel	w10, w10, wzr, ne
	ldr	q1, [sp, #9808]                 ; 16-byte Reload
	str	q1, [sp, #19744]
	ldr	q1, [sp, #9792]                 ; 16-byte Reload
	str	q1, [sp, #19760]
	str	q4, [sp, #19776]
	ldr	q1, [sp, #9824]                 ; 16-byte Reload
	str	q1, [sp, #19792]
	ubfiz	x8, x10, #3, #3
	ldr	x11, [x15, x8]
	str	q5, [sp, #8496]                 ; 16-byte Spill
	str	q5, [sp, #19680]
	ldr	q1, [sp, #9968]                 ; 16-byte Reload
	str	q1, [sp, #19696]
	str	q6, [sp, #8464]                 ; 16-byte Spill
	str	q6, [sp, #19712]
	ldr	q1, [sp, #9952]                 ; 16-byte Reload
	str	q1, [sp, #19728]
	ldr	x13, [x16, x8]
	add	x13, x13, x13, lsl #3
	ldr	q1, [sp, #10032]                ; 16-byte Reload
	str	q1, [sp, #19616]
	ldr	q1, [sp, #10016]                ; 16-byte Reload
	str	q1, [sp, #19632]
	ldr	q1, [sp, #10000]                ; 16-byte Reload
	str	q1, [sp, #19648]
	ldr	q1, [sp, #9984]                 ; 16-byte Reload
	str	q1, [sp, #19664]
	ldr	x17, [x4, x8]
	add	x13, x13, x17
	lsl	w10, w10, #2
	sub	x11, x11, x10
	ldr	q1, [sp, #10384]                ; 16-byte Reload
	str	q1, [sp, #19552]
	ldr	q1, [sp, #10144]                ; 16-byte Reload
	str	q1, [sp, #19568]
	ldr	q1, [sp, #10368]                ; 16-byte Reload
	str	q1, [sp, #19584]
	ldr	q1, [sp, #10160]                ; 16-byte Reload
	str	q1, [sp, #19600]
	add	x17, sp, #4, lsl #12            ; =16384
	add	x17, x17, #3168
	ldr	x17, [x17, x8]
	add	x11, x11, x13, lsl #5
	sub	x10, x17, x10
	tst	w9, #0xff
	csel	x9, xzr, x11, eq
	add	x11, sp, #7, lsl #12            ; =28672
	add	x11, x11, #1056
	add	x9, x11, x9
	ldp	q4, q1, [x9]
	zip2.8b	v5, v0, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #8432]                 ; 16-byte Reload
	bif.16b	v1, v6, v5
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmge.4s	v6, v6, #0
	dup.4s	v7, w14
	and.16b	v6, v6, v1
	zip2.8b	v1, v16, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	str	q6, [sp, #8432]                 ; 16-byte Spill
	bsl.16b	v1, v6, v7
	str	q15, [sp, #19488]
	str	q25, [sp, #19504]
	str	q3, [sp, #19520]
	str	q12, [sp, #19536]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #3104
	ldr	x8, [x9, x8]
	add	x8, x10, x8, lsl #5
	csel	x8, xzr, x8, eq
	add	x9, sp, #6, lsl #12             ; =24576
	add	x9, x9, #1656
	add	x8, x9, x8
	ldr	q6, [x8, #16]
	bif.16b	v1, v6, v5
	zip1.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q5, [sp, #8448]                 ; 16-byte Reload
	bif.16b	v4, v5, v0
	zip1.8b	v2, v2, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	and.16b	v4, v2, v4
	str	q16, [sp, #8480]                ; 16-byte Spill
	zip1.8b	v2, v16, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	str	q4, [sp, #8448]                 ; 16-byte Spill
	bsl.16b	v2, v4, v7
	ldr	q4, [x8]
	bsl.16b	v0, v2, v4
	stp	q0, q1, [x8]
	add.2d	v21, v25, v28
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	add.2d	v22, v3, v23
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v2, v12, v0
	ldr	q8, [sp, #11424]                ; 16-byte Reload
	add.2d	v1, v15, v8
	fmov	x8, d1
	cmp	x8, #18
	b.ge	LBB0_223
LBB0_206:                               ; %direct.true618
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v5, v30, #0
	sshll.2d	v6, v31, #0
	mov.16b	v12, v2
	and.16b	v0, v10, v2
	mov.16b	v25, v21
	and.16b	v2, v14, v21
	mov.16b	v3, v22
	and.16b	v17, v6, v22
	mov.16b	v15, v1
	and.16b	v7, v5, v1
	fmov	x8, d7
	fmov	x9, d29
	sdiv	x8, x8, x9
	mul	x9, x8, x9
	fmov	d1, x8
	mov.d	x8, v7[1]
	sdiv	x10, x8, x25
	mov.d	v1[1], x10
	fmov	x8, d17
	ldr	q4, [sp, #11312]                ; 16-byte Reload
	fmov	x11, d4
	sdiv	x3, x8, x11
	mov.d	x17, v17[1]
	fmov	x8, d2
	ldr	q4, [sp, #10608]                ; 16-byte Reload
	fmov	x5, d4
	mov.d	x23, v2[1]
	sdiv	x6, x8, x5
	fmov	x8, d0
	fmov	x24, d18
	sdiv	x8, x8, x24
	mov.d	x13, v0[1]
	sdiv	x13, x13, x26
	mul	x25, x13, x26
	mul	x24, x8, x24
	fmov	d4, x24
	mov.d	v4[1], x25
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	ldr	x1, [sp, #10440]                ; 8-byte Reload
	sdiv	x23, x23, x1
	mul	x24, x23, x1
	mul	x5, x6, x5
	fmov	d21, x5
	mov.d	v21[1], x24
	sdiv	x5, x17, x22
	mul	x17, x5, x22
	mul	x11, x3, x11
	fmov	d20, x11
	mov.d	v20[1], x17
	mul	x10, x10, x25
	fmov	d22, x9
	mov.d	v22[1], x10
	sub.2d	v7, v7, v22
	sub.2d	v20, v17, v20
	sub.2d	v21, v2, v21
	sub.2d	v22, v0, v4
	shl.2d	v0, v7, #3
	shl.2d	v2, v21, #3
	shl.2d	v4, v20, #3
	shl.2d	v17, v22, #3
	ldr	q16, [sp, #10480]               ; 16-byte Reload
	cmgt.2d	v17, v16, v17
	ldr	q16, [sp, #10512]               ; 16-byte Reload
	cmgt.2d	v4, v16, v4
	uzp1.4s	v4, v4, v17
	ldr	q16, [sp, #10496]               ; 16-byte Reload
	cmgt.2d	v2, v16, v2
	cmgt.2d	v0, v19, v0
	uzp1.4s	v0, v0, v2
	uzp1.8h	v2, v0, v4
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	and.16b	v0, v0, v2
	xtn.8b	v28, v0
	and.16b	v0, v5, v1
	mov.d	x9, v0[1]
	sdiv	x10, x9, x12
	msub	x9, x10, x12, x9
	fmov	x10, d0
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x17, x10, x11
	msub	x10, x17, x11, x10
	fmov	d29, x10
	mov.d	v29[1], x9
	shl.8b	v0, v28, #7
	cmlt.8b	v23, v0, #0
	and.8b	v0, v23, v26
	addv.8b	b0, v0
	fmov	w17, s0
	add.2d	v0, v7, v7
	ldr	q1, [sp, #10272]                ; 16-byte Reload
	add.2d	v0, v0, v1
	ldr	q1, [sp, #10208]                ; 16-byte Reload
	add.2d	v0, v1, v0
	add.2d	v0, v0, v29
	tbz	w17, #0, LBB0_208
; %bb.207:                              ; %cond.load700
                                        ;   in Loop: Header=BB0_206 Depth=2
	fmov	x9, d0
	ldr	b8, [x9]
	ldr	w1, [sp, #10316]                ; 4-byte Reload
	tbnz	w17, #1, LBB0_209
	b	LBB0_210
LBB0_208:                               ;   in Loop: Header=BB0_206 Depth=2
	movi.2d	v8, #0000000000000000
	ldr	w1, [sp, #10316]                ; 4-byte Reload
	tbz	w17, #1, LBB0_210
LBB0_209:                               ; %cond.load706
                                        ;   in Loop: Header=BB0_206 Depth=2
	mov.d	x9, v0[1]
	ld1.b	{ v8 }[1], [x9]
LBB0_210:                               ; %else710
                                        ;   in Loop: Header=BB0_206 Depth=2
	fmov	d0, x6
	mov.d	v0[1], x23
	and.16b	v0, v14, v0
	mov.d	x9, v0[1]
	sdiv	x10, x9, x19
	msub	x9, x10, x19, x9
	fmov	x10, d0
	fmov	x11, d13
	sdiv	x6, x10, x11
	msub	x10, x6, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	add.2d	v1, v21, v21
	add.2d	v1, v1, v11
	ldr	q4, [sp, #10192]                ; 16-byte Reload
	add.2d	v1, v4, v1
	add.2d	v1, v1, v0
	tbz	w17, #2, LBB0_212
; %bb.211:                              ; %cond.load712
                                        ;   in Loop: Header=BB0_206 Depth=2
	fmov	x9, d1
	ld1.b	{ v8 }[2], [x9]
LBB0_212:                               ; %else716
                                        ;   in Loop: Header=BB0_206 Depth=2
	tbz	w17, #3, LBB0_214
; %bb.213:                              ; %cond.load718
                                        ;   in Loop: Header=BB0_206 Depth=2
	mov.d	x9, v1[1]
	ld1.b	{ v8 }[3], [x9]
LBB0_214:                               ; %else722
                                        ;   in Loop: Header=BB0_206 Depth=2
	fmov	d1, x3
	mov.d	v1[1], x5
	and.16b	v1, v6, v1
	mov.d	x9, v1[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d1
	ldr	q1, [sp, #10560]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x3, x10, x11
	msub	x10, x3, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	add.2d	v4, v20, v20
	ldr	q17, [sp, #10240]               ; 16-byte Reload
	add.2d	v4, v4, v17
	ldr	q16, [sp, #10176]               ; 16-byte Reload
	add.2d	v4, v16, v4
	add.2d	v4, v4, v1
	tbz	w17, #4, LBB0_216
; %bb.215:                              ; %cond.load724
                                        ;   in Loop: Header=BB0_206 Depth=2
	fmov	x9, d4
	ld1.b	{ v8 }[4], [x9]
LBB0_216:                               ; %else728
                                        ;   in Loop: Header=BB0_206 Depth=2
	tbz	w17, #5, LBB0_218
; %bb.217:                              ; %cond.load730
                                        ;   in Loop: Header=BB0_206 Depth=2
	mov.d	x9, v4[1]
	ld1.b	{ v8 }[5], [x9]
LBB0_218:                               ; %else734
                                        ;   in Loop: Header=BB0_206 Depth=2
	fmov	d4, x8
	mov.d	v4[1], x13
	and.16b	v4, v10, v4
	mov.d	x8, v4[1]
	sdiv	x9, x8, x28
	msub	x8, x9, x28, x8
	fmov	x9, d4
	ldr	q4, [sp, #10592]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d17, x9
	mov.d	v17[1], x8
	add.2d	v4, v22, v22
	ldr	q26, [sp, #10224]               ; 16-byte Reload
	add.2d	v4, v4, v26
	ldr	q16, [sp, #10288]               ; 16-byte Reload
	add.2d	v4, v16, v4
	add.2d	v4, v4, v17
	tbz	w17, #6, LBB0_220
; %bb.219:                              ; %cond.load736
                                        ;   in Loop: Header=BB0_206 Depth=2
	fmov	x8, d4
	ld1.b	{ v8 }[6], [x8]
LBB0_220:                               ; %else740
                                        ;   in Loop: Header=BB0_206 Depth=2
	ldr	q16, [sp, #9984]                ; 16-byte Reload
	bit.16b	v16, v22, v10
	str	q16, [sp, #9984]                ; 16-byte Spill
	ldr	q16, [sp, #10016]               ; 16-byte Reload
	bit.16b	v16, v21, v14
	str	q16, [sp, #10016]               ; 16-byte Spill
	ldr	q16, [sp, #10000]               ; 16-byte Reload
	bit.16b	v16, v20, v6
	str	q16, [sp, #10000]               ; 16-byte Spill
	ldr	q16, [sp, #10032]               ; 16-byte Reload
	bit.16b	v16, v7, v5
	str	q16, [sp, #10032]               ; 16-byte Spill
	ldr	q7, [sp, #8512]                 ; 16-byte Reload
	ldr	q16, [sp, #11280]               ; 16-byte Reload
	bic.8b	v7, v7, v16
	orr.8b	v7, v28, v7
	ldr	q16, [sp, #9952]                ; 16-byte Reload
	bit.16b	v16, v17, v10
	str	q16, [sp, #9952]                ; 16-byte Spill
	ldr	q16, [sp, #9968]                ; 16-byte Reload
	bit.16b	v16, v0, v14
	str	q16, [sp, #9968]                ; 16-byte Spill
	ldr	q0, [sp, #8464]                 ; 16-byte Reload
	bsl.16b	v6, v1, v0
	ldr	q0, [sp, #8496]                 ; 16-byte Reload
	bsl.16b	v5, v29, v0
	tbz	w17, #7, LBB0_205
; %bb.221:                              ; %cond.load742
                                        ;   in Loop: Header=BB0_206 Depth=2
	mov.d	x8, v4[1]
	ld1.b	{ v8 }[7], [x8]
	b	LBB0_205
LBB0_222:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	x19, [sp, #10432]               ; 8-byte Reload
	ldr	q19, [sp, #10576]               ; 16-byte Reload
	ldr	q9, [sp, #11024]                ; 16-byte Reload
	ldr	q24, [sp, #11008]               ; 16-byte Reload
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	ldr	x26, [sp, #10448]               ; 8-byte Reload
	ldr	q13, [sp, #10528]               ; 16-byte Reload
LBB0_223:                               ; %direct.false619
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q22, [sp, #3216]                ; 16-byte Spill
	str	q21, [sp, #3232]                ; 16-byte Spill
	str	q27, [sp, #3344]                ; 16-byte Spill
	str	q1, [sp, #3168]                 ; 16-byte Spill
	str	q2, [sp, #3200]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #9344]                 ; 16-byte Reload
	bic.16b	v2, v2, v10
	ldr	q6, [sp, #9376]                 ; 16-byte Reload
	bic.16b	v6, v6, v14
	ldr	q5, [sp, #9360]                 ; 16-byte Reload
	str	q1, [sp, #10704]                ; 16-byte Spill
	bic.16b	v5, v5, v1
	ldr	q4, [sp, #9328]                 ; 16-byte Reload
	str	q0, [sp, #10720]                ; 16-byte Spill
	bic.16b	v4, v4, v0
	fmov	x6, d4
	cmp	x6, #1
	b.gt	LBB0_228
; %bb.224:                              ; %direct.true642.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q16, [sp, #10560]               ; 16-byte Reload
	ldr	q7, [sp, #10592]                ; 16-byte Reload
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #1656
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #2976
	add	x16, sp, #4, lsl #12            ; =16384
	add	x16, x16, #2912
	add	x4, sp, #4, lsl #12             ; =16384
	add	x4, x4, #3040
	ldr	q25, [sp, #3088]                ; 16-byte Reload
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	ldr	q18, [sp, #3056]                ; 16-byte Reload
	ldr	x23, [sp, #10440]               ; 8-byte Reload
	b	LBB0_226
LBB0_225:                               ; %direct.false648
                                        ;   in Loop: Header=BB0_226 Depth=2
	str	q16, [sp, #8336]                ; 16-byte Spill
	str	q23, [sp, #8352]                ; 16-byte Spill
	str	q30, [sp, #8368]                ; 16-byte Spill
	str	q10, [sp, #8384]                ; 16-byte Spill
	str	q27, [sp, #8400]                ; 16-byte Spill
	str	q15, [sp, #8416]                ; 16-byte Spill
	str	q3, [sp, #19264]
	str	q18, [sp, #19280]
	ldr	x9, [sp, #6472]                 ; 8-byte Reload
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2880
	ldr	s0, [x8, x9]
	ldr	w8, [sp, #9036]                 ; 4-byte Reload
	tst	w8, #0x1
	movi.2d	v16, #0000000000000000
	fcsel	s2, s0, s16, ne
	str	q3, [sp, #19232]
	str	q18, [sp, #19248]
	ldr	x10, [sp, #6424]                ; 8-byte Reload
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2848
	ldr	s0, [x8, x10]
	movi.8b	v1, #1
	and.8b	v1, v25, v1
	ushll.8h	v1, v1, #0
	ushll.4s	v5, v1, #0
	ushll2.4s	v6, v1, #0
	str	q6, [sp, #18800]
	str	q5, [sp, #18784]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2400
	ldr	w8, [x8, x9]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9032]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s0, s0, s16, ne
	str	q3, [sp, #19200]
	str	q18, [sp, #19216]
	ldr	x11, [sp, #6392]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2816
	ldr	s7, [x9, x11]
	str	q6, [sp, #18832]
	str	q5, [sp, #18816]
	fmov	s1, w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2432
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9028]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s7, s7, s16, ne
	str	q3, [sp, #19168]
	str	q18, [sp, #19184]
	ldr	x13, [sp, #6376]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2784
	ldr	s4, [x9, x13]
	str	q6, [sp, #18864]
	str	q5, [sp, #18848]
	mov.s	v1[1], w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2464
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9024]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q3, [sp, #19136]
	str	q18, [sp, #19152]
	ldr	x10, [sp, #6464]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2752
	ldr	s17, [x9, x10]
	str	q6, [sp, #18896]
	str	q5, [sp, #18880]
	mov.s	v1[2], w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2496
	ldr	w8, [x8, x13]
	fcsel	s20, s4, s16, ne
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9020]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s4, s17, s16, ne
	str	q3, [sp, #19104]
	str	q18, [sp, #19120]
	ldr	x11, [sp, #6336]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2720
	ldr	s17, [x9, x11]
	str	q6, [sp, #18928]
	str	q5, [sp, #18912]
	mov.s	v1[3], w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2528
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9016]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s17, s17, s16, ne
	str	q3, [sp, #19072]
	str	q18, [sp, #19088]
	ldr	x10, [sp, #6296]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2688
	ldr	s21, [x9, x10]
	str	q6, [sp, #18960]
	str	q5, [sp, #18944]
	fmov	s22, w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2560
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9012]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s21, s21, s16, ne
	str	q3, [sp, #19040]
	str	q18, [sp, #19056]
	ldr	x11, [sp, #6280]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2656
	ldr	s23, [x9, x11]
	mov.s	v22[1], w8
	str	q6, [sp, #18992]
	str	q5, [sp, #18976]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2592
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9008]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s23, s23, s16, ne
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v21[0]
	mov.s	v4[3], v23[0]
	mov.s	v2[1], v0[0]
	mov.s	v2[2], v7[0]
	mov.s	v2[3], v20[0]
	fmaxnm.4s	v0, v3, v2
	fmaxnm.4s	v7, v18, v4
	mov.s	v22[2], w8
	str	q6, [sp, #19024]
	str	q5, [sp, #19008]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2624
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	mov.s	v22[3], w8
	cmtst.4s	v5, v22, v22
	cmtst.4s	v6, v1, v1
	uzp1.8h	v5, v6, v5
	xtn.8b	v5, v5
	cmeq.4s	v1, v1, #0
	cmeq.4s	v6, v22, #0
	bsl.16b	v6, v18, v7
	bit.16b	v0, v3, v1
	zip1.8b	v1, v25, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bit.16b	v2, v0, v1
	zip2.8b	v0, v25, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	bif.16b	v6, v4, v0
	orr.8b	v5, v25, v5
	str	q6, [sp, #18768]
	str	q2, [sp, #18752]
	ldr	x9, [sp, #6456]                 ; 8-byte Reload
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2368
	ldr	s0, [x8, x9]
	ldr	w8, [sp, #9004]                 ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s7, s0, s16, ne
	str	q6, [sp, #18704]
	str	q2, [sp, #18688]
	ldr	x10, [sp, #6232]                ; 8-byte Reload
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2304
	ldr	s0, [x8, x10]
	zip1.8b	v1, v5, v0
	ushll.4s	v21, v1, #0
	movi.4s	v27, #1
	and.16b	v20, v21, v27
	zip2.8b	v1, v5, v0
	ushll.4s	v23, v1, #0
	and.16b	v22, v23, v27
	str	q22, [sp, #18736]
	str	q20, [sp, #18720]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2336
	ldr	w8, [x8, x9]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9000]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s0, s0, s16, ne
	str	q6, [sp, #18640]
	str	q2, [sp, #18624]
	ldr	x11, [sp, #6216]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2240
	ldr	s17, [x9, x11]
	str	q22, [sp, #18672]
	str	q20, [sp, #18656]
	fmov	s28, w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2272
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8996]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s1, s17, s16, ne
	str	q6, [sp, #18576]
	str	q2, [sp, #18560]
	ldr	x13, [sp, #6184]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2176
	ldr	s4, [x9, x13]
	str	q22, [sp, #18608]
	str	q20, [sp, #18592]
	mov.s	v28[1], w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2208
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8992]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s4, s4, s16, ne
	str	q6, [sp, #18512]
	str	q2, [sp, #18496]
	ldr	x10, [sp, #6448]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2112
	ldr	s17, [x9, x10]
	str	q22, [sp, #18544]
	str	q20, [sp, #18528]
	mov.s	v28[2], w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2144
	ldr	w8, [x8, x13]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8988]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s17, s17, s16, ne
	str	q6, [sp, #18448]
	str	q2, [sp, #18432]
	ldr	x11, [sp, #6136]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #2048
	ldr	s26, [x9, x11]
	str	q22, [sp, #18480]
	str	q20, [sp, #18464]
	mov.s	v28[3], w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2080
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8984]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q6, [sp, #18384]
	str	q2, [sp, #18368]
	ldr	x10, [sp, #6120]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1984
	ldr	s29, [x9, x10]
	fcsel	s26, s26, s16, ne
	str	q22, [sp, #18416]
	str	q20, [sp, #18400]
	mov.s	v17[1], v26[0]
	fmov	s26, w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #2016
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8980]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s29, s29, s16, ne
	str	q6, [sp, #18320]
	str	q2, [sp, #18304]
	mov.s	v17[2], v29[0]
	ldr	x11, [sp, #6088]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1920
	ldr	s29, [x9, x11]
	str	q22, [sp, #18352]
	str	q20, [sp, #18336]
	mov.s	v26[1], w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1952
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8976]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s29, s29, s16, ne
	mov.s	v17[3], v29[0]
	ldr	q19, [sp, #11360]               ; 16-byte Reload
	mov.s	v7[1], v0[0]
	mov.s	v7[2], v1[0]
	mov.s	v7[3], v4[0]
	fmaxnm.4s	v0, v2, v7
	fmaxnm.4s	v1, v6, v17
	shl.4s	v4, v23, #31
	cmlt.4s	v4, v4, #0
	shl.4s	v21, v21, #31
	mov.s	v26[2], w8
	str	q22, [sp, #18288]
	str	q20, [sp, #18272]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1888
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	mov.s	v26[3], w8
	cmlt.4s	v20, v21, #0
	cmtst.4s	v21, v26, v26
	cmtst.4s	v22, v28, v28
	uzp1.8h	v21, v22, v21
	xtn.8b	v21, v21
	cmeq.4s	v22, v28, #0
	mov.16b	v28, v19
	ldr	q19, [sp, #10576]               ; 16-byte Reload
	cmeq.4s	v23, v26, #0
	bit.16b	v1, v6, v23
	bit.16b	v0, v2, v22
	bif.16b	v0, v7, v20
	bsl.16b	v4, v1, v17
	orr.8b	v5, v5, v21
	str	q4, [sp, #18256]
	str	q0, [sp, #18240]
	ldr	x9, [sp, #6440]                 ; 8-byte Reload
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1856
	ldr	s1, [x8, x9]
	ldr	w8, [sp, #8972]                 ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s2, s1, s16, ne
	str	q4, [sp, #18192]
	str	q0, [sp, #18176]
	ldr	x10, [sp, #6064]                ; 8-byte Reload
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1792
	ldr	s6, [x8, x10]
	zip1.8b	v1, v5, v0
	ushll.4s	v1, v1, #0
	and.16b	v7, v1, v27
	zip2.8b	v5, v5, v0
	ushll.4s	v5, v5, #0
	and.16b	v5, v5, v27
	str	q5, [sp, #18224]
	str	q7, [sp, #18208]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1824
	ldr	w8, [x8, x9]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8968]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s6, s6, s16, ne
	str	q4, [sp, #18128]
	str	q0, [sp, #18112]
	ldr	x11, [sp, #6024]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1728
	ldr	s17, [x9, x11]
	str	q5, [sp, #18160]
	str	q7, [sp, #18144]
	fmov	s20, w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1760
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8964]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s17, s17, s16, ne
	str	q4, [sp, #18064]
	str	q0, [sp, #18048]
	ldr	x10, [sp, #6008]                ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1664
	ldr	s4, [x9, x10]
	mov.s	v20[1], w8
	str	q5, [sp, #18096]
	str	q7, [sp, #18080]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1696
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8960]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q5, [sp, #18032]
	str	q7, [sp, #18016]
	mov.s	v20[2], w8
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1632
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	mov.s	v20[3], w8
	fcsel	s4, s4, s16, ne
	mov.16b	v5, v2
	mov.s	v5[1], v6[0]
	mov.s	v5[2], v17[0]
	mov.s	v5[3], v4[0]
	fmaxnm.4s	v4, v0, v5
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	cmeq.4s	v5, v20, #0
	bif.16b	v0, v4, v5
	bif.16b	v0, v2, v1
	tst	w0, #0x1
	fcsel	s1, s0, s16, ne
	ldr	w8, [sp, #10420]                ; 4-byte Reload
	and	w8, w8, w0
	tst	w8, #0x1
	fcsel	s2, s0, s16, ne
	and	w8, w1, w0
	tst	w8, #0x1
	fcsel	s4, s0, s16, ne
	and	w8, w2, w0
	tst	w8, #0x1
	fcsel	s5, s0, s16, ne
	and	w8, w7, w0
	tst	w8, #0x1
	fcsel	s6, s0, s16, ne
	ldr	w8, [sp, #10092]                ; 4-byte Reload
	and	w8, w8, w0
	tst	w8, #0x1
	fcsel	s7, s0, s16, ne
	and	w8, w21, w0
	tst	w8, #0x1
	fcsel	s17, s0, s16, ne
	and	w8, w20, w0
	tst	w8, #0x1
	fcsel	s0, s0, s16, ne
	mov.s	v1[1], v2[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v5[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v0[0]
	str	q6, [sp, #17744]
	str	q1, [sp, #17728]
	ldr	x8, [sp, #5992]                 ; 8-byte Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1344
	ldr	s0, [x9, x8, lsl #2]
	mov	w8, #-8388608                   ; =0xff800000
	fmov	s1, w8
	fmaxnm	s0, s0, s1
	dup.4s	v0, v0[0]
	add	x8, sp, #6, lsl #12             ; =24576
	add	x8, x8, #1592
	add	x8, x8, x6, lsl #5
	ldp	q1, q2, [x8]
	ldr	q31, [sp, #11184]               ; 16-byte Reload
	bit.16b	v2, v0, v31
	ldr	q30, [sp, #11216]               ; 16-byte Reload
	bif.16b	v0, v1, v30
	stp	q0, q2, [x8]
	ldr	q6, [sp, #9376]                 ; 16-byte Reload
	add.2d	v6, v6, v28
	ldr	q5, [sp, #9360]                 ; 16-byte Reload
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v5, v5, v0
	ldr	q2, [sp, #9344]                 ; 16-byte Reload
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v2, v2, v0
	ldr	q4, [sp, #9328]                 ; 16-byte Reload
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v4, v4, v0
	fmov	x6, d4
	cmp	x6, #2
	ldr	q13, [sp, #10528]               ; 16-byte Reload
	ldr	q7, [sp, #10592]                ; 16-byte Reload
	ldr	q17, [sp, #11120]               ; 16-byte Reload
	ldr	q20, [sp, #11104]               ; 16-byte Reload
	ldr	q9, [sp, #11024]                ; 16-byte Reload
	ldr	q24, [sp, #11008]               ; 16-byte Reload
	ldr	q10, [sp, #11328]               ; 16-byte Reload
	ldr	q14, [sp, #11344]               ; 16-byte Reload
	ldr	q16, [sp, #10560]               ; 16-byte Reload
	b.ge	LBB0_229
LBB0_226:                               ; %direct.true642
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_227 Depth 3
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	str	q2, [sp, #9344]                 ; 16-byte Spill
	and.16b	v2, v10, v2
	str	q4, [sp, #9328]                 ; 16-byte Spill
	and.16b	v4, v0, v4
	mov.d	x8, v4[1]
	sdiv	x9, x8, x12
	msub	x8, x9, x12, x8
	fmov	x9, d4
	ldr	q4, [sp, #10544]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	str	q5, [sp, #9360]                 ; 16-byte Spill
	and.16b	v5, v1, v5
	mov.d	x8, v5[1]
	sdiv	x9, x8, x30
	msub	x8, x9, x30, x8
	fmov	x9, d5
	fmov	x10, d16
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d5, x9
	mov.d	v5[1], x8
	str	q6, [sp, #9376]                 ; 16-byte Spill
	and.16b	v6, v14, v6
	mov.d	x8, v6[1]
	sdiv	x9, x8, x19
	msub	x8, x9, x19, x8
	fmov	x9, d6
	fmov	x10, d13
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d6, x9
	mov.d	v6[1], x8
	mov.d	x8, v2[1]
	sdiv	x9, x8, x28
	msub	x8, x9, x28, x8
	fmov	x9, d2
	fmov	x10, d7
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d2, x9
	mov.d	v2[1], x8
	bit.16b	v24, v2, v10
	str	q24, [sp, #11008]               ; 16-byte Spill
	bit.16b	v20, v6, v14
	str	q20, [sp, #11104]               ; 16-byte Spill
	bit.16b	v9, v5, v1
	str	q9, [sp, #11024]                ; 16-byte Spill
	bit.16b	v17, v4, v0
	str	q17, [sp, #11120]               ; 16-byte Spill
	ldr	q15, [sp, #8416]                ; 16-byte Reload
	bic.16b	v15, v15, v10
	ldr	q10, [sp, #8384]                ; 16-byte Reload
	bic.16b	v10, v10, v14
	mov.16b	v4, v30
	ldr	q30, [sp, #8368]                ; 16-byte Reload
	bic.16b	v30, v30, v1
	ldr	q27, [sp, #8400]                ; 16-byte Reload
	bic.16b	v27, v27, v0
	bic.16b	v18, v18, v31
	bic.16b	v3, v3, v4
	ldr	d0, [sp, #10424]                ; 8-byte Reload
	and.8b	v25, v0, v25
	fmov	x8, d27
	cmp	x8, #8
	ldr	q23, [sp, #8352]                ; 16-byte Reload
	ldr	q16, [sp, #8336]                ; 16-byte Reload
	ldr	q12, [sp, #10480]               ; 16-byte Reload
	ldr	q29, [sp, #10496]               ; 16-byte Reload
	ldr	q11, [sp, #10512]               ; 16-byte Reload
	ldr	q26, [sp, #10160]               ; 16-byte Reload
	ldr	q31, [sp, #10368]               ; 16-byte Reload
	ldr	q8, [sp, #10608]                ; 16-byte Reload
	ldr	q9, [sp, #10384]                ; 16-byte Reload
	ldr	q14, [sp, #10144]               ; 16-byte Reload
	b.gt	LBB0_225
LBB0_227:                               ; %direct.true647
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_226 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q13, [sp, #11184]               ; 16-byte Reload
	sshll.2d	v0, v13, #0
	ldr	q1, [sp, #11344]                ; 16-byte Reload
	and.16b	v1, v1, v10
	and.16b	v0, v0, v30
	ldr	q2, [sp, #11328]                ; 16-byte Reload
	and.16b	v2, v2, v15
	mov.d	x8, v2[1]
	fmov	x9, d2
	ldr	q2, [sp, #11296]                ; 16-byte Reload
	fmov	x10, d2
	sdiv	x11, x9, x10
	mov.d	x13, v0[1]
	msub	x9, x11, x10, x9
	fmov	x10, d0
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x17, x10, x11
	mov.d	x3, v1[1]
	msub	x10, x17, x11, x10
	fmov	x11, d1
	fmov	x17, d8
	sdiv	x5, x11, x17
	msub	x11, x5, x17, x11
	sdiv	x17, x8, x26
	msub	x8, x17, x26, x8
	fmov	d1, x9
	sdiv	x9, x13, x22
	msub	x9, x9, x22, x13
	ldr	q24, [sp, #11216]               ; 16-byte Reload
	sshll.2d	v0, v24, #0
	and.16b	v0, v0, v27
	fmov	d2, x10
	sdiv	x10, x3, x23
	msub	x10, x10, x23, x3
	mov.d	x13, v0[1]
	mov.d	v1[1], x8
	fmov	d4, x11
	sdiv	x8, x13, x25
	msub	x8, x8, x25, x13
	fmov	x11, d0
	mov.d	v4[1], x10
	ldr	q0, [sp, #11136]                ; 16-byte Reload
	fmov	x10, d0
	sdiv	x13, x11, x10
	msub	x10, x13, x10, x11
	fmov	d5, x10
	mov.d	v2[1], x9
	mov.d	v5[1], x8
	shl.2d	v0, v5, #3
	shl.2d	v6, v4, #3
	shl.2d	v7, v1, #3
	shl.2d	v17, v2, #3
	cmgt.2d	v20, v12, v7
	cmgt.2d	v21, v11, v17
	uzp1.4s	v20, v21, v20
	cmgt.2d	v21, v29, v6
	cmgt.2d	v22, v19, v0
	uzp1.4s	v21, v22, v21
	uzp1.8h	v22, v21, v20
	cmge.2d	v6, v6, v29
	cmge.2d	v0, v0, v19
	cmge.2d	v7, v7, v12
	cmge.2d	v17, v17, v11
	uzp1.4s	v6, v0, v6
	uzp1.4s	v7, v17, v7
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	and.16b	v0, v0, v22
	xtn.8b	v0, v0
	shl.8b	v17, v0, #7
	cmlt.8b	v17, v17, #0
	ldr	d22, [sp, #11400]               ; 8-byte Reload
	and.8b	v22, v17, v22
	addv.8b	b22, v22
	fmov	w8, s22
	umaxv.8b	b17, v17
	fmov	w9, s17
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	str	q9, [sp, #19360]
	str	q14, [sp, #19376]
	str	q31, [sp, #19392]
	str	q26, [sp, #19408]
	ubfiz	x10, x9, #3, #3
	ldr	x11, [x15, x10]
	ldr	q17, [sp, #11120]               ; 16-byte Reload
	str	q17, [sp, #19296]
	ldr	q17, [sp, #11104]               ; 16-byte Reload
	str	q17, [sp, #19312]
	ldr	q17, [sp, #11024]               ; 16-byte Reload
	str	q17, [sp, #19328]
	ldr	q17, [sp, #11008]               ; 16-byte Reload
	str	q17, [sp, #19344]
	ldr	x13, [x16, x10]
	str	q4, [sp, #19440]
	str	q1, [sp, #19472]
	str	q2, [sp, #19456]
	add	x13, x13, x13, lsl #3
	str	q5, [sp, #19424]
	ldr	x10, [x4, x10]
	lsl	w9, w9, #2
	add	x10, x13, x10
	sub	x9, x11, x9
	add	x9, x9, x10, lsl #5
	tst	w8, #0xff
	csel	x8, xzr, x9, eq
	add	x8, x14, x8
	and.16b	v1, v13, v20
	ldp	q4, q2, [x8]
	bif.16b	v2, v16, v1
	and.16b	v5, v24, v21
	bif.16b	v4, v23, v5
	and.16b	v7, v13, v7
	and.16b	v6, v24, v6
	bic.16b	v23, v4, v6
	bic.16b	v16, v2, v7
	zip2.8b	v2, v25, v0
	ushll.4s	v2, v2, #0
	fmaxnm.4s	v4, v18, v16
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bsl.16b	v2, v4, v16
	bit.16b	v18, v2, v1
	zip1.8b	v1, v25, v0
	fmaxnm.4s	v2, v3, v23
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bsl.16b	v1, v2, v23
	bit.16b	v3, v1, v5
	orr.8b	v25, v25, v0
	add.2d	v10, v10, v28
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v30, v30, v0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v15, v15, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v27, v27, v0
	fmov	x8, d27
	cmp	x8, #9
	b.lt	LBB0_227
	b	LBB0_225
LBB0_228:                               ;   in Loop: Header=BB0_28 Depth=1
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #1656
	ldr	q25, [sp, #3088]                ; 16-byte Reload
	ldr	q3, [sp, #3072]                 ; 16-byte Reload
	ldr	q18, [sp, #3056]                ; 16-byte Reload
LBB0_229:                               ; %direct.false643
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q18, [sp, #3056]                ; 16-byte Spill
	str	q3, [sp, #3072]                 ; 16-byte Spill
	str	q25, [sp, #3088]                ; 16-byte Spill
	str	q4, [sp, #9328]                 ; 16-byte Spill
	str	q24, [sp, #11008]               ; 16-byte Spill
	str	q9, [sp, #11024]                ; 16-byte Spill
	str	q20, [sp, #11104]               ; 16-byte Spill
	str	q17, [sp, #11120]               ; 16-byte Spill
	str	q2, [sp, #9344]                 ; 16-byte Spill
	str	q5, [sp, #9360]                 ; 16-byte Spill
	str	q6, [sp, #9376]                 ; 16-byte Spill
	ldr	q0, [sp, #1232]                 ; 16-byte Reload
	ldr	q15, [sp, #3136]                ; 16-byte Reload
	bit.16b	v15, v0, v10
	ldr	q1, [sp, #5600]                 ; 16-byte Reload
	bit.16b	v1, v0, v14
	str	q1, [sp, #5600]                 ; 16-byte Spill
	ldr	q1, [sp, #5584]                 ; 16-byte Reload
	ldr	q3, [sp, #10704]                ; 16-byte Reload
	bit.16b	v1, v0, v3
	str	q1, [sp, #5584]                 ; 16-byte Spill
	ldr	q1, [sp, #10720]                ; 16-byte Reload
	ldr	q2, [sp, #5616]                 ; 16-byte Reload
	bit.16b	v2, v0, v1
	str	q2, [sp, #5616]                 ; 16-byte Spill
	ldr	q4, [sp, #5696]                 ; 16-byte Reload
	ldr	q0, [sp, #5632]                 ; 16-byte Reload
	bit.16b	v0, v4, v10
	str	q0, [sp, #5632]                 ; 16-byte Spill
	ldr	q5, [sp, #5680]                 ; 16-byte Reload
	ldr	q0, [sp, #5648]                 ; 16-byte Reload
	bit.16b	v0, v5, v14
	str	q0, [sp, #5648]                 ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q11, [sp, #3120]                ; 16-byte Reload
	bit.16b	v11, v2, v3
	ldr	q3, [sp, #5712]                 ; 16-byte Reload
	ldr	q0, [sp, #5664]                 ; 16-byte Reload
	bit.16b	v0, v3, v1
	str	q0, [sp, #5664]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q7, [sp, #7408]                 ; 16-byte Reload
	bit.16b	v7, v4, v10
	ldr	q4, [sp, #7392]                 ; 16-byte Reload
	bit.16b	v4, v5, v14
	ldr	q16, [sp, #7376]                ; 16-byte Reload
	bit.16b	v16, v2, v1
	ldr	q27, [sp, #7360]                ; 16-byte Reload
	bit.16b	v27, v3, v0
	ldr	q2, [sp, #7728]                 ; 16-byte Reload
	bic.16b	v2, v2, v10
	str	q2, [sp, #7728]                 ; 16-byte Spill
	ldr	q3, [sp, #2992]                 ; 16-byte Reload
	bic.16b	v3, v3, v14
	ldr	q2, [sp, #7744]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #7744]                 ; 16-byte Spill
	ldr	q23, [sp, #3008]                ; 16-byte Reload
	bic.16b	v23, v23, v0
	fmov	x8, d23
	ldr	q0, [sp, #4512]                 ; 16-byte Reload
	shl.8b	v0, v0, #7
	str	d0, [sp, #7664]                 ; 8-byte Spill
	cmp	x8, #1
	str	q4, [sp, #7392]                 ; 16-byte Spill
	str	q16, [sp, #7376]                ; 16-byte Spill
	str	q7, [sp, #7408]                 ; 16-byte Spill
	b.lt	LBB0_233
; %bb.230:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	w10, [sp, #5052]                ; 4-byte Reload
	ldr	x13, [sp, #1008]                ; 8-byte Reload
	add	x16, sp, #6, lsl #12            ; =24576
	add	x16, x16, #1560
	add	x27, sp, #4, lsl #12            ; =16384
	add	x27, x27, #576
	ldr	q10, [sp, #3024]                ; 16-byte Reload
	ldr	q18, [sp, #5488]                ; 16-byte Reload
	ldr	q8, [sp, #5744]                 ; 16-byte Reload
	ldr	q16, [sp, #2960]                ; 16-byte Reload
	ldr	q19, [sp, #2928]                ; 16-byte Reload
	ldr	q12, [sp, #2912]                ; 16-byte Reload
	ldr	q25, [sp, #2896]                ; 16-byte Reload
	ldr	q9, [sp, #2768]                 ; 16-byte Reload
LBB0_231:                               ; %direct.false681
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q15, [sp, #3136]                ; 16-byte Spill
	str	q25, [sp, #2896]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q20, [sp, #4672]                ; 16-byte Reload
	ldr	q5, [sp, #11328]                ; 16-byte Reload
	bit.16b	v20, v2, v5
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q7, [sp, #4704]                 ; 16-byte Reload
	bit.16b	v7, v2, v14
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q17, [sp, #4688]                ; 16-byte Reload
	bit.16b	v17, v2, v1
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q4, [sp, #4720]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	bic.16b	v18, v18, v5
	bic.16b	v25, v19, v14
	bic.16b	v15, v12, v1
	bic.16b	v16, v16, v0
	mov.16b	v12, v16
	fmov	x8, d16
	cmp	x8, #0
	str	q27, [sp, #7360]                ; 16-byte Spill
	str	q10, [sp, #3024]                ; 16-byte Spill
	str	q3, [sp, #2992]                 ; 16-byte Spill
	str	q4, [sp, #4720]                 ; 16-byte Spill
	str	q7, [sp, #4704]                 ; 16-byte Spill
	str	q17, [sp, #4688]                ; 16-byte Spill
	str	q20, [sp, #4672]                ; 16-byte Spill
	b.le	LBB0_251
; %bb.232:                              ;   in Loop: Header=BB0_28 Depth=1
	add	x15, sp, #6, lsl #12            ; =24576
	add	x15, x15, #1528
	ldr	q16, [sp, #2976]                ; 16-byte Reload
	ldr	q19, [sp, #2944]                ; 16-byte Reload
	ldr	q26, [sp, #2816]                ; 16-byte Reload
	b	LBB0_253
LBB0_233:                               ; %direct.true680.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	x8, [sp, #96]                   ; 8-byte Reload
	ldp	q6, q5, [x8]
	str	q27, [sp, #17664]
	str	q4, [sp, #17680]
	str	q16, [sp, #17696]
	str	q7, [sp, #17712]
	ldp	x11, x8, [sp, #216]             ; 16-byte Folded Reload
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #1280
	ldr	x8, [x9, x8, lsl #3]
	ldr	x9, [sp, #4968]                 ; 8-byte Reload
	sub	x5, x8, x9
	ldr	q7, [sp, #4528]                 ; 16-byte Reload
	ldr	d17, [sp, #11400]               ; 8-byte Reload
	ldr	w10, [sp, #5052]                ; 4-byte Reload
	ldp	q21, q20, [sp, #656]            ; 32-byte Folded Reload
	ldp	q24, q22, [sp, #624]            ; 32-byte Folded Reload
	ldp	q13, q26, [sp, #592]            ; 32-byte Folded Reload
	ldr	x13, [sp, #1008]                ; 8-byte Reload
	add	x15, sp, #4, lsl #12            ; =16384
	add	x15, x15, #1216
	add	x16, sp, #6, lsl #12            ; =24576
	add	x16, x16, #1560
	add	x27, sp, #4, lsl #12            ; =16384
	add	x27, x27, #576
	ldr	q10, [sp, #3024]                ; 16-byte Reload
	ldr	q16, [sp, #2960]                ; 16-byte Reload
	ldr	q19, [sp, #2928]                ; 16-byte Reload
	ldr	q12, [sp, #2912]                ; 16-byte Reload
	ldr	q25, [sp, #2896]                ; 16-byte Reload
	ldr	q9, [sp, #2768]                 ; 16-byte Reload
	b	LBB0_235
LBB0_234:                               ; %else795
                                        ;   in Loop: Header=BB0_235 Depth=2
	movi	d1, #0x0000000000ffff
	ldr	q29, [sp, #11280]               ; 16-byte Reload
	bit.8b	v10, v1, v29
	ldr	q1, [sp, #7600]                 ; 16-byte Reload
	bit.16b	v1, v6, v20
	ldr	q4, [sp, #7632]                 ; 16-byte Reload
	bit.16b	v4, v5, v21
	and.16b	v18, v22, v4
	and.16b	v8, v24, v1
	bic.8b	v1, v29, v10
	bif.16b	v0, v25, v26
	ldr	q4, [sp, #7584]                 ; 16-byte Reload
	bif.16b	v2, v4, v13
	zip2.8b	v4, v1, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v4, v4, #0
	and.16b	v2, v4, v2
	zip1.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v25, v1, v0
	str	q8, [sp, #7600]                 ; 16-byte Spill
	fmaxnm.4s	v0, v8, v25
	str	q18, [sp, #7632]                ; 16-byte Spill
	str	q2, [sp, #7584]                 ; 16-byte Spill
	fmaxnm.4s	v1, v18, v2
	str	q23, [sp, #17600]
	str	q3, [sp, #17616]
	ldr	q8, [sp, #7744]                 ; 16-byte Reload
	str	q8, [sp, #17632]
	ldr	q18, [sp, #7728]                ; 16-byte Reload
	str	q18, [sp, #17648]
	ldr	x8, [x15, x11, lsl #3]
	add	x8, x5, x8, lsl #5
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x16, x8
	ldp	q2, q4, [x8]
	bif.16b	v1, v4, v13
	bif.16b	v0, v2, v26
	stp	q0, q1, [x8]
	add.2d	v3, v3, v28
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v8, v8, v0
	str	q8, [sp, #7744]                 ; 16-byte Spill
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v18, v18, v0
	str	q18, [sp, #7728]                ; 16-byte Spill
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v23, v23, v0
	fmov	x8, d23
	cmp	x8, #1
	ldr	q18, [sp, #5488]                ; 16-byte Reload
	ldr	q8, [sp, #5744]                 ; 16-byte Reload
	b.ge	LBB0_231
LBB0_235:                               ; %direct.true680
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v30, #0
	ldr	q1, [sp, #7616]                 ; 16-byte Reload
	bit.16b	v1, v7, v0
	ldr	d0, [sp, #7664]                 ; 8-byte Reload
	cmlt.8b	v0, v0, #0
	and.8b	v0, v0, v17
	addv.8b	b0, v0
	fmov	w8, s0
	str	q1, [sp, #7616]                 ; 16-byte Spill
	shl.2d	v0, v1, #5
	ldr	q1, [sp, #5664]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	ldr	q1, [sp, #5616]                 ; 16-byte Reload
	add.2d	v1, v1, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w8, #0, LBB0_237
; %bb.236:                              ; %cond.load749
                                        ;   in Loop: Header=BB0_235 Depth=2
	fmov	x9, d1
	ldr	s0, [x9]
LBB0_237:                               ; %else753
                                        ;   in Loop: Header=BB0_235 Depth=2
	tbz	w8, #1, LBB0_239
; %bb.238:                              ; %cond.load755
                                        ;   in Loop: Header=BB0_235 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_239:                               ; %else759
                                        ;   in Loop: Header=BB0_235 Depth=2
	ldr	q1, [sp, #7568]                 ; 16-byte Reload
	bic.16b	v1, v1, v14
	ssubw2.2d	v1, v1, v30
	str	q1, [sp, #7568]                 ; 16-byte Spill
	shl.2d	v1, v1, #5
	ldr	q4, [sp, #5648]                 ; 16-byte Reload
	orr.16b	v1, v1, v4
	ldr	q4, [sp, #5600]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	tbz	w8, #2, LBB0_241
; %bb.240:                              ; %cond.load761
                                        ;   in Loop: Header=BB0_235 Depth=2
	fmov	x9, d1
	ld1.s	{ v0 }[2], [x9]
LBB0_241:                               ; %else765
                                        ;   in Loop: Header=BB0_235 Depth=2
	tbz	w8, #3, LBB0_243
; %bb.242:                              ; %cond.load767
                                        ;   in Loop: Header=BB0_235 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v0 }[3], [x9]
LBB0_243:                               ; %else771
                                        ;   in Loop: Header=BB0_235 Depth=2
	sshll.2d	v1, v31, #0
	ldr	q4, [sp, #7552]                 ; 16-byte Reload
	bic.16b	v1, v4, v1
	ssubw.2d	v1, v1, v31
	str	q1, [sp, #7552]                 ; 16-byte Spill
	shl.2d	v1, v1, #5
	orr.16b	v1, v1, v11
	ldr	q4, [sp, #5584]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	tbz	w8, #4, LBB0_245
; %bb.244:                              ; %cond.load773
                                        ;   in Loop: Header=BB0_235 Depth=2
	fmov	x9, d1
	ld1.s	{ v2 }[0], [x9]
LBB0_245:                               ; %else777
                                        ;   in Loop: Header=BB0_235 Depth=2
	tbz	w8, #5, LBB0_247
; %bb.246:                              ; %cond.load779
                                        ;   in Loop: Header=BB0_235 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_247:                               ; %else783
                                        ;   in Loop: Header=BB0_235 Depth=2
	ldr	q1, [sp, #11328]                ; 16-byte Reload
	ldr	q4, [sp, #7648]                 ; 16-byte Reload
	bic.16b	v1, v4, v1
	ssubw2.2d	v1, v1, v31
	str	q1, [sp, #7648]                 ; 16-byte Spill
	shl.2d	v1, v1, #5
	ldr	q4, [sp, #5632]                 ; 16-byte Reload
	orr.16b	v1, v1, v4
	add.2d	v1, v15, v1
	tbz	w8, #6, LBB0_249
; %bb.248:                              ; %cond.load785
                                        ;   in Loop: Header=BB0_235 Depth=2
	fmov	x9, d1
	ld1.s	{ v2 }[2], [x9]
LBB0_249:                               ; %else789
                                        ;   in Loop: Header=BB0_235 Depth=2
	tbz	w8, #7, LBB0_234
; %bb.250:                              ; %cond.load791
                                        ;   in Loop: Header=BB0_235 Depth=2
	mov.d	x8, v1[1]
	ld1.s	{ v2 }[3], [x8]
	b	LBB0_234
LBB0_251:                               ; %direct.true699.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	x8, [sp, #104]                  ; 8-byte Reload
	add	x9, sp, #10, lsl #12            ; =40960
	add	x9, x9, #1728
	add	x8, x9, x8
	ldp	q2, q0, [x8]
	str	q0, [sp, #10720]                ; 16-byte Spill
	str	q27, [sp, #17536]
	ldr	q0, [sp, #7392]                 ; 16-byte Reload
	str	q0, [sp, #17552]
	ldr	q0, [sp, #7376]                 ; 16-byte Reload
	str	q0, [sp, #17568]
	ldr	q0, [sp, #7408]                 ; 16-byte Reload
	str	q0, [sp, #17584]
	ldr	x11, [sp, #208]                 ; 8-byte Reload
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1152
	ldr	x8, [x8, x11]
	ldr	x9, [sp, #4968]                 ; 8-byte Reload
	sub	x8, x8, x9
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x16, x8
	ldp	q6, q5, [x8]
	str	q4, [sp, #17472]
	str	q7, [sp, #17488]
	str	q17, [sp, #17504]
	str	q20, [sp, #17520]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #1088
	ldr	x8, [x8, x11]
	sub	x8, x8, x9
	ldp	q21, q20, [sp, #560]            ; 32-byte Folded Reload
	ldp	q24, q22, [sp, #528]            ; 32-byte Folded Reload
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #1024
	add	x15, sp, #6, lsl #12            ; =24576
	add	x15, x15, #1528
	ldr	q16, [sp, #2976]                ; 16-byte Reload
	ldr	q19, [sp, #2944]                ; 16-byte Reload
	ldr	q26, [sp, #2816]                ; 16-byte Reload
	ldr	q29, [sp, #11280]               ; 16-byte Reload
	ldr	q27, [sp, #11440]               ; 16-byte Reload
	ldr	q13, [sp, #11408]               ; 16-byte Reload
	ldr	q28, [sp, #11424]               ; 16-byte Reload
	ldr	q0, [sp, #11360]                ; 16-byte Reload
LBB0_252:                               ; %direct.true699
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	movi	d1, #0x0000000000ffff
	bit.8b	v8, v1, v29
	mov.16b	v1, v20
	bsl.16b	v1, v2, v19
	ldr	q4, [sp, #10720]                ; 16-byte Reload
	bif.16b	v4, v16, v21
	and.16b	v16, v22, v4
	and.16b	v19, v24, v1
	bic.8b	v1, v29, v8
	mov.16b	v4, v20
	bsl.16b	v4, v6, v9
	mov.16b	v7, v21
	bsl.16b	v7, v5, v26
	zip2.8b	v17, v1, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmge.4s	v17, v17, #0
	and.16b	v26, v17, v7
	zip1.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v9, v1, v4
	fsub.4s	v1, v19, v9
	fsub.4s	v4, v16, v26
	str	q12, [sp, #17408]
	str	q25, [sp, #17424]
	str	q15, [sp, #17440]
	str	q18, [sp, #17456]
	ldr	x9, [x11, x13, lsl #3]
	add	x9, x8, x9, lsl #5
	tst	w10, #0xff
	csel	x9, xzr, x9, eq
	add	x9, x15, x9
	ldp	q7, q17, [x9]
	bif.16b	v4, v17, v21
	bif.16b	v1, v7, v20
	stp	q1, q4, [x9]
	add.2d	v25, v25, v0
	add.2d	v15, v15, v27
	add.2d	v18, v18, v13
	add.2d	v12, v12, v28
	fmov	x9, d12
	cmp	x9, #1
	b.lt	LBB0_252
LBB0_253:                               ; %direct.false700
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q9, [sp, #2768]                 ; 16-byte Spill
	str	q26, [sp, #2816]                ; 16-byte Spill
	str	q15, [sp, #2912]                ; 16-byte Spill
	str	q25, [sp, #2928]                ; 16-byte Spill
	str	q19, [sp, #2944]                ; 16-byte Spill
	str	q12, [sp, #2960]                ; 16-byte Spill
	str	q16, [sp, #2976]                ; 16-byte Spill
	str	q11, [sp, #3120]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q19, [sp, #7136]                ; 16-byte Reload
	ldr	q5, [sp, #11328]                ; 16-byte Reload
	bit.16b	v19, v2, v5
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q6, [sp, #7168]                 ; 16-byte Reload
	bit.16b	v6, v2, v14
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q24, [sp, #7152]                ; 16-byte Reload
	bit.16b	v24, v2, v1
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q4, [sp, #7184]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	ldr	q9, [sp, #2784]                 ; 16-byte Reload
	bic.16b	v9, v9, v5
	ldr	q7, [sp, #2848]                 ; 16-byte Reload
	bic.16b	v7, v7, v14
	ldr	q13, [sp, #2800]                ; 16-byte Reload
	bic.16b	v13, v13, v1
	ldr	q12, [sp, #2880]                ; 16-byte Reload
	bic.16b	v12, v12, v0
	mov	w8, #-1026555904                ; =0xc2d00000
	dup.4s	v20, w8
	mov	w8, #1120403456                 ; =0x42c80000
	dup.4s	v21, w8
	mov	w8, #43579                      ; =0xaa3b
	movk	w8, #16312, lsl #16
	dup.4s	v22, w8
	mov	w8, #29184                      ; =0x7200
	movk	w8, #48945, lsl #16
	dup.4s	v0, w8
	str	q0, [sp, #6784]                 ; 16-byte Spill
	mov	w8, #48782                      ; =0xbe8e
	movk	w8, #46527, lsl #16
	dup.4s	v0, w8
	str	q0, [sp, #6768]                 ; 16-byte Spill
	mov	w8, #11226                      ; =0x2bda
	movk	w8, #14672, lsl #16
	dup.4s	v0, w8
	str	q0, [sp, #6752]                 ; 16-byte Spill
	mov	w8, #38601                      ; =0x96c9
	movk	w8, #15030, lsl #16
	dup.4s	v0, w8
	str	q0, [sp, #6736]                 ; 16-byte Spill
	mov	w8, #34982                      ; =0x88a6
	movk	w8, #15368, lsl #16
	dup.4s	v0, w8
	str	q0, [sp, #6720]                 ; 16-byte Spill
	fmov	x8, d12
	mov	w9, #43642                      ; =0xaa7a
	movk	w9, #15658, lsl #16
	dup.4s	v0, w9
	str	q0, [sp, #1328]                 ; 16-byte Spill
	mov	w9, #43691                      ; =0xaaab
	movk	w9, #15914, lsl #16
	dup.4s	v0, w9
	str	q0, [sp, #1312]                 ; 16-byte Spill
	cmp	x8, #0
	str	q4, [sp, #7184]                 ; 16-byte Spill
	str	q6, [sp, #7168]                 ; 16-byte Spill
	str	q20, [sp, #5472]                ; 16-byte Spill
	str	q21, [sp, #7680]                ; 16-byte Spill
	str	q22, [sp, #10672]               ; 16-byte Spill
	str	q24, [sp, #7152]                ; 16-byte Spill
	str	q19, [sp, #7136]                ; 16-byte Spill
	b.le	LBB0_255
; %bb.254:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	q19, [sp, #2864]                ; 16-byte Reload
	ldr	q26, [sp, #2832]                ; 16-byte Reload
	b	LBB0_257
LBB0_255:                               ; %direct.true720.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q0, [sp, #4720]                 ; 16-byte Reload
	str	q0, [sp, #17344]
	ldr	q0, [sp, #4704]                 ; 16-byte Reload
	str	q0, [sp, #17360]
	ldr	q0, [sp, #4688]                 ; 16-byte Reload
	str	q0, [sp, #17376]
	ldr	q0, [sp, #4672]                 ; 16-byte Reload
	str	q0, [sp, #17392]
	ldr	x11, [sp, #200]                 ; 8-byte Reload
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #960
	ldr	x8, [x8, x11]
	ldr	x9, [sp, #4968]                 ; 8-byte Reload
	sub	x8, x8, x9
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x15, x8
	ldp	q0, q1, [x8]
	str	q1, [sp, #10720]                ; 16-byte Spill
	str	q0, [sp, #10704]                ; 16-byte Spill
	str	q4, [sp, #17280]
	str	q6, [sp, #17296]
	str	q24, [sp, #17312]
	str	q19, [sp, #17328]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #896
	ldr	x8, [x8, x11]
	sub	x8, x8, x9
	ldp	q27, q24, [sp, #496]            ; 32-byte Folded Reload
	ldr	q25, [sp, #6704]                ; 16-byte Reload
	ldr	q15, [sp, #6688]                ; 16-byte Reload
	ldr	x11, [sp, #192]                 ; 8-byte Reload
	add	x13, sp, #4, lsl #12            ; =16384
	add	x13, x13, #832
	add	x15, sp, #6, lsl #12            ; =24576
	add	x15, x15, #1496
	ldr	q19, [sp, #2864]                ; 16-byte Reload
	ldr	q26, [sp, #2832]                ; 16-byte Reload
	ldr	q29, [sp, #6784]                ; 16-byte Reload
	ldr	q2, [sp, #6768]                 ; 16-byte Reload
	ldr	q5, [sp, #6752]                 ; 16-byte Reload
	ldr	q28, [sp, #6736]                ; 16-byte Reload
	ldr	q14, [sp, #6720]                ; 16-byte Reload
	ldr	q3, [sp, #1328]                 ; 16-byte Reload
	ldr	q11, [sp, #1312]                ; 16-byte Reload
	fmov.4s	v10, #1.00000000
LBB0_256:                               ; %direct.true720
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	ldr	q0, [sp, #10704]                ; 16-byte Reload
	bif.16b	v0, v26, v24
	ldr	q1, [sp, #10720]                ; 16-byte Reload
	bif.16b	v1, v19, v27
	ldr	q4, [sp, #5456]                 ; 16-byte Reload
	and.16b	v19, v4, v1
	ldr	q1, [sp, #5440]                 ; 16-byte Reload
	and.16b	v26, v1, v0
	and.16b	v6, v30, v26
	and.16b	v0, v31, v19
	fcmge.4s	v1, v0, v20
	fcmge.4s	v4, v6, v20
	mov.16b	v16, v7
	fcmge.4s	v7, v21, v0
	ldr	q17, [sp, #7680]                ; 16-byte Reload
	fcmge.4s	v17, v17, v6
	and.16b	v4, v4, v17
	and.16b	v1, v1, v7
	and.16b	v1, v1, v0
	and.16b	v4, v4, v6
	fmul.4s	v7, v4, v22
	fmul.4s	v17, v1, v22
	movi.4s	v21, #75, lsl #24
	mvni.4s	v22, #128, lsl #24
	mov.16b	v20, v22
	bsl.16b	v20, v21, v17
	bif.16b	v21, v7, v22
	fadd.4s	v7, v7, v21
	fadd.4s	v17, v17, v20
	fsub.4s	v17, v17, v20
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v7, v7
	fcvtzs.4s	v17, v17
	scvtf.4s	v20, v17
	scvtf.4s	v21, v7
	fmul.4s	v22, v20, v29
	fadd.4s	v1, v1, v22
	fmul.4s	v22, v21, v29
	fadd.4s	v4, v4, v22
	fmul.4s	v20, v20, v2
	fmul.4s	v21, v21, v2
	fadd.4s	v4, v4, v21
	fadd.4s	v1, v1, v20
	fmul.4s	v20, v1, v5
	fmul.4s	v21, v4, v5
	fadd.4s	v21, v21, v28
	fadd.4s	v20, v20, v28
	fmul.4s	v20, v1, v20
	fmul.4s	v21, v4, v21
	fadd.4s	v21, v21, v14
	fadd.4s	v20, v20, v14
	fmul.4s	v20, v1, v20
	fmul.4s	v21, v4, v21
	fadd.4s	v21, v21, v3
	fadd.4s	v20, v20, v3
	fmul.4s	v20, v1, v20
	fmul.4s	v21, v4, v21
	fadd.4s	v21, v21, v11
	fadd.4s	v20, v20, v11
	fmul.4s	v20, v1, v20
	fmul.4s	v21, v4, v21
	movi.4s	v22, #63, lsl #24
	fadd.4s	v21, v21, v22
	fadd.4s	v20, v20, v22
	fmul.4s	v22, v1, v1
	fmul.4s	v20, v22, v20
	fmul.4s	v22, v4, v4
	fmul.4s	v21, v22, v21
	fadd.4s	v4, v4, v21
	fadd.4s	v1, v1, v20
	fadd.4s	v1, v1, v10
	sshr.4s	v20, v17, #1
	sshr.4s	v21, v7, #1
	fadd.4s	v4, v4, v10
	shl.4s	v22, v21, #23
	add.4s	v22, v22, v10
	fmul.4s	v4, v4, v22
	shl.4s	v22, v20, #23
	add.4s	v22, v22, v10
	fmul.4s	v1, v1, v22
	ldr	q22, [sp, #10672]               ; 16-byte Reload
	sub.4s	v7, v7, v21
	sub.4s	v17, v17, v20
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v10
	fmul.4s	v1, v1, v17
	ldr	q21, [sp, #7680]                ; 16-byte Reload
	ldr	q20, [sp, #5472]                ; 16-byte Reload
	shl.4s	v7, v7, #23
	add.4s	v7, v7, v10
	fmul.4s	v4, v4, v7
	fcmgt.4s	v7, v20, v6
	bic.16b	v4, v4, v7
	fcmgt.4s	v7, v20, v0
	bic.16b	v1, v1, v7
	fcmgt.4s	v7, v0, v21
	bit.16b	v1, v25, v7
	fcmgt.4s	v7, v6, v21
	bit.16b	v4, v25, v7
	fcmeq.4s	v6, v6, v6
	bif.16b	v4, v15, v6
	str	q12, [sp, #17216]
	str	q16, [sp, #17232]
	str	q13, [sp, #17248]
	str	q9, [sp, #17264]
	ldr	x9, [x13, x11, lsl #3]
	fcmeq.4s	v0, v0, v0
	add	x9, x8, x9, lsl #5
	tst	w10, #0xff
	csel	x9, xzr, x9, eq
	add	x9, x15, x9
	bsl.16b	v0, v1, v15
	ldp	q1, q6, [x9]
	bif.16b	v0, v6, v27
	bit.16b	v1, v4, v24
	stp	q1, q0, [x9]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v7, v16, v0
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v13, v13, v0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v9, v9, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v12, v12, v0
	fmov	x9, d12
	cmp	x9, #1
	b.lt	LBB0_256
LBB0_257:                               ; %direct.false721
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q9, [sp, #2784]                 ; 16-byte Spill
	str	q13, [sp, #2800]                ; 16-byte Spill
	str	q26, [sp, #2832]                ; 16-byte Spill
	str	q7, [sp, #2848]                 ; 16-byte Spill
	str	q19, [sp, #2864]                ; 16-byte Spill
	str	q12, [sp, #2880]                ; 16-byte Spill
	str	q8, [sp, #5744]                 ; 16-byte Spill
	str	q18, [sp, #5488]                ; 16-byte Spill
	str	q23, [sp, #3008]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q4, [sp, #9264]                 ; 16-byte Reload
	ldr	q3, [sp, #11328]                ; 16-byte Reload
	bit.16b	v4, v2, v3
	str	q4, [sp, #9264]                 ; 16-byte Spill
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q4, [sp, #9296]                 ; 16-byte Reload
	ldr	q29, [sp, #11344]               ; 16-byte Reload
	bit.16b	v4, v2, v29
	str	q4, [sp, #9296]                 ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q4, [sp, #9280]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #9280]                 ; 16-byte Spill
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q4, [sp, #9312]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #9312]                 ; 16-byte Spill
	ldr	q2, [sp, #10400]                ; 16-byte Reload
	bic.16b	v2, v2, v3
	ldr	q4, [sp, #10096]                ; 16-byte Reload
	bic.16b	v4, v4, v29
	ldr	q15, [sp, #10128]               ; 16-byte Reload
	bic.16b	v15, v15, v1
	ldr	q1, [sp, #10112]                ; 16-byte Reload
	bic.16b	v1, v1, v0
	fmov	x8, d1
	cmp	x8, #17
	ldr	q28, [sp, #10608]               ; 16-byte Reload
	b.gt	LBB0_260
; %bb.258:                              ; %direct.true735.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q19, [sp, #2752]                ; 16-byte Reload
	ldr	q13, [sp, #2736]                ; 16-byte Reload
	ldr	q5, [sp, #9232]                 ; 16-byte Reload
	ldr	q11, [sp, #5120]                ; 16-byte Reload
	ldr	q25, [sp, #5104]                ; 16-byte Reload
	ldr	q14, [sp, #2656]                ; 16-byte Reload
	ldr	q6, [sp, #9168]                 ; 16-byte Reload
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	ldr	q24, [sp, #11232]               ; 16-byte Reload
	ldr	q10, [sp, #11376]               ; 16-byte Reload
	ldr	x1, [sp, #10440]                ; 8-byte Reload
	ldr	w2, [sp, #10316]                ; 4-byte Reload
	ldr	w7, [sp, #5372]                 ; 4-byte Reload
	ldr	w4, [sp, #7356]                 ; 4-byte Reload
	ldr	w20, [sp, #10092]               ; 4-byte Reload
	ldr	w21, [sp, #5368]                ; 4-byte Reload
	ldr	w22, [sp, #7836]                ; 4-byte Reload
	ldr	x15, [sp, #5360]                ; 8-byte Reload
	ldr	w24, [sp, #10420]               ; 4-byte Reload
	ldr	q18, [sp, #11312]               ; 16-byte Reload
LBB0_259:                               ; %direct.true735
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	q2, [sp, #10400]                ; 16-byte Spill
	str	q6, [sp, #9168]                 ; 16-byte Spill
	str	q5, [sp, #9232]                 ; 16-byte Spill
	str	q1, [sp, #10112]                ; 16-byte Spill
	str	q4, [sp, #10096]                ; 16-byte Spill
	str	q15, [sp, #10128]               ; 16-byte Spill
	sshll.2d	v21, v30, #0
	sshll.2d	v22, v31, #0
	ldr	q16, [sp, #11328]               ; 16-byte Reload
	ldr	q0, [sp, #10400]                ; 16-byte Reload
	and.16b	v2, v16, v0
	and.16b	v0, v29, v4
	and.16b	v6, v22, v15
	and.16b	v5, v21, v1
	fmov	x8, d5
	ldr	q1, [sp, #11136]                ; 16-byte Reload
	fmov	x9, d1
	sdiv	x8, x8, x9
	mov.d	x10, v5[1]
	fmov	x11, d6
	fmov	x13, d18
	sdiv	x11, x11, x13
	sdiv	x10, x10, x25
	mov.d	x17, v6[1]
	sdiv	x17, x17, x15
	fmov	x3, d0
	mul	x9, x8, x9
	fmov	d4, x8
	fmov	x8, d28
	sdiv	x3, x3, x8
	mul	x8, x3, x8
	fmov	d1, x3
	mul	x13, x11, x13
	fmov	d17, x11
	mov.d	x11, v0[1]
	sdiv	x11, x11, x1
	fmov	x3, d2
	mov.d	v1[1], x11
	ldr	q7, [sp, #11296]                ; 16-byte Reload
	fmov	x5, d7
	sdiv	x3, x3, x5
	mov.d	x6, v2[1]
	mov.d	v4[1], x10
	fmov	d26, x3
	sdiv	x6, x6, x26
	mov.d	v26[1], x6
	mov.d	v17[1], x17
	mul	x10, x10, x25
	fmov	d23, x9
	mul	x9, x11, x1
	fmov	d28, x8
	mov.d	v23[1], x10
	mov.d	v28[1], x9
	mul	x8, x17, x15
	fmov	d20, x13
	mov.d	v20[1], x8
	mul	x8, x3, x5
	mul	x9, x6, x26
	fmov	d7, x8
	mov.d	v7[1], x9
	sub.2d	v7, v2, v7
	sub.2d	v20, v6, v20
	sub.2d	v0, v0, v28
	sub.2d	v2, v5, v23
	shl.2d	v12, v2, #3
	str	q12, [sp, #10704]               ; 16-byte Spill
	shl.2d	v18, v0, #3
	str	q18, [sp, #10720]               ; 16-byte Spill
	shl.2d	v6, v20, #3
	shl.2d	v23, v7, #3
	ldr	q9, [sp, #10480]                ; 16-byte Reload
	cmgt.2d	v5, v9, v23
	ldr	q27, [sp, #10512]               ; 16-byte Reload
	cmgt.2d	v28, v27, v6
	mov.16b	v8, v11
	mov.16b	v11, v19
	uzp1.4s	v19, v28, v5
	str	q19, [sp, #10688]               ; 16-byte Spill
	ldr	q15, [sp, #10496]               ; 16-byte Reload
	cmgt.2d	v28, v15, v18
	ldr	q18, [sp, #10576]               ; 16-byte Reload
	mov.16b	v5, v24
	mov.16b	v24, v29
	cmgt.2d	v29, v18, v12
	uzp1.4s	v12, v29, v28
	and.16b	v4, v21, v4
	mov.d	x8, v4[1]
	fmov	x9, d4
	uzp1.8h	v4, v12, v19
	mov.16b	v19, v11
	and.16b	v26, v16, v26
	and.16b	v1, v24, v1
	and.16b	v17, v22, v17
	ldr	q18, [sp, #10544]               ; 16-byte Reload
	fmov	x10, d18
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	sdiv	x10, x8, x12
	mov.d	x11, v17[1]
	fmov	x13, d17
	ldr	q17, [sp, #10560]               ; 16-byte Reload
	fmov	x17, d17
	msub	x8, x10, x12, x8
	sdiv	x10, x13, x17
	msub	x10, x10, x17, x13
	sdiv	x13, x11, x30
	mov.d	x17, v1[1]
	msub	x11, x13, x30, x11
	fmov	x13, d1
	ldr	q1, [sp, #10528]                ; 16-byte Reload
	fmov	x3, d1
	sdiv	x5, x13, x3
	mov.d	x23, v26[1]
	fmov	d1, x9
	msub	x9, x5, x3, x13
	fmov	x13, d26
	and.16b	v4, v10, v4
	xtn.8b	v4, v4
	shl.8b	v4, v4, #7
	fmov	d26, x10
	cmlt.8b	v4, v4, #0
	umaxv.8b	b17, v4
	fmov	w10, s17
	fmov	d28, x9
	mov.d	v1[1], x8
	sdiv	x8, x17, x19
	msub	x8, x8, x19, x17
	mov.d	v28[1], x8
	mov.d	v26[1], x11
	ldr	q17, [sp, #10592]               ; 16-byte Reload
	fmov	x8, d17
	sdiv	x9, x13, x8
	msub	x8, x9, x8, x13
	ldr	d17, [sp, #11400]               ; 8-byte Reload
	and.8b	v4, v4, v17
	addv.8b	b4, v4
	fmov	w6, s4
	fmov	d4, x8
	sdiv	x8, x23, x28
	msub	x8, x8, x28, x23
	mov.d	v4[1], x8
	cmge.2d	v17, v23, v9
	cmge.2d	v6, v6, v27
	rbit	w8, w6
	clz	w8, w8
	tst	w10, #0x1
	ldr	q18, [sp, #10384]               ; 16-byte Reload
	str	q18, [sp, #16960]
	csel	w25, w8, wzr, ne
	ldr	q18, [sp, #10144]               ; 16-byte Reload
	str	q18, [sp, #16976]
	ldr	q18, [sp, #10368]               ; 16-byte Reload
	str	q18, [sp, #16992]
	ldr	q18, [sp, #10160]               ; 16-byte Reload
	str	q18, [sp, #17008]
	ubfiz	x5, x25, #3, #3
	ldr	x26, [x27, x5]
	str	q4, [sp, #17072]
	str	q26, [sp, #17056]
	str	q28, [sp, #17040]
	str	q1, [sp, #17024]
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #640
	ldr	x27, [x8, x5]
	uzp1.4s	v6, v6, v17
	str	q0, [sp, #17104]
	and.16b	v17, v16, v4
	and.16b	v23, v24, v28
	and.16b	v29, v22, v26
	and.16b	v28, v21, v1
	mov.d	x8, v28[1]
	ldr	q0, [sp, #11040]                ; 16-byte Reload
	mov.d	x13, v0[1]
	fmov	x9, d0
	fmov	x10, d28
	ldr	q4, [sp, #11056]                ; 16-byte Reload
	mov.d	x3, v4[1]
	mov.d	x11, v17[1]
	str	q7, [sp, #17136]
	str	q20, [sp, #17120]
	sdiv	x10, x10, x9
	ldr	q1, [sp, #11168]                ; 16-byte Reload
	mov.d	x23, v1[1]
	fmov	x17, d17
	mul	x9, x10, x9
	fmov	d0, x10
	fmov	x10, d1
	sdiv	x17, x17, x10
	mul	x10, x17, x10
	fmov	d1, x10
	mov.d	x10, v29[1]
	sdiv	x11, x11, x23
	mul	x23, x11, x23
	mov.d	v1[1], x23
	fmov	x23, d29
	str	q2, [sp, #17088]
	fmov	d2, x9
	fmov	x9, d4
	sdiv	x23, x23, x9
	mul	x9, x23, x9
	sub.2d	v7, v17, v1
	fmov	d1, x9
	ldr	q4, [sp, #11152]                ; 16-byte Reload
	mov.d	x9, v4[1]
	sdiv	x8, x8, x13
	mul	x13, x8, x13
	mov.d	v2[1], x13
	fmov	x13, d4
	sdiv	x10, x10, x3
	mul	x3, x10, x3
	mov.d	v1[1], x3
	fmov	x3, d23
	sdiv	x3, x3, x13
	mul	x13, x3, x13
	sub.2d	v1, v29, v1
	mov.16b	v29, v24
	fmov	d4, x13
	mov.d	x13, v23[1]
	sdiv	x13, x13, x9
	mul	x9, x13, x9
	mov.d	v4[1], x9
	sub.2d	v4, v23, v4
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	fmov	d17, x23
	sub.2d	v2, v28, v2
	ldr	q28, [sp, #10608]               ; 16-byte Reload
	ldr	q26, [sp, #10576]               ; 16-byte Reload
	fmov	d20, x3
	mov.d	v20[1], x13
	mov.d	v0[1], x8
	mov.16b	v11, v21
	bsl.16b	v11, v2, v8
	bit.16b	v19, v1, v22
	ldr	q18, [sp, #11248]               ; 16-byte Reload
	cmeq.2d	v21, v18, v7
	cmeq.2d	v1, v5, v1
	ldr	q18, [sp, #11200]               ; 16-byte Reload
	cmeq.2d	v22, v18, v4
	uzp1.4s	v1, v1, v21
	ldr	q18, [sp, #11264]               ; 16-byte Reload
	cmeq.2d	v2, v18, v2
	uzp1.4s	v2, v2, v22
	uzp1.8h	v21, v2, v1
	and.16b	v21, v10, v21
	mov.d	v17[1], x10
	xtn.8b	v21, v21
	shl.8b	v21, v21, #7
	cmlt.8b	v21, v21, #0
	ldr	d18, [sp, #11400]               ; 8-byte Reload
	and.8b	v22, v21, v18
	ldr	q18, [sp, #11312]               ; 16-byte Reload
	ldr	q24, [sp, #11232]               ; 16-byte Reload
	ldr	q10, [sp, #11376]               ; 16-byte Reload
	addv.8b	b22, v22
	fmov	w8, s22
	fmov	d22, x17
	mov.d	v22[1], x11
	umaxv.8b	b21, v21
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #704
	ldr	x23, [x9, x5]
	fmov	w9, s21
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	ldr	q5, [sp, #7360]                 ; 16-byte Reload
	str	q5, [sp, #16832]
	ldr	q21, [sp, #7392]                ; 16-byte Reload
	str	q21, [sp, #16848]
	ldr	q21, [sp, #7376]                ; 16-byte Reload
	str	q21, [sp, #16864]
	ldr	q21, [sp, #7408]                ; 16-byte Reload
	str	q21, [sp, #16880]
	ubfiz	x10, x9, #3, #3
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #448
	ldr	x11, [x11, x10]
	bit.16b	v25, v4, v29
	lsl	w9, w9, #2
	sub	x9, x11, x9
	str	q22, [sp, #16944]
	and.16b	v4, v30, v2
	str	q17, [sp, #16928]
	and.16b	v17, v31, v1
	str	q20, [sp, #16912]
	str	q0, [sp, #16896]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #512
	ldr	x10, [x11, x10]
	bic.16b	v0, v31, v1
	bic.16b	v2, v30, v2
	add	x9, x9, x10, lsl #5
	tst	w8, #0xff
	csel	x8, xzr, x9, eq
	add	x8, x16, x8
	ldp	q1, q20, [x8]
	bsl.16b	v17, v20, v3
	bsl.16b	v4, v1, v14
	xtn.2s	v1, v25
	xtn.2s	v20, v11
	bic.16b	v14, v4, v2
	mov.s	w8, v20[1]
	fmov	w9, s20
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	bic.16b	v3, v17, v0
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #120
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	str	d0, [sp, #16504]
	ldrb	w10, [x10]
	str	q3, [sp, #16816]
	str	q14, [sp, #16800]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #416
	ldr	s2, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w0, w10
	xtn.2s	v0, v19
	tst	w9, w10
	movi.2d	v17, #0000000000000000
	fcsel	s21, s2, s17, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #120
	cset	w10, lo
	bfxil	x9, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w9, [x9]
	str	q3, [sp, #16784]
	str	q14, [sp, #16768]
	and	w9, w24, w9
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #384
	ldr	s2, [x11, x8, lsl #2]
	tst	w10, w9
	mov.s	w8, v1[1]
	fcsel	s2, s2, s17, ne
	fmov	w9, s1
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #120
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q3, [sp, #16752]
	str	q14, [sp, #16736]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #352
	ldr	s1, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w2, w10
	tst	w9, w10
	fcsel	s20, s1, s17, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #120
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	str	q3, [sp, #16720]
	and	w10, w7, w10
	str	q14, [sp, #16704]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #320
	ldr	s1, [x11, x8, lsl #2]
	mov.s	w8, v0[1]
	tst	w9, w10
	fcsel	s22, s1, s17, ne
	fmov	w9, s0
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #120
	bit.16b	v13, v7, v16
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q3, [sp, #16688]
	str	q14, [sp, #16672]
	xtn.2s	v4, v13
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #288
	ldr	s0, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w4, w10
	tst	w9, w10
	fcsel	s0, s0, s17, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #120
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	str	q3, [sp, #16656]
	str	q14, [sp, #16640]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #256
	ldr	s1, [x11, x8, lsl #2]
	and	w8, w20, w10
	tst	w9, w8
	fcsel	s1, s1, s17, ne
	mov.s	w8, v4[1]
	fmov	w9, s4
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #120
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q3, [sp, #16624]
	str	q14, [sp, #16608]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #224
	ldr	s4, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w21, w10
	tst	w9, w10
	fcsel	s4, s4, s17, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #4, lsl #12            ; =16384
	add	x10, x10, #120
	bfxil	x10, x8, #0, #3
	ldrb	w10, [x10]
	and	w10, w22, w10
	tst	w9, w10
	add	x9, x27, x27, lsl #3
	add	x27, sp, #4, lsl #12            ; =16384
	add	x27, x27, #576
	ldr	x19, [sp, #10432]               ; 8-byte Reload
	add	x9, x9, x23
	lsl	w10, w25, #2
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	sub	x11, x26, x10
	ldr	x26, [sp, #10448]               ; 8-byte Reload
	add	x9, x11, x9, lsl #5
	and	x8, x8, #0x7
	mov.s	v0[1], v1[0]
	str	q3, [sp, #16592]
	str	q14, [sp, #16576]
	add	x11, sp, #4, lsl #12            ; =16384
	add	x11, x11, #192
	ldr	s1, [x11, x8, lsl #2]
	fcsel	s1, s1, s17, ne
	tst	w6, #0xff
	ldr	q5, [sp, #10688]                ; 16-byte Reload
	and.16b	v5, v31, v5
	ldr	q7, [sp, #9312]                 ; 16-byte Reload
	str	q7, [sp, #16512]
	ldr	q7, [sp, #9296]                 ; 16-byte Reload
	str	q7, [sp, #16528]
	ldr	q7, [sp, #9280]                 ; 16-byte Reload
	str	q7, [sp, #16544]
	ldr	q7, [sp, #9264]                 ; 16-byte Reload
	str	q7, [sp, #16560]
	csel	x8, xzr, x9, eq
	add	x8, x14, x8
	mov.s	v0[2], v4[0]
	mov.s	v0[3], v1[0]
	ldp	q4, q1, [x8]
	ldr	q7, [sp, #9168]                 ; 16-byte Reload
	bif.16b	v1, v7, v5
	add	x8, sp, #4, lsl #12             ; =16384
	add	x8, x8, #128
	ldr	x8, [x8, x5]
	sub	x8, x8, x10
	ldr	q7, [sp, #10112]                ; 16-byte Reload
	str	q7, [sp, #17152]
	ldr	q7, [sp, #10096]                ; 16-byte Reload
	str	q7, [sp, #17168]
	ldr	q7, [sp, #10128]                ; 16-byte Reload
	str	q7, [sp, #17184]
	ldr	q7, [sp, #10400]                ; 16-byte Reload
	str	q7, [sp, #17200]
	add	x9, sp, #4, lsl #12             ; =16384
	add	x9, x9, #768
	ldr	x9, [x9, x5]
	add	x8, x8, x9, lsl #5
	and.16b	v6, v31, v6
	bic.16b	v6, v1, v6
	fsub.4s	v0, v6, v0
	csel	x8, xzr, x8, eq
	add	x9, sp, #6, lsl #12             ; =24576
	add	x9, x9, #920
	add	x8, x9, x8
	ldr	q1, [x8, #16]
	bif.16b	v0, v1, v5
	ldr	q1, [sp, #10720]                ; 16-byte Reload
	cmge.2d	v1, v1, v15
	ldr	q5, [sp, #10704]                ; 16-byte Reload
	cmge.2d	v5, v5, v26
	uzp1.4s	v1, v5, v1
	mov.s	v21[1], v2[0]
	and.16b	v2, v30, v12
	ldr	q5, [sp, #9232]                 ; 16-byte Reload
	bif.16b	v4, v5, v2
	mov.s	v21[2], v20[0]
	mov.s	v21[3], v22[0]
	and.16b	v1, v30, v1
	bic.16b	v5, v4, v1
	ldr	q1, [x8]
	fsub.4s	v4, v5, v21
	bit.16b	v1, v4, v2
	ldr	q4, [sp, #10096]                ; 16-byte Reload
	ldr	q2, [sp, #10400]                ; 16-byte Reload
	stp	q1, q0, [x8]
	ldr	q1, [sp, #10112]                ; 16-byte Reload
	ldr	q15, [sp, #10128]               ; 16-byte Reload
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v4, v4, v0
	add.2d	v15, v15, v23
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v2, v2, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v1, v1, v0
	fmov	x8, d1
	cmp	x8, #18
	b.lt	LBB0_259
	b	LBB0_261
LBB0_260:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	q19, [sp, #2752]                ; 16-byte Reload
	ldr	q13, [sp, #2736]                ; 16-byte Reload
	ldr	q5, [sp, #9232]                 ; 16-byte Reload
	ldr	q11, [sp, #5120]                ; 16-byte Reload
	ldr	q25, [sp, #5104]                ; 16-byte Reload
	ldr	q14, [sp, #2656]                ; 16-byte Reload
	ldr	q6, [sp, #9168]                 ; 16-byte Reload
	ldr	q3, [sp, #2528]                 ; 16-byte Reload
	ldr	q26, [sp, #10576]               ; 16-byte Reload
LBB0_261:                               ; %direct.false736
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q3, [sp, #2528]                 ; 16-byte Spill
	str	q6, [sp, #9168]                 ; 16-byte Spill
	str	q14, [sp, #2656]                ; 16-byte Spill
	str	q25, [sp, #5104]                ; 16-byte Spill
	str	q11, [sp, #5120]                ; 16-byte Spill
	str	q5, [sp, #9232]                 ; 16-byte Spill
	str	q19, [sp, #2752]                ; 16-byte Spill
	str	q4, [sp, #10096]                ; 16-byte Spill
	str	q1, [sp, #10112]                ; 16-byte Spill
	str	q13, [sp, #2736]                ; 16-byte Spill
	str	q2, [sp, #10400]                ; 16-byte Spill
	str	q15, [sp, #10128]               ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q4, [sp, #9216]                 ; 16-byte Reload
	ldr	q3, [sp, #11328]                ; 16-byte Reload
	bit.16b	v4, v2, v3
	str	q4, [sp, #9216]                 ; 16-byte Spill
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q4, [sp, #9184]                 ; 16-byte Reload
	bit.16b	v4, v2, v29
	str	q4, [sp, #9184]                 ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q4, [sp, #9248]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	str	q4, [sp, #9248]                 ; 16-byte Spill
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q4, [sp, #9200]                 ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #9200]                 ; 16-byte Spill
	ldr	q16, [sp, #2672]                ; 16-byte Reload
	bic.16b	v16, v16, v3
	ldr	q9, [sp, #2704]                 ; 16-byte Reload
	bic.16b	v9, v9, v29
	ldr	q11, [sp, #2688]                ; 16-byte Reload
	bic.16b	v11, v11, v1
	ldr	q29, [sp, #2720]                ; 16-byte Reload
	bic.16b	v29, v29, v0
	fmov	x8, d29
	cmp	x8, #17
	b.gt	LBB0_264
; %bb.262:                              ; %direct.true762.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	add	x16, sp, #3, lsl #12            ; =12288
	add	x16, x16, #4016
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #4080
	add	x26, sp, #3, lsl #12            ; =12288
	add	x26, x26, #3888
	add	x14, sp, #4, lsl #12            ; =16384
	add	x14, x14, #48
	add	x15, sp, #6, lsl #12            ; =24576
	add	x15, x15, #344
	ldr	q13, [sp, #2640]                ; 16-byte Reload
	ldr	q10, [sp, #2624]                ; 16-byte Reload
	fmov.4s	v12, #1.00000000
	ldr	x1, [sp, #10440]                ; 8-byte Reload
	ldr	w7, [sp, #5372]                 ; 4-byte Reload
	ldr	w27, [sp, #7356]                ; 4-byte Reload
	ldr	w20, [sp, #10092]               ; 4-byte Reload
	ldr	w21, [sp, #5368]                ; 4-byte Reload
	ldr	x22, [sp, #5360]                ; 8-byte Reload
	ldr	x2, [sp, #10448]                ; 8-byte Reload
	mov.16b	v19, v26
	ldr	q25, [sp, #5472]                ; 16-byte Reload
	ldr	q15, [sp, #7680]                ; 16-byte Reload
	ldr	q14, [sp, #1328]                ; 16-byte Reload
	ldr	q27, [sp, #1312]                ; 16-byte Reload
LBB0_263:                               ; %direct.true762
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v30, #0
	sshll.2d	v23, v31, #0
	ldr	q24, [sp, #11328]               ; 16-byte Reload
	and.16b	v2, v24, v16
	ldr	q3, [sp, #11344]                ; 16-byte Reload
	and.16b	v1, v3, v9
	and.16b	v5, v23, v11
	and.16b	v4, v0, v29
	ldr	q6, [sp, #11136]                ; 16-byte Reload
	fmov	x9, d6
	fmov	x8, d4
	sdiv	x8, x8, x9
	mov.d	x10, v4[1]
	fmov	x11, d5
	ldr	q6, [sp, #11312]                ; 16-byte Reload
	fmov	x6, d6
	sdiv	x13, x11, x6
	mov.d	x11, v5[1]
	fmov	x17, d1
	fmov	x23, d28
	sdiv	x17, x17, x23
	sdiv	x10, x10, x25
	mov.d	x3, v1[1]
	sdiv	x3, x3, x1
	fmov	x5, d2
	ldr	q6, [sp, #11296]                ; 16-byte Reload
	fmov	x24, d6
	sdiv	x11, x11, x22
	sdiv	x5, x5, x24
	mov.d	x25, v2[1]
	sdiv	x25, x25, x2
	mul	x9, x8, x9
	fmov	d7, x9
	ldr	x9, [sp, #10464]                ; 8-byte Reload
	mul	x9, x10, x9
	mul	x23, x17, x23
	fmov	d6, x23
	mul	x23, x3, x1
	mov.d	v6[1], x23
	mul	x23, x11, x22
	mul	x6, x13, x6
	fmov	d17, x6
	mul	x6, x25, x2
	mov.d	v7[1], x9
	mul	x9, x5, x24
	fmov	d20, x9
	mov.d	v20[1], x6
	mov.d	v17[1], x23
	sub.2d	v21, v2, v20
	sub.2d	v20, v5, v17
	sub.2d	v6, v1, v6
	sub.2d	v7, v4, v7
	shl.2d	v1, v7, #3
	shl.2d	v4, v6, #3
	shl.2d	v5, v20, #3
	shl.2d	v17, v21, #3
	ldr	q18, [sp, #10480]               ; 16-byte Reload
	cmgt.2d	v2, v18, v17
	ldr	q8, [sp, #10512]                ; 16-byte Reload
	cmgt.2d	v22, v8, v5
	uzp1.4s	v2, v22, v2
	ldr	q28, [sp, #10496]               ; 16-byte Reload
	cmgt.2d	v22, v28, v4
	cmgt.2d	v26, v19, v1
	uzp1.4s	v22, v26, v22
	fmov	d26, x8
	mov.d	v26[1], x10
	cmge.2d	v17, v17, v18
	cmge.2d	v5, v5, v8
	uzp1.4s	v5, v5, v17
	fmov	d17, x13
	cmge.2d	v4, v4, v28
	cmge.2d	v1, v1, v19
	uzp1.4s	v28, v1, v4
	fmov	d1, x17
	mov.d	v1[1], x3
	mov.d	v17[1], x11
	and.16b	v4, v23, v17
	fmov	d17, x5
	mov.d	v17[1], x25
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	and.16b	v17, v24, v17
	and.16b	v1, v3, v1
	and.16b	v0, v0, v26
	ldr	q24, [sp, #10528]               ; 16-byte Reload
	mov.d	x8, v0[1]
	sdiv	x9, x8, x12
	fmov	x10, d0
	uzp1.8h	v0, v22, v2
	ldr	q3, [sp, #10544]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	mov.d	x11, v4[1]
	msub	x8, x9, x12, x8
	sdiv	x9, x11, x30
	fmov	x13, d4
	ldr	q3, [sp, #10560]                ; 16-byte Reload
	fmov	x17, d3
	sdiv	x3, x13, x17
	msub	x13, x3, x17, x13
	msub	x9, x9, x30, x11
	mov.d	x11, v1[1]
	sdiv	x17, x11, x19
	msub	x11, x17, x19, x11
	fmov	x17, d1
	fmov	d1, x10
	fmov	x10, d24
	sdiv	x3, x17, x10
	msub	x10, x3, x10, x17
	mov.d	x17, v17[1]
	fmov	d4, x13
	fmov	d23, x10
	sdiv	x10, x17, x28
	msub	x10, x10, x28, x17
	fmov	x13, d17
	mov.d	v23[1], x11
	ldr	q17, [sp, #10592]               ; 16-byte Reload
	fmov	x11, d17
	sdiv	x17, x13, x11
	msub	x11, x17, x11, x13
	ldr	q3, [sp, #11376]                ; 16-byte Reload
	and.16b	v0, v3, v0
	mov.d	v1[1], x8
	xtn.8b	v0, v0
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d17, [sp, #11400]               ; 8-byte Reload
	and.8b	v17, v0, v17
	mov.d	v4[1], x9
	addv.8b	b17, v17
	fmov	w9, s17
	fmov	d17, x11
	mov.d	v17[1], x10
	umaxv.8b	b0, v0
	fmov	w8, s0
	rbit	w10, w9
	clz	w10, w10
	tst	w8, #0x1
	csel	w10, w10, wzr, ne
	ldr	q0, [sp, #9312]                 ; 16-byte Reload
	str	q0, [sp, #16240]
	ldr	q0, [sp, #9296]                 ; 16-byte Reload
	str	q0, [sp, #16256]
	ldr	q0, [sp, #9280]                 ; 16-byte Reload
	str	q0, [sp, #16272]
	ldr	q0, [sp, #9264]                 ; 16-byte Reload
	str	q0, [sp, #16288]
	ubfiz	x8, x10, #3, #3
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #3952
	ldr	x11, [x11, x8]
	str	q17, [sp, #16352]
	and.16b	v0, v31, v2
	and.16b	v2, v30, v22
	and.16b	v17, v30, v28
	ldr	q28, [sp, #10608]               ; 16-byte Reload
	ldr	q19, [sp, #10576]               ; 16-byte Reload
	str	q4, [sp, #16336]
	str	q23, [sp, #16320]
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	str	q1, [sp, #16304]
	ldr	x13, [x16, x8]
	str	q21, [sp, #16416]
	str	q20, [sp, #16400]
	add	x17, x13, x13, lsl #3
	str	q6, [sp, #16384]
	str	q7, [sp, #16368]
	ldr	x3, [x4, x8]
	lsl	w13, w10, #2
	add	x10, x17, x3
	sub	x11, x11, x13
	add	x10, x11, x10, lsl #5
	ldr	q1, [sp, #9200]                 ; 16-byte Reload
	str	q1, [sp, #16176]
	ldr	q1, [sp, #9184]                 ; 16-byte Reload
	str	q1, [sp, #16192]
	ldr	q1, [sp, #9248]                 ; 16-byte Reload
	str	q1, [sp, #16208]
	ldr	q1, [sp, #9216]                 ; 16-byte Reload
	str	q1, [sp, #16224]
	tst	w9, #0xff
	csel	x9, xzr, x10, eq
	add	x10, sp, #6, lsl #12            ; =24576
	add	x10, x10, #920
	add	x9, x10, x9
	ldp	q4, q1, [x9]
	and.16b	v5, v31, v5
	bif.16b	v4, v10, v2
	bif.16b	v1, v13, v0
	bic.16b	v13, v1, v5
	bic.16b	v10, v4, v17
	and.16b	v5, v30, v10
	and.16b	v6, v31, v13
	fcmge.4s	v1, v6, v25
	fcmge.4s	v4, v5, v25
	fcmge.4s	v7, v15, v6
	fcmge.4s	v17, v15, v5
	and.16b	v4, v4, v17
	and.16b	v1, v1, v7
	and.16b	v1, v1, v6
	and.16b	v4, v4, v5
	ldr	q3, [sp, #10672]                ; 16-byte Reload
	fmul.4s	v7, v4, v3
	fmul.4s	v17, v1, v3
	movi.4s	v3, #75, lsl #24
	mvni.4s	v18, #128, lsl #24
	mov.16b	v20, v18
	bsl.16b	v20, v3, v17
	mov.16b	v21, v18
	bsl.16b	v21, v3, v7
	fadd.4s	v7, v7, v21
	fadd.4s	v17, v17, v20
	fsub.4s	v17, v17, v20
	fsub.4s	v7, v7, v21
	fcvtzs.4s	v7, v7
	fcvtzs.4s	v17, v17
	scvtf.4s	v20, v17
	scvtf.4s	v21, v7
	ldr	q3, [sp, #6784]                 ; 16-byte Reload
	fmul.4s	v22, v20, v3
	fadd.4s	v1, v1, v22
	fmul.4s	v22, v21, v3
	fadd.4s	v4, v4, v22
	ldr	q3, [sp, #6768]                 ; 16-byte Reload
	fmul.4s	v20, v20, v3
	fmul.4s	v21, v21, v3
	fadd.4s	v4, v4, v21
	fadd.4s	v1, v1, v20
	ldr	q3, [sp, #6752]                 ; 16-byte Reload
	fmul.4s	v20, v1, v3
	fmul.4s	v21, v4, v3
	ldr	q3, [sp, #6736]                 ; 16-byte Reload
	fadd.4s	v21, v21, v3
	fadd.4s	v20, v20, v3
	fmul.4s	v20, v1, v20
	fmul.4s	v21, v4, v21
	ldr	q3, [sp, #6720]                 ; 16-byte Reload
	fadd.4s	v21, v21, v3
	fadd.4s	v20, v20, v3
	fmul.4s	v20, v1, v20
	fmul.4s	v21, v4, v21
	fadd.4s	v21, v21, v14
	fadd.4s	v20, v20, v14
	fmul.4s	v20, v1, v20
	fmul.4s	v21, v4, v21
	fadd.4s	v21, v21, v27
	fadd.4s	v20, v20, v27
	fmul.4s	v20, v1, v20
	fmul.4s	v21, v4, v21
	movi.4s	v3, #63, lsl #24
	fadd.4s	v21, v21, v3
	fadd.4s	v20, v20, v3
	fmul.4s	v22, v1, v1
	fmul.4s	v20, v22, v20
	fmul.4s	v22, v4, v4
	fmul.4s	v21, v22, v21
	fadd.4s	v4, v4, v21
	fadd.4s	v1, v1, v20
	fadd.4s	v1, v1, v12
	sshr.4s	v20, v17, #1
	sub.4s	v17, v17, v20
	shl.4s	v20, v20, #23
	add.4s	v20, v20, v12
	fmul.4s	v1, v1, v20
	shl.4s	v17, v17, #23
	add.4s	v17, v17, v12
	fmul.4s	v1, v1, v17
	fcmgt.4s	v17, v25, v6
	bic.16b	v1, v1, v17
	fcmgt.4s	v17, v6, v15
	ldr	q3, [sp, #6704]                 ; 16-byte Reload
	bit.16b	v1, v3, v17
	ldr	x9, [x26, x8]
	sub	x9, x9, x13
	str	q29, [sp, #16432]
	fcmeq.4s	v6, v6, v6
	str	q9, [sp, #16448]
	str	q11, [sp, #16464]
	str	q16, [sp, #16480]
	ldr	x8, [x14, x8]
	fadd.4s	v4, v4, v12
	ldr	q17, [sp, #6688]                ; 16-byte Reload
	bif.16b	v1, v17, v6
	add	x8, x9, x8, lsl #5
	csel	x8, xzr, x8, eq
	add	x8, x15, x8
	ldr	q6, [x8, #16]
	bsl.16b	v0, v1, v6
	sshr.4s	v1, v7, #1
	shl.4s	v6, v1, #23
	add.4s	v6, v6, v12
	fmul.4s	v4, v4, v6
	sub.4s	v1, v7, v1
	shl.4s	v1, v1, #23
	add.4s	v1, v1, v12
	fmul.4s	v1, v4, v1
	fcmgt.4s	v4, v25, v5
	bic.16b	v1, v1, v4
	fcmgt.4s	v4, v5, v15
	bit.16b	v1, v3, v4
	fcmeq.4s	v4, v5, v5
	bif.16b	v1, v17, v4
	ldr	q4, [x8]
	bif.16b	v1, v4, v2
	stp	q1, q0, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v9, v9, v0
	add.2d	v11, v11, v23
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v16, v16, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v29, v29, v0
	fmov	x8, d29
	cmp	x8, #18
	b.lt	LBB0_263
	b	LBB0_265
LBB0_264:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	q13, [sp, #2640]                ; 16-byte Reload
	ldr	q10, [sp, #2624]                ; 16-byte Reload
	ldr	w7, [sp, #5372]                 ; 4-byte Reload
	ldr	w27, [sp, #7356]                ; 4-byte Reload
	ldr	w20, [sp, #10092]               ; 4-byte Reload
	ldr	w21, [sp, #5368]                ; 4-byte Reload
	ldr	x22, [sp, #5360]                ; 8-byte Reload
LBB0_265:                               ; %direct.false763
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q10, [sp, #2624]                ; 16-byte Spill
	str	q13, [sp, #2640]                ; 16-byte Spill
	str	q16, [sp, #2672]                ; 16-byte Spill
	str	q11, [sp, #2688]                ; 16-byte Spill
	str	q9, [sp, #2704]                 ; 16-byte Spill
	str	q29, [sp, #2720]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q3, [sp, #10944]                ; 16-byte Reload
	ldr	q27, [sp, #11328]               ; 16-byte Reload
	bit.16b	v3, v2, v27
	str	q3, [sp, #10944]                ; 16-byte Spill
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q24, [sp, #10976]               ; 16-byte Reload
	ldr	q14, [sp, #11344]               ; 16-byte Reload
	bit.16b	v24, v2, v14
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q3, [sp, #10960]                ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #10960]                ; 16-byte Spill
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q4, [sp, #10992]                ; 16-byte Reload
	bit.16b	v4, v2, v0
	str	q4, [sp, #10992]                ; 16-byte Spill
	ldr	q16, [sp, #2560]                ; 16-byte Reload
	bic.16b	v16, v16, v27
	ldr	q17, [sp, #2592]                ; 16-byte Reload
	bic.16b	v17, v17, v14
	ldr	q20, [sp, #2576]                ; 16-byte Reload
	bic.16b	v20, v20, v1
	ldr	q7, [sp, #2608]                 ; 16-byte Reload
	bic.16b	v7, v7, v0
	fmov	x8, d7
	cmp	x8, #17
	str	q24, [sp, #10976]               ; 16-byte Spill
	b.gt	LBB0_284
; %bb.266:                              ; %direct.true779.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	d8, [sp, #11400]                ; 8-byte Reload
	ldr	q10, [sp, #1120]                ; 16-byte Reload
	add	x14, sp, #6, lsl #12            ; =24576
	add	x14, x14, #344
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3824
	add	x16, sp, #3, lsl #12            ; =12288
	add	x16, x16, #3760
	ldr	q26, [sp, #2544]                ; 16-byte Reload
	ldr	q12, [sp, #2320]                ; 16-byte Reload
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3696
	add	x26, sp, #3, lsl #12            ; =12288
	add	x26, x26, #3632
	ldr	q18, [sp, #11280]               ; 16-byte Reload
	ldr	q15, [sp, #11408]               ; 16-byte Reload
	ldr	w2, [sp, #10420]                ; 4-byte Reload
	b	LBB0_268
LBB0_267:                               ; %else844
                                        ;   in Loop: Header=BB0_268 Depth=2
	ldr	q3, [sp, #11360]                ; 16-byte Reload
	ldr	q4, [sp, #9184]                 ; 16-byte Reload
	mov.16b	v17, v19
	ldr	q28, [sp, #10608]               ; 16-byte Reload
	xtn.8b	v0, v2
	cmtst.8b	v1, v8, v8
	ldr	q2, [sp, #8240]                 ; 16-byte Reload
	bif.8b	v1, v2, v23
	ldr	d2, [sp, #10424]                ; 8-byte Reload
	orr.8b	v2, v0, v2
	and.8b	v19, v2, v1
	and.8b	v0, v18, v0
	shl.8b	v1, v0, #7
	cmlt.8b	v1, v1, #0
	ldr	d8, [sp, #11400]                ; 8-byte Reload
	and.8b	v2, v1, v8
	addv.8b	b2, v2
	fmov	w9, s2
	ldr	q2, [sp, #9920]                 ; 16-byte Reload
	bic.8b	v2, v18, v2
	umaxv.8b	b1, v1
	fmov	w8, s1
	rbit	w10, w9
	clz	w10, w10
	tst	w8, #0x1
	csel	w10, w10, wzr, ne
	ldr	q1, [sp, #9200]                 ; 16-byte Reload
	str	q1, [sp, #16112]
	str	q4, [sp, #16128]
	ldr	q1, [sp, #9248]                 ; 16-byte Reload
	str	q1, [sp, #16144]
	ldr	q1, [sp, #9216]                 ; 16-byte Reload
	str	q1, [sp, #16160]
	ubfiz	x8, x10, #3, #3
	ldr	x11, [x15, x8]
	str	q5, [sp, #8256]                 ; 16-byte Spill
	str	q5, [sp, #16048]
	str	q21, [sp, #8288]                ; 16-byte Spill
	str	q21, [sp, #16064]
	str	q6, [sp, #8272]                 ; 16-byte Spill
	str	q6, [sp, #16080]
	str	q26, [sp, #16096]
	ldr	x13, [x16, x8]
	add	x13, x13, x13, lsl #3
	ldr	q1, [sp, #9936]                 ; 16-byte Reload
	str	q1, [sp, #15984]
	ldr	q1, [sp, #9904]                 ; 16-byte Reload
	str	q1, [sp, #16000]
	str	q20, [sp, #8320]                ; 16-byte Spill
	str	q20, [sp, #16016]
	str	q22, [sp, #8304]                ; 16-byte Spill
	str	q22, [sp, #16032]
	ldr	x17, [x4, x8]
	add	x13, x13, x17
	lsl	w10, w10, #2
	sub	x11, x11, x10
	add	x11, x11, x13, lsl #5
	ldr	q1, [sp, #10992]                ; 16-byte Reload
	str	q1, [sp, #15920]
	str	q24, [sp, #15936]
	ldr	q1, [sp, #10960]                ; 16-byte Reload
	str	q1, [sp, #15952]
	str	q16, [sp, #15968]
	ldr	x13, [x26, x8]
	sub	x10, x13, x10
	tst	w9, #0xff
	csel	x9, xzr, x11, eq
	add	x9, x14, x9
	ldp	q4, q1, [x9]
	zip2.8b	v5, v0, v0
	ushll.4s	v5, v5, #0
	shl.4s	v5, v5, #31
	cmlt.4s	v5, v5, #0
	ldr	q6, [sp, #8208]                 ; 16-byte Reload
	bif.16b	v1, v6, v5
	zip2.8b	v6, v2, v0
	ushll.4s	v6, v6, #0
	shl.4s	v6, v6, #31
	cmge.4s	v6, v6, #0
	and.16b	v6, v6, v1
	zip2.8b	v1, v19, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	str	q6, [sp, #8208]                 ; 16-byte Spill
	and.16b	v1, v1, v6
	str	q9, [sp, #15856]
	str	q17, [sp, #15872]
	str	q13, [sp, #15888]
	str	q25, [sp, #15904]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3568
	ldr	x8, [x9, x8]
	add	x8, x10, x8, lsl #5
	csel	x8, xzr, x8, eq
	add	x8, x24, x8
	ldr	q6, [x8, #16]
	bif.16b	v1, v6, v5
	zip1.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	ldr	q5, [sp, #8224]                 ; 16-byte Reload
	bif.16b	v4, v5, v0
	ldr	q5, [x8]
	zip1.8b	v2, v2, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmge.4s	v2, v2, #0
	and.16b	v4, v2, v4
	str	q19, [sp, #8240]                ; 16-byte Spill
	zip1.8b	v2, v19, v0
	ushll.4s	v2, v2, #0
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	str	q4, [sp, #8224]                 ; 16-byte Spill
	and.16b	v2, v2, v4
	bsl.16b	v0, v2, v5
	stp	q0, q1, [x8]
	add.2d	v17, v17, v3
	ldr	q23, [sp, #11440]               ; 16-byte Reload
	add.2d	v20, v13, v23
	add.2d	v16, v25, v15
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v7, v9, v0
	fmov	x8, d7
	cmp	x8, #18
	b.ge	LBB0_285
LBB0_268:                               ; %direct.true779
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v5, v30, #0
	sshll.2d	v6, v31, #0
	mov.16b	v25, v16
	and.16b	v0, v27, v16
	mov.16b	v19, v17
	and.16b	v2, v14, v17
	mov.16b	v13, v20
	and.16b	v17, v6, v20
	mov.16b	v9, v7
	and.16b	v7, v5, v7
	fmov	x8, d7
	ldr	q1, [sp, #11136]                ; 16-byte Reload
	fmov	x9, d1
	sdiv	x8, x8, x9
	mul	x9, x8, x9
	fmov	d1, x8
	mov.d	x8, v7[1]
	sdiv	x10, x8, x25
	mov.d	v1[1], x10
	fmov	x8, d17
	ldr	q3, [sp, #11312]                ; 16-byte Reload
	fmov	x11, d3
	sdiv	x3, x8, x11
	mov.d	x17, v17[1]
	fmov	x8, d2
	fmov	x5, d28
	mov.d	x23, v2[1]
	sdiv	x6, x8, x5
	fmov	x8, d0
	ldr	q3, [sp, #11296]                ; 16-byte Reload
	fmov	x24, d3
	sdiv	x8, x8, x24
	mov.d	x13, v0[1]
	ldr	x1, [sp, #10448]                ; 8-byte Reload
	sdiv	x13, x13, x1
	mul	x25, x13, x1
	mul	x24, x8, x24
	fmov	d4, x24
	mov.d	v4[1], x25
	ldr	x25, [sp, #10464]               ; 8-byte Reload
	ldr	x1, [sp, #10440]                ; 8-byte Reload
	sdiv	x23, x23, x1
	mul	x24, x23, x1
	mul	x5, x6, x5
	fmov	d21, x5
	mov.d	v21[1], x24
	sdiv	x5, x17, x22
	mul	x17, x5, x22
	mul	x11, x3, x11
	fmov	d20, x11
	mov.d	v20[1], x17
	mul	x10, x10, x25
	fmov	d22, x9
	mov.d	v22[1], x10
	sub.2d	v7, v7, v22
	sub.2d	v20, v17, v20
	sub.2d	v21, v2, v21
	sub.2d	v22, v0, v4
	shl.2d	v0, v7, #3
	shl.2d	v2, v21, #3
	shl.2d	v4, v20, #3
	shl.2d	v17, v22, #3
	ldr	q3, [sp, #10480]                ; 16-byte Reload
	cmgt.2d	v17, v3, v17
	ldr	q3, [sp, #10512]                ; 16-byte Reload
	cmgt.2d	v4, v3, v4
	uzp1.4s	v4, v4, v17
	ldr	q3, [sp, #10496]                ; 16-byte Reload
	cmgt.2d	v2, v3, v2
	ldr	q3, [sp, #10576]                ; 16-byte Reload
	cmgt.2d	v0, v3, v0
	uzp1.4s	v0, v0, v2
	uzp1.8h	v2, v0, v4
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	and.16b	v0, v0, v2
	xtn.8b	v28, v0
	and.16b	v0, v5, v1
	mov.d	x9, v0[1]
	sdiv	x10, x9, x12
	msub	x9, x10, x12, x9
	fmov	x10, d0
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x17, x10, x11
	msub	x10, x17, x11, x10
	fmov	d29, x10
	mov.d	v29[1], x9
	shl.8b	v0, v28, #7
	cmlt.8b	v23, v0, #0
	and.8b	v0, v23, v8
	addv.8b	b0, v0
	fmov	w17, s0
	add.2d	v0, v7, v7
	ldr	q1, [sp, #10272]                ; 16-byte Reload
	add.2d	v0, v0, v1
	ldr	q1, [sp, #10208]                ; 16-byte Reload
	add.2d	v0, v1, v0
	add.2d	v0, v0, v29
	tbz	w17, #0, LBB0_270
; %bb.269:                              ; %cond.load798
                                        ;   in Loop: Header=BB0_268 Depth=2
	fmov	x9, d0
	ldr	b8, [x9]
	add	x24, sp, #5, lsl #12            ; =20480
	add	x24, x24, #3864
	ldr	w1, [sp, #10316]                ; 4-byte Reload
	tbnz	w17, #1, LBB0_271
	b	LBB0_272
LBB0_270:                               ;   in Loop: Header=BB0_268 Depth=2
	movi.2d	v8, #0000000000000000
	add	x24, sp, #5, lsl #12            ; =20480
	add	x24, x24, #3864
	ldr	w1, [sp, #10316]                ; 4-byte Reload
	tbz	w17, #1, LBB0_272
LBB0_271:                               ; %cond.load804
                                        ;   in Loop: Header=BB0_268 Depth=2
	mov.d	x9, v0[1]
	ld1.b	{ v8 }[1], [x9]
LBB0_272:                               ; %else808
                                        ;   in Loop: Header=BB0_268 Depth=2
	fmov	d0, x6
	mov.d	v0[1], x23
	and.16b	v0, v14, v0
	mov.d	x9, v0[1]
	sdiv	x10, x9, x19
	msub	x9, x10, x19, x9
	fmov	x10, d0
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x6, x10, x11
	msub	x10, x6, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	add.2d	v1, v21, v21
	ldr	q3, [sp, #10256]                ; 16-byte Reload
	add.2d	v1, v1, v3
	ldr	q4, [sp, #10192]                ; 16-byte Reload
	add.2d	v1, v4, v1
	add.2d	v1, v1, v0
	tbz	w17, #2, LBB0_274
; %bb.273:                              ; %cond.load810
                                        ;   in Loop: Header=BB0_268 Depth=2
	fmov	x9, d1
	ld1.b	{ v8 }[2], [x9]
LBB0_274:                               ; %else814
                                        ;   in Loop: Header=BB0_268 Depth=2
	tbz	w17, #3, LBB0_276
; %bb.275:                              ; %cond.load816
                                        ;   in Loop: Header=BB0_268 Depth=2
	mov.d	x9, v1[1]
	ld1.b	{ v8 }[3], [x9]
LBB0_276:                               ; %else820
                                        ;   in Loop: Header=BB0_268 Depth=2
	fmov	d1, x3
	mov.d	v1[1], x5
	and.16b	v1, v6, v1
	mov.d	x9, v1[1]
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d1
	ldr	q1, [sp, #10560]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x3, x10, x11
	msub	x10, x3, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	add.2d	v4, v20, v20
	ldr	q17, [sp, #10240]               ; 16-byte Reload
	add.2d	v4, v4, v17
	ldr	q16, [sp, #10176]               ; 16-byte Reload
	add.2d	v4, v16, v4
	add.2d	v4, v4, v1
	tbz	w17, #4, LBB0_278
; %bb.277:                              ; %cond.load822
                                        ;   in Loop: Header=BB0_268 Depth=2
	fmov	x9, d4
	ld1.b	{ v8 }[4], [x9]
LBB0_278:                               ; %else826
                                        ;   in Loop: Header=BB0_268 Depth=2
	ldr	q24, [sp, #10976]               ; 16-byte Reload
	ldr	q16, [sp, #10944]               ; 16-byte Reload
	tbz	w17, #5, LBB0_280
; %bb.279:                              ; %cond.load828
                                        ;   in Loop: Header=BB0_268 Depth=2
	mov.d	x9, v4[1]
	ld1.b	{ v8 }[5], [x9]
LBB0_280:                               ; %else832
                                        ;   in Loop: Header=BB0_268 Depth=2
	fmov	d4, x8
	mov.d	v4[1], x13
	and.16b	v4, v27, v4
	mov.d	x8, v4[1]
	sdiv	x9, x8, x28
	msub	x8, x9, x28, x8
	fmov	x9, d4
	ldr	q4, [sp, #10592]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d17, x9
	mov.d	v17[1], x8
	add.2d	v4, v22, v22
	ldr	q11, [sp, #10224]               ; 16-byte Reload
	add.2d	v4, v4, v11
	ldr	q3, [sp, #10288]                ; 16-byte Reload
	add.2d	v4, v3, v4
	add.2d	v4, v4, v17
	tbz	w17, #6, LBB0_282
; %bb.281:                              ; %cond.load834
                                        ;   in Loop: Header=BB0_268 Depth=2
	fmov	x8, d4
	ld1.b	{ v8 }[6], [x8]
LBB0_282:                               ; %else838
                                        ;   in Loop: Header=BB0_268 Depth=2
	ldr	q11, [sp, #8304]                ; 16-byte Reload
	bif.16b	v22, v11, v27
	ldr	q11, [sp, #9904]                ; 16-byte Reload
	bit.16b	v11, v21, v14
	str	q11, [sp, #9904]                ; 16-byte Spill
	ldr	q21, [sp, #8320]                ; 16-byte Reload
	bif.16b	v20, v21, v6
	ldr	q21, [sp, #9936]                ; 16-byte Reload
	bit.16b	v21, v7, v5
	str	q21, [sp, #9936]                ; 16-byte Spill
	ldr	q7, [sp, #9920]                 ; 16-byte Reload
	bic.8b	v7, v7, v18
	orr.8b	v7, v28, v7
	str	q7, [sp, #9920]                 ; 16-byte Spill
	bit.16b	v26, v17, v27
	ldr	q21, [sp, #8288]                ; 16-byte Reload
	bit.16b	v21, v0, v14
	ldr	q0, [sp, #8272]                 ; 16-byte Reload
	bsl.16b	v6, v1, v0
	ldr	q0, [sp, #8256]                 ; 16-byte Reload
	bsl.16b	v5, v29, v0
	tbz	w17, #7, LBB0_267
; %bb.283:                              ; %cond.load840
                                        ;   in Loop: Header=BB0_268 Depth=2
	mov.d	x8, v4[1]
	ld1.b	{ v8 }[7], [x8]
	b	LBB0_267
LBB0_284:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	q10, [sp, #1120]                ; 16-byte Reload
	ldr	q26, [sp, #2544]                ; 16-byte Reload
	ldr	q12, [sp, #2320]                ; 16-byte Reload
	ldr	q18, [sp, #11280]               ; 16-byte Reload
	ldr	w1, [sp, #10316]                ; 4-byte Reload
	ldr	q15, [sp, #11408]               ; 16-byte Reload
	ldr	w2, [sp, #10420]                ; 4-byte Reload
LBB0_285:                               ; %direct.false780
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q16, [sp, #2560]                ; 16-byte Spill
	str	q26, [sp, #2544]                ; 16-byte Spill
	str	q20, [sp, #2576]                ; 16-byte Spill
	str	q17, [sp, #2592]                ; 16-byte Spill
	str	q7, [sp, #2608]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q7, [sp, #4640]                 ; 16-byte Reload
	bit.16b	v7, v2, v27
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q20, [sp, #4608]                ; 16-byte Reload
	bit.16b	v20, v2, v14
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q4, [sp, #4656]                 ; 16-byte Reload
	bit.16b	v4, v2, v1
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q17, [sp, #4624]                ; 16-byte Reload
	bit.16b	v17, v2, v0
	ldr	q9, [sp, #2464]                 ; 16-byte Reload
	bic.16b	v9, v9, v27
	ldr	q25, [sp, #2496]                ; 16-byte Reload
	bic.16b	v25, v25, v14
	ldr	q26, [sp, #2480]                ; 16-byte Reload
	bic.16b	v26, v26, v1
	ldr	q23, [sp, #2512]                ; 16-byte Reload
	bic.16b	v23, v23, v0
	fmov	x8, d23
	cmp	x8, #1
	str	q4, [sp, #4656]                 ; 16-byte Spill
	str	q7, [sp, #4640]                 ; 16-byte Spill
	str	q17, [sp, #4624]                ; 16-byte Spill
	str	q20, [sp, #4608]                ; 16-byte Spill
	b.lt	LBB0_287
; %bb.286:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	q11, [sp, #2432]                ; 16-byte Reload
	ldr	q3, [sp, #2416]                 ; 16-byte Reload
	ldr	q0, [sp, #2400]                 ; 16-byte Reload
	ldr	q2, [sp, #2368]                 ; 16-byte Reload
	ldr	q5, [sp, #2352]                 ; 16-byte Reload
	ldr	q13, [sp, #2304]                ; 16-byte Reload
	ldr	q19, [sp, #2288]                ; 16-byte Reload
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3248
	add	x16, sp, #3, lsl #12            ; =12288
	add	x16, x16, #3184
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3312
	add	x23, sp, #3, lsl #12            ; =12288
	add	x23, x23, #3152
	add	x26, sp, #3, lsl #12            ; =12288
	add	x26, x26, #3120
	ldr	x24, [sp, #10440]               ; 8-byte Reload
	b	LBB0_289
LBB0_287:                               ; %direct.true803.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	x8, [sp, #88]                   ; 8-byte Reload
	ldp	q0, q1, [x8]
	str	q1, [sp, #10720]                ; 16-byte Spill
	str	q0, [sp, #10704]                ; 16-byte Spill
	ldr	q1, [sp, #7184]                 ; 16-byte Reload
	str	q1, [sp, #15792]
	ldr	q1, [sp, #7168]                 ; 16-byte Reload
	str	q1, [sp, #15808]
	ldr	q1, [sp, #7152]                 ; 16-byte Reload
	str	q1, [sp, #15824]
	ldr	q1, [sp, #7136]                 ; 16-byte Reload
	str	q1, [sp, #15840]
	ldr	x11, [sp, #184]                 ; 8-byte Reload
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #3504
	ldr	x8, [x8, x11]
	ldr	x9, [sp, #4968]                 ; 8-byte Reload
	sub	x8, x8, x9
	ldr	w10, [sp, #5052]                ; 4-byte Reload
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #1496
	add	x8, x13, x8
	ldp	q6, q0, [x8]
	str	q0, [sp, #10688]                ; 16-byte Spill
	str	q17, [sp, #15728]
	str	q20, [sp, #15744]
	str	q4, [sp, #15760]
	str	q7, [sp, #15776]
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #3440
	ldr	x8, [x8, x11]
	sub	x8, x8, x9
	movi	d16, #0x0000000000ffff
	ldr	q20, [sp, #11424]               ; 16-byte Reload
	ldp	q22, q21, [sp, #464]            ; 32-byte Folded Reload
	ldr	q8, [sp, #448]                  ; 16-byte Reload
	ldr	x11, [sp, #176]                 ; 8-byte Reload
	ldr	q11, [sp, #2432]                ; 16-byte Reload
	ldr	q3, [sp, #2416]                 ; 16-byte Reload
	ldr	q0, [sp, #2400]                 ; 16-byte Reload
	ldr	q2, [sp, #2368]                 ; 16-byte Reload
	ldr	q5, [sp, #2352]                 ; 16-byte Reload
	ldr	q13, [sp, #2304]                ; 16-byte Reload
	ldr	q19, [sp, #2288]                ; 16-byte Reload
	add	x13, sp, #3, lsl #12            ; =12288
	add	x13, x13, #3376
	add	x14, sp, #5, lsl #12            ; =20480
	add	x14, x14, #3832
	add	x15, sp, #3, lsl #12            ; =12288
	add	x15, x15, #3248
	add	x16, sp, #3, lsl #12            ; =12288
	add	x16, x16, #3184
	add	x4, sp, #3, lsl #12             ; =12288
	add	x4, x4, #3312
	add	x23, sp, #3, lsl #12            ; =12288
	add	x23, x23, #3152
	add	x26, sp, #3, lsl #12            ; =12288
	add	x26, x26, #3120
	ldr	q29, [sp, #11440]               ; 16-byte Reload
	ldr	x24, [sp, #10440]               ; 8-byte Reload
	ldr	q28, [sp, #11360]               ; 16-byte Reload
	mov.16b	v7, v10
LBB0_288:                               ; %direct.true803
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	bit.8b	v11, v16, v18
	ldr	q1, [sp, #10704]                ; 16-byte Reload
	bif.16b	v1, v0, v7
	ldr	q0, [sp, #10720]                ; 16-byte Reload
	mov.16b	v4, v21
	bsl.16b	v4, v0, v3
	and.16b	v3, v22, v4
	and.16b	v0, v8, v1
	bic.8b	v1, v18, v11
	mov.16b	v4, v7
	bsl.16b	v4, v6, v5
	ldr	q5, [sp, #10688]                ; 16-byte Reload
	mov.16b	v7, v21
	bsl.16b	v7, v5, v2
	zip2.8b	v17, v1, v0
	ushll.4s	v17, v17, #0
	shl.4s	v17, v17, #31
	cmge.4s	v17, v17, #0
	and.16b	v2, v17, v7
	zip1.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v5, v1, v4
	fmul.4s	v1, v0, v5
	fmul.4s	v4, v3, v2
	str	q23, [sp, #15664]
	str	q25, [sp, #15680]
	str	q26, [sp, #15696]
	str	q9, [sp, #15712]
	ldr	x9, [x13, x11, lsl #3]
	add	x9, x8, x9, lsl #5
	tst	w10, #0xff
	csel	x9, xzr, x9, eq
	add	x9, x14, x9
	ldp	q7, q17, [x9]
	bif.16b	v4, v17, v21
	bif.16b	v1, v7, v10
	mov.16b	v7, v10
	stp	q1, q4, [x9]
	add.2d	v25, v25, v28
	add.2d	v26, v26, v29
	add.2d	v9, v9, v15
	add.2d	v23, v23, v20
	fmov	x9, d23
	cmp	x9, #1
	b.lt	LBB0_288
LBB0_289:                               ; %direct.false804
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q5, [sp, #2352]                 ; 16-byte Spill
	str	q2, [sp, #2368]                 ; 16-byte Spill
	str	q0, [sp, #2400]                 ; 16-byte Spill
	str	q3, [sp, #2416]                 ; 16-byte Spill
	str	q11, [sp, #2432]                ; 16-byte Spill
	str	q9, [sp, #2464]                 ; 16-byte Spill
	str	q26, [sp, #2480]                ; 16-byte Spill
	str	q25, [sp, #2496]                ; 16-byte Spill
	str	q23, [sp, #2512]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #9104]                 ; 16-byte Reload
	bic.16b	v2, v2, v27
	ldr	q6, [sp, #9136]                 ; 16-byte Reload
	bic.16b	v6, v6, v14
	ldr	q5, [sp, #9120]                 ; 16-byte Reload
	str	q1, [sp, #10704]                ; 16-byte Spill
	bic.16b	v5, v5, v1
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	str	q0, [sp, #10720]                ; 16-byte Spill
	bic.16b	v4, v4, v0
	fmov	x6, d4
	cmp	x6, #1
	b.gt	LBB0_294
; %bb.290:                              ; %direct.true824.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q17, [sp, #10928]               ; 16-byte Reload
	ldr	q10, [sp, #10912]               ; 16-byte Reload
	ldr	q14, [sp, #10896]               ; 16-byte Reload
	ldr	q24, [sp, #10528]               ; 16-byte Reload
	ldr	q7, [sp, #10592]                ; 16-byte Reload
	b	LBB0_292
LBB0_291:                               ; %direct.false830
                                        ;   in Loop: Header=BB0_292 Depth=2
	str	q24, [sp, #8112]                ; 16-byte Spill
	str	q29, [sp, #8128]                ; 16-byte Spill
	str	q30, [sp, #8144]                ; 16-byte Spill
	str	q25, [sp, #8160]                ; 16-byte Spill
	str	q9, [sp, #8176]                 ; 16-byte Spill
	str	q23, [sp, #8192]                ; 16-byte Spill
	str	q13, [sp, #15440]
	str	q16, [sp, #15456]
	ldr	x9, [sp, #6432]                 ; 8-byte Reload
	ldr	s0, [x23, x9]
	ldr	w8, [sp, #9036]                 ; 4-byte Reload
	tst	w8, #0x1
	movi.2d	v19, #0000000000000000
	fcsel	s2, s0, s19, ne
	str	q13, [sp, #15408]
	str	q16, [sp, #15424]
	ldr	x10, [sp, #6416]                ; 8-byte Reload
	ldr	s0, [x26, x10]
	movi.8b	v1, #1
	and.8b	v1, v12, v1
	ushll.8h	v1, v1, #0
	ushll.4s	v5, v1, #0
	ushll2.4s	v6, v1, #0
	str	q6, [sp, #14976]
	str	q5, [sp, #14960]
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2672
	ldr	w8, [x8, x9]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9032]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s0, s0, s19, ne
	str	q13, [sp, #15376]
	str	q16, [sp, #15392]
	ldr	x11, [sp, #6384]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3088
	ldr	s7, [x9, x11]
	str	q6, [sp, #15008]
	str	q5, [sp, #14992]
	fmov	s1, w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2704
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9028]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s7, s7, s19, ne
	str	q13, [sp, #15344]
	str	q16, [sp, #15360]
	ldr	x10, [sp, #6368]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3056
	ldr	s4, [x9, x10]
	str	q6, [sp, #15040]
	str	q5, [sp, #15024]
	mov.s	v1[1], w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2736
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9024]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q13, [sp, #15312]
	str	q16, [sp, #15328]
	ldr	x11, [sp, #6344]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #3024
	ldr	s17, [x9, x11]
	str	q6, [sp, #15072]
	str	q5, [sp, #15056]
	mov.s	v1[2], w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2768
	ldr	w8, [x8, x10]
	fcsel	s20, s4, s19, ne
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9020]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s4, s17, s19, ne
	str	q13, [sp, #15280]
	str	q16, [sp, #15296]
	ldr	x10, [sp, #6328]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2992
	ldr	s17, [x9, x10]
	str	q6, [sp, #15104]
	str	q5, [sp, #15088]
	mov.s	v1[3], w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2800
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9016]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s17, s17, s19, ne
	str	q13, [sp, #15248]
	str	q16, [sp, #15264]
	ldr	x11, [sp, #6288]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2960
	ldr	s21, [x9, x11]
	str	q6, [sp, #15136]
	str	q5, [sp, #15120]
	fmov	s22, w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2832
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9012]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s21, s21, s19, ne
	str	q13, [sp, #15216]
	str	q16, [sp, #15232]
	ldr	x10, [sp, #6272]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2928
	ldr	s23, [x9, x10]
	mov.s	v22[1], w8
	str	q6, [sp, #15168]
	str	q5, [sp, #15152]
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2864
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9008]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s23, s23, s19, ne
	mov.s	v4[1], v17[0]
	mov.s	v4[2], v21[0]
	mov.s	v4[3], v23[0]
	mov.s	v2[1], v0[0]
	mov.s	v2[2], v7[0]
	mov.s	v2[3], v20[0]
	fadd.4s	v0, v13, v2
	fadd.4s	v7, v16, v4
	mov.s	v22[2], w8
	str	q6, [sp, #15200]
	str	q5, [sp, #15184]
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2896
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	mov.s	v22[3], w8
	cmtst.4s	v5, v22, v22
	cmtst.4s	v6, v1, v1
	uzp1.8h	v5, v6, v5
	xtn.8b	v5, v5
	cmeq.4s	v1, v1, #0
	cmeq.4s	v6, v22, #0
	bsl.16b	v6, v16, v7
	bit.16b	v0, v13, v1
	zip1.8b	v1, v12, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bit.16b	v2, v0, v1
	zip2.8b	v0, v12, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v0, v0, #0
	bif.16b	v6, v4, v0
	orr.8b	v5, v12, v5
	str	q6, [sp, #14944]
	str	q2, [sp, #14928]
	ldr	x9, [sp, #6264]                 ; 8-byte Reload
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2640
	ldr	s0, [x8, x9]
	ldr	w8, [sp, #9004]                 ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s7, s0, s19, ne
	str	q6, [sp, #14880]
	str	q2, [sp, #14864]
	ldr	x10, [sp, #6224]                ; 8-byte Reload
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2576
	ldr	s0, [x8, x10]
	zip1.8b	v1, v5, v0
	ushll.4s	v21, v1, #0
	movi.4s	v9, #1
	and.16b	v20, v21, v9
	zip2.8b	v1, v5, v0
	ushll.4s	v23, v1, #0
	and.16b	v22, v23, v9
	str	q22, [sp, #14912]
	str	q20, [sp, #14896]
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2608
	ldr	w8, [x8, x9]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #9000]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s0, s0, s19, ne
	str	q6, [sp, #14816]
	str	q2, [sp, #14800]
	ldr	x11, [sp, #6208]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2512
	ldr	s17, [x9, x11]
	str	q22, [sp, #14848]
	str	q20, [sp, #14832]
	fmov	s28, w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2544
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8996]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s1, s17, s19, ne
	str	q6, [sp, #14752]
	str	q2, [sp, #14736]
	ldr	x10, [sp, #6176]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2448
	ldr	s4, [x9, x10]
	str	q22, [sp, #14784]
	str	q20, [sp, #14768]
	mov.s	v28[1], w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2480
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8992]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s4, s4, s19, ne
	str	q6, [sp, #14688]
	str	q2, [sp, #14672]
	ldr	x11, [sp, #6168]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2384
	ldr	s17, [x9, x11]
	str	q22, [sp, #14720]
	str	q20, [sp, #14704]
	mov.s	v28[2], w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2416
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8988]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s17, s17, s19, ne
	str	q6, [sp, #14624]
	str	q2, [sp, #14608]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2320
	ldr	x13, [sp, #6128]                ; 8-byte Reload
	ldr	s26, [x9, x13]
	str	q22, [sp, #14656]
	str	q20, [sp, #14640]
	mov.s	v28[3], w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2352
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8984]                 ; 4-byte Reload
	tst	w9, #0x1
	str	q6, [sp, #14560]
	str	q2, [sp, #14544]
	ldr	x10, [sp, #6112]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2256
	ldr	s29, [x9, x10]
	fcsel	s26, s26, s19, ne
	str	q22, [sp, #14592]
	str	q20, [sp, #14576]
	mov.s	v17[1], v26[0]
	fmov	s26, w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2288
	ldr	w8, [x8, x13]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8980]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s29, s29, s19, ne
	str	q6, [sp, #14496]
	str	q2, [sp, #14480]
	mov.s	v17[2], v29[0]
	ldr	x11, [sp, #6080]                ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2192
	ldr	s29, [x9, x11]
	str	q22, [sp, #14528]
	str	q20, [sp, #14512]
	mov.s	v26[1], w8
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2224
	ldr	w8, [x8, x10]
	csel	w8, w8, wzr, ne
	ldr	w9, [sp, #8976]                 ; 4-byte Reload
	tst	w9, #0x1
	fcsel	s29, s29, s19, ne
	mov.s	v17[3], v29[0]
	mov.s	v7[1], v0[0]
	mov.s	v7[2], v1[0]
	mov.s	v7[3], v4[0]
	fadd.4s	v0, v2, v7
	fadd.4s	v1, v6, v17
	shl.4s	v4, v23, #31
	cmlt.4s	v4, v4, #0
	shl.4s	v21, v21, #31
	mov.s	v26[2], w8
	str	q22, [sp, #14464]
	str	q20, [sp, #14448]
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2160
	ldr	w8, [x8, x11]
	csel	w8, w8, wzr, ne
	mov.s	v26[3], w8
	cmlt.4s	v20, v21, #0
	cmtst.4s	v21, v26, v26
	cmtst.4s	v22, v28, v28
	uzp1.8h	v21, v22, v21
	xtn.8b	v21, v21
	cmeq.4s	v22, v28, #0
	cmeq.4s	v23, v26, #0
	bit.16b	v1, v6, v23
	ldr	q3, [sp, #11440]                ; 16-byte Reload
	bit.16b	v0, v2, v22
	bif.16b	v0, v7, v20
	bif.16b	v1, v17, v4
	orr.8b	v2, v5, v21
	str	q1, [sp, #14432]
	str	q0, [sp, #14416]
	ldr	x9, [sp, #6072]                 ; 8-byte Reload
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2128
	ldr	s1, [x8, x9]
	ldr	w8, [sp, #8972]                 ; 4-byte Reload
	tst	w8, #0x1
	fcsel	s1, s1, s19, ne
	zip1.8b	v4, v2, v0
	ushll.4s	v4, v4, #0
	and.16b	v5, v4, v9
	zip2.8b	v2, v2, v0
	ushll.4s	v2, v2, #0
	and.16b	v2, v2, v9
	str	q2, [sp, #14400]
	str	q5, [sp, #14384]
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #2096
	ldr	w8, [x8, x9]
	csel	w8, w8, wzr, ne
	str	q2, [sp, #14368]
	str	q5, [sp, #14352]
	fmov	s6, w8
	ldr	x8, [sp, #6056]                 ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2064
	ldr	w8, [x9, x8, lsl #2]
	ldr	w9, [sp, #8968]                 ; 4-byte Reload
	tst	w9, #0x1
	csel	w8, w8, wzr, ne
	str	q2, [sp, #14336]
	str	q5, [sp, #14320]
	mov.s	v6[1], w8
	ldr	x8, [sp, #6016]                 ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2032
	ldr	w8, [x9, x8, lsl #2]
	ldr	w9, [sp, #8964]                 ; 4-byte Reload
	tst	w9, #0x1
	csel	w8, w8, wzr, ne
	str	q2, [sp, #14304]
	str	q5, [sp, #14288]
	mov.s	v6[2], w8
	ldr	x8, [sp, #6000]                 ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #2000
	ldr	w8, [x9, x8, lsl #2]
	ldr	w9, [sp, #8960]                 ; 4-byte Reload
	tst	w9, #0x1
	csel	w8, w8, wzr, ne
	mov.s	v6[3], w8
	fadd.4s	v2, v0, v1
	shl.4s	v4, v4, #31
	cmlt.4s	v4, v4, #0
	cmeq.4s	v5, v6, #0
	bif.16b	v0, v2, v5
	bif.16b	v0, v1, v4
	tst	w0, #0x1
	fcsel	s1, s0, s19, ne
	ldr	w2, [sp, #10420]                ; 4-byte Reload
	and	w8, w2, w0
	tst	w8, #0x1
	fcsel	s2, s0, s19, ne
	and	w8, w1, w0
	tst	w8, #0x1
	fcsel	s4, s0, s19, ne
	mov	x7, x27
	and	w8, w27, w0
	tst	w8, #0x1
	fcsel	s5, s0, s19, ne
	mov	x27, x20
	and	w8, w20, w0
	tst	w8, #0x1
	fcsel	s6, s0, s19, ne
	mov	x20, x21
	and	w8, w21, w0
	tst	w8, #0x1
	fcsel	s7, s0, s19, ne
	mov	x21, x14
	and	w8, w14, w0
	tst	w8, #0x1
	fcsel	s17, s0, s19, ne
	ldr	w8, [sp, #7836]                 ; 4-byte Reload
	and	w8, w8, w0
	tst	w8, #0x1
	fcsel	s0, s0, s19, ne
	mov.s	v1[1], v2[0]
	mov.s	v1[2], v4[0]
	mov.s	v1[3], v5[0]
	mov.s	v6[1], v7[0]
	mov.s	v6[2], v17[0]
	mov.s	v6[3], v0[0]
	str	q6, [sp, #14144]
	str	q1, [sp, #14128]
	ldr	x8, [sp, #5984]                 ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #1840
	ldr	s0, [x9, x8, lsl #2]
	fadd	s0, s0, s19
	dup.4s	v0, v0[0]
	add	x8, sp, #5, lsl #12             ; =20480
	add	x8, x8, #3768
	add	x8, x8, x6, lsl #5
	ldp	q1, q2, [x8]
	ldr	q31, [sp, #11184]               ; 16-byte Reload
	bit.16b	v2, v0, v31
	ldr	q30, [sp, #11216]               ; 16-byte Reload
	bif.16b	v0, v1, v30
	stp	q0, q2, [x8]
	ldr	q6, [sp, #9136]                 ; 16-byte Reload
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v6, v6, v0
	ldr	q5, [sp, #9120]                 ; 16-byte Reload
	add.2d	v5, v5, v3
	ldr	q2, [sp, #9104]                 ; 16-byte Reload
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v2, v2, v0
	ldr	q4, [sp, #9152]                 ; 16-byte Reload
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v4, v4, v0
	fmov	x6, d4
	cmp	x6, #2
	ldr	q24, [sp, #10528]               ; 16-byte Reload
	ldr	q7, [sp, #10592]                ; 16-byte Reload
	ldr	q10, [sp, #10912]               ; 16-byte Reload
	ldr	q14, [sp, #10896]               ; 16-byte Reload
	mov.16b	v19, v16
	ldr	q17, [sp, #10928]               ; 16-byte Reload
	b.ge	LBB0_295
LBB0_292:                               ; %direct.true824
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_293 Depth 3
	mov	x14, x21
	mov	x21, x20
	mov	x20, x27
	mov	x27, x7
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	str	q2, [sp, #9104]                 ; 16-byte Spill
	ldr	q16, [sp, #11328]               ; 16-byte Reload
	and.16b	v2, v16, v2
	str	q4, [sp, #9152]                 ; 16-byte Spill
	and.16b	v4, v0, v4
	mov.d	x8, v4[1]
	sdiv	x9, x8, x12
	msub	x8, x9, x12, x8
	fmov	x9, d4
	ldr	q4, [sp, #10544]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	str	q5, [sp, #9120]                 ; 16-byte Spill
	and.16b	v5, v1, v5
	mov.d	x8, v5[1]
	sdiv	x9, x8, x30
	msub	x8, x9, x30, x8
	fmov	x9, d5
	ldr	q5, [sp, #10560]                ; 16-byte Reload
	fmov	x10, d5
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d5, x9
	mov.d	v5[1], x8
	str	q6, [sp, #9136]                 ; 16-byte Spill
	ldr	q18, [sp, #11344]               ; 16-byte Reload
	and.16b	v6, v18, v6
	mov.d	x8, v6[1]
	sdiv	x9, x8, x19
	msub	x8, x9, x19, x8
	fmov	x9, d6
	fmov	x10, d24
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d6, x9
	mov.d	v6[1], x8
	mov.d	x8, v2[1]
	sdiv	x9, x8, x28
	msub	x8, x9, x28, x8
	fmov	x9, d2
	fmov	x10, d7
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d2, x9
	mov.d	v2[1], x8
	bit.16b	v17, v2, v16
	str	q17, [sp, #10928]               ; 16-byte Spill
	bit.16b	v10, v6, v18
	str	q10, [sp, #10912]               ; 16-byte Spill
	bit.16b	v14, v5, v1
	str	q14, [sp, #10896]               ; 16-byte Spill
	ldr	q2, [sp, #10784]                ; 16-byte Reload
	bit.16b	v2, v4, v0
	str	q2, [sp, #10784]                ; 16-byte Spill
	ldr	q25, [sp, #8160]                ; 16-byte Reload
	bic.16b	v25, v25, v16
	ldr	q23, [sp, #8192]                ; 16-byte Reload
	bic.16b	v23, v23, v18
	ldr	q9, [sp, #8176]                 ; 16-byte Reload
	bic.16b	v9, v9, v1
	ldr	q29, [sp, #8128]                ; 16-byte Reload
	bic.16b	v29, v29, v0
	bic.16b	v16, v19, v31
	bic.16b	v13, v13, v30
	ldr	d0, [sp, #10424]                ; 8-byte Reload
	and.8b	v12, v0, v12
	fmov	x8, d29
	cmp	x8, #8
	ldr	q19, [sp, #10496]               ; 16-byte Reload
	ldr	q30, [sp, #8144]                ; 16-byte Reload
	ldr	q24, [sp, #8112]                ; 16-byte Reload
	ldr	x2, [sp, #10448]                ; 8-byte Reload
	ldr	q15, [sp, #10608]               ; 16-byte Reload
	ldr	q31, [sp, #10576]               ; 16-byte Reload
	add	x7, sp, #5, lsl #12             ; =20480
	add	x7, x7, #3864
	ldr	q18, [sp, #10992]               ; 16-byte Reload
	ldr	q26, [sp, #10944]               ; 16-byte Reload
	ldr	q27, [sp, #10960]               ; 16-byte Reload
	ldr	q10, [sp, #10512]               ; 16-byte Reload
	ldr	q11, [sp, #10480]               ; 16-byte Reload
	ldr	q3, [sp, #11136]                ; 16-byte Reload
	ldr	q8, [sp, #10976]                ; 16-byte Reload
	b.gt	LBB0_291
LBB0_293:                               ; %direct.true829
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_292 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	ldr	q14, [sp, #11184]               ; 16-byte Reload
	sshll.2d	v0, v14, #0
	ldr	q1, [sp, #11344]                ; 16-byte Reload
	and.16b	v1, v1, v23
	and.16b	v0, v0, v9
	ldr	q2, [sp, #11328]                ; 16-byte Reload
	and.16b	v2, v2, v25
	mov.d	x8, v2[1]
	fmov	x9, d2
	ldr	q2, [sp, #11296]                ; 16-byte Reload
	fmov	x10, d2
	sdiv	x11, x9, x10
	mov.d	x13, v0[1]
	msub	x9, x11, x10, x9
	fmov	x10, d0
	ldr	q0, [sp, #11312]                ; 16-byte Reload
	fmov	x11, d0
	sdiv	x17, x10, x11
	mov.d	x3, v1[1]
	msub	x10, x17, x11, x10
	fmov	x11, d1
	fmov	x17, d15
	sdiv	x5, x11, x17
	msub	x11, x5, x17, x11
	sdiv	x17, x8, x2
	msub	x8, x17, x2, x8
	fmov	d1, x9
	sdiv	x9, x13, x22
	msub	x9, x9, x22, x13
	ldr	q28, [sp, #11216]               ; 16-byte Reload
	sshll.2d	v0, v28, #0
	and.16b	v0, v0, v29
	fmov	d2, x10
	sdiv	x10, x3, x24
	msub	x10, x10, x24, x3
	mov.d	x13, v0[1]
	mov.d	v1[1], x8
	fmov	d4, x11
	sdiv	x8, x13, x25
	msub	x8, x8, x25, x13
	fmov	x11, d0
	mov.d	v4[1], x10
	fmov	x10, d3
	sdiv	x13, x11, x10
	msub	x10, x13, x10, x11
	fmov	d5, x10
	mov.d	v2[1], x9
	mov.d	v5[1], x8
	shl.2d	v0, v5, #3
	shl.2d	v6, v4, #3
	shl.2d	v7, v1, #3
	shl.2d	v17, v2, #3
	cmgt.2d	v20, v11, v7
	cmgt.2d	v21, v10, v17
	uzp1.4s	v20, v21, v20
	cmgt.2d	v21, v19, v6
	cmgt.2d	v22, v31, v0
	uzp1.4s	v21, v22, v21
	uzp1.8h	v22, v21, v20
	cmge.2d	v6, v6, v19
	cmge.2d	v0, v0, v31
	cmge.2d	v7, v7, v11
	cmge.2d	v17, v17, v10
	uzp1.4s	v6, v0, v6
	uzp1.4s	v7, v17, v7
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	and.16b	v0, v0, v22
	xtn.8b	v0, v0
	shl.8b	v17, v0, #7
	cmlt.8b	v17, v17, #0
	ldr	d22, [sp, #11400]               ; 8-byte Reload
	and.8b	v22, v17, v22
	addv.8b	b22, v22
	fmov	w8, s22
	umaxv.8b	b17, v17
	fmov	w9, s17
	rbit	w10, w8
	clz	w10, w10
	tst	w9, #0x1
	csel	w9, w10, wzr, ne
	str	q18, [sp, #15536]
	str	q8, [sp, #15552]
	str	q27, [sp, #15568]
	str	q26, [sp, #15584]
	ubfiz	x10, x9, #3, #3
	ldr	x11, [x15, x10]
	ldr	q17, [sp, #10784]               ; 16-byte Reload
	str	q17, [sp, #15472]
	ldr	q17, [sp, #10912]               ; 16-byte Reload
	str	q17, [sp, #15488]
	ldr	q17, [sp, #10896]               ; 16-byte Reload
	str	q17, [sp, #15504]
	ldr	q17, [sp, #10928]               ; 16-byte Reload
	str	q17, [sp, #15520]
	ldr	x13, [x16, x10]
	str	q4, [sp, #15616]
	str	q1, [sp, #15648]
	str	q2, [sp, #15632]
	add	x13, x13, x13, lsl #3
	str	q5, [sp, #15600]
	ldr	x10, [x4, x10]
	lsl	w9, w9, #2
	add	x10, x13, x10
	sub	x9, x11, x9
	add	x9, x9, x10, lsl #5
	tst	w8, #0xff
	csel	x8, xzr, x9, eq
	add	x8, x7, x8
	and.16b	v1, v14, v20
	ldp	q4, q2, [x8]
	bif.16b	v2, v24, v1
	and.16b	v5, v28, v21
	bif.16b	v4, v30, v5
	and.16b	v7, v14, v7
	and.16b	v6, v28, v6
	bic.16b	v30, v4, v6
	bic.16b	v24, v2, v7
	zip2.8b	v2, v12, v0
	ushll.4s	v2, v2, #0
	fadd.4s	v4, v16, v24
	shl.4s	v2, v2, #31
	cmlt.4s	v2, v2, #0
	bsl.16b	v2, v4, v24
	bit.16b	v16, v2, v1
	zip1.8b	v1, v12, v0
	fadd.4s	v2, v13, v30
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmlt.4s	v1, v1, #0
	bsl.16b	v1, v2, v30
	bit.16b	v13, v1, v5
	orr.8b	v12, v12, v0
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v23, v23, v0
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v9, v9, v0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v25, v25, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v29, v29, v0
	fmov	x8, d29
	cmp	x8, #9
	b.lt	LBB0_293
	b	LBB0_291
LBB0_294:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	q17, [sp, #10928]               ; 16-byte Reload
	ldr	q10, [sp, #10912]               ; 16-byte Reload
	ldr	q14, [sp, #10896]               ; 16-byte Reload
LBB0_295:                               ; %direct.false825
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q2, [sp, #9104]                 ; 16-byte Spill
	str	q5, [sp, #9120]                 ; 16-byte Spill
	str	q6, [sp, #9136]                 ; 16-byte Spill
	str	q4, [sp, #9152]                 ; 16-byte Spill
	str	q17, [sp, #10928]               ; 16-byte Spill
	ldr	q0, [sp, #1216]                 ; 16-byte Reload
	ldr	q1, [sp, #5552]                 ; 16-byte Reload
	ldr	q17, [sp, #11328]               ; 16-byte Reload
	bit.16b	v1, v0, v17
	str	q1, [sp, #5552]                 ; 16-byte Spill
	ldr	q6, [sp, #11344]                ; 16-byte Reload
	ldr	q1, [sp, #5568]                 ; 16-byte Reload
	bit.16b	v1, v0, v6
	str	q1, [sp, #5568]                 ; 16-byte Spill
	ldr	q15, [sp, #2384]                ; 16-byte Reload
	ldr	q3, [sp, #10704]                ; 16-byte Reload
	bit.16b	v15, v0, v3
	ldr	q25, [sp, #2336]                ; 16-byte Reload
	ldr	q1, [sp, #10720]                ; 16-byte Reload
	bit.16b	v25, v0, v1
	ldr	q4, [sp, #5696]                 ; 16-byte Reload
	ldr	q26, [sp, #2448]                ; 16-byte Reload
	bit.16b	v26, v4, v17
	ldr	q5, [sp, #5680]                 ; 16-byte Reload
	ldr	q0, [sp, #5520]                 ; 16-byte Reload
	bit.16b	v0, v5, v6
	str	q0, [sp, #5520]                 ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q0, [sp, #5504]                 ; 16-byte Reload
	bit.16b	v0, v2, v3
	str	q0, [sp, #5504]                 ; 16-byte Spill
	ldr	q3, [sp, #5712]                 ; 16-byte Reload
	ldr	q0, [sp, #5536]                 ; 16-byte Reload
	bit.16b	v0, v3, v1
	str	q0, [sp, #5536]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q16, [sp, #4544]                ; 16-byte Reload
	bit.16b	v16, v4, v17
	ldr	q4, [sp, #4576]                 ; 16-byte Reload
	bit.16b	v4, v5, v6
	ldr	q7, [sp, #4560]                 ; 16-byte Reload
	bit.16b	v7, v2, v1
	ldr	q2, [sp, #4592]                 ; 16-byte Reload
	bit.16b	v2, v3, v0
	ldr	q18, [sp, #2256]                ; 16-byte Reload
	bic.16b	v18, v18, v17
	ldr	q3, [sp, #7696]                 ; 16-byte Reload
	bic.16b	v3, v3, v6
	str	q3, [sp, #7696]                 ; 16-byte Spill
	ldr	q27, [sp, #2272]                ; 16-byte Reload
	bic.16b	v27, v27, v1
	ldr	q1, [sp, #7712]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	str	q1, [sp, #7712]                 ; 16-byte Spill
	fmov	x8, d1
	cmp	x8, #1
	str	q2, [sp, #4592]                 ; 16-byte Spill
	str	q4, [sp, #4576]                 ; 16-byte Spill
	str	q7, [sp, #4560]                 ; 16-byte Spill
	str	q16, [sp, #4544]                ; 16-byte Spill
	b.lt	LBB0_313
; %bb.296:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	w22, [sp, #7132]                ; 4-byte Reload
	ldr	x5, [sp, #5040]                 ; 8-byte Reload
	ldr	x4, [sp, #6824]                 ; 8-byte Reload
	ldr	q11, [sp, #2240]                ; 16-byte Reload
	ldr	q29, [sp, #2128]                ; 16-byte Reload
	ldr	w24, [sp, #7836]                ; 4-byte Reload
LBB0_297:                               ; %direct.false863
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q27, [sp, #2272]                ; 16-byte Spill
	str	q18, [sp, #2256]                ; 16-byte Spill
	str	q11, [sp, #2240]                ; 16-byte Spill
	str	q19, [sp, #2288]                ; 16-byte Spill
	str	q13, [sp, #2304]                ; 16-byte Spill
	str	q14, [sp, #10896]               ; 16-byte Spill
	str	q10, [sp, #10912]               ; 16-byte Spill
	str	q25, [sp, #2336]                ; 16-byte Spill
	str	q15, [sp, #2384]                ; 16-byte Spill
	str	q26, [sp, #2448]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q4, [sp, #6880]                 ; 16-byte Reload
	ldr	q16, [sp, #11328]               ; 16-byte Reload
	bit.16b	v4, v2, v16
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q17, [sp, #11344]               ; 16-byte Reload
	ldr	q6, [sp, #6848]                 ; 16-byte Reload
	bit.16b	v6, v2, v17
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q7, [sp, #6832]                 ; 16-byte Reload
	bit.16b	v7, v2, v1
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q5, [sp, #6864]                 ; 16-byte Reload
	bif.16b	v2, v5, v0
	ldr	q28, [sp, #2192]                ; 16-byte Reload
	bic.16b	v28, v28, v16
	ldr	q24, [sp, #2224]                ; 16-byte Reload
	bic.16b	v24, v24, v17
	ldr	q26, [sp, #2208]                ; 16-byte Reload
	bic.16b	v26, v26, v1
	ldr	q16, [sp, #2160]                ; 16-byte Reload
	bic.16b	v16, v16, v0
	fmov	x8, d16
	cmp	x8, #1
	str	q4, [sp, #6880]                 ; 16-byte Spill
	str	q2, [sp, #6864]                 ; 16-byte Spill
	str	q6, [sp, #6848]                 ; 16-byte Spill
	str	q7, [sp, #6832]                 ; 16-byte Spill
	b.gt	LBB0_300
; %bb.298:                              ; %direct.true881.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q2, [sp, #13872]
	str	q6, [sp, #13888]
	str	q7, [sp, #13904]
	str	q4, [sp, #13920]
	ldr	x8, [sp, #720]                  ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #1584
	ldr	x8, [x9, x8, lsl #3]
	sub	x14, x8, x4
	add	x25, sp, #6, lsl #12            ; =24576
	add	x25, x25, #1496
	ldr	q8, [sp, #5088]                 ; 16-byte Reload
	ldr	q10, [sp, #5072]                ; 16-byte Reload
	ldr	q13, [sp, #2176]                ; 16-byte Reload
	ldr	q23, [sp, #2144]                ; 16-byte Reload
	ldr	q21, [sp, #5056]                ; 16-byte Reload
	ldr	q14, [sp, #2096]                ; 16-byte Reload
	ldr	q27, [sp, #1920]                ; 16-byte Reload
	ldr	x6, [sp, #712]                  ; 8-byte Reload
	ldr	q22, [sp, #11168]               ; 16-byte Reload
	add	x26, sp, #3, lsl #12            ; =12288
	add	x26, x26, #1456
	add	x23, sp, #5, lsl #12            ; =20480
	add	x23, x23, #3672
	movi.2d	v15, #0000000000000000
	ldr	q11, [sp, #11328]               ; 16-byte Reload
	ldr	q19, [sp, #11152]               ; 16-byte Reload
	ldr	q18, [sp, #11344]               ; 16-byte Reload
	ldr	q3, [sp, #11056]                ; 16-byte Reload
	ldr	q25, [sp, #11040]               ; 16-byte Reload
LBB0_299:                               ; %direct.true881
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v2, v30, #0
	sshll.2d	v5, v31, #0
	and.16b	v0, v11, v28
	and.16b	v1, v18, v24
	and.16b	v4, v5, v26
	and.16b	v6, v2, v16
	mov.d	x8, v6[1]
	fmov	x9, d6
	ldr	q6, [sp, #10544]                ; 16-byte Reload
	fmov	x10, d6
	sdiv	x11, x9, x10
	mov.d	x13, v4[1]
	msub	x9, x11, x10, x9
	sdiv	x10, x8, x12
	fmov	x11, d4
	ldr	q4, [sp, #10560]                ; 16-byte Reload
	fmov	x15, d4
	sdiv	x16, x11, x15
	msub	x11, x16, x15, x11
	msub	x8, x10, x12, x8
	sdiv	x10, x13, x30
	msub	x10, x10, x30, x13
	mov.d	x13, v1[1]
	fmov	x15, d1
	fmov	d4, x9
	ldr	q1, [sp, #10528]                ; 16-byte Reload
	fmov	x9, d1
	sdiv	x16, x15, x9
	msub	x9, x16, x9, x15
	fmov	d6, x9
	sdiv	x9, x13, x19
	fmov	d17, x11
	msub	x9, x9, x19, x13
	mov.d	x11, v0[1]
	fmov	x13, d0
	mov.d	v6[1], x9
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	fmov	x9, d0
	sdiv	x15, x13, x9
	msub	x9, x15, x9, x13
	fmov	d0, x9
	mov.d	v4[1], x8
	sdiv	x8, x11, x28
	msub	x8, x8, x28, x11
	mov.d	v0[1], x8
	mov.d	v17[1], x10
	str	q0, [sp, #13856]
	str	q17, [sp, #13840]
	and.16b	v1, v11, v0
	str	q6, [sp, #13824]
	str	q4, [sp, #13808]
	and.16b	v0, v18, v6
	and.16b	v7, v2, v4
	mov.d	x13, v25[1]
	mov.d	x15, v7[1]
	and.16b	v4, v5, v17
	fmov	x8, d7
	fmov	x9, d25
	fmov	x10, d4
	fmov	x11, d3
	sdiv	x8, x8, x9
	sdiv	x10, x10, x11
	mov.d	x16, v1[1]
	fmov	x17, d1
	mul	x11, x10, x11
	fmov	d20, x10
	fmov	x10, d22
	sdiv	x17, x17, x10
	mul	x9, x8, x9
	fmov	d17, x9
	mov.d	x9, v4[1]
	mul	x10, x17, x10
	fmov	d6, x10
	mov.d	x10, v22[1]
	sdiv	x3, x16, x10
	mul	x10, x3, x10
	mov.d	v6[1], x10
	mov.d	x10, v3[1]
	sub.2d	v6, v1, v6
	fmov	d1, x11
	mov.d	x11, v19[1]
	sdiv	x16, x15, x13
	mul	x13, x16, x13
	mov.d	v17[1], x13
	fmov	x13, d19
	sdiv	x9, x9, x10
	mul	x10, x9, x10
	mov.d	v1[1], x10
	fmov	x10, d0
	sdiv	x10, x10, x13
	mul	x13, x10, x13
	sub.2d	v1, v4, v1
	fmov	d4, x13
	mov.d	x13, v0[1]
	sdiv	x13, x13, x11
	mul	x11, x13, x11
	mov.d	v4[1], x11
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1520
	ldr	x15, [x11, x6]
	sub.2d	v0, v0, v4
	sub.2d	v4, v7, v17
	bit.16b	v21, v4, v2
	ldr	q2, [sp, #11248]                ; 16-byte Reload
	cmeq.2d	v2, v2, v6
	ldr	q7, [sp, #11232]                ; 16-byte Reload
	cmeq.2d	v7, v7, v1
	uzp1.4s	v2, v7, v2
	ldr	q7, [sp, #11200]                ; 16-byte Reload
	cmeq.2d	v7, v7, v0
	ldr	q17, [sp, #11264]               ; 16-byte Reload
	cmeq.2d	v4, v17, v4
	uzp1.4s	v4, v4, v7
	uzp1.8h	v7, v4, v2
	mov.d	v20[1], x9
	ldr	q17, [sp, #11376]               ; 16-byte Reload
	and.16b	v7, v17, v7
	xtn.8b	v7, v7
	shl.8b	v7, v7, #7
	cmlt.8b	v7, v7, #0
	umaxv.8b	b17, v7
	fmov	w9, s17
	fmov	d17, x17
	mov.d	v17[1], x3
	ldr	d9, [sp, #11400]                ; 8-byte Reload
	and.8b	v7, v7, v9
	addv.8b	b7, v7
	fmov	w11, s7
	fmov	d7, x8
	rbit	w8, w11
	clz	w8, w8
	tst	w9, #0x1
	ldr	q9, [sp, #7184]                 ; 16-byte Reload
	str	q9, [sp, #13616]
	csel	w8, w8, wzr, ne
	ldr	q9, [sp, #7168]                 ; 16-byte Reload
	str	q9, [sp, #13632]
	ldr	q9, [sp, #7152]                 ; 16-byte Reload
	str	q9, [sp, #13648]
	ldr	q9, [sp, #7136]                 ; 16-byte Reload
	str	q9, [sp, #13664]
	ubfiz	x9, x8, #3, #3
	add	x17, sp, #3, lsl #12            ; =12288
	add	x17, x17, #1328
	ldr	x17, [x17, x9]
	str	q17, [sp, #13728]
	fmov	d17, x10
	mov.d	v17[1], x13
	mov.d	v7[1], x16
	str	q20, [sp, #13712]
	str	q17, [sp, #13696]
	str	q7, [sp, #13680]
	lsl	w8, w8, #2
	sub	x8, x17, x8
	bit.16b	v10, v1, v5
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1392
	ldr	x9, [x10, x9]
	add	x8, x8, x9, lsl #5
	tst	w11, #0xff
	csel	x8, xzr, x8, eq
	and.16b	v1, v31, v2
	add	x8, x25, x8
	ldp	q5, q7, [x8]
	bsl.16b	v1, v7, v27
	and.16b	v7, v30, v4
	bit.16b	v8, v0, v18
	bic.16b	v2, v31, v2
	bic.16b	v4, v30, v4
	bif.16b	v5, v29, v7
	xtn.2s	v0, v8
	xtn.2s	v7, v21
	bic.16b	v29, v5, v4
	mov.s	w8, v7[1]
	fmov	w9, s7
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	bic.16b	v27, v1, v2
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1064
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldr	q1, [sp, #11280]                ; 16-byte Reload
	str	d1, [sp, #13352]
	ldrb	w10, [x10]
	str	q27, [sp, #13600]
	str	q29, [sp, #13584]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1296
	ldr	s1, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w0, w10
	xtn.2s	v17, v10
	tst	w9, w10
	fcsel	s5, s1, s15, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #1064
	cset	w10, lo
	bfxil	x9, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w9, [x9]
	str	q27, [sp, #13568]
	str	q29, [sp, #13552]
	and	w9, w2, w9
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1264
	ldr	s1, [x11, x8, lsl #2]
	tst	w10, w9
	mov.s	w8, v0[1]
	fcsel	s2, s1, s15, ne
	fmov	w9, s0
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1064
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q27, [sp, #13536]
	str	q29, [sp, #13520]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1232
	ldr	s0, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w1, w10
	tst	w9, w10
	fcsel	s7, s0, s15, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1064
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	str	q27, [sp, #13504]
	and	w10, w7, w10
	str	q29, [sp, #13488]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1200
	ldr	s0, [x11, x8, lsl #2]
	mov.s	w8, v17[1]
	tst	w9, w10
	fcsel	s0, s0, s15, ne
	fmov	w9, s17
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1064
	bit.16b	v13, v6, v11
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q27, [sp, #13472]
	str	q29, [sp, #13456]
	xtn.2s	v1, v13
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1168
	ldr	s4, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w27, w10
	tst	w9, w10
	fcsel	s6, s4, s15, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1064
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	and	w10, w20, w10
	tst	w9, w10
	mov.s	w9, v1[1]
	str	q27, [sp, #13440]
	str	q29, [sp, #13424]
	fmov	w10, s1
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1136
	ldr	s1, [x11, x8, lsl #2]
	fcsel	s1, s1, s15, ne
	cmp	w10, #8
	csel	w8, w10, wzr, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1064
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	str	q27, [sp, #13408]
	str	q29, [sp, #13392]
	mov.s	v6[1], v1[0]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #1104
	ldr	s1, [x11, x8, lsl #2]
	cset	w8, lo
	and	w10, w21, w10
	tst	w8, w10
	fcsel	s1, s1, s15, ne
	cmp	w9, #8
	csel	w8, w9, wzr, lo
	cset	w9, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #1064
	bfxil	x10, x8, #0, #3
	ldrb	w10, [x10]
	and	w10, w24, w10
	tst	w9, w10
	and	x8, x8, #0x7
	str	q27, [sp, #13376]
	str	q29, [sp, #13360]
	mov.s	v6[2], v1[0]
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #1072
	ldr	s1, [x9, x8, lsl #2]
	fcsel	s1, s1, s15, ne
	mov.s	v6[3], v1[0]
	mov.s	v5[1], v2[0]
	add	x8, x5, x15, lsl #5
	tst	w22, #0xff
	csel	x8, xzr, x8, eq
	add	x9, sp, #10, lsl #12            ; =40960
	add	x9, x9, #1568
	add	x8, x9, x8
	mov.s	v5[2], v7[0]
	ldr	q1, [x8]
	ldr	q7, [sp, #6400]                 ; 16-byte Reload
	bif.16b	v1, v14, v7
	mov.s	v5[3], v0[0]
	ldr	q0, [x8, #16]
	str	q16, [sp, #13744]
	ldr	q4, [sp, #6352]                 ; 16-byte Reload
	bif.16b	v0, v23, v4
	str	q24, [sp, #13760]
	str	q26, [sp, #13776]
	str	q28, [sp, #13792]
	ldr	x8, [x26, x6]
	ldr	q2, [sp, #6304]                 ; 16-byte Reload
	and.16b	v23, v2, v0
	fmul.4s	v0, v23, v6
	add	x8, x14, x8, lsl #5
	csel	x8, xzr, x8, eq
	add	x8, x23, x8
	ldp	q2, q6, [x8]
	bif.16b	v0, v6, v4
	ldr	q4, [sp, #6240]                 ; 16-byte Reload
	and.16b	v14, v4, v1
	fmul.4s	v1, v14, v5
	bif.16b	v1, v2, v7
	stp	q1, q0, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v24, v24, v0
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v26, v26, v0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v28, v28, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v16, v16, v0
	fmov	x8, d16
	cmp	x8, #2
	b.lt	LBB0_299
	b	LBB0_301
LBB0_300:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	q8, [sp, #5088]                 ; 16-byte Reload
	ldr	q10, [sp, #5072]                ; 16-byte Reload
	ldr	q13, [sp, #2176]                ; 16-byte Reload
	ldr	q23, [sp, #2144]                ; 16-byte Reload
	ldr	q21, [sp, #5056]                ; 16-byte Reload
	ldr	q14, [sp, #2096]                ; 16-byte Reload
	ldr	q27, [sp, #1920]                ; 16-byte Reload
	ldr	q11, [sp, #11328]               ; 16-byte Reload
	ldr	q18, [sp, #11344]               ; 16-byte Reload
LBB0_301:                               ; %direct.false882
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q27, [sp, #1920]                ; 16-byte Spill
	str	q14, [sp, #2096]                ; 16-byte Spill
	str	q29, [sp, #2128]                ; 16-byte Spill
	str	q21, [sp, #5056]                ; 16-byte Spill
	str	q23, [sp, #2144]                ; 16-byte Spill
	str	q16, [sp, #2160]                ; 16-byte Spill
	str	q13, [sp, #2176]                ; 16-byte Spill
	str	q10, [sp, #5072]                ; 16-byte Spill
	str	q8, [sp, #5088]                 ; 16-byte Spill
	str	q28, [sp, #2192]                ; 16-byte Spill
	str	q26, [sp, #2208]                ; 16-byte Spill
	str	q24, [sp, #2224]                ; 16-byte Spill
	str	q12, [sp, #2320]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5696]                 ; 16-byte Reload
	ldr	q3, [sp, #7216]                 ; 16-byte Reload
	bit.16b	v3, v2, v11
	str	q3, [sp, #7216]                 ; 16-byte Spill
	ldr	q2, [sp, #5680]                 ; 16-byte Reload
	ldr	q3, [sp, #7248]                 ; 16-byte Reload
	bit.16b	v3, v2, v18
	str	q3, [sp, #7248]                 ; 16-byte Spill
	ldr	q2, [sp, #5728]                 ; 16-byte Reload
	ldr	q3, [sp, #7232]                 ; 16-byte Reload
	bit.16b	v3, v2, v1
	str	q3, [sp, #7232]                 ; 16-byte Spill
	ldr	q2, [sp, #5712]                 ; 16-byte Reload
	ldr	q3, [sp, #7200]                 ; 16-byte Reload
	bit.16b	v3, v2, v0
	str	q3, [sp, #7200]                 ; 16-byte Spill
	ldr	q17, [sp, #9040]                ; 16-byte Reload
	bic.16b	v17, v17, v11
	ldr	q7, [sp, #9072]                 ; 16-byte Reload
	bic.16b	v7, v7, v18
	ldr	q16, [sp, #9056]                ; 16-byte Reload
	bic.16b	v16, v16, v1
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	bic.16b	v3, v3, v0
	fmov	x8, d3
	cmp	x8, #1
	b.gt	LBB0_308
; %bb.302:                              ; %direct.true908.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q0, [sp, #4912]                 ; 16-byte Reload
	str	q0, [sp, #13280]
	ldr	q0, [sp, #4896]                 ; 16-byte Reload
	str	q0, [sp, #13296]
	ldr	q0, [sp, #4944]                 ; 16-byte Reload
	str	q0, [sp, #13312]
	ldr	q0, [sp, #4928]                 ; 16-byte Reload
	str	q0, [sp, #13328]
	ldr	x8, [sp, #704]                  ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #992
	ldr	x8, [x9, x8, lsl #3]
	sub	x14, x8, x4
	ldr	q25, [sp, #10880]               ; 16-byte Reload
	ldr	q27, [sp, #10864]               ; 16-byte Reload
	ldr	q13, [sp, #10848]               ; 16-byte Reload
	ldr	q14, [sp, #10832]               ; 16-byte Reload
	ldr	q20, [sp, #2112]                ; 16-byte Reload
	ldr	q18, [sp, #2080]                ; 16-byte Reload
	ldr	q23, [sp, #2064]                ; 16-byte Reload
	ldr	q26, [sp, #2048]                ; 16-byte Reload
	ldr	q19, [sp, #11280]               ; 16-byte Reload
	ldr	q21, [sp, #10528]               ; 16-byte Reload
	b	LBB0_305
LBB0_303:                               ;   in Loop: Header=BB0_305 Depth=2
	ldr	q6, [sp, #8016]                 ; 16-byte Reload
	ldr	q9, [sp, #8000]                 ; 16-byte Reload
	ldr	q28, [sp, #7984]                ; 16-byte Reload
	ldr	q15, [sp, #7968]                ; 16-byte Reload
	ldr	q3, [sp, #7952]                 ; 16-byte Reload
	ldr	q16, [sp, #7936]                ; 16-byte Reload
	ldr	q11, [sp, #7920]                ; 16-byte Reload
	ldr	q19, [sp, #7904]                ; 16-byte Reload
	ldr	q12, [sp, #7888]                ; 16-byte Reload
	ldr	q10, [sp, #7872]                ; 16-byte Reload
	ldr	q27, [sp, #11440]               ; 16-byte Reload
LBB0_304:                               ; %direct.false920
                                        ;   in Loop: Header=BB0_305 Depth=2
	str	q10, [sp, #7872]                ; 16-byte Spill
	str	q12, [sp, #7888]                ; 16-byte Spill
	str	q19, [sp, #7904]                ; 16-byte Spill
	str	q11, [sp, #7920]                ; 16-byte Spill
	str	q16, [sp, #7936]                ; 16-byte Spill
	str	q3, [sp, #7952]                 ; 16-byte Spill
	str	q15, [sp, #7968]                ; 16-byte Spill
	str	q28, [sp, #7984]                ; 16-byte Spill
	str	q9, [sp, #8000]                 ; 16-byte Spill
	str	q6, [sp, #8016]                 ; 16-byte Spill
	str	q29, [sp, #8048]                ; 16-byte Spill
	str	q5, [sp, #8064]                 ; 16-byte Spill
	ldr	q0, [sp, #7216]                 ; 16-byte Reload
	ldr	q1, [sp, #10448]                ; 16-byte Reload
	orr.16b	v0, v1, v0
	ldr	q1, [sp, #7232]                 ; 16-byte Reload
	ldr	q2, [sp, #10464]                ; 16-byte Reload
	orr.16b	v1, v2, v1
	ldr	q2, [sp, #7248]                 ; 16-byte Reload
	ldr	q3, [sp, #10672]                ; 16-byte Reload
	orr.16b	v2, v3, v2
	ldr	q3, [sp, #7200]                 ; 16-byte Reload
	ldr	q4, [sp, #10688]                ; 16-byte Reload
	orr.16b	v4, v4, v3
	str	q4, [sp, #12624]
	str	q2, [sp, #12640]
	str	q1, [sp, #12656]
	str	q0, [sp, #12672]
	ldr	x8, [sp, #5760]                 ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #336
	ldr	x8, [x9, x8, lsl #3]
	ldr	x4, [sp, #6824]                 ; 8-byte Reload
	sub	x8, x8, x4
	tst	w27, #0xff
	csel	x8, xzr, x8, eq
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #3608
	add	x8, x15, x8
	ldp	q0, q1, [x8]
	ldr	q2, [sp, #5968]                 ; 16-byte Reload
	bit.16b	v1, v18, v2
	ldr	q2, [sp, #5952]                 ; 16-byte Reload
	bit.16b	v0, v20, v2
	stp	q0, q1, [x8]
	ldr	q7, [sp, #9072]                 ; 16-byte Reload
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v7, v7, v0
	ldr	q16, [sp, #9056]                ; 16-byte Reload
	add.2d	v16, v16, v27
	ldr	q17, [sp, #9040]                ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	add.2d	v17, v17, v9
	ldr	q3, [sp, #9088]                 ; 16-byte Reload
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v3, v3, v0
	fmov	x8, d3
	cmp	x8, #2
	ldr	q21, [sp, #10528]               ; 16-byte Reload
	ldr	q19, [sp, #11280]               ; 16-byte Reload
	ldr	q25, [sp, #10880]               ; 16-byte Reload
	ldr	q27, [sp, #10864]               ; 16-byte Reload
	ldr	q13, [sp, #10848]               ; 16-byte Reload
	ldr	q14, [sp, #10832]               ; 16-byte Reload
	ldr	x12, [sp, #7672]                ; 8-byte Reload
	ldr	q11, [sp, #11328]               ; 16-byte Reload
	ldr	x28, [sp, #9896]                ; 8-byte Reload
	ldr	x30, [sp, #9888]                ; 8-byte Reload
	ldr	x19, [sp, #10432]               ; 8-byte Reload
	mov	x22, x27
	b.ge	LBB0_309
LBB0_305:                               ; %direct.true908
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Loop Header: Depth=2
                                        ;       Child Loop BB0_307 Depth 3
	sshll.2d	v0, v30, #0
	sshll.2d	v2, v31, #0
	and.16b	v1, v11, v17
	and.16b	v4, v0, v3
	mov.d	x8, v4[1]
	sdiv	x9, x8, x12
	msub	x8, x9, x12, x8
	fmov	x9, d4
	ldr	q4, [sp, #10544]                ; 16-byte Reload
	fmov	x10, d4
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d4, x9
	mov.d	v4[1], x8
	and.16b	v5, v2, v16
	mov.d	x8, v5[1]
	sdiv	x9, x8, x30
	msub	x8, x9, x30, x8
	fmov	x9, d5
	ldr	q5, [sp, #10560]                ; 16-byte Reload
	fmov	x10, d5
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d5, x9
	mov.d	v5[1], x8
	ldr	q24, [sp, #11344]               ; 16-byte Reload
	and.16b	v6, v24, v7
	mov.d	x8, v6[1]
	sdiv	x9, x8, x19
	msub	x8, x9, x19, x8
	fmov	x9, d6
	fmov	x10, d21
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d6, x9
	mov.d	v6[1], x8
	mov.d	x8, v1[1]
	sdiv	x9, x8, x28
	msub	x8, x9, x28, x8
	fmov	x9, d1
	ldr	q1, [sp, #10592]                ; 16-byte Reload
	fmov	x10, d1
	sdiv	x11, x9, x10
	msub	x9, x11, x10, x9
	fmov	d1, x9
	mov.d	v1[1], x8
	mov.16b	v21, v11
	bsl.16b	v21, v1, v14
	mov.16b	v22, v24
	bsl.16b	v22, v6, v27
	mov.16b	v27, v2
	bsl.16b	v27, v5, v13
	mov.16b	v13, v0
	bsl.16b	v13, v4, v25
	str	q3, [sp, #9088]                 ; 16-byte Spill
	shl.2d	v4, v3, #5
	str	q7, [sp, #9072]                 ; 16-byte Spill
	shl.2d	v3, v7, #5
	str	q16, [sp, #9056]                ; 16-byte Spill
	shl.2d	v5, v16, #5
	str	q17, [sp, #9040]                ; 16-byte Spill
	shl.2d	v6, v17, #5
	ldr	q1, [sp, #6848]                 ; 16-byte Reload
	str	q3, [sp, #10672]                ; 16-byte Spill
	orr.16b	v1, v3, v1
	ldr	q3, [sp, #6864]                 ; 16-byte Reload
	str	q4, [sp, #10688]                ; 16-byte Spill
	orr.16b	v4, v4, v3
	str	q4, [sp, #13216]
	ldr	q3, [sp, #6880]                 ; 16-byte Reload
	str	q6, [sp, #10448]                ; 16-byte Spill
	orr.16b	v4, v6, v3
	str	q1, [sp, #13232]
	ldr	q1, [sp, #6832]                 ; 16-byte Reload
	str	q5, [sp, #10464]                ; 16-byte Spill
	orr.16b	v1, v5, v1
	str	q1, [sp, #13248]
	str	q4, [sp, #13264]
	ldr	x8, [sp, #5768]                 ; 8-byte Reload
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #928
	ldr	x8, [x9, x8, lsl #3]
	sub	x8, x8, x4
	mov	x27, x22
	tst	w22, #0xff
	csel	x8, xzr, x8, eq
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #3672
	add	x8, x9, x8
	ldr	q1, [x8, #16]
	ldr	q3, [sp, #6192]                 ; 16-byte Reload
	ldr	q4, [sp, #8032]                 ; 16-byte Reload
	bif.16b	v1, v4, v3
	ldr	q4, [x8]
	ldr	q3, [sp, #6144]                 ; 16-byte Reload
	ldr	q5, [sp, #8080]                 ; 16-byte Reload
	bif.16b	v4, v5, v3
	ldr	q5, [sp, #8064]                 ; 16-byte Reload
	bic.16b	v5, v5, v2
	bic.16b	v23, v23, v0
	ldr	q2, [sp, #8096]                 ; 16-byte Reload
	movi	d0, #0xffffffffffffff
	bit.8b	v2, v0, v19
	ldr	q0, [sp, #6096]                 ; 16-byte Reload
	and.16b	v3, v0, v4
	ldr	q0, [sp, #6032]                 ; 16-byte Reload
	and.16b	v0, v0, v1
	ldr	q29, [sp, #8048]                ; 16-byte Reload
	bic.16b	v29, v29, v11
	bic.16b	v26, v26, v24
	str	q0, [sp, #8032]                 ; 16-byte Spill
	bit.16b	v18, v0, v31
	str	q3, [sp, #8080]                 ; 16-byte Spill
	bit.16b	v20, v3, v30
	fmov	x8, d23
	cmp	x8, #64
	str	q2, [sp, #8096]                 ; 16-byte Spill
	str	q13, [sp, #10880]               ; 16-byte Spill
	str	q22, [sp, #10864]               ; 16-byte Spill
	str	q27, [sp, #10848]               ; 16-byte Spill
	str	q21, [sp, #10832]               ; 16-byte Spill
	b.gt	LBB0_303
; %bb.306:                              ; %direct.true919.lr.ph
                                        ;   in Loop: Header=BB0_305 Depth=2
	bic.8b	v0, v19, v2
	zip1.8b	v1, v0, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	str	q1, [sp, #10720]                ; 16-byte Spill
	zip2.8b	v0, v0, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #10704]                ; 16-byte Spill
	ldr	q6, [sp, #8016]                 ; 16-byte Reload
	ldr	q9, [sp, #8000]                 ; 16-byte Reload
	ldr	q28, [sp, #7984]                ; 16-byte Reload
	ldr	q15, [sp, #7968]                ; 16-byte Reload
	ldr	q3, [sp, #7952]                 ; 16-byte Reload
	ldr	q16, [sp, #7936]                ; 16-byte Reload
	ldr	q11, [sp, #7920]                ; 16-byte Reload
	ldr	q19, [sp, #7904]                ; 16-byte Reload
	ldr	q12, [sp, #7888]                ; 16-byte Reload
	ldr	q10, [sp, #7872]                ; 16-byte Reload
	add	x28, sp, #3, lsl #12            ; =12288
	add	x28, x28, #608
	ldr	w1, [sp, #10420]                ; 4-byte Reload
	ldr	w2, [sp, #10316]                ; 4-byte Reload
	ldr	w7, [sp, #5372]                 ; 4-byte Reload
	ldr	w19, [sp, #7356]                ; 4-byte Reload
	ldr	w20, [sp, #10092]               ; 4-byte Reload
	ldr	w21, [sp, #5368]                ; 4-byte Reload
	ldr	w22, [sp, #7836]                ; 4-byte Reload
	ldr	w0, [sp, #5324]                 ; 4-byte Reload
	add	x25, sp, #3, lsl #12            ; =12288
	add	x25, x25, #576
	add	x5, sp, #3, lsl #12             ; =12288
	add	x5, x5, #544
	add	x23, sp, #3, lsl #12            ; =12288
	add	x23, x23, #512
	add	x26, sp, #3, lsl #12            ; =12288
	add	x26, x26, #480
	ldr	x24, [sp, #5240]                ; 8-byte Reload
	add	x12, sp, #3, lsl #12            ; =12288
	add	x12, x12, #416
	add	x6, sp, #7, lsl #12             ; =28672
	add	x6, x6, #2208
	add	x30, sp, #5, lsl #12            ; =20480
	add	x30, x30, #3864
LBB0_307:                               ; %direct.true919
                                        ;   Parent Loop BB0_28 Depth=1
                                        ;     Parent Loop BB0_305 Depth=2
                                        ; =>    This Inner Loop Header: Depth=3
	sshll.2d	v2, v30, #0
	sshll.2d	v21, v31, #0
	ldr	q8, [sp, #11328]                ; 16-byte Reload
	and.16b	v7, v8, v29
	ldr	q24, [sp, #11344]               ; 16-byte Reload
	and.16b	v0, v24, v26
	and.16b	v22, v21, v5
	and.16b	v17, v2, v23
	mov.d	x8, v17[1]
	ldr	q1, [sp, #11040]                ; 16-byte Reload
	mov.d	x9, v1[1]
	fmov	x10, d1
	fmov	x11, d17
	sdiv	x13, x11, x10
	mov.d	x11, v22[1]
	ldr	q1, [sp, #11056]                ; 16-byte Reload
	mov.d	x17, v1[1]
	sdiv	x8, x8, x9
	fmov	x15, d22
	fmov	x3, d1
	mov.d	x16, v0[1]
	mul	x10, x13, x10
	fmov	d4, x10
	fmov	x10, d0
	mul	x9, x8, x9
	mov.d	v4[1], x9
	ldr	q1, [sp, #11152]                ; 16-byte Reload
	fmov	x9, d1
	sdiv	x4, x15, x3
	sdiv	x15, x10, x9
	mul	x9, x15, x9
	mov.16b	v14, v23
	fmov	d23, x9
	mov.d	x9, v1[1]
	sdiv	x16, x16, x9
	mul	x9, x16, x9
	mov.d	v23[1], x9
	mov.d	x9, v7[1]
	mul	x10, x4, x3
	fmov	d1, x4
	ldr	q25, [sp, #11168]               ; 16-byte Reload
	mov.d	x3, v25[1]
	mov.16b	v27, v26
	fmov	d26, x10
	fmov	x10, d7
	sdiv	x11, x11, x17
	mul	x17, x11, x17
	mov.d	v26[1], x17
	fmov	x17, d25
	sdiv	x10, x10, x17
	mul	x17, x10, x17
	mov.16b	v13, v20
	fmov	d20, x17
	sdiv	x9, x9, x3
	mul	x17, x9, x3
	add	x3, sp, #3, lsl #12             ; =12288
	add	x3, x3, #800
	mov.d	v20[1], x17
	sub.2d	v20, v7, v20
	sub.2d	v7, v22, v26
	sub.2d	v0, v0, v23
	sub.2d	v22, v17, v4
	ldr	q4, [sp, #11248]                ; 16-byte Reload
	cmeq.2d	v4, v4, v20
	ldr	q17, [sp, #11232]               ; 16-byte Reload
	cmeq.2d	v17, v17, v7
	uzp1.4s	v4, v17, v4
	ldr	q17, [sp, #11200]               ; 16-byte Reload
	cmeq.2d	v17, v17, v0
	ldr	q23, [sp, #11264]               ; 16-byte Reload
	cmeq.2d	v23, v23, v22
	uzp1.4s	v17, v23, v17
	uzp1.8h	v23, v17, v4
	mov.d	v1[1], x11
	ldr	q25, [sp, #11376]               ; 16-byte Reload
	and.16b	v23, v25, v23
	xtn.8b	v23, v23
	shl.8b	v23, v23, #7
	cmlt.8b	v23, v23, #0
	umaxv.8b	b26, v23
	fmov	w11, s26
	fmov	d26, x10
	mov.d	v26[1], x9
	ldr	d25, [sp, #11400]               ; 8-byte Reload
	and.8b	v23, v23, v25
	addv.8b	b23, v23
	fmov	w9, s23
	fmov	d23, x13
	rbit	w10, w9
	clz	w10, w10
	tst	w11, #0x1
	ldr	q25, [sp, #10992]               ; 16-byte Reload
	str	q25, [sp, #13088]
	csel	w10, w10, wzr, ne
	ldr	q25, [sp, #10976]               ; 16-byte Reload
	str	q25, [sp, #13104]
	ldr	q25, [sp, #10960]               ; 16-byte Reload
	str	q25, [sp, #13120]
	ldr	q25, [sp, #10944]               ; 16-byte Reload
	str	q25, [sp, #13136]
	ubfiz	x11, x10, #3, #3
	ldr	x13, [x3, x11]
	add	x17, sp, #3, lsl #12            ; =12288
	add	x17, x17, #736
	ldr	q25, [sp, #10880]               ; 16-byte Reload
	str	q25, [sp, #13024]
	ldr	q25, [sp, #10864]               ; 16-byte Reload
	str	q25, [sp, #13040]
	ldr	q25, [sp, #10848]               ; 16-byte Reload
	str	q25, [sp, #13056]
	ldr	q25, [sp, #10832]               ; 16-byte Reload
	str	q25, [sp, #13072]
	ldr	x17, [x17, x11]
	str	q26, [sp, #13200]
	fmov	d26, x15
	mov.d	v26[1], x16
	mov.d	v23[1], x8
	str	q1, [sp, #13184]
	str	q26, [sp, #13168]
	mov.16b	v26, v27
	str	q23, [sp, #13152]
	ldr	q27, [sp, #11440]               ; 16-byte Reload
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #864
	ldr	x8, [x8, x11]
	add	x11, x17, x17, lsl #3
	add	x8, x11, x8
	bit.16b	v6, v22, v2
	lsl	w10, w10, #2
	sub	x10, x13, x10
	add	x8, x10, x8, lsl #5
	and.16b	v1, v31, v4
	tst	w9, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x30, x8
	ldr	q2, [x8, #16]
	bsl.16b	v1, v2, v10
	ldr	q2, [x8]
	and.16b	v22, v30, v17
	bif.16b	v2, v9, v22
	bit.16b	v28, v0, v24
	bic.16b	v0, v31, v4
	bic.16b	v4, v30, v17
	bic.16b	v9, v2, v4
	xtn.2s	v2, v6
	mov.s	w8, v2[1]
	fmov	w9, s2
	xtn.2s	v4, v28
	bic.16b	v10, v1, v0
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #408
	bfxil	x10, x9, #0, #3
	ldr	q0, [sp, #11280]                ; 16-byte Reload
	str	d0, [sp, #12696]
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q10, [sp, #13008]
	str	q9, [sp, #12992]
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #704
	ldr	s0, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w0, w10
	tst	w9, w10
	movi.2d	v17, #0000000000000000
	fcsel	s2, s0, s17, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	and	x9, x8, #0x7
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #408
	bfxil	x10, x8, #0, #3
	ldrb	w8, [x10]
	mov.s	w10, v4[1]
	str	q10, [sp, #12976]
	str	q9, [sp, #12960]
	fmov	w11, s4
	add	x13, sp, #3, lsl #12            ; =12288
	add	x13, x13, #672
	ldr	s0, [x13, x9, lsl #2]
	cset	w9, lo
	and	w8, w1, w8
	tst	w9, w8
	fcsel	s22, s0, s17, ne
	cmp	w11, #8
	csel	w8, w11, wzr, lo
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #408
	bit.16b	v3, v20, v8
	bfxil	x9, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w9, [x9]
	str	q10, [sp, #12944]
	str	q9, [sp, #12928]
	bit.16b	v15, v7, v21
	add	x11, sp, #3, lsl #12            ; =12288
	add	x11, x11, #640
	ldr	s0, [x11, x8, lsl #2]
	cset	w8, lo
	and	w9, w2, w9
	tst	w8, w9
	xtn.2s	v1, v15
	fcsel	s0, s0, s17, ne
	cmp	w10, #8
	csel	w8, w10, wzr, lo
	add	x9, sp, #3, lsl #12             ; =12288
	add	x9, x9, #408
	bfxil	x9, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w9, [x9]
	str	q10, [sp, #12912]
	str	q9, [sp, #12896]
	ldr	s4, [x28, x8, lsl #2]
	cset	w8, lo
	and	w9, w7, w9
	tst	w8, w9
	mov.s	w8, v1[1]
	fmov	w9, s1
	fcsel	s7, s4, s17, ne
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #408
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w13, [x10]
	str	q10, [sp, #12880]
	str	q9, [sp, #12864]
	ldr	s1, [x25, x9, lsl #2]
	mov.s	v2[1], v22[0]
	xtn.2s	v4, v3
	cset	w9, lo
	and	w10, w19, w13
	tst	w9, w10
	fcsel	s1, s1, s17, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #408
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	and	w10, w20, w10
	str	q10, [sp, #12848]
	str	q9, [sp, #12832]
	tst	w9, w10
	mov.s	w9, v4[1]
	fmov	w10, s4
	ldr	s4, [x5, x8, lsl #2]
	fcsel	s4, s4, s17, ne
	mov.s	v1[1], v4[0]
	cmp	w10, #8
	csel	w8, w10, wzr, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #408
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	str	q10, [sp, #12816]
	str	q9, [sp, #12800]
	mov.s	v2[2], v0[0]
	ldr	s0, [x23, x8, lsl #2]
	cset	w8, lo
	and	w10, w21, w10
	tst	w8, w10
	fcsel	s0, s0, s17, ne
	mov.s	v1[2], v0[0]
	cmp	w9, #8
	csel	w8, w9, wzr, lo
	cset	w9, lo
	add	x10, sp, #3, lsl #12            ; =12288
	add	x10, x10, #408
	bfxil	x10, x8, #0, #3
	ldrb	w10, [x10]
	and	w10, w22, w10
	tst	w9, w10
	and	x8, x8, #0x7
	mov.s	v2[3], v7[0]
	str	q10, [sp, #12784]
	str	q9, [sp, #12768]
	ldr	s0, [x26, x8, lsl #2]
	fcsel	s0, s0, s17, ne
	mov.s	v1[3], v0[0]
	str	q14, [sp, #12704]
	str	q26, [sp, #12720]
	str	q5, [sp, #12736]
	str	q29, [sp, #12752]
	ldr	x8, [x12, x24, lsl #3]
	bit.16b	v11, v2, v30
	add	x8, x14, x8, lsl #5
	tst	w27, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x6, x8
	bit.16b	v19, v1, v31
	ldr	q0, [x8, #16]
	ldr	q1, [sp, #10640]                ; 16-byte Reload
	bif.16b	v0, v12, v1
	ldr	q1, [x8]
	ldr	q2, [sp, #10624]                ; 16-byte Reload
	bif.16b	v1, v16, v2
	ldr	q2, [sp, #10720]                ; 16-byte Reload
	and.16b	v16, v2, v1
	ldr	q1, [sp, #10704]                ; 16-byte Reload
	and.16b	v12, v1, v0
	fmul.4s	v0, v12, v19
	fadd.4s	v0, v18, v0
	bit.16b	v18, v0, v31
	fmul.4s	v0, v16, v11
	fadd.4s	v0, v13, v0
	mov.16b	v20, v30
	bsl.16b	v20, v0, v13
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v26, v26, v0
	add.2d	v5, v5, v27
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v29, v29, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v23, v14, v0
	fmov	x8, d23
	cmp	x8, #65
	b.lt	LBB0_307
	b	LBB0_304
LBB0_308:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	q25, [sp, #10880]               ; 16-byte Reload
	ldr	q27, [sp, #10864]               ; 16-byte Reload
	ldr	q13, [sp, #10848]               ; 16-byte Reload
	ldr	q14, [sp, #10832]               ; 16-byte Reload
	ldr	q20, [sp, #2112]                ; 16-byte Reload
	ldr	q18, [sp, #2080]                ; 16-byte Reload
	ldr	q23, [sp, #2064]                ; 16-byte Reload
	ldr	q26, [sp, #2048]                ; 16-byte Reload
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #3608
	ldr	q9, [sp, #11408]                ; 16-byte Reload
LBB0_309:                               ; %direct.false909
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q25, [sp, #10880]               ; 16-byte Spill
	str	q23, [sp, #2064]                ; 16-byte Spill
	str	q18, [sp, #2080]                ; 16-byte Spill
	str	q20, [sp, #2112]                ; 16-byte Spill
	str	q17, [sp, #9040]                ; 16-byte Spill
	str	q16, [sp, #9056]                ; 16-byte Spill
	str	q7, [sp, #9072]                 ; 16-byte Spill
	str	q3, [sp, #9088]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q23, [sp, #2016]                ; 16-byte Reload
	bic.16b	v23, v23, v11
	ldr	q12, [sp, #1936]                ; 16-byte Reload
	ldr	q2, [sp, #11344]                ; 16-byte Reload
	bic.16b	v12, v12, v2
	ldr	q19, [sp, #2032]                ; 16-byte Reload
	bic.16b	v19, v19, v1
	ldr	q11, [sp, #1952]                ; 16-byte Reload
	bic.16b	v11, v11, v0
	fmov	x8, d11
	cmp	x8, #1
	ldr	q20, [sp, #11424]               ; 16-byte Reload
	ldr	q21, [sp, #10656]               ; 16-byte Reload
	ldr	w10, [sp, #5052]                ; 4-byte Reload
	ldr	x11, [sp, #4968]                ; 8-byte Reload
	ldr	q3, [sp, #1104]                 ; 16-byte Reload
	ldr	q24, [sp, #1088]                ; 16-byte Reload
	ldr	q25, [sp, #1072]                ; 16-byte Reload
	ldr	x3, [sp, #1000]                 ; 8-byte Reload
	add	x13, sp, #6, lsl #12            ; =24576
	add	x13, x13, #1560
	ldr	q28, [sp, #7392]                ; 16-byte Reload
	ldr	q8, [sp, #7376]                 ; 16-byte Reload
	ldr	q10, [sp, #1968]                ; 16-byte Reload
	ldr	q15, [sp, #1904]                ; 16-byte Reload
	add	x14, sp, #3, lsl #12            ; =12288
	add	x14, x14, #272
	add	x16, sp, #3, lsl #12            ; =12288
	add	x16, x16, #208
	add	x17, sp, #10, lsl #12           ; =40960
	add	x17, x17, #1696
	ldr	q22, [sp, #11440]               ; 16-byte Reload
	ldr	q29, [sp, #7360]                ; 16-byte Reload
	ldr	q16, [sp, #7408]                ; 16-byte Reload
	ldr	q18, [sp, #11360]               ; 16-byte Reload
	b.ge	LBB0_311
LBB0_310:                               ; %direct.true954
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v0, v11, #5
	shl.2d	v1, v12, #5
	shl.2d	v2, v19, #5
	shl.2d	v4, v23, #5
	orr.16b	v5, v4, v16
	orr.16b	v6, v2, v8
	orr.16b	v7, v1, v28
	orr.16b	v17, v0, v29
	str	q17, [sp, #12560]
	str	q7, [sp, #12576]
	str	q6, [sp, #12592]
	str	q5, [sp, #12608]
	ldr	q5, [sp, #5408]                 ; 16-byte Reload
	ldr	x8, [x14, x3]
	sub	x8, x8, x11
	orr.16b	v4, v4, v21
	ldr	q6, [sp, #10736]                ; 16-byte Reload
	orr.16b	v2, v2, v6
	ldr	q6, [sp, #11072]                ; 16-byte Reload
	orr.16b	v1, v1, v6
	ldr	q6, [sp, #11088]                ; 16-byte Reload
	orr.16b	v0, v0, v6
	str	q0, [sp, #12496]
	str	q1, [sp, #12512]
	str	q2, [sp, #12528]
	str	q4, [sp, #12544]
	ldr	x9, [x16, x3]
	sub	x9, x9, x11
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x13, x8
	ldp	q0, q1, [x8]
	bif.16b	v1, v15, v5
	bif.16b	v0, v10, v3
	and.16b	v10, v24, v0
	and.16b	v15, v25, v1
	csel	x8, xzr, x9, eq
	add	x8, x17, x8
	ldp	q0, q1, [x8]
	bit.16b	v1, v15, v5
	bit.16b	v0, v10, v3
	stp	q0, q1, [x8]
	add.2d	v12, v12, v18
	add.2d	v19, v19, v22
	add.2d	v23, v23, v9
	add.2d	v11, v11, v20
	fmov	x8, d11
	cmp	x8, #1
	b.lt	LBB0_310
LBB0_311:                               ; %direct.false955
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q15, [sp, #1904]                ; 16-byte Spill
	str	q12, [sp, #1936]                ; 16-byte Spill
	str	q11, [sp, #1952]                ; 16-byte Spill
	str	q10, [sp, #1968]                ; 16-byte Spill
	str	q23, [sp, #2016]                ; 16-byte Spill
	str	q19, [sp, #2032]                ; 16-byte Spill
	str	q26, [sp, #2048]                ; 16-byte Spill
	str	q14, [sp, #10832]               ; 16-byte Spill
	str	q13, [sp, #10848]               ; 16-byte Spill
	str	q27, [sp, #10864]               ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q14, [sp, #1984]                ; 16-byte Reload
	ldr	q24, [sp, #11328]               ; 16-byte Reload
	bic.16b	v14, v14, v24
	ldr	q19, [sp, #1824]                ; 16-byte Reload
	ldr	q3, [sp, #11344]                ; 16-byte Reload
	bic.16b	v19, v19, v3
	ldr	q13, [sp, #2000]                ; 16-byte Reload
	bic.16b	v13, v13, v1
	ldr	q25, [sp, #1840]                ; 16-byte Reload
	bic.16b	v25, v25, v0
	fmov	x8, d25
	cmp	x8, #1
	ldr	q11, [sp, #1056]                ; 16-byte Reload
	ldr	q15, [sp, #1040]                ; 16-byte Reload
	ldr	x13, [sp, #992]                 ; 8-byte Reload
	add	x14, sp, #10, lsl #12           ; =40960
	add	x14, x14, #1728
	add	x0, sp, #3, lsl #12             ; =12288
	add	x0, x0, #80
	add	x5, sp, #10, lsl #12            ; =40960
	add	x5, x5, #1632
	add	x6, sp, #3, lsl #12             ; =12288
	add	x6, x6, #16
	add	x23, sp, #2, lsl #12            ; =8192
	add	x23, x23, #4048
	add	x24, sp, #10, lsl #12           ; =40960
	add	x24, x24, #1504
	ldr	x2, [sp, #5040]                 ; 8-byte Reload
	add	x1, sp, #5, lsl #12             ; =20480
	add	x1, x1, #3736
	b.lt	LBB0_331
; %bb.312:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	q22, [sp, #1856]                ; 16-byte Reload
	ldr	q23, [sp, #1808]                ; 16-byte Reload
	ldr	q29, [sp, #11360]               ; 16-byte Reload
	b	LBB0_333
LBB0_313:                               ; %direct.true862.lr.ph
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q0, [sp, #4624]                 ; 16-byte Reload
	str	q0, [sp, #14064]
	ldr	q0, [sp, #4608]                 ; 16-byte Reload
	str	q0, [sp, #14080]
	ldr	q0, [sp, #4656]                 ; 16-byte Reload
	str	q0, [sp, #14096]
	ldr	q0, [sp, #4640]                 ; 16-byte Reload
	str	q0, [sp, #14112]
	ldr	x11, [sp, #168]                 ; 8-byte Reload
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #1776
	ldr	x8, [x8, x11]
	ldr	x9, [sp, #4968]                 ; 8-byte Reload
	sub	x8, x8, x9
	ldr	w10, [sp, #5052]                ; 4-byte Reload
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x13, sp, #5, lsl #12            ; =20480
	add	x13, x13, #3832
	add	x8, x13, x8
	ldp	q6, q5, [x8]
	str	q2, [sp, #14000]
	str	q4, [sp, #14016]
	str	q7, [sp, #14032]
	str	q16, [sp, #14048]
	add	x8, sp, #3, lsl #12             ; =12288
	add	x8, x8, #1712
	ldr	x8, [x8, x11]
	sub	x14, x8, x9
	ldr	q7, [sp, #4528]                 ; 16-byte Reload
	ldr	w22, [sp, #7132]                ; 4-byte Reload
	ldr	x5, [sp, #5040]                 ; 8-byte Reload
	ldr	x4, [sp, #6824]                 ; 8-byte Reload
	ldp	q20, q17, [sp, #416]            ; 32-byte Folded Reload
	ldp	q22, q21, [sp, #384]            ; 32-byte Folded Reload
	ldr	q9, [sp, #368]                  ; 16-byte Reload
	ldr	x11, [sp, #160]                 ; 8-byte Reload
	ldr	q11, [sp, #2240]                ; 16-byte Reload
	ldr	q29, [sp, #2128]                ; 16-byte Reload
	add	x13, sp, #3, lsl #12            ; =12288
	add	x13, x13, #1648
	add	x15, sp, #5, lsl #12            ; =20480
	add	x15, x15, #3736
	ldr	w24, [sp, #7836]                ; 4-byte Reload
	b	LBB0_315
LBB0_314:                               ; %else893
                                        ;   in Loop: Header=BB0_315 Depth=2
	ldr	q8, [sp, #7504]                 ; 16-byte Reload
	ldr	q23, [sp, #11280]               ; 16-byte Reload
	movi	d1, #0x0000000000ffff
	bit.8b	v8, v1, v23
	ldr	q1, [sp, #7456]                 ; 16-byte Reload
	ldr	q4, [sp, #5424]                 ; 16-byte Reload
	bit.16b	v1, v6, v4
	ldr	q4, [sp, #7488]                 ; 16-byte Reload
	bit.16b	v4, v5, v17
	and.16b	v24, v20, v4
	and.16b	v28, v21, v1
	str	q8, [sp, #7504]                 ; 16-byte Spill
	bic.8b	v1, v23, v8
	ldr	q4, [sp, #7424]                 ; 16-byte Reload
	bif.16b	v0, v4, v22
	ldr	q4, [sp, #7440]                 ; 16-byte Reload
	bif.16b	v2, v4, v9
	zip2.8b	v4, v1, v0
	ushll.4s	v4, v4, #0
	shl.4s	v4, v4, #31
	cmge.4s	v4, v4, #0
	and.16b	v2, v4, v2
	zip1.8b	v1, v1, v0
	ushll.4s	v1, v1, #0
	shl.4s	v1, v1, #31
	cmge.4s	v1, v1, #0
	and.16b	v0, v1, v0
	str	q28, [sp, #7456]                ; 16-byte Spill
	str	q0, [sp, #7424]                 ; 16-byte Spill
	fadd.4s	v0, v28, v0
	str	q24, [sp, #7488]                ; 16-byte Spill
	str	q2, [sp, #7440]                 ; 16-byte Spill
	fadd.4s	v1, v24, v2
	ldr	q8, [sp, #7712]                 ; 16-byte Reload
	str	q8, [sp, #13936]
	ldr	q24, [sp, #7696]                ; 16-byte Reload
	str	q24, [sp, #13952]
	str	q27, [sp, #13968]
	str	q18, [sp, #13984]
	ldr	x8, [x13, x11, lsl #3]
	add	x8, x14, x8, lsl #5
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x15, x8
	ldp	q2, q4, [x8]
	bif.16b	v1, v4, v9
	bif.16b	v0, v2, v22
	stp	q0, q1, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v24, v24, v0
	str	q24, [sp, #7696]                ; 16-byte Spill
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v27, v27, v0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v18, v18, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v8, v8, v0
	str	q8, [sp, #7712]                 ; 16-byte Spill
	fmov	x8, d8
	cmp	x8, #1
	b.ge	LBB0_297
LBB0_315:                               ; %direct.true862
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	sshll.2d	v0, v30, #0
	ldr	q2, [sp, #7472]                 ; 16-byte Reload
	bit.16b	v2, v7, v0
	ldr	d0, [sp, #7664]                 ; 8-byte Reload
	cmlt.8b	v0, v0, #0
	ldr	d1, [sp, #11400]                ; 8-byte Reload
	and.8b	v0, v0, v1
	addv.8b	b0, v0
	fmov	w8, s0
	str	q2, [sp, #7472]                 ; 16-byte Spill
	shl.2d	v0, v2, #5
	ldr	q1, [sp, #5536]                 ; 16-byte Reload
	orr.16b	v0, v0, v1
	add.2d	v1, v25, v0
	movi.2d	v0, #0000000000000000
	movi.2d	v2, #0000000000000000
	tbz	w8, #0, LBB0_317
; %bb.316:                              ; %cond.load847
                                        ;   in Loop: Header=BB0_315 Depth=2
	fmov	x9, d1
	ldr	s0, [x9]
LBB0_317:                               ; %else851
                                        ;   in Loop: Header=BB0_315 Depth=2
	tbz	w8, #1, LBB0_319
; %bb.318:                              ; %cond.load853
                                        ;   in Loop: Header=BB0_315 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v0 }[1], [x9]
LBB0_319:                               ; %else857
                                        ;   in Loop: Header=BB0_315 Depth=2
	ldr	q1, [sp, #11344]                ; 16-byte Reload
	bic.16b	v1, v11, v1
	ssubw2.2d	v11, v1, v30
	shl.2d	v1, v11, #5
	ldr	q4, [sp, #5520]                 ; 16-byte Reload
	orr.16b	v1, v1, v4
	ldr	q4, [sp, #5568]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	tbz	w8, #2, LBB0_321
; %bb.320:                              ; %cond.load859
                                        ;   in Loop: Header=BB0_315 Depth=2
	fmov	x9, d1
	ld1.s	{ v0 }[2], [x9]
LBB0_321:                               ; %else863
                                        ;   in Loop: Header=BB0_315 Depth=2
	tbz	w8, #3, LBB0_323
; %bb.322:                              ; %cond.load865
                                        ;   in Loop: Header=BB0_315 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v0 }[3], [x9]
LBB0_323:                               ; %else869
                                        ;   in Loop: Header=BB0_315 Depth=2
	sshll.2d	v1, v31, #0
	ldr	q4, [sp, #7536]                 ; 16-byte Reload
	bic.16b	v1, v4, v1
	ssubw.2d	v1, v1, v31
	str	q1, [sp, #7536]                 ; 16-byte Spill
	shl.2d	v1, v1, #5
	ldr	q4, [sp, #5504]                 ; 16-byte Reload
	orr.16b	v1, v1, v4
	add.2d	v1, v15, v1
	tbz	w8, #4, LBB0_325
; %bb.324:                              ; %cond.load871
                                        ;   in Loop: Header=BB0_315 Depth=2
	fmov	x9, d1
	ld1.s	{ v2 }[0], [x9]
LBB0_325:                               ; %else875
                                        ;   in Loop: Header=BB0_315 Depth=2
	tbz	w8, #5, LBB0_327
; %bb.326:                              ; %cond.load877
                                        ;   in Loop: Header=BB0_315 Depth=2
	mov.d	x9, v1[1]
	ld1.s	{ v2 }[1], [x9]
LBB0_327:                               ; %else881
                                        ;   in Loop: Header=BB0_315 Depth=2
	ldr	q1, [sp, #7520]                 ; 16-byte Reload
	ldr	q4, [sp, #11328]                ; 16-byte Reload
	bic.16b	v1, v1, v4
	ssubw2.2d	v1, v1, v31
	str	q1, [sp, #7520]                 ; 16-byte Spill
	shl.2d	v1, v1, #5
	orr.16b	v1, v1, v26
	ldr	q4, [sp, #5552]                 ; 16-byte Reload
	add.2d	v1, v4, v1
	tbz	w8, #6, LBB0_329
; %bb.328:                              ; %cond.load883
                                        ;   in Loop: Header=BB0_315 Depth=2
	fmov	x9, d1
	ld1.s	{ v2 }[2], [x9]
LBB0_329:                               ; %else887
                                        ;   in Loop: Header=BB0_315 Depth=2
	tbz	w8, #7, LBB0_314
; %bb.330:                              ; %cond.load889
                                        ;   in Loop: Header=BB0_315 Depth=2
	mov.d	x8, v1[1]
	ld1.s	{ v2 }[3], [x8]
	b	LBB0_314
LBB0_331:                               ; %direct.true970.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q20, [sp, #11424]               ; 16-byte Reload
	ldp	q8, q3, [sp, #336]              ; 32-byte Folded Reload
	ldr	q12, [sp, #4576]                ; 16-byte Reload
	ldr	q26, [sp, #4560]                ; 16-byte Reload
	ldr	q28, [sp, #4544]                ; 16-byte Reload
	ldr	q22, [sp, #1856]                ; 16-byte Reload
	ldr	q23, [sp, #1808]                ; 16-byte Reload
	add	x16, sp, #3, lsl #12            ; =12288
	add	x16, x16, #144
	ldr	q27, [sp, #11440]               ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q29, [sp, #11360]               ; 16-byte Reload
	ldr	q18, [sp, #4592]                ; 16-byte Reload
	ldr	q16, [sp, #10736]               ; 16-byte Reload
LBB0_332:                               ; %direct.true970
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v0, v25, #5
	shl.2d	v1, v19, #5
	shl.2d	v2, v13, #5
	shl.2d	v4, v14, #5
	orr.16b	v5, v4, v28
	orr.16b	v6, v2, v26
	orr.16b	v7, v1, v12
	orr.16b	v17, v0, v18
	str	q17, [sp, #12432]
	str	q7, [sp, #12448]
	str	q6, [sp, #12464]
	str	q5, [sp, #12480]
	ldr	x8, [x16, x13]
	sub	x8, x8, x11
	orr.16b	v4, v4, v21
	orr.16b	v2, v2, v16
	ldr	q5, [sp, #11072]                ; 16-byte Reload
	orr.16b	v1, v1, v5
	ldr	q5, [sp, #11088]                ; 16-byte Reload
	orr.16b	v0, v0, v5
	str	q0, [sp, #12368]
	str	q1, [sp, #12384]
	str	q2, [sp, #12400]
	str	q4, [sp, #12416]
	ldr	x9, [x0, x13]
	sub	x9, x9, x11
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x1, x8
	ldp	q0, q1, [x8]
	bif.16b	v1, v23, v3
	bif.16b	v0, v22, v11
	and.16b	v22, v15, v0
	and.16b	v23, v8, v1
	csel	x8, xzr, x9, eq
	add	x8, x5, x8
	ldp	q0, q1, [x8]
	bit.16b	v1, v23, v3
	bit.16b	v0, v22, v11
	stp	q0, q1, [x8]
	add.2d	v19, v19, v29
	add.2d	v13, v13, v27
	add.2d	v14, v14, v9
	add.2d	v25, v25, v20
	fmov	x8, d25
	cmp	x8, #1
	b.lt	LBB0_332
LBB0_333:                               ; %direct.false971
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q22, [sp, #1856]                ; 16-byte Spill
	str	q23, [sp, #1808]                ; 16-byte Spill
	str	q19, [sp, #1824]                ; 16-byte Spill
	str	q25, [sp, #1840]                ; 16-byte Spill
	str	q14, [sp, #1984]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q14, [sp, #1872]                ; 16-byte Reload
	bic.16b	v14, v14, v24
	ldr	q22, [sp, #1776]                ; 16-byte Reload
	ldr	q3, [sp, #11344]                ; 16-byte Reload
	bic.16b	v22, v22, v3
	ldr	q12, [sp, #1888]                ; 16-byte Reload
	bic.16b	v12, v12, v1
	ldr	q23, [sp, #1792]                ; 16-byte Reload
	bic.16b	v23, v23, v0
	fmov	x8, d23
	cmp	x8, #1
	ldr	w7, [sp, #5372]                 ; 4-byte Reload
	ldr	w21, [sp, #5368]                ; 4-byte Reload
	ldr	w20, [sp, #7836]                ; 4-byte Reload
	ldr	w0, [sp, #5324]                 ; 4-byte Reload
	b.gt	LBB0_336
; %bb.334:                              ; %direct.true986.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q20, [sp, #11424]               ; 16-byte Reload
	ldr	x11, [sp, #1296]                ; 8-byte Reload
	ldp	q8, q24, [sp, #832]             ; 32-byte Folded Reload
	ldp	q15, q11, [sp, #800]            ; 32-byte Folded Reload
	ldr	x13, [sp, #984]                 ; 8-byte Reload
	ldr	q26, [sp, #7232]                ; 16-byte Reload
	ldr	q28, [sp, #7216]                ; 16-byte Reload
	ldr	q25, [sp, #1424]                ; 16-byte Reload
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	ldr	q10, [sp, #1760]                ; 16-byte Reload
	ldr	x16, [sp, #696]                 ; 8-byte Reload
	ldr	q27, [sp, #11440]               ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q18, [sp, #7248]                ; 16-byte Reload
	ldr	q16, [sp, #7200]                ; 16-byte Reload
	ldr	q19, [sp, #10736]               ; 16-byte Reload
LBB0_335:                               ; %direct.true986
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	shl.2d	v0, v23, #5
	shl.2d	v1, v22, #5
	shl.2d	v2, v12, #5
	shl.2d	v4, v14, #5
	orr.16b	v5, v4, v28
	orr.16b	v6, v2, v26
	orr.16b	v7, v1, v18
	orr.16b	v17, v0, v16
	str	q17, [sp, #12304]
	str	q7, [sp, #12320]
	str	q6, [sp, #12336]
	str	q5, [sp, #12352]
	ldr	x8, [x6, x16]
	sub	x8, x8, x4
	orr.16b	v4, v4, v21
	orr.16b	v2, v2, v19
	ldr	q5, [sp, #11072]                ; 16-byte Reload
	orr.16b	v1, v1, v5
	ldr	q5, [sp, #11088]                ; 16-byte Reload
	orr.16b	v0, v0, v5
	str	q0, [sp, #12240]
	str	q1, [sp, #12256]
	str	q2, [sp, #12272]
	str	q4, [sp, #12288]
	ldr	x9, [x23, x16]
	sub	x9, x9, x4
	tst	w22, #0xff
	csel	x8, xzr, x8, eq
	add	x8, x15, x8
	ldp	q0, q1, [x8]
	bif.16b	v1, v10, v24
	bif.16b	v0, v3, v8
	and.16b	v3, v11, v0
	and.16b	v10, v15, v1
	csel	x8, xzr, x9, eq
	add	x8, x24, x8
	ldp	q0, q1, [x8]
	bit.16b	v1, v10, v24
	bit.16b	v0, v3, v8
	stp	q0, q1, [x8]
	add.2d	v22, v22, v29
	add.2d	v12, v12, v27
	add.2d	v14, v14, v9
	add.2d	v23, v23, v20
	fmov	x8, d23
	cmp	x8, #2
	b.lt	LBB0_335
	b	LBB0_337
LBB0_336:                               ;   in Loop: Header=BB0_28 Depth=1
	ldr	x11, [sp, #1296]                ; 8-byte Reload
	ldr	x13, [sp, #984]                 ; 8-byte Reload
	ldr	q25, [sp, #1424]                ; 16-byte Reload
	ldr	q3, [sp, #1408]                 ; 16-byte Reload
	ldr	q10, [sp, #1760]                ; 16-byte Reload
LBB0_337:                               ; %direct.false987
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q10, [sp, #1760]                ; 16-byte Spill
	str	q22, [sp, #1776]                ; 16-byte Spill
	str	q23, [sp, #1792]                ; 16-byte Spill
	str	q14, [sp, #1872]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q7, [sp, #11328]                ; 16-byte Reload
	bic.16b	v25, v25, v7
	ldr	q26, [sp, #1696]                ; 16-byte Reload
	ldr	q2, [sp, #11344]                ; 16-byte Reload
	bic.16b	v26, v26, v2
	ldr	q19, [sp, #1440]                ; 16-byte Reload
	bic.16b	v19, v19, v1
	ldr	q24, [sp, #1712]                ; 16-byte Reload
	bic.16b	v24, v24, v0
	fmov	x8, d24
	cmp	x8, #1
	b.lt	LBB0_339
; %bb.338:                              ;   in Loop: Header=BB0_28 Depth=1
	ldr	q17, [sp, #11296]               ; 16-byte Reload
	ldp	q15, q11, [sp, #944]            ; 32-byte Folded Reload
	ldr	q16, [sp, #5392]                ; 16-byte Reload
	ldr	q18, [sp, #5376]                ; 16-byte Reload
	ldr	q22, [sp, #1392]                ; 16-byte Reload
	ldr	q5, [sp, #1744]                 ; 16-byte Reload
	ldr	q23, [sp, #1728]                ; 16-byte Reload
	ldr	q28, [sp, #1680]                ; 16-byte Reload
	ldr	q6, [sp, #1632]                 ; 16-byte Reload
	b	LBB0_341
LBB0_339:                               ; %direct.true1002.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #11424]                ; 16-byte Reload
	ldr	q17, [sp, #11296]               ; 16-byte Reload
	ldp	q21, q20, [sp, #304]            ; 32-byte Folded Reload
	ldp	q8, q4, [sp, #272]              ; 32-byte Folded Reload
	ldp	q15, q11, [sp, #944]            ; 32-byte Folded Reload
	ldr	q16, [sp, #5392]                ; 16-byte Reload
	ldr	q18, [sp, #5376]                ; 16-byte Reload
	ldr	q22, [sp, #1392]                ; 16-byte Reload
	ldr	q5, [sp, #1744]                 ; 16-byte Reload
	ldr	q23, [sp, #1728]                ; 16-byte Reload
	ldr	q28, [sp, #1680]                ; 16-byte Reload
	ldr	q6, [sp, #1632]                 ; 16-byte Reload
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #3984
	ldr	q27, [sp, #11440]               ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q10, [sp, #11360]               ; 16-byte Reload
LBB0_340:                               ; %direct.true1002
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	q24, [sp, #12176]
	str	q26, [sp, #12192]
	str	q19, [sp, #12208]
	str	q25, [sp, #12224]
	ldr	x8, [x15, x13, lsl #3]
	add	x8, x11, x8, lsl #5
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x9, x17, x8
	ldp	q0, q1, [x9]
	bif.16b	v1, v28, v20
	bif.16b	v0, v23, v21
	and.16b	v23, v4, v0
	and.16b	v28, v8, v1
	add	x8, x14, x8
	ldp	q0, q1, [x8]
	bit.16b	v1, v28, v20
	bit.16b	v0, v23, v21
	stp	q0, q1, [x8]
	add.2d	v26, v26, v10
	add.2d	v19, v19, v27
	add.2d	v25, v25, v9
	add.2d	v24, v24, v2
	fmov	x8, d24
	cmp	x8, #1
	b.lt	LBB0_340
LBB0_341:                               ; %direct.false1003
                                        ;   in Loop: Header=BB0_28 Depth=1
	str	q23, [sp, #1728]                ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	bic.16b	v5, v5, v7
	ldr	q2, [sp, #11344]                ; 16-byte Reload
	bic.16b	v6, v6, v2
	bic.16b	v22, v22, v1
	ldr	q7, [sp, #1648]                 ; 16-byte Reload
	bic.16b	v7, v7, v0
	fmov	x8, d7
	cmp	x8, #1
	b.lt	LBB0_343
; %bb.342:                              ;   in Loop: Header=BB0_28 Depth=1
	mov.16b	v23, v3
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	ldr	q14, [sp, #1376]                ; 16-byte Reload
	ldr	q29, [sp, #7408]                ; 16-byte Reload
	b	LBB0_345
LBB0_343:                               ; %direct.true1018.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #11424]                ; 16-byte Reload
	ldr	x13, [sp, #152]                 ; 8-byte Reload
	ldp	q8, q4, [sp, #112]              ; 32-byte Folded Reload
	mov.16b	v23, v3
	ldr	q3, [sp, #1664]                 ; 16-byte Reload
	ldr	q14, [sp, #1376]                ; 16-byte Reload
	add	x14, sp, #10, lsl #12           ; =40960
	add	x14, x14, #1664
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #3920
	ldr	q27, [sp, #11440]               ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q29, [sp, #7408]                ; 16-byte Reload
	ldr	q10, [sp, #11360]               ; 16-byte Reload
LBB0_344:                               ; %direct.true1018
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	q7, [sp, #12112]
	str	q6, [sp, #12128]
	str	q22, [sp, #12144]
	str	q5, [sp, #12160]
	ldr	x8, [x15, x13, lsl #3]
	add	x8, x11, x8, lsl #5
	tst	w10, #0xff
	csel	x8, xzr, x8, eq
	add	x9, x5, x8
	ldp	q0, q1, [x9]
	bif.16b	v1, v14, v4
	bif.16b	v0, v3, v11
	and.16b	v3, v15, v0
	and.16b	v14, v8, v1
	add	x8, x14, x8
	ldp	q0, q1, [x8]
	bit.16b	v1, v14, v4
	bit.16b	v0, v3, v11
	stp	q0, q1, [x8]
	add.2d	v6, v6, v10
	add.2d	v22, v22, v27
	add.2d	v5, v5, v9
	add.2d	v7, v7, v2
	fmov	x8, d7
	cmp	x8, #1
	b.lt	LBB0_344
LBB0_345:                               ; %direct.false1019
                                        ;   in Loop: Header=BB0_28 Depth=1
	mov.16b	v4, v14
	str	q6, [sp, #1632]                 ; 16-byte Spill
	str	q7, [sp, #1648]                 ; 16-byte Spill
	str	q3, [sp, #1664]                 ; 16-byte Spill
	sshll.2d	v0, v30, #0
	sshll.2d	v1, v31, #0
	ldr	q2, [sp, #5136]                 ; 16-byte Reload
	ldr	q3, [sp, #11328]                ; 16-byte Reload
	bic.16b	v2, v2, v3
	str	q2, [sp, #5136]                 ; 16-byte Spill
	ldr	q7, [sp, #1344]                 ; 16-byte Reload
	ldr	q2, [sp, #11344]                ; 16-byte Reload
	bic.16b	v7, v7, v2
	ldr	q2, [sp, #5152]                 ; 16-byte Reload
	bic.16b	v2, v2, v1
	str	q2, [sp, #5152]                 ; 16-byte Spill
	ldr	q1, [sp, #1536]                 ; 16-byte Reload
	bic.16b	v1, v1, v0
	mov.16b	v0, v1
	fmov	x8, d1
	cmp	x8, #1
	str	q13, [sp, #2000]                ; 16-byte Spill
	str	q12, [sp, #1888]                ; 16-byte Spill
	str	q5, [sp, #1744]                 ; 16-byte Spill
	str	q24, [sp, #1712]                ; 16-byte Spill
	str	q26, [sp, #1696]                ; 16-byte Spill
	str	q28, [sp, #1680]                ; 16-byte Spill
	b.gt	LBB0_26
; %bb.346:                              ; %direct.true1034.preheader
                                        ;   in Loop: Header=BB0_28 Depth=1
	ldr	q2, [sp, #11424]                ; 16-byte Reload
	ldp	q11, q8, [sp, #768]             ; 32-byte Folded Reload
	ldp	q3, q15, [sp, #736]             ; 32-byte Folded Reload
	ldr	q5, [sp, #5152]                 ; 16-byte Reload
	ldr	q24, [sp, #5136]                ; 16-byte Reload
	ldr	q6, [sp, #1360]                 ; 16-byte Reload
	ldr	q26, [sp, #1616]                ; 16-byte Reload
	add	x11, sp, #10, lsl #12           ; =40960
	add	x11, x11, #1568
	mov.16b	v28, v0
	ldr	x14, [sp, #688]                 ; 8-byte Reload
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #3856
	ldr	q27, [sp, #11440]               ; 16-byte Reload
	ldr	q9, [sp, #11408]                ; 16-byte Reload
	ldr	q14, [sp, #11360]               ; 16-byte Reload
LBB0_347:                               ; %direct.true1034
                                        ;   Parent Loop BB0_28 Depth=1
                                        ; =>  This Inner Loop Header: Depth=2
	str	q28, [sp, #12048]
	str	q7, [sp, #12064]
	str	q5, [sp, #12080]
	str	q24, [sp, #12096]
	ldr	x8, [x15, x14, lsl #3]
	add	x8, x2, x8, lsl #5
	tst	w22, #0xff
	csel	x8, xzr, x8, eq
	add	x9, x24, x8
	ldp	q0, q1, [x9]
	bif.16b	v1, v26, v8
	bif.16b	v0, v6, v11
	and.16b	v6, v15, v0
	and.16b	v26, v3, v1
	add	x8, x11, x8
	ldp	q0, q1, [x8]
	bit.16b	v1, v26, v8
	bit.16b	v0, v6, v11
	stp	q0, q1, [x8]
	add.2d	v7, v7, v14
	add.2d	v5, v5, v27
	add.2d	v24, v24, v9
	add.2d	v28, v28, v2
	fmov	x8, d28
	cmp	x8, #2
	b.lt	LBB0_347
	b	LBB0_27
LBB0_348:                               ; %direct.true1051.preheader
	movi.2d	v2, #0000000000000000
	sshll.2d	v3, v30, #0
	sshll.2d	v4, v31, #0
	ldr	q0, [sp, #10544]                ; 16-byte Reload
	fmov	x8, d0
	str	x8, [sp, #11312]                ; 8-byte Spill
	ldr	q0, [sp, #10560]                ; 16-byte Reload
	fmov	x8, d0
	str	x8, [sp, #11296]                ; 8-byte Spill
	ldr	q0, [sp, #10528]                ; 16-byte Reload
	fmov	x1, d0
	ldr	q0, [sp, #10592]                ; 16-byte Reload
	fmov	x16, d0
	ldr	x8, [sp, #80]                   ; 8-byte Reload
	ubfiz	x17, x8, #3, #3
	movi.2d	v5, #0000000000000000
	ldr	q0, [sp, #11040]                ; 16-byte Reload
	mov.d	x4, v0[1]
	fmov	x5, d0
	ldr	q0, [sp, #11056]                ; 16-byte Reload
	mov.d	x6, v0[1]
	fmov	x23, d0
	ldr	q0, [sp, #11152]                ; 16-byte Reload
	mov.d	x24, v0[1]
	fmov	x25, d0
	ldr	q0, [sp, #11168]                ; 16-byte Reload
	mov.d	x26, v0[1]
	fmov	x27, d0
	ldr	q1, [sp, #6672]                 ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v6, v0, #0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v7, v0, #0
	ldr	q1, [sp, #64]                   ; 16-byte Reload
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #11168]                ; 16-byte Spill
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v0, v0, #0
	str	q0, [sp, #11152]                ; 16-byte Spill
	movi.2d	v21, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	ldr	q15, [sp, #11328]               ; 16-byte Reload
	ldr	q16, [sp, #10656]               ; 16-byte Reload
	ldr	q17, [sp, #11072]               ; 16-byte Reload
	ldr	q14, [sp, #11280]               ; 16-byte Reload
	ldr	w2, [sp, #10316]                ; 4-byte Reload
	mov	x22, x20
	ldr	w20, [sp, #10092]               ; 4-byte Reload
	ldr	w19, [sp, #7356]                ; 4-byte Reload
	ldr	q10, [sp, #11344]               ; 16-byte Reload
LBB0_349:                               ; %direct.true1051
                                        ; =>This Inner Loop Header: Depth=1
	and.16b	v1, v15, v25
	and.16b	v29, v10, v23
	and.16b	v8, v4, v24
	and.16b	v0, v3, v2
	mov.d	x8, v0[1]
	fmov	x9, d0
	ldr	x11, [sp, #11312]               ; 8-byte Reload
	sdiv	x10, x9, x11
	msub	x9, x10, x11, x9
	sdiv	x10, x8, x12
	msub	x8, x10, x12, x8
	mov.d	x10, v8[1]
	fmov	d0, x9
	fmov	x9, d8
	ldr	x13, [sp, #11296]               ; 8-byte Reload
	sdiv	x11, x9, x13
	msub	x9, x11, x13, x9
	sdiv	x11, x10, x30
	msub	x10, x11, x30, x10
	fmov	d8, x9
	mov.d	x9, v29[1]
	fmov	x11, d29
	sdiv	x13, x11, x1
	mov.d	v0[1], x8
	msub	x8, x13, x1, x11
	fmov	d29, x8
	ldr	x11, [sp, #10432]               ; 8-byte Reload
	sdiv	x8, x9, x11
	msub	x8, x8, x11, x9
	mov.d	v8[1], x10
	mov.d	x9, v1[1]
	fmov	x10, d1
	sdiv	x11, x10, x16
	mov.d	v29[1], x8
	msub	x8, x11, x16, x10
	fmov	d1, x8
	sdiv	x8, x9, x28
	msub	x8, x8, x28, x9
	mov.d	v1[1], x8
	str	q29, [sp, #12000]
	str	q1, [sp, #12032]
	str	q8, [sp, #12016]
	and.16b	v1, v15, v1
	and.16b	v29, v10, v29
	and.16b	v9, v4, v8
	and.16b	v10, v3, v0
	mov.d	x8, v10[1]
	fmov	x9, d10
	sdiv	x13, x9, x5
	mov.d	x9, v9[1]
	fmov	x10, d9
	mov.d	x11, v29[1]
	sdiv	x28, x8, x4
	fmov	x8, d29
	sdiv	x30, x8, x25
	mov.d	x3, v1[1]
	fmov	x14, d1
	sdiv	x8, x11, x24
	mul	x11, x13, x5
	fmov	d11, x11
	mul	x11, x28, x4
	mov.d	v11[1], x11
	mul	x11, x30, x25
	fmov	d12, x11
	mul	x11, x8, x24
	mov.d	v12[1], x11
	sdiv	x10, x10, x23
	mul	x11, x10, x23
	fmov	d13, x11
	sdiv	x9, x9, x6
	mul	x11, x9, x6
	sdiv	x14, x14, x27
	mov.d	v13[1], x11
	mul	x11, x14, x27
	fmov	d8, x11
	sdiv	x11, x3, x26
	mul	x3, x11, x26
	mov.d	v8[1], x3
	sub.2d	v8, v1, v8
	sub.2d	v1, v9, v13
	sub.2d	v29, v29, v12
	sub.2d	v9, v10, v11
	ldr	q10, [sp, #11248]               ; 16-byte Reload
	cmeq.2d	v10, v10, v8
	ldr	q11, [sp, #11232]               ; 16-byte Reload
	cmeq.2d	v11, v11, v1
	uzp1.4s	v10, v11, v10
	ldr	q11, [sp, #11200]               ; 16-byte Reload
	cmeq.2d	v11, v11, v29
	ldr	q12, [sp, #11264]               ; 16-byte Reload
	cmeq.2d	v12, v12, v9
	uzp1.4s	v11, v12, v11
	uzp1.8h	v12, v11, v10
	str	q0, [sp, #11984]
	ldr	q0, [sp, #11376]                ; 16-byte Reload
	and.16b	v0, v0, v12
	xtn.8b	v0, v0
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d12, [sp, #11400]               ; 8-byte Reload
	and.8b	v12, v0, v12
	addv.8b	b12, v12
	fmov	w15, s12
	fmov	d12, x10
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3792
	ldr	x3, [x10, x17]
	mov.d	v12[1], x9
	umaxv.8b	b0, v0
	fmov	w9, s0
	fmov	d0, x14
	mov.d	v0[1], x11
	rbit	w10, w15
	clz	w10, w10
	tst	w9, #0x1
	ldr	q13, [sp, #11088]               ; 16-byte Reload
	str	q13, [sp, #11792]
	str	q17, [sp, #11808]
	ldr	q13, [sp, #10736]               ; 16-byte Reload
	str	q13, [sp, #11824]
	csel	w9, w10, wzr, ne
	str	q16, [sp, #11840]
	ubfiz	x10, x9, #3, #3
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #3600
	ldr	x11, [x11, x10]
	str	q0, [sp, #11904]
	fmov	d0, x13
	mov.d	v0[1], x28
	ldr	x28, [sp, #9896]                ; 8-byte Reload
	str	q12, [sp, #11888]
	fmov	d12, x30
	ldr	x30, [sp, #9888]                ; 8-byte Reload
	mov.d	v12[1], x8
	lsl	w8, w9, #2
	sub	x8, x11, x8
	str	q12, [sp, #11872]
	str	q0, [sp, #11856]
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #3664
	ldr	x9, [x9, x10]
	and.16b	v0, v31, v10
	add	x8, x8, x9, lsl #5
	tst	w15, #0xff
	csel	x8, xzr, x8, eq
	add	x9, sp, #10, lsl #12            ; =40960
	add	x9, x9, #1664
	add	x8, x9, x8
	ldr	q12, [x8, #16]
	bsl.16b	v0, v12, v28
	bit.16b	v18, v9, v3
	ldr	q28, [x8]
	ldr	q9, [sp, #11344]                ; 16-byte Reload
	bit.16b	v19, v29, v9
	and.16b	v29, v30, v11
	bit.16b	v20, v1, v4
	bic.16b	v1, v31, v10
	bic.16b	v9, v30, v11
	bit.16b	v21, v28, v29
	xtn.2s	v11, v20
	xtn.2s	v28, v18
	bic.16b	v21, v21, v9
	mov.s	w8, v28[1]
	fmov	w9, s28
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	bic.16b	v28, v0, v1
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3336
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	str	d14, [sp, #11528]
	ldrb	w10, [x10]
	str	q28, [sp, #11776]
	str	q21, [sp, #11760]
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #3568
	ldr	s0, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w0, w10
	xtn.2s	v1, v19
	tst	w9, w10
	fcsel	s29, s0, s5, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #3336
	cset	w10, lo
	bfxil	x9, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w9, [x9]
	str	q28, [sp, #11744]
	str	q21, [sp, #11728]
	ldr	w11, [sp, #10420]               ; 4-byte Reload
	and	w9, w11, w9
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #3536
	ldr	s0, [x11, x8, lsl #2]
	tst	w10, w9
	mov.s	w8, v1[1]
	fcsel	s9, s0, s5, ne
	fmov	w9, s1
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3336
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q28, [sp, #11712]
	str	q21, [sp, #11696]
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #3504
	ldr	s0, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w2, w10
	tst	w9, w10
	fcsel	s10, s0, s5, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3336
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	str	q28, [sp, #11680]
	and	w10, w7, w10
	str	q21, [sp, #11664]
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #3472
	ldr	s0, [x11, x8, lsl #2]
	mov.s	w8, v11[1]
	tst	w9, w10
	fcsel	s0, s0, s5, ne
	fmov	w9, s11
	cmp	w9, #8
	csel	w9, w9, wzr, lo
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3336
	bit.16b	v22, v8, v15
	bfxil	x10, x9, #0, #3
	and	x9, x9, #0x7
	ldrb	w10, [x10]
	str	q28, [sp, #11648]
	str	q21, [sp, #11632]
	xtn.2s	v1, v22
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #3440
	ldr	s8, [x11, x9, lsl #2]
	cset	w9, lo
	and	w10, w19, w10
	tst	w9, w10
	fcsel	s8, s8, s5, ne
	cmp	w8, #8
	csel	w8, w8, wzr, lo
	cset	w9, lo
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3336
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	and	w10, w20, w10
	tst	w9, w10
	mov.s	w9, v1[1]
	str	q28, [sp, #11616]
	str	q21, [sp, #11600]
	fmov	w10, s1
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #3408
	ldr	s1, [x11, x8, lsl #2]
	fcsel	s1, s1, s5, ne
	cmp	w10, #8
	csel	w8, w10, wzr, lo
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3336
	bfxil	x10, x8, #0, #3
	and	x8, x8, #0x7
	ldrb	w10, [x10]
	str	q28, [sp, #11584]
	str	q21, [sp, #11568]
	mov.s	v8[1], v1[0]
	add	x11, sp, #2, lsl #12            ; =8192
	add	x11, x11, #3376
	ldr	s1, [x11, x8, lsl #2]
	cset	w8, lo
	and	w10, w21, w10
	tst	w8, w10
	fcsel	s1, s1, s5, ne
	cmp	w9, #8
	csel	w8, w9, wzr, lo
	cset	w9, lo
	add	x10, sp, #2, lsl #12            ; =8192
	add	x10, x10, #3336
	bfxil	x10, x8, #0, #3
	ldrb	w10, [x10]
	and	w10, w22, w10
	tst	w9, w10
	and	x8, x8, #0x7
	str	q28, [sp, #11552]
	str	q21, [sp, #11536]
	mov.s	v8[2], v1[0]
	add	x9, sp, #2, lsl #12             ; =8192
	add	x9, x9, #3344
	ldr	s1, [x9, x8, lsl #2]
	fcsel	s1, s1, s5, ne
	mov.s	v8[3], v1[0]
	mov.s	v29[1], v9[0]
	ldr	x10, [sp, #5040]                ; 8-byte Reload
	add	x8, x10, x3, lsl #5
	ldr	w9, [sp, #7132]                 ; 4-byte Reload
	tst	w9, #0xff
	csel	x8, xzr, x8, eq
	add	x9, sp, #10, lsl #12            ; =40960
	add	x9, x9, #1568
	add	x8, x9, x8
	mov.s	v29[2], v10[0]
	ldr	q10, [sp, #11344]               ; 16-byte Reload
	ldr	q1, [x8]
	bif.16b	v1, v27, v6
	mov.s	v29[3], v0[0]
	ldr	q0, [x8, #16]
	str	q2, [sp, #11920]
	bif.16b	v0, v26, v7
	str	q23, [sp, #11936]
	str	q24, [sp, #11952]
	str	q25, [sp, #11968]
	add	x8, sp, #2, lsl #12             ; =8192
	add	x8, x8, #3728
	ldr	x8, [x8, x17]
	ldr	q26, [sp, #11168]               ; 16-byte Reload
	and.16b	v26, v26, v0
	fdiv.4s	v0, v26, v8
	add	x8, x10, x8, lsl #5
	csel	x8, xzr, x8, eq
	add	x9, sp, #5, lsl #12             ; =20480
	add	x9, x9, #3544
	add	x8, x9, x8
	ldp	q8, q27, [x8]
	bif.16b	v0, v27, v7
	ldr	q27, [sp, #11152]               ; 16-byte Reload
	and.16b	v27, v27, v1
	fdiv.4s	v1, v27, v29
	bif.16b	v1, v8, v6
	stp	q1, q0, [x8]
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v23, v23, v0
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v24, v24, v0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v25, v25, v0
	ldr	q0, [sp, #11424]                ; 16-byte Reload
	add.2d	v2, v2, v0
	fmov	x8, d2
	cmp	x8, #2
	b.lt	LBB0_349
; %bb.350:                              ; %direct.true1078.preheader
	movi.2d	v2, #0000000000000000
	sshll.2d	v3, v31, #0
	sshll.2d	v4, v30, #0
	movi	d5, #0xffffffffffffff
	mov	w8, #6                          ; =0x6
	ldr	x9, [sp, #80]                   ; 8-byte Reload
	and	x14, x9, #0x7
	add	x15, sp, #2, lsl #12            ; =8192
	add	x15, x15, #3264
	add	x16, sp, #5, lsl #12            ; =20480
	add	x16, x16, #3544
	ldr	q1, [sp, #6672]                 ; 16-byte Reload
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v6, v0, #0
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmlt.4s	v7, v0, #0
	ldr	q1, [sp, #64]                   ; 16-byte Reload
	zip2.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v16, v0, #0
	zip1.8b	v0, v1, v0
	ushll.4s	v0, v0, #0
	shl.4s	v0, v0, #31
	cmge.4s	v17, v0, #0
	mov	w17, #3                         ; =0x3
	movi.2d	v31, #0000000000000000
	movi.2d	v21, #0000000000000000
	movi.2d	v18, #0000000000000000
	movi.2d	v19, #0000000000000000
	movi.2d	v20, #0000000000000000
	movi.2d	v22, #0000000000000000
	movi.2d	v23, #0000000000000000
	movi.2d	v24, #0000000000000000
	movi.2d	v25, #0000000000000000
	movi.2d	v26, #0000000000000000
	movi.2d	v27, #0000000000000000
	movi.2d	v28, #0000000000000000
	movi.2d	v29, #0000000000000000
	movi.2d	v30, #0000000000000000
	ldr	q11, [sp, #48]                  ; 16-byte Reload
	ldr	x1, [sp, #40]                   ; 8-byte Reload
	ldr	q9, [sp, #10544]                ; 16-byte Reload
	ldr	x2, [sp, #10432]                ; 8-byte Reload
	ldr	q12, [sp, #16]                  ; 16-byte Reload
	ldr	w3, [sp, #7132]                 ; 4-byte Reload
	ldr	x4, [sp, #5040]                 ; 8-byte Reload
	b	LBB0_352
LBB0_351:                               ; %else927
                                        ;   in Loop: Header=BB0_352 Depth=1
	ldr	q0, [sp, #11360]                ; 16-byte Reload
	add.2d	v28, v28, v0
	ldr	q0, [sp, #11440]                ; 16-byte Reload
	add.2d	v29, v29, v0
	ldr	q0, [sp, #11408]                ; 16-byte Reload
	add.2d	v30, v30, v0
	add.2d	v2, v2, v1
	fmov	x9, d2
	cmp	x9, #2
	b.ge	LBB0_368
LBB0_352:                               ; %direct.true1078
                                        ; =>This Inner Loop Header: Depth=1
	and.16b	v0, v4, v2
	mov.d	x9, v0[1]
	and.16b	v1, v10, v28
	sdiv	x10, x9, x12
	msub	x9, x10, x12, x9
	fmov	x10, d0
	fmov	x11, d9
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	fmov	d0, x10
	mov.d	v0[1], x9
	mov.d	x9, v1[1]
	and.16b	v8, v3, v29
	sdiv	x10, x9, x2
	msub	x9, x10, x2, x9
	fmov	x10, d1
	ldr	q1, [sp, #10528]                ; 16-byte Reload
	fmov	x11, d1
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	mov.d	x9, v8[1]
	and.16b	v9, v15, v30
	sdiv	x10, x9, x30
	msub	x9, x10, x30, x9
	fmov	x10, d8
	ldr	q8, [sp, #10560]                ; 16-byte Reload
	fmov	x11, d8
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	fmov	d8, x10
	mov.d	v8[1], x9
	mov.d	x9, v9[1]
	sdiv	x10, x9, x28
	msub	x9, x10, x28, x9
	fmov	x10, d9
	ldr	q9, [sp, #10592]                ; 16-byte Reload
	fmov	x11, d9
	sdiv	x13, x10, x11
	msub	x10, x13, x11, x10
	fmov	d9, x10
	mov.d	v9[1], x9
	bit.16b	v22, v9, v15
	bit.16b	v20, v8, v3
	bit.16b	v19, v1, v10
	bit.16b	v18, v0, v4
	str	q2, [sp, #11456]
	str	q28, [sp, #11472]
	str	q29, [sp, #11488]
	str	q30, [sp, #11504]
	ldr	x9, [x15, x14, lsl #3]
	add	x9, x4, x9, lsl #5
	tst	w3, #0xff
	csel	x9, xzr, x9, eq
	add	x0, x16, x9
	ldr	q0, [x0]
	bif.16b	v0, v31, v6
	ldr	q1, [sp, #5024]                 ; 16-byte Reload
	add.2d	v1, v18, v1
	ldr	q31, [sp, #5008]                ; 16-byte Reload
	add.2d	v31, v20, v31
	dup.2d	v8, x17
	ldr	q9, [sp, #4976]                 ; 16-byte Reload
	add.2d	v9, v22, v9
	cmhi.2d	v9, v8, v9
	cmhi.2d	v31, v8, v31
	uzp1.4s	v9, v31, v9
	ldr	q31, [sp, #4992]                ; 16-byte Reload
	add.2d	v31, v19, v31
	cmhi.2d	v31, v8, v31
	cmhi.2d	v1, v8, v1
	uzp1.4s	v1, v1, v31
	bit.8b	v27, v5, v14
	ldr	q31, [sp, #4528]                ; 16-byte Reload
	bit.16b	v23, v31, v4
	and.16b	v31, v17, v0
	uzp1.8h	v0, v1, v9
	ldr	q1, [sp, #4448]                 ; 16-byte Reload
	add.2d	v1, v18, v1
	xtn.8b	v0, v0
	mov.d	x9, v1[1]
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d1
	lsl	x11, x10, #3
	sub	x10, x11, x10
	and.8b	v1, v14, v27
	and.8b	v0, v1, v0
	fmov	d1, x10
	mov.d	v1[1], x9
	add.2d	v1, v1, v23
	shl.8b	v0, v0, #7
	cmlt.8b	v0, v0, #0
	ldr	d8, [sp, #11400]                ; 8-byte Reload
	and.8b	v0, v0, v8
	addv.8b	b0, v0
	fmov	w13, s0
	shl.2d	v1, v1, #2
	dup.2d	v0, x1
	add.2d	v8, v0, v1
	tbz	w13, #0, LBB0_354
; %bb.353:                              ; %cond.store896
                                        ;   in Loop: Header=BB0_352 Depth=1
	fmov	x9, d8
	str	s31, [x9]
LBB0_354:                               ; %else899
                                        ;   in Loop: Header=BB0_352 Depth=1
	ldr	q1, [x0, #16]
	tbz	w13, #1, LBB0_356
; %bb.355:                              ; %cond.store900
                                        ;   in Loop: Header=BB0_352 Depth=1
	mov.d	x9, v8[1]
	st1.s	{ v31 }[1], [x9]
LBB0_356:                               ; %else903
                                        ;   in Loop: Header=BB0_352 Depth=1
	ldr	q8, [sp, #4480]                 ; 16-byte Reload
	add.2d	v8, v19, v8
	mov.d	x9, v8[1]
	bit.16b	v24, v12, v10
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d8
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d8, x10
	mov.d	v8[1], x9
	add.2d	v8, v8, v24
	shl.2d	v8, v8, #2
	add.2d	v8, v0, v8
	ldr	q9, [sp, #10544]                ; 16-byte Reload
	tbz	w13, #2, LBB0_358
; %bb.357:                              ; %cond.store904
                                        ;   in Loop: Header=BB0_352 Depth=1
	fmov	x9, d8
	st1.s	{ v31 }[2], [x9]
LBB0_358:                               ; %else907
                                        ;   in Loop: Header=BB0_352 Depth=1
	tbz	w13, #3, LBB0_360
; %bb.359:                              ; %cond.store908
                                        ;   in Loop: Header=BB0_352 Depth=1
	mov.d	x9, v8[1]
	st1.s	{ v31 }[3], [x9]
LBB0_360:                               ; %else911
                                        ;   in Loop: Header=BB0_352 Depth=1
	bit.16b	v25, v11, v3
	bif.16b	v1, v21, v7
	ldr	q21, [sp, #4464]                ; 16-byte Reload
	add.2d	v8, v20, v21
	mov.d	x9, v8[1]
	and.16b	v21, v16, v1
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d8
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	add.2d	v1, v1, v25
	shl.2d	v1, v1, #2
	add.2d	v1, v0, v1
	tbz	w13, #4, LBB0_362
; %bb.361:                              ; %cond.store912
                                        ;   in Loop: Header=BB0_352 Depth=1
	fmov	x9, d1
	str	s21, [x9]
LBB0_362:                               ; %else915
                                        ;   in Loop: Header=BB0_352 Depth=1
	tbz	w13, #5, LBB0_364
; %bb.363:                              ; %cond.store916
                                        ;   in Loop: Header=BB0_352 Depth=1
	mov.d	x9, v1[1]
	st1.s	{ v21 }[1], [x9]
LBB0_364:                               ; %else919
                                        ;   in Loop: Header=BB0_352 Depth=1
	dup.2d	v1, x8
	ldr	q8, [sp, #4496]                 ; 16-byte Reload
	add.2d	v8, v22, v8
	mov.d	x9, v8[1]
	bit.16b	v26, v1, v15
	lsl	x10, x9, #3
	sub	x9, x10, x9
	fmov	x10, d8
	lsl	x11, x10, #3
	sub	x10, x11, x10
	fmov	d1, x10
	mov.d	v1[1], x9
	add.2d	v1, v1, v26
	shl.2d	v1, v1, #2
	add.2d	v0, v0, v1
	tbz	w13, #6, LBB0_366
; %bb.365:                              ; %cond.store920
                                        ;   in Loop: Header=BB0_352 Depth=1
	fmov	x9, d0
	st1.s	{ v21 }[2], [x9]
LBB0_366:                               ; %else923
                                        ;   in Loop: Header=BB0_352 Depth=1
	ldr	q1, [sp, #11424]                ; 16-byte Reload
	tbz	w13, #7, LBB0_351
; %bb.367:                              ; %cond.store924
                                        ;   in Loop: Header=BB0_352 Depth=1
	mov.d	x9, v0[1]
	st1.s	{ v21 }[3], [x9]
	b	LBB0_351
LBB0_368:
	add	sp, sp, #10, lsl #12            ; =40960
	add	sp, sp, #2080
	ldp	x29, x30, [sp, #144]            ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #128]            ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #112]            ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             ; 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               ; 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             ; 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             ; 16-byte Folded Reload
	ldp	d15, d14, [sp], #160            ; 16-byte Folded Reload
LBB0_369:                               ; %common.ret
	ret
	.loh AdrpLdr	Lloh2, Lloh3
	.loh AdrpAdrp	Lloh0, Lloh2
	.loh AdrpLdr	Lloh0, Lloh1
	.loh AdrpLdr	Lloh19, Lloh23
	.loh AdrpLdr	Lloh17, Lloh18
	.loh AdrpLdr	Lloh15, Lloh16
	.loh AdrpLdr	Lloh14, Lloh22
	.loh AdrpLdr	Lloh13, Lloh21
	.loh AdrpLdr	Lloh12, Lloh20
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpAdrp	Lloh6, Lloh8
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpLdr	Lloh24, Lloh25
	.loh AdrpLdr	Lloh43, Lloh44
	.loh AdrpAdrp	Lloh36, Lloh43
	.loh AdrpLdr	Lloh36, Lloh37
	.loh AdrpLdr	Lloh35, Lloh42
	.loh AdrpLdr	Lloh34, Lloh41
	.loh AdrpLdr	Lloh33, Lloh40
	.loh AdrpLdr	Lloh32, Lloh39
	.loh AdrpLdr	Lloh31, Lloh38
	.loh AdrpLdr	Lloh30, Lloh49
	.loh AdrpLdr	Lloh29, Lloh48
	.loh AdrpLdr	Lloh28, Lloh47
	.loh AdrpLdr	Lloh27, Lloh46
	.loh AdrpLdr	Lloh26, Lloh45
                                        ; -- End function
	.globl	_llm_attention.packet_batch.blocks ; -- Begin function llm_attention.packet_batch.blocks
	.p2align	2
_llm_attention.packet_batch.blocks:     ; @llm_attention.packet_batch.blocks
; %bb.0:                                ; %block.batch.prologue
	cbz	w3, LBB1_14
; %bb.1:                                ; %block.batch.loop.preheader
	sub	sp, sp, #112
	stp	x28, x27, [sp, #16]             ; 16-byte Folded Spill
	stp	x26, x25, [sp, #32]             ; 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             ; 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             ; 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             ; 16-byte Folded Spill
	stp	x29, x30, [sp, #96]             ; 16-byte Folded Spill
	mov	x19, x3
	mov	x20, x2
	mov	x21, x0
	ldp	w28, w23, [x2, #44]
	ldp	w25, w27, [x2]
	ldp	w26, w24, [x2, #8]
	str	w23, [sp, #12]                  ; 4-byte Spill
	b	LBB1_4
LBB1_2:                                 ; %packet.batch.full.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_3:                                 ; %llm_attention.packet_batch.exit
                                        ;   in Loop: Header=BB1_4 Depth=1
	add	w8, w25, #1
	cmp	w8, w28
	cset	w8, eq
	csinc	w25, wzr, w25, eq
	cinc	w9, w27, eq
	cmp	w9, w23
	cset	w10, eq
	ands	w8, w8, w10
	csel	w27, wzr, w9, ne
	add	w26, w26, w8
	subs	w19, w19, #1
	b.eq	LBB1_13
LBB1_4:                                 ; %block.batch.loop
                                        ; =>This Inner Loop Header: Depth=1
	ubfiz	x8, x25, #5, #32
	cmp	x8, x24
	csel	x9, x8, xzr, ls
	subs	x10, x24, x9
	cmp	x10, #32
	mov	w11, #32                        ; =0x20
	csel	x10, x10, x11, lo
	cmp	x24, x9
	stp	w25, w27, [x20]
	str	w26, [x20, #8]
	str	wzr, [x20, #36]
	ccmp	x8, x24, #2, hi
	csel	x22, x10, xzr, ls
	cmp	x22, #32
	b.hs	LBB1_2
; %bb.5:                                ; %packet.batch.partial.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	x23, x28
	lsr	x28, x22, #3
	cbz	x28, LBB1_10
; %bb.6:                                ; %packet.batch.partial.full.loop.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	str	wzr, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #1
	b.eq	LBB1_10
; %bb.7:                                ; %packet.batch.partial.full.loop.i.1
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #8                          ; =0x8
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #2
	b.eq	LBB1_10
; %bb.8:                                ; %packet.batch.partial.full.loop.i.2
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #16                         ; =0x10
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	cmp	x28, #3
	b.eq	LBB1_10
; %bb.9:                                ; %packet.batch.partial.full.loop.i.3
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #32                         ; =0x20
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #40                         ; =0x28
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
	mov	w8, #48                         ; =0x30
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	mov	w2, #8                          ; =0x8
	bl	_llm_attention
LBB1_10:                                ; %packet.batch.tail.check.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	and	w2, w22, #0x7
	cbz	w2, LBB1_12
; %bb.11:                               ; %packet.batch.tail.call.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	lsl	w8, w28, #3
	str	w8, [x20, #36]
	mov	x0, x21
	mov	x1, x20
	bl	_llm_attention
LBB1_12:                                ; %packet.batch.partial.finish.i
                                        ;   in Loop: Header=BB1_4 Depth=1
	mov	w8, #24                         ; =0x18
	str	w8, [x20, #36]
	mov	x28, x23
	ldr	w23, [sp, #12]                  ; 4-byte Reload
	b	LBB1_3
LBB1_13:
	ldp	x29, x30, [sp, #96]             ; 16-byte Folded Reload
	ldp	x20, x19, [sp, #80]             ; 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             ; 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             ; 16-byte Folded Reload
	ldp	x26, x25, [sp, #32]             ; 16-byte Folded Reload
	ldp	x28, x27, [sp, #16]             ; 16-byte Folded Reload
	add	sp, sp, #112
LBB1_14:                                ; %block.batch.exit
	ret
                                        ; -- End function
.subsections_via_symbols

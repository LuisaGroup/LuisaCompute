// Bounded Metal4 Runtime copy-only progress diagnostic; no Tile/SIMT kernel.
// Eight separately submitted uploads followed by eight separate downloads
// exercise default cap-four admission. Every input and output word is checked.

#include <luisa/core/logging.h>
#include <luisa/core/stl/vector.h>
#include <luisa/runtime/buffer.h>
#include <luisa/runtime/context.h>
#include <luisa/runtime/device.h>
#include <luisa/runtime/rhi/device_interface.h>
#include <luisa/runtime/stream.h>
#include <array>
#include <cstdint>
#include <cstdio>

using namespace luisa;
using namespace luisa::compute;

namespace {

constexpr size_t kBuffers = 8u;
constexpr size_t kPadding = 17u;
constexpr size_t kPayload = 119u;
constexpr size_t kElements = kPayload + 2u * kPadding;

[[nodiscard]] uint32_t expected_word(size_t buffer, size_t index) noexcept {
    if (index < kPadding || index >= kPadding + kPayload) {
        return 0x7bad0000u + static_cast<uint32_t>(buffer);
    }
    return ((static_cast<uint32_t>(buffer) + 1u) * 0x1f123bb5u) ^
           (static_cast<uint32_t>(index) * 0x9e3779b9u);
}

void marker(const char *phase, size_t ordinal) noexcept {
    std::printf("COPY_PROBE %s ordinal=%zu\n", phase, ordinal);
    std::fflush(stdout);
}

}// namespace

int main(int argc, char *argv[]) {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    LUISA_ASSERT(argc == 2, "Usage: {} <frozen-runtime-program-path>", argv[0]);
    std::printf("COPY_PROBE begin buffers=%zu elements=%zu submissions=16 inqueue_buffer_limit=true\n",
                kBuffers, kElements);
    {
        // Use the frozen build's program path for Runtime plugin discovery;
        // this standalone diagnostic executable lives outside that build.
        Context context{argv[1]};
        DeviceConfig config{};
        config.inqueue_buffer_limit = true;
        marker("device_create_before", 0u);
        auto device = context.create_device("metal4", &config);
        marker("device_create_after", 0u);
        LUISA_ASSERT(device.backend_name() == "metal4", "Expected the native Metal4 backend");
        marker("stream_create_before", 0u);
        auto stream = device.create_stream(StreamTag::COMPUTE);
        marker("stream_create_after", 0u);

        std::array<vector<uint32_t>, kBuffers> inputs;
        std::array<vector<uint32_t>, kBuffers> outputs;
        vector<Buffer<uint32_t>> buffers;
        buffers.reserve(kBuffers);
        for (size_t i = 0u; i < kBuffers; i++) {
            inputs[i].resize(kElements);
            outputs[i].resize(kElements, 0xdeadbeefu);
            for (size_t j = 0u; j < kElements; j++) { inputs[i][j] = expected_word(i, j); }
            buffers.emplace_back(device.create_buffer<uint32_t>(kElements));
        }
        // Each full expression destroys its Delegate and submits separately.
        // No intermediate synchronization hides cap-four admission behavior.
        for (size_t i = 0u; i < kBuffers; i++) {
            marker("upload_submit_before", i);
            stream << buffers[i].copy_from(span{inputs[i]});
            marker("upload_submit_after", i);
        }
        for (size_t i = 0u; i < kBuffers; i++) {
            marker("download_submit_before", i);
            stream << buffers[i].copy_to(span{outputs[i]});
            marker("download_submit_after", i);
        }
        marker("synchronize_before", 0u);
        stream << synchronize();
        marker("synchronize_after", 0u);
        for (size_t i = 0u; i < kBuffers; i++) {
            for (size_t j = 0u; j < kElements; j++) {
                auto expected = expected_word(i, j);
                LUISA_ASSERT(outputs[i][j] == expected,
                             "Copy output mismatch: buffer={} element={} actual={} expected={}",
                             i, j, outputs[i][j], expected);
                LUISA_ASSERT(inputs[i][j] == expected,
                             "Host input changed: buffer={} element={} actual={} expected={}",
                             i, j, inputs[i][j], expected);
            }
        }
        std::printf("COPY_PROBE checks_passed words=%zu\n", 2u * kBuffers * kElements);
        marker("teardown_before", 0u);
    }
    // A PASS includes Stream/Device/Context teardown, not just the readback.
    std::printf("COPY_PROBE PASS buffers=8 elements=153 checks=2448 submissions=16\n");
    return 0;
}

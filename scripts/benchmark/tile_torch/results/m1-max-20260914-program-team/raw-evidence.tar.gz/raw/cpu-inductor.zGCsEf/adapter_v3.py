"""Validate current twelve captures, adapt four row pairs, reuse native_rows unchanged.

No capture, full build, production edit, admission relaxation or timer rewrite.
Root explicitly chose the original 18 visits/case, 7 samples, 100ms warmup,
30ms target protocol. This is not the native_tile timer or its ABBA cohort.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
RAW = HERE.parent
SPEC = importlib.util.spec_from_file_location('inductor_receipt_runner', RAW / 'run.py')
RUN = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RUN)
SOURCE, BUILD = RUN.SELECTED, RUN.BUILD
HELPERS = SOURCE / 'scripts/benchmark/tile_torch'
sys.path.insert(0, str(HELPERS))
import native_tile
import native_rows
from compare_llm import check_metadata, reference, shapes_for, validate_output
import numpy as np

native_rows.LLVM_BIN = Path('/opt/homebrew/opt/llvm@22/bin')
CASES = [('rms65', 'rmsnorm', (129, 65), (1, 1)),
         ('softmax65', 'masked_softmax', (129, 65), (1, 1)),
         ('rms512', 'rmsnorm', (129, 512), (1, 1)),
         ('softmax512', 'masked_softmax', (129, 512), (1, 1)),
         ('attention33', 'attention', (1, 2, 1, 3, 35, 7, 3), (2, 33)),
         ('attention65', 'attention', (1, 2, 1, 3, 67, 33, 7), (2, 65))]


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    RUN.save(Path(path), value)


def gate(path, frozen):
    result = read(path)
    command = read(path.parent / 'command.json')
    need(result.get('status') == 'passed' and result.get('exit_code') == 0 and not result.get('timed_out'),
         'gate not passed: ' + str(path))
    need(result['command'] == command['command'] and result['source_sha256'] == command['source_sha256'] == frozen['source_sha256']
         and result['source_freeze_sha256'] == command['source_freeze_sha256'] == frozen['receipt_sha256'],
         'gate is not the current exact frozen build')
    need(frozen['finished'] <= result['started'] <= result['finished'], 'invalid gate chronology')
    need(result['harness_sha256'] == RUN.digest(RAW / 'run.py'), 'gate runner changed')
    for channel in ('stdout', 'stderr'):
        need(RUN.digest(path.parent / f'{channel}.txt') == result[channel + '_sha256'], 'gate log changed')
    return result


def validate():
    frozen = RUN.check_freeze()
    need(Path(frozen['receipt']).name == 'source-freeze-default-predication.json', 'expected default-predication freeze')
    build = gate(RAW / 'build-full-6/result.json', frozen)
    need(build['command'][1:3] == ['--build', str(BUILD)] and '--target' not in build['command'], 'not a full build')
    for name, expression, count in (('simd-all-default-6', '^test_tile_xir_runtime
        test = gate(RAW / name / 'result.json', frozen)
        argv = test['command']
        need(Path(argv[0]).name == 'ctest' and '-R' in argv and argv[argv.index('-R') + 1] == expression
             and test['started'] >= build['finished'], 'wrong default SIMD regression gate')
        need(re.search(rf'^100% tests passed(?:, 0 tests failed)? out of {count},
                       (RAW / name / 'stdout.txt').read_text(), re.M), 'incomplete default regression')
    initial = read(RAW / 'cpu-capture-6-manifest.json')
    completed = read(RAW / 'cpu-capture-6-result.json')
    expected_cases = [[name, op, ','.join(map(str, dims)), str(block[0]), str(block[1])] for name, op, dims, block in CASES]
    need(initial['cases'] == completed['cases'] == expected_cases and completed['status'] == 'passed'
         and completed['closure_unchanged'] is True and initial['source_freeze'] == completed['source_freeze'] == frozen['receipt_sha256'],
         'not the complete current twelve-capture cohort')
    originals = dict(initial['binary_sha256']) | dict(initial['helper_sha256'])
    need(initial['binary_sha256'] == completed['binary_sha256'] and initial['helper_sha256'] == completed['helper_sha256'],
         'capture closure/result mismatch')
    need(all(RUN.digest(path) == digest for path, digest in originals.items()), 'capture binary/helper closure changed')
    report = dict(started=time.time(), source_freeze=frozen['receipt_sha256'], original_closure_sha256=originals,
                  original_manifest=str(RAW / 'cpu-capture-6-manifest.json'), checked=[],
                  source_hashes={str(HELPERS / name): RUN.digest(HELPERS / name)
                                 for name in ('native_rows.py', 'native_rows_replay.cpp', 'compare_llm.py')},
                  adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN),
                  original_driver_unmodified=True, no_capture_or_fullbuild=True,
                  protocol=dict(visits_per_case=18, samples=7, warmup_ms=100, target_ms=30,
                                order='all six permutations of whole/local/inductor; no three-cycle claim'),
                  binary_closure_boundary='Four compiler/capture artifacts identified by original cohort; '
                                          'ORC object, LLVM, payloads and all prepared files checked below.')
    adapted = HERE / 'capture'
    adapted.mkdir()
    rows = []
    matching = {}
    for name, op, dims, block in CASES:
        for local in (1, 8):
            directory = RAW / f'cpu-capture-{name}-l{local}-6'
            capture = gate(directory / 'result.json', frozen)
            prefix = directory / 'output.f32'
            expected_env = {'LUISA_SIMD_WARP_WIDTH': '8', 'LUISA_SIMD_WORKER_COUNT': '1',
                            'LUISA_TILE_BENCH_XIR_BACKEND': 'simd', 'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(local),
                            'LUISA_TILE_BENCH_XIR_BLOCK_SIZE': '32', 'LUISA_TILE_BENCH_XIR_BLOCKS_PER_TASK': '1',
                            'LUISA_TILE_BENCH_DUMP_SOURCE': str(prefix) + '.source.txt',
                            'LUISA_SIMD_DUMP_ASSEMBLY_DIR': str(directory / 'objects')}
            expected_command = ['/usr/bin/env', *(f'{key}={value}' for key, value in expected_env.items()),
                                str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, ','.join(map(str, dims)),
                                *map(str, block), '3', '10', '20', str(prefix)]
            need(capture['command'] == expected_command and capture['started'] >= build['finished'], 'capture command/default flags drift')
            payload = read(directory / 'stdout.txt')
            check_metadata(payload, 'cpu', op, dims, block, 3)
            need(f'local_lanes={local};' in payload['realization'] and 'W8, 32 workers/block, 1 CPU workers' in payload['realization'],
                 'wrong actual CPU packet/block/local realization')
            programs = dims[0] if op != 'attention' else dims[0] * dims[1] * ((dims[3] + block[0] - 1) // block[0])
            need(payload['dispatch'] == [programs * local, 1, 1], 'actual dispatch mismatch')
            shapes, output_shape = shapes_for(op, dims)
            arrays = []
            for i, shape in enumerate(shapes):
                path = Path(str(prefix) + f'.input{i}.f32')
                need(path.stat().st_size == 4 * np.prod(shape), 'input byte count mismatch')
                array = np.fromfile(path, dtype=np.float32).reshape(shape)
                need(np.isfinite(array).all(), 'nonfinite input')
                arrays.append(array)
            expected = reference(op, dims, arrays)
            oracle = np.fromfile(str(prefix) + '.expected.f64', dtype=np.float64).reshape(output_shape)
            need(np.isfinite(oracle).all() and np.allclose(oracle, expected, rtol=1e-12, atol=1e-12), 'captured FP64 oracle mismatch')
            numerical = validate_output(np.fromfile(prefix, dtype=np.float32).reshape(output_shape), expected)
            hashes = [RUN.digest(str(prefix) + f'.input{i}.f32') for i in range(3)]
            need(matching.setdefault(name, hashes) == hashes, 'cross-local input bits differ')
            prepared = RAW / f'cpu-prepared-{name}-l{local}-6/prepared.json'
            bundle = native_tile.verify(prepared)
            need(bundle['metadata'] == payload and bundle['capture_kind'] == 'llm', 'prepared object metadata differs from capture')
            for path, digest in bundle['original_sha256'].items():
                need(RUN.digest(path) == digest, 'prepared original capture changed')
            record = dict(name=name, operation=op, dimensions=dims, local_lanes=local, source=str(directory),
                          source_result_sha256=RUN.digest(directory / 'result.json'), prepared=str(prepared),
                          prepared_sha256=RUN.digest(prepared), input_sha256=hashes, numerical=numerical,
                          captured_fp64_oracle_independently_verified=True)
            report['checked'].append(record)
            if op == 'attention':
                continue
            target = adapted / (native_rows.case_name(op, dims) + f'-l{local}')
            target.mkdir()
            copied = {}
            for suffix in ('', '.input0.f32', '.input1.f32', '.input2.f32', '.expected.f64'):
                source, destination = Path(str(prefix) + suffix), target / ('output.f32' + suffix)
                shutil.copy2(source, destination)
                need(RUN.digest(source) == RUN.digest(destination), 'adapted payload changed')
                copied[str(destination)] = dict(source=str(source), sha256=RUN.digest(source))
            shutil.copy2(str(prefix) + '.source.txt', target / 'kernel.ll')
            shutil.copytree(directory / 'objects', target / 'object')
            need(RUN.digest(target / 'kernel.ll') == bundle['files']['kernel.ll'], 'adapted LLVM changed')
            objects = list((target / 'object').glob('*.o'))
            need(len(objects) == 1 and RUN.digest(objects[0]) == bundle['files']['kernel.o'], 'adapted ORC changed')
            write(target / 'measurement.json', payload)
            write(target / 'adapter-provenance.json', dict(record=record, payload_copies=copied,
                  llvm_sha256=RUN.digest(target / 'kernel.ll'), object_sha256=RUN.digest(objects[0]),
                  purpose='Mechanical format adapter from independently validated current captures, not a new capture.'))
            rows.append(dict(operation=op, dimensions=dims, local_lanes=local, directory=str(target), valid=True,
                             original_capture=str(directory), correctness=numerical, input_sha256=hashes,
                             output_sha256=RUN.digest(prefix)))
    need(len(report['checked']) == 12 and len(rows) == 8, 'missing captured case or row arm')
    need(RUN.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'] and
         all(RUN.digest(path) == digest for path, digest in originals.items()), 'identity drift during validation')
    write(adapted / 'results.json', dict(cases=[[op, dims] for _, op, dims, _ in CASES[:4]], results=rows,
          closure_unchanged=True, runner_unchanged=True,
          kind='derived_validated_current_capture_adapter', provenance=str(HERE / 'validated.json')))
    report.update(status='passed', finished=time.time())
    write(HERE / 'validated.json', report)


def verify_ready():
    report = read(HERE / 'validated.json')
    need(report['status'] == 'passed' and report['adapter_sha256'] == RUN.digest(__file__), 'adapter not validated or changed')
    need(RUN.check_freeze()['receipt_sha256'] == report['source_freeze'], 'source freeze changed')
    for path, digest in report['original_closure_sha256'].items() | report['source_hashes'].items():
        need(RUN.digest(path) == digest, 'frozen compiler/helper changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('validate', 'prepare', 'replay'))
    args = parser.parse_args()
    try:
        if args.mode == 'validate':
            validate()
        else:
            verify_ready()
            options = argparse.Namespace(capture=HERE / 'capture', prepared=HERE / 'prepared',
                                         output=HERE / ('prepared' if args.mode == 'prepare' else 'replay'))
            (native_rows.prepare if args.mode == 'prepare' else native_rows.replay)(options)
            verify_ready()
        write(HERE / (args.mode + '-complete.json'), dict(status='passed', finished=time.time(),
                                                       adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN)))
    except BaseException as error:
        write(HERE / (args.mode + '-' + Path(__file__).stem + '-error.json'), dict(status='Error', finished=time.time(),
                                                    error=f'{type(error).__name__}: {error}'))
        raise


if __name__ == '__main__':
    main()

, 1),
                                    ('simd-codegen-default-6',
                                     '^(test_simd_warp_uniformity|test_simd_xir_to_schedule|test_simd_llvm_warp_collectives|test_simd_llvm_schedule_codegen)
        test = gate(RAW / name / 'result.json', frozen)
        argv = test['command']
        need(Path(argv[0]).name == 'ctest' and '-R' in argv and argv[argv.index('-R') + 1] == expression
             and test['started'] >= build['finished'], 'wrong default SIMD regression gate')
        need(re.search(r'^100% tests passed(?:, 0 tests failed)? out of 1$',
                       (RAW / name / 'stdout.txt').read_text(), re.M), 'incomplete default regression')
    initial = read(RAW / 'cpu-capture-6-manifest.json')
    completed = read(RAW / 'cpu-capture-6-result.json')
    expected_cases = [[name, op, ','.join(map(str, dims)), str(block[0]), str(block[1])] for name, op, dims, block in CASES]
    need(initial['cases'] == completed['cases'] == expected_cases and completed['status'] == 'passed'
         and completed['closure_unchanged'] is True and initial['source_freeze'] == completed['source_freeze'] == frozen['receipt_sha256'],
         'not the complete current twelve-capture cohort')
    originals = dict(initial['binary_sha256']) | dict(initial['helper_sha256'])
    need(initial['binary_sha256'] == completed['binary_sha256'] and initial['helper_sha256'] == completed['helper_sha256'],
         'capture closure/result mismatch')
    need(all(RUN.digest(path) == digest for path, digest in originals.items()), 'capture binary/helper closure changed')
    report = dict(started=time.time(), source_freeze=frozen['receipt_sha256'], original_closure_sha256=originals,
                  original_manifest=str(RAW / 'cpu-capture-6-manifest.json'), checked=[],
                  source_hashes={str(HELPERS / name): RUN.digest(HELPERS / name)
                                 for name in ('native_rows.py', 'native_rows_replay.cpp', 'compare_llm.py')},
                  adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN),
                  original_driver_unmodified=True, no_capture_or_fullbuild=True,
                  protocol=dict(visits_per_case=18, samples=7, warmup_ms=100, target_ms=30,
                                order='all six permutations of whole/local/inductor; no three-cycle claim'),
                  binary_closure_boundary='Four compiler/capture artifacts identified by original cohort; '
                                          'ORC object, LLVM, payloads and all prepared files checked below.')
    adapted = HERE / 'capture'
    adapted.mkdir()
    rows = []
    matching = {}
    for name, op, dims, block in CASES:
        for local in (1, 8):
            directory = RAW / f'cpu-capture-{name}-l{local}-6'
            capture = gate(directory / 'result.json', frozen)
            prefix = directory / 'output.f32'
            expected_env = {'LUISA_SIMD_WARP_WIDTH': '8', 'LUISA_SIMD_WORKER_COUNT': '1',
                            'LUISA_TILE_BENCH_XIR_BACKEND': 'simd', 'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(local),
                            'LUISA_TILE_BENCH_XIR_BLOCK_SIZE': '32', 'LUISA_TILE_BENCH_XIR_BLOCKS_PER_TASK': '1',
                            'LUISA_TILE_BENCH_DUMP_SOURCE': str(prefix) + '.source.txt',
                            'LUISA_SIMD_DUMP_ASSEMBLY_DIR': str(directory / 'objects')}
            expected_command = ['/usr/bin/env', *(f'{key}={value}' for key, value in expected_env.items()),
                                str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, ','.join(map(str, dims)),
                                *map(str, block), '3', '10', '20', str(prefix)]
            need(capture['command'] == expected_command and capture['started'] >= build['finished'], 'capture command/default flags drift')
            payload = read(directory / 'stdout.txt')
            check_metadata(payload, 'cpu', op, dims, block, 3)
            need(f'local_lanes={local};' in payload['realization'] and 'W8, 32 workers/block, 1 CPU workers' in payload['realization'],
                 'wrong actual CPU packet/block/local realization')
            programs = dims[0] if op != 'attention' else dims[0] * dims[1] * ((dims[3] + block[0] - 1) // block[0])
            need(payload['dispatch'] == [programs * local, 1, 1], 'actual dispatch mismatch')
            shapes, output_shape = shapes_for(op, dims)
            arrays = []
            for i, shape in enumerate(shapes):
                path = Path(str(prefix) + f'.input{i}.f32')
                need(path.stat().st_size == 4 * np.prod(shape), 'input byte count mismatch')
                array = np.fromfile(path, dtype=np.float32).reshape(shape)
                need(np.isfinite(array).all(), 'nonfinite input')
                arrays.append(array)
            expected = reference(op, dims, arrays)
            oracle = np.fromfile(str(prefix) + '.expected.f64', dtype=np.float64).reshape(output_shape)
            need(np.isfinite(oracle).all() and np.allclose(oracle, expected, rtol=1e-12, atol=1e-12), 'captured FP64 oracle mismatch')
            numerical = validate_output(np.fromfile(prefix, dtype=np.float32).reshape(output_shape), expected)
            hashes = [RUN.digest(str(prefix) + f'.input{i}.f32') for i in range(3)]
            need(matching.setdefault(name, hashes) == hashes, 'cross-local input bits differ')
            prepared = RAW / f'cpu-prepared-{name}-l{local}-6/prepared.json'
            bundle = native_tile.verify(prepared)
            need(bundle['metadata'] == payload and bundle['capture_kind'] == 'llm', 'prepared object metadata differs from capture')
            for path, digest in bundle['original_sha256'].items():
                need(RUN.digest(path) == digest, 'prepared original capture changed')
            record = dict(name=name, operation=op, dimensions=dims, local_lanes=local, source=str(directory),
                          source_result_sha256=RUN.digest(directory / 'result.json'), prepared=str(prepared),
                          prepared_sha256=RUN.digest(prepared), input_sha256=hashes, numerical=numerical,
                          captured_fp64_oracle_independently_verified=True)
            report['checked'].append(record)
            if op == 'attention':
                continue
            target = adapted / (native_rows.case_name(op, dims) + f'-l{local}')
            target.mkdir()
            copied = {}
            for suffix in ('', '.input0.f32', '.input1.f32', '.input2.f32', '.expected.f64'):
                source, destination = Path(str(prefix) + suffix), target / ('output.f32' + suffix)
                shutil.copy2(source, destination)
                need(RUN.digest(source) == RUN.digest(destination), 'adapted payload changed')
                copied[str(destination)] = dict(source=str(source), sha256=RUN.digest(source))
            shutil.copy2(str(prefix) + '.source.txt', target / 'kernel.ll')
            shutil.copytree(directory / 'objects', target / 'object')
            need(RUN.digest(target / 'kernel.ll') == bundle['files']['kernel.ll'], 'adapted LLVM changed')
            objects = list((target / 'object').glob('*.o'))
            need(len(objects) == 1 and RUN.digest(objects[0]) == bundle['files']['kernel.o'], 'adapted ORC changed')
            write(target / 'measurement.json', payload)
            write(target / 'adapter-provenance.json', dict(record=record, payload_copies=copied,
                  llvm_sha256=RUN.digest(target / 'kernel.ll'), object_sha256=RUN.digest(objects[0]),
                  purpose='Mechanical format adapter from independently validated current captures, not a new capture.'))
            rows.append(dict(operation=op, dimensions=dims, local_lanes=local, directory=str(target), valid=True,
                             original_capture=str(directory), correctness=numerical, input_sha256=hashes,
                             output_sha256=RUN.digest(prefix)))
    need(len(report['checked']) == 12 and len(rows) == 8, 'missing captured case or row arm')
    need(RUN.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'] and
         all(RUN.digest(path) == digest for path, digest in originals.items()), 'identity drift during validation')
    write(adapted / 'results.json', dict(cases=[[op, dims] for _, op, dims, _ in CASES[:4]], results=rows,
          closure_unchanged=True, runner_unchanged=True,
          kind='derived_validated_current_capture_adapter', provenance=str(HERE / 'validated.json')))
    report.update(status='passed', finished=time.time())
    write(HERE / 'validated.json', report)


def verify_ready():
    report = read(HERE / 'validated.json')
    need(report['status'] == 'passed' and report['adapter_sha256'] == RUN.digest(__file__), 'adapter not validated or changed')
    need(RUN.check_freeze()['receipt_sha256'] == report['source_freeze'], 'source freeze changed')
    for path, digest in report['original_closure_sha256'].items() | report['source_hashes'].items():
        need(RUN.digest(path) == digest, 'frozen compiler/helper changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('validate', 'prepare', 'replay'))
    args = parser.parse_args()
    try:
        if args.mode == 'validate':
            validate()
        else:
            verify_ready()
            options = argparse.Namespace(capture=HERE / 'capture', prepared=HERE / 'prepared',
                                         output=HERE / ('prepared' if args.mode == 'prepare' else 'replay'))
            (native_rows.prepare if args.mode == 'prepare' else native_rows.replay)(options)
            verify_ready()
        write(HERE / (args.mode + '-complete.json'), dict(status='passed', finished=time.time(),
                                                       adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN)))
    except BaseException as error:
        write(HERE / (args.mode + '-error.json'), dict(status='Error', finished=time.time(),
                                                    error=f'{type(error).__name__}: {error}'))
        raise


if __name__ == '__main__':
    main()

, 4)):
        test = gate(RAW / name / 'result.json', frozen)
        argv = test['command']
        need(Path(argv[0]).name == 'ctest' and '-R' in argv and argv[argv.index('-R') + 1] == expression
             and test['started'] >= build['finished'], 'wrong default SIMD regression gate')
        need(re.search(r'^100% tests passed(?:, 0 tests failed)? out of 1$',
                       (RAW / name / 'stdout.txt').read_text(), re.M), 'incomplete default regression')
    initial = read(RAW / 'cpu-capture-6-manifest.json')
    completed = read(RAW / 'cpu-capture-6-result.json')
    expected_cases = [[name, op, ','.join(map(str, dims)), str(block[0]), str(block[1])] for name, op, dims, block in CASES]
    need(initial['cases'] == completed['cases'] == expected_cases and completed['status'] == 'passed'
         and completed['closure_unchanged'] is True and initial['source_freeze'] == completed['source_freeze'] == frozen['receipt_sha256'],
         'not the complete current twelve-capture cohort')
    originals = dict(initial['binary_sha256']) | dict(initial['helper_sha256'])
    need(initial['binary_sha256'] == completed['binary_sha256'] and initial['helper_sha256'] == completed['helper_sha256'],
         'capture closure/result mismatch')
    need(all(RUN.digest(path) == digest for path, digest in originals.items()), 'capture binary/helper closure changed')
    report = dict(started=time.time(), source_freeze=frozen['receipt_sha256'], original_closure_sha256=originals,
                  original_manifest=str(RAW / 'cpu-capture-6-manifest.json'), checked=[],
                  source_hashes={str(HELPERS / name): RUN.digest(HELPERS / name)
                                 for name in ('native_rows.py', 'native_rows_replay.cpp', 'compare_llm.py')},
                  adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN),
                  original_driver_unmodified=True, no_capture_or_fullbuild=True,
                  protocol=dict(visits_per_case=18, samples=7, warmup_ms=100, target_ms=30,
                                order='all six permutations of whole/local/inductor; no three-cycle claim'),
                  binary_closure_boundary='Four compiler/capture artifacts identified by original cohort; '
                                          'ORC object, LLVM, payloads and all prepared files checked below.')
    adapted = HERE / 'capture'
    adapted.mkdir()
    rows = []
    matching = {}
    for name, op, dims, block in CASES:
        for local in (1, 8):
            directory = RAW / f'cpu-capture-{name}-l{local}-6'
            capture = gate(directory / 'result.json', frozen)
            prefix = directory / 'output.f32'
            expected_env = {'LUISA_SIMD_WARP_WIDTH': '8', 'LUISA_SIMD_WORKER_COUNT': '1',
                            'LUISA_TILE_BENCH_XIR_BACKEND': 'simd', 'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(local),
                            'LUISA_TILE_BENCH_XIR_BLOCK_SIZE': '32', 'LUISA_TILE_BENCH_XIR_BLOCKS_PER_TASK': '1',
                            'LUISA_TILE_BENCH_DUMP_SOURCE': str(prefix) + '.source.txt',
                            'LUISA_SIMD_DUMP_ASSEMBLY_DIR': str(directory / 'objects')}
            expected_command = ['/usr/bin/env', *(f'{key}={value}' for key, value in expected_env.items()),
                                str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, ','.join(map(str, dims)),
                                *map(str, block), '3', '10', '20', str(prefix)]
            need(capture['command'] == expected_command and capture['started'] >= build['finished'], 'capture command/default flags drift')
            payload = read(directory / 'stdout.txt')
            check_metadata(payload, 'cpu', op, dims, block, 3)
            need(f'local_lanes={local};' in payload['realization'] and 'W8, 32 workers/block, 1 CPU workers' in payload['realization'],
                 'wrong actual CPU packet/block/local realization')
            programs = dims[0] if op != 'attention' else dims[0] * dims[1] * ((dims[3] + block[0] - 1) // block[0])
            need(payload['dispatch'] == [programs * local, 1, 1], 'actual dispatch mismatch')
            shapes, output_shape = shapes_for(op, dims)
            arrays = []
            for i, shape in enumerate(shapes):
                path = Path(str(prefix) + f'.input{i}.f32')
                need(path.stat().st_size == 4 * np.prod(shape), 'input byte count mismatch')
                array = np.fromfile(path, dtype=np.float32).reshape(shape)
                need(np.isfinite(array).all(), 'nonfinite input')
                arrays.append(array)
            expected = reference(op, dims, arrays)
            oracle = np.fromfile(str(prefix) + '.expected.f64', dtype=np.float64).reshape(output_shape)
            need(np.isfinite(oracle).all() and np.allclose(oracle, expected, rtol=1e-12, atol=1e-12), 'captured FP64 oracle mismatch')
            numerical = validate_output(np.fromfile(prefix, dtype=np.float32).reshape(output_shape), expected)
            hashes = [RUN.digest(str(prefix) + f'.input{i}.f32') for i in range(3)]
            need(matching.setdefault(name, hashes) == hashes, 'cross-local input bits differ')
            prepared = RAW / f'cpu-prepared-{name}-l{local}-6/prepared.json'
            bundle = native_tile.verify(prepared)
            need(bundle['metadata'] == payload and bundle['capture_kind'] == 'llm', 'prepared object metadata differs from capture')
            for path, digest in bundle['original_sha256'].items():
                need(RUN.digest(path) == digest, 'prepared original capture changed')
            record = dict(name=name, operation=op, dimensions=dims, local_lanes=local, source=str(directory),
                          source_result_sha256=RUN.digest(directory / 'result.json'), prepared=str(prepared),
                          prepared_sha256=RUN.digest(prepared), input_sha256=hashes, numerical=numerical,
                          captured_fp64_oracle_independently_verified=True)
            report['checked'].append(record)
            if op == 'attention':
                continue
            target = adapted / (native_rows.case_name(op, dims) + f'-l{local}')
            target.mkdir()
            copied = {}
            for suffix in ('', '.input0.f32', '.input1.f32', '.input2.f32', '.expected.f64'):
                source, destination = Path(str(prefix) + suffix), target / ('output.f32' + suffix)
                shutil.copy2(source, destination)
                need(RUN.digest(source) == RUN.digest(destination), 'adapted payload changed')
                copied[str(destination)] = dict(source=str(source), sha256=RUN.digest(source))
            shutil.copy2(str(prefix) + '.source.txt', target / 'kernel.ll')
            shutil.copytree(directory / 'objects', target / 'object')
            need(RUN.digest(target / 'kernel.ll') == bundle['files']['kernel.ll'], 'adapted LLVM changed')
            objects = list((target / 'object').glob('*.o'))
            need(len(objects) == 1 and RUN.digest(objects[0]) == bundle['files']['kernel.o'], 'adapted ORC changed')
            write(target / 'measurement.json', payload)
            write(target / 'adapter-provenance.json', dict(record=record, payload_copies=copied,
                  llvm_sha256=RUN.digest(target / 'kernel.ll'), object_sha256=RUN.digest(objects[0]),
                  purpose='Mechanical format adapter from independently validated current captures, not a new capture.'))
            rows.append(dict(operation=op, dimensions=dims, local_lanes=local, directory=str(target), valid=True,
                             original_capture=str(directory), correctness=numerical, input_sha256=hashes,
                             output_sha256=RUN.digest(prefix)))
    need(len(report['checked']) == 12 and len(rows) == 8, 'missing captured case or row arm')
    need(RUN.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'] and
         all(RUN.digest(path) == digest for path, digest in originals.items()), 'identity drift during validation')
    write(adapted / 'results.json', dict(cases=[[op, dims] for _, op, dims, _ in CASES[:4]], results=rows,
          closure_unchanged=True, runner_unchanged=True,
          kind='derived_validated_current_capture_adapter', provenance=str(HERE / 'validated.json')))
    report.update(status='passed', finished=time.time())
    write(HERE / 'validated.json', report)


def verify_ready():
    report = read(HERE / 'validated.json')
    need(report['status'] == 'passed' and report['adapter_sha256'] == RUN.digest(__file__), 'adapter not validated or changed')
    need(RUN.check_freeze()['receipt_sha256'] == report['source_freeze'], 'source freeze changed')
    for path, digest in report['original_closure_sha256'].items() | report['source_hashes'].items():
        need(RUN.digest(path) == digest, 'frozen compiler/helper changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('validate', 'prepare', 'replay'))
    args = parser.parse_args()
    try:
        if args.mode == 'validate':
            validate()
        else:
            verify_ready()
            options = argparse.Namespace(capture=HERE / 'capture', prepared=HERE / 'prepared',
                                         output=HERE / ('prepared' if args.mode == 'prepare' else 'replay'))
            (native_rows.prepare if args.mode == 'prepare' else native_rows.replay)(options)
            verify_ready()
        write(HERE / (args.mode + '-complete.json'), dict(status='passed', finished=time.time(),
                                                       adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN)))
    except BaseException as error:
        write(HERE / (args.mode + '-error.json'), dict(status='Error', finished=time.time(),
                                                    error=f'{type(error).__name__}: {error}'))
        raise


if __name__ == '__main__':
    main()

,
                       (RAW / name / 'stdout.txt').read_text(), re.M), 'incomplete default regression')
    initial = read(RAW / 'cpu-capture-6-manifest.json')
    completed = read(RAW / 'cpu-capture-6-result.json')
    expected_cases = [[name, op, ','.join(map(str, dims)), str(block[0]), str(block[1])] for name, op, dims, block in CASES]
    need(initial['cases'] == completed['cases'] == expected_cases and completed['status'] == 'passed'
         and completed['closure_unchanged'] is True and initial['source_freeze'] == completed['source_freeze'] == frozen['receipt_sha256'],
         'not the complete current twelve-capture cohort')
    originals = dict(initial['binary_sha256']) | dict(initial['helper_sha256'])
    need(initial['binary_sha256'] == completed['binary_sha256'] and initial['helper_sha256'] == completed['helper_sha256'],
         'capture closure/result mismatch')
    need(all(RUN.digest(path) == digest for path, digest in originals.items()), 'capture binary/helper closure changed')
    report = dict(started=time.time(), source_freeze=frozen['receipt_sha256'], original_closure_sha256=originals,
                  original_manifest=str(RAW / 'cpu-capture-6-manifest.json'), checked=[],
                  source_hashes={str(HELPERS / name): RUN.digest(HELPERS / name)
                                 for name in ('native_rows.py', 'native_rows_replay.cpp', 'compare_llm.py')},
                  adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN),
                  original_driver_unmodified=True, no_capture_or_fullbuild=True,
                  protocol=dict(visits_per_case=18, samples=7, warmup_ms=100, target_ms=30,
                                order='all six permutations of whole/local/inductor; no three-cycle claim'),
                  binary_closure_boundary='Four compiler/capture artifacts identified by original cohort; '
                                          'ORC object, LLVM, payloads and all prepared files checked below.')
    adapted = HERE / 'capture'
    adapted.mkdir()
    rows = []
    matching = {}
    for name, op, dims, block in CASES:
        for local in (1, 8):
            directory = RAW / f'cpu-capture-{name}-l{local}-6'
            capture = gate(directory / 'result.json', frozen)
            prefix = directory / 'output.f32'
            expected_env = {'LUISA_SIMD_WARP_WIDTH': '8', 'LUISA_SIMD_WORKER_COUNT': '1',
                            'LUISA_TILE_BENCH_XIR_BACKEND': 'simd', 'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(local),
                            'LUISA_TILE_BENCH_XIR_BLOCK_SIZE': '32', 'LUISA_TILE_BENCH_XIR_BLOCKS_PER_TASK': '1',
                            'LUISA_TILE_BENCH_DUMP_SOURCE': str(prefix) + '.source.txt',
                            'LUISA_SIMD_DUMP_ASSEMBLY_DIR': str(directory / 'objects')}
            expected_command = ['/usr/bin/env', *(f'{key}={value}' for key, value in expected_env.items()),
                                str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, ','.join(map(str, dims)),
                                *map(str, block), '3', '10', '20', str(prefix)]
            need(capture['command'] == expected_command and capture['started'] >= build['finished'], 'capture command/default flags drift')
            payload = read(directory / 'stdout.txt')
            check_metadata(payload, 'cpu', op, dims, block, 3)
            need(f'local_lanes={local};' in payload['realization'] and 'W8, 32 workers/block, 1 CPU workers' in payload['realization'],
                 'wrong actual CPU packet/block/local realization')
            programs = dims[0] if op != 'attention' else dims[0] * dims[1] * ((dims[3] + block[0] - 1) // block[0])
            need(payload['dispatch'] == [programs * local, 1, 1], 'actual dispatch mismatch')
            shapes, output_shape = shapes_for(op, dims)
            arrays = []
            for i, shape in enumerate(shapes):
                path = Path(str(prefix) + f'.input{i}.f32')
                need(path.stat().st_size == 4 * np.prod(shape), 'input byte count mismatch')
                array = np.fromfile(path, dtype=np.float32).reshape(shape)
                need(np.isfinite(array).all(), 'nonfinite input')
                arrays.append(array)
            expected = reference(op, dims, arrays)
            oracle = np.fromfile(str(prefix) + '.expected.f64', dtype=np.float64).reshape(output_shape)
            need(np.isfinite(oracle).all() and np.allclose(oracle, expected, rtol=1e-12, atol=1e-12), 'captured FP64 oracle mismatch')
            numerical = validate_output(np.fromfile(prefix, dtype=np.float32).reshape(output_shape), expected)
            hashes = [RUN.digest(str(prefix) + f'.input{i}.f32') for i in range(3)]
            need(matching.setdefault(name, hashes) == hashes, 'cross-local input bits differ')
            prepared = RAW / f'cpu-prepared-{name}-l{local}-6/prepared.json'
            bundle = native_tile.verify(prepared)
            need(bundle['metadata'] == payload and bundle['capture_kind'] == 'llm', 'prepared object metadata differs from capture')
            for path, digest in bundle['original_sha256'].items():
                need(RUN.digest(path) == digest, 'prepared original capture changed')
            record = dict(name=name, operation=op, dimensions=dims, local_lanes=local, source=str(directory),
                          source_result_sha256=RUN.digest(directory / 'result.json'), prepared=str(prepared),
                          prepared_sha256=RUN.digest(prepared), input_sha256=hashes, numerical=numerical,
                          captured_fp64_oracle_independently_verified=True)
            report['checked'].append(record)
            if op == 'attention':
                continue
            target = adapted / (native_rows.case_name(op, dims) + f'-l{local}')
            target.mkdir()
            copied = {}
            for suffix in ('', '.input0.f32', '.input1.f32', '.input2.f32', '.expected.f64'):
                source, destination = Path(str(prefix) + suffix), target / ('output.f32' + suffix)
                shutil.copy2(source, destination)
                need(RUN.digest(source) == RUN.digest(destination), 'adapted payload changed')
                copied[str(destination)] = dict(source=str(source), sha256=RUN.digest(source))
            shutil.copy2(str(prefix) + '.source.txt', target / 'kernel.ll')
            shutil.copytree(directory / 'objects', target / 'object')
            need(RUN.digest(target / 'kernel.ll') == bundle['files']['kernel.ll'], 'adapted LLVM changed')
            objects = list((target / 'object').glob('*.o'))
            need(len(objects) == 1 and RUN.digest(objects[0]) == bundle['files']['kernel.o'], 'adapted ORC changed')
            write(target / 'measurement.json', payload)
            write(target / 'adapter-provenance.json', dict(record=record, payload_copies=copied,
                  llvm_sha256=RUN.digest(target / 'kernel.ll'), object_sha256=RUN.digest(objects[0]),
                  purpose='Mechanical format adapter from independently validated current captures, not a new capture.'))
            rows.append(dict(operation=op, dimensions=dims, local_lanes=local, directory=str(target), valid=True,
                             original_capture=str(directory), correctness=numerical, input_sha256=hashes,
                             output_sha256=RUN.digest(prefix)))
    need(len(report['checked']) == 12 and len(rows) == 8, 'missing captured case or row arm')
    need(RUN.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'] and
         all(RUN.digest(path) == digest for path, digest in originals.items()), 'identity drift during validation')
    write(adapted / 'results.json', dict(cases=[[op, dims] for _, op, dims, _ in CASES[:4]], results=rows,
          closure_unchanged=True, runner_unchanged=True,
          kind='derived_validated_current_capture_adapter', provenance=str(HERE / 'validated.json')))
    report.update(status='passed', finished=time.time())
    write(HERE / 'validated.json', report)


def verify_ready():
    report = read(HERE / 'validated.json')
    need(report['status'] == 'passed' and report['adapter_sha256'] == RUN.digest(__file__), 'adapter not validated or changed')
    need(RUN.check_freeze()['receipt_sha256'] == report['source_freeze'], 'source freeze changed')
    for path, digest in report['original_closure_sha256'].items() | report['source_hashes'].items():
        need(RUN.digest(path) == digest, 'frozen compiler/helper changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('validate', 'prepare', 'replay'))
    args = parser.parse_args()
    try:
        if args.mode == 'validate':
            validate()
        else:
            verify_ready()
            options = argparse.Namespace(capture=HERE / 'capture', prepared=HERE / 'prepared',
                                         output=HERE / ('prepared' if args.mode == 'prepare' else 'replay'))
            (native_rows.prepare if args.mode == 'prepare' else native_rows.replay)(options)
            verify_ready()
        write(HERE / (args.mode + '-complete.json'), dict(status='passed', finished=time.time(),
                                                       adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN)))
    except BaseException as error:
        write(HERE / (args.mode + '-error.json'), dict(status='Error', finished=time.time(),
                                                    error=f'{type(error).__name__}: {error}'))
        raise


if __name__ == '__main__':
    main()

, 1),
                                    ('simd-codegen-default-6',
                                     '^(test_simd_warp_uniformity|test_simd_xir_to_schedule|test_simd_llvm_warp_collectives|test_simd_llvm_schedule_codegen)
        test = gate(RAW / name / 'result.json', frozen)
        argv = test['command']
        need(Path(argv[0]).name == 'ctest' and '-R' in argv and argv[argv.index('-R') + 1] == expression
             and test['started'] >= build['finished'], 'wrong default SIMD regression gate')
        need(re.search(r'^100% tests passed(?:, 0 tests failed)? out of 1$',
                       (RAW / name / 'stdout.txt').read_text(), re.M), 'incomplete default regression')
    initial = read(RAW / 'cpu-capture-6-manifest.json')
    completed = read(RAW / 'cpu-capture-6-result.json')
    expected_cases = [[name, op, ','.join(map(str, dims)), str(block[0]), str(block[1])] for name, op, dims, block in CASES]
    need(initial['cases'] == completed['cases'] == expected_cases and completed['status'] == 'passed'
         and completed['closure_unchanged'] is True and initial['source_freeze'] == completed['source_freeze'] == frozen['receipt_sha256'],
         'not the complete current twelve-capture cohort')
    originals = dict(initial['binary_sha256']) | dict(initial['helper_sha256'])
    need(initial['binary_sha256'] == completed['binary_sha256'] and initial['helper_sha256'] == completed['helper_sha256'],
         'capture closure/result mismatch')
    need(all(RUN.digest(path) == digest for path, digest in originals.items()), 'capture binary/helper closure changed')
    report = dict(started=time.time(), source_freeze=frozen['receipt_sha256'], original_closure_sha256=originals,
                  original_manifest=str(RAW / 'cpu-capture-6-manifest.json'), checked=[],
                  source_hashes={str(HELPERS / name): RUN.digest(HELPERS / name)
                                 for name in ('native_rows.py', 'native_rows_replay.cpp', 'compare_llm.py')},
                  adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN),
                  original_driver_unmodified=True, no_capture_or_fullbuild=True,
                  protocol=dict(visits_per_case=18, samples=7, warmup_ms=100, target_ms=30,
                                order='all six permutations of whole/local/inductor; no three-cycle claim'),
                  binary_closure_boundary='Four compiler/capture artifacts identified by original cohort; '
                                          'ORC object, LLVM, payloads and all prepared files checked below.')
    adapted = HERE / 'capture'
    adapted.mkdir()
    rows = []
    matching = {}
    for name, op, dims, block in CASES:
        for local in (1, 8):
            directory = RAW / f'cpu-capture-{name}-l{local}-6'
            capture = gate(directory / 'result.json', frozen)
            prefix = directory / 'output.f32'
            expected_env = {'LUISA_SIMD_WARP_WIDTH': '8', 'LUISA_SIMD_WORKER_COUNT': '1',
                            'LUISA_TILE_BENCH_XIR_BACKEND': 'simd', 'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(local),
                            'LUISA_TILE_BENCH_XIR_BLOCK_SIZE': '32', 'LUISA_TILE_BENCH_XIR_BLOCKS_PER_TASK': '1',
                            'LUISA_TILE_BENCH_DUMP_SOURCE': str(prefix) + '.source.txt',
                            'LUISA_SIMD_DUMP_ASSEMBLY_DIR': str(directory / 'objects')}
            expected_command = ['/usr/bin/env', *(f'{key}={value}' for key, value in expected_env.items()),
                                str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, ','.join(map(str, dims)),
                                *map(str, block), '3', '10', '20', str(prefix)]
            need(capture['command'] == expected_command and capture['started'] >= build['finished'], 'capture command/default flags drift')
            payload = read(directory / 'stdout.txt')
            check_metadata(payload, 'cpu', op, dims, block, 3)
            need(f'local_lanes={local};' in payload['realization'] and 'W8, 32 workers/block, 1 CPU workers' in payload['realization'],
                 'wrong actual CPU packet/block/local realization')
            programs = dims[0] if op != 'attention' else dims[0] * dims[1] * ((dims[3] + block[0] - 1) // block[0])
            need(payload['dispatch'] == [programs * local, 1, 1], 'actual dispatch mismatch')
            shapes, output_shape = shapes_for(op, dims)
            arrays = []
            for i, shape in enumerate(shapes):
                path = Path(str(prefix) + f'.input{i}.f32')
                need(path.stat().st_size == 4 * np.prod(shape), 'input byte count mismatch')
                array = np.fromfile(path, dtype=np.float32).reshape(shape)
                need(np.isfinite(array).all(), 'nonfinite input')
                arrays.append(array)
            expected = reference(op, dims, arrays)
            oracle = np.fromfile(str(prefix) + '.expected.f64', dtype=np.float64).reshape(output_shape)
            need(np.isfinite(oracle).all() and np.allclose(oracle, expected, rtol=1e-12, atol=1e-12), 'captured FP64 oracle mismatch')
            numerical = validate_output(np.fromfile(prefix, dtype=np.float32).reshape(output_shape), expected)
            hashes = [RUN.digest(str(prefix) + f'.input{i}.f32') for i in range(3)]
            need(matching.setdefault(name, hashes) == hashes, 'cross-local input bits differ')
            prepared = RAW / f'cpu-prepared-{name}-l{local}-6/prepared.json'
            bundle = native_tile.verify(prepared)
            need(bundle['metadata'] == payload and bundle['capture_kind'] == 'llm', 'prepared object metadata differs from capture')
            for path, digest in bundle['original_sha256'].items():
                need(RUN.digest(path) == digest, 'prepared original capture changed')
            record = dict(name=name, operation=op, dimensions=dims, local_lanes=local, source=str(directory),
                          source_result_sha256=RUN.digest(directory / 'result.json'), prepared=str(prepared),
                          prepared_sha256=RUN.digest(prepared), input_sha256=hashes, numerical=numerical,
                          captured_fp64_oracle_independently_verified=True)
            report['checked'].append(record)
            if op == 'attention':
                continue
            target = adapted / (native_rows.case_name(op, dims) + f'-l{local}')
            target.mkdir()
            copied = {}
            for suffix in ('', '.input0.f32', '.input1.f32', '.input2.f32', '.expected.f64'):
                source, destination = Path(str(prefix) + suffix), target / ('output.f32' + suffix)
                shutil.copy2(source, destination)
                need(RUN.digest(source) == RUN.digest(destination), 'adapted payload changed')
                copied[str(destination)] = dict(source=str(source), sha256=RUN.digest(source))
            shutil.copy2(str(prefix) + '.source.txt', target / 'kernel.ll')
            shutil.copytree(directory / 'objects', target / 'object')
            need(RUN.digest(target / 'kernel.ll') == bundle['files']['kernel.ll'], 'adapted LLVM changed')
            objects = list((target / 'object').glob('*.o'))
            need(len(objects) == 1 and RUN.digest(objects[0]) == bundle['files']['kernel.o'], 'adapted ORC changed')
            write(target / 'measurement.json', payload)
            write(target / 'adapter-provenance.json', dict(record=record, payload_copies=copied,
                  llvm_sha256=RUN.digest(target / 'kernel.ll'), object_sha256=RUN.digest(objects[0]),
                  purpose='Mechanical format adapter from independently validated current captures, not a new capture.'))
            rows.append(dict(operation=op, dimensions=dims, local_lanes=local, directory=str(target), valid=True,
                             original_capture=str(directory), correctness=numerical, input_sha256=hashes,
                             output_sha256=RUN.digest(prefix)))
    need(len(report['checked']) == 12 and len(rows) == 8, 'missing captured case or row arm')
    need(RUN.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'] and
         all(RUN.digest(path) == digest for path, digest in originals.items()), 'identity drift during validation')
    write(adapted / 'results.json', dict(cases=[[op, dims] for _, op, dims, _ in CASES[:4]], results=rows,
          closure_unchanged=True, runner_unchanged=True,
          kind='derived_validated_current_capture_adapter', provenance=str(HERE / 'validated.json')))
    report.update(status='passed', finished=time.time())
    write(HERE / 'validated.json', report)


def verify_ready():
    report = read(HERE / 'validated.json')
    need(report['status'] == 'passed' and report['adapter_sha256'] == RUN.digest(__file__), 'adapter not validated or changed')
    need(RUN.check_freeze()['receipt_sha256'] == report['source_freeze'], 'source freeze changed')
    for path, digest in report['original_closure_sha256'].items() | report['source_hashes'].items():
        need(RUN.digest(path) == digest, 'frozen compiler/helper changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('validate', 'prepare', 'replay'))
    args = parser.parse_args()
    try:
        if args.mode == 'validate':
            validate()
        else:
            verify_ready()
            options = argparse.Namespace(capture=HERE / 'capture', prepared=HERE / 'prepared',
                                         output=HERE / ('prepared' if args.mode == 'prepare' else 'replay'))
            (native_rows.prepare if args.mode == 'prepare' else native_rows.replay)(options)
            verify_ready()
        write(HERE / (args.mode + '-complete.json'), dict(status='passed', finished=time.time(),
                                                       adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN)))
    except BaseException as error:
        write(HERE / (args.mode + '-error.json'), dict(status='Error', finished=time.time(),
                                                    error=f'{type(error).__name__}: {error}'))
        raise


if __name__ == '__main__':
    main()

, 4)):
        test = gate(RAW / name / 'result.json', frozen)
        argv = test['command']
        need(Path(argv[0]).name == 'ctest' and '-R' in argv and argv[argv.index('-R') + 1] == expression
             and test['started'] >= build['finished'], 'wrong default SIMD regression gate')
        need(re.search(r'^100% tests passed(?:, 0 tests failed)? out of 1$',
                       (RAW / name / 'stdout.txt').read_text(), re.M), 'incomplete default regression')
    initial = read(RAW / 'cpu-capture-6-manifest.json')
    completed = read(RAW / 'cpu-capture-6-result.json')
    expected_cases = [[name, op, ','.join(map(str, dims)), str(block[0]), str(block[1])] for name, op, dims, block in CASES]
    need(initial['cases'] == completed['cases'] == expected_cases and completed['status'] == 'passed'
         and completed['closure_unchanged'] is True and initial['source_freeze'] == completed['source_freeze'] == frozen['receipt_sha256'],
         'not the complete current twelve-capture cohort')
    originals = dict(initial['binary_sha256']) | dict(initial['helper_sha256'])
    need(initial['binary_sha256'] == completed['binary_sha256'] and initial['helper_sha256'] == completed['helper_sha256'],
         'capture closure/result mismatch')
    need(all(RUN.digest(path) == digest for path, digest in originals.items()), 'capture binary/helper closure changed')
    report = dict(started=time.time(), source_freeze=frozen['receipt_sha256'], original_closure_sha256=originals,
                  original_manifest=str(RAW / 'cpu-capture-6-manifest.json'), checked=[],
                  source_hashes={str(HELPERS / name): RUN.digest(HELPERS / name)
                                 for name in ('native_rows.py', 'native_rows_replay.cpp', 'compare_llm.py')},
                  adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN),
                  original_driver_unmodified=True, no_capture_or_fullbuild=True,
                  protocol=dict(visits_per_case=18, samples=7, warmup_ms=100, target_ms=30,
                                order='all six permutations of whole/local/inductor; no three-cycle claim'),
                  binary_closure_boundary='Four compiler/capture artifacts identified by original cohort; '
                                          'ORC object, LLVM, payloads and all prepared files checked below.')
    adapted = HERE / 'capture'
    adapted.mkdir()
    rows = []
    matching = {}
    for name, op, dims, block in CASES:
        for local in (1, 8):
            directory = RAW / f'cpu-capture-{name}-l{local}-6'
            capture = gate(directory / 'result.json', frozen)
            prefix = directory / 'output.f32'
            expected_env = {'LUISA_SIMD_WARP_WIDTH': '8', 'LUISA_SIMD_WORKER_COUNT': '1',
                            'LUISA_TILE_BENCH_XIR_BACKEND': 'simd', 'LUISA_TILE_BENCH_XIR_LOCAL_LANES': str(local),
                            'LUISA_TILE_BENCH_XIR_BLOCK_SIZE': '32', 'LUISA_TILE_BENCH_XIR_BLOCKS_PER_TASK': '1',
                            'LUISA_TILE_BENCH_DUMP_SOURCE': str(prefix) + '.source.txt',
                            'LUISA_SIMD_DUMP_ASSEMBLY_DIR': str(directory / 'objects')}
            expected_command = ['/usr/bin/env', *(f'{key}={value}' for key, value in expected_env.items()),
                                str(BUILD / 'bin/benchmark_tile_xir'), 'llm', op, ','.join(map(str, dims)),
                                *map(str, block), '3', '10', '20', str(prefix)]
            need(capture['command'] == expected_command and capture['started'] >= build['finished'], 'capture command/default flags drift')
            payload = read(directory / 'stdout.txt')
            check_metadata(payload, 'cpu', op, dims, block, 3)
            need(f'local_lanes={local};' in payload['realization'] and 'W8, 32 workers/block, 1 CPU workers' in payload['realization'],
                 'wrong actual CPU packet/block/local realization')
            programs = dims[0] if op != 'attention' else dims[0] * dims[1] * ((dims[3] + block[0] - 1) // block[0])
            need(payload['dispatch'] == [programs * local, 1, 1], 'actual dispatch mismatch')
            shapes, output_shape = shapes_for(op, dims)
            arrays = []
            for i, shape in enumerate(shapes):
                path = Path(str(prefix) + f'.input{i}.f32')
                need(path.stat().st_size == 4 * np.prod(shape), 'input byte count mismatch')
                array = np.fromfile(path, dtype=np.float32).reshape(shape)
                need(np.isfinite(array).all(), 'nonfinite input')
                arrays.append(array)
            expected = reference(op, dims, arrays)
            oracle = np.fromfile(str(prefix) + '.expected.f64', dtype=np.float64).reshape(output_shape)
            need(np.isfinite(oracle).all() and np.allclose(oracle, expected, rtol=1e-12, atol=1e-12), 'captured FP64 oracle mismatch')
            numerical = validate_output(np.fromfile(prefix, dtype=np.float32).reshape(output_shape), expected)
            hashes = [RUN.digest(str(prefix) + f'.input{i}.f32') for i in range(3)]
            need(matching.setdefault(name, hashes) == hashes, 'cross-local input bits differ')
            prepared = RAW / f'cpu-prepared-{name}-l{local}-6/prepared.json'
            bundle = native_tile.verify(prepared)
            need(bundle['metadata'] == payload and bundle['capture_kind'] == 'llm', 'prepared object metadata differs from capture')
            for path, digest in bundle['original_sha256'].items():
                need(RUN.digest(path) == digest, 'prepared original capture changed')
            record = dict(name=name, operation=op, dimensions=dims, local_lanes=local, source=str(directory),
                          source_result_sha256=RUN.digest(directory / 'result.json'), prepared=str(prepared),
                          prepared_sha256=RUN.digest(prepared), input_sha256=hashes, numerical=numerical,
                          captured_fp64_oracle_independently_verified=True)
            report['checked'].append(record)
            if op == 'attention':
                continue
            target = adapted / (native_rows.case_name(op, dims) + f'-l{local}')
            target.mkdir()
            copied = {}
            for suffix in ('', '.input0.f32', '.input1.f32', '.input2.f32', '.expected.f64'):
                source, destination = Path(str(prefix) + suffix), target / ('output.f32' + suffix)
                shutil.copy2(source, destination)
                need(RUN.digest(source) == RUN.digest(destination), 'adapted payload changed')
                copied[str(destination)] = dict(source=str(source), sha256=RUN.digest(source))
            shutil.copy2(str(prefix) + '.source.txt', target / 'kernel.ll')
            shutil.copytree(directory / 'objects', target / 'object')
            need(RUN.digest(target / 'kernel.ll') == bundle['files']['kernel.ll'], 'adapted LLVM changed')
            objects = list((target / 'object').glob('*.o'))
            need(len(objects) == 1 and RUN.digest(objects[0]) == bundle['files']['kernel.o'], 'adapted ORC changed')
            write(target / 'measurement.json', payload)
            write(target / 'adapter-provenance.json', dict(record=record, payload_copies=copied,
                  llvm_sha256=RUN.digest(target / 'kernel.ll'), object_sha256=RUN.digest(objects[0]),
                  purpose='Mechanical format adapter from independently validated current captures, not a new capture.'))
            rows.append(dict(operation=op, dimensions=dims, local_lanes=local, directory=str(target), valid=True,
                             original_capture=str(directory), correctness=numerical, input_sha256=hashes,
                             output_sha256=RUN.digest(prefix)))
    need(len(report['checked']) == 12 and len(rows) == 8, 'missing captured case or row arm')
    need(RUN.check_freeze()['receipt_sha256'] == frozen['receipt_sha256'] and
         all(RUN.digest(path) == digest for path, digest in originals.items()), 'identity drift during validation')
    write(adapted / 'results.json', dict(cases=[[op, dims] for _, op, dims, _ in CASES[:4]], results=rows,
          closure_unchanged=True, runner_unchanged=True,
          kind='derived_validated_current_capture_adapter', provenance=str(HERE / 'validated.json')))
    report.update(status='passed', finished=time.time())
    write(HERE / 'validated.json', report)


def verify_ready():
    report = read(HERE / 'validated.json')
    need(report['status'] == 'passed' and report['adapter_sha256'] == RUN.digest(__file__), 'adapter not validated or changed')
    need(RUN.check_freeze()['receipt_sha256'] == report['source_freeze'], 'source freeze changed')
    for path, digest in report['original_closure_sha256'].items() | report['source_hashes'].items():
        need(RUN.digest(path) == digest, 'frozen compiler/helper changed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('validate', 'prepare', 'replay'))
    args = parser.parse_args()
    try:
        if args.mode == 'validate':
            validate()
        else:
            verify_ready()
            options = argparse.Namespace(capture=HERE / 'capture', prepared=HERE / 'prepared',
                                         output=HERE / ('prepared' if args.mode == 'prepare' else 'replay'))
            (native_rows.prepare if args.mode == 'prepare' else native_rows.replay)(options)
            verify_ready()
        write(HERE / (args.mode + '-complete.json'), dict(status='passed', finished=time.time(),
                                                       adapter_sha256=RUN.digest(__file__), llvm_tools=str(native_rows.LLVM_BIN)))
    except BaseException as error:
        write(HERE / (args.mode + '-error.json'), dict(status='Error', finished=time.time(),
                                                    error=f'{type(error).__name__}: {error}'))
        raise


if __name__ == '__main__':
    main()



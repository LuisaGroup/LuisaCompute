"""Bounded offline validation and summaries; never load a native library."""
import importlib.util
import itertools
import json
import math
from pathlib import Path
import re
import statistics as st
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('validated_row_adapter', HERE / 'adapter_v5.py')
A = importlib.util.module_from_spec(spec)
spec.loader.exec_module(A)
np, RAW, sha, need = A.np, A.RAW, A.RUN.digest, A.need
observed = {}


def read(path):
    path = Path(path)
    observed[str(path)] = sha(path)
    return A.read(path)


def tensor(path, dtype, shape):
    path = Path(path)
    observed[str(path)] = sha(path)
    value = np.fromfile(path, dtype=dtype).reshape(shape)
    need(np.isfinite(value).all(), 'nonfinite retained tensor')
    return value


def sample(row, count):
    values = row['samples_us']
    need(len(values) == count and all(math.isfinite(v) and v > 0 for v in values), 'invalid samples')
    result = st.median(values)
    need(result == row['median_us'] and row['repetitions'] > 0, 'incorrect visit median')
    return result


def ratios(values):
    return dict(median=st.median(values), minimum=min(values), maximum=max(values),
                wins=sum(v < 1 for v in values), pairs=values)


def main():
    A.verify_ready()
    frozen = A.RUN.check_freeze()
    for name in ('cohort-private-replays-6', 'cpu-inductor-prepare-v5-6', 'cpu-inductor-replay-v5-6'):
        A.gate(RAW / name / 'result.json', frozen)
    validated = read(HERE / 'validated.json')
    need(len(validated['checked']) == 12, 'incomplete twelve-capture gate')
    result = dict(status='running', started=time.time(), source_freeze=frozen['receipt_sha256'],
                  boundaries=['Two separate common C++ timers; no cross-cohort timing division.',
                              'Offline re-read checks full retained payloads, FP64 oracle, hashes and samples.',
                              'In-memory input/output/workspace guard assertions are runner receipts; guard bytes are not retained.',
                              'Single-thread native entries include block traversal and compiler-emitted allocation/libc, not Runtime/Python/JIT/caller allocations.'],
                  cohort_private=[], inductor=[])
    for name, op, dims, block in A.CASES:
        path = RAW / f'cohort-private-replayed-{name}-6/results.json'
        replay = read(path)
        need(replay['status'] == 'passed' and replay['artifacts_unchanged'] and len(replay['visits']) == 12, 'bad cohort replay')
        need(replay['options']['cycles'] == 3 and replay['options']['samples'] == 5 and
             replay['options']['warmup_ms'] == 40 and replay['options']['target_ms'] == 20, 'changed ABBA protocol')
        bundles = []
        for manifest, digest in replay['prepared_sha256'].items():
            need(sha(manifest) == digest, 'changed prepared capture')
            bundle = A.native_tile.verify(manifest)
            for original, original_hash in bundle['original_sha256'].items():
                need(sha(original) == original_hash, 'changed original artifact')
            bundles.append((Path(manifest).parent, bundle))
        shapes, output_shape = A.shapes_for(op, dims)
        arrays = [tensor(bundles[0][0] / f'input{i}.f32', np.float32, shape) for i, shape in enumerate(shapes)]
        expected = A.reference(op, dims, arrays)
        for directory, bundle in bundles:
            need(bundle['metadata']['operation'] == op and bundle['metadata']['dimensions'] == list(dims), 'case identity drift')
            for i, array in enumerate(arrays):
                other = tensor(directory / f'input{i}.f32', np.float32, array.shape)
                need(array.tobytes() == other.tobytes(), 'cross-arm input mismatch')
            oracle = tensor(directory / 'expected.f64', np.float64, output_shape)
            need(np.allclose(oracle, expected, rtol=1e-12, atol=1e-12), 'FP64 oracle mismatch')
        times = {'local8': [], 'local8-cohort-private': []}
        visit_medians, output_hashes = [], set()
        for i, row in enumerate(replay['visits']):
            order = ('local8', 'local8-cohort-private', 'local8-cohort-private', 'local8')
            need(row['cycle'] == i // 4 and row['position'] == i % 4 and row['variant'] == order[i % 4], 'not ABBA')
            need(row['valid'] and row['returncode'] == 0 and row['all_guards_passed'] and row['inputs_unchanged'], 'invalid visit')
            value = sample(row, 5)
            visit_medians.append(value)
            times[row['variant']].append(value)
            output = path.parent / row['output']
            need(sha(output) == row['output_sha256'], 'output hash mismatch')
            A.validate_output(tensor(output, np.float32, output_shape), expected)
            output_hashes.add(row['output_sha256'])
        summary = {key: st.median(values) for key, values in times.items()}
        pairs = [visit_medians[c * 4 + b] / visit_medians[c * 4 + a] for c in range(3) for a, b in ((0, 1), (3, 2))]
        need(summary == replay['summary_us'] and pairs == replay['candidate_over_baseline']['pairs'], 'cohort summary differs')
        result['cohort_private'].append(dict(case=name, dimensions=dims, median_us=summary,
                candidate_over_baseline=ratios(pairs), cross_arm_output_bitwise_equal=len(output_hashes) == 1))
    prepared = read(HERE / 'prepared/manifest.json')
    replay = read(HERE / 'replay/results.json')
    need(prepared['runner_unchanged'] and replay['runner_unchanged'] and len(prepared['cases']) == len(replay['cases']) == 4, 'incomplete Inductor cohort')
    need(replay['samples'] == 7 and replay['warmup_ms'] == 100 and replay['target_ms'] == 30 and replay['cpu_threads'] == 1, 'changed Inductor protocol')
    need(sha(replay['manifest']) == replay['manifest_sha256'] and sha(prepared['helper']) == prepared['helper_sha256'], 'changed native manifest/helper')
    result['torch_version'], result['torch_git_version'] = prepared['torch_version'], prepared['torch_git_version']
    for case, capture in zip(replay['cases'], prepared['cases']):
        op, dims = case['operation'], case['dimensions']
        need(op == capture['operation'] and dims == capture['dimensions'] and len(case['results']) == 18, 'row case/visit mismatch')
        directory = HERE / 'replay' / A.native_rows.case_name(op, dims)
        arrays = [tensor(Path(capture['inputs']) / f'output.f32.input{i}.f32', np.float32, shape) for i, shape in enumerate(capture['input_shapes'])]
        need([A.native_rows.array_digest(v) for v in arrays] == capture['input_sha256'], 'row input mismatch')
        expected = A.reference(op, dims, arrays)
        for variant, entry in capture['entries'].items():
            need(sha(entry['library']) == entry['library_sha256'], 'changed actual native library')
            if variant == 'inductor':
                need(sha(Path(entry['library']).with_name('inductor.cpp')) == entry['source_sha256'] and
                     sha(Path(entry['library']).with_name('inductor-wrapper.py')) == entry['wrapper_sha256'], 'generated source changed')
            else:
                need(entry['local_lanes'] == (1 if variant == 'whole' else 8) and entry['block_size'] == 32 and entry['packet_width'] == 8, 'mapping changed')
                llvm = Path(entry['capture']) / 'kernel.ll'
                need(sha(llvm) == entry['llvm_sha256'], 'changed LLVM')
            output = directory / (variant + '.f32')
            need(sha(output) == case['output_sha256'][variant], 'retained row output changed')
            A.validate_output(tensor(output, np.float32, capture['output_shape']), expected)
        orders = list(itertools.permutations(('whole', 'local', 'inductor')))
        medians = {}
        for i, row in enumerate(case['results']):
            need(row['round'] == i // 3 and row['order'] == list(orders[i // 3]) and row['variant'] == orders[i // 3][i % 3], 'changed balanced order')
            need(row['workspace_guards_passed'] and row['inputs_unchanged'] and row['guard_elements'] >= 512 and
                 row['output_sha256'] == case['output_sha256'][row['variant']], 'failed row guard/output receipt')
            medians[(row['round'], row['variant'])] = sample(row, 7)
        summary = {variant: st.median(medians[r, variant] for r in range(6)) for variant in orders[0]}
        need(summary == case['summary_us'], 'row summary differs')
        paired = {}
        for numerator, denominator in (('local', 'inductor'), ('whole', 'inductor'), ('local', 'whole')):
            values = [medians[r, numerator] / medians[r, denominator] for r in range(6)]
            need(values == case['paired_ratios'][numerator + '/' + denominator]['rounds'], 'row pair ratios differ')
            paired[numerator + '/' + denominator] = ratios(values)
        resource_fields = {}
        for variant in ('whole', 'local'):
            text = capture['entries'][variant]['realization']
            resource_fields[variant] = dict(re.findall(r'(static_snapshot_bytes_per_worker|static_snapshot_allocations|contiguous_private_reads|contiguous_private_writes|interleaved_private_arrays|private_workspace_bytes)=([0-9]+)', text))
        result['inductor'].append(dict(operation=op, dimensions=dims, median_us=summary, ratios=paired,
                                      resources=resource_fields, inductor_internal_allocation_sites=capture['entries']['inductor']['plan']['compiler_internal_allocation_sites']))
    A.verify_ready()
    need(all(sha(path) == digest for path, digest in observed.items()), 'audit inputs changed')
    result.update(status='passed', finished=time.time(), audit_source_sha256=sha(__file__), observed_sha256=observed,
                  native_tile_visits=72, native_tile_samples=360, native_rows_visits=72, native_rows_samples=504)
    A.write(HERE / 'audit-results.json', result)
    print(json.dumps({key: value for key, value in result.items() if key not in ('observed_sha256',)}, indent=2))


if __name__ == '__main__':
    main()

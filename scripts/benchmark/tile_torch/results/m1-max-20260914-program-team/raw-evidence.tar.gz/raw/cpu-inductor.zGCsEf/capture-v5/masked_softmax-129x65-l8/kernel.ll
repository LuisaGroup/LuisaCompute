; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [288 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [576 x i8], align 8
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local4 = alloca [72 x i8], align 1
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 9, i64 18, i64 27, i64 36, i64 45, i64 54, i64 63>, 1
  %tile_snapshot.local7 = alloca [288 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [288 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %.spill13 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill13, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill14 = alloca <8 x i1>, align 1
  store <8 x i1> zeroinitializer, ptr %.spill14, align 1
  %tile_snapshot.spill15 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill15, align 64
  %.slot16 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot16, align 64
  %.spill17 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill17, align 64
  %tile_snapshot.spill18 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill18, align 64
  %.slot19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot19, align 64
  %tile_snapshot.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill20, align 64
  %.slot21 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot21, align 64
  %.slot22 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot22, align 64
  %.slot23 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot23, align 32
  %.slot24 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot24, align 32
  %.slot25 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot25, align 32
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.spill28 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill28, align 32
  %.spill29 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill29, align 32
  %.spill30 = alloca <8 x i32>, align 32
  store <8 x i32> zeroinitializer, ptr %.spill30, align 32
  %.spill31 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill31, align 4
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot33, align 64
  %.slot34 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot34, align 64
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.slot37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot37, align 32
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.slot39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot39, align 32
  %.spill40 = alloca float, align 4
  store float 0.000000e+00, ptr %.spill40, align 4
  %.slot41 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.slot41, align 64
  %10 = getelementptr i8, ptr %argument_buffer, i64 0
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 16
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 32
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = getelementptr i8, ptr %argument_buffer, i64 48
  %29 = load ptr, ptr %28, align 16
  %30 = getelementptr i8, ptr %28, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = insertvalue { ptr, i64 } poison, ptr %29, 0
  %33 = insertvalue { ptr, i64 } %32, i64 %31, 1
  %34 = load i32, ptr %launch_config, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 12
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 4
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 16
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 8
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 20
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 36
  %46 = load i32, ptr %45, align 4
  %.splatinsert42 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat43 = shufflevector <8 x i32> %.splatinsert42, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat43, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %48 = mul i32 %34, 32
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat45, %47
  %50 = mul i32 %38, 1
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat47, zeroinitializer
  %52 = mul i32 %42, 1
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat49, zeroinitializer
  %54 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %49, 0
  %55 = insertvalue [3 x <8 x i32>] %54, <8 x i32> %51, 1
  %56 = insertvalue [3 x <8 x i32>] %55, <8 x i32> %53, 2
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %57 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat51
  %58 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  br i1 %58, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %59 = extractvalue [3 x <8 x i32>] %56, 0
  %60 = load <8 x i64>, ptr %.spill, align 64
  %61 = select <8 x i1> %57, <8 x i64> <i64 0, i64 1, i64 2, i64 3, i64 4, i64 5, i64 6, i64 7>, <8 x i64> %60
  store <8 x i64> %61, ptr %.spill, align 64
  %62 = sub <8 x i32> %59, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %63 = select <8 x i1> %57, <8 x i32> %62, <8 x i32> zeroinitializer
  %64 = select <8 x i1> %57, <8 x i32> splat (i32 3), <8 x i32> zeroinitializer
  %65 = lshr <8 x i32> %63, %64
  %66 = zext <8 x i32> %65 to <8 x i64>
  %67 = select <8 x i1> %57, <8 x i64> %66, <8 x i64> zeroinitializer
  %68 = select <8 x i1> %57, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %69 = sdiv <8 x i64> %67, %68
  %70 = load <8 x i64>, ptr %.spill13, align 64
  %71 = select <8 x i1> %57, <8 x i64> %69, <8 x i64> %70
  store <8 x i64> %71, ptr %.spill13, align 64
  %72 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %74 = extractvalue { <8 x ptr>, <8 x i64> } %72, 0
  %75 = select <8 x i1> %57, <8 x ptr> %73, <8 x ptr> %74
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %77 = extractvalue { <8 x ptr>, <8 x i64> } %72, 1
  %78 = select <8 x i1> %57, <8 x i64> %76, <8 x i64> %77
  %79 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %75, 0
  %80 = insertvalue { <8 x ptr>, <8 x i64> } %79, <8 x i64> %78, 1
  store { <8 x ptr>, <8 x i64> } %80, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %81 = icmp slt i64 %.state, 8
  br i1 %81, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.state52 = load i64, ptr %.slot, align 4
  %82 = mul i64 %.state52, 8
  %.splatinsert53 = insertelement <8 x i64> poison, i64 %82, i64 0
  %.splat54 = shufflevector <8 x i64> %.splatinsert53, <8 x i64> poison, <8 x i32> zeroinitializer
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %83 = add <8 x i64> %.splat54, %.spill.load
  %.spill.load55 = load <8 x i64>, ptr %.spill13, align 64
  %84 = add <8 x i64> %.spill.load55, zeroinitializer
  %85 = add <8 x i64> zeroinitializer, %84
  %86 = add <8 x i64> zeroinitializer, %83
  %87 = mul <8 x i64> %85, splat (i64 65)
  %88 = add <8 x i64> %87, %86
  %89 = extractvalue { ptr, i64 } %15, 0
  %90 = extractelement <8 x i64> %88, i32 0
  %91 = sub i64 %90, 0
  %92 = mul i64 %91, 4
  %buffer.contiguous.address = getelementptr i8, ptr %89, i64 %92
  %buffer.contiguous.load = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address, <8 x i1> %57, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %93 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state56 = load i64, ptr %.slot, align 4
  %.splatinsert57 = insertelement <8 x i64> poison, i64 %.state56, i64 0
  %.splat58 = shufflevector <8 x i64> %.splatinsert57, <8 x i64> poison, <8 x i32> zeroinitializer
  %95 = mul <8 x i64> %.splat58, splat (i64 32)
  %96 = add <8 x i64> %94, %95
  %97 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %93, 0
  %98 = insertvalue { <8 x ptr>, <8 x i64> } %97, <8 x i64> %96, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %98, 1
  %101 = extractelement <8 x ptr> %99, i32 0
  %102 = extractelement <8 x i64> %100, i32 0
  %103 = sub i64 %102, 0
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %105 = select i1 %104, i64 %103, i64 0
  %private.contiguous.address = getelementptr i8, ptr %101, i64 %105
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %106 = select <8 x i1> %57, <8 x float> %buffer.contiguous.load, <8 x float> %private.contiguous.preserve
  store <8 x float> %106, ptr %private.contiguous.address, align 4
  %.state59 = load i64, ptr %.slot, align 4
  %107 = add i64 %.state59, 1
  store i64 %107, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %.spill.load60 = load <8 x i64>, ptr %.spill, align 64
  %108 = icmp slt <8 x i64> %.spill.load60, splat (i64 1)
  %109 = load <8 x i1>, ptr %.spill14, align 1
  %110 = select <8 x i1> %57, <8 x i1> %108, <8 x i1> %109
  store <8 x i1> %110, ptr %.spill14, align 1
  %111 = and <8 x i1> %57, %108
  %112 = xor <8 x i1> %108, splat (i1 true)
  %113 = and <8 x i1> %57, %112
  %114 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %115 = bitcast <8 x i1> %111 to i8
  %116 = call i8 @llvm.cttz.i8(i8 %115, i1 false)
  %117 = zext i8 %116 to i32
  %118 = select i1 %114, i32 %117, i32 0
  %.spill.load61 = load <8 x i64>, ptr %.spill, align 64
  %119 = add <8 x i64> splat (i64 64), %.spill.load61
  %.spill.load62 = load <8 x i64>, ptr %.spill13, align 64
  %120 = add <8 x i64> %.spill.load62, zeroinitializer
  %121 = add <8 x i64> zeroinitializer, %120
  %122 = add <8 x i64> zeroinitializer, %119
  %123 = mul <8 x i64> %121, splat (i64 65)
  %124 = add <8 x i64> %123, %122
  %125 = extractvalue { ptr, i64 } %15, 0
  %126 = select <8 x i1> %111, <8 x i64> %124, <8 x i64> zeroinitializer
  %127 = extractelement <8 x i64> %126, i32 %118
  %128 = zext i32 %118 to i64
  %129 = sub i64 %127, %128
  %130 = mul i64 %129, 4
  %buffer.contiguous.address63 = getelementptr i8, ptr %125, i64 %130
  %buffer.contiguous.load64 = call <8 x float> @llvm.masked.load.v8f32.p0(ptr align 1 %buffer.contiguous.address63, <8 x i1> %111, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load65 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 0
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load65, 1
  %133 = add <8 x i64> %132, splat (i64 256)
  %134 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %131, 0
  %135 = insertvalue { <8 x ptr>, <8 x i64> } %134, <8 x i64> %133, 1
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %138 = extractelement <8 x ptr> %136, i32 0
  %139 = extractelement <8 x i64> %137, i32 %118
  %140 = zext i32 %118 to i64
  %141 = mul i64 %140, 4
  %142 = sub i64 %139, %141
  %143 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %111)
  %144 = select i1 %143, i64 %142, i64 0
  %private.contiguous.address66 = getelementptr i8, ptr %138, i64 %144
  %private.contiguous.preserve67 = load <8 x float>, ptr %private.contiguous.address66, align 4
  %145 = select <8 x i1> %111, <8 x float> %buffer.contiguous.load64, <8 x float> %private.contiguous.preserve67
  store <8 x float> %145, ptr %private.contiguous.address66, align 4
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %113)
  %147 = bitcast <8 x i1> %113 to i8
  %148 = call i8 @llvm.cttz.i8(i8 %147, i1 false)
  %149 = zext i8 %148 to i32
  %150 = select i1 %146, i32 %149, i32 0
  br label %direct.schedule.5

direct.schedule.5:                                ; preds = %direct.schedule.3
  %151 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 0
  %154 = select <8 x i1> %57, <8 x ptr> %152, <8 x ptr> %153
  %155 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %157 = select <8 x i1> %57, <8 x i64> %155, <8 x i64> %156
  %158 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %154, 0
  %159 = insertvalue { <8 x ptr>, <8 x i64> } %158, <8 x i64> %157, 1
  store { <8 x ptr>, <8 x i64> } %159, ptr %tile_snapshot.spill15, align 64
  %160 = load <8 x i64>, ptr %.slot16, align 64
  %161 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %160
  store <8 x i64> %161, ptr %.slot16, align 64
  br label %direct.schedule.6

direct.schedule.6:                                ; preds = %direct.schedule.7, %direct.schedule.5
  %.state68 = load <8 x i64>, ptr %.slot16, align 64
  %162 = icmp slt <8 x i64> %.state68, splat (i64 8)
  %163 = extractelement <8 x i1> %162, i32 0
  br i1 %163, label %direct.true69, label %direct.false70

direct.schedule.7:                                ; preds = %direct.true69
  %.state71 = load <8 x i64>, ptr %.slot16, align 64
  %164 = mul <8 x i64> %.state71, splat (i64 8)
  %.spill.load72 = load <8 x i64>, ptr %.spill, align 64
  %165 = add <8 x i64> %164, %.spill.load72
  %tile_snapshot.spill.load73 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load73, 1
  %.state74 = load <8 x i64>, ptr %.slot16, align 64
  %168 = mul <8 x i64> %.state74, splat (i64 64)
  %169 = add <8 x i64> %167, %168
  %170 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %166, 0
  %171 = insertvalue { <8 x ptr>, <8 x i64> } %170, <8 x i64> %169, 1
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %171, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %174 = getelementptr i8, <8 x ptr> %172, <8 x i64> %173
  call void @llvm.masked.scatter.v8i64.v8p0(<8 x i64> %165, <8 x ptr> align 1 %174, <8 x i1> %57)
  %.state75 = load <8 x i64>, ptr %.slot16, align 64
  %175 = add <8 x i64> %.state75, splat (i64 1)
  %176 = load <8 x i64>, ptr %.slot16, align 64
  %177 = select <8 x i1> %57, <8 x i64> %175, <8 x i64> %176
  store <8 x i64> %177, ptr %.slot16, align 64
  br label %direct.schedule.6

direct.schedule.8:                                ; preds = %direct.false70
  %.spill.load76 = load <8 x i1>, ptr %.spill14, align 1
  %178 = and <8 x i1> %57, %.spill.load76
  %179 = xor <8 x i1> %.spill.load76, splat (i1 true)
  %180 = and <8 x i1> %57, %179
  %181 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %178)
  %182 = bitcast <8 x i1> %178 to i8
  %183 = call i8 @llvm.cttz.i8(i8 %182, i1 false)
  %184 = zext i8 %183 to i32
  %185 = select i1 %181, i32 %184, i32 0
  %.spill.load77 = load <8 x i64>, ptr %.spill, align 64
  %186 = add <8 x i64> splat (i64 64), %.spill.load77
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %189 = add <8 x i64> %188, splat (i64 512)
  %190 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %191 = insertvalue { <8 x ptr>, <8 x i64> } %190, <8 x i64> %189, 1
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %191, 1
  %194 = extractelement <8 x ptr> %192, i32 0
  %195 = extractelement <8 x i64> %193, i32 %185
  %196 = zext i32 %185 to i64
  %197 = mul i64 %196, 8
  %198 = sub i64 %195, %197
  %199 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %178)
  %200 = select i1 %199, i64 %198, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %194, i64 %200
  %private.contiguous.preserve80 = load <8 x i64>, ptr %private.contiguous.address79, align 8
  %201 = select <8 x i1> %178, <8 x i64> %186, <8 x i64> %private.contiguous.preserve80
  store <8 x i64> %201, ptr %private.contiguous.address79, align 8
  %202 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %180)
  %203 = bitcast <8 x i1> %180 to i8
  %204 = call i8 @llvm.cttz.i8(i8 %203, i1 false)
  %205 = zext i8 %204 to i32
  %206 = select i1 %202, i32 %205, i32 0
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.8
  %.spill.load81 = load <8 x i64>, ptr %.spill13, align 64
  %207 = select <8 x i1> %57, <8 x i64> %.spill.load81, <8 x i64> zeroinitializer
  %208 = select <8 x i1> %57, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %209 = srem <8 x i64> %207, %208
  %210 = load <8 x i64>, ptr %.spill17, align 64
  %211 = select <8 x i1> %57, <8 x i64> %209, <8 x i64> %210
  store <8 x i64> %211, ptr %.spill17, align 64
  %212 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 0
  %215 = select <8 x i1> %57, <8 x ptr> %213, <8 x ptr> %214
  %216 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %218 = select <8 x i1> %57, <8 x i64> %216, <8 x i64> %217
  %219 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %215, 0
  %220 = insertvalue { <8 x ptr>, <8 x i64> } %219, <8 x i64> %218, 1
  store { <8 x ptr>, <8 x i64> } %220, ptr %tile_snapshot.spill18, align 64
  %221 = load <8 x i64>, ptr %.slot19, align 64
  %222 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %221
  store <8 x i64> %222, ptr %.slot19, align 64
  br label %direct.schedule.11

direct.schedule.11:                               ; preds = %direct.schedule.12, %direct.schedule.10
  %.state82 = load <8 x i64>, ptr %.slot19, align 64
  %223 = icmp slt <8 x i64> %.state82, splat (i64 8)
  %224 = extractelement <8 x i1> %223, i32 0
  br i1 %224, label %direct.true83, label %direct.false84

direct.schedule.12:                               ; preds = %direct.true83
  %tile_snapshot.spill.load85 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %225 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 0
  %226 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load85, 1
  %.state86 = load <8 x i64>, ptr %.slot19, align 64
  %227 = mul <8 x i64> %.state86, splat (i64 64)
  %228 = add <8 x i64> %226, %227
  %229 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %225, 0
  %230 = insertvalue { <8 x ptr>, <8 x i64> } %229, <8 x i64> %228, 1
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %230, 0
  %232 = extractvalue { <8 x ptr>, <8 x i64> } %230, 1
  %233 = getelementptr i8, <8 x ptr> %231, <8 x i64> %232
  %234 = call <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr> align 1 %233, <8 x i1> %57, <8 x i64> zeroinitializer)
  %.spill.load87 = load <8 x i64>, ptr %.spill17, align 64
  %235 = icmp sle <8 x i64> %234, %.spill.load87
  %tile_snapshot.spill.load88 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 0
  %237 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load88, 1
  %.state89 = load <8 x i64>, ptr %.slot19, align 64
  %238 = add <8 x i64> %237, %.state89
  %239 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %236, 0
  %240 = insertvalue { <8 x ptr>, <8 x i64> } %239, <8 x i64> %238, 1
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %240, 0
  %242 = extractvalue { <8 x ptr>, <8 x i64> } %240, 1
  %243 = getelementptr i8, <8 x ptr> %241, <8 x i64> %242
  %244 = zext <8 x i1> %235 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %244, <8 x ptr> align 1 %243, <8 x i1> %57)
  %.state90 = load <8 x i64>, ptr %.slot19, align 64
  %245 = add <8 x i64> %.state90, splat (i64 1)
  %246 = load <8 x i64>, ptr %.slot19, align 64
  %247 = select <8 x i1> %57, <8 x i64> %245, <8 x i64> %246
  store <8 x i64> %247, ptr %.slot19, align 64
  br label %direct.schedule.11

direct.schedule.13:                               ; preds = %direct.false84
  %.spill.load91 = load <8 x i1>, ptr %.spill14, align 1
  %248 = and <8 x i1> %57, %.spill.load91
  %249 = xor <8 x i1> %.spill.load91, splat (i1 true)
  %250 = and <8 x i1> %57, %249
  %251 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %248)
  %252 = bitcast <8 x i1> %248 to i8
  %253 = call i8 @llvm.cttz.i8(i8 %252, i1 false)
  %254 = zext i8 %253 to i32
  %255 = select i1 %251, i32 %254, i32 0
  %tile_snapshot.spill.load92 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill15, align 64
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load92, 1
  %258 = add <8 x i64> %257, splat (i64 512)
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %256, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %263 = extractelement <8 x ptr> %261, i32 0
  %264 = extractelement <8 x i64> %262, i32 %255
  %265 = zext i32 %255 to i64
  %266 = mul i64 %265, 8
  %267 = sub i64 %264, %266
  %268 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %248)
  %269 = select i1 %268, i64 %267, i64 0
  %private.contiguous.address93 = getelementptr i8, ptr %263, i64 %269
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address93, align 8
  %270 = select <8 x i1> %248, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load94 = load <8 x i64>, ptr %.spill17, align 64
  %271 = icmp sle <8 x i64> %270, %.spill.load94
  %tile_snapshot.spill.load95 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %272 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 0
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load95, 1
  %274 = add <8 x i64> %273, splat (i64 8)
  %275 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %272, 0
  %276 = insertvalue { <8 x ptr>, <8 x i64> } %275, <8 x i64> %274, 1
  %277 = extractvalue { <8 x ptr>, <8 x i64> } %276, 0
  %278 = extractvalue { <8 x ptr>, <8 x i64> } %276, 1
  %279 = getelementptr i8, <8 x ptr> %277, <8 x i64> %278
  %280 = zext <8 x i1> %271 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %280, <8 x ptr> align 1 %279, <8 x i1> %248)
  %281 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %250)
  %282 = bitcast <8 x i1> %250 to i8
  %283 = call i8 @llvm.cttz.i8(i8 %282, i1 false)
  %284 = zext i8 %283 to i32
  %285 = select i1 %281, i32 %284, i32 0
  br label %direct.schedule.15

direct.schedule.15:                               ; preds = %direct.schedule.13
  %286 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 0
  %289 = select <8 x i1> %57, <8 x ptr> %287, <8 x ptr> %288
  %290 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %291 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %292 = select <8 x i1> %57, <8 x i64> %290, <8 x i64> %291
  %293 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %289, 0
  %294 = insertvalue { <8 x ptr>, <8 x i64> } %293, <8 x i64> %292, 1
  store { <8 x ptr>, <8 x i64> } %294, ptr %tile_snapshot.spill20, align 64
  %295 = load <8 x i64>, ptr %.slot21, align 64
  %296 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %295
  store <8 x i64> %296, ptr %.slot21, align 64
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state96 = load <8 x i64>, ptr %.slot21, align 64
  %297 = icmp slt <8 x i64> %.state96, splat (i64 8)
  %298 = extractelement <8 x i1> %297, i32 0
  br i1 %298, label %direct.true97, label %direct.false98

direct.schedule.17:                               ; preds = %direct.true97
  %tile_snapshot.spill.load99 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load99, 1
  %.state100 = load <8 x i64>, ptr %.slot21, align 64
  %301 = add <8 x i64> %300, %.state100
  %302 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %299, 0
  %303 = insertvalue { <8 x ptr>, <8 x i64> } %302, <8 x i64> %301, 1
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %303, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %303, 1
  %306 = getelementptr i8, <8 x ptr> %304, <8 x i64> %305
  %307 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %306, <8 x i1> %57, <8 x i8> zeroinitializer)
  %308 = icmp ne <8 x i8> %307, zeroinitializer
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %309 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.state102 = load <8 x i64>, ptr %.slot21, align 64
  %311 = mul <8 x i64> %.state102, splat (i64 32)
  %312 = add <8 x i64> %310, %311
  %313 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %309, 0
  %314 = insertvalue { <8 x ptr>, <8 x i64> } %313, <8 x i64> %312, 1
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %314, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %314, 1
  %317 = getelementptr i8, <8 x ptr> %315, <8 x i64> %316
  %318 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %317, <8 x i1> %57, <8 x float> zeroinitializer)
  %319 = select <8 x i1> %308, <8 x float> %318, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load103 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %320 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load103, 0
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load103, 1
  %.state104 = load <8 x i64>, ptr %.slot21, align 64
  %322 = mul <8 x i64> %.state104, splat (i64 32)
  %323 = add <8 x i64> %321, %322
  %324 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %320, 0
  %325 = insertvalue { <8 x ptr>, <8 x i64> } %324, <8 x i64> %323, 1
  %326 = extractvalue { <8 x ptr>, <8 x i64> } %325, 0
  %327 = extractvalue { <8 x ptr>, <8 x i64> } %325, 1
  %328 = getelementptr i8, <8 x ptr> %326, <8 x i64> %327
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %319, <8 x ptr> align 1 %328, <8 x i1> %57)
  %.state105 = load <8 x i64>, ptr %.slot21, align 64
  %329 = add <8 x i64> %.state105, splat (i64 1)
  %330 = load <8 x i64>, ptr %.slot21, align 64
  %331 = select <8 x i1> %57, <8 x i64> %329, <8 x i64> %330
  store <8 x i64> %331, ptr %.slot21, align 64
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false98
  %.spill.load106 = load <8 x i1>, ptr %.spill14, align 1
  %332 = and <8 x i1> %57, %.spill.load106
  %333 = xor <8 x i1> %.spill.load106, splat (i1 true)
  %334 = and <8 x i1> %57, %333
  %335 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %332)
  %336 = bitcast <8 x i1> %332 to i8
  %337 = call i8 @llvm.cttz.i8(i8 %336, i1 false)
  %338 = zext i8 %337 to i32
  %339 = select i1 %335, i32 %338, i32 0
  %tile_snapshot.spill.load107 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load107, 1
  %342 = add <8 x i64> %341, splat (i64 8)
  %343 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %344 = insertvalue { <8 x ptr>, <8 x i64> } %343, <8 x i64> %342, 1
  %345 = extractvalue { <8 x ptr>, <8 x i64> } %344, 0
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %344, 1
  %347 = getelementptr i8, <8 x ptr> %345, <8 x i64> %346
  %348 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %347, <8 x i1> %332, <8 x i8> zeroinitializer)
  %349 = icmp ne <8 x i8> %348, zeroinitializer
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %350 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %351 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %352 = add <8 x i64> %351, splat (i64 256)
  %353 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %350, 0
  %354 = insertvalue { <8 x ptr>, <8 x i64> } %353, <8 x i64> %352, 1
  %355 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %356 = extractvalue { <8 x ptr>, <8 x i64> } %354, 1
  %357 = extractelement <8 x ptr> %355, i32 0
  %358 = extractelement <8 x i64> %356, i32 %339
  %359 = zext i32 %339 to i64
  %360 = mul i64 %359, 4
  %361 = sub i64 %358, %360
  %362 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %332)
  %363 = select i1 %362, i64 %361, i64 0
  %private.contiguous.address109 = getelementptr i8, ptr %357, i64 %363
  %private.contiguous.load110 = load <8 x float>, ptr %private.contiguous.address109, align 4
  %364 = select <8 x i1> %332, <8 x float> %private.contiguous.load110, <8 x float> zeroinitializer
  %365 = select <8 x i1> %349, <8 x float> %364, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load111 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 1
  %368 = add <8 x i64> %367, splat (i64 256)
  %369 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %366, 0
  %370 = insertvalue { <8 x ptr>, <8 x i64> } %369, <8 x i64> %368, 1
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %373 = extractelement <8 x ptr> %371, i32 0
  %374 = extractelement <8 x i64> %372, i32 %339
  %375 = zext i32 %339 to i64
  %376 = mul i64 %375, 4
  %377 = sub i64 %374, %376
  %378 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %332)
  %379 = select i1 %378, i64 %377, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %373, i64 %379
  %private.contiguous.preserve113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %380 = select <8 x i1> %332, <8 x float> %365, <8 x float> %private.contiguous.preserve113
  store <8 x float> %380, ptr %private.contiguous.address112, align 4
  %381 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %334)
  %382 = bitcast <8 x i1> %334 to i8
  %383 = call i8 @llvm.cttz.i8(i8 %382, i1 false)
  %384 = zext i8 %383 to i32
  %385 = select i1 %381, i32 %384, i32 0
  br label %direct.schedule.20

direct.schedule.20:                               ; preds = %direct.schedule.18
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %388 = add <8 x i64> %387, zeroinitializer
  %389 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %386, 0
  %390 = insertvalue { <8 x ptr>, <8 x i64> } %389, <8 x i64> %388, 1
  %391 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %390, 1
  %393 = extractelement <8 x ptr> %391, i32 0
  %394 = extractelement <8 x i64> %392, i32 0
  %395 = sub i64 %394, 0
  %396 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %397 = select i1 %396, i64 %395, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %393, i64 %397
  %private.contiguous.load116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %398 = select <8 x i1> %57, <8 x float> %private.contiguous.load116, <8 x float> zeroinitializer
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %401 = add <8 x i64> %400, splat (i64 32)
  %402 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %399, 0
  %403 = insertvalue { <8 x ptr>, <8 x i64> } %402, <8 x i64> %401, 1
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %403, 1
  %406 = extractelement <8 x ptr> %404, i32 0
  %407 = extractelement <8 x i64> %405, i32 0
  %408 = sub i64 %407, 0
  %409 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %410 = select i1 %409, i64 %408, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %406, i64 %410
  %private.contiguous.load119 = load <8 x float>, ptr %private.contiguous.address118, align 4
  %411 = select <8 x i1> %57, <8 x float> %private.contiguous.load119, <8 x float> zeroinitializer
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %412 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %413 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %414 = add <8 x i64> %413, splat (i64 64)
  %415 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %412, 0
  %416 = insertvalue { <8 x ptr>, <8 x i64> } %415, <8 x i64> %414, 1
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %418 = extractvalue { <8 x ptr>, <8 x i64> } %416, 1
  %419 = extractelement <8 x ptr> %417, i32 0
  %420 = extractelement <8 x i64> %418, i32 0
  %421 = sub i64 %420, 0
  %422 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %423 = select i1 %422, i64 %421, i64 0
  %private.contiguous.address121 = getelementptr i8, ptr %419, i64 %423
  %private.contiguous.load122 = load <8 x float>, ptr %private.contiguous.address121, align 4
  %424 = select <8 x i1> %57, <8 x float> %private.contiguous.load122, <8 x float> zeroinitializer
  %tile_snapshot.spill.load123 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load123, 1
  %427 = add <8 x i64> %426, splat (i64 96)
  %428 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %429 = insertvalue { <8 x ptr>, <8 x i64> } %428, <8 x i64> %427, 1
  %430 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %429, 1
  %432 = extractelement <8 x ptr> %430, i32 0
  %433 = extractelement <8 x i64> %431, i32 0
  %434 = sub i64 %433, 0
  %435 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %436 = select i1 %435, i64 %434, i64 0
  %private.contiguous.address124 = getelementptr i8, ptr %432, i64 %436
  %private.contiguous.load125 = load <8 x float>, ptr %private.contiguous.address124, align 4
  %437 = select <8 x i1> %57, <8 x float> %private.contiguous.load125, <8 x float> zeroinitializer
  %438 = load <8 x i64>, ptr %.slot22, align 64
  %439 = select <8 x i1> %57, <8 x i64> splat (i64 4), <8 x i64> %438
  store <8 x i64> %439, ptr %.slot22, align 64
  %440 = load <8 x float>, ptr %.slot23, align 32
  %441 = select <8 x i1> %57, <8 x float> %398, <8 x float> %440
  store <8 x float> %441, ptr %.slot23, align 32
  %442 = load <8 x float>, ptr %.slot24, align 32
  %443 = select <8 x i1> %57, <8 x float> %411, <8 x float> %442
  store <8 x float> %443, ptr %.slot24, align 32
  %444 = load <8 x float>, ptr %.slot25, align 32
  %445 = select <8 x i1> %57, <8 x float> %424, <8 x float> %444
  store <8 x float> %445, ptr %.slot25, align 32
  %446 = load <8 x float>, ptr %.slot26, align 32
  %447 = select <8 x i1> %57, <8 x float> %437, <8 x float> %446
  store <8 x float> %447, ptr %.slot26, align 32
  br label %direct.schedule.21

direct.schedule.21:                               ; preds = %direct.schedule.22, %direct.schedule.20
  %.state126 = load <8 x i64>, ptr %.slot22, align 64
  %448 = icmp slt <8 x i64> %.state126, splat (i64 8)
  %449 = extractelement <8 x i1> %448, i32 0
  br i1 %449, label %direct.true127, label %direct.false128

direct.schedule.22:                               ; preds = %direct.true127
  %.state129 = load <8 x i64>, ptr %.slot22, align 64
  %450 = add <8 x i64> %.state129, zeroinitializer
  %tile_snapshot.spill.load130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 0
  %452 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 1
  %453 = mul <8 x i64> %450, splat (i64 32)
  %454 = add <8 x i64> %452, %453
  %455 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %451, 0
  %456 = insertvalue { <8 x ptr>, <8 x i64> } %455, <8 x i64> %454, 1
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %456, 0
  %458 = extractvalue { <8 x ptr>, <8 x i64> } %456, 1
  %459 = getelementptr i8, <8 x ptr> %457, <8 x i64> %458
  %460 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %459, <8 x i1> %57, <8 x float> zeroinitializer)
  %.state131 = load <8 x float>, ptr %.slot23, align 32
  %461 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state131, <8 x float> %460)
  %.state132 = load <8 x i64>, ptr %.slot22, align 64
  %462 = add <8 x i64> %.state132, splat (i64 1)
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %463 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %465 = mul <8 x i64> %462, splat (i64 32)
  %466 = add <8 x i64> %464, %465
  %467 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %463, 0
  %468 = insertvalue { <8 x ptr>, <8 x i64> } %467, <8 x i64> %466, 1
  %469 = extractvalue { <8 x ptr>, <8 x i64> } %468, 0
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %468, 1
  %471 = getelementptr i8, <8 x ptr> %469, <8 x i64> %470
  %472 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %471, <8 x i1> %57, <8 x float> zeroinitializer)
  %.state134 = load <8 x float>, ptr %.slot24, align 32
  %473 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state134, <8 x float> %472)
  %.state135 = load <8 x i64>, ptr %.slot22, align 64
  %474 = add <8 x i64> %.state135, splat (i64 2)
  %tile_snapshot.spill.load136 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %475 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 0
  %476 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load136, 1
  %477 = mul <8 x i64> %474, splat (i64 32)
  %478 = add <8 x i64> %476, %477
  %479 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %475, 0
  %480 = insertvalue { <8 x ptr>, <8 x i64> } %479, <8 x i64> %478, 1
  %481 = extractvalue { <8 x ptr>, <8 x i64> } %480, 0
  %482 = extractvalue { <8 x ptr>, <8 x i64> } %480, 1
  %483 = getelementptr i8, <8 x ptr> %481, <8 x i64> %482
  %484 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %483, <8 x i1> %57, <8 x float> zeroinitializer)
  %.state137 = load <8 x float>, ptr %.slot25, align 32
  %485 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state137, <8 x float> %484)
  %.state138 = load <8 x i64>, ptr %.slot22, align 64
  %486 = add <8 x i64> %.state138, splat (i64 3)
  %tile_snapshot.spill.load139 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %487 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 0
  %488 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load139, 1
  %489 = mul <8 x i64> %486, splat (i64 32)
  %490 = add <8 x i64> %488, %489
  %491 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %487, 0
  %492 = insertvalue { <8 x ptr>, <8 x i64> } %491, <8 x i64> %490, 1
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %492, 0
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %492, 1
  %495 = getelementptr i8, <8 x ptr> %493, <8 x i64> %494
  %496 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %495, <8 x i1> %57, <8 x float> zeroinitializer)
  %.state140 = load <8 x float>, ptr %.slot26, align 32
  %497 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state140, <8 x float> %496)
  %.state141 = load <8 x i64>, ptr %.slot22, align 64
  %498 = add <8 x i64> %.state141, splat (i64 4)
  %499 = load <8 x i64>, ptr %.slot22, align 64
  %500 = select <8 x i1> %57, <8 x i64> %498, <8 x i64> %499
  store <8 x i64> %500, ptr %.slot22, align 64
  %501 = load <8 x float>, ptr %.slot23, align 32
  %502 = select <8 x i1> %57, <8 x float> %461, <8 x float> %501
  store <8 x float> %502, ptr %.slot23, align 32
  %503 = load <8 x float>, ptr %.slot24, align 32
  %504 = select <8 x i1> %57, <8 x float> %473, <8 x float> %503
  store <8 x float> %504, ptr %.slot24, align 32
  %505 = load <8 x float>, ptr %.slot25, align 32
  %506 = select <8 x i1> %57, <8 x float> %485, <8 x float> %505
  store <8 x float> %506, ptr %.slot25, align 32
  %507 = load <8 x float>, ptr %.slot26, align 32
  %508 = select <8 x i1> %57, <8 x float> %497, <8 x float> %507
  store <8 x float> %508, ptr %.slot26, align 32
  br label %direct.schedule.21

direct.schedule.23:                               ; preds = %direct.false128
  %.spill.load142 = load <8 x i1>, ptr %.spill14, align 1
  %509 = and <8 x i1> %57, %.spill.load142
  %510 = xor <8 x i1> %.spill.load142, splat (i1 true)
  %511 = and <8 x i1> %57, %510
  %512 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %509)
  %513 = bitcast <8 x i1> %509 to i8
  %514 = call i8 @llvm.cttz.i8(i8 %513, i1 false)
  %515 = zext i8 %514 to i32
  %516 = select i1 %512, i32 %515, i32 0
  %tile_snapshot.spill.load143 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load143, 1
  %519 = add <8 x i64> %518, splat (i64 256)
  %520 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %517, 0
  %521 = insertvalue { <8 x ptr>, <8 x i64> } %520, <8 x i64> %519, 1
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %521, 1
  %524 = extractelement <8 x ptr> %522, i32 0
  %525 = extractelement <8 x i64> %523, i32 %516
  %526 = zext i32 %516 to i64
  %527 = mul i64 %526, 4
  %528 = sub i64 %525, %527
  %529 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %509)
  %530 = select i1 %529, i64 %528, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %524, i64 %530
  %private.contiguous.load145 = load <8 x float>, ptr %private.contiguous.address144, align 4
  %531 = select <8 x i1> %509, <8 x float> %private.contiguous.load145, <8 x float> zeroinitializer
  %.state146 = load <8 x float>, ptr %.slot23, align 32
  %532 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state146, <8 x float> %531)
  %533 = load <8 x float>, ptr %.slot27, align 32
  %534 = select <8 x i1> %509, <8 x float> %532, <8 x float> %533
  store <8 x float> %534, ptr %.slot27, align 32
  %535 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %511)
  %536 = bitcast <8 x i1> %511 to i8
  %537 = call i8 @llvm.cttz.i8(i8 %536, i1 false)
  %538 = zext i8 %537 to i32
  %539 = select i1 %535, i32 %538, i32 0
  %.state147 = load <8 x float>, ptr %.slot23, align 32
  %540 = load <8 x float>, ptr %.slot27, align 32
  %541 = select <8 x i1> %511, <8 x float> %.state147, <8 x float> %540
  store <8 x float> %541, ptr %.slot27, align 32
  br label %direct.schedule.25

direct.schedule.25:                               ; preds = %direct.schedule.23
  %.state148 = load <8 x float>, ptr %.slot27, align 32
  %.state149 = load <8 x float>, ptr %.slot24, align 32
  %542 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state148, <8 x float> %.state149)
  %.state150 = load <8 x float>, ptr %.slot25, align 32
  %543 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %542, <8 x float> %.state150)
  %.state151 = load <8 x float>, ptr %.slot26, align 32
  %544 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %543, <8 x float> %.state151)
  %.spill.load152 = load <8 x i64>, ptr %.spill, align 64
  %545 = trunc <8 x i64> %.spill.load152 to <8 x i32>
  %546 = xor <8 x i32> %545, splat (i32 1)
  %547 = load <8 x i32>, ptr %.spill28, align 32
  %548 = select <8 x i1> %57, <8 x i32> %546, <8 x i32> %547
  store <8 x i32> %548, ptr %.spill28, align 32
  %549 = extractelement <8 x i32> %546, i64 0
  %550 = icmp ult i32 %549, 8
  %551 = select i1 %550, i32 %549, i32 0
  %552 = extractelement <8 x i1> %57, i32 %551
  %553 = extractelement <8 x i1> %57, i64 0
  %554 = and i1 %550, %552
  %555 = and i1 %553, %554
  %556 = extractelement <8 x float> %544, i32 %551
  %557 = select i1 %555, float %556, float 0.000000e+00
  %558 = insertelement <8 x float> poison, float %557, i64 0
  %559 = xor i1 %555, true
  %560 = and i1 %553, %559
  %561 = insertelement <8 x i1> poison, i1 %560, i64 0
  %562 = extractelement <8 x i32> %546, i64 1
  %563 = icmp ult i32 %562, 8
  %564 = select i1 %563, i32 %562, i32 0
  %565 = extractelement <8 x i1> %57, i32 %564
  %566 = extractelement <8 x i1> %57, i64 1
  %567 = and i1 %563, %565
  %568 = and i1 %566, %567
  %569 = extractelement <8 x float> %544, i32 %564
  %570 = select i1 %568, float %569, float 0.000000e+00
  %571 = insertelement <8 x float> %558, float %570, i64 1
  %572 = xor i1 %568, true
  %573 = and i1 %566, %572
  %574 = insertelement <8 x i1> %561, i1 %573, i64 1
  %575 = extractelement <8 x i32> %546, i64 2
  %576 = icmp ult i32 %575, 8
  %577 = select i1 %576, i32 %575, i32 0
  %578 = extractelement <8 x i1> %57, i32 %577
  %579 = extractelement <8 x i1> %57, i64 2
  %580 = and i1 %576, %578
  %581 = and i1 %579, %580
  %582 = extractelement <8 x float> %544, i32 %577
  %583 = select i1 %581, float %582, float 0.000000e+00
  %584 = insertelement <8 x float> %571, float %583, i64 2
  %585 = xor i1 %581, true
  %586 = and i1 %579, %585
  %587 = insertelement <8 x i1> %574, i1 %586, i64 2
  %588 = extractelement <8 x i32> %546, i64 3
  %589 = icmp ult i32 %588, 8
  %590 = select i1 %589, i32 %588, i32 0
  %591 = extractelement <8 x i1> %57, i32 %590
  %592 = extractelement <8 x i1> %57, i64 3
  %593 = and i1 %589, %591
  %594 = and i1 %592, %593
  %595 = extractelement <8 x float> %544, i32 %590
  %596 = select i1 %594, float %595, float 0.000000e+00
  %597 = insertelement <8 x float> %584, float %596, i64 3
  %598 = xor i1 %594, true
  %599 = and i1 %592, %598
  %600 = insertelement <8 x i1> %587, i1 %599, i64 3
  %601 = extractelement <8 x i32> %546, i64 4
  %602 = icmp ult i32 %601, 8
  %603 = select i1 %602, i32 %601, i32 0
  %604 = extractelement <8 x i1> %57, i32 %603
  %605 = extractelement <8 x i1> %57, i64 4
  %606 = and i1 %602, %604
  %607 = and i1 %605, %606
  %608 = extractelement <8 x float> %544, i32 %603
  %609 = select i1 %607, float %608, float 0.000000e+00
  %610 = insertelement <8 x float> %597, float %609, i64 4
  %611 = xor i1 %607, true
  %612 = and i1 %605, %611
  %613 = insertelement <8 x i1> %600, i1 %612, i64 4
  %614 = extractelement <8 x i32> %546, i64 5
  %615 = icmp ult i32 %614, 8
  %616 = select i1 %615, i32 %614, i32 0
  %617 = extractelement <8 x i1> %57, i32 %616
  %618 = extractelement <8 x i1> %57, i64 5
  %619 = and i1 %615, %617
  %620 = and i1 %618, %619
  %621 = extractelement <8 x float> %544, i32 %616
  %622 = select i1 %620, float %621, float 0.000000e+00
  %623 = insertelement <8 x float> %610, float %622, i64 5
  %624 = xor i1 %620, true
  %625 = and i1 %618, %624
  %626 = insertelement <8 x i1> %613, i1 %625, i64 5
  %627 = extractelement <8 x i32> %546, i64 6
  %628 = icmp ult i32 %627, 8
  %629 = select i1 %628, i32 %627, i32 0
  %630 = extractelement <8 x i1> %57, i32 %629
  %631 = extractelement <8 x i1> %57, i64 6
  %632 = and i1 %628, %630
  %633 = and i1 %631, %632
  %634 = extractelement <8 x float> %544, i32 %629
  %635 = select i1 %633, float %634, float 0.000000e+00
  %636 = insertelement <8 x float> %623, float %635, i64 6
  %637 = xor i1 %633, true
  %638 = and i1 %631, %637
  %639 = insertelement <8 x i1> %626, i1 %638, i64 6
  %640 = extractelement <8 x i32> %546, i64 7
  %641 = icmp ult i32 %640, 8
  %642 = select i1 %641, i32 %640, i32 0
  %643 = extractelement <8 x i1> %57, i32 %642
  %644 = extractelement <8 x i1> %57, i64 7
  %645 = and i1 %641, %643
  %646 = and i1 %644, %645
  %647 = extractelement <8 x float> %544, i32 %642
  %648 = select i1 %646, float %647, float 0.000000e+00
  %649 = insertelement <8 x float> %636, float %648, i64 7
  %650 = xor i1 %646, true
  %651 = and i1 %644, %650
  %652 = insertelement <8 x i1> %639, i1 %651, i64 7
  %653 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %544, <8 x float> %649)
  %654 = xor <8 x i32> %545, splat (i32 2)
  %655 = load <8 x i32>, ptr %.spill29, align 32
  %656 = select <8 x i1> %57, <8 x i32> %654, <8 x i32> %655
  store <8 x i32> %656, ptr %.spill29, align 32
  %657 = extractelement <8 x i32> %654, i64 0
  %658 = icmp ult i32 %657, 8
  %659 = select i1 %658, i32 %657, i32 0
  %660 = extractelement <8 x i1> %57, i32 %659
  %661 = extractelement <8 x i1> %57, i64 0
  %662 = and i1 %658, %660
  %663 = and i1 %661, %662
  %664 = extractelement <8 x float> %653, i32 %659
  %665 = select i1 %663, float %664, float 0.000000e+00
  %666 = insertelement <8 x float> poison, float %665, i64 0
  %667 = xor i1 %663, true
  %668 = and i1 %661, %667
  %669 = insertelement <8 x i1> poison, i1 %668, i64 0
  %670 = extractelement <8 x i32> %654, i64 1
  %671 = icmp ult i32 %670, 8
  %672 = select i1 %671, i32 %670, i32 0
  %673 = extractelement <8 x i1> %57, i32 %672
  %674 = extractelement <8 x i1> %57, i64 1
  %675 = and i1 %671, %673
  %676 = and i1 %674, %675
  %677 = extractelement <8 x float> %653, i32 %672
  %678 = select i1 %676, float %677, float 0.000000e+00
  %679 = insertelement <8 x float> %666, float %678, i64 1
  %680 = xor i1 %676, true
  %681 = and i1 %674, %680
  %682 = insertelement <8 x i1> %669, i1 %681, i64 1
  %683 = extractelement <8 x i32> %654, i64 2
  %684 = icmp ult i32 %683, 8
  %685 = select i1 %684, i32 %683, i32 0
  %686 = extractelement <8 x i1> %57, i32 %685
  %687 = extractelement <8 x i1> %57, i64 2
  %688 = and i1 %684, %686
  %689 = and i1 %687, %688
  %690 = extractelement <8 x float> %653, i32 %685
  %691 = select i1 %689, float %690, float 0.000000e+00
  %692 = insertelement <8 x float> %679, float %691, i64 2
  %693 = xor i1 %689, true
  %694 = and i1 %687, %693
  %695 = insertelement <8 x i1> %682, i1 %694, i64 2
  %696 = extractelement <8 x i32> %654, i64 3
  %697 = icmp ult i32 %696, 8
  %698 = select i1 %697, i32 %696, i32 0
  %699 = extractelement <8 x i1> %57, i32 %698
  %700 = extractelement <8 x i1> %57, i64 3
  %701 = and i1 %697, %699
  %702 = and i1 %700, %701
  %703 = extractelement <8 x float> %653, i32 %698
  %704 = select i1 %702, float %703, float 0.000000e+00
  %705 = insertelement <8 x float> %692, float %704, i64 3
  %706 = xor i1 %702, true
  %707 = and i1 %700, %706
  %708 = insertelement <8 x i1> %695, i1 %707, i64 3
  %709 = extractelement <8 x i32> %654, i64 4
  %710 = icmp ult i32 %709, 8
  %711 = select i1 %710, i32 %709, i32 0
  %712 = extractelement <8 x i1> %57, i32 %711
  %713 = extractelement <8 x i1> %57, i64 4
  %714 = and i1 %710, %712
  %715 = and i1 %713, %714
  %716 = extractelement <8 x float> %653, i32 %711
  %717 = select i1 %715, float %716, float 0.000000e+00
  %718 = insertelement <8 x float> %705, float %717, i64 4
  %719 = xor i1 %715, true
  %720 = and i1 %713, %719
  %721 = insertelement <8 x i1> %708, i1 %720, i64 4
  %722 = extractelement <8 x i32> %654, i64 5
  %723 = icmp ult i32 %722, 8
  %724 = select i1 %723, i32 %722, i32 0
  %725 = extractelement <8 x i1> %57, i32 %724
  %726 = extractelement <8 x i1> %57, i64 5
  %727 = and i1 %723, %725
  %728 = and i1 %726, %727
  %729 = extractelement <8 x float> %653, i32 %724
  %730 = select i1 %728, float %729, float 0.000000e+00
  %731 = insertelement <8 x float> %718, float %730, i64 5
  %732 = xor i1 %728, true
  %733 = and i1 %726, %732
  %734 = insertelement <8 x i1> %721, i1 %733, i64 5
  %735 = extractelement <8 x i32> %654, i64 6
  %736 = icmp ult i32 %735, 8
  %737 = select i1 %736, i32 %735, i32 0
  %738 = extractelement <8 x i1> %57, i32 %737
  %739 = extractelement <8 x i1> %57, i64 6
  %740 = and i1 %736, %738
  %741 = and i1 %739, %740
  %742 = extractelement <8 x float> %653, i32 %737
  %743 = select i1 %741, float %742, float 0.000000e+00
  %744 = insertelement <8 x float> %731, float %743, i64 6
  %745 = xor i1 %741, true
  %746 = and i1 %739, %745
  %747 = insertelement <8 x i1> %734, i1 %746, i64 6
  %748 = extractelement <8 x i32> %654, i64 7
  %749 = icmp ult i32 %748, 8
  %750 = select i1 %749, i32 %748, i32 0
  %751 = extractelement <8 x i1> %57, i32 %750
  %752 = extractelement <8 x i1> %57, i64 7
  %753 = and i1 %749, %751
  %754 = and i1 %752, %753
  %755 = extractelement <8 x float> %653, i32 %750
  %756 = select i1 %754, float %755, float 0.000000e+00
  %757 = insertelement <8 x float> %744, float %756, i64 7
  %758 = xor i1 %754, true
  %759 = and i1 %752, %758
  %760 = insertelement <8 x i1> %747, i1 %759, i64 7
  %761 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %653, <8 x float> %757)
  %762 = xor <8 x i32> %545, splat (i32 4)
  %763 = load <8 x i32>, ptr %.spill30, align 32
  %764 = select <8 x i1> %57, <8 x i32> %762, <8 x i32> %763
  store <8 x i32> %764, ptr %.spill30, align 32
  %765 = extractelement <8 x i32> %762, i64 0
  %766 = icmp ult i32 %765, 8
  %767 = select i1 %766, i32 %765, i32 0
  %768 = extractelement <8 x i1> %57, i32 %767
  %769 = extractelement <8 x i1> %57, i64 0
  %770 = and i1 %766, %768
  %771 = and i1 %769, %770
  %772 = extractelement <8 x float> %761, i32 %767
  %773 = select i1 %771, float %772, float 0.000000e+00
  %774 = insertelement <8 x float> poison, float %773, i64 0
  %775 = xor i1 %771, true
  %776 = and i1 %769, %775
  %777 = insertelement <8 x i1> poison, i1 %776, i64 0
  %778 = extractelement <8 x i32> %762, i64 1
  %779 = icmp ult i32 %778, 8
  %780 = select i1 %779, i32 %778, i32 0
  %781 = extractelement <8 x i1> %57, i32 %780
  %782 = extractelement <8 x i1> %57, i64 1
  %783 = and i1 %779, %781
  %784 = and i1 %782, %783
  %785 = extractelement <8 x float> %761, i32 %780
  %786 = select i1 %784, float %785, float 0.000000e+00
  %787 = insertelement <8 x float> %774, float %786, i64 1
  %788 = xor i1 %784, true
  %789 = and i1 %782, %788
  %790 = insertelement <8 x i1> %777, i1 %789, i64 1
  %791 = extractelement <8 x i32> %762, i64 2
  %792 = icmp ult i32 %791, 8
  %793 = select i1 %792, i32 %791, i32 0
  %794 = extractelement <8 x i1> %57, i32 %793
  %795 = extractelement <8 x i1> %57, i64 2
  %796 = and i1 %792, %794
  %797 = and i1 %795, %796
  %798 = extractelement <8 x float> %761, i32 %793
  %799 = select i1 %797, float %798, float 0.000000e+00
  %800 = insertelement <8 x float> %787, float %799, i64 2
  %801 = xor i1 %797, true
  %802 = and i1 %795, %801
  %803 = insertelement <8 x i1> %790, i1 %802, i64 2
  %804 = extractelement <8 x i32> %762, i64 3
  %805 = icmp ult i32 %804, 8
  %806 = select i1 %805, i32 %804, i32 0
  %807 = extractelement <8 x i1> %57, i32 %806
  %808 = extractelement <8 x i1> %57, i64 3
  %809 = and i1 %805, %807
  %810 = and i1 %808, %809
  %811 = extractelement <8 x float> %761, i32 %806
  %812 = select i1 %810, float %811, float 0.000000e+00
  %813 = insertelement <8 x float> %800, float %812, i64 3
  %814 = xor i1 %810, true
  %815 = and i1 %808, %814
  %816 = insertelement <8 x i1> %803, i1 %815, i64 3
  %817 = extractelement <8 x i32> %762, i64 4
  %818 = icmp ult i32 %817, 8
  %819 = select i1 %818, i32 %817, i32 0
  %820 = extractelement <8 x i1> %57, i32 %819
  %821 = extractelement <8 x i1> %57, i64 4
  %822 = and i1 %818, %820
  %823 = and i1 %821, %822
  %824 = extractelement <8 x float> %761, i32 %819
  %825 = select i1 %823, float %824, float 0.000000e+00
  %826 = insertelement <8 x float> %813, float %825, i64 4
  %827 = xor i1 %823, true
  %828 = and i1 %821, %827
  %829 = insertelement <8 x i1> %816, i1 %828, i64 4
  %830 = extractelement <8 x i32> %762, i64 5
  %831 = icmp ult i32 %830, 8
  %832 = select i1 %831, i32 %830, i32 0
  %833 = extractelement <8 x i1> %57, i32 %832
  %834 = extractelement <8 x i1> %57, i64 5
  %835 = and i1 %831, %833
  %836 = and i1 %834, %835
  %837 = extractelement <8 x float> %761, i32 %832
  %838 = select i1 %836, float %837, float 0.000000e+00
  %839 = insertelement <8 x float> %826, float %838, i64 5
  %840 = xor i1 %836, true
  %841 = and i1 %834, %840
  %842 = insertelement <8 x i1> %829, i1 %841, i64 5
  %843 = extractelement <8 x i32> %762, i64 6
  %844 = icmp ult i32 %843, 8
  %845 = select i1 %844, i32 %843, i32 0
  %846 = extractelement <8 x i1> %57, i32 %845
  %847 = extractelement <8 x i1> %57, i64 6
  %848 = and i1 %844, %846
  %849 = and i1 %847, %848
  %850 = extractelement <8 x float> %761, i32 %845
  %851 = select i1 %849, float %850, float 0.000000e+00
  %852 = insertelement <8 x float> %839, float %851, i64 6
  %853 = xor i1 %849, true
  %854 = and i1 %847, %853
  %855 = insertelement <8 x i1> %842, i1 %854, i64 6
  %856 = extractelement <8 x i32> %762, i64 7
  %857 = icmp ult i32 %856, 8
  %858 = select i1 %857, i32 %856, i32 0
  %859 = extractelement <8 x i1> %57, i32 %858
  %860 = extractelement <8 x i1> %57, i64 7
  %861 = and i1 %857, %859
  %862 = and i1 %860, %861
  %863 = extractelement <8 x float> %761, i32 %858
  %864 = select i1 %862, float %863, float 0.000000e+00
  %865 = insertelement <8 x float> %852, float %864, i64 7
  %866 = xor i1 %862, true
  %867 = and i1 %860, %866
  %868 = insertelement <8 x i1> %855, i1 %867, i64 7
  %869 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %761, <8 x float> %865)
  %870 = extractelement <8 x i1> %57, i32 0
  %871 = extractelement <8 x i1> %57, i64 0
  %872 = and i1 true, %870
  %873 = and i1 %871, %872
  %874 = extractelement <8 x float> %869, i32 0
  %875 = select i1 %873, float %874, float 0.000000e+00
  %876 = insertelement <8 x float> poison, float %875, i64 0
  %877 = xor i1 %873, true
  %878 = and i1 %871, %877
  %879 = insertelement <8 x i1> poison, i1 %878, i64 0
  %880 = extractelement <8 x i1> %57, i32 0
  %881 = extractelement <8 x i1> %57, i64 1
  %882 = and i1 true, %880
  %883 = and i1 %881, %882
  %884 = extractelement <8 x float> %869, i32 0
  %885 = select i1 %883, float %884, float 0.000000e+00
  %886 = insertelement <8 x float> %876, float %885, i64 1
  %887 = xor i1 %883, true
  %888 = and i1 %881, %887
  %889 = insertelement <8 x i1> %879, i1 %888, i64 1
  %890 = extractelement <8 x i1> %57, i32 0
  %891 = extractelement <8 x i1> %57, i64 2
  %892 = and i1 true, %890
  %893 = and i1 %891, %892
  %894 = extractelement <8 x float> %869, i32 0
  %895 = select i1 %893, float %894, float 0.000000e+00
  %896 = insertelement <8 x float> %886, float %895, i64 2
  %897 = xor i1 %893, true
  %898 = and i1 %891, %897
  %899 = insertelement <8 x i1> %889, i1 %898, i64 2
  %900 = extractelement <8 x i1> %57, i32 0
  %901 = extractelement <8 x i1> %57, i64 3
  %902 = and i1 true, %900
  %903 = and i1 %901, %902
  %904 = extractelement <8 x float> %869, i32 0
  %905 = select i1 %903, float %904, float 0.000000e+00
  %906 = insertelement <8 x float> %896, float %905, i64 3
  %907 = xor i1 %903, true
  %908 = and i1 %901, %907
  %909 = insertelement <8 x i1> %899, i1 %908, i64 3
  %910 = extractelement <8 x i1> %57, i32 0
  %911 = extractelement <8 x i1> %57, i64 4
  %912 = and i1 true, %910
  %913 = and i1 %911, %912
  %914 = extractelement <8 x float> %869, i32 0
  %915 = select i1 %913, float %914, float 0.000000e+00
  %916 = insertelement <8 x float> %906, float %915, i64 4
  %917 = xor i1 %913, true
  %918 = and i1 %911, %917
  %919 = insertelement <8 x i1> %909, i1 %918, i64 4
  %920 = extractelement <8 x i1> %57, i32 0
  %921 = extractelement <8 x i1> %57, i64 5
  %922 = and i1 true, %920
  %923 = and i1 %921, %922
  %924 = extractelement <8 x float> %869, i32 0
  %925 = select i1 %923, float %924, float 0.000000e+00
  %926 = insertelement <8 x float> %916, float %925, i64 5
  %927 = xor i1 %923, true
  %928 = and i1 %921, %927
  %929 = insertelement <8 x i1> %919, i1 %928, i64 5
  %930 = extractelement <8 x i1> %57, i32 0
  %931 = extractelement <8 x i1> %57, i64 6
  %932 = and i1 true, %930
  %933 = and i1 %931, %932
  %934 = extractelement <8 x float> %869, i32 0
  %935 = select i1 %933, float %934, float 0.000000e+00
  %936 = insertelement <8 x float> %926, float %935, i64 6
  %937 = xor i1 %933, true
  %938 = and i1 %931, %937
  %939 = insertelement <8 x i1> %929, i1 %938, i64 6
  %940 = extractelement <8 x i1> %57, i32 0
  %941 = extractelement <8 x i1> %57, i64 7
  %942 = and i1 true, %940
  %943 = and i1 %941, %942
  %944 = extractelement <8 x float> %869, i32 0
  %945 = select i1 %943, float %944, float 0.000000e+00
  %946 = insertelement <8 x float> %936, float %945, i64 7
  %947 = xor i1 %943, true
  %948 = and i1 %941, %947
  %949 = insertelement <8 x i1> %939, i1 %948, i64 7
  %950 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %951 = bitcast <8 x i1> %57 to i8
  %952 = call i8 @llvm.cttz.i8(i8 %951, i1 false)
  %953 = zext i8 %952 to i32
  %954 = select i1 %950, i32 %953, i32 0
  %955 = extractelement <8 x float> %946, i32 %954
  %956 = call float @llvm.maxnum.f32(float 0xFFF0000000000000, float %955)
  store float %956, ptr %.spill31, align 4
  %957 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %958 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %959 = extractvalue { <8 x ptr>, <8 x i64> } %957, 0
  %960 = select <8 x i1> %57, <8 x ptr> %958, <8 x ptr> %959
  %961 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %962 = extractvalue { <8 x ptr>, <8 x i64> } %957, 1
  %963 = select <8 x i1> %57, <8 x i64> %961, <8 x i64> %962
  %964 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %960, 0
  %965 = insertvalue { <8 x ptr>, <8 x i64> } %964, <8 x i64> %963, 1
  store { <8 x ptr>, <8 x i64> } %965, ptr %tile_snapshot.spill32, align 64
  %966 = load <8 x i64>, ptr %.slot33, align 64
  %967 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %966
  store <8 x i64> %967, ptr %.slot33, align 64
  br label %direct.schedule.26

direct.schedule.26:                               ; preds = %direct.schedule.27, %direct.schedule.25
  %.state153 = load <8 x i64>, ptr %.slot33, align 64
  %968 = icmp slt <8 x i64> %.state153, splat (i64 8)
  %969 = extractelement <8 x i1> %968, i32 0
  br i1 %969, label %direct.true154, label %direct.false155

direct.schedule.27:                               ; preds = %direct.true154
  %tile_snapshot.spill.load156 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %970 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 0
  %971 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load156, 1
  %.state157 = load <8 x i64>, ptr %.slot33, align 64
  %972 = add <8 x i64> %971, %.state157
  %973 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %970, 0
  %974 = insertvalue { <8 x ptr>, <8 x i64> } %973, <8 x i64> %972, 1
  %975 = extractvalue { <8 x ptr>, <8 x i64> } %974, 0
  %976 = extractvalue { <8 x ptr>, <8 x i64> } %974, 1
  %977 = getelementptr i8, <8 x ptr> %975, <8 x i64> %976
  %978 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %977, <8 x i1> %57, <8 x i8> zeroinitializer)
  %979 = icmp ne <8 x i8> %978, zeroinitializer
  %tile_snapshot.spill.load158 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %980 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 0
  %981 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load158, 1
  %.state159 = load <8 x i64>, ptr %.slot33, align 64
  %982 = mul <8 x i64> %.state159, splat (i64 32)
  %983 = add <8 x i64> %981, %982
  %984 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %980, 0
  %985 = insertvalue { <8 x ptr>, <8 x i64> } %984, <8 x i64> %983, 1
  %986 = extractvalue { <8 x ptr>, <8 x i64> } %985, 0
  %987 = extractvalue { <8 x ptr>, <8 x i64> } %985, 1
  %988 = getelementptr i8, <8 x ptr> %986, <8 x i64> %987
  %989 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %988, <8 x i1> %57, <8 x float> zeroinitializer)
  %.spill.load160 = load float, ptr %.spill31, align 4
  %.splatinsert161 = insertelement <8 x float> poison, float %.spill.load160, i64 0
  %.splat162 = shufflevector <8 x float> %.splatinsert161, <8 x float> poison, <8 x i32> zeroinitializer
  %990 = fsub <8 x float> %989, %.splat162
  %991 = select <8 x i1> %57, <8 x float> %990, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %991)
  %992 = select <8 x i1> %979, <8 x float> %native.exp, <8 x float> zeroinitializer
  %tile_snapshot.spill.load163 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %993 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 0
  %994 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load163, 1
  %.state164 = load <8 x i64>, ptr %.slot33, align 64
  %995 = mul <8 x i64> %.state164, splat (i64 32)
  %996 = add <8 x i64> %994, %995
  %997 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %993, 0
  %998 = insertvalue { <8 x ptr>, <8 x i64> } %997, <8 x i64> %996, 1
  %999 = extractvalue { <8 x ptr>, <8 x i64> } %998, 0
  %1000 = extractvalue { <8 x ptr>, <8 x i64> } %998, 1
  %1001 = getelementptr i8, <8 x ptr> %999, <8 x i64> %1000
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %992, <8 x ptr> align 1 %1001, <8 x i1> %57)
  %.state165 = load <8 x i64>, ptr %.slot33, align 64
  %1002 = add <8 x i64> %.state165, splat (i64 1)
  %1003 = load <8 x i64>, ptr %.slot33, align 64
  %1004 = select <8 x i1> %57, <8 x i64> %1002, <8 x i64> %1003
  store <8 x i64> %1004, ptr %.slot33, align 64
  br label %direct.schedule.26

direct.schedule.28:                               ; preds = %direct.false155
  %.spill.load166 = load <8 x i1>, ptr %.spill14, align 1
  %1005 = and <8 x i1> %57, %.spill.load166
  %1006 = xor <8 x i1> %.spill.load166, splat (i1 true)
  %1007 = and <8 x i1> %57, %1006
  %1008 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1005)
  %1009 = bitcast <8 x i1> %1005 to i8
  %1010 = call i8 @llvm.cttz.i8(i8 %1009, i1 false)
  %1011 = zext i8 %1010 to i32
  %1012 = select i1 %1008, i32 %1011, i32 0
  %tile_snapshot.spill.load167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %1013 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 0
  %1014 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 1
  %1015 = add <8 x i64> %1014, splat (i64 8)
  %1016 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1013, 0
  %1017 = insertvalue { <8 x ptr>, <8 x i64> } %1016, <8 x i64> %1015, 1
  %1018 = extractvalue { <8 x ptr>, <8 x i64> } %1017, 0
  %1019 = extractvalue { <8 x ptr>, <8 x i64> } %1017, 1
  %1020 = getelementptr i8, <8 x ptr> %1018, <8 x i64> %1019
  %1021 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %1020, <8 x i1> %1005, <8 x i8> zeroinitializer)
  %1022 = icmp ne <8 x i8> %1021, zeroinitializer
  %tile_snapshot.spill.load168 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %1023 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 0
  %1024 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load168, 1
  %1025 = add <8 x i64> %1024, splat (i64 256)
  %1026 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1023, 0
  %1027 = insertvalue { <8 x ptr>, <8 x i64> } %1026, <8 x i64> %1025, 1
  %1028 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %1029 = extractvalue { <8 x ptr>, <8 x i64> } %1027, 1
  %1030 = extractelement <8 x ptr> %1028, i32 0
  %1031 = extractelement <8 x i64> %1029, i32 %1012
  %1032 = zext i32 %1012 to i64
  %1033 = mul i64 %1032, 4
  %1034 = sub i64 %1031, %1033
  %1035 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1005)
  %1036 = select i1 %1035, i64 %1034, i64 0
  %private.contiguous.address169 = getelementptr i8, ptr %1030, i64 %1036
  %private.contiguous.load170 = load <8 x float>, ptr %private.contiguous.address169, align 4
  %1037 = select <8 x i1> %1005, <8 x float> %private.contiguous.load170, <8 x float> zeroinitializer
  %.spill.load171 = load float, ptr %.spill31, align 4
  %.splatinsert172 = insertelement <8 x float> poison, float %.spill.load171, i64 0
  %.splat173 = shufflevector <8 x float> %.splatinsert172, <8 x float> poison, <8 x i32> zeroinitializer
  %1038 = fsub <8 x float> %1037, %.splat173
  %1039 = select <8 x i1> %1005, <8 x float> %1038, <8 x float> zeroinitializer
  %native.exp174 = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %1039)
  %1040 = select <8 x i1> %1022, <8 x float> %native.exp174, <8 x float> zeroinitializer
  %tile_snapshot.spill.load175 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1041 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load175, 0
  %1042 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load175, 1
  %1043 = add <8 x i64> %1042, splat (i64 256)
  %1044 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1041, 0
  %1045 = insertvalue { <8 x ptr>, <8 x i64> } %1044, <8 x i64> %1043, 1
  %1046 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1047 = extractvalue { <8 x ptr>, <8 x i64> } %1045, 1
  %1048 = extractelement <8 x ptr> %1046, i32 0
  %1049 = extractelement <8 x i64> %1047, i32 %1012
  %1050 = zext i32 %1012 to i64
  %1051 = mul i64 %1050, 4
  %1052 = sub i64 %1049, %1051
  %1053 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1005)
  %1054 = select i1 %1053, i64 %1052, i64 0
  %private.contiguous.address176 = getelementptr i8, ptr %1048, i64 %1054
  %private.contiguous.preserve177 = load <8 x float>, ptr %private.contiguous.address176, align 4
  %1055 = select <8 x i1> %1005, <8 x float> %1040, <8 x float> %private.contiguous.preserve177
  store <8 x float> %1055, ptr %private.contiguous.address176, align 4
  %1056 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1007)
  %1057 = bitcast <8 x i1> %1007 to i8
  %1058 = call i8 @llvm.cttz.i8(i8 %1057, i1 false)
  %1059 = zext i8 %1058 to i32
  %1060 = select i1 %1056, i32 %1059, i32 0
  br label %direct.schedule.30

direct.schedule.30:                               ; preds = %direct.schedule.28
  %tile_snapshot.spill.load178 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1061 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 0
  %1062 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load178, 1
  %1063 = add <8 x i64> %1062, zeroinitializer
  %1064 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1061, 0
  %1065 = insertvalue { <8 x ptr>, <8 x i64> } %1064, <8 x i64> %1063, 1
  %1066 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1067 = extractvalue { <8 x ptr>, <8 x i64> } %1065, 1
  %1068 = extractelement <8 x ptr> %1066, i32 0
  %1069 = extractelement <8 x i64> %1067, i32 0
  %1070 = sub i64 %1069, 0
  %1071 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1072 = select i1 %1071, i64 %1070, i64 0
  %private.contiguous.address179 = getelementptr i8, ptr %1068, i64 %1072
  %private.contiguous.load180 = load <8 x float>, ptr %private.contiguous.address179, align 4
  %1073 = select <8 x i1> %57, <8 x float> %private.contiguous.load180, <8 x float> zeroinitializer
  %tile_snapshot.spill.load181 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1074 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 0
  %1075 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load181, 1
  %1076 = add <8 x i64> %1075, splat (i64 32)
  %1077 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1074, 0
  %1078 = insertvalue { <8 x ptr>, <8 x i64> } %1077, <8 x i64> %1076, 1
  %1079 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1080 = extractvalue { <8 x ptr>, <8 x i64> } %1078, 1
  %1081 = extractelement <8 x ptr> %1079, i32 0
  %1082 = extractelement <8 x i64> %1080, i32 0
  %1083 = sub i64 %1082, 0
  %1084 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1085 = select i1 %1084, i64 %1083, i64 0
  %private.contiguous.address182 = getelementptr i8, ptr %1081, i64 %1085
  %private.contiguous.load183 = load <8 x float>, ptr %private.contiguous.address182, align 4
  %1086 = select <8 x i1> %57, <8 x float> %private.contiguous.load183, <8 x float> zeroinitializer
  %tile_snapshot.spill.load184 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1087 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 0
  %1088 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load184, 1
  %1089 = add <8 x i64> %1088, splat (i64 64)
  %1090 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1087, 0
  %1091 = insertvalue { <8 x ptr>, <8 x i64> } %1090, <8 x i64> %1089, 1
  %1092 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1093 = extractvalue { <8 x ptr>, <8 x i64> } %1091, 1
  %1094 = extractelement <8 x ptr> %1092, i32 0
  %1095 = extractelement <8 x i64> %1093, i32 0
  %1096 = sub i64 %1095, 0
  %1097 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1098 = select i1 %1097, i64 %1096, i64 0
  %private.contiguous.address185 = getelementptr i8, ptr %1094, i64 %1098
  %private.contiguous.load186 = load <8 x float>, ptr %private.contiguous.address185, align 4
  %1099 = select <8 x i1> %57, <8 x float> %private.contiguous.load186, <8 x float> zeroinitializer
  %tile_snapshot.spill.load187 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1100 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 0
  %1101 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load187, 1
  %1102 = add <8 x i64> %1101, splat (i64 96)
  %1103 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1100, 0
  %1104 = insertvalue { <8 x ptr>, <8 x i64> } %1103, <8 x i64> %1102, 1
  %1105 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1106 = extractvalue { <8 x ptr>, <8 x i64> } %1104, 1
  %1107 = extractelement <8 x ptr> %1105, i32 0
  %1108 = extractelement <8 x i64> %1106, i32 0
  %1109 = sub i64 %1108, 0
  %1110 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1111 = select i1 %1110, i64 %1109, i64 0
  %private.contiguous.address188 = getelementptr i8, ptr %1107, i64 %1111
  %private.contiguous.load189 = load <8 x float>, ptr %private.contiguous.address188, align 4
  %1112 = select <8 x i1> %57, <8 x float> %private.contiguous.load189, <8 x float> zeroinitializer
  %1113 = load <8 x i64>, ptr %.slot34, align 64
  %1114 = select <8 x i1> %57, <8 x i64> splat (i64 4), <8 x i64> %1113
  store <8 x i64> %1114, ptr %.slot34, align 64
  %1115 = load <8 x float>, ptr %.slot35, align 32
  %1116 = select <8 x i1> %57, <8 x float> %1073, <8 x float> %1115
  store <8 x float> %1116, ptr %.slot35, align 32
  %1117 = load <8 x float>, ptr %.slot36, align 32
  %1118 = select <8 x i1> %57, <8 x float> %1086, <8 x float> %1117
  store <8 x float> %1118, ptr %.slot36, align 32
  %1119 = load <8 x float>, ptr %.slot37, align 32
  %1120 = select <8 x i1> %57, <8 x float> %1099, <8 x float> %1119
  store <8 x float> %1120, ptr %.slot37, align 32
  %1121 = load <8 x float>, ptr %.slot38, align 32
  %1122 = select <8 x i1> %57, <8 x float> %1112, <8 x float> %1121
  store <8 x float> %1122, ptr %.slot38, align 32
  br label %direct.schedule.31

direct.schedule.31:                               ; preds = %direct.schedule.32, %direct.schedule.30
  %.state190 = load <8 x i64>, ptr %.slot34, align 64
  %1123 = icmp slt <8 x i64> %.state190, splat (i64 8)
  %1124 = extractelement <8 x i1> %1123, i32 0
  br i1 %1124, label %direct.true191, label %direct.false192

direct.schedule.32:                               ; preds = %direct.true191
  %.state193 = load <8 x i64>, ptr %.slot34, align 64
  %1125 = add <8 x i64> %.state193, zeroinitializer
  %tile_snapshot.spill.load194 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1126 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 0
  %1127 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load194, 1
  %1128 = mul <8 x i64> %1125, splat (i64 32)
  %1129 = add <8 x i64> %1127, %1128
  %1130 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1126, 0
  %1131 = insertvalue { <8 x ptr>, <8 x i64> } %1130, <8 x i64> %1129, 1
  %1132 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 0
  %1133 = extractvalue { <8 x ptr>, <8 x i64> } %1131, 1
  %1134 = getelementptr i8, <8 x ptr> %1132, <8 x i64> %1133
  %1135 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1134, <8 x i1> %57, <8 x float> zeroinitializer)
  %.state195 = load <8 x float>, ptr %.slot35, align 32
  %1136 = fadd <8 x float> %.state195, %1135
  %.state196 = load <8 x i64>, ptr %.slot34, align 64
  %1137 = add <8 x i64> %.state196, splat (i64 1)
  %tile_snapshot.spill.load197 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1138 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load197, 0
  %1139 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load197, 1
  %1140 = mul <8 x i64> %1137, splat (i64 32)
  %1141 = add <8 x i64> %1139, %1140
  %1142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1138, 0
  %1143 = insertvalue { <8 x ptr>, <8 x i64> } %1142, <8 x i64> %1141, 1
  %1144 = extractvalue { <8 x ptr>, <8 x i64> } %1143, 0
  %1145 = extractvalue { <8 x ptr>, <8 x i64> } %1143, 1
  %1146 = getelementptr i8, <8 x ptr> %1144, <8 x i64> %1145
  %1147 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1146, <8 x i1> %57, <8 x float> zeroinitializer)
  %.state198 = load <8 x float>, ptr %.slot36, align 32
  %1148 = fadd <8 x float> %.state198, %1147
  %.state199 = load <8 x i64>, ptr %.slot34, align 64
  %1149 = add <8 x i64> %.state199, splat (i64 2)
  %tile_snapshot.spill.load200 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1150 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 0
  %1151 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load200, 1
  %1152 = mul <8 x i64> %1149, splat (i64 32)
  %1153 = add <8 x i64> %1151, %1152
  %1154 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1150, 0
  %1155 = insertvalue { <8 x ptr>, <8 x i64> } %1154, <8 x i64> %1153, 1
  %1156 = extractvalue { <8 x ptr>, <8 x i64> } %1155, 0
  %1157 = extractvalue { <8 x ptr>, <8 x i64> } %1155, 1
  %1158 = getelementptr i8, <8 x ptr> %1156, <8 x i64> %1157
  %1159 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1158, <8 x i1> %57, <8 x float> zeroinitializer)
  %.state201 = load <8 x float>, ptr %.slot37, align 32
  %1160 = fadd <8 x float> %.state201, %1159
  %.state202 = load <8 x i64>, ptr %.slot34, align 64
  %1161 = add <8 x i64> %.state202, splat (i64 3)
  %tile_snapshot.spill.load203 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load203, 0
  %1163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load203, 1
  %1164 = mul <8 x i64> %1161, splat (i64 32)
  %1165 = add <8 x i64> %1163, %1164
  %1166 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1162, 0
  %1167 = insertvalue { <8 x ptr>, <8 x i64> } %1166, <8 x i64> %1165, 1
  %1168 = extractvalue { <8 x ptr>, <8 x i64> } %1167, 0
  %1169 = extractvalue { <8 x ptr>, <8 x i64> } %1167, 1
  %1170 = getelementptr i8, <8 x ptr> %1168, <8 x i64> %1169
  %1171 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1170, <8 x i1> %57, <8 x float> zeroinitializer)
  %.state204 = load <8 x float>, ptr %.slot38, align 32
  %1172 = fadd <8 x float> %.state204, %1171
  %.state205 = load <8 x i64>, ptr %.slot34, align 64
  %1173 = add <8 x i64> %.state205, splat (i64 4)
  %1174 = load <8 x i64>, ptr %.slot34, align 64
  %1175 = select <8 x i1> %57, <8 x i64> %1173, <8 x i64> %1174
  store <8 x i64> %1175, ptr %.slot34, align 64
  %1176 = load <8 x float>, ptr %.slot35, align 32
  %1177 = select <8 x i1> %57, <8 x float> %1136, <8 x float> %1176
  store <8 x float> %1177, ptr %.slot35, align 32
  %1178 = load <8 x float>, ptr %.slot36, align 32
  %1179 = select <8 x i1> %57, <8 x float> %1148, <8 x float> %1178
  store <8 x float> %1179, ptr %.slot36, align 32
  %1180 = load <8 x float>, ptr %.slot37, align 32
  %1181 = select <8 x i1> %57, <8 x float> %1160, <8 x float> %1180
  store <8 x float> %1181, ptr %.slot37, align 32
  %1182 = load <8 x float>, ptr %.slot38, align 32
  %1183 = select <8 x i1> %57, <8 x float> %1172, <8 x float> %1182
  store <8 x float> %1183, ptr %.slot38, align 32
  br label %direct.schedule.31

direct.schedule.33:                               ; preds = %direct.false192
  %.spill.load206 = load <8 x i1>, ptr %.spill14, align 1
  %1184 = and <8 x i1> %57, %.spill.load206
  %1185 = xor <8 x i1> %.spill.load206, splat (i1 true)
  %1186 = and <8 x i1> %57, %1185
  %1187 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1184)
  %1188 = bitcast <8 x i1> %1184 to i8
  %1189 = call i8 @llvm.cttz.i8(i8 %1188, i1 false)
  %1190 = zext i8 %1189 to i32
  %1191 = select i1 %1187, i32 %1190, i32 0
  %tile_snapshot.spill.load207 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load207, 0
  %1193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load207, 1
  %1194 = add <8 x i64> %1193, splat (i64 256)
  %1195 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1192, 0
  %1196 = insertvalue { <8 x ptr>, <8 x i64> } %1195, <8 x i64> %1194, 1
  %1197 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1198 = extractvalue { <8 x ptr>, <8 x i64> } %1196, 1
  %1199 = extractelement <8 x ptr> %1197, i32 0
  %1200 = extractelement <8 x i64> %1198, i32 %1191
  %1201 = zext i32 %1191 to i64
  %1202 = mul i64 %1201, 4
  %1203 = sub i64 %1200, %1202
  %1204 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1184)
  %1205 = select i1 %1204, i64 %1203, i64 0
  %private.contiguous.address208 = getelementptr i8, ptr %1199, i64 %1205
  %private.contiguous.load209 = load <8 x float>, ptr %private.contiguous.address208, align 4
  %1206 = select <8 x i1> %1184, <8 x float> %private.contiguous.load209, <8 x float> zeroinitializer
  %.state210 = load <8 x float>, ptr %.slot35, align 32
  %1207 = fadd <8 x float> %.state210, %1206
  %1208 = load <8 x float>, ptr %.slot39, align 32
  %1209 = select <8 x i1> %1184, <8 x float> %1207, <8 x float> %1208
  store <8 x float> %1209, ptr %.slot39, align 32
  %1210 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1186)
  %1211 = bitcast <8 x i1> %1186 to i8
  %1212 = call i8 @llvm.cttz.i8(i8 %1211, i1 false)
  %1213 = zext i8 %1212 to i32
  %1214 = select i1 %1210, i32 %1213, i32 0
  %.state211 = load <8 x float>, ptr %.slot35, align 32
  %1215 = load <8 x float>, ptr %.slot39, align 32
  %1216 = select <8 x i1> %1186, <8 x float> %.state211, <8 x float> %1215
  store <8 x float> %1216, ptr %.slot39, align 32
  br label %direct.schedule.35

direct.schedule.35:                               ; preds = %direct.schedule.33
  %.state212 = load <8 x float>, ptr %.slot39, align 32
  %.state213 = load <8 x float>, ptr %.slot36, align 32
  %1217 = fadd <8 x float> %.state212, %.state213
  %.state214 = load <8 x float>, ptr %.slot37, align 32
  %1218 = fadd <8 x float> %1217, %.state214
  %.state215 = load <8 x float>, ptr %.slot38, align 32
  %1219 = fadd <8 x float> %1218, %.state215
  %.spill.load216 = load <8 x i32>, ptr %.spill28, align 32
  %1220 = extractelement <8 x i32> %.spill.load216, i64 0
  %1221 = icmp ult i32 %1220, 8
  %1222 = select i1 %1221, i32 %1220, i32 0
  %1223 = extractelement <8 x i1> %57, i32 %1222
  %1224 = extractelement <8 x i1> %57, i64 0
  %1225 = and i1 %1221, %1223
  %1226 = and i1 %1224, %1225
  %1227 = extractelement <8 x float> %1219, i32 %1222
  %1228 = select i1 %1226, float %1227, float 0.000000e+00
  %1229 = insertelement <8 x float> poison, float %1228, i64 0
  %1230 = xor i1 %1226, true
  %1231 = and i1 %1224, %1230
  %1232 = insertelement <8 x i1> poison, i1 %1231, i64 0
  %1233 = extractelement <8 x i32> %.spill.load216, i64 1
  %1234 = icmp ult i32 %1233, 8
  %1235 = select i1 %1234, i32 %1233, i32 0
  %1236 = extractelement <8 x i1> %57, i32 %1235
  %1237 = extractelement <8 x i1> %57, i64 1
  %1238 = and i1 %1234, %1236
  %1239 = and i1 %1237, %1238
  %1240 = extractelement <8 x float> %1219, i32 %1235
  %1241 = select i1 %1239, float %1240, float 0.000000e+00
  %1242 = insertelement <8 x float> %1229, float %1241, i64 1
  %1243 = xor i1 %1239, true
  %1244 = and i1 %1237, %1243
  %1245 = insertelement <8 x i1> %1232, i1 %1244, i64 1
  %1246 = extractelement <8 x i32> %.spill.load216, i64 2
  %1247 = icmp ult i32 %1246, 8
  %1248 = select i1 %1247, i32 %1246, i32 0
  %1249 = extractelement <8 x i1> %57, i32 %1248
  %1250 = extractelement <8 x i1> %57, i64 2
  %1251 = and i1 %1247, %1249
  %1252 = and i1 %1250, %1251
  %1253 = extractelement <8 x float> %1219, i32 %1248
  %1254 = select i1 %1252, float %1253, float 0.000000e+00
  %1255 = insertelement <8 x float> %1242, float %1254, i64 2
  %1256 = xor i1 %1252, true
  %1257 = and i1 %1250, %1256
  %1258 = insertelement <8 x i1> %1245, i1 %1257, i64 2
  %1259 = extractelement <8 x i32> %.spill.load216, i64 3
  %1260 = icmp ult i32 %1259, 8
  %1261 = select i1 %1260, i32 %1259, i32 0
  %1262 = extractelement <8 x i1> %57, i32 %1261
  %1263 = extractelement <8 x i1> %57, i64 3
  %1264 = and i1 %1260, %1262
  %1265 = and i1 %1263, %1264
  %1266 = extractelement <8 x float> %1219, i32 %1261
  %1267 = select i1 %1265, float %1266, float 0.000000e+00
  %1268 = insertelement <8 x float> %1255, float %1267, i64 3
  %1269 = xor i1 %1265, true
  %1270 = and i1 %1263, %1269
  %1271 = insertelement <8 x i1> %1258, i1 %1270, i64 3
  %1272 = extractelement <8 x i32> %.spill.load216, i64 4
  %1273 = icmp ult i32 %1272, 8
  %1274 = select i1 %1273, i32 %1272, i32 0
  %1275 = extractelement <8 x i1> %57, i32 %1274
  %1276 = extractelement <8 x i1> %57, i64 4
  %1277 = and i1 %1273, %1275
  %1278 = and i1 %1276, %1277
  %1279 = extractelement <8 x float> %1219, i32 %1274
  %1280 = select i1 %1278, float %1279, float 0.000000e+00
  %1281 = insertelement <8 x float> %1268, float %1280, i64 4
  %1282 = xor i1 %1278, true
  %1283 = and i1 %1276, %1282
  %1284 = insertelement <8 x i1> %1271, i1 %1283, i64 4
  %1285 = extractelement <8 x i32> %.spill.load216, i64 5
  %1286 = icmp ult i32 %1285, 8
  %1287 = select i1 %1286, i32 %1285, i32 0
  %1288 = extractelement <8 x i1> %57, i32 %1287
  %1289 = extractelement <8 x i1> %57, i64 5
  %1290 = and i1 %1286, %1288
  %1291 = and i1 %1289, %1290
  %1292 = extractelement <8 x float> %1219, i32 %1287
  %1293 = select i1 %1291, float %1292, float 0.000000e+00
  %1294 = insertelement <8 x float> %1281, float %1293, i64 5
  %1295 = xor i1 %1291, true
  %1296 = and i1 %1289, %1295
  %1297 = insertelement <8 x i1> %1284, i1 %1296, i64 5
  %1298 = extractelement <8 x i32> %.spill.load216, i64 6
  %1299 = icmp ult i32 %1298, 8
  %1300 = select i1 %1299, i32 %1298, i32 0
  %1301 = extractelement <8 x i1> %57, i32 %1300
  %1302 = extractelement <8 x i1> %57, i64 6
  %1303 = and i1 %1299, %1301
  %1304 = and i1 %1302, %1303
  %1305 = extractelement <8 x float> %1219, i32 %1300
  %1306 = select i1 %1304, float %1305, float 0.000000e+00
  %1307 = insertelement <8 x float> %1294, float %1306, i64 6
  %1308 = xor i1 %1304, true
  %1309 = and i1 %1302, %1308
  %1310 = insertelement <8 x i1> %1297, i1 %1309, i64 6
  %1311 = extractelement <8 x i32> %.spill.load216, i64 7
  %1312 = icmp ult i32 %1311, 8
  %1313 = select i1 %1312, i32 %1311, i32 0
  %1314 = extractelement <8 x i1> %57, i32 %1313
  %1315 = extractelement <8 x i1> %57, i64 7
  %1316 = and i1 %1312, %1314
  %1317 = and i1 %1315, %1316
  %1318 = extractelement <8 x float> %1219, i32 %1313
  %1319 = select i1 %1317, float %1318, float 0.000000e+00
  %1320 = insertelement <8 x float> %1307, float %1319, i64 7
  %1321 = xor i1 %1317, true
  %1322 = and i1 %1315, %1321
  %1323 = insertelement <8 x i1> %1310, i1 %1322, i64 7
  %1324 = fadd <8 x float> %1219, %1320
  %.spill.load217 = load <8 x i32>, ptr %.spill29, align 32
  %1325 = extractelement <8 x i32> %.spill.load217, i64 0
  %1326 = icmp ult i32 %1325, 8
  %1327 = select i1 %1326, i32 %1325, i32 0
  %1328 = extractelement <8 x i1> %57, i32 %1327
  %1329 = extractelement <8 x i1> %57, i64 0
  %1330 = and i1 %1326, %1328
  %1331 = and i1 %1329, %1330
  %1332 = extractelement <8 x float> %1324, i32 %1327
  %1333 = select i1 %1331, float %1332, float 0.000000e+00
  %1334 = insertelement <8 x float> poison, float %1333, i64 0
  %1335 = xor i1 %1331, true
  %1336 = and i1 %1329, %1335
  %1337 = insertelement <8 x i1> poison, i1 %1336, i64 0
  %1338 = extractelement <8 x i32> %.spill.load217, i64 1
  %1339 = icmp ult i32 %1338, 8
  %1340 = select i1 %1339, i32 %1338, i32 0
  %1341 = extractelement <8 x i1> %57, i32 %1340
  %1342 = extractelement <8 x i1> %57, i64 1
  %1343 = and i1 %1339, %1341
  %1344 = and i1 %1342, %1343
  %1345 = extractelement <8 x float> %1324, i32 %1340
  %1346 = select i1 %1344, float %1345, float 0.000000e+00
  %1347 = insertelement <8 x float> %1334, float %1346, i64 1
  %1348 = xor i1 %1344, true
  %1349 = and i1 %1342, %1348
  %1350 = insertelement <8 x i1> %1337, i1 %1349, i64 1
  %1351 = extractelement <8 x i32> %.spill.load217, i64 2
  %1352 = icmp ult i32 %1351, 8
  %1353 = select i1 %1352, i32 %1351, i32 0
  %1354 = extractelement <8 x i1> %57, i32 %1353
  %1355 = extractelement <8 x i1> %57, i64 2
  %1356 = and i1 %1352, %1354
  %1357 = and i1 %1355, %1356
  %1358 = extractelement <8 x float> %1324, i32 %1353
  %1359 = select i1 %1357, float %1358, float 0.000000e+00
  %1360 = insertelement <8 x float> %1347, float %1359, i64 2
  %1361 = xor i1 %1357, true
  %1362 = and i1 %1355, %1361
  %1363 = insertelement <8 x i1> %1350, i1 %1362, i64 2
  %1364 = extractelement <8 x i32> %.spill.load217, i64 3
  %1365 = icmp ult i32 %1364, 8
  %1366 = select i1 %1365, i32 %1364, i32 0
  %1367 = extractelement <8 x i1> %57, i32 %1366
  %1368 = extractelement <8 x i1> %57, i64 3
  %1369 = and i1 %1365, %1367
  %1370 = and i1 %1368, %1369
  %1371 = extractelement <8 x float> %1324, i32 %1366
  %1372 = select i1 %1370, float %1371, float 0.000000e+00
  %1373 = insertelement <8 x float> %1360, float %1372, i64 3
  %1374 = xor i1 %1370, true
  %1375 = and i1 %1368, %1374
  %1376 = insertelement <8 x i1> %1363, i1 %1375, i64 3
  %1377 = extractelement <8 x i32> %.spill.load217, i64 4
  %1378 = icmp ult i32 %1377, 8
  %1379 = select i1 %1378, i32 %1377, i32 0
  %1380 = extractelement <8 x i1> %57, i32 %1379
  %1381 = extractelement <8 x i1> %57, i64 4
  %1382 = and i1 %1378, %1380
  %1383 = and i1 %1381, %1382
  %1384 = extractelement <8 x float> %1324, i32 %1379
  %1385 = select i1 %1383, float %1384, float 0.000000e+00
  %1386 = insertelement <8 x float> %1373, float %1385, i64 4
  %1387 = xor i1 %1383, true
  %1388 = and i1 %1381, %1387
  %1389 = insertelement <8 x i1> %1376, i1 %1388, i64 4
  %1390 = extractelement <8 x i32> %.spill.load217, i64 5
  %1391 = icmp ult i32 %1390, 8
  %1392 = select i1 %1391, i32 %1390, i32 0
  %1393 = extractelement <8 x i1> %57, i32 %1392
  %1394 = extractelement <8 x i1> %57, i64 5
  %1395 = and i1 %1391, %1393
  %1396 = and i1 %1394, %1395
  %1397 = extractelement <8 x float> %1324, i32 %1392
  %1398 = select i1 %1396, float %1397, float 0.000000e+00
  %1399 = insertelement <8 x float> %1386, float %1398, i64 5
  %1400 = xor i1 %1396, true
  %1401 = and i1 %1394, %1400
  %1402 = insertelement <8 x i1> %1389, i1 %1401, i64 5
  %1403 = extractelement <8 x i32> %.spill.load217, i64 6
  %1404 = icmp ult i32 %1403, 8
  %1405 = select i1 %1404, i32 %1403, i32 0
  %1406 = extractelement <8 x i1> %57, i32 %1405
  %1407 = extractelement <8 x i1> %57, i64 6
  %1408 = and i1 %1404, %1406
  %1409 = and i1 %1407, %1408
  %1410 = extractelement <8 x float> %1324, i32 %1405
  %1411 = select i1 %1409, float %1410, float 0.000000e+00
  %1412 = insertelement <8 x float> %1399, float %1411, i64 6
  %1413 = xor i1 %1409, true
  %1414 = and i1 %1407, %1413
  %1415 = insertelement <8 x i1> %1402, i1 %1414, i64 6
  %1416 = extractelement <8 x i32> %.spill.load217, i64 7
  %1417 = icmp ult i32 %1416, 8
  %1418 = select i1 %1417, i32 %1416, i32 0
  %1419 = extractelement <8 x i1> %57, i32 %1418
  %1420 = extractelement <8 x i1> %57, i64 7
  %1421 = and i1 %1417, %1419
  %1422 = and i1 %1420, %1421
  %1423 = extractelement <8 x float> %1324, i32 %1418
  %1424 = select i1 %1422, float %1423, float 0.000000e+00
  %1425 = insertelement <8 x float> %1412, float %1424, i64 7
  %1426 = xor i1 %1422, true
  %1427 = and i1 %1420, %1426
  %1428 = insertelement <8 x i1> %1415, i1 %1427, i64 7
  %1429 = fadd <8 x float> %1324, %1425
  %.spill.load218 = load <8 x i32>, ptr %.spill30, align 32
  %1430 = extractelement <8 x i32> %.spill.load218, i64 0
  %1431 = icmp ult i32 %1430, 8
  %1432 = select i1 %1431, i32 %1430, i32 0
  %1433 = extractelement <8 x i1> %57, i32 %1432
  %1434 = extractelement <8 x i1> %57, i64 0
  %1435 = and i1 %1431, %1433
  %1436 = and i1 %1434, %1435
  %1437 = extractelement <8 x float> %1429, i32 %1432
  %1438 = select i1 %1436, float %1437, float 0.000000e+00
  %1439 = insertelement <8 x float> poison, float %1438, i64 0
  %1440 = xor i1 %1436, true
  %1441 = and i1 %1434, %1440
  %1442 = insertelement <8 x i1> poison, i1 %1441, i64 0
  %1443 = extractelement <8 x i32> %.spill.load218, i64 1
  %1444 = icmp ult i32 %1443, 8
  %1445 = select i1 %1444, i32 %1443, i32 0
  %1446 = extractelement <8 x i1> %57, i32 %1445
  %1447 = extractelement <8 x i1> %57, i64 1
  %1448 = and i1 %1444, %1446
  %1449 = and i1 %1447, %1448
  %1450 = extractelement <8 x float> %1429, i32 %1445
  %1451 = select i1 %1449, float %1450, float 0.000000e+00
  %1452 = insertelement <8 x float> %1439, float %1451, i64 1
  %1453 = xor i1 %1449, true
  %1454 = and i1 %1447, %1453
  %1455 = insertelement <8 x i1> %1442, i1 %1454, i64 1
  %1456 = extractelement <8 x i32> %.spill.load218, i64 2
  %1457 = icmp ult i32 %1456, 8
  %1458 = select i1 %1457, i32 %1456, i32 0
  %1459 = extractelement <8 x i1> %57, i32 %1458
  %1460 = extractelement <8 x i1> %57, i64 2
  %1461 = and i1 %1457, %1459
  %1462 = and i1 %1460, %1461
  %1463 = extractelement <8 x float> %1429, i32 %1458
  %1464 = select i1 %1462, float %1463, float 0.000000e+00
  %1465 = insertelement <8 x float> %1452, float %1464, i64 2
  %1466 = xor i1 %1462, true
  %1467 = and i1 %1460, %1466
  %1468 = insertelement <8 x i1> %1455, i1 %1467, i64 2
  %1469 = extractelement <8 x i32> %.spill.load218, i64 3
  %1470 = icmp ult i32 %1469, 8
  %1471 = select i1 %1470, i32 %1469, i32 0
  %1472 = extractelement <8 x i1> %57, i32 %1471
  %1473 = extractelement <8 x i1> %57, i64 3
  %1474 = and i1 %1470, %1472
  %1475 = and i1 %1473, %1474
  %1476 = extractelement <8 x float> %1429, i32 %1471
  %1477 = select i1 %1475, float %1476, float 0.000000e+00
  %1478 = insertelement <8 x float> %1465, float %1477, i64 3
  %1479 = xor i1 %1475, true
  %1480 = and i1 %1473, %1479
  %1481 = insertelement <8 x i1> %1468, i1 %1480, i64 3
  %1482 = extractelement <8 x i32> %.spill.load218, i64 4
  %1483 = icmp ult i32 %1482, 8
  %1484 = select i1 %1483, i32 %1482, i32 0
  %1485 = extractelement <8 x i1> %57, i32 %1484
  %1486 = extractelement <8 x i1> %57, i64 4
  %1487 = and i1 %1483, %1485
  %1488 = and i1 %1486, %1487
  %1489 = extractelement <8 x float> %1429, i32 %1484
  %1490 = select i1 %1488, float %1489, float 0.000000e+00
  %1491 = insertelement <8 x float> %1478, float %1490, i64 4
  %1492 = xor i1 %1488, true
  %1493 = and i1 %1486, %1492
  %1494 = insertelement <8 x i1> %1481, i1 %1493, i64 4
  %1495 = extractelement <8 x i32> %.spill.load218, i64 5
  %1496 = icmp ult i32 %1495, 8
  %1497 = select i1 %1496, i32 %1495, i32 0
  %1498 = extractelement <8 x i1> %57, i32 %1497
  %1499 = extractelement <8 x i1> %57, i64 5
  %1500 = and i1 %1496, %1498
  %1501 = and i1 %1499, %1500
  %1502 = extractelement <8 x float> %1429, i32 %1497
  %1503 = select i1 %1501, float %1502, float 0.000000e+00
  %1504 = insertelement <8 x float> %1491, float %1503, i64 5
  %1505 = xor i1 %1501, true
  %1506 = and i1 %1499, %1505
  %1507 = insertelement <8 x i1> %1494, i1 %1506, i64 5
  %1508 = extractelement <8 x i32> %.spill.load218, i64 6
  %1509 = icmp ult i32 %1508, 8
  %1510 = select i1 %1509, i32 %1508, i32 0
  %1511 = extractelement <8 x i1> %57, i32 %1510
  %1512 = extractelement <8 x i1> %57, i64 6
  %1513 = and i1 %1509, %1511
  %1514 = and i1 %1512, %1513
  %1515 = extractelement <8 x float> %1429, i32 %1510
  %1516 = select i1 %1514, float %1515, float 0.000000e+00
  %1517 = insertelement <8 x float> %1504, float %1516, i64 6
  %1518 = xor i1 %1514, true
  %1519 = and i1 %1512, %1518
  %1520 = insertelement <8 x i1> %1507, i1 %1519, i64 6
  %1521 = extractelement <8 x i32> %.spill.load218, i64 7
  %1522 = icmp ult i32 %1521, 8
  %1523 = select i1 %1522, i32 %1521, i32 0
  %1524 = extractelement <8 x i1> %57, i32 %1523
  %1525 = extractelement <8 x i1> %57, i64 7
  %1526 = and i1 %1522, %1524
  %1527 = and i1 %1525, %1526
  %1528 = extractelement <8 x float> %1429, i32 %1523
  %1529 = select i1 %1527, float %1528, float 0.000000e+00
  %1530 = insertelement <8 x float> %1517, float %1529, i64 7
  %1531 = xor i1 %1527, true
  %1532 = and i1 %1525, %1531
  %1533 = insertelement <8 x i1> %1520, i1 %1532, i64 7
  %1534 = fadd <8 x float> %1429, %1530
  %1535 = extractelement <8 x i1> %57, i32 0
  %1536 = extractelement <8 x i1> %57, i64 0
  %1537 = and i1 true, %1535
  %1538 = and i1 %1536, %1537
  %1539 = extractelement <8 x float> %1534, i32 0
  %1540 = select i1 %1538, float %1539, float 0.000000e+00
  %1541 = insertelement <8 x float> poison, float %1540, i64 0
  %1542 = xor i1 %1538, true
  %1543 = and i1 %1536, %1542
  %1544 = insertelement <8 x i1> poison, i1 %1543, i64 0
  %1545 = extractelement <8 x i1> %57, i32 0
  %1546 = extractelement <8 x i1> %57, i64 1
  %1547 = and i1 true, %1545
  %1548 = and i1 %1546, %1547
  %1549 = extractelement <8 x float> %1534, i32 0
  %1550 = select i1 %1548, float %1549, float 0.000000e+00
  %1551 = insertelement <8 x float> %1541, float %1550, i64 1
  %1552 = xor i1 %1548, true
  %1553 = and i1 %1546, %1552
  %1554 = insertelement <8 x i1> %1544, i1 %1553, i64 1
  %1555 = extractelement <8 x i1> %57, i32 0
  %1556 = extractelement <8 x i1> %57, i64 2
  %1557 = and i1 true, %1555
  %1558 = and i1 %1556, %1557
  %1559 = extractelement <8 x float> %1534, i32 0
  %1560 = select i1 %1558, float %1559, float 0.000000e+00
  %1561 = insertelement <8 x float> %1551, float %1560, i64 2
  %1562 = xor i1 %1558, true
  %1563 = and i1 %1556, %1562
  %1564 = insertelement <8 x i1> %1554, i1 %1563, i64 2
  %1565 = extractelement <8 x i1> %57, i32 0
  %1566 = extractelement <8 x i1> %57, i64 3
  %1567 = and i1 true, %1565
  %1568 = and i1 %1566, %1567
  %1569 = extractelement <8 x float> %1534, i32 0
  %1570 = select i1 %1568, float %1569, float 0.000000e+00
  %1571 = insertelement <8 x float> %1561, float %1570, i64 3
  %1572 = xor i1 %1568, true
  %1573 = and i1 %1566, %1572
  %1574 = insertelement <8 x i1> %1564, i1 %1573, i64 3
  %1575 = extractelement <8 x i1> %57, i32 0
  %1576 = extractelement <8 x i1> %57, i64 4
  %1577 = and i1 true, %1575
  %1578 = and i1 %1576, %1577
  %1579 = extractelement <8 x float> %1534, i32 0
  %1580 = select i1 %1578, float %1579, float 0.000000e+00
  %1581 = insertelement <8 x float> %1571, float %1580, i64 4
  %1582 = xor i1 %1578, true
  %1583 = and i1 %1576, %1582
  %1584 = insertelement <8 x i1> %1574, i1 %1583, i64 4
  %1585 = extractelement <8 x i1> %57, i32 0
  %1586 = extractelement <8 x i1> %57, i64 5
  %1587 = and i1 true, %1585
  %1588 = and i1 %1586, %1587
  %1589 = extractelement <8 x float> %1534, i32 0
  %1590 = select i1 %1588, float %1589, float 0.000000e+00
  %1591 = insertelement <8 x float> %1581, float %1590, i64 5
  %1592 = xor i1 %1588, true
  %1593 = and i1 %1586, %1592
  %1594 = insertelement <8 x i1> %1584, i1 %1593, i64 5
  %1595 = extractelement <8 x i1> %57, i32 0
  %1596 = extractelement <8 x i1> %57, i64 6
  %1597 = and i1 true, %1595
  %1598 = and i1 %1596, %1597
  %1599 = extractelement <8 x float> %1534, i32 0
  %1600 = select i1 %1598, float %1599, float 0.000000e+00
  %1601 = insertelement <8 x float> %1591, float %1600, i64 6
  %1602 = xor i1 %1598, true
  %1603 = and i1 %1596, %1602
  %1604 = insertelement <8 x i1> %1594, i1 %1603, i64 6
  %1605 = extractelement <8 x i1> %57, i32 0
  %1606 = extractelement <8 x i1> %57, i64 7
  %1607 = and i1 true, %1605
  %1608 = and i1 %1606, %1607
  %1609 = extractelement <8 x float> %1534, i32 0
  %1610 = select i1 %1608, float %1609, float 0.000000e+00
  %1611 = insertelement <8 x float> %1601, float %1610, i64 7
  %1612 = xor i1 %1608, true
  %1613 = and i1 %1606, %1612
  %1614 = insertelement <8 x i1> %1604, i1 %1613, i64 7
  %1615 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %1616 = bitcast <8 x i1> %57 to i8
  %1617 = call i8 @llvm.cttz.i8(i8 %1616, i1 false)
  %1618 = zext i8 %1617 to i32
  %1619 = select i1 %1615, i32 %1618, i32 0
  %1620 = extractelement <8 x float> %1611, i32 %1619
  %1621 = fadd float 0.000000e+00, %1620
  store float %1621, ptr %.spill40, align 4
  %1622 = load <8 x i64>, ptr %.slot41, align 64
  %1623 = select <8 x i1> %57, <8 x i64> zeroinitializer, <8 x i64> %1622
  store <8 x i64> %1623, ptr %.slot41, align 64
  br label %direct.schedule.36

direct.schedule.36:                               ; preds = %direct.schedule.37, %direct.schedule.35
  %.state219 = load <8 x i64>, ptr %.slot41, align 64
  %1624 = icmp slt <8 x i64> %.state219, splat (i64 8)
  %1625 = extractelement <8 x i1> %1624, i32 0
  br i1 %1625, label %direct.true220, label %direct.false221

direct.schedule.37:                               ; preds = %direct.true220
  %.state222 = load <8 x i64>, ptr %.slot41, align 64
  %1626 = mul <8 x i64> %.state222, splat (i64 8)
  %.spill.load223 = load <8 x i64>, ptr %.spill, align 64
  %1627 = add <8 x i64> %1626, %.spill.load223
  %.spill.load224 = load <8 x i64>, ptr %.spill13, align 64
  %1628 = add <8 x i64> %.spill.load224, zeroinitializer
  %1629 = add <8 x i64> zeroinitializer, %1628
  %1630 = add <8 x i64> zeroinitializer, %1627
  %1631 = mul <8 x i64> %1629, splat (i64 65)
  %1632 = add <8 x i64> %1631, %1630
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1633 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %1634 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.state226 = load <8 x i64>, ptr %.slot41, align 64
  %1635 = mul <8 x i64> %.state226, splat (i64 32)
  %1636 = add <8 x i64> %1634, %1635
  %1637 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1633, 0
  %1638 = insertvalue { <8 x ptr>, <8 x i64> } %1637, <8 x i64> %1636, 1
  %1639 = extractvalue { <8 x ptr>, <8 x i64> } %1638, 0
  %1640 = extractvalue { <8 x ptr>, <8 x i64> } %1638, 1
  %1641 = getelementptr i8, <8 x ptr> %1639, <8 x i64> %1640
  %1642 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %1641, <8 x i1> %57, <8 x float> zeroinitializer)
  %.spill.load227 = load float, ptr %.spill40, align 4
  %.splatinsert228 = insertelement <8 x float> poison, float %.spill.load227, i64 0
  %.splat229 = shufflevector <8 x float> %.splatinsert228, <8 x float> poison, <8 x i32> zeroinitializer
  %1643 = fdiv <8 x float> %1642, %.splat229
  %1644 = extractvalue { ptr, i64 } %33, 0
  %1645 = extractelement <8 x i64> %1632, i32 0
  %1646 = sub i64 %1645, 0
  %1647 = mul i64 %1646, 4
  %buffer.contiguous.address230 = getelementptr i8, ptr %1644, i64 %1647
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1643, ptr align 1 %buffer.contiguous.address230, <8 x i1> %57)
  %.state231 = load <8 x i64>, ptr %.slot41, align 64
  %1648 = add <8 x i64> %.state231, splat (i64 1)
  %1649 = load <8 x i64>, ptr %.slot41, align 64
  %1650 = select <8 x i1> %57, <8 x i64> %1648, <8 x i64> %1649
  store <8 x i64> %1650, ptr %.slot41, align 64
  br label %direct.schedule.36

direct.schedule.38:                               ; preds = %direct.false221
  %.spill.load232 = load <8 x i1>, ptr %.spill14, align 1
  %1651 = and <8 x i1> %57, %.spill.load232
  %1652 = xor <8 x i1> %.spill.load232, splat (i1 true)
  %1653 = and <8 x i1> %57, %1652
  %1654 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1651)
  %1655 = bitcast <8 x i1> %1651 to i8
  %1656 = call i8 @llvm.cttz.i8(i8 %1655, i1 false)
  %1657 = zext i8 %1656 to i32
  %1658 = select i1 %1654, i32 %1657, i32 0
  %.spill.load233 = load <8 x i64>, ptr %.spill, align 64
  %1659 = add <8 x i64> splat (i64 64), %.spill.load233
  %.spill.load234 = load <8 x i64>, ptr %.spill13, align 64
  %1660 = add <8 x i64> %.spill.load234, zeroinitializer
  %1661 = add <8 x i64> zeroinitializer, %1660
  %1662 = add <8 x i64> zeroinitializer, %1659
  %1663 = mul <8 x i64> %1661, splat (i64 65)
  %1664 = add <8 x i64> %1663, %1662
  %tile_snapshot.spill.load235 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %1665 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 0
  %1666 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load235, 1
  %1667 = add <8 x i64> %1666, splat (i64 256)
  %1668 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %1665, 0
  %1669 = insertvalue { <8 x ptr>, <8 x i64> } %1668, <8 x i64> %1667, 1
  %1670 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %1671 = extractvalue { <8 x ptr>, <8 x i64> } %1669, 1
  %1672 = extractelement <8 x ptr> %1670, i32 0
  %1673 = extractelement <8 x i64> %1671, i32 %1658
  %1674 = zext i32 %1658 to i64
  %1675 = mul i64 %1674, 4
  %1676 = sub i64 %1673, %1675
  %1677 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1651)
  %1678 = select i1 %1677, i64 %1676, i64 0
  %private.contiguous.address236 = getelementptr i8, ptr %1672, i64 %1678
  %private.contiguous.load237 = load <8 x float>, ptr %private.contiguous.address236, align 4
  %1679 = select <8 x i1> %1651, <8 x float> %private.contiguous.load237, <8 x float> zeroinitializer
  %.spill.load238 = load float, ptr %.spill40, align 4
  %.splatinsert239 = insertelement <8 x float> poison, float %.spill.load238, i64 0
  %.splat240 = shufflevector <8 x float> %.splatinsert239, <8 x float> poison, <8 x i32> zeroinitializer
  %1680 = fdiv <8 x float> %1679, %.splat240
  %1681 = extractvalue { ptr, i64 } %33, 0
  %1682 = extractelement <8 x i64> %1664, i32 %1658
  %1683 = zext i32 %1658 to i64
  %1684 = sub i64 %1682, %1683
  %1685 = mul i64 %1684, 4
  %buffer.contiguous.address241 = getelementptr i8, ptr %1681, i64 %1685
  call void @llvm.masked.store.v8f32.p0(<8 x float> %1680, ptr align 1 %buffer.contiguous.address241, <8 x i1> %1651)
  %1686 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %1653)
  %1687 = bitcast <8 x i1> %1653 to i8
  %1688 = call i8 @llvm.cttz.i8(i8 %1687, i1 false)
  %1689 = zext i8 %1688 to i32
  %1690 = select i1 %1686, i32 %1689, i32 0
  br label %direct.schedule.40

direct.schedule.40:                               ; preds = %direct.schedule.38
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true69:                                    ; preds = %direct.schedule.6
  br label %direct.schedule.7

direct.false70:                                   ; preds = %direct.schedule.6
  br label %direct.schedule.8

direct.true83:                                    ; preds = %direct.schedule.11
  br label %direct.schedule.12

direct.false84:                                   ; preds = %direct.schedule.11
  br label %direct.schedule.13

direct.true97:                                    ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false98:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true127:                                   ; preds = %direct.schedule.21
  br label %direct.schedule.22

direct.false128:                                  ; preds = %direct.schedule.21
  br label %direct.schedule.23

direct.true154:                                   ; preds = %direct.schedule.26
  br label %direct.schedule.27

direct.false155:                                  ; preds = %direct.schedule.26
  br label %direct.schedule.28

direct.true191:                                   ; preds = %direct.schedule.31
  br label %direct.schedule.32

direct.false192:                                  ; preds = %direct.schedule.31
  br label %direct.schedule.33

direct.true220:                                   ; preds = %direct.schedule.36
  br label %direct.schedule.37

direct.false221:                                  ; preds = %direct.schedule.36
  br label %direct.schedule.38
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: read)
declare <8 x float> @llvm.masked.load.v8f32.p0(ptr captures(none), <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.cttz.i8(i8, i1 immarg) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i64.v8p0(<8 x i64>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i64> @llvm.masked.gather.v8i64.v8p0(<8 x ptr>, <8 x i1>, <8 x i64>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #4

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare float @llvm.maxnum.f32(float, float) #4

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #5 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.masked.store.v8f32.p0(<8 x float>, ptr captures(none), <8 x i1>) #6

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #4 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #5 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }
attributes #6 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }

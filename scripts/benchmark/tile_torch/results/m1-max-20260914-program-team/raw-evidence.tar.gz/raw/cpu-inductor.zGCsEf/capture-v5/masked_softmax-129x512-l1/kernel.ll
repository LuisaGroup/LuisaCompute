; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %0 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace = load ptr, ptr %0, align 8
  %tile_snapshot.private = getelementptr inbounds i8, ptr %private.workspace, i64 0
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.private, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %1 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %2 = insertvalue { <8 x ptr>, <8 x i64> } %1, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %3 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace1 = load ptr, ptr %3, align 8
  %tile_snapshot.private2 = getelementptr inbounds i8, ptr %private.workspace1, i64 16384
  %.splatinsert3 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private2, i64 0
  %.splat4 = shufflevector <8 x ptr> %.splatinsert3, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat4, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %6 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace5 = load ptr, ptr %6, align 8
  %tile_snapshot.private6 = getelementptr inbounds i8, ptr %private.workspace5, i64 49152
  %.splatinsert7 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private6, i64 0
  %.splat8 = shufflevector <8 x ptr> %.splatinsert7, <8 x ptr> poison, <8 x i32> zeroinitializer
  %7 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat8, 0
  %8 = insertvalue { <8 x ptr>, <8 x i64> } %7, <8 x i64> <i64 0, i64 512, i64 1024, i64 1536, i64 2048, i64 2560, i64 3072, i64 3584>, 1
  %9 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace9 = load ptr, ptr %9, align 8
  %tile_snapshot.private10 = getelementptr inbounds i8, ptr %private.workspace9, i64 53248
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %10 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %11 = insertvalue { <8 x ptr>, <8 x i64> } %10, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %12 = getelementptr i8, ptr %launch_config, i64 136
  %private.workspace13 = load ptr, ptr %12, align 8
  %tile_snapshot.private14 = getelementptr inbounds i8, ptr %private.workspace13, i64 69632
  %.splatinsert15 = insertelement <8 x ptr> poison, ptr %tile_snapshot.private14, i64 0
  %.splat16 = shufflevector <8 x ptr> %.splatinsert15, <8 x ptr> poison, <8 x i32> zeroinitializer
  %13 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat16, 0
  %14 = insertvalue { <8 x ptr>, <8 x i64> } %13, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill17 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill17, align 64
  %.slot18 = alloca i64, align 8
  store i64 0, ptr %.slot18, align 4
  %.spill19 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill19, align 64
  %tile_snapshot.spill20 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill20, align 64
  %.slot21 = alloca i64, align 8
  store i64 0, ptr %.slot21, align 4
  %tile_snapshot.spill22 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill22, align 64
  %.slot23 = alloca i64, align 8
  store i64 0, ptr %.slot23, align 4
  %.spill24 = alloca i64, align 8
  store i64 0, ptr %.spill24, align 4
  %.spill25 = alloca i64, align 8
  store i64 0, ptr %.spill25, align 4
  %.spill26 = alloca i64, align 8
  store i64 0, ptr %.spill26, align 4
  %.spill27 = alloca i64, align 8
  store i64 0, ptr %.spill27, align 4
  %.spill28 = alloca i64, align 8
  store i64 0, ptr %.spill28, align 4
  %.slot29 = alloca i64, align 8
  store i64 0, ptr %.slot29, align 4
  %.slot30 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot30, align 32
  %.slot31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot31, align 32
  %.slot32 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot32, align 32
  %.slot33 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot33, align 32
  %.spill34 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill34, align 32
  %tile_snapshot.spill35 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill35, align 64
  %.slot36 = alloca i64, align 8
  store i64 0, ptr %.slot36, align 4
  %.slot37 = alloca i64, align 8
  store i64 0, ptr %.slot37, align 4
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.slot39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot39, align 32
  %.slot40 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot40, align 32
  %.slot41 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot41, align 32
  %.spill42 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill42, align 32
  %.slot43 = alloca i64, align 8
  store i64 0, ptr %.slot43, align 4
  %15 = getelementptr i8, ptr %argument_buffer, i64 0
  %16 = load ptr, ptr %15, align 16
  %17 = getelementptr i8, ptr %15, i64 8
  %18 = load i64, ptr %17, align 8
  %19 = insertvalue { ptr, i64 } poison, ptr %16, 0
  %20 = insertvalue { ptr, i64 } %19, i64 %18, 1
  %21 = getelementptr i8, ptr %argument_buffer, i64 16
  %22 = load ptr, ptr %21, align 16
  %23 = getelementptr i8, ptr %21, i64 8
  %24 = load i64, ptr %23, align 8
  %25 = insertvalue { ptr, i64 } poison, ptr %22, 0
  %26 = insertvalue { ptr, i64 } %25, i64 %24, 1
  %27 = getelementptr i8, ptr %argument_buffer, i64 32
  %28 = load ptr, ptr %27, align 16
  %29 = getelementptr i8, ptr %27, i64 8
  %30 = load i64, ptr %29, align 8
  %31 = insertvalue { ptr, i64 } poison, ptr %28, 0
  %32 = insertvalue { ptr, i64 } %31, i64 %30, 1
  %33 = getelementptr i8, ptr %argument_buffer, i64 48
  %34 = load ptr, ptr %33, align 16
  %35 = getelementptr i8, ptr %33, i64 8
  %36 = load i64, ptr %35, align 8
  %37 = insertvalue { ptr, i64 } poison, ptr %34, 0
  %38 = insertvalue { ptr, i64 } %37, i64 %36, 1
  %39 = load i32, ptr %launch_config, align 4
  %40 = getelementptr i8, ptr %launch_config, i64 12
  %41 = load i32, ptr %40, align 4
  %42 = getelementptr i8, ptr %launch_config, i64 4
  %43 = load i32, ptr %42, align 4
  %44 = getelementptr i8, ptr %launch_config, i64 16
  %45 = load i32, ptr %44, align 4
  %46 = getelementptr i8, ptr %launch_config, i64 8
  %47 = load i32, ptr %46, align 4
  %48 = getelementptr i8, ptr %launch_config, i64 20
  %49 = load i32, ptr %48, align 4
  %50 = getelementptr i8, ptr %launch_config, i64 36
  %51 = load i32, ptr %50, align 4
  %.splatinsert44 = insertelement <8 x i32> poison, i32 %51, i64 0
  %.splat45 = shufflevector <8 x i32> %.splatinsert44, <8 x i32> poison, <8 x i32> zeroinitializer
  %52 = add <8 x i32> %.splat45, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %53 = mul i32 %39, 32
  %.splatinsert46 = insertelement <8 x i32> poison, i32 %53, i64 0
  %.splat47 = shufflevector <8 x i32> %.splatinsert46, <8 x i32> poison, <8 x i32> zeroinitializer
  %54 = add <8 x i32> %.splat47, %52
  %55 = mul i32 %43, 1
  %.splatinsert48 = insertelement <8 x i32> poison, i32 %55, i64 0
  %.splat49 = shufflevector <8 x i32> %.splatinsert48, <8 x i32> poison, <8 x i32> zeroinitializer
  %56 = add <8 x i32> %.splat49, zeroinitializer
  %57 = mul i32 %47, 1
  %.splatinsert50 = insertelement <8 x i32> poison, i32 %57, i64 0
  %.splat51 = shufflevector <8 x i32> %.splatinsert50, <8 x i32> poison, <8 x i32> zeroinitializer
  %58 = add <8 x i32> %.splat51, zeroinitializer
  %59 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %54, 0
  %60 = insertvalue [3 x <8 x i32>] %59, <8 x i32> %56, 1
  %61 = insertvalue [3 x <8 x i32>] %60, <8 x i32> %58, 2
  %.splatinsert52 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat53 = shufflevector <8 x i32> %.splatinsert52, <8 x i32> poison, <8 x i32> zeroinitializer
  %62 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat53
  %63 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  br i1 %63, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %64 = extractvalue [3 x <8 x i32>] %61, 0
  %65 = zext <8 x i32> %64 to <8 x i64>
  %66 = select <8 x i1> %62, <8 x i64> %65, <8 x i64> zeroinitializer
  %67 = select <8 x i1> %62, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %68 = sdiv <8 x i64> %66, %67
  %69 = load <8 x i64>, ptr %.spill, align 64
  %70 = select <8 x i1> %62, <8 x i64> %68, <8 x i64> %69
  store <8 x i64> %70, ptr %.spill, align 64
  %71 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %72 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %73 = extractvalue { <8 x ptr>, <8 x i64> } %71, 0
  %74 = select <8 x i1> %62, <8 x ptr> %72, <8 x ptr> %73
  %75 = extractvalue { <8 x ptr>, <8 x i64> } %2, 1
  %76 = extractvalue { <8 x ptr>, <8 x i64> } %71, 1
  %77 = select <8 x i1> %62, <8 x i64> %75, <8 x i64> %76
  %78 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %74, 0
  %79 = insertvalue { <8 x ptr>, <8 x i64> } %78, <8 x i64> %77, 1
  store { <8 x ptr>, <8 x i64> } %79, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %80 = icmp slt i64 %.state, 512
  br i1 %80, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %81 = add <8 x i64> %.spill.load, zeroinitializer
  %82 = add <8 x i64> zeroinitializer, %81
  %.state54 = load i64, ptr %.slot, align 4
  %83 = add i64 0, %.state54
  %84 = mul <8 x i64> %82, splat (i64 512)
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %83, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %85 = add <8 x i64> %84, %.splat56
  %86 = extractvalue { ptr, i64 } %20, 0
  %87 = mul <8 x i64> %85, splat (i64 4)
  %88 = getelementptr i8, ptr %86, <8 x i64> %87
  %89 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %88, <8 x i1> %62, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %90 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state57 = load i64, ptr %.slot, align 4
  %.splatinsert58 = insertelement <8 x i64> poison, i64 %.state57, i64 0
  %.splat59 = shufflevector <8 x i64> %.splatinsert58, <8 x i64> poison, <8 x i32> zeroinitializer
  %92 = mul <8 x i64> %.splat59, splat (i64 32)
  %93 = add <8 x i64> %91, %92
  %94 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %90, 0
  %95 = insertvalue { <8 x ptr>, <8 x i64> } %94, <8 x i64> %93, 1
  %96 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %97 = extractvalue { <8 x ptr>, <8 x i64> } %95, 1
  %98 = extractelement <8 x ptr> %96, i32 0
  %99 = extractelement <8 x i64> %97, i32 0
  %100 = sub i64 %99, 0
  %101 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %102 = select i1 %101, i64 %100, i64 0
  %private.contiguous.address = getelementptr i8, ptr %98, i64 %102
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %103 = select <8 x i1> %62, <8 x float> %89, <8 x float> %private.contiguous.preserve
  store <8 x float> %103, ptr %private.contiguous.address, align 4
  %.state60 = load i64, ptr %.slot, align 4
  %104 = add i64 %.state60, 1
  store i64 %104, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %106 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %107 = extractvalue { <8 x ptr>, <8 x i64> } %105, 0
  %108 = select <8 x i1> %62, <8 x ptr> %106, <8 x ptr> %107
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %105, 1
  %111 = select <8 x i1> %62, <8 x i64> %109, <8 x i64> %110
  %112 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %113 = insertvalue { <8 x ptr>, <8 x i64> } %112, <8 x i64> %111, 1
  store { <8 x ptr>, <8 x i64> } %113, ptr %tile_snapshot.spill17, align 64
  store i64 0, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state61 = load i64, ptr %.slot18, align 4
  %114 = icmp slt i64 %.state61, 512
  br i1 %114, label %direct.true62, label %direct.false63

direct.schedule.5:                                ; preds = %direct.true62
  %tile_snapshot.spill.load64 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %115 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 0
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load64, 1
  %.state65 = load i64, ptr %.slot18, align 4
  %.splatinsert66 = insertelement <8 x i64> poison, i64 %.state65, i64 0
  %.splat67 = shufflevector <8 x i64> %.splatinsert66, <8 x i64> poison, <8 x i32> zeroinitializer
  %117 = mul <8 x i64> %.splat67, splat (i64 64)
  %118 = add <8 x i64> %116, %117
  %119 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %115, 0
  %120 = insertvalue { <8 x ptr>, <8 x i64> } %119, <8 x i64> %118, 1
  %.state68 = load i64, ptr %.slot18, align 4
  %.splatinsert69 = insertelement <8 x i64> poison, i64 %.state68, i64 0
  %.splat70 = shufflevector <8 x i64> %.splatinsert69, <8 x i64> poison, <8 x i32> zeroinitializer
  %121 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %120, 1
  %123 = extractelement <8 x ptr> %121, i32 0
  %124 = extractelement <8 x i64> %122, i32 0
  %125 = sub i64 %124, 0
  %126 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %127 = select i1 %126, i64 %125, i64 0
  %private.contiguous.address71 = getelementptr i8, ptr %123, i64 %127
  %private.contiguous.preserve72 = load <8 x i64>, ptr %private.contiguous.address71, align 8
  %128 = select <8 x i1> %62, <8 x i64> %.splat70, <8 x i64> %private.contiguous.preserve72
  store <8 x i64> %128, ptr %private.contiguous.address71, align 8
  %.state73 = load i64, ptr %.slot18, align 4
  %129 = add i64 %.state73, 1
  store i64 %129, ptr %.slot18, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false63
  %.spill.load74 = load <8 x i64>, ptr %.spill, align 64
  %130 = select <8 x i1> %62, <8 x i64> %.spill.load74, <8 x i64> zeroinitializer
  %131 = select <8 x i1> %62, <8 x i64> splat (i64 512), <8 x i64> splat (i64 1)
  %132 = srem <8 x i64> %130, %131
  %133 = load <8 x i64>, ptr %.spill19, align 64
  %134 = select <8 x i1> %62, <8 x i64> %132, <8 x i64> %133
  store <8 x i64> %134, ptr %.spill19, align 64
  %135 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %8, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %135, 0
  %138 = select <8 x i1> %62, <8 x ptr> %136, <8 x ptr> %137
  %139 = extractvalue { <8 x ptr>, <8 x i64> } %8, 1
  %140 = extractvalue { <8 x ptr>, <8 x i64> } %135, 1
  %141 = select <8 x i1> %62, <8 x i64> %139, <8 x i64> %140
  %142 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %138, 0
  %143 = insertvalue { <8 x ptr>, <8 x i64> } %142, <8 x i64> %141, 1
  store { <8 x ptr>, <8 x i64> } %143, ptr %tile_snapshot.spill20, align 64
  store i64 0, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state75 = load i64, ptr %.slot21, align 4
  %144 = icmp slt i64 %.state75, 512
  br i1 %144, label %direct.true76, label %direct.false77

direct.schedule.8:                                ; preds = %direct.true76
  %.state78 = load i64, ptr %.slot21, align 4
  %145 = add i64 0, %.state78
  %tile_snapshot.spill.load79 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill17, align 64
  %146 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load79, 0
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load79, 1
  %.splatinsert80 = insertelement <8 x i64> poison, i64 %145, i64 0
  %.splat81 = shufflevector <8 x i64> %.splatinsert80, <8 x i64> poison, <8 x i32> zeroinitializer
  %148 = mul <8 x i64> %.splat81, splat (i64 64)
  %149 = add <8 x i64> %147, %148
  %150 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %146, 0
  %151 = insertvalue { <8 x ptr>, <8 x i64> } %150, <8 x i64> %149, 1
  %152 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %153 = extractvalue { <8 x ptr>, <8 x i64> } %151, 1
  %154 = extractelement <8 x ptr> %152, i32 0
  %155 = extractelement <8 x i64> %153, i32 0
  %156 = sub i64 %155, 0
  %157 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %158 = select i1 %157, i64 %156, i64 0
  %private.contiguous.address82 = getelementptr i8, ptr %154, i64 %158
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address82, align 8
  %159 = select <8 x i1> %62, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load83 = load <8 x i64>, ptr %.spill19, align 64
  %160 = icmp sle <8 x i64> %159, %.spill.load83
  %tile_snapshot.spill.load84 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load84, 1
  %.state85 = load i64, ptr %.slot21, align 4
  %.splatinsert86 = insertelement <8 x i64> poison, i64 %.state85, i64 0
  %.splat87 = shufflevector <8 x i64> %.splatinsert86, <8 x i64> poison, <8 x i32> zeroinitializer
  %163 = add <8 x i64> %162, %.splat87
  %164 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %161, 0
  %165 = insertvalue { <8 x ptr>, <8 x i64> } %164, <8 x i64> %163, 1
  %166 = extractvalue { <8 x ptr>, <8 x i64> } %165, 0
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %165, 1
  %168 = getelementptr i8, <8 x ptr> %166, <8 x i64> %167
  %169 = zext <8 x i1> %160 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %169, <8 x ptr> align 1 %168, <8 x i1> %62)
  %.state88 = load i64, ptr %.slot21, align 4
  %170 = add i64 %.state88, 1
  store i64 %170, ptr %.slot21, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false77
  %171 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %172 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %173 = extractvalue { <8 x ptr>, <8 x i64> } %171, 0
  %174 = select <8 x i1> %62, <8 x ptr> %172, <8 x ptr> %173
  %175 = extractvalue { <8 x ptr>, <8 x i64> } %11, 1
  %176 = extractvalue { <8 x ptr>, <8 x i64> } %171, 1
  %177 = select <8 x i1> %62, <8 x i64> %175, <8 x i64> %176
  %178 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %174, 0
  %179 = insertvalue { <8 x ptr>, <8 x i64> } %178, <8 x i64> %177, 1
  store { <8 x ptr>, <8 x i64> } %179, ptr %tile_snapshot.spill22, align 64
  store i64 0, ptr %.slot23, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state89 = load i64, ptr %.slot23, align 4
  %180 = icmp slt i64 %.state89, 512
  br i1 %180, label %direct.true90, label %direct.false91

direct.schedule.11:                               ; preds = %direct.true90
  %.state92 = load i64, ptr %.slot23, align 4
  %181 = add i64 0, %.state92
  %tile_snapshot.spill.load93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 1
  %.splatinsert94 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat95 = shufflevector <8 x i64> %.splatinsert94, <8 x i64> poison, <8 x i32> zeroinitializer
  %184 = add <8 x i64> %183, %.splat95
  %185 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %182, 0
  %186 = insertvalue { <8 x ptr>, <8 x i64> } %185, <8 x i64> %184, 1
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %186, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %186, 1
  %189 = getelementptr i8, <8 x ptr> %187, <8 x i64> %188
  %190 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %189, <8 x i1> %62, <8 x i8> zeroinitializer)
  %191 = icmp ne <8 x i8> %190, zeroinitializer
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %192 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.splatinsert97 = insertelement <8 x i64> poison, i64 %181, i64 0
  %.splat98 = shufflevector <8 x i64> %.splatinsert97, <8 x i64> poison, <8 x i32> zeroinitializer
  %194 = mul <8 x i64> %.splat98, splat (i64 32)
  %195 = add <8 x i64> %193, %194
  %196 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %192, 0
  %197 = insertvalue { <8 x ptr>, <8 x i64> } %196, <8 x i64> %195, 1
  %198 = extractvalue { <8 x ptr>, <8 x i64> } %2, 0
  %199 = extractvalue { <8 x ptr>, <8 x i64> } %197, 1
  %200 = extractelement <8 x ptr> %198, i32 0
  %201 = extractelement <8 x i64> %199, i32 0
  %202 = sub i64 %201, 0
  %203 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %204 = select i1 %203, i64 %202, i64 0
  %private.contiguous.address99 = getelementptr i8, ptr %200, i64 %204
  %private.contiguous.load100 = load <8 x float>, ptr %private.contiguous.address99, align 4
  %205 = select <8 x i1> %62, <8 x float> %private.contiguous.load100, <8 x float> zeroinitializer
  %206 = select <8 x i1> %191, <8 x float> %205, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load101 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %207 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 0
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load101, 1
  %.state102 = load i64, ptr %.slot23, align 4
  %.splatinsert103 = insertelement <8 x i64> poison, i64 %.state102, i64 0
  %.splat104 = shufflevector <8 x i64> %.splatinsert103, <8 x i64> poison, <8 x i32> zeroinitializer
  %209 = mul <8 x i64> %.splat104, splat (i64 32)
  %210 = add <8 x i64> %208, %209
  %211 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %207, 0
  %212 = insertvalue { <8 x ptr>, <8 x i64> } %211, <8 x i64> %210, 1
  %213 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %214 = extractvalue { <8 x ptr>, <8 x i64> } %212, 1
  %215 = extractelement <8 x ptr> %213, i32 0
  %216 = extractelement <8 x i64> %214, i32 0
  %217 = sub i64 %216, 0
  %218 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %219 = select i1 %218, i64 %217, i64 0
  %private.contiguous.address105 = getelementptr i8, ptr %215, i64 %219
  %private.contiguous.preserve106 = load <8 x float>, ptr %private.contiguous.address105, align 4
  %220 = select <8 x i1> %62, <8 x float> %206, <8 x float> %private.contiguous.preserve106
  store <8 x float> %220, ptr %private.contiguous.address105, align 4
  %.state107 = load i64, ptr %.slot23, align 4
  %221 = add i64 %.state107, 1
  store i64 %221, ptr %.slot23, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false91
  store i64 0, ptr %.spill24, align 4
  store i64 0, ptr %.spill25, align 4
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %224 = add <8 x i64> %223, zeroinitializer
  %225 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %222, 0
  %226 = insertvalue { <8 x ptr>, <8 x i64> } %225, <8 x i64> %224, 1
  %227 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %228 = extractvalue { <8 x ptr>, <8 x i64> } %226, 1
  %229 = extractelement <8 x ptr> %227, i32 0
  %230 = extractelement <8 x i64> %228, i32 0
  %231 = sub i64 %230, 0
  %232 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %233 = select i1 %232, i64 %231, i64 0
  %private.contiguous.address109 = getelementptr i8, ptr %229, i64 %233
  %private.contiguous.load110 = load <8 x float>, ptr %private.contiguous.address109, align 4
  %234 = select <8 x i1> %62, <8 x float> %private.contiguous.load110, <8 x float> zeroinitializer
  store i64 1, ptr %.spill26, align 4
  %tile_snapshot.spill.load111 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 1
  %237 = add <8 x i64> %236, splat (i64 32)
  %238 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %235, 0
  %239 = insertvalue { <8 x ptr>, <8 x i64> } %238, <8 x i64> %237, 1
  %240 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %241 = extractvalue { <8 x ptr>, <8 x i64> } %239, 1
  %242 = extractelement <8 x ptr> %240, i32 0
  %243 = extractelement <8 x i64> %241, i32 0
  %244 = sub i64 %243, 0
  %245 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %246 = select i1 %245, i64 %244, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %242, i64 %246
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %247 = select <8 x i1> %62, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  store i64 2, ptr %.spill27, align 4
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %250 = add <8 x i64> %249, splat (i64 64)
  %251 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %248, 0
  %252 = insertvalue { <8 x ptr>, <8 x i64> } %251, <8 x i64> %250, 1
  %253 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %254 = extractvalue { <8 x ptr>, <8 x i64> } %252, 1
  %255 = extractelement <8 x ptr> %253, i32 0
  %256 = extractelement <8 x i64> %254, i32 0
  %257 = sub i64 %256, 0
  %258 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %259 = select i1 %258, i64 %257, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %255, i64 %259
  %private.contiguous.load116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %260 = select <8 x i1> %62, <8 x float> %private.contiguous.load116, <8 x float> zeroinitializer
  store i64 3, ptr %.spill28, align 4
  %tile_snapshot.spill.load117 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load117, 1
  %263 = add <8 x i64> %262, splat (i64 96)
  %264 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %261, 0
  %265 = insertvalue { <8 x ptr>, <8 x i64> } %264, <8 x i64> %263, 1
  %266 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %267 = extractvalue { <8 x ptr>, <8 x i64> } %265, 1
  %268 = extractelement <8 x ptr> %266, i32 0
  %269 = extractelement <8 x i64> %267, i32 0
  %270 = sub i64 %269, 0
  %271 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %272 = select i1 %271, i64 %270, i64 0
  %private.contiguous.address118 = getelementptr i8, ptr %268, i64 %272
  %private.contiguous.load119 = load <8 x float>, ptr %private.contiguous.address118, align 4
  %273 = select <8 x i1> %62, <8 x float> %private.contiguous.load119, <8 x float> zeroinitializer
  store i64 4, ptr %.slot29, align 4
  %274 = load <8 x float>, ptr %.slot30, align 32
  %275 = select <8 x i1> %62, <8 x float> %234, <8 x float> %274
  store <8 x float> %275, ptr %.slot30, align 32
  %276 = load <8 x float>, ptr %.slot31, align 32
  %277 = select <8 x i1> %62, <8 x float> %247, <8 x float> %276
  store <8 x float> %277, ptr %.slot31, align 32
  %278 = load <8 x float>, ptr %.slot32, align 32
  %279 = select <8 x i1> %62, <8 x float> %260, <8 x float> %278
  store <8 x float> %279, ptr %.slot32, align 32
  %280 = load <8 x float>, ptr %.slot33, align 32
  %281 = select <8 x i1> %62, <8 x float> %273, <8 x float> %280
  store <8 x float> %281, ptr %.slot33, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state120 = load i64, ptr %.slot29, align 4
  %282 = icmp slt i64 %.state120, 512
  br i1 %282, label %direct.true121, label %direct.false122

direct.schedule.14:                               ; preds = %direct.true121
  %.state123 = load i64, ptr %.slot29, align 4
  %283 = add i64 %.state123, 0
  %284 = sdiv i64 %283, 1
  %.spill.load124 = load i64, ptr %.spill24, align 4
  %285 = add i64 %.spill.load124, %284
  %tile_snapshot.spill.load125 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %286 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 0
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load125, 1
  %.splatinsert126 = insertelement <8 x i64> poison, i64 %285, i64 0
  %.splat127 = shufflevector <8 x i64> %.splatinsert126, <8 x i64> poison, <8 x i32> zeroinitializer
  %288 = mul <8 x i64> %.splat127, splat (i64 32)
  %289 = add <8 x i64> %287, %288
  %290 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %286, 0
  %291 = insertvalue { <8 x ptr>, <8 x i64> } %290, <8 x i64> %289, 1
  %292 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %293 = extractvalue { <8 x ptr>, <8 x i64> } %291, 1
  %294 = extractelement <8 x ptr> %292, i32 0
  %295 = extractelement <8 x i64> %293, i32 0
  %296 = sub i64 %295, 0
  %297 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %298 = select i1 %297, i64 %296, i64 0
  %private.contiguous.address128 = getelementptr i8, ptr %294, i64 %298
  %private.contiguous.load129 = load <8 x float>, ptr %private.contiguous.address128, align 4
  %299 = select <8 x i1> %62, <8 x float> %private.contiguous.load129, <8 x float> zeroinitializer
  %.state130 = load <8 x float>, ptr %.slot30, align 32
  %300 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state130, <8 x float> %299)
  %.state131 = load i64, ptr %.slot29, align 4
  %301 = add i64 %.state131, 1
  %302 = sdiv i64 %301, 1
  %.spill.load132 = load i64, ptr %.spill24, align 4
  %303 = add i64 %.spill.load132, %302
  %tile_snapshot.spill.load133 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %304 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 0
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load133, 1
  %.splatinsert134 = insertelement <8 x i64> poison, i64 %303, i64 0
  %.splat135 = shufflevector <8 x i64> %.splatinsert134, <8 x i64> poison, <8 x i32> zeroinitializer
  %306 = mul <8 x i64> %.splat135, splat (i64 32)
  %307 = add <8 x i64> %305, %306
  %308 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %304, 0
  %309 = insertvalue { <8 x ptr>, <8 x i64> } %308, <8 x i64> %307, 1
  %310 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %311 = extractvalue { <8 x ptr>, <8 x i64> } %309, 1
  %312 = extractelement <8 x ptr> %310, i32 0
  %313 = extractelement <8 x i64> %311, i32 0
  %314 = sub i64 %313, 0
  %315 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %316 = select i1 %315, i64 %314, i64 0
  %private.contiguous.address136 = getelementptr i8, ptr %312, i64 %316
  %private.contiguous.load137 = load <8 x float>, ptr %private.contiguous.address136, align 4
  %317 = select <8 x i1> %62, <8 x float> %private.contiguous.load137, <8 x float> zeroinitializer
  %.state138 = load <8 x float>, ptr %.slot31, align 32
  %318 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state138, <8 x float> %317)
  %.state139 = load i64, ptr %.slot29, align 4
  %319 = add i64 %.state139, 2
  %320 = sdiv i64 %319, 1
  %.spill.load140 = load i64, ptr %.spill24, align 4
  %321 = add i64 %.spill.load140, %320
  %tile_snapshot.spill.load141 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 0
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load141, 1
  %.splatinsert142 = insertelement <8 x i64> poison, i64 %321, i64 0
  %.splat143 = shufflevector <8 x i64> %.splatinsert142, <8 x i64> poison, <8 x i32> zeroinitializer
  %324 = mul <8 x i64> %.splat143, splat (i64 32)
  %325 = add <8 x i64> %323, %324
  %326 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %322, 0
  %327 = insertvalue { <8 x ptr>, <8 x i64> } %326, <8 x i64> %325, 1
  %328 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %329 = extractvalue { <8 x ptr>, <8 x i64> } %327, 1
  %330 = extractelement <8 x ptr> %328, i32 0
  %331 = extractelement <8 x i64> %329, i32 0
  %332 = sub i64 %331, 0
  %333 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %334 = select i1 %333, i64 %332, i64 0
  %private.contiguous.address144 = getelementptr i8, ptr %330, i64 %334
  %private.contiguous.load145 = load <8 x float>, ptr %private.contiguous.address144, align 4
  %335 = select <8 x i1> %62, <8 x float> %private.contiguous.load145, <8 x float> zeroinitializer
  %.state146 = load <8 x float>, ptr %.slot32, align 32
  %336 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state146, <8 x float> %335)
  %.state147 = load i64, ptr %.slot29, align 4
  %337 = add i64 %.state147, 3
  %338 = sdiv i64 %337, 1
  %.spill.load148 = load i64, ptr %.spill24, align 4
  %339 = add i64 %.spill.load148, %338
  %tile_snapshot.spill.load149 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %340 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 0
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load149, 1
  %.splatinsert150 = insertelement <8 x i64> poison, i64 %339, i64 0
  %.splat151 = shufflevector <8 x i64> %.splatinsert150, <8 x i64> poison, <8 x i32> zeroinitializer
  %342 = mul <8 x i64> %.splat151, splat (i64 32)
  %343 = add <8 x i64> %341, %342
  %344 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %340, 0
  %345 = insertvalue { <8 x ptr>, <8 x i64> } %344, <8 x i64> %343, 1
  %346 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %347 = extractvalue { <8 x ptr>, <8 x i64> } %345, 1
  %348 = extractelement <8 x ptr> %346, i32 0
  %349 = extractelement <8 x i64> %347, i32 0
  %350 = sub i64 %349, 0
  %351 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %352 = select i1 %351, i64 %350, i64 0
  %private.contiguous.address152 = getelementptr i8, ptr %348, i64 %352
  %private.contiguous.load153 = load <8 x float>, ptr %private.contiguous.address152, align 4
  %353 = select <8 x i1> %62, <8 x float> %private.contiguous.load153, <8 x float> zeroinitializer
  %.state154 = load <8 x float>, ptr %.slot33, align 32
  %354 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state154, <8 x float> %353)
  %.state155 = load i64, ptr %.slot29, align 4
  %355 = add i64 %.state155, 4
  store i64 %355, ptr %.slot29, align 4
  %356 = load <8 x float>, ptr %.slot30, align 32
  %357 = select <8 x i1> %62, <8 x float> %300, <8 x float> %356
  store <8 x float> %357, ptr %.slot30, align 32
  %358 = load <8 x float>, ptr %.slot31, align 32
  %359 = select <8 x i1> %62, <8 x float> %318, <8 x float> %358
  store <8 x float> %359, ptr %.slot31, align 32
  %360 = load <8 x float>, ptr %.slot32, align 32
  %361 = select <8 x i1> %62, <8 x float> %336, <8 x float> %360
  store <8 x float> %361, ptr %.slot32, align 32
  %362 = load <8 x float>, ptr %.slot33, align 32
  %363 = select <8 x i1> %62, <8 x float> %354, <8 x float> %362
  store <8 x float> %363, ptr %.slot33, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false122
  %.state156 = load <8 x float>, ptr %.slot30, align 32
  %364 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> splat (float 0xFFF0000000000000), <8 x float> %.state156)
  %.state157 = load <8 x float>, ptr %.slot31, align 32
  %365 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %364, <8 x float> %.state157)
  %.state158 = load <8 x float>, ptr %.slot32, align 32
  %366 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %365, <8 x float> %.state158)
  %.state159 = load <8 x float>, ptr %.slot33, align 32
  %367 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %366, <8 x float> %.state159)
  %368 = load <8 x float>, ptr %.spill34, align 32
  %369 = select <8 x i1> %62, <8 x float> %367, <8 x float> %368
  store <8 x float> %369, ptr %.spill34, align 32
  %370 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %371 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %372 = extractvalue { <8 x ptr>, <8 x i64> } %370, 0
  %373 = select <8 x i1> %62, <8 x ptr> %371, <8 x ptr> %372
  %374 = extractvalue { <8 x ptr>, <8 x i64> } %14, 1
  %375 = extractvalue { <8 x ptr>, <8 x i64> } %370, 1
  %376 = select <8 x i1> %62, <8 x i64> %374, <8 x i64> %375
  %377 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %373, 0
  %378 = insertvalue { <8 x ptr>, <8 x i64> } %377, <8 x i64> %376, 1
  store { <8 x ptr>, <8 x i64> } %378, ptr %tile_snapshot.spill35, align 64
  store i64 0, ptr %.slot36, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state160 = load i64, ptr %.slot36, align 4
  %379 = icmp slt i64 %.state160, 512
  br i1 %379, label %direct.true161, label %direct.false162

direct.schedule.17:                               ; preds = %direct.true161
  %.state163 = load i64, ptr %.slot36, align 4
  %380 = add i64 0, %.state163
  %tile_snapshot.spill.load164 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill20, align 64
  %381 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 0
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load164, 1
  %.splatinsert165 = insertelement <8 x i64> poison, i64 %380, i64 0
  %.splat166 = shufflevector <8 x i64> %.splatinsert165, <8 x i64> poison, <8 x i32> zeroinitializer
  %383 = add <8 x i64> %382, %.splat166
  %384 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %381, 0
  %385 = insertvalue { <8 x ptr>, <8 x i64> } %384, <8 x i64> %383, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %385, 0
  %387 = extractvalue { <8 x ptr>, <8 x i64> } %385, 1
  %388 = getelementptr i8, <8 x ptr> %386, <8 x i64> %387
  %389 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %388, <8 x i1> %62, <8 x i8> zeroinitializer)
  %390 = icmp ne <8 x i8> %389, zeroinitializer
  %391 = add i64 0, %380
  %392 = add i64 0, %391
  %tile_snapshot.spill.load167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill22, align 64
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 0
  %394 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 1
  %.splatinsert168 = insertelement <8 x i64> poison, i64 %392, i64 0
  %.splat169 = shufflevector <8 x i64> %.splatinsert168, <8 x i64> poison, <8 x i32> zeroinitializer
  %395 = mul <8 x i64> %.splat169, splat (i64 32)
  %396 = add <8 x i64> %394, %395
  %397 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %393, 0
  %398 = insertvalue { <8 x ptr>, <8 x i64> } %397, <8 x i64> %396, 1
  %399 = extractvalue { <8 x ptr>, <8 x i64> } %11, 0
  %400 = extractvalue { <8 x ptr>, <8 x i64> } %398, 1
  %401 = extractelement <8 x ptr> %399, i32 0
  %402 = extractelement <8 x i64> %400, i32 0
  %403 = sub i64 %402, 0
  %404 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %405 = select i1 %404, i64 %403, i64 0
  %private.contiguous.address170 = getelementptr i8, ptr %401, i64 %405
  %private.contiguous.load171 = load <8 x float>, ptr %private.contiguous.address170, align 4
  %406 = select <8 x i1> %62, <8 x float> %private.contiguous.load171, <8 x float> zeroinitializer
  %.spill.load172 = load <8 x float>, ptr %.spill34, align 32
  %407 = fsub <8 x float> %406, %.spill.load172
  %408 = select <8 x i1> %62, <8 x float> %407, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %408)
  %409 = select <8 x i1> %390, <8 x float> %native.exp, <8 x float> zeroinitializer
  %tile_snapshot.spill.load173 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 0
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load173, 1
  %.state174 = load i64, ptr %.slot36, align 4
  %.splatinsert175 = insertelement <8 x i64> poison, i64 %.state174, i64 0
  %.splat176 = shufflevector <8 x i64> %.splatinsert175, <8 x i64> poison, <8 x i32> zeroinitializer
  %412 = mul <8 x i64> %.splat176, splat (i64 32)
  %413 = add <8 x i64> %411, %412
  %414 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %410, 0
  %415 = insertvalue { <8 x ptr>, <8 x i64> } %414, <8 x i64> %413, 1
  %416 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %417 = extractvalue { <8 x ptr>, <8 x i64> } %415, 1
  %418 = extractelement <8 x ptr> %416, i32 0
  %419 = extractelement <8 x i64> %417, i32 0
  %420 = sub i64 %419, 0
  %421 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %422 = select i1 %421, i64 %420, i64 0
  %private.contiguous.address177 = getelementptr i8, ptr %418, i64 %422
  %private.contiguous.preserve178 = load <8 x float>, ptr %private.contiguous.address177, align 4
  %423 = select <8 x i1> %62, <8 x float> %409, <8 x float> %private.contiguous.preserve178
  store <8 x float> %423, ptr %private.contiguous.address177, align 4
  %.state179 = load i64, ptr %.slot36, align 4
  %424 = add i64 %.state179, 1
  store i64 %424, ptr %.slot36, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false162
  %tile_snapshot.spill.load180 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %425 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load180, 0
  %426 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load180, 1
  %.spill.load181 = load i64, ptr %.spill25, align 4
  %.splatinsert182 = insertelement <8 x i64> poison, i64 %.spill.load181, i64 0
  %.splat183 = shufflevector <8 x i64> %.splatinsert182, <8 x i64> poison, <8 x i32> zeroinitializer
  %427 = mul <8 x i64> %.splat183, splat (i64 32)
  %428 = add <8 x i64> %426, %427
  %429 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %425, 0
  %430 = insertvalue { <8 x ptr>, <8 x i64> } %429, <8 x i64> %428, 1
  %431 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %432 = extractvalue { <8 x ptr>, <8 x i64> } %430, 1
  %433 = extractelement <8 x ptr> %431, i32 0
  %434 = extractelement <8 x i64> %432, i32 0
  %435 = sub i64 %434, 0
  %436 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %437 = select i1 %436, i64 %435, i64 0
  %private.contiguous.address184 = getelementptr i8, ptr %433, i64 %437
  %private.contiguous.load185 = load <8 x float>, ptr %private.contiguous.address184, align 4
  %438 = select <8 x i1> %62, <8 x float> %private.contiguous.load185, <8 x float> zeroinitializer
  %tile_snapshot.spill.load186 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %439 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load186, 0
  %440 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load186, 1
  %.spill.load187 = load i64, ptr %.spill26, align 4
  %.splatinsert188 = insertelement <8 x i64> poison, i64 %.spill.load187, i64 0
  %.splat189 = shufflevector <8 x i64> %.splatinsert188, <8 x i64> poison, <8 x i32> zeroinitializer
  %441 = mul <8 x i64> %.splat189, splat (i64 32)
  %442 = add <8 x i64> %440, %441
  %443 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %439, 0
  %444 = insertvalue { <8 x ptr>, <8 x i64> } %443, <8 x i64> %442, 1
  %445 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %446 = extractvalue { <8 x ptr>, <8 x i64> } %444, 1
  %447 = extractelement <8 x ptr> %445, i32 0
  %448 = extractelement <8 x i64> %446, i32 0
  %449 = sub i64 %448, 0
  %450 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %451 = select i1 %450, i64 %449, i64 0
  %private.contiguous.address190 = getelementptr i8, ptr %447, i64 %451
  %private.contiguous.load191 = load <8 x float>, ptr %private.contiguous.address190, align 4
  %452 = select <8 x i1> %62, <8 x float> %private.contiguous.load191, <8 x float> zeroinitializer
  %tile_snapshot.spill.load192 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %453 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 0
  %454 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load192, 1
  %.spill.load193 = load i64, ptr %.spill27, align 4
  %.splatinsert194 = insertelement <8 x i64> poison, i64 %.spill.load193, i64 0
  %.splat195 = shufflevector <8 x i64> %.splatinsert194, <8 x i64> poison, <8 x i32> zeroinitializer
  %455 = mul <8 x i64> %.splat195, splat (i64 32)
  %456 = add <8 x i64> %454, %455
  %457 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %453, 0
  %458 = insertvalue { <8 x ptr>, <8 x i64> } %457, <8 x i64> %456, 1
  %459 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %460 = extractvalue { <8 x ptr>, <8 x i64> } %458, 1
  %461 = extractelement <8 x ptr> %459, i32 0
  %462 = extractelement <8 x i64> %460, i32 0
  %463 = sub i64 %462, 0
  %464 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %465 = select i1 %464, i64 %463, i64 0
  %private.contiguous.address196 = getelementptr i8, ptr %461, i64 %465
  %private.contiguous.load197 = load <8 x float>, ptr %private.contiguous.address196, align 4
  %466 = select <8 x i1> %62, <8 x float> %private.contiguous.load197, <8 x float> zeroinitializer
  %tile_snapshot.spill.load198 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %467 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 0
  %468 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load198, 1
  %.spill.load199 = load i64, ptr %.spill28, align 4
  %.splatinsert200 = insertelement <8 x i64> poison, i64 %.spill.load199, i64 0
  %.splat201 = shufflevector <8 x i64> %.splatinsert200, <8 x i64> poison, <8 x i32> zeroinitializer
  %469 = mul <8 x i64> %.splat201, splat (i64 32)
  %470 = add <8 x i64> %468, %469
  %471 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %467, 0
  %472 = insertvalue { <8 x ptr>, <8 x i64> } %471, <8 x i64> %470, 1
  %473 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %474 = extractvalue { <8 x ptr>, <8 x i64> } %472, 1
  %475 = extractelement <8 x ptr> %473, i32 0
  %476 = extractelement <8 x i64> %474, i32 0
  %477 = sub i64 %476, 0
  %478 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %479 = select i1 %478, i64 %477, i64 0
  %private.contiguous.address202 = getelementptr i8, ptr %475, i64 %479
  %private.contiguous.load203 = load <8 x float>, ptr %private.contiguous.address202, align 4
  %480 = select <8 x i1> %62, <8 x float> %private.contiguous.load203, <8 x float> zeroinitializer
  store i64 4, ptr %.slot37, align 4
  %481 = load <8 x float>, ptr %.slot38, align 32
  %482 = select <8 x i1> %62, <8 x float> %438, <8 x float> %481
  store <8 x float> %482, ptr %.slot38, align 32
  %483 = load <8 x float>, ptr %.slot39, align 32
  %484 = select <8 x i1> %62, <8 x float> %452, <8 x float> %483
  store <8 x float> %484, ptr %.slot39, align 32
  %485 = load <8 x float>, ptr %.slot40, align 32
  %486 = select <8 x i1> %62, <8 x float> %466, <8 x float> %485
  store <8 x float> %486, ptr %.slot40, align 32
  %487 = load <8 x float>, ptr %.slot41, align 32
  %488 = select <8 x i1> %62, <8 x float> %480, <8 x float> %487
  store <8 x float> %488, ptr %.slot41, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state204 = load i64, ptr %.slot37, align 4
  %489 = icmp slt i64 %.state204, 512
  br i1 %489, label %direct.true205, label %direct.false206

direct.schedule.20:                               ; preds = %direct.true205
  %.state207 = load i64, ptr %.slot37, align 4
  %490 = add i64 %.state207, 0
  %491 = sdiv i64 %490, 1
  %.spill.load208 = load i64, ptr %.spill24, align 4
  %492 = add i64 %.spill.load208, %491
  %tile_snapshot.spill.load209 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %493 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 0
  %494 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load209, 1
  %.splatinsert210 = insertelement <8 x i64> poison, i64 %492, i64 0
  %.splat211 = shufflevector <8 x i64> %.splatinsert210, <8 x i64> poison, <8 x i32> zeroinitializer
  %495 = mul <8 x i64> %.splat211, splat (i64 32)
  %496 = add <8 x i64> %494, %495
  %497 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %493, 0
  %498 = insertvalue { <8 x ptr>, <8 x i64> } %497, <8 x i64> %496, 1
  %499 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %500 = extractvalue { <8 x ptr>, <8 x i64> } %498, 1
  %501 = extractelement <8 x ptr> %499, i32 0
  %502 = extractelement <8 x i64> %500, i32 0
  %503 = sub i64 %502, 0
  %504 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %505 = select i1 %504, i64 %503, i64 0
  %private.contiguous.address212 = getelementptr i8, ptr %501, i64 %505
  %private.contiguous.load213 = load <8 x float>, ptr %private.contiguous.address212, align 4
  %506 = select <8 x i1> %62, <8 x float> %private.contiguous.load213, <8 x float> zeroinitializer
  %.state214 = load <8 x float>, ptr %.slot38, align 32
  %507 = fadd <8 x float> %.state214, %506
  %.state215 = load i64, ptr %.slot37, align 4
  %508 = add i64 %.state215, 1
  %509 = sdiv i64 %508, 1
  %.spill.load216 = load i64, ptr %.spill24, align 4
  %510 = add i64 %.spill.load216, %509
  %tile_snapshot.spill.load217 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 0
  %512 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load217, 1
  %.splatinsert218 = insertelement <8 x i64> poison, i64 %510, i64 0
  %.splat219 = shufflevector <8 x i64> %.splatinsert218, <8 x i64> poison, <8 x i32> zeroinitializer
  %513 = mul <8 x i64> %.splat219, splat (i64 32)
  %514 = add <8 x i64> %512, %513
  %515 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %511, 0
  %516 = insertvalue { <8 x ptr>, <8 x i64> } %515, <8 x i64> %514, 1
  %517 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %518 = extractvalue { <8 x ptr>, <8 x i64> } %516, 1
  %519 = extractelement <8 x ptr> %517, i32 0
  %520 = extractelement <8 x i64> %518, i32 0
  %521 = sub i64 %520, 0
  %522 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %523 = select i1 %522, i64 %521, i64 0
  %private.contiguous.address220 = getelementptr i8, ptr %519, i64 %523
  %private.contiguous.load221 = load <8 x float>, ptr %private.contiguous.address220, align 4
  %524 = select <8 x i1> %62, <8 x float> %private.contiguous.load221, <8 x float> zeroinitializer
  %.state222 = load <8 x float>, ptr %.slot39, align 32
  %525 = fadd <8 x float> %.state222, %524
  %.state223 = load i64, ptr %.slot37, align 4
  %526 = add i64 %.state223, 2
  %527 = sdiv i64 %526, 1
  %.spill.load224 = load i64, ptr %.spill24, align 4
  %528 = add i64 %.spill.load224, %527
  %tile_snapshot.spill.load225 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 0
  %530 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load225, 1
  %.splatinsert226 = insertelement <8 x i64> poison, i64 %528, i64 0
  %.splat227 = shufflevector <8 x i64> %.splatinsert226, <8 x i64> poison, <8 x i32> zeroinitializer
  %531 = mul <8 x i64> %.splat227, splat (i64 32)
  %532 = add <8 x i64> %530, %531
  %533 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %529, 0
  %534 = insertvalue { <8 x ptr>, <8 x i64> } %533, <8 x i64> %532, 1
  %535 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %536 = extractvalue { <8 x ptr>, <8 x i64> } %534, 1
  %537 = extractelement <8 x ptr> %535, i32 0
  %538 = extractelement <8 x i64> %536, i32 0
  %539 = sub i64 %538, 0
  %540 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %541 = select i1 %540, i64 %539, i64 0
  %private.contiguous.address228 = getelementptr i8, ptr %537, i64 %541
  %private.contiguous.load229 = load <8 x float>, ptr %private.contiguous.address228, align 4
  %542 = select <8 x i1> %62, <8 x float> %private.contiguous.load229, <8 x float> zeroinitializer
  %.state230 = load <8 x float>, ptr %.slot40, align 32
  %543 = fadd <8 x float> %.state230, %542
  %.state231 = load i64, ptr %.slot37, align 4
  %544 = add i64 %.state231, 3
  %545 = sdiv i64 %544, 1
  %.spill.load232 = load i64, ptr %.spill24, align 4
  %546 = add i64 %.spill.load232, %545
  %tile_snapshot.spill.load233 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load233, 0
  %548 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load233, 1
  %.splatinsert234 = insertelement <8 x i64> poison, i64 %546, i64 0
  %.splat235 = shufflevector <8 x i64> %.splatinsert234, <8 x i64> poison, <8 x i32> zeroinitializer
  %549 = mul <8 x i64> %.splat235, splat (i64 32)
  %550 = add <8 x i64> %548, %549
  %551 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %547, 0
  %552 = insertvalue { <8 x ptr>, <8 x i64> } %551, <8 x i64> %550, 1
  %553 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %554 = extractvalue { <8 x ptr>, <8 x i64> } %552, 1
  %555 = extractelement <8 x ptr> %553, i32 0
  %556 = extractelement <8 x i64> %554, i32 0
  %557 = sub i64 %556, 0
  %558 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %559 = select i1 %558, i64 %557, i64 0
  %private.contiguous.address236 = getelementptr i8, ptr %555, i64 %559
  %private.contiguous.load237 = load <8 x float>, ptr %private.contiguous.address236, align 4
  %560 = select <8 x i1> %62, <8 x float> %private.contiguous.load237, <8 x float> zeroinitializer
  %.state238 = load <8 x float>, ptr %.slot41, align 32
  %561 = fadd <8 x float> %.state238, %560
  %.state239 = load i64, ptr %.slot37, align 4
  %562 = add i64 %.state239, 4
  store i64 %562, ptr %.slot37, align 4
  %563 = load <8 x float>, ptr %.slot38, align 32
  %564 = select <8 x i1> %62, <8 x float> %507, <8 x float> %563
  store <8 x float> %564, ptr %.slot38, align 32
  %565 = load <8 x float>, ptr %.slot39, align 32
  %566 = select <8 x i1> %62, <8 x float> %525, <8 x float> %565
  store <8 x float> %566, ptr %.slot39, align 32
  %567 = load <8 x float>, ptr %.slot40, align 32
  %568 = select <8 x i1> %62, <8 x float> %543, <8 x float> %567
  store <8 x float> %568, ptr %.slot40, align 32
  %569 = load <8 x float>, ptr %.slot41, align 32
  %570 = select <8 x i1> %62, <8 x float> %561, <8 x float> %569
  store <8 x float> %570, ptr %.slot41, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false206
  %.state240 = load <8 x float>, ptr %.slot38, align 32
  %571 = fadd <8 x float> zeroinitializer, %.state240
  %.state241 = load <8 x float>, ptr %.slot39, align 32
  %572 = fadd <8 x float> %571, %.state241
  %.state242 = load <8 x float>, ptr %.slot40, align 32
  %573 = fadd <8 x float> %572, %.state242
  %.state243 = load <8 x float>, ptr %.slot41, align 32
  %574 = fadd <8 x float> %573, %.state243
  %575 = load <8 x float>, ptr %.spill42, align 32
  %576 = select <8 x i1> %62, <8 x float> %574, <8 x float> %575
  store <8 x float> %576, ptr %.spill42, align 32
  store i64 0, ptr %.slot43, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state244 = load i64, ptr %.slot43, align 4
  %577 = icmp slt i64 %.state244, 512
  br i1 %577, label %direct.true245, label %direct.false246

direct.schedule.23:                               ; preds = %direct.true245
  %.spill.load247 = load <8 x i64>, ptr %.spill, align 64
  %578 = add <8 x i64> %.spill.load247, zeroinitializer
  %579 = add <8 x i64> zeroinitializer, %578
  %.state248 = load i64, ptr %.slot43, align 4
  %580 = add i64 0, %.state248
  %581 = mul <8 x i64> %579, splat (i64 512)
  %.splatinsert249 = insertelement <8 x i64> poison, i64 %580, i64 0
  %.splat250 = shufflevector <8 x i64> %.splatinsert249, <8 x i64> poison, <8 x i32> zeroinitializer
  %582 = add <8 x i64> %581, %.splat250
  %.state251 = load i64, ptr %.slot43, align 4
  %583 = add i64 0, %.state251
  %tile_snapshot.spill.load252 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill35, align 64
  %584 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 0
  %585 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load252, 1
  %.splatinsert253 = insertelement <8 x i64> poison, i64 %583, i64 0
  %.splat254 = shufflevector <8 x i64> %.splatinsert253, <8 x i64> poison, <8 x i32> zeroinitializer
  %586 = mul <8 x i64> %.splat254, splat (i64 32)
  %587 = add <8 x i64> %585, %586
  %588 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %584, 0
  %589 = insertvalue { <8 x ptr>, <8 x i64> } %588, <8 x i64> %587, 1
  %590 = extractvalue { <8 x ptr>, <8 x i64> } %14, 0
  %591 = extractvalue { <8 x ptr>, <8 x i64> } %589, 1
  %592 = extractelement <8 x ptr> %590, i32 0
  %593 = extractelement <8 x i64> %591, i32 0
  %594 = sub i64 %593, 0
  %595 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %62)
  %596 = select i1 %595, i64 %594, i64 0
  %private.contiguous.address255 = getelementptr i8, ptr %592, i64 %596
  %private.contiguous.load256 = load <8 x float>, ptr %private.contiguous.address255, align 4
  %597 = select <8 x i1> %62, <8 x float> %private.contiguous.load256, <8 x float> zeroinitializer
  %.spill.load257 = load <8 x float>, ptr %.spill42, align 32
  %598 = fdiv <8 x float> %597, %.spill.load257
  %599 = extractvalue { ptr, i64 } %38, 0
  %600 = mul <8 x i64> %582, splat (i64 4)
  %601 = getelementptr i8, ptr %599, <8 x i64> %600
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %598, <8 x ptr> align 1 %601, <8 x i1> %62)
  %.state258 = load i64, ptr %.slot43, align 4
  %602 = add i64 %.state258, 1
  store i64 %602, ptr %.slot43, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false246
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true62:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false63:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true76:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false77:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true90:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false91:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true121:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false122:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true161:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false162:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true205:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false206:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true245:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false246:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #3

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

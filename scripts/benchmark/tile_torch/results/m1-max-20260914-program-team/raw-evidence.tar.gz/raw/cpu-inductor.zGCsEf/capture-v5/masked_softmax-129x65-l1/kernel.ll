; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [2080 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [4160 x i8], align 8
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 8, i64 16, i64 24, i64 32, i64 40, i64 48, i64 56>, 1
  %tile_snapshot.local4 = alloca [520 x i8], align 1
  %.splatinsert5 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local4, i64 0
  %.splat6 = shufflevector <8 x ptr> %.splatinsert5, <8 x ptr> poison, <8 x i32> zeroinitializer
  %4 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat6, 0
  %5 = insertvalue { <8 x ptr>, <8 x i64> } %4, <8 x i64> <i64 0, i64 65, i64 130, i64 195, i64 260, i64 325, i64 390, i64 455>, 1
  %tile_snapshot.local7 = alloca [2080 x i8], align 4
  %.splatinsert8 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local7, i64 0
  %.splat9 = shufflevector <8 x ptr> %.splatinsert8, <8 x ptr> poison, <8 x i32> zeroinitializer
  %6 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat9, 0
  %7 = insertvalue { <8 x ptr>, <8 x i64> } %6, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local10 = alloca [2080 x i8], align 4
  %.splatinsert11 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local10, i64 0
  %.splat12 = shufflevector <8 x ptr> %.splatinsert11, <8 x ptr> poison, <8 x i32> zeroinitializer
  %8 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat12, 0
  %9 = insertvalue { <8 x ptr>, <8 x i64> } %8, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill15, align 64
  %tile_snapshot.spill16 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill16, align 64
  %.slot17 = alloca i64, align 8
  store i64 0, ptr %.slot17, align 4
  %tile_snapshot.spill18 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill18, align 64
  %.slot19 = alloca i64, align 8
  store i64 0, ptr %.slot19, align 4
  %.spill20 = alloca i64, align 8
  store i64 0, ptr %.spill20, align 4
  %.spill21 = alloca i64, align 8
  store i64 0, ptr %.spill21, align 4
  %.spill22 = alloca i64, align 8
  store i64 0, ptr %.spill22, align 4
  %.spill23 = alloca i64, align 8
  store i64 0, ptr %.spill23, align 4
  %.spill24 = alloca i64, align 8
  store i64 0, ptr %.spill24, align 4
  %.slot25 = alloca i64, align 8
  store i64 0, ptr %.slot25, align 4
  %.slot26 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot26, align 32
  %.slot27 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot27, align 32
  %.slot28 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot28, align 32
  %.slot29 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot29, align 32
  %.spill30 = alloca i64, align 8
  store i64 0, ptr %.spill30, align 4
  %.spill31 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill31, align 32
  %tile_snapshot.spill32 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill32, align 64
  %.slot33 = alloca i64, align 8
  store i64 0, ptr %.slot33, align 4
  %.slot34 = alloca i64, align 8
  store i64 0, ptr %.slot34, align 4
  %.slot35 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot35, align 32
  %.slot36 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot36, align 32
  %.slot37 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot37, align 32
  %.slot38 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot38, align 32
  %.spill39 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill39, align 32
  %.slot40 = alloca i64, align 8
  store i64 0, ptr %.slot40, align 4
  %10 = getelementptr i8, ptr %argument_buffer, i64 0
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 16
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 32
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = getelementptr i8, ptr %argument_buffer, i64 48
  %29 = load ptr, ptr %28, align 16
  %30 = getelementptr i8, ptr %28, i64 8
  %31 = load i64, ptr %30, align 8
  %32 = insertvalue { ptr, i64 } poison, ptr %29, 0
  %33 = insertvalue { ptr, i64 } %32, i64 %31, 1
  %34 = load i32, ptr %launch_config, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 12
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 4
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 16
  %40 = load i32, ptr %39, align 4
  %41 = getelementptr i8, ptr %launch_config, i64 8
  %42 = load i32, ptr %41, align 4
  %43 = getelementptr i8, ptr %launch_config, i64 20
  %44 = load i32, ptr %43, align 4
  %45 = getelementptr i8, ptr %launch_config, i64 36
  %46 = load i32, ptr %45, align 4
  %.splatinsert41 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat42 = shufflevector <8 x i32> %.splatinsert41, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat42, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %48 = mul i32 %34, 32
  %.splatinsert43 = insertelement <8 x i32> poison, i32 %48, i64 0
  %.splat44 = shufflevector <8 x i32> %.splatinsert43, <8 x i32> poison, <8 x i32> zeroinitializer
  %49 = add <8 x i32> %.splat44, %47
  %50 = mul i32 %38, 1
  %.splatinsert45 = insertelement <8 x i32> poison, i32 %50, i64 0
  %.splat46 = shufflevector <8 x i32> %.splatinsert45, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = add <8 x i32> %.splat46, zeroinitializer
  %52 = mul i32 %42, 1
  %.splatinsert47 = insertelement <8 x i32> poison, i32 %52, i64 0
  %.splat48 = shufflevector <8 x i32> %.splatinsert47, <8 x i32> poison, <8 x i32> zeroinitializer
  %53 = add <8 x i32> %.splat48, zeroinitializer
  %54 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %49, 0
  %55 = insertvalue [3 x <8 x i32>] %54, <8 x i32> %51, 1
  %56 = insertvalue [3 x <8 x i32>] %55, <8 x i32> %53, 2
  %.splatinsert49 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat50 = shufflevector <8 x i32> %.splatinsert49, <8 x i32> poison, <8 x i32> zeroinitializer
  %57 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat50
  %58 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  br i1 %58, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %59 = extractvalue [3 x <8 x i32>] %56, 0
  %60 = zext <8 x i32> %59 to <8 x i64>
  %61 = select <8 x i1> %57, <8 x i64> %60, <8 x i64> zeroinitializer
  %62 = select <8 x i1> %57, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %63 = sdiv <8 x i64> %61, %62
  %64 = load <8 x i64>, ptr %.spill, align 64
  %65 = select <8 x i1> %57, <8 x i64> %63, <8 x i64> %64
  store <8 x i64> %65, ptr %.spill, align 64
  %66 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %67 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %68 = extractvalue { <8 x ptr>, <8 x i64> } %66, 0
  %69 = select <8 x i1> %57, <8 x ptr> %67, <8 x ptr> %68
  %70 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %71 = extractvalue { <8 x ptr>, <8 x i64> } %66, 1
  %72 = select <8 x i1> %57, <8 x i64> %70, <8 x i64> %71
  %73 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %69, 0
  %74 = insertvalue { <8 x ptr>, <8 x i64> } %73, <8 x i64> %72, 1
  store { <8 x ptr>, <8 x i64> } %74, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %75 = icmp slt i64 %.state, 65
  br i1 %75, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %76 = add <8 x i64> %.spill.load, zeroinitializer
  %77 = add <8 x i64> zeroinitializer, %76
  %.state51 = load i64, ptr %.slot, align 4
  %78 = add i64 0, %.state51
  %79 = mul <8 x i64> %77, splat (i64 65)
  %.splatinsert52 = insertelement <8 x i64> poison, i64 %78, i64 0
  %.splat53 = shufflevector <8 x i64> %.splatinsert52, <8 x i64> poison, <8 x i32> zeroinitializer
  %80 = add <8 x i64> %79, %.splat53
  %81 = extractvalue { ptr, i64 } %15, 0
  %82 = mul <8 x i64> %80, splat (i64 4)
  %83 = getelementptr i8, ptr %81, <8 x i64> %82
  %84 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %83, <8 x i1> %57, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state54 = load i64, ptr %.slot, align 4
  %.splatinsert55 = insertelement <8 x i64> poison, i64 %.state54, i64 0
  %.splat56 = shufflevector <8 x i64> %.splatinsert55, <8 x i64> poison, <8 x i32> zeroinitializer
  %87 = mul <8 x i64> %.splat56, splat (i64 32)
  %88 = add <8 x i64> %86, %87
  %89 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %85, 0
  %90 = insertvalue { <8 x ptr>, <8 x i64> } %89, <8 x i64> %88, 1
  %91 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %92 = extractvalue { <8 x ptr>, <8 x i64> } %90, 1
  %93 = extractelement <8 x ptr> %91, i32 0
  %94 = extractelement <8 x i64> %92, i32 0
  %95 = sub i64 %94, 0
  %96 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %97 = select i1 %96, i64 %95, i64 0
  %private.contiguous.address = getelementptr i8, ptr %93, i64 %97
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %98 = select <8 x i1> %57, <8 x float> %84, <8 x float> %private.contiguous.preserve
  store <8 x float> %98, ptr %private.contiguous.address, align 4
  %.state57 = load i64, ptr %.slot, align 4
  %99 = add i64 %.state57, 1
  store i64 %99, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  %100 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %101 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %102 = extractvalue { <8 x ptr>, <8 x i64> } %100, 0
  %103 = select <8 x i1> %57, <8 x ptr> %101, <8 x ptr> %102
  %104 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %105 = extractvalue { <8 x ptr>, <8 x i64> } %100, 1
  %106 = select <8 x i1> %57, <8 x i64> %104, <8 x i64> %105
  %107 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %103, 0
  %108 = insertvalue { <8 x ptr>, <8 x i64> } %107, <8 x i64> %106, 1
  store { <8 x ptr>, <8 x i64> } %108, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state58 = load i64, ptr %.slot14, align 4
  %109 = icmp slt i64 %.state58, 65
  br i1 %109, label %direct.true59, label %direct.false60

direct.schedule.5:                                ; preds = %direct.true59
  %tile_snapshot.spill.load61 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %110 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 0
  %111 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load61, 1
  %.state62 = load i64, ptr %.slot14, align 4
  %.splatinsert63 = insertelement <8 x i64> poison, i64 %.state62, i64 0
  %.splat64 = shufflevector <8 x i64> %.splatinsert63, <8 x i64> poison, <8 x i32> zeroinitializer
  %112 = mul <8 x i64> %.splat64, splat (i64 64)
  %113 = add <8 x i64> %111, %112
  %114 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %110, 0
  %115 = insertvalue { <8 x ptr>, <8 x i64> } %114, <8 x i64> %113, 1
  %.state65 = load i64, ptr %.slot14, align 4
  %.splatinsert66 = insertelement <8 x i64> poison, i64 %.state65, i64 0
  %.splat67 = shufflevector <8 x i64> %.splatinsert66, <8 x i64> poison, <8 x i32> zeroinitializer
  %116 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %117 = extractvalue { <8 x ptr>, <8 x i64> } %115, 1
  %118 = extractelement <8 x ptr> %116, i32 0
  %119 = extractelement <8 x i64> %117, i32 0
  %120 = sub i64 %119, 0
  %121 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %122 = select i1 %121, i64 %120, i64 0
  %private.contiguous.address68 = getelementptr i8, ptr %118, i64 %122
  %private.contiguous.preserve69 = load <8 x i64>, ptr %private.contiguous.address68, align 8
  %123 = select <8 x i1> %57, <8 x i64> %.splat67, <8 x i64> %private.contiguous.preserve69
  store <8 x i64> %123, ptr %private.contiguous.address68, align 8
  %.state70 = load i64, ptr %.slot14, align 4
  %124 = add i64 %.state70, 1
  store i64 %124, ptr %.slot14, align 4
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false60
  %.spill.load71 = load <8 x i64>, ptr %.spill, align 64
  %125 = select <8 x i1> %57, <8 x i64> %.spill.load71, <8 x i64> zeroinitializer
  %126 = select <8 x i1> %57, <8 x i64> splat (i64 65), <8 x i64> splat (i64 1)
  %127 = srem <8 x i64> %125, %126
  %128 = load <8 x i64>, ptr %.spill15, align 64
  %129 = select <8 x i1> %57, <8 x i64> %127, <8 x i64> %128
  store <8 x i64> %129, ptr %.spill15, align 64
  %130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %131 = extractvalue { <8 x ptr>, <8 x i64> } %5, 0
  %132 = extractvalue { <8 x ptr>, <8 x i64> } %130, 0
  %133 = select <8 x i1> %57, <8 x ptr> %131, <8 x ptr> %132
  %134 = extractvalue { <8 x ptr>, <8 x i64> } %5, 1
  %135 = extractvalue { <8 x ptr>, <8 x i64> } %130, 1
  %136 = select <8 x i1> %57, <8 x i64> %134, <8 x i64> %135
  %137 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %133, 0
  %138 = insertvalue { <8 x ptr>, <8 x i64> } %137, <8 x i64> %136, 1
  store { <8 x ptr>, <8 x i64> } %138, ptr %tile_snapshot.spill16, align 64
  store i64 0, ptr %.slot17, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state72 = load i64, ptr %.slot17, align 4
  %139 = icmp slt i64 %.state72, 65
  br i1 %139, label %direct.true73, label %direct.false74

direct.schedule.8:                                ; preds = %direct.true73
  %.state75 = load i64, ptr %.slot17, align 4
  %140 = add i64 0, %.state75
  %tile_snapshot.spill.load76 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load76, 1
  %.splatinsert77 = insertelement <8 x i64> poison, i64 %140, i64 0
  %.splat78 = shufflevector <8 x i64> %.splatinsert77, <8 x i64> poison, <8 x i32> zeroinitializer
  %143 = mul <8 x i64> %.splat78, splat (i64 64)
  %144 = add <8 x i64> %142, %143
  %145 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %141, 0
  %146 = insertvalue { <8 x ptr>, <8 x i64> } %145, <8 x i64> %144, 1
  %147 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %148 = extractvalue { <8 x ptr>, <8 x i64> } %146, 1
  %149 = extractelement <8 x ptr> %147, i32 0
  %150 = extractelement <8 x i64> %148, i32 0
  %151 = sub i64 %150, 0
  %152 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %153 = select i1 %152, i64 %151, i64 0
  %private.contiguous.address79 = getelementptr i8, ptr %149, i64 %153
  %private.contiguous.load = load <8 x i64>, ptr %private.contiguous.address79, align 8
  %154 = select <8 x i1> %57, <8 x i64> %private.contiguous.load, <8 x i64> zeroinitializer
  %.spill.load80 = load <8 x i64>, ptr %.spill15, align 64
  %155 = icmp sle <8 x i64> %154, %.spill.load80
  %tile_snapshot.spill.load81 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %156 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 0
  %157 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load81, 1
  %.state82 = load i64, ptr %.slot17, align 4
  %.splatinsert83 = insertelement <8 x i64> poison, i64 %.state82, i64 0
  %.splat84 = shufflevector <8 x i64> %.splatinsert83, <8 x i64> poison, <8 x i32> zeroinitializer
  %158 = add <8 x i64> %157, %.splat84
  %159 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %156, 0
  %160 = insertvalue { <8 x ptr>, <8 x i64> } %159, <8 x i64> %158, 1
  %161 = extractvalue { <8 x ptr>, <8 x i64> } %160, 0
  %162 = extractvalue { <8 x ptr>, <8 x i64> } %160, 1
  %163 = getelementptr i8, <8 x ptr> %161, <8 x i64> %162
  %164 = zext <8 x i1> %155 to <8 x i8>
  call void @llvm.masked.scatter.v8i8.v8p0(<8 x i8> %164, <8 x ptr> align 1 %163, <8 x i1> %57)
  %.state85 = load i64, ptr %.slot17, align 4
  %165 = add i64 %.state85, 1
  store i64 %165, ptr %.slot17, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false74
  %166 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %167 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %168 = extractvalue { <8 x ptr>, <8 x i64> } %166, 0
  %169 = select <8 x i1> %57, <8 x ptr> %167, <8 x ptr> %168
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %7, 1
  %171 = extractvalue { <8 x ptr>, <8 x i64> } %166, 1
  %172 = select <8 x i1> %57, <8 x i64> %170, <8 x i64> %171
  %173 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %169, 0
  %174 = insertvalue { <8 x ptr>, <8 x i64> } %173, <8 x i64> %172, 1
  store { <8 x ptr>, <8 x i64> } %174, ptr %tile_snapshot.spill18, align 64
  store i64 0, ptr %.slot19, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state86 = load i64, ptr %.slot19, align 4
  %175 = icmp slt i64 %.state86, 65
  br i1 %175, label %direct.true87, label %direct.false88

direct.schedule.11:                               ; preds = %direct.true87
  %.state89 = load i64, ptr %.slot19, align 4
  %176 = add i64 0, %.state89
  %tile_snapshot.spill.load90 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %177 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 0
  %178 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load90, 1
  %.splatinsert91 = insertelement <8 x i64> poison, i64 %176, i64 0
  %.splat92 = shufflevector <8 x i64> %.splatinsert91, <8 x i64> poison, <8 x i32> zeroinitializer
  %179 = add <8 x i64> %178, %.splat92
  %180 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %177, 0
  %181 = insertvalue { <8 x ptr>, <8 x i64> } %180, <8 x i64> %179, 1
  %182 = extractvalue { <8 x ptr>, <8 x i64> } %181, 0
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %181, 1
  %184 = getelementptr i8, <8 x ptr> %182, <8 x i64> %183
  %185 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %184, <8 x i1> %57, <8 x i8> zeroinitializer)
  %186 = icmp ne <8 x i8> %185, zeroinitializer
  %tile_snapshot.spill.load93 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %187 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 0
  %188 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load93, 1
  %.splatinsert94 = insertelement <8 x i64> poison, i64 %176, i64 0
  %.splat95 = shufflevector <8 x i64> %.splatinsert94, <8 x i64> poison, <8 x i32> zeroinitializer
  %189 = mul <8 x i64> %.splat95, splat (i64 32)
  %190 = add <8 x i64> %188, %189
  %191 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %187, 0
  %192 = insertvalue { <8 x ptr>, <8 x i64> } %191, <8 x i64> %190, 1
  %193 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %194 = extractvalue { <8 x ptr>, <8 x i64> } %192, 1
  %195 = extractelement <8 x ptr> %193, i32 0
  %196 = extractelement <8 x i64> %194, i32 0
  %197 = sub i64 %196, 0
  %198 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %199 = select i1 %198, i64 %197, i64 0
  %private.contiguous.address96 = getelementptr i8, ptr %195, i64 %199
  %private.contiguous.load97 = load <8 x float>, ptr %private.contiguous.address96, align 4
  %200 = select <8 x i1> %57, <8 x float> %private.contiguous.load97, <8 x float> zeroinitializer
  %201 = select <8 x i1> %186, <8 x float> %200, <8 x float> splat (float 0xC6293E5940000000)
  %tile_snapshot.spill.load98 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %202 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 0
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load98, 1
  %.state99 = load i64, ptr %.slot19, align 4
  %.splatinsert100 = insertelement <8 x i64> poison, i64 %.state99, i64 0
  %.splat101 = shufflevector <8 x i64> %.splatinsert100, <8 x i64> poison, <8 x i32> zeroinitializer
  %204 = mul <8 x i64> %.splat101, splat (i64 32)
  %205 = add <8 x i64> %203, %204
  %206 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %202, 0
  %207 = insertvalue { <8 x ptr>, <8 x i64> } %206, <8 x i64> %205, 1
  %208 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %207, 1
  %210 = extractelement <8 x ptr> %208, i32 0
  %211 = extractelement <8 x i64> %209, i32 0
  %212 = sub i64 %211, 0
  %213 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %214 = select i1 %213, i64 %212, i64 0
  %private.contiguous.address102 = getelementptr i8, ptr %210, i64 %214
  %private.contiguous.preserve103 = load <8 x float>, ptr %private.contiguous.address102, align 4
  %215 = select <8 x i1> %57, <8 x float> %201, <8 x float> %private.contiguous.preserve103
  store <8 x float> %215, ptr %private.contiguous.address102, align 4
  %.state104 = load i64, ptr %.slot19, align 4
  %216 = add i64 %.state104, 1
  store i64 %216, ptr %.slot19, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false88
  store i64 0, ptr %.spill20, align 4
  store i64 0, ptr %.spill21, align 4
  %tile_snapshot.spill.load105 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %217 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load105, 0
  %218 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load105, 1
  %219 = add <8 x i64> %218, zeroinitializer
  %220 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %217, 0
  %221 = insertvalue { <8 x ptr>, <8 x i64> } %220, <8 x i64> %219, 1
  %222 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %221, 1
  %224 = extractelement <8 x ptr> %222, i32 0
  %225 = extractelement <8 x i64> %223, i32 0
  %226 = sub i64 %225, 0
  %227 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %228 = select i1 %227, i64 %226, i64 0
  %private.contiguous.address106 = getelementptr i8, ptr %224, i64 %228
  %private.contiguous.load107 = load <8 x float>, ptr %private.contiguous.address106, align 4
  %229 = select <8 x i1> %57, <8 x float> %private.contiguous.load107, <8 x float> zeroinitializer
  store i64 1, ptr %.spill22, align 4
  %tile_snapshot.spill.load108 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 0
  %231 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load108, 1
  %232 = add <8 x i64> %231, splat (i64 32)
  %233 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %230, 0
  %234 = insertvalue { <8 x ptr>, <8 x i64> } %233, <8 x i64> %232, 1
  %235 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %236 = extractvalue { <8 x ptr>, <8 x i64> } %234, 1
  %237 = extractelement <8 x ptr> %235, i32 0
  %238 = extractelement <8 x i64> %236, i32 0
  %239 = sub i64 %238, 0
  %240 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %241 = select i1 %240, i64 %239, i64 0
  %private.contiguous.address109 = getelementptr i8, ptr %237, i64 %241
  %private.contiguous.load110 = load <8 x float>, ptr %private.contiguous.address109, align 4
  %242 = select <8 x i1> %57, <8 x float> %private.contiguous.load110, <8 x float> zeroinitializer
  store i64 2, ptr %.spill23, align 4
  %tile_snapshot.spill.load111 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %243 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 0
  %244 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load111, 1
  %245 = add <8 x i64> %244, splat (i64 64)
  %246 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %243, 0
  %247 = insertvalue { <8 x ptr>, <8 x i64> } %246, <8 x i64> %245, 1
  %248 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %249 = extractvalue { <8 x ptr>, <8 x i64> } %247, 1
  %250 = extractelement <8 x ptr> %248, i32 0
  %251 = extractelement <8 x i64> %249, i32 0
  %252 = sub i64 %251, 0
  %253 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %254 = select i1 %253, i64 %252, i64 0
  %private.contiguous.address112 = getelementptr i8, ptr %250, i64 %254
  %private.contiguous.load113 = load <8 x float>, ptr %private.contiguous.address112, align 4
  %255 = select <8 x i1> %57, <8 x float> %private.contiguous.load113, <8 x float> zeroinitializer
  store i64 3, ptr %.spill24, align 4
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %258 = add <8 x i64> %257, splat (i64 96)
  %259 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %256, 0
  %260 = insertvalue { <8 x ptr>, <8 x i64> } %259, <8 x i64> %258, 1
  %261 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %262 = extractvalue { <8 x ptr>, <8 x i64> } %260, 1
  %263 = extractelement <8 x ptr> %261, i32 0
  %264 = extractelement <8 x i64> %262, i32 0
  %265 = sub i64 %264, 0
  %266 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %267 = select i1 %266, i64 %265, i64 0
  %private.contiguous.address115 = getelementptr i8, ptr %263, i64 %267
  %private.contiguous.load116 = load <8 x float>, ptr %private.contiguous.address115, align 4
  %268 = select <8 x i1> %57, <8 x float> %private.contiguous.load116, <8 x float> zeroinitializer
  store i64 4, ptr %.slot25, align 4
  %269 = load <8 x float>, ptr %.slot26, align 32
  %270 = select <8 x i1> %57, <8 x float> %229, <8 x float> %269
  store <8 x float> %270, ptr %.slot26, align 32
  %271 = load <8 x float>, ptr %.slot27, align 32
  %272 = select <8 x i1> %57, <8 x float> %242, <8 x float> %271
  store <8 x float> %272, ptr %.slot27, align 32
  %273 = load <8 x float>, ptr %.slot28, align 32
  %274 = select <8 x i1> %57, <8 x float> %255, <8 x float> %273
  store <8 x float> %274, ptr %.slot28, align 32
  %275 = load <8 x float>, ptr %.slot29, align 32
  %276 = select <8 x i1> %57, <8 x float> %268, <8 x float> %275
  store <8 x float> %276, ptr %.slot29, align 32
  br label %direct.schedule.13

direct.schedule.13:                               ; preds = %direct.schedule.14, %direct.schedule.12
  %.state117 = load i64, ptr %.slot25, align 4
  %277 = icmp slt i64 %.state117, 64
  br i1 %277, label %direct.true118, label %direct.false119

direct.schedule.14:                               ; preds = %direct.true118
  %.state120 = load i64, ptr %.slot25, align 4
  %278 = add i64 %.state120, 0
  %279 = sdiv i64 %278, 1
  %.spill.load121 = load i64, ptr %.spill20, align 4
  %280 = add i64 %.spill.load121, %279
  %tile_snapshot.spill.load122 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %281 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 0
  %282 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load122, 1
  %.splatinsert123 = insertelement <8 x i64> poison, i64 %280, i64 0
  %.splat124 = shufflevector <8 x i64> %.splatinsert123, <8 x i64> poison, <8 x i32> zeroinitializer
  %283 = mul <8 x i64> %.splat124, splat (i64 32)
  %284 = add <8 x i64> %282, %283
  %285 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %281, 0
  %286 = insertvalue { <8 x ptr>, <8 x i64> } %285, <8 x i64> %284, 1
  %287 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %288 = extractvalue { <8 x ptr>, <8 x i64> } %286, 1
  %289 = extractelement <8 x ptr> %287, i32 0
  %290 = extractelement <8 x i64> %288, i32 0
  %291 = sub i64 %290, 0
  %292 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %293 = select i1 %292, i64 %291, i64 0
  %private.contiguous.address125 = getelementptr i8, ptr %289, i64 %293
  %private.contiguous.load126 = load <8 x float>, ptr %private.contiguous.address125, align 4
  %294 = select <8 x i1> %57, <8 x float> %private.contiguous.load126, <8 x float> zeroinitializer
  %.state127 = load <8 x float>, ptr %.slot26, align 32
  %295 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state127, <8 x float> %294)
  %.state128 = load i64, ptr %.slot25, align 4
  %296 = add i64 %.state128, 1
  %297 = sdiv i64 %296, 1
  %.spill.load129 = load i64, ptr %.spill20, align 4
  %298 = add i64 %.spill.load129, %297
  %tile_snapshot.spill.load130 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %299 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 0
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load130, 1
  %.splatinsert131 = insertelement <8 x i64> poison, i64 %298, i64 0
  %.splat132 = shufflevector <8 x i64> %.splatinsert131, <8 x i64> poison, <8 x i32> zeroinitializer
  %301 = mul <8 x i64> %.splat132, splat (i64 32)
  %302 = add <8 x i64> %300, %301
  %303 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %299, 0
  %304 = insertvalue { <8 x ptr>, <8 x i64> } %303, <8 x i64> %302, 1
  %305 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %304, 1
  %307 = extractelement <8 x ptr> %305, i32 0
  %308 = extractelement <8 x i64> %306, i32 0
  %309 = sub i64 %308, 0
  %310 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %311 = select i1 %310, i64 %309, i64 0
  %private.contiguous.address133 = getelementptr i8, ptr %307, i64 %311
  %private.contiguous.load134 = load <8 x float>, ptr %private.contiguous.address133, align 4
  %312 = select <8 x i1> %57, <8 x float> %private.contiguous.load134, <8 x float> zeroinitializer
  %.state135 = load <8 x float>, ptr %.slot27, align 32
  %313 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state135, <8 x float> %312)
  %.state136 = load i64, ptr %.slot25, align 4
  %314 = add i64 %.state136, 2
  %315 = sdiv i64 %314, 1
  %.spill.load137 = load i64, ptr %.spill20, align 4
  %316 = add i64 %.spill.load137, %315
  %tile_snapshot.spill.load138 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %317 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 0
  %318 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load138, 1
  %.splatinsert139 = insertelement <8 x i64> poison, i64 %316, i64 0
  %.splat140 = shufflevector <8 x i64> %.splatinsert139, <8 x i64> poison, <8 x i32> zeroinitializer
  %319 = mul <8 x i64> %.splat140, splat (i64 32)
  %320 = add <8 x i64> %318, %319
  %321 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %317, 0
  %322 = insertvalue { <8 x ptr>, <8 x i64> } %321, <8 x i64> %320, 1
  %323 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %324 = extractvalue { <8 x ptr>, <8 x i64> } %322, 1
  %325 = extractelement <8 x ptr> %323, i32 0
  %326 = extractelement <8 x i64> %324, i32 0
  %327 = sub i64 %326, 0
  %328 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %329 = select i1 %328, i64 %327, i64 0
  %private.contiguous.address141 = getelementptr i8, ptr %325, i64 %329
  %private.contiguous.load142 = load <8 x float>, ptr %private.contiguous.address141, align 4
  %330 = select <8 x i1> %57, <8 x float> %private.contiguous.load142, <8 x float> zeroinitializer
  %.state143 = load <8 x float>, ptr %.slot28, align 32
  %331 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state143, <8 x float> %330)
  %.state144 = load i64, ptr %.slot25, align 4
  %332 = add i64 %.state144, 3
  %333 = sdiv i64 %332, 1
  %.spill.load145 = load i64, ptr %.spill20, align 4
  %334 = add i64 %.spill.load145, %333
  %tile_snapshot.spill.load146 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %335 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load146, 0
  %336 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load146, 1
  %.splatinsert147 = insertelement <8 x i64> poison, i64 %334, i64 0
  %.splat148 = shufflevector <8 x i64> %.splatinsert147, <8 x i64> poison, <8 x i32> zeroinitializer
  %337 = mul <8 x i64> %.splat148, splat (i64 32)
  %338 = add <8 x i64> %336, %337
  %339 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %335, 0
  %340 = insertvalue { <8 x ptr>, <8 x i64> } %339, <8 x i64> %338, 1
  %341 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %342 = extractvalue { <8 x ptr>, <8 x i64> } %340, 1
  %343 = extractelement <8 x ptr> %341, i32 0
  %344 = extractelement <8 x i64> %342, i32 0
  %345 = sub i64 %344, 0
  %346 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %347 = select i1 %346, i64 %345, i64 0
  %private.contiguous.address149 = getelementptr i8, ptr %343, i64 %347
  %private.contiguous.load150 = load <8 x float>, ptr %private.contiguous.address149, align 4
  %348 = select <8 x i1> %57, <8 x float> %private.contiguous.load150, <8 x float> zeroinitializer
  %.state151 = load <8 x float>, ptr %.slot29, align 32
  %349 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state151, <8 x float> %348)
  %.state152 = load i64, ptr %.slot25, align 4
  %350 = add i64 %.state152, 4
  store i64 %350, ptr %.slot25, align 4
  %351 = load <8 x float>, ptr %.slot26, align 32
  %352 = select <8 x i1> %57, <8 x float> %295, <8 x float> %351
  store <8 x float> %352, ptr %.slot26, align 32
  %353 = load <8 x float>, ptr %.slot27, align 32
  %354 = select <8 x i1> %57, <8 x float> %313, <8 x float> %353
  store <8 x float> %354, ptr %.slot27, align 32
  %355 = load <8 x float>, ptr %.slot28, align 32
  %356 = select <8 x i1> %57, <8 x float> %331, <8 x float> %355
  store <8 x float> %356, ptr %.slot28, align 32
  %357 = load <8 x float>, ptr %.slot29, align 32
  %358 = select <8 x i1> %57, <8 x float> %349, <8 x float> %357
  store <8 x float> %358, ptr %.slot29, align 32
  br label %direct.schedule.13

direct.schedule.15:                               ; preds = %direct.false119
  %.spill.load153 = load i64, ptr %.spill20, align 4
  %359 = add i64 %.spill.load153, 64
  store i64 %359, ptr %.spill30, align 4
  %tile_snapshot.spill.load154 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %360 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 0
  %361 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load154, 1
  %.splatinsert155 = insertelement <8 x i64> poison, i64 %359, i64 0
  %.splat156 = shufflevector <8 x i64> %.splatinsert155, <8 x i64> poison, <8 x i32> zeroinitializer
  %362 = mul <8 x i64> %.splat156, splat (i64 32)
  %363 = add <8 x i64> %361, %362
  %364 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %360, 0
  %365 = insertvalue { <8 x ptr>, <8 x i64> } %364, <8 x i64> %363, 1
  %366 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %367 = extractvalue { <8 x ptr>, <8 x i64> } %365, 1
  %368 = extractelement <8 x ptr> %366, i32 0
  %369 = extractelement <8 x i64> %367, i32 0
  %370 = sub i64 %369, 0
  %371 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %372 = select i1 %371, i64 %370, i64 0
  %private.contiguous.address157 = getelementptr i8, ptr %368, i64 %372
  %private.contiguous.load158 = load <8 x float>, ptr %private.contiguous.address157, align 4
  %373 = select <8 x i1> %57, <8 x float> %private.contiguous.load158, <8 x float> zeroinitializer
  %.state159 = load <8 x float>, ptr %.slot26, align 32
  %374 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %.state159, <8 x float> %373)
  %375 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> splat (float 0xFFF0000000000000), <8 x float> %374)
  %.state160 = load <8 x float>, ptr %.slot27, align 32
  %376 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %375, <8 x float> %.state160)
  %.state161 = load <8 x float>, ptr %.slot28, align 32
  %377 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %376, <8 x float> %.state161)
  %.state162 = load <8 x float>, ptr %.slot29, align 32
  %378 = call <8 x float> @llvm.maxnum.v8f32(<8 x float> %377, <8 x float> %.state162)
  %379 = load <8 x float>, ptr %.spill31, align 32
  %380 = select <8 x i1> %57, <8 x float> %378, <8 x float> %379
  store <8 x float> %380, ptr %.spill31, align 32
  %381 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %382 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %383 = extractvalue { <8 x ptr>, <8 x i64> } %381, 0
  %384 = select <8 x i1> %57, <8 x ptr> %382, <8 x ptr> %383
  %385 = extractvalue { <8 x ptr>, <8 x i64> } %9, 1
  %386 = extractvalue { <8 x ptr>, <8 x i64> } %381, 1
  %387 = select <8 x i1> %57, <8 x i64> %385, <8 x i64> %386
  %388 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %384, 0
  %389 = insertvalue { <8 x ptr>, <8 x i64> } %388, <8 x i64> %387, 1
  store { <8 x ptr>, <8 x i64> } %389, ptr %tile_snapshot.spill32, align 64
  store i64 0, ptr %.slot33, align 4
  br label %direct.schedule.16

direct.schedule.16:                               ; preds = %direct.schedule.17, %direct.schedule.15
  %.state163 = load i64, ptr %.slot33, align 4
  %390 = icmp slt i64 %.state163, 65
  br i1 %390, label %direct.true164, label %direct.false165

direct.schedule.17:                               ; preds = %direct.true164
  %.state166 = load i64, ptr %.slot33, align 4
  %391 = add i64 0, %.state166
  %tile_snapshot.spill.load167 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill16, align 64
  %392 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 0
  %393 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load167, 1
  %.splatinsert168 = insertelement <8 x i64> poison, i64 %391, i64 0
  %.splat169 = shufflevector <8 x i64> %.splatinsert168, <8 x i64> poison, <8 x i32> zeroinitializer
  %394 = add <8 x i64> %393, %.splat169
  %395 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %392, 0
  %396 = insertvalue { <8 x ptr>, <8 x i64> } %395, <8 x i64> %394, 1
  %397 = extractvalue { <8 x ptr>, <8 x i64> } %396, 0
  %398 = extractvalue { <8 x ptr>, <8 x i64> } %396, 1
  %399 = getelementptr i8, <8 x ptr> %397, <8 x i64> %398
  %400 = call <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr> align 1 %399, <8 x i1> %57, <8 x i8> zeroinitializer)
  %401 = icmp ne <8 x i8> %400, zeroinitializer
  %402 = add i64 0, %391
  %403 = add i64 0, %402
  %tile_snapshot.spill.load170 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill18, align 64
  %404 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load170, 0
  %405 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load170, 1
  %.splatinsert171 = insertelement <8 x i64> poison, i64 %403, i64 0
  %.splat172 = shufflevector <8 x i64> %.splatinsert171, <8 x i64> poison, <8 x i32> zeroinitializer
  %406 = mul <8 x i64> %.splat172, splat (i64 32)
  %407 = add <8 x i64> %405, %406
  %408 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %404, 0
  %409 = insertvalue { <8 x ptr>, <8 x i64> } %408, <8 x i64> %407, 1
  %410 = extractvalue { <8 x ptr>, <8 x i64> } %7, 0
  %411 = extractvalue { <8 x ptr>, <8 x i64> } %409, 1
  %412 = extractelement <8 x ptr> %410, i32 0
  %413 = extractelement <8 x i64> %411, i32 0
  %414 = sub i64 %413, 0
  %415 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %416 = select i1 %415, i64 %414, i64 0
  %private.contiguous.address173 = getelementptr i8, ptr %412, i64 %416
  %private.contiguous.load174 = load <8 x float>, ptr %private.contiguous.address173, align 4
  %417 = select <8 x i1> %57, <8 x float> %private.contiguous.load174, <8 x float> zeroinitializer
  %.spill.load175 = load <8 x float>, ptr %.spill31, align 32
  %418 = fsub <8 x float> %417, %.spill.load175
  %419 = select <8 x i1> %57, <8 x float> %418, <8 x float> zeroinitializer
  %native.exp = call <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %419)
  %420 = select <8 x i1> %401, <8 x float> %native.exp, <8 x float> zeroinitializer
  %tile_snapshot.spill.load176 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %421 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 0
  %422 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load176, 1
  %.state177 = load i64, ptr %.slot33, align 4
  %.splatinsert178 = insertelement <8 x i64> poison, i64 %.state177, i64 0
  %.splat179 = shufflevector <8 x i64> %.splatinsert178, <8 x i64> poison, <8 x i32> zeroinitializer
  %423 = mul <8 x i64> %.splat179, splat (i64 32)
  %424 = add <8 x i64> %422, %423
  %425 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %421, 0
  %426 = insertvalue { <8 x ptr>, <8 x i64> } %425, <8 x i64> %424, 1
  %427 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %428 = extractvalue { <8 x ptr>, <8 x i64> } %426, 1
  %429 = extractelement <8 x ptr> %427, i32 0
  %430 = extractelement <8 x i64> %428, i32 0
  %431 = sub i64 %430, 0
  %432 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %433 = select i1 %432, i64 %431, i64 0
  %private.contiguous.address180 = getelementptr i8, ptr %429, i64 %433
  %private.contiguous.preserve181 = load <8 x float>, ptr %private.contiguous.address180, align 4
  %434 = select <8 x i1> %57, <8 x float> %420, <8 x float> %private.contiguous.preserve181
  store <8 x float> %434, ptr %private.contiguous.address180, align 4
  %.state182 = load i64, ptr %.slot33, align 4
  %435 = add i64 %.state182, 1
  store i64 %435, ptr %.slot33, align 4
  br label %direct.schedule.16

direct.schedule.18:                               ; preds = %direct.false165
  %tile_snapshot.spill.load183 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %436 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 0
  %437 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load183, 1
  %.spill.load184 = load i64, ptr %.spill21, align 4
  %.splatinsert185 = insertelement <8 x i64> poison, i64 %.spill.load184, i64 0
  %.splat186 = shufflevector <8 x i64> %.splatinsert185, <8 x i64> poison, <8 x i32> zeroinitializer
  %438 = mul <8 x i64> %.splat186, splat (i64 32)
  %439 = add <8 x i64> %437, %438
  %440 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %436, 0
  %441 = insertvalue { <8 x ptr>, <8 x i64> } %440, <8 x i64> %439, 1
  %442 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %443 = extractvalue { <8 x ptr>, <8 x i64> } %441, 1
  %444 = extractelement <8 x ptr> %442, i32 0
  %445 = extractelement <8 x i64> %443, i32 0
  %446 = sub i64 %445, 0
  %447 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %448 = select i1 %447, i64 %446, i64 0
  %private.contiguous.address187 = getelementptr i8, ptr %444, i64 %448
  %private.contiguous.load188 = load <8 x float>, ptr %private.contiguous.address187, align 4
  %449 = select <8 x i1> %57, <8 x float> %private.contiguous.load188, <8 x float> zeroinitializer
  %tile_snapshot.spill.load189 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %450 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 0
  %451 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load189, 1
  %.spill.load190 = load i64, ptr %.spill22, align 4
  %.splatinsert191 = insertelement <8 x i64> poison, i64 %.spill.load190, i64 0
  %.splat192 = shufflevector <8 x i64> %.splatinsert191, <8 x i64> poison, <8 x i32> zeroinitializer
  %452 = mul <8 x i64> %.splat192, splat (i64 32)
  %453 = add <8 x i64> %451, %452
  %454 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %450, 0
  %455 = insertvalue { <8 x ptr>, <8 x i64> } %454, <8 x i64> %453, 1
  %456 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %457 = extractvalue { <8 x ptr>, <8 x i64> } %455, 1
  %458 = extractelement <8 x ptr> %456, i32 0
  %459 = extractelement <8 x i64> %457, i32 0
  %460 = sub i64 %459, 0
  %461 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %462 = select i1 %461, i64 %460, i64 0
  %private.contiguous.address193 = getelementptr i8, ptr %458, i64 %462
  %private.contiguous.load194 = load <8 x float>, ptr %private.contiguous.address193, align 4
  %463 = select <8 x i1> %57, <8 x float> %private.contiguous.load194, <8 x float> zeroinitializer
  %tile_snapshot.spill.load195 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %464 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 0
  %465 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load195, 1
  %.spill.load196 = load i64, ptr %.spill23, align 4
  %.splatinsert197 = insertelement <8 x i64> poison, i64 %.spill.load196, i64 0
  %.splat198 = shufflevector <8 x i64> %.splatinsert197, <8 x i64> poison, <8 x i32> zeroinitializer
  %466 = mul <8 x i64> %.splat198, splat (i64 32)
  %467 = add <8 x i64> %465, %466
  %468 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %464, 0
  %469 = insertvalue { <8 x ptr>, <8 x i64> } %468, <8 x i64> %467, 1
  %470 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %471 = extractvalue { <8 x ptr>, <8 x i64> } %469, 1
  %472 = extractelement <8 x ptr> %470, i32 0
  %473 = extractelement <8 x i64> %471, i32 0
  %474 = sub i64 %473, 0
  %475 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %476 = select i1 %475, i64 %474, i64 0
  %private.contiguous.address199 = getelementptr i8, ptr %472, i64 %476
  %private.contiguous.load200 = load <8 x float>, ptr %private.contiguous.address199, align 4
  %477 = select <8 x i1> %57, <8 x float> %private.contiguous.load200, <8 x float> zeroinitializer
  %tile_snapshot.spill.load201 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %478 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 0
  %479 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load201, 1
  %.spill.load202 = load i64, ptr %.spill24, align 4
  %.splatinsert203 = insertelement <8 x i64> poison, i64 %.spill.load202, i64 0
  %.splat204 = shufflevector <8 x i64> %.splatinsert203, <8 x i64> poison, <8 x i32> zeroinitializer
  %480 = mul <8 x i64> %.splat204, splat (i64 32)
  %481 = add <8 x i64> %479, %480
  %482 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %478, 0
  %483 = insertvalue { <8 x ptr>, <8 x i64> } %482, <8 x i64> %481, 1
  %484 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %485 = extractvalue { <8 x ptr>, <8 x i64> } %483, 1
  %486 = extractelement <8 x ptr> %484, i32 0
  %487 = extractelement <8 x i64> %485, i32 0
  %488 = sub i64 %487, 0
  %489 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %490 = select i1 %489, i64 %488, i64 0
  %private.contiguous.address205 = getelementptr i8, ptr %486, i64 %490
  %private.contiguous.load206 = load <8 x float>, ptr %private.contiguous.address205, align 4
  %491 = select <8 x i1> %57, <8 x float> %private.contiguous.load206, <8 x float> zeroinitializer
  store i64 4, ptr %.slot34, align 4
  %492 = load <8 x float>, ptr %.slot35, align 32
  %493 = select <8 x i1> %57, <8 x float> %449, <8 x float> %492
  store <8 x float> %493, ptr %.slot35, align 32
  %494 = load <8 x float>, ptr %.slot36, align 32
  %495 = select <8 x i1> %57, <8 x float> %463, <8 x float> %494
  store <8 x float> %495, ptr %.slot36, align 32
  %496 = load <8 x float>, ptr %.slot37, align 32
  %497 = select <8 x i1> %57, <8 x float> %477, <8 x float> %496
  store <8 x float> %497, ptr %.slot37, align 32
  %498 = load <8 x float>, ptr %.slot38, align 32
  %499 = select <8 x i1> %57, <8 x float> %491, <8 x float> %498
  store <8 x float> %499, ptr %.slot38, align 32
  br label %direct.schedule.19

direct.schedule.19:                               ; preds = %direct.schedule.20, %direct.schedule.18
  %.state207 = load i64, ptr %.slot34, align 4
  %500 = icmp slt i64 %.state207, 64
  br i1 %500, label %direct.true208, label %direct.false209

direct.schedule.20:                               ; preds = %direct.true208
  %.state210 = load i64, ptr %.slot34, align 4
  %501 = add i64 %.state210, 0
  %502 = sdiv i64 %501, 1
  %.spill.load211 = load i64, ptr %.spill20, align 4
  %503 = add i64 %.spill.load211, %502
  %tile_snapshot.spill.load212 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %504 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load212, 0
  %505 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load212, 1
  %.splatinsert213 = insertelement <8 x i64> poison, i64 %503, i64 0
  %.splat214 = shufflevector <8 x i64> %.splatinsert213, <8 x i64> poison, <8 x i32> zeroinitializer
  %506 = mul <8 x i64> %.splat214, splat (i64 32)
  %507 = add <8 x i64> %505, %506
  %508 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %504, 0
  %509 = insertvalue { <8 x ptr>, <8 x i64> } %508, <8 x i64> %507, 1
  %510 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %511 = extractvalue { <8 x ptr>, <8 x i64> } %509, 1
  %512 = extractelement <8 x ptr> %510, i32 0
  %513 = extractelement <8 x i64> %511, i32 0
  %514 = sub i64 %513, 0
  %515 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %516 = select i1 %515, i64 %514, i64 0
  %private.contiguous.address215 = getelementptr i8, ptr %512, i64 %516
  %private.contiguous.load216 = load <8 x float>, ptr %private.contiguous.address215, align 4
  %517 = select <8 x i1> %57, <8 x float> %private.contiguous.load216, <8 x float> zeroinitializer
  %.state217 = load <8 x float>, ptr %.slot35, align 32
  %518 = fadd <8 x float> %.state217, %517
  %.state218 = load i64, ptr %.slot34, align 4
  %519 = add i64 %.state218, 1
  %520 = sdiv i64 %519, 1
  %.spill.load219 = load i64, ptr %.spill20, align 4
  %521 = add i64 %.spill.load219, %520
  %tile_snapshot.spill.load220 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %522 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 0
  %523 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load220, 1
  %.splatinsert221 = insertelement <8 x i64> poison, i64 %521, i64 0
  %.splat222 = shufflevector <8 x i64> %.splatinsert221, <8 x i64> poison, <8 x i32> zeroinitializer
  %524 = mul <8 x i64> %.splat222, splat (i64 32)
  %525 = add <8 x i64> %523, %524
  %526 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %522, 0
  %527 = insertvalue { <8 x ptr>, <8 x i64> } %526, <8 x i64> %525, 1
  %528 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %529 = extractvalue { <8 x ptr>, <8 x i64> } %527, 1
  %530 = extractelement <8 x ptr> %528, i32 0
  %531 = extractelement <8 x i64> %529, i32 0
  %532 = sub i64 %531, 0
  %533 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %534 = select i1 %533, i64 %532, i64 0
  %private.contiguous.address223 = getelementptr i8, ptr %530, i64 %534
  %private.contiguous.load224 = load <8 x float>, ptr %private.contiguous.address223, align 4
  %535 = select <8 x i1> %57, <8 x float> %private.contiguous.load224, <8 x float> zeroinitializer
  %.state225 = load <8 x float>, ptr %.slot36, align 32
  %536 = fadd <8 x float> %.state225, %535
  %.state226 = load i64, ptr %.slot34, align 4
  %537 = add i64 %.state226, 2
  %538 = sdiv i64 %537, 1
  %.spill.load227 = load i64, ptr %.spill20, align 4
  %539 = add i64 %.spill.load227, %538
  %tile_snapshot.spill.load228 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %540 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load228, 0
  %541 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load228, 1
  %.splatinsert229 = insertelement <8 x i64> poison, i64 %539, i64 0
  %.splat230 = shufflevector <8 x i64> %.splatinsert229, <8 x i64> poison, <8 x i32> zeroinitializer
  %542 = mul <8 x i64> %.splat230, splat (i64 32)
  %543 = add <8 x i64> %541, %542
  %544 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %540, 0
  %545 = insertvalue { <8 x ptr>, <8 x i64> } %544, <8 x i64> %543, 1
  %546 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %547 = extractvalue { <8 x ptr>, <8 x i64> } %545, 1
  %548 = extractelement <8 x ptr> %546, i32 0
  %549 = extractelement <8 x i64> %547, i32 0
  %550 = sub i64 %549, 0
  %551 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %552 = select i1 %551, i64 %550, i64 0
  %private.contiguous.address231 = getelementptr i8, ptr %548, i64 %552
  %private.contiguous.load232 = load <8 x float>, ptr %private.contiguous.address231, align 4
  %553 = select <8 x i1> %57, <8 x float> %private.contiguous.load232, <8 x float> zeroinitializer
  %.state233 = load <8 x float>, ptr %.slot37, align 32
  %554 = fadd <8 x float> %.state233, %553
  %.state234 = load i64, ptr %.slot34, align 4
  %555 = add i64 %.state234, 3
  %556 = sdiv i64 %555, 1
  %.spill.load235 = load i64, ptr %.spill20, align 4
  %557 = add i64 %.spill.load235, %556
  %tile_snapshot.spill.load236 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %558 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 0
  %559 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load236, 1
  %.splatinsert237 = insertelement <8 x i64> poison, i64 %557, i64 0
  %.splat238 = shufflevector <8 x i64> %.splatinsert237, <8 x i64> poison, <8 x i32> zeroinitializer
  %560 = mul <8 x i64> %.splat238, splat (i64 32)
  %561 = add <8 x i64> %559, %560
  %562 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %558, 0
  %563 = insertvalue { <8 x ptr>, <8 x i64> } %562, <8 x i64> %561, 1
  %564 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %565 = extractvalue { <8 x ptr>, <8 x i64> } %563, 1
  %566 = extractelement <8 x ptr> %564, i32 0
  %567 = extractelement <8 x i64> %565, i32 0
  %568 = sub i64 %567, 0
  %569 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %570 = select i1 %569, i64 %568, i64 0
  %private.contiguous.address239 = getelementptr i8, ptr %566, i64 %570
  %private.contiguous.load240 = load <8 x float>, ptr %private.contiguous.address239, align 4
  %571 = select <8 x i1> %57, <8 x float> %private.contiguous.load240, <8 x float> zeroinitializer
  %.state241 = load <8 x float>, ptr %.slot38, align 32
  %572 = fadd <8 x float> %.state241, %571
  %.state242 = load i64, ptr %.slot34, align 4
  %573 = add i64 %.state242, 4
  store i64 %573, ptr %.slot34, align 4
  %574 = load <8 x float>, ptr %.slot35, align 32
  %575 = select <8 x i1> %57, <8 x float> %518, <8 x float> %574
  store <8 x float> %575, ptr %.slot35, align 32
  %576 = load <8 x float>, ptr %.slot36, align 32
  %577 = select <8 x i1> %57, <8 x float> %536, <8 x float> %576
  store <8 x float> %577, ptr %.slot36, align 32
  %578 = load <8 x float>, ptr %.slot37, align 32
  %579 = select <8 x i1> %57, <8 x float> %554, <8 x float> %578
  store <8 x float> %579, ptr %.slot37, align 32
  %580 = load <8 x float>, ptr %.slot38, align 32
  %581 = select <8 x i1> %57, <8 x float> %572, <8 x float> %580
  store <8 x float> %581, ptr %.slot38, align 32
  br label %direct.schedule.19

direct.schedule.21:                               ; preds = %direct.false209
  %tile_snapshot.spill.load243 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %582 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 0
  %583 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load243, 1
  %.spill.load244 = load i64, ptr %.spill30, align 4
  %.splatinsert245 = insertelement <8 x i64> poison, i64 %.spill.load244, i64 0
  %.splat246 = shufflevector <8 x i64> %.splatinsert245, <8 x i64> poison, <8 x i32> zeroinitializer
  %584 = mul <8 x i64> %.splat246, splat (i64 32)
  %585 = add <8 x i64> %583, %584
  %586 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %582, 0
  %587 = insertvalue { <8 x ptr>, <8 x i64> } %586, <8 x i64> %585, 1
  %588 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %589 = extractvalue { <8 x ptr>, <8 x i64> } %587, 1
  %590 = extractelement <8 x ptr> %588, i32 0
  %591 = extractelement <8 x i64> %589, i32 0
  %592 = sub i64 %591, 0
  %593 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %594 = select i1 %593, i64 %592, i64 0
  %private.contiguous.address247 = getelementptr i8, ptr %590, i64 %594
  %private.contiguous.load248 = load <8 x float>, ptr %private.contiguous.address247, align 4
  %595 = select <8 x i1> %57, <8 x float> %private.contiguous.load248, <8 x float> zeroinitializer
  %.state249 = load <8 x float>, ptr %.slot35, align 32
  %596 = fadd <8 x float> %.state249, %595
  %597 = fadd <8 x float> zeroinitializer, %596
  %.state250 = load <8 x float>, ptr %.slot36, align 32
  %598 = fadd <8 x float> %597, %.state250
  %.state251 = load <8 x float>, ptr %.slot37, align 32
  %599 = fadd <8 x float> %598, %.state251
  %.state252 = load <8 x float>, ptr %.slot38, align 32
  %600 = fadd <8 x float> %599, %.state252
  %601 = load <8 x float>, ptr %.spill39, align 32
  %602 = select <8 x i1> %57, <8 x float> %600, <8 x float> %601
  store <8 x float> %602, ptr %.spill39, align 32
  store i64 0, ptr %.slot40, align 4
  br label %direct.schedule.22

direct.schedule.22:                               ; preds = %direct.schedule.23, %direct.schedule.21
  %.state253 = load i64, ptr %.slot40, align 4
  %603 = icmp slt i64 %.state253, 65
  br i1 %603, label %direct.true254, label %direct.false255

direct.schedule.23:                               ; preds = %direct.true254
  %.spill.load256 = load <8 x i64>, ptr %.spill, align 64
  %604 = add <8 x i64> %.spill.load256, zeroinitializer
  %605 = add <8 x i64> zeroinitializer, %604
  %.state257 = load i64, ptr %.slot40, align 4
  %606 = add i64 0, %.state257
  %607 = mul <8 x i64> %605, splat (i64 65)
  %.splatinsert258 = insertelement <8 x i64> poison, i64 %606, i64 0
  %.splat259 = shufflevector <8 x i64> %.splatinsert258, <8 x i64> poison, <8 x i32> zeroinitializer
  %608 = add <8 x i64> %607, %.splat259
  %.state260 = load i64, ptr %.slot40, align 4
  %609 = add i64 0, %.state260
  %tile_snapshot.spill.load261 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill32, align 64
  %610 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load261, 0
  %611 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load261, 1
  %.splatinsert262 = insertelement <8 x i64> poison, i64 %609, i64 0
  %.splat263 = shufflevector <8 x i64> %.splatinsert262, <8 x i64> poison, <8 x i32> zeroinitializer
  %612 = mul <8 x i64> %.splat263, splat (i64 32)
  %613 = add <8 x i64> %611, %612
  %614 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %610, 0
  %615 = insertvalue { <8 x ptr>, <8 x i64> } %614, <8 x i64> %613, 1
  %616 = extractvalue { <8 x ptr>, <8 x i64> } %9, 0
  %617 = extractvalue { <8 x ptr>, <8 x i64> } %615, 1
  %618 = extractelement <8 x ptr> %616, i32 0
  %619 = extractelement <8 x i64> %617, i32 0
  %620 = sub i64 %619, 0
  %621 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %57)
  %622 = select i1 %621, i64 %620, i64 0
  %private.contiguous.address264 = getelementptr i8, ptr %618, i64 %622
  %private.contiguous.load265 = load <8 x float>, ptr %private.contiguous.address264, align 4
  %623 = select <8 x i1> %57, <8 x float> %private.contiguous.load265, <8 x float> zeroinitializer
  %.spill.load266 = load <8 x float>, ptr %.spill39, align 32
  %624 = fdiv <8 x float> %623, %.spill.load266
  %625 = extractvalue { ptr, i64 } %33, 0
  %626 = mul <8 x i64> %608, splat (i64 4)
  %627 = getelementptr i8, ptr %625, <8 x i64> %626
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %624, <8 x ptr> align 1 %627, <8 x i1> %57)
  %.state267 = load i64, ptr %.slot40, align 4
  %628 = add i64 %.state267, 1
  store i64 %628, ptr %.slot40, align 4
  br label %direct.schedule.22

direct.schedule.24:                               ; preds = %direct.false255
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true59:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false60:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true73:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false74:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true87:                                    ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false88:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.12

direct.true118:                                   ; preds = %direct.schedule.13
  br label %direct.schedule.14

direct.false119:                                  ; preds = %direct.schedule.13
  br label %direct.schedule.15

direct.true164:                                   ; preds = %direct.schedule.16
  br label %direct.schedule.17

direct.false165:                                  ; preds = %direct.schedule.16
  br label %direct.schedule.18

direct.true208:                                   ; preds = %direct.schedule.19
  br label %direct.schedule.20

direct.false209:                                  ; preds = %direct.schedule.19
  br label %direct.schedule.21

direct.true254:                                   ; preds = %direct.schedule.22
  br label %direct.schedule.23

direct.false255:                                  ; preds = %direct.schedule.22
  br label %direct.schedule.24
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8i8.v8p0(<8 x i8>, <8 x ptr>, <8 x i1>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x i8> @llvm.masked.gather.v8i8.v8p0(<8 x ptr>, <8 x i1>, <8 x i8>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.maxnum.v8f32(<8 x float>, <8 x float>) #3

; Function Attrs: alwaysinline norecurse nounwind willreturn memory(none)
define internal <8 x float> @__luisa_cpu_native_exp_f32_v8_u10(<8 x float> %x) #4 {
entry:
  %0 = fcmp oge <8 x float> %x, splat (float -1.040000e+02)
  %1 = fcmp ole <8 x float> %x, splat (float 1.000000e+02)
  %2 = and <8 x i1> %0, %1
  %3 = select <8 x i1> %2, <8 x float> %x, <8 x float> zeroinitializer
  %4 = fmul <8 x float> %3, splat (float 0x3FF7154760000000)
  %5 = bitcast <8 x float> %4 to <8 x i32>
  %6 = and <8 x i32> %5, splat (i32 -2147483648)
  %7 = or <8 x i32> splat (i32 1258291200), %6
  %8 = bitcast <8 x i32> %7 to <8 x float>
  %9 = fadd <8 x float> %4, %8
  %10 = fsub <8 x float> %9, %8
  %11 = fptosi <8 x float> %10 to <8 x i32>
  %12 = sitofp <8 x i32> %11 to <8 x float>
  %13 = fmul <8 x float> %12, splat (float 0xBFE62E4000000000)
  %14 = fadd <8 x float> %13, %3
  %15 = fmul <8 x float> %12, splat (float 0xBEB7F7D1C0000000)
  %16 = fadd <8 x float> %15, %14
  %17 = fmul <8 x float> splat (float 0x3F2A057B40000000), %16
  %18 = fadd <8 x float> %17, splat (float 0x3F56D2D920000000)
  %19 = fmul <8 x float> %18, %16
  %20 = fadd <8 x float> %19, splat (float 0x3F811114C0000000)
  %21 = fmul <8 x float> %20, %16
  %22 = fadd <8 x float> %21, splat (float 0x3FA5554F40000000)
  %23 = fmul <8 x float> %22, %16
  %24 = fadd <8 x float> %23, splat (float 0x3FC5555560000000)
  %25 = fmul <8 x float> %24, %16
  %26 = fadd <8 x float> %25, splat (float 5.000000e-01)
  %27 = fmul <8 x float> %16, %16
  %28 = fmul <8 x float> %27, %26
  %29 = fadd <8 x float> %16, %28
  %30 = fadd <8 x float> splat (float 1.000000e+00), %29
  %31 = ashr <8 x i32> %11, splat (i32 1)
  %32 = add <8 x i32> %31, splat (i32 127)
  %33 = shl <8 x i32> %32, splat (i32 23)
  %34 = bitcast <8 x i32> %33 to <8 x float>
  %35 = fmul <8 x float> %30, %34
  %36 = sub <8 x i32> %11, %31
  %37 = add <8 x i32> %36, splat (i32 127)
  %38 = shl <8 x i32> %37, splat (i32 23)
  %39 = bitcast <8 x i32> %38 to <8 x float>
  %40 = fmul <8 x float> %35, %39
  %41 = fcmp olt <8 x float> %x, splat (float -1.040000e+02)
  %42 = select <8 x i1> %41, <8 x float> zeroinitializer, <8 x float> %40
  %43 = fcmp ogt <8 x float> %x, splat (float 1.000000e+02)
  %44 = select <8 x i1> %43, <8 x float> splat (float 0x7FF0000000000000), <8 x float> %42
  %45 = fcmp uno <8 x float> %x, %x
  %46 = select <8 x i1> %45, <8 x float> splat (float 0x7FF8000000000000), <8 x float> %44
  ret <8 x float> %46
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #2

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(write) }
attributes #3 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #4 = { alwaysinline norecurse nounwind willreturn memory(none) "luisa.cpu.native_math" }

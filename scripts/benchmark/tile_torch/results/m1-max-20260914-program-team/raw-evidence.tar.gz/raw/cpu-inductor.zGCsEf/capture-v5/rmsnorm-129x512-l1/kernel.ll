; ModuleID = 'luisa-simd-kernel'
source_filename = "luisa-simd-kernel"

define internal void @llm_rows(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull readonly %launch_config, i32 %active_lane_count) {
prologue:
  %tile_snapshot.local = alloca [16384 x i8], align 4
  %.splatinsert = insertelement <8 x ptr> poison, ptr %tile_snapshot.local, i64 0
  %.splat = shufflevector <8 x ptr> %.splatinsert, <8 x ptr> poison, <8 x i32> zeroinitializer
  %0 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat, 0
  %1 = insertvalue { <8 x ptr>, <8 x i64> } %0, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %tile_snapshot.local1 = alloca [16384 x i8], align 4
  %.splatinsert2 = insertelement <8 x ptr> poison, ptr %tile_snapshot.local1, i64 0
  %.splat3 = shufflevector <8 x ptr> %.splatinsert2, <8 x ptr> poison, <8 x i32> zeroinitializer
  %2 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %.splat3, 0
  %3 = insertvalue { <8 x ptr>, <8 x i64> } %2, <8 x i64> <i64 0, i64 4, i64 8, i64 12, i64 16, i64 20, i64 24, i64 28>, 1
  %.spill = alloca <8 x i64>, align 64
  store <8 x i64> zeroinitializer, ptr %.spill, align 64
  %tile_snapshot.spill = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill, align 64
  %.slot = alloca i64, align 8
  store i64 0, ptr %.slot, align 4
  %.spill4 = alloca i64, align 8
  store i64 0, ptr %.spill4, align 4
  %.spill5 = alloca i64, align 8
  store i64 0, ptr %.spill5, align 4
  %.spill6 = alloca i64, align 8
  store i64 0, ptr %.spill6, align 4
  %.slot7 = alloca i64, align 8
  store i64 0, ptr %.slot7, align 4
  %.slot8 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot8, align 32
  %.slot9 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot9, align 32
  %.slot10 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot10, align 32
  %.slot11 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.slot11, align 32
  %.spill12 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill12, align 32
  %tile_snapshot.spill13 = alloca { <8 x ptr>, <8 x i64> }, align 64
  store { <8 x ptr>, <8 x i64> } zeroinitializer, ptr %tile_snapshot.spill13, align 64
  %.slot14 = alloca i64, align 8
  store i64 0, ptr %.slot14, align 4
  %.spill15 = alloca <8 x float>, align 32
  store <8 x float> zeroinitializer, ptr %.spill15, align 32
  %.slot16 = alloca i64, align 8
  store i64 0, ptr %.slot16, align 4
  %4 = getelementptr i8, ptr %argument_buffer, i64 0
  %5 = load ptr, ptr %4, align 16
  %6 = getelementptr i8, ptr %4, i64 8
  %7 = load i64, ptr %6, align 8
  %8 = insertvalue { ptr, i64 } poison, ptr %5, 0
  %9 = insertvalue { ptr, i64 } %8, i64 %7, 1
  %10 = getelementptr i8, ptr %argument_buffer, i64 16
  %11 = load ptr, ptr %10, align 16
  %12 = getelementptr i8, ptr %10, i64 8
  %13 = load i64, ptr %12, align 8
  %14 = insertvalue { ptr, i64 } poison, ptr %11, 0
  %15 = insertvalue { ptr, i64 } %14, i64 %13, 1
  %16 = getelementptr i8, ptr %argument_buffer, i64 32
  %17 = load ptr, ptr %16, align 16
  %18 = getelementptr i8, ptr %16, i64 8
  %19 = load i64, ptr %18, align 8
  %20 = insertvalue { ptr, i64 } poison, ptr %17, 0
  %21 = insertvalue { ptr, i64 } %20, i64 %19, 1
  %22 = getelementptr i8, ptr %argument_buffer, i64 48
  %23 = load ptr, ptr %22, align 16
  %24 = getelementptr i8, ptr %22, i64 8
  %25 = load i64, ptr %24, align 8
  %26 = insertvalue { ptr, i64 } poison, ptr %23, 0
  %27 = insertvalue { ptr, i64 } %26, i64 %25, 1
  %28 = load i32, ptr %launch_config, align 4
  %29 = getelementptr i8, ptr %launch_config, i64 12
  %30 = load i32, ptr %29, align 4
  %31 = getelementptr i8, ptr %launch_config, i64 4
  %32 = load i32, ptr %31, align 4
  %33 = getelementptr i8, ptr %launch_config, i64 16
  %34 = load i32, ptr %33, align 4
  %35 = getelementptr i8, ptr %launch_config, i64 8
  %36 = load i32, ptr %35, align 4
  %37 = getelementptr i8, ptr %launch_config, i64 20
  %38 = load i32, ptr %37, align 4
  %39 = getelementptr i8, ptr %launch_config, i64 36
  %40 = load i32, ptr %39, align 4
  %.splatinsert17 = insertelement <8 x i32> poison, i32 %40, i64 0
  %.splat18 = shufflevector <8 x i32> %.splatinsert17, <8 x i32> poison, <8 x i32> zeroinitializer
  %41 = add <8 x i32> %.splat18, <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>
  %42 = mul i32 %28, 32
  %.splatinsert19 = insertelement <8 x i32> poison, i32 %42, i64 0
  %.splat20 = shufflevector <8 x i32> %.splatinsert19, <8 x i32> poison, <8 x i32> zeroinitializer
  %43 = add <8 x i32> %.splat20, %41
  %44 = mul i32 %32, 1
  %.splatinsert21 = insertelement <8 x i32> poison, i32 %44, i64 0
  %.splat22 = shufflevector <8 x i32> %.splatinsert21, <8 x i32> poison, <8 x i32> zeroinitializer
  %45 = add <8 x i32> %.splat22, zeroinitializer
  %46 = mul i32 %36, 1
  %.splatinsert23 = insertelement <8 x i32> poison, i32 %46, i64 0
  %.splat24 = shufflevector <8 x i32> %.splatinsert23, <8 x i32> poison, <8 x i32> zeroinitializer
  %47 = add <8 x i32> %.splat24, zeroinitializer
  %48 = insertvalue [3 x <8 x i32>] poison, <8 x i32> %43, 0
  %49 = insertvalue [3 x <8 x i32>] %48, <8 x i32> %45, 1
  %50 = insertvalue [3 x <8 x i32>] %49, <8 x i32> %47, 2
  %.splatinsert25 = insertelement <8 x i32> poison, i32 %active_lane_count, i64 0
  %.splat26 = shufflevector <8 x i32> %.splatinsert25, <8 x i32> poison, <8 x i32> zeroinitializer
  %51 = icmp ult <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7>, %.splat26
  %52 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  br i1 %52, label %direct.activate, label %direct.inactive

direct.schedule.0:                                ; preds = %direct.activate
  %53 = extractvalue [3 x <8 x i32>] %50, 0
  %54 = zext <8 x i32> %53 to <8 x i64>
  %55 = select <8 x i1> %51, <8 x i64> %54, <8 x i64> zeroinitializer
  %56 = select <8 x i1> %51, <8 x i64> splat (i64 1), <8 x i64> splat (i64 1)
  %57 = sdiv <8 x i64> %55, %56
  %58 = load <8 x i64>, ptr %.spill, align 64
  %59 = select <8 x i1> %51, <8 x i64> %57, <8 x i64> %58
  store <8 x i64> %59, ptr %.spill, align 64
  %60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %61 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %62 = extractvalue { <8 x ptr>, <8 x i64> } %60, 0
  %63 = select <8 x i1> %51, <8 x ptr> %61, <8 x ptr> %62
  %64 = extractvalue { <8 x ptr>, <8 x i64> } %1, 1
  %65 = extractvalue { <8 x ptr>, <8 x i64> } %60, 1
  %66 = select <8 x i1> %51, <8 x i64> %64, <8 x i64> %65
  %67 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %63, 0
  %68 = insertvalue { <8 x ptr>, <8 x i64> } %67, <8 x i64> %66, 1
  store { <8 x ptr>, <8 x i64> } %68, ptr %tile_snapshot.spill, align 64
  store i64 0, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.1:                                ; preds = %direct.schedule.2, %direct.schedule.0
  %.state = load i64, ptr %.slot, align 4
  %69 = icmp slt i64 %.state, 512
  br i1 %69, label %direct.true, label %direct.false

direct.schedule.2:                                ; preds = %direct.true
  %.spill.load = load <8 x i64>, ptr %.spill, align 64
  %70 = add <8 x i64> %.spill.load, zeroinitializer
  %71 = add <8 x i64> zeroinitializer, %70
  %.state27 = load i64, ptr %.slot, align 4
  %72 = add i64 0, %.state27
  %73 = mul <8 x i64> %71, splat (i64 512)
  %.splatinsert28 = insertelement <8 x i64> poison, i64 %72, i64 0
  %.splat29 = shufflevector <8 x i64> %.splatinsert28, <8 x i64> poison, <8 x i32> zeroinitializer
  %74 = add <8 x i64> %73, %.splat29
  %75 = extractvalue { ptr, i64 } %9, 0
  %76 = mul <8 x i64> %74, splat (i64 4)
  %77 = getelementptr i8, ptr %75, <8 x i64> %76
  %78 = call <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr> align 1 %77, <8 x i1> %51, <8 x float> zeroinitializer)
  %tile_snapshot.spill.load = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %79 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 0
  %80 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load, 1
  %.state30 = load i64, ptr %.slot, align 4
  %.splatinsert31 = insertelement <8 x i64> poison, i64 %.state30, i64 0
  %.splat32 = shufflevector <8 x i64> %.splatinsert31, <8 x i64> poison, <8 x i32> zeroinitializer
  %81 = mul <8 x i64> %.splat32, splat (i64 32)
  %82 = add <8 x i64> %80, %81
  %83 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %79, 0
  %84 = insertvalue { <8 x ptr>, <8 x i64> } %83, <8 x i64> %82, 1
  %85 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %86 = extractvalue { <8 x ptr>, <8 x i64> } %84, 1
  %87 = extractelement <8 x ptr> %85, i32 0
  %88 = extractelement <8 x i64> %86, i32 0
  %89 = sub i64 %88, 0
  %90 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %91 = select i1 %90, i64 %89, i64 0
  %private.contiguous.address = getelementptr i8, ptr %87, i64 %91
  %private.contiguous.preserve = load <8 x float>, ptr %private.contiguous.address, align 4
  %92 = select <8 x i1> %51, <8 x float> %78, <8 x float> %private.contiguous.preserve
  store <8 x float> %92, ptr %private.contiguous.address, align 4
  %.state33 = load i64, ptr %.slot, align 4
  %93 = add i64 %.state33, 1
  store i64 %93, ptr %.slot, align 4
  br label %direct.schedule.1

direct.schedule.3:                                ; preds = %direct.false
  store i64 0, ptr %.spill4, align 4
  store i64 0, ptr %.spill5, align 4
  store i64 0, ptr %.spill6, align 4
  %tile_snapshot.spill.load34 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %94 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load34, 0
  %95 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load34, 1
  %96 = add <8 x i64> %95, zeroinitializer
  %97 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %94, 0
  %98 = insertvalue { <8 x ptr>, <8 x i64> } %97, <8 x i64> %96, 1
  %99 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %100 = extractvalue { <8 x ptr>, <8 x i64> } %98, 1
  %101 = extractelement <8 x ptr> %99, i32 0
  %102 = extractelement <8 x i64> %100, i32 0
  %103 = sub i64 %102, 0
  %104 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %105 = select i1 %104, i64 %103, i64 0
  %private.contiguous.address35 = getelementptr i8, ptr %101, i64 %105
  %private.contiguous.load = load <8 x float>, ptr %private.contiguous.address35, align 4
  %106 = select <8 x i1> %51, <8 x float> %private.contiguous.load, <8 x float> zeroinitializer
  %107 = fmul <8 x float> %106, %106
  %tile_snapshot.spill.load36 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %108 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 0
  %109 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load36, 1
  %110 = add <8 x i64> %109, splat (i64 32)
  %111 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %108, 0
  %112 = insertvalue { <8 x ptr>, <8 x i64> } %111, <8 x i64> %110, 1
  %113 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %114 = extractvalue { <8 x ptr>, <8 x i64> } %112, 1
  %115 = extractelement <8 x ptr> %113, i32 0
  %116 = extractelement <8 x i64> %114, i32 0
  %117 = sub i64 %116, 0
  %118 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %119 = select i1 %118, i64 %117, i64 0
  %private.contiguous.address37 = getelementptr i8, ptr %115, i64 %119
  %private.contiguous.load38 = load <8 x float>, ptr %private.contiguous.address37, align 4
  %120 = select <8 x i1> %51, <8 x float> %private.contiguous.load38, <8 x float> zeroinitializer
  %121 = fmul <8 x float> %120, %120
  %tile_snapshot.spill.load39 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %122 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load39, 0
  %123 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load39, 1
  %124 = add <8 x i64> %123, splat (i64 64)
  %125 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %122, 0
  %126 = insertvalue { <8 x ptr>, <8 x i64> } %125, <8 x i64> %124, 1
  %127 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %128 = extractvalue { <8 x ptr>, <8 x i64> } %126, 1
  %129 = extractelement <8 x ptr> %127, i32 0
  %130 = extractelement <8 x i64> %128, i32 0
  %131 = sub i64 %130, 0
  %132 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %133 = select i1 %132, i64 %131, i64 0
  %private.contiguous.address40 = getelementptr i8, ptr %129, i64 %133
  %private.contiguous.load41 = load <8 x float>, ptr %private.contiguous.address40, align 4
  %134 = select <8 x i1> %51, <8 x float> %private.contiguous.load41, <8 x float> zeroinitializer
  %135 = fmul <8 x float> %134, %134
  %tile_snapshot.spill.load42 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %136 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 0
  %137 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load42, 1
  %138 = add <8 x i64> %137, splat (i64 96)
  %139 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %136, 0
  %140 = insertvalue { <8 x ptr>, <8 x i64> } %139, <8 x i64> %138, 1
  %141 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %142 = extractvalue { <8 x ptr>, <8 x i64> } %140, 1
  %143 = extractelement <8 x ptr> %141, i32 0
  %144 = extractelement <8 x i64> %142, i32 0
  %145 = sub i64 %144, 0
  %146 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %147 = select i1 %146, i64 %145, i64 0
  %private.contiguous.address43 = getelementptr i8, ptr %143, i64 %147
  %private.contiguous.load44 = load <8 x float>, ptr %private.contiguous.address43, align 4
  %148 = select <8 x i1> %51, <8 x float> %private.contiguous.load44, <8 x float> zeroinitializer
  %149 = fmul <8 x float> %148, %148
  store i64 4, ptr %.slot7, align 4
  %150 = load <8 x float>, ptr %.slot8, align 32
  %151 = select <8 x i1> %51, <8 x float> %107, <8 x float> %150
  store <8 x float> %151, ptr %.slot8, align 32
  %152 = load <8 x float>, ptr %.slot9, align 32
  %153 = select <8 x i1> %51, <8 x float> %121, <8 x float> %152
  store <8 x float> %153, ptr %.slot9, align 32
  %154 = load <8 x float>, ptr %.slot10, align 32
  %155 = select <8 x i1> %51, <8 x float> %135, <8 x float> %154
  store <8 x float> %155, ptr %.slot10, align 32
  %156 = load <8 x float>, ptr %.slot11, align 32
  %157 = select <8 x i1> %51, <8 x float> %149, <8 x float> %156
  store <8 x float> %157, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.4:                                ; preds = %direct.schedule.5, %direct.schedule.3
  %.state45 = load i64, ptr %.slot7, align 4
  %158 = icmp slt i64 %.state45, 512
  br i1 %158, label %direct.true46, label %direct.false47

direct.schedule.5:                                ; preds = %direct.true46
  %.state48 = load i64, ptr %.slot7, align 4
  %159 = add i64 %.state48, 0
  %160 = sdiv i64 %159, 1
  %.spill.load49 = load i64, ptr %.spill5, align 4
  %161 = add i64 %.spill.load49, %160
  %.spill.load50 = load i64, ptr %.spill6, align 4
  %162 = add i64 %.spill.load50, %161
  %tile_snapshot.spill.load51 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %163 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 0
  %164 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load51, 1
  %.splatinsert52 = insertelement <8 x i64> poison, i64 %162, i64 0
  %.splat53 = shufflevector <8 x i64> %.splatinsert52, <8 x i64> poison, <8 x i32> zeroinitializer
  %165 = mul <8 x i64> %.splat53, splat (i64 32)
  %166 = add <8 x i64> %164, %165
  %167 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %163, 0
  %168 = insertvalue { <8 x ptr>, <8 x i64> } %167, <8 x i64> %166, 1
  %169 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %170 = extractvalue { <8 x ptr>, <8 x i64> } %168, 1
  %171 = extractelement <8 x ptr> %169, i32 0
  %172 = extractelement <8 x i64> %170, i32 0
  %173 = sub i64 %172, 0
  %174 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %175 = select i1 %174, i64 %173, i64 0
  %private.contiguous.address54 = getelementptr i8, ptr %171, i64 %175
  %private.contiguous.load55 = load <8 x float>, ptr %private.contiguous.address54, align 4
  %176 = select <8 x i1> %51, <8 x float> %private.contiguous.load55, <8 x float> zeroinitializer
  %177 = fmul <8 x float> %176, %176
  %.state56 = load <8 x float>, ptr %.slot8, align 32
  %178 = fadd <8 x float> %.state56, %177
  %.state57 = load i64, ptr %.slot7, align 4
  %179 = add i64 %.state57, 1
  %180 = sdiv i64 %179, 1
  %.spill.load58 = load i64, ptr %.spill5, align 4
  %181 = add i64 %.spill.load58, %180
  %.spill.load59 = load i64, ptr %.spill6, align 4
  %182 = add i64 %.spill.load59, %181
  %tile_snapshot.spill.load60 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %183 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 0
  %184 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load60, 1
  %.splatinsert61 = insertelement <8 x i64> poison, i64 %182, i64 0
  %.splat62 = shufflevector <8 x i64> %.splatinsert61, <8 x i64> poison, <8 x i32> zeroinitializer
  %185 = mul <8 x i64> %.splat62, splat (i64 32)
  %186 = add <8 x i64> %184, %185
  %187 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %183, 0
  %188 = insertvalue { <8 x ptr>, <8 x i64> } %187, <8 x i64> %186, 1
  %189 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %190 = extractvalue { <8 x ptr>, <8 x i64> } %188, 1
  %191 = extractelement <8 x ptr> %189, i32 0
  %192 = extractelement <8 x i64> %190, i32 0
  %193 = sub i64 %192, 0
  %194 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %195 = select i1 %194, i64 %193, i64 0
  %private.contiguous.address63 = getelementptr i8, ptr %191, i64 %195
  %private.contiguous.load64 = load <8 x float>, ptr %private.contiguous.address63, align 4
  %196 = select <8 x i1> %51, <8 x float> %private.contiguous.load64, <8 x float> zeroinitializer
  %197 = fmul <8 x float> %196, %196
  %.state65 = load <8 x float>, ptr %.slot9, align 32
  %198 = fadd <8 x float> %.state65, %197
  %.state66 = load i64, ptr %.slot7, align 4
  %199 = add i64 %.state66, 2
  %200 = sdiv i64 %199, 1
  %.spill.load67 = load i64, ptr %.spill5, align 4
  %201 = add i64 %.spill.load67, %200
  %.spill.load68 = load i64, ptr %.spill6, align 4
  %202 = add i64 %.spill.load68, %201
  %tile_snapshot.spill.load69 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %203 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 0
  %204 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load69, 1
  %.splatinsert70 = insertelement <8 x i64> poison, i64 %202, i64 0
  %.splat71 = shufflevector <8 x i64> %.splatinsert70, <8 x i64> poison, <8 x i32> zeroinitializer
  %205 = mul <8 x i64> %.splat71, splat (i64 32)
  %206 = add <8 x i64> %204, %205
  %207 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %203, 0
  %208 = insertvalue { <8 x ptr>, <8 x i64> } %207, <8 x i64> %206, 1
  %209 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %210 = extractvalue { <8 x ptr>, <8 x i64> } %208, 1
  %211 = extractelement <8 x ptr> %209, i32 0
  %212 = extractelement <8 x i64> %210, i32 0
  %213 = sub i64 %212, 0
  %214 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %215 = select i1 %214, i64 %213, i64 0
  %private.contiguous.address72 = getelementptr i8, ptr %211, i64 %215
  %private.contiguous.load73 = load <8 x float>, ptr %private.contiguous.address72, align 4
  %216 = select <8 x i1> %51, <8 x float> %private.contiguous.load73, <8 x float> zeroinitializer
  %217 = fmul <8 x float> %216, %216
  %.state74 = load <8 x float>, ptr %.slot10, align 32
  %218 = fadd <8 x float> %.state74, %217
  %.state75 = load i64, ptr %.slot7, align 4
  %219 = add i64 %.state75, 3
  %220 = sdiv i64 %219, 1
  %.spill.load76 = load i64, ptr %.spill5, align 4
  %221 = add i64 %.spill.load76, %220
  %.spill.load77 = load i64, ptr %.spill6, align 4
  %222 = add i64 %.spill.load77, %221
  %tile_snapshot.spill.load78 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %223 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 0
  %224 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load78, 1
  %.splatinsert79 = insertelement <8 x i64> poison, i64 %222, i64 0
  %.splat80 = shufflevector <8 x i64> %.splatinsert79, <8 x i64> poison, <8 x i32> zeroinitializer
  %225 = mul <8 x i64> %.splat80, splat (i64 32)
  %226 = add <8 x i64> %224, %225
  %227 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %223, 0
  %228 = insertvalue { <8 x ptr>, <8 x i64> } %227, <8 x i64> %226, 1
  %229 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %230 = extractvalue { <8 x ptr>, <8 x i64> } %228, 1
  %231 = extractelement <8 x ptr> %229, i32 0
  %232 = extractelement <8 x i64> %230, i32 0
  %233 = sub i64 %232, 0
  %234 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %235 = select i1 %234, i64 %233, i64 0
  %private.contiguous.address81 = getelementptr i8, ptr %231, i64 %235
  %private.contiguous.load82 = load <8 x float>, ptr %private.contiguous.address81, align 4
  %236 = select <8 x i1> %51, <8 x float> %private.contiguous.load82, <8 x float> zeroinitializer
  %237 = fmul <8 x float> %236, %236
  %.state83 = load <8 x float>, ptr %.slot11, align 32
  %238 = fadd <8 x float> %.state83, %237
  %.state84 = load i64, ptr %.slot7, align 4
  %239 = add i64 %.state84, 4
  store i64 %239, ptr %.slot7, align 4
  %240 = load <8 x float>, ptr %.slot8, align 32
  %241 = select <8 x i1> %51, <8 x float> %178, <8 x float> %240
  store <8 x float> %241, ptr %.slot8, align 32
  %242 = load <8 x float>, ptr %.slot9, align 32
  %243 = select <8 x i1> %51, <8 x float> %198, <8 x float> %242
  store <8 x float> %243, ptr %.slot9, align 32
  %244 = load <8 x float>, ptr %.slot10, align 32
  %245 = select <8 x i1> %51, <8 x float> %218, <8 x float> %244
  store <8 x float> %245, ptr %.slot10, align 32
  %246 = load <8 x float>, ptr %.slot11, align 32
  %247 = select <8 x i1> %51, <8 x float> %238, <8 x float> %246
  store <8 x float> %247, ptr %.slot11, align 32
  br label %direct.schedule.4

direct.schedule.6:                                ; preds = %direct.false47
  %.state85 = load <8 x float>, ptr %.slot8, align 32
  %248 = fadd <8 x float> zeroinitializer, %.state85
  %.state86 = load <8 x float>, ptr %.slot9, align 32
  %249 = fadd <8 x float> %248, %.state86
  %.state87 = load <8 x float>, ptr %.slot10, align 32
  %250 = fadd <8 x float> %249, %.state87
  %.state88 = load <8 x float>, ptr %.slot11, align 32
  %251 = fadd <8 x float> %250, %.state88
  %252 = fdiv <8 x float> %251, splat (float 5.120000e+02)
  %253 = load <8 x float>, ptr %.spill12, align 32
  %254 = select <8 x i1> %51, <8 x float> %252, <8 x float> %253
  store <8 x float> %254, ptr %.spill12, align 32
  %255 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %256 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %257 = extractvalue { <8 x ptr>, <8 x i64> } %255, 0
  %258 = select <8 x i1> %51, <8 x ptr> %256, <8 x ptr> %257
  %259 = extractvalue { <8 x ptr>, <8 x i64> } %3, 1
  %260 = extractvalue { <8 x ptr>, <8 x i64> } %255, 1
  %261 = select <8 x i1> %51, <8 x i64> %259, <8 x i64> %260
  %262 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %258, 0
  %263 = insertvalue { <8 x ptr>, <8 x i64> } %262, <8 x i64> %261, 1
  store { <8 x ptr>, <8 x i64> } %263, ptr %tile_snapshot.spill13, align 64
  store i64 0, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.7:                                ; preds = %direct.schedule.8, %direct.schedule.6
  %.state89 = load i64, ptr %.slot14, align 4
  %264 = icmp slt i64 %.state89, 512
  br i1 %264, label %direct.true90, label %direct.false91

direct.schedule.8:                                ; preds = %direct.true90
  %.spill.load92 = load i64, ptr %.spill4, align 4
  %265 = add i64 %.spill.load92, 0
  %.state93 = load i64, ptr %.slot14, align 4
  %266 = add i64 0, %.state93
  %267 = mul i64 %265, 512
  %268 = add i64 %267, %266
  %269 = extractvalue { ptr, i64 } %15, 0
  %270 = mul i64 %268, 4
  %271 = getelementptr i8, ptr %269, i64 %270
  %272 = load float, ptr %271, align 4
  %.splatinsert94 = insertelement <8 x float> poison, float %272, i64 0
  %.splat95 = shufflevector <8 x float> %.splatinsert94, <8 x float> poison, <8 x i32> zeroinitializer
  %tile_snapshot.spill.load96 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %273 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 0
  %274 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load96, 1
  %.state97 = load i64, ptr %.slot14, align 4
  %.splatinsert98 = insertelement <8 x i64> poison, i64 %.state97, i64 0
  %.splat99 = shufflevector <8 x i64> %.splatinsert98, <8 x i64> poison, <8 x i32> zeroinitializer
  %275 = mul <8 x i64> %.splat99, splat (i64 32)
  %276 = add <8 x i64> %274, %275
  %277 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %273, 0
  %278 = insertvalue { <8 x ptr>, <8 x i64> } %277, <8 x i64> %276, 1
  %279 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %280 = extractvalue { <8 x ptr>, <8 x i64> } %278, 1
  %281 = extractelement <8 x ptr> %279, i32 0
  %282 = extractelement <8 x i64> %280, i32 0
  %283 = sub i64 %282, 0
  %284 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %285 = select i1 %284, i64 %283, i64 0
  %private.contiguous.address100 = getelementptr i8, ptr %281, i64 %285
  %private.contiguous.preserve101 = load <8 x float>, ptr %private.contiguous.address100, align 4
  %286 = select <8 x i1> %51, <8 x float> %.splat95, <8 x float> %private.contiguous.preserve101
  store <8 x float> %286, ptr %private.contiguous.address100, align 4
  %.state102 = load i64, ptr %.slot14, align 4
  %287 = add i64 %.state102, 1
  store i64 %287, ptr %.slot14, align 4
  br label %direct.schedule.7

direct.schedule.9:                                ; preds = %direct.false91
  %.spill.load103 = load <8 x float>, ptr %.spill12, align 32
  %288 = fadd <8 x float> %.spill.load103, splat (float 0x3EE4F8B580000000)
  %289 = call <8 x float> @llvm.sqrt.v8f32(<8 x float> %288)
  %290 = load <8 x float>, ptr %.spill15, align 32
  %291 = select <8 x i1> %51, <8 x float> %289, <8 x float> %290
  store <8 x float> %291, ptr %.spill15, align 32
  store i64 0, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.10:                               ; preds = %direct.schedule.11, %direct.schedule.9
  %.state104 = load i64, ptr %.slot16, align 4
  %292 = icmp slt i64 %.state104, 512
  br i1 %292, label %direct.true105, label %direct.false106

direct.schedule.11:                               ; preds = %direct.true105
  %.spill.load107 = load <8 x i64>, ptr %.spill, align 64
  %293 = add <8 x i64> %.spill.load107, zeroinitializer
  %294 = add <8 x i64> zeroinitializer, %293
  %.state108 = load i64, ptr %.slot16, align 4
  %295 = add i64 0, %.state108
  %296 = mul <8 x i64> %294, splat (i64 512)
  %.splatinsert109 = insertelement <8 x i64> poison, i64 %295, i64 0
  %.splat110 = shufflevector <8 x i64> %.splatinsert109, <8 x i64> poison, <8 x i32> zeroinitializer
  %297 = add <8 x i64> %296, %.splat110
  %.spill.load111 = load i64, ptr %.spill6, align 4
  %.state112 = load i64, ptr %.slot16, align 4
  %298 = add i64 %.spill.load111, %.state112
  %.spill.load113 = load i64, ptr %.spill6, align 4
  %299 = add i64 %.spill.load113, %298
  %tile_snapshot.spill.load114 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill, align 64
  %300 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 0
  %301 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load114, 1
  %.splatinsert115 = insertelement <8 x i64> poison, i64 %299, i64 0
  %.splat116 = shufflevector <8 x i64> %.splatinsert115, <8 x i64> poison, <8 x i32> zeroinitializer
  %302 = mul <8 x i64> %.splat116, splat (i64 32)
  %303 = add <8 x i64> %301, %302
  %304 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %300, 0
  %305 = insertvalue { <8 x ptr>, <8 x i64> } %304, <8 x i64> %303, 1
  %306 = extractvalue { <8 x ptr>, <8 x i64> } %1, 0
  %307 = extractvalue { <8 x ptr>, <8 x i64> } %305, 1
  %308 = extractelement <8 x ptr> %306, i32 0
  %309 = extractelement <8 x i64> %307, i32 0
  %310 = sub i64 %309, 0
  %311 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %312 = select i1 %311, i64 %310, i64 0
  %private.contiguous.address117 = getelementptr i8, ptr %308, i64 %312
  %private.contiguous.load118 = load <8 x float>, ptr %private.contiguous.address117, align 4
  %313 = select <8 x i1> %51, <8 x float> %private.contiguous.load118, <8 x float> zeroinitializer
  %.spill.load119 = load <8 x float>, ptr %.spill15, align 32
  %314 = fdiv <8 x float> %313, %.spill.load119
  %tile_snapshot.spill.load120 = load { <8 x ptr>, <8 x i64> }, ptr %tile_snapshot.spill13, align 64
  %315 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 0
  %316 = extractvalue { <8 x ptr>, <8 x i64> } %tile_snapshot.spill.load120, 1
  %.splatinsert121 = insertelement <8 x i64> poison, i64 %298, i64 0
  %.splat122 = shufflevector <8 x i64> %.splatinsert121, <8 x i64> poison, <8 x i32> zeroinitializer
  %317 = mul <8 x i64> %.splat122, splat (i64 32)
  %318 = add <8 x i64> %316, %317
  %319 = insertvalue { <8 x ptr>, <8 x i64> } poison, <8 x ptr> %315, 0
  %320 = insertvalue { <8 x ptr>, <8 x i64> } %319, <8 x i64> %318, 1
  %321 = extractvalue { <8 x ptr>, <8 x i64> } %3, 0
  %322 = extractvalue { <8 x ptr>, <8 x i64> } %320, 1
  %323 = extractelement <8 x ptr> %321, i32 0
  %324 = extractelement <8 x i64> %322, i32 0
  %325 = sub i64 %324, 0
  %326 = call i1 @llvm.vector.reduce.or.v8i1(<8 x i1> %51)
  %327 = select i1 %326, i64 %325, i64 0
  %private.contiguous.address123 = getelementptr i8, ptr %323, i64 %327
  %private.contiguous.load124 = load <8 x float>, ptr %private.contiguous.address123, align 4
  %328 = select <8 x i1> %51, <8 x float> %private.contiguous.load124, <8 x float> zeroinitializer
  %329 = fmul <8 x float> %314, %328
  %330 = extractvalue { ptr, i64 } %27, 0
  %331 = mul <8 x i64> %297, splat (i64 4)
  %332 = getelementptr i8, ptr %330, <8 x i64> %331
  call void @llvm.masked.scatter.v8f32.v8p0(<8 x float> %329, <8 x ptr> align 1 %332, <8 x i1> %51)
  %.state125 = load i64, ptr %.slot16, align 4
  %333 = add i64 %.state125, 1
  store i64 %333, ptr %.slot16, align 4
  br label %direct.schedule.10

direct.schedule.12:                               ; preds = %direct.false106
  ret void

direct.activate:                                  ; preds = %prologue
  br label %direct.schedule.0

direct.inactive:                                  ; preds = %prologue
  ret void

direct.true:                                      ; preds = %direct.schedule.1
  br label %direct.schedule.2

direct.false:                                     ; preds = %direct.schedule.1
  br label %direct.schedule.3

direct.true46:                                    ; preds = %direct.schedule.4
  br label %direct.schedule.5

direct.false47:                                   ; preds = %direct.schedule.4
  br label %direct.schedule.6

direct.true90:                                    ; preds = %direct.schedule.7
  br label %direct.schedule.8

direct.false91:                                   ; preds = %direct.schedule.7
  br label %direct.schedule.9

direct.true105:                                   ; preds = %direct.schedule.10
  br label %direct.schedule.11

direct.false106:                                  ; preds = %direct.schedule.10
  br label %direct.schedule.12
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i1 @llvm.vector.reduce.or.v8i1(<8 x i1>) #0

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(read)
declare <8 x float> @llvm.masked.gather.v8f32.v8p0(<8 x ptr>, <8 x i1>, <8 x float>) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare <8 x float> @llvm.sqrt.v8f32(<8 x float>) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(write)
declare void @llvm.masked.scatter.v8f32.v8p0(<8 x float>, <8 x ptr>, <8 x i1>) #3

define internal void @llm_rows.packet_batch(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %packet_count) {
packet.batch.prologue:
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %base.thread.index = load i32, ptr %thread.index.address, align 4
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.x = load i32, ptr %block.x.address, align 4
  %dispatch.size.x.address = getelementptr inbounds i8, ptr %launch_config, i64 12
  %dispatch.size.x = load i32, ptr %dispatch.size.x.address, align 4
  %base.thread.index.i64 = zext i32 %base.thread.index to i64
  %0 = zext i32 %block.x to i64
  %block.origin.x = mul i64 %0, 32
  %dispatch.size.x.i64 = zext i32 %dispatch.size.x to i64
  %block.origin.in.range = icmp ule i64 %block.origin.x, %dispatch.size.x.i64
  %block.origin.safe = select i1 %block.origin.in.range, i64 %block.origin.x, i64 0
  %packet.range.start = add i64 %block.origin.safe, %base.thread.index.i64
  %1 = icmp ult i64 %packet.range.start, %dispatch.size.x.i64
  %packet.range.inside.dispatch = and i1 %block.origin.in.range, %1
  %2 = sub i64 %dispatch.size.x.i64, %packet.range.start
  %dispatch.remaining = select i1 %packet.range.inside.dispatch, i64 %2, i64 0
  %packet.range.inside.block = icmp ult i64 %base.thread.index.i64, 32
  %3 = sub i64 32, %base.thread.index.i64
  %block.remaining = select i1 %packet.range.inside.block, i64 %3, i64 0
  %4 = icmp ult i64 %dispatch.remaining, %block.remaining
  %packet.range.remaining = select i1 %4, i64 %dispatch.remaining, i64 %block.remaining
  %5 = zext i32 %packet_count to i64
  %packet.range.requested.threads = mul i64 %5, 8
  %6 = icmp ult i64 %packet.range.remaining, %packet.range.requested.threads
  %packet.range.active.threads = select i1 %6, i64 %packet.range.remaining, i64 %packet.range.requested.threads
  %7 = icmp eq i32 %packet_count, 4
  %8 = icmp uge i64 %packet.range.remaining, 32
  %packet.range.complete.static = and i1 %7, %8
  br i1 %packet.range.complete.static, label %packet.batch.full, label %packet.batch.partial

packet.batch.full:                                ; preds = %packet.batch.prologue
  store i32 %base.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index = add i32 %base.thread.index, 8
  store i32 %packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index1 = add i32 %base.thread.index, 16
  store i32 %packet.thread.index1, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %packet.thread.index2 = add i32 %base.thread.index, 24
  store i32 %packet.thread.index2, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  br label %packet.batch.exit

packet.batch.partial:                             ; preds = %packet.batch.prologue
  %packet.full.count.i64 = udiv i64 %packet.range.active.threads, 8
  %packet.full.count = trunc i64 %packet.full.count.i64 to i32
  %packet.tail.lane.count.i64 = urem i64 %packet.range.active.threads, 8
  %packet.tail.lane.count = trunc i64 %packet.tail.lane.count.i64 to i32
  %9 = icmp ne i32 %packet.full.count, 0
  br i1 %9, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.exit:                                ; preds = %packet.batch.partial.finish, %packet.batch.full
  ret void

packet.batch.partial.full.loop:                   ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %partial.packet.index = phi i32 [ 0, %packet.batch.partial ], [ %partial.packet.index.next, %packet.batch.partial.full.loop ]
  %partial.packet.thread.offset = mul i32 %partial.packet.index, 8
  %partial.packet.thread.index = add i32 %base.thread.index, %partial.packet.thread.offset
  store i32 %partial.packet.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 8)
  %partial.packet.index.next = add i32 %partial.packet.index, 1
  %partial.packet.has.more.full = icmp ult i32 %partial.packet.index.next, %packet.full.count
  br i1 %partial.packet.has.more.full, label %packet.batch.partial.full.loop, label %packet.batch.tail.check

packet.batch.tail.check:                          ; preds = %packet.batch.partial.full.loop, %packet.batch.partial
  %10 = icmp ne i32 %packet.tail.lane.count, 0
  br i1 %10, label %packet.batch.tail.call, label %packet.batch.partial.finish

packet.batch.tail.call:                           ; preds = %packet.batch.tail.check
  %packet.tail.thread.offset = mul i32 %packet.full.count, 8
  %packet.tail.thread.index = add i32 %base.thread.index, %packet.tail.thread.offset
  store i32 %packet.tail.thread.index, ptr %thread.index.address, align 4
  call void @llm_rows(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 %packet.tail.lane.count)
  br label %packet.batch.partial.finish

packet.batch.partial.finish:                      ; preds = %packet.batch.tail.call, %packet.batch.tail.check
  %packet.batch.has.requested = icmp ne i32 %packet_count, 0
  %packet.batch.last.requested = sub i32 %packet_count, 1
  %packet.batch.last.requested.offset = mul i32 %packet.batch.last.requested, 8
  %packet.batch.last.requested.index = add i32 %base.thread.index, %packet.batch.last.requested.offset
  %11 = select i1 %packet.batch.has.requested, i32 %packet.batch.last.requested.index, i32 %base.thread.index
  store i32 %11, ptr %thread.index.address, align 4
  br label %packet.batch.exit
}

define dso_local void @llm_rows.packet_batch.blocks(ptr noalias readonly %argument_buffer, ptr %return_lanes, ptr noalias nonnull %launch_config, i32 %block_count) {
block.batch.prologue:
  %block.x.address = getelementptr inbounds i8, ptr %launch_config, i64 0
  %block.y.address = getelementptr inbounds i8, ptr %launch_config, i64 4
  %block.z.address = getelementptr inbounds i8, ptr %launch_config, i64 8
  %thread.index.address = getelementptr inbounds i8, ptr %launch_config, i64 36
  %grid.x.address = getelementptr inbounds i8, ptr %launch_config, i64 44
  %grid.y.address = getelementptr inbounds i8, ptr %launch_config, i64 48
  %initial.block.x = load i32, ptr %block.x.address, align 4
  %initial.block.y = load i32, ptr %block.y.address, align 4
  %initial.block.z = load i32, ptr %block.z.address, align 4
  %grid.x = load i32, ptr %grid.x.address, align 4
  %grid.y = load i32, ptr %grid.y.address, align 4
  %block.batch.empty = icmp eq i32 %block_count, 0
  br i1 %block.batch.empty, label %block.batch.exit, label %block.batch.loop

block.batch.loop:                                 ; preds = %block.batch.loop, %block.batch.prologue
  %block.index = phi i32 [ 0, %block.batch.prologue ], [ %block.index.next, %block.batch.loop ]
  %block.x = phi i32 [ %initial.block.x, %block.batch.prologue ], [ %block.x.next, %block.batch.loop ]
  %block.y = phi i32 [ %initial.block.y, %block.batch.prologue ], [ %block.y.next, %block.batch.loop ]
  %block.z = phi i32 [ %initial.block.z, %block.batch.prologue ], [ %block.z.next, %block.batch.loop ]
  store i32 %block.x, ptr %block.x.address, align 4
  store i32 %block.y, ptr %block.y.address, align 4
  store i32 %block.z, ptr %block.z.address, align 4
  store i32 0, ptr %thread.index.address, align 4
  call void @llm_rows.packet_batch(ptr %argument_buffer, ptr %return_lanes, ptr %launch_config, i32 4)
  %block.x.incremented = add i32 %block.x, 1
  %block.x.wrap = icmp eq i32 %block.x.incremented, %grid.x
  %block.x.next = select i1 %block.x.wrap, i32 0, i32 %block.x.incremented
  %block.y.increment = zext i1 %block.x.wrap to i32
  %block.y.incremented = add i32 %block.y, %block.y.increment
  %block.y.at.end = icmp eq i32 %block.y.incremented, %grid.y
  %block.y.wrap = and i1 %block.x.wrap, %block.y.at.end
  %block.y.next = select i1 %block.y.wrap, i32 0, i32 %block.y.incremented
  %block.z.increment = zext i1 %block.y.wrap to i32
  %block.z.next = add i32 %block.z, %block.z.increment
  %block.index.next = add i32 %block.index, 1
  %block.batch.has.more = icmp ult i32 %block.index.next, %block_count
  br i1 %block.batch.has.more, label %block.batch.loop, label %block.batch.exit

block.batch.exit:                                 ; preds = %block.batch.loop, %block.batch.prologue
  ret void
}

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(read) }
attributes #2 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(write) }
